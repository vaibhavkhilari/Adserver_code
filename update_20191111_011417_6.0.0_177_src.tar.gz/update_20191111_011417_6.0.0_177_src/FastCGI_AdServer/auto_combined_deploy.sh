#!/bin/bash
#===============================================================================
#
# Pubmatic Inc. ("PubMatic") CONFIDENTIAL
# Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
# 
# NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
#technical concepts contained
# herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
#protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
#permission is obtained
# from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
#PubMatic employees, managers or contractors who have executed 
# Confidentiality and Non-disclosure agreements explicitly covering such access.
# The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
#code, which includes 
#MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
# OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
#STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
#DOES NOT CONVEY OR IMPLY ANY RIGHTS 
# TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
#DESCRIBE, IN WHOLE OR IN PART. 
# 
#          FILE:  modified_deploy.sh
# 
#         USAGE:  .deploy.sh  [--restartiptables]   [--restart_main_memcache_USOCK] [--mysql_kill_connection]  [--deploy_bin] [ --doall ]   
# 
#   DESCRIPTION:  new deploy.sh , [minimal]  
# 
#       OPTIONS:  ---
#  REQUIREMENTS:  ---
#          BUGS:  ---
#         NOTES:  added mailing support in case of issues
#        AUTHOR:  AdServerTeam
#       COMPANY:  Pubmatic
#       VERSION:  3
#       CREATED:  11/26/13 13:09:19 IST
#      REVISION:  1
#===============================================================================

DBUSER=deploy_user
DBPASSWD=#1TYvI34q

#DBUSER=kdbuser
#DBPASSWD=KdBuSeR12!


deploy_bin=false;
restartiptables=false;
restart_main_memcache_USOCK=false;
mysql_kill_connection=false;
restart_mysql=false;
is_nginx=false;
path=$(pwd)
myname=$(cat /etc/stats_collection.properties | grep stats.adserver.name | cut -d= -f2)
st=$(date +%Y%m%d)
#-------------------------------------------------------------------------------
#   below are config variables
#-------------------------------------------------------------------------------

APACHE_CTRL="/home/http/FCGI_ADSERVER/Install/Apache2/bin/apachectl";
MEMCACHE='/home/http/FCGI_ADSERVER/Build/memcached-1.4.15/memcached -t 8 -c 2048 -d -u root -m 1024 -s /home/http/memcached.socket';
ADSERVER_PATH="/home/http/FCGI_ADSERVER/Install/Apache2/htdocs/AdServer/";
IPTABLES_RESTORE="/sbin/iptables-restore"
IPTABLES_CONF="/etc/sysconfig/iptables";
DSS_MYSQL_START='sh /DSS_FILES/start_server.sh';
DSS_MYSQL_STOP='sh /DSS_FILES/stop_server.sh';
MYSQL=/etc/init.d/mysql
LOG_SIZE=5
SENDMAIL="/MONITORING_SCRIPTS/send_mail/sendmail.php"
STBLE_THREAD=2000
#log size is the size of selected capmpaign log file expected minimum check for 10 sec 


#-------------------------------------------------------------------------------
#   below are the functions of deploy.sh
#-------------------------------------------------------------------------------

if [ ! -f server/AdServerServlet ]
then
	echo " file not found AdSErverServlet "
	exit 2 
fi

if [ ! -f /home/http/FCGI_ADSERVER/Install/nginx/htdocs/crossdomain.xml ]
then
        \cp -f config/video/crossdomain.xml /home/http/FCGI_ADSERVER/Install/nginx/htdocs/crossdomain.xml
fi


cd CACHE_PUSHBACK/ADSERVER_CONFIG_RELOAD/ && make && cd ../ && make && cd ..

if [ $? -ne 0 ]
then
	echo "CACHE_PUSHBACK:ERROR_COMPILING"
	exit
fi


check_os () {

        uname -a | grep 2.6.9 >> /dev/null
        if [ $? -eq "0" ]
        then
        OS_NAME=RHEL4
        fi
        uname -a | grep 2.6.18 >> /dev/null
        if [ $? -eq "0" ]
        then
        OS_NAME=RHEL5
        fi


        uname -a | grep 2.6.32 >> /dev/null
        if [ $? -eq "0" ]
        then
        OS_NAME=RHEL6
        fi


}

check_os
if [ $OS_NAME == "RHEL6" ]
        then
                echo " the machine is centos "
                MYSQL=/etc/init.d/mysqld
        else
                MYSQL=/etc/init.d/mysql
fi

#$DSS_MYSQL_STOP
#sleep 2
#$DSS_MYSQL_STOP



function iptable_start () {
     cp /etc/sysconfig/iptables.disable /etc/sysconfig/iptables
     /etc/init.d/iptables restart
     echo "$myname:TRAFFIC_STOPPED:success:MOK:"
}    # ----------  end of function iptable_start  ----------

function apache_stop () {

  $APACHE_CTRL stop 
 
  if [ $? -eq 0 ]
  then
     echo "$myname:SERVER_stop:success:MOK:"
  else
     echo "$myname:SERVER_stop:FATAL:MERR:"
     exit 2
  fi

	if [ $is_nginx == "true" ]
	then
		pkill AdServerServlet 
		ERROR_LOG=`ls -lct /home/http/FCGI_ADSERVER/Install/nginx/logs/error.* | awk {'print $9'} | head -1`
	else
		echo  "executing the error log"
		ERROR_LOG=`ls -lct /home/http/FCGI_ADSERVER/Install/Apache2/logs/error_* | awk {'print $9'} | head -1`	
		echo $ERROR_LOG

	fi
	echo " is nginx is " $is_nginx 
	echo "file is " $ERROR_LOG 
	echo " moved file will be " $ERROR_LOG_`date | sed "s/ /_/g"`;

        mv $ERROR_LOG $ERROR_LOG.`date | sed "s/ /_/g"`;
        if [ $? -ne 0 ];
           then
               echo "$myname:Could'nt move error log:MERR" 
               exit;
        fi
}

function apache_start () {
  $APACHE_CTRL start
  sleep 3
  if [ $? -eq 0 ]
  then
			countr=$(ps -ef | grep -c httpd);
			maxCOUNT=0
	   while [ $countr -lt 5 -a $maxCOUNT -lt 5 ]
	   do
				sleep 2;
  		  echo "$myname:apache still not started:MWAIT";
				maxCOUNT=$(($maxCOUNT+1))
				countr=$(ps -ef | grep -c httpd);
	   done
	   if [ $maxCOUNT -eq 5 ]
	   then
				echo "$myname:apache_start:FATAL:MERR:";
				exit 1;
	   fi
			echo "$myname:apache_start:success:MOK:"
  else
			echo "$myname:apache_start:FATAL:MERR:"
			exit 2
  fi
}    # ----------  end of function apache_start  ----------



function nginx_start () {
	nohup /home/http/FCGI_ADSERVER/Install/nginx/bin/nginxctl.sh start &
        echo
        echo -en '\E[25;44m' "\033[2m\t Restarted WEBSERVER \033[0m"; echo
        sleep 10;
        echo 
	echo "spawnning fcgi"
	cd /home/http/FCGI_ADSERVER/Install/nginx/htdocs/AdServer/ && nohup spawn-fcgi -s /home/http/FCGI_ADSERVER/Install/nginx/adserver_nginx.socket -n -f  /home/http/FCGI_ADSERVER/Install/nginx/htdocs/AdServer/AdServerServlet >> /home/http/FCGI_ADSERVER/Install/nginx/logs/error.log 2>&1  &
	sleep 2
	chmod 777  /home/http/FCGI_ADSERVER/Install/nginx/adserver_nginx.socket;
	chown http:http /home/http/FCGI_ADSERVER/Install/nginx/adserver_nginx.socket;
	cd -
}    # ----------  end of function nginx_start  ----------




function restart_memcache () {
	pkill -9 -f memcached.socket
	count=$(ps -ef | grep -c memcached.socket )
	while [ "$count" -ne 1 ] 
	do 
		sleep 1
		pkill -9 -f memcached.socket
		count=$(ps -ef | grep -c  memcached.socket )
	done
	echo "$myname:memcache_kill:success:MOK:"
	# start memcache now !!    
	$MEMCACHE   

	if [ $? -ne 0 ]
	then
		echo "$myname:memcache_start:FATAL:MERR:" 
		exit 2 ;
	else
		echo "$myname:memcached_start:success:MOK:" 
	fi
	sleep  2 
	count=0;
	# set permissions 
	chmod 777 "/home/http/memcached.socket"
	while [ $? -ne 0 -a $count -lt 4 ];
	do
				echo "memcached.socket permission not set waiting for a sec"
				sleep 1;
				count=`expr $count + 1`
				chmod 777 "/home/http/memcached.socket"
	done
        echo "$myname:memcached_permissions:777:MOK:";
        echo -en '\E[25;44m' "\033[2m\t Restarted Unix-Socket base Main Memcache OK  \033[0m"; echo
	/CACHE_PUSHBACK/ADSERVER_RELOAD_FLAG/adserver_config_reload -l  
}    # ----------  end of function restart_memcache  ----------



#-------------------------------------------------------------------------------
#  restart mysql is  not called by main .we will kill open connections  for $DBUSER  instead . 
#-------------------------------------------------------------------------------

function restart_mysqls () {
	#RESTART DB
	$DSS_MYSQL_STOP
	sleep 2
	$MYSQL stop  ;
	$DSS_MYSQL_STOP ;
	sleep 10
	$MYSQL start  2>&1;
	$DSS_MYSQL_START ;
	sleep 5
	maxCOUNT=0
	MYSQL_PWD=$DBPASSWD mysql -u$DBUSER  AdFlex -e  "SHOW tables" > /dev/null 2>&1 ;
	while [ $? -ne 0 -a $maxCOUNT -lt 6 ]
	do
		sleep 3;
		echo "$myname:mysql_start:waiting:MWAIT:";
		maxCOUNT=$(($maxCOUNT+1))
		MYSQL_PWD=$DBPASSWD mysql -u$DBUSER   AdFlex -e  "SHOW tables" > /dev/null 2>&1 ;
	done 
	if [ $maxCOUNT -eq 6 ] 
	then 
		echo "$myname:mysql_connect:FATAL:MERR"
		php "$SENDMAIL" "DEPLOYMENT ALERTS FROM $myname"   " mysql_connect failed"
		exit 1
	fi
	echo -en '\E[25;44m' "\033[2m\t Restarted Main DB  OK \033[0m"; echo
	echo "$myname:mysql_start:success:MOK:"
	maxCOUNT=0
	MYSQL_PWD=$DBPASSWD -u$DBUSER   --socket=/DSS_FILES/mysql.sock --port=3308 dss_db -e  "SHOW tables" > /dev/null 2>&1 ;
	while [ $? -ne 0 -a $maxCOUNT -lt 10 ]
	do
		sleep 15;
		echo "$myname:DSS_mysql_start:waiting:MWAIT:"
		maxCOUNT=$(($maxCOUNT+1))
		MYSQL_PWD=$DBPASSWD mysql -u$DBUSER    --socket=/DSS_FILES/mysql.sock --port=3308 dss_db -e  "SHOW tables" > /dev/null 2>&1 ;
	done
	if [ $maxCOUNT -eq 10 ]
	then 
		echo "$myname:DSS_mysql_connect:FATAL:MERR"
		php "$SENDMAIL" "DEPLOYMENT ALERTS FROM $myname"   " DSS mysql_connect failed"
		exit 1
	fi 

	echo -en '\E[25;44m' "\033[2m\t Restarted DSS DB  OK \033[0m"; echo
	echo "$myname:DSS_mysql_start:success:MOK:"
}

    # ----------  end of function restart_mysqls  ----------

function copy_binary () {
	su -c " \cp -f $path/server/* $ADSERVER_PATH " http
	while [ $? -ne 0 ]
	do 
			echo " could not copy , trying once more ";
			sleep 1;
			su -c "  \cp -f $path/server/* $ADSERVER_PATH" http
	done
	echo -en '\E[25;44m' "\033[2m\t Copied AdServer Binaried   OK \033[0m"; echo
	echo "$myname:Binary_Copied:success:MOK:"

 \cp -f $path/CACHE_PUSHBACK/ADSERVER_CONFIG_RELOAD/bin/adserver_config_reload /CACHE_PUSHBACK/ADSERVER_RELOAD_FLAG/adserver_config_reload 

	if [ $? -ne 0 ]
	then
	        echo " could not copy adserver config reload:MERR "
		        exit
		fi



 \cp -f $path/CACHE_PUSHBACK/bin/cachpushback /CACHE_PUSHBACK/bin/cachpushback

	if [ $? -ne 0 ] 
	then
		echo " could not copy cachepushback:MERR "
		exit  
	fi

/CACHE_PUSHBACK/ADSERVER_RELOAD_FLAG/adserver_config_reload -l
}

    # ----------  end of function copy_binary  ----------
function iptable_stop () {
	cp /etc/sysconfig/iptables.enable /etc/sysconfig/iptables;
	/etc/init.d/iptables restart
	echo -en '\E[25;44m' "\033[2m\t TRAFFIC STARTED     OK  \033[0m"; echo
	echo "$myname:traffic_start:success:MOK:"

}    # ----------  end of function iptable_stop  ----------

function mysql_kill_connections () {
	VAR=$(mysql -u$DBUSER -p$DBPASSWD  --disable-column-names  -e "select concat('KILL ',id,';') from information_schema.processlist where ( user='kdbuser'  or user='ADSVR_USER' ) and (DB='KomliAdServer' or DB='AdFlex') ;" )
	mysql -u$DBUSER -p$DBPASSWD   --disable-column-names  -e "$VAR"
	DSS_VAR=$(mysql -u$DBUSER -p$DBPASSWD  --disable-column-names --socket=/DSS_FILES/mysql.sock   -e "select concat('kill ', id, ';') from information_schema.processlist where ( user='kdbuser'  or user='ADSVR_USER' )  and DB='dss_db' ;")
	mysql -u$DBUSER -p$DBPASSWD   --disable-column-names  -e "$DSS_VAR"

	echo "$myname:MYSQL_CONNECTIONS:KILLED:MOK:" 
}    # ----------  end of function mysql_kill_connections  ----------



function cksumIT () {
	SOURCE="$path/server/AdServerServlet"

	if [ $is_nginx == "true" ]
	then
		DESTINATION="/home/http/FCGI_ADSERVER/Install/nginx/htdocs/AdServer/AdServerServlet"
	else
		DESTINATION="/home/http/FCGI_ADSERVER/Install/Apache2/htdocs/AdServer/AdServerServlet"
	fi

	ansS=$(cksum $SOURCE | awk '{print $1}' );
	ansD=$(cksum $DESTINATION | awk '{print $1}' );
	if [ "$ansS" -eq "$ansD" ]
	then
		echo -e "$myname:cksum_check:\e[1;32m:MOK:\e[0m "
		return 0
	else
		echo  -e "$myname:cksum_check:\e[1;31m:MERR:\e[0m "
		exit 1
	fi
}


function checkSelectedCaimpaign () {
	echo "selected campaign check plz wait "
	SIZE=0
	maxCOUNT=0
	while [ "$SIZE" -lt $LOG_SIZE -a $maxCOUNT -lt 10 ]
	do
		if [ $is_nginx == "true" ]
		then
			cd /home/http/FCGI_ADSERVER/Install/nginx/logs/ ;
		else
			cd /home/http/FCGI_ADSERVER/Install/Apache2/logs/ ;
		fi
		ls -lrt | tail -n1 | awk '{print $9}' | xargs   tail --pid=$$ -f  | grep "Camp_Selected" > /tmp/dump1 2>/dev/null  &
		PID=$!
		sleep 9 ;
		pkill -TERM -P $PID > /dev/null 2>&1
		maxCOUNT=$(($maxCOUNT+1))
		echo "$myname:selected_campaign_check:9 sec running:MWAIT:";
		SIZE=$(stat -c%s "/tmp/dump1")
	done

	if [ $maxCOUNT -eq 10 ]
	then 
		echo "$myname:selected_campaign_check:Failed:MERR"
		exit 20
	fi


	if [ "$SIZE" -gt $LOG_SIZE ]
	then
		echo -e "$myname:selected_campaign_check:\e[1;32m:MOK:\e[0m"
	else
		echo -e "$myname:seleted_campaign_check:\e[1;31m:MERR:\e[0m"
		php "$SENDMAIL" "DEPLOYMENT ALERTS FROM $myname"   "selected CAMP chk failed"
		 
		return 20
	fi
	return 0
}


function checkfailedlogs () {
	echo "failed logs check plz wait "
	SIZE=0
	if [ $is_nginx == "true" ]
	then
		cd /home/http/FCGI_ADSERVER/Install/nginx/logs/ ;
	else
		cd /home/http/FCGI_ADSERVER/Install/Apache2/logs/ ;
	fi
	ls -lrt | tail -n1 | awk '{print $9}' | xargs   tail --pid=$$ -f  | grep "Fail to add" > /tmp/dump2 2>/dev/null  &
	PID=$!
	sleep 10 ;
	pkill -TERM -P $PID > /dev/null 2>&1
	echo "$myname:failed logs running:MWAIT:";
	SIZE=$(stat -c%s "/tmp/dump2")
	if [ $SIZE -ne 0 ]
	then 
		echo "$myname:cache failed to add:Failed:MERR"
		exit 1
	else
		echo "$myname:cache failed to add:success:MOK"
	fi
	return 0
}



function checkerrorlogs () {
	echo "error logs check plz wait "
	SIZE=0
	if [ $is_nginx == "true" ]
	then
		cd /home/http/FCGI_ADSERVER/Install/nginx/logs/ ;
	else
		cd /home/http/FCGI_ADSERVER/Install/Apache2/logs/ ;
	fi
	ls -lrt | tail -n1 | awk '{print $9}' | xargs   tail --pid=$$ -f  | egrep -i 'Error: machine count' > /tmp/dump3 2>/dev/null  &
	PID=$!
	sleep 10 ;
	pkill -TERM -P $PID > /dev/null 2>&1
	echo "$myname:error logs running:MWAIT:";
	SIZE=$(stat -c%s "/tmp/dump3")
	if [ $SIZE -ne 0 ]
	then 
		echo "$myname:error logs found:Failed:MERR"
		exit 1
	else
		echo "$myname:error log check:success:MOK"
	fi
	return 0
}


function checkPermissionMemCache ()  {
	expected="srwxrwxrwx"
	actual=$(ls -l /home/http/memcached.socket |  awk '{ print $1 } ')
	if [ "$expected" == "$actual" ]
	then
		echo -e " memcache permisions check                            \e[1;32mOK\e[0m "
		return 0
	else
		echo " memcache permission check  value : $actual              \e[1;31mFAIL\e[0m "
		exit 1
	fi
}



function checkThread () {
	echo "$myname:httpd_thread_count:waiting:MWAIT:"
	STABLE=0
	ACT=$( ps -ef|grep httpd |awk '{print $2}' |xargs ps uHp |wc -l)
	AFT=0
	while [ $STABLE -lt 5  ]
	do
		sleep 5
		AFT=$( ps -ef|grep httpd |awk '{print $2}' |xargs ps uHp |wc -l)
		if [ $AFT -lt $ACT ]
		then
				echo -e "$myname:thread_count:\e[1;32m reducing $AFT:MWAIT:\e[0m" 
				if [ $AFT -lt $STBLE_THREAD ] 
				then
						STABLE=$(($STABLE+1)) 
				fi
				elif [ $AFT -eq $ACT ]
				then
						echo -e "$myname:thread_count:\e[5;33m stable   $AFT:MWAIT:\e[0m"
				if [ $AFT -lt $STBLE_THREAD ]
				then
						STABLE=$(($STABLE+1))
				fi
		else
				echo -e "$myname:thread_count:\e[5;31m  increasing  $AFT:MWAIT:\e[0m"
				STABLE=0
		fi
				ACT=$AFT
	done
	echo -e "$myname:thread_count:\e[1;32mstable:MOK:\e[0m "
}
function CheckMysqlConnection () {
	KomliConnections=$(MYSQL_PWD=$DBPASSWD mysqladmin -u$DBUSER   processlist |  grep KomliAdServer | wc -l)
	ADflexConnection=$(MYSQL_PWD=$DBPASSWD mysqladmin -u$DBUSER   processlist | grep AdFlex | wc -l)
	EXPECTED=$(cat /etc/adserver.properties  |  grep "adserver.thread.count" | cut -d= -f2)
	if [ -z "$KomliConnections" ]
	then
		echo "$myname:unable to get komliconnection details:MERR "
		exit 1
	fi
	while [ "$KomliConnections" -lt "$EXPECTED" ]
	do
			echo "$myname:KomliAdSErver_connections_Count:$KomliConnections expected$EXPECTED:MWAIT:"
			sleep 3
			KomliConnections=$(MYSQL_PWD=$DBPASSWD mysqladmin -u$DBUSER  processlist |  grep KomliAdServer | wc -l)
	done
	echo -e "$myname:KomliAdserver_connection_Count:$KomliConnections\e[1;32m:MOK:\e[0m " 
	
	while [ "$ADflexConnection" -lt "$EXPECTED" ]
	do
			echo "$myname:ADflexConnection_connections_Count:$ADflexConnection expected:$EXPECTED:MWAIT"
			sleep 3
			ADflexConnection=$(MYSQL_PWD=$DBPASSWD mysqladmin -u$DBUSER  processlist |  grep AdFlex | wc -l)
	done
	echo -e "$myname:ADflexConnection_connection_Count:$ADflexConnection\e[1;32m:MOK:\e[0m "
	
	return 0
}



function CheckCores () {
	coreCount=$(ls -ltrh /home/http/FCGI_ADSERVER/Install/Apache2/htdocs/AdServer/ | grep -v "filecount" | grep -c "core"  )
	if [ "$coreCount" -ne 0 ]
	then
				CoreFile=$(ls -ltrh /home/http/FCGI_ADSERVER/Install/Apache2/htdocs/AdServer/ | grep -v "filecount" |  grep "core" | tail -n1 | awk ' { print $9 } '  )

       stamp=$( stat -c "%Y" /home/http/FCGI_ADSERVER/Install/Apache2/htdocs/AdServer/$CoreFile )
       Binstamp=$( stat -c "%Y" /home/http/FCGI_ADSERVER/Install/Apache2/htdocs/AdServer/AdServerServlet )

				if [ "$stamp" -gt "$Binstamp" ]
				then
						echo "$myname:if_cores_present_check:\e[1;31m:MERR:\e[0m        "
						exit 1
				else
						echo -e "$myname:if_cores_present_check:\e[1;32m:MOK:\e[0m  "
				fi
	else
				echo -e "$myname:if_cores_present_check:\e[1;32m:MOK:\e[0m  "
				return 0
	fi
}





function nginx_CheckCores () {
        coreCount=$(ls -ltrh /home/http/FCGI_ADSERVER/Install/nginx/htdocs/AdServer/ | grep -v "filecount" | grep -c "core"  )
	if [ "$coreCount" -ne 0 ]
	then
		CoreFile=$(ls -ltrh /home/http/FCGI_ADSERVER/Install/nginx/htdocs/AdServer/ | grep -v "filecount" |  grep "core" | tail -n1 | awk ' { print $9 } '  )

		stamp=$( stat -c "%Y" /home/http/FCGI_ADSERVER/Install/nginx/htdocs/AdServer/$CoreFile )
		Binstamp=$( stat -c "%Y" /home/http/FCGI_ADSERVER/Install/nginx/htdocs/AdServer/AdServerServlet )

		if [ "$stamp" -gt "$Binstamp" ]
		then
			echo "$myname:if_cores_present_check:\e[1;31m:MERR:\e[0m        "
			exit 1
		else
			echo -e "$myname:if_cores_present_check:\e[1;32m:MOK:\e[0m  "
		fi
        else
		echo -e "$myname:if_cores_present_check:\e[1;32m:MOK:\e[0m  "
		return 0
        fi
}






function CheckDSSConnectionCount () {
	EXPECTED=$(cat /etc/adserver.properties  |  grep "adserver.thread.count" | awk ' { print $3 } ')
	count=$(MYSQL_PWD=$DBPASSWD mysqladmin -u$DBUSER  --socket=/DSS_FILES/mysql.sock  processlist | grep -c dss_db )

	#increasing one for expected for the current command 
	#EXPECTED=$(($EXPECTED+1))

	while [ "$count" -lt "$EXPECTED" ]
	do
		echo "$myname:DSS_connection_count_check:$count:MWAIT:"
		sleep 10 
		count=$(MYSQL_PWD=$DBPASSWD mysqladmin -u$DBUSER  --socket=/DSS_FILES/mysql.sock  processlist | grep -c dss_db )

	done
		echo -e "$myname:DSS_connection_count_check:\e[1;32m:MOK:\e[0m "
		return 0
	
}


function checkreplication () {


REPLY=$(MYSQL_PWD=$DBPASSWD mysql -u$DBUSER  --socket=/DSS_FILES/mysql.sock -e 'SHOW SLAVE STATUS \G ' | egrep 'Slave_IO_Running|Slave_SQL_Running|Seconds_Behind_Master')
IO=$(echo $REPLY |  cut -d: -f2 | cut -d' '  -f2 )
SSQL=$(echo $REPLY |  cut -d: -f3 | cut -d' '  -f2)
SSEC=$(echo $REPLY |  cut -d: -f4)

	 if [ "$IO" == "Yes" -a "$SSQL" == "Yes" -a "$SSEC" -lt "1000" ]
	 then
		     echo "$myname:Replication_check:ok DSS:MOK" 
	 else
		     echo "$myname:Replication_check:FATAL DSS:MERR"
				 exit 2
	 fi

REPLY2=$(MYSQL_PWD=$DBPASSWD mysql -u$DBUSER  -e  'SHOW SLAVE STATUS \G ' | egrep 'Slave_IO_Running|Slave_SQL_Running|Seconds_Behind_Master')
IO2=$(echo $REPLY2 |  cut -d: -f2 | cut -d' '  -f2 )
SSQL2=$(echo $REPLY2 |  cut -d: -f3 | cut -d' '  -f2)
SSEC2=$(echo $REPLY2 |  cut -d: -f4)

   if [ "$IO2" == "Yes" -a "$SSQL2" == "Yes" -a "$SSEC2" -lt  "1000" ]
   then
         echo "$myname:Replication_check:ok :MOK" 
   else
         echo "$myname:Replication_check:FATAL :MERR"
         exit 2
   fi

	 
}

for last; do true; done
echo $last
STBLE_THREAD=$last

GOT_OPTION=0

for i in $*
do
	GOT_OPTION=1

	case $i in
    	--restartiptables)
		restartiptables=true
		;;
	--restart_main_memcache_USOCK)
		restart_main_memcache_USOCK=true;
		;;

	--deploy_bin)
		deploy_bin=true
		;;
	--mysql_kill_connection)
		mysql_kill_connection=true
                ;;

	--restart_mysql)
		restart_mysql=true
		;;

	--doall)
		restartiptables=true;
		restartdb_dss=true;
		deploy_bin=true;
		mysql_kill_connection=true;
		;;
	--nginx)
		is_nginx="true"
		echo "WE WILL DEPLOY FOR NGINX"
		APACHE_CTRL="/home/http/FCGI_ADSERVER/Install/nginx/bin/nginxctl.sh";
		ADSERVER_PATH="/home/http/FCGI_ADSERVER/Install/nginx/htdocs/AdServer/";
		chown http:http /home/http/FCGI_ADSERVER/Install/nginx/htdocs -R
		;;


	--help)
		echo "usage: "
		echo "#deploy.sh [--doall] "
		echo "#deploy.sh [--restartiptables] [--restart_main_memcache_USOCK] [ --mysql_kill_connection] [ --restart_mysql ]    [--deploy_bin]  "
		echo "#deploy.sh [--help]"
		exit;	
		;;
		*)
		echo " parsed " 
                # unknown option
		;;
  	esac
done



echo " STABLE thread Count will be $STBLE_THREAD" 
sleep 3


if [ $GOT_OPTION -eq 0 ] ; then
	echo
	echo -e "\tusage:\n"
	echo -e "\t#deploy.sh [--doall] "
	echo -e "\t#deploy.sh  [--restartiptables]    [--restart_main_memcache_USOCK] [--mysql_kill_connection] [--restart_mysql ]  [--deploy_bin]  "
	exit;

fi


main() {
	if [ $restartiptables == "true" ]; then
		iptable_start
	fi
	
	apache_stop
	su -c "ulimit -a" http
	ulimit -c unlimited;
        
	if [ $mysql_kill_connection == "true" ]; then
		mysql_kill_connections
        fi
		 
	if [ $restart_mysql == "true" ]; then
		restart_mysqls
	fi
	if [ $deploy_bin == "true" ]; then
                copy_binary
	fi
	if [ $restart_main_memcache_USOCK == "true" ]; then
		restart_memcache;
	fi

	cksumIT      #nginx handled internally
	if [ $is_nginx == "true" ]
        then
		nginx_start
	else	
		apache_start
	fi
	sleep 5
	CheckDSSConnectionCount
	CheckMysqlConnection
	if [ $is_nginx == "true" ]
        then
		nginx_CheckCores
	else
		CheckCores   
	fi
	if [ $restartiptables == "true" ]; then
		iptable_stop
	fi
	
}

main
