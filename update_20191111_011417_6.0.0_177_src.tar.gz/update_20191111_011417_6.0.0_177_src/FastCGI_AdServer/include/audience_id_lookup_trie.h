#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "trie.h"
#include "error.h"
#include "slist.h"

#ifdef __cplusplus
extern "C" {
#endif

void* generate_dpid_to_audid_trie();
long search_aid_for_paid(const char *prov_aud_data);
int generate_dpid_to_audid_trie_first_call();
int slist_to_int_array( SLIST * audience_data_list, char* audience_int_list_str);

#ifdef __cplusplus
}
#endif

