/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#ifndef GEO_BLOCKLIST_UTIL_H_ 
#define GEO_BLOCKLIST_UTIL_H_

#include <stdio.h>
#include <error.h>
#include "ad_server_types.h"
#include "common_constants.h"
#include "rt_types.h"
#include "bloom_filter.h"
#include "bkt_bloom_filter.h"
#include "generic_thread.h"

#define MAX_DOMAINS_USED_FOR_GEO_BLOCK 2

int apply_pub_geo_domain_blocklist_filter(
		cache_handle_t *cache_handle,
		db_connection_t *dbconn,
		const ad_server_req_param_t *params,
		const geo_data_t *geo_data);

int apply_pub_level_geo_blocklist(int pub_id,
		const geo_data_t *geo_data,
		cache_handle_t *cache,
		db_connection_t *dbconn);

void apply_pub_geo_blocklist_and_passback(
		cache_handle_t *cache_handle,
		db_connection_t *dbconn,
		const ad_server_req_param_t *params,
		const geo_data_t *geo_data,
		impression_passback_reason_t *passback_flag);

#endif // GEO_BLOCKLIST_UTIL_H_
