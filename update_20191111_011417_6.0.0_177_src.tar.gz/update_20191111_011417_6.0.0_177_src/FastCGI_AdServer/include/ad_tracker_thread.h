/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef AD_TRACKER_THREAD_H
#define AD_TRACKER_THREAD_H   

/* Include required files */
#include <sys/types.h>
#include "locking.h"
#include "ftrack_util.h"

/* Ad Server lock parameters */
typedef struct ad_track_thread_ft_context {
	ftrack_context_t impr_track_context;	/* Impression tracking file context */
	lock_var_t impr_track_lock;				/* Impression tracking lock */
	ftrack_context_t click_track_context;	/* Click tracking file context */
	lock_var_t click_track_lock;			/* Click tracking lock */
	ftrack_context_t activity_track_context;	/* Activity tracking file context */
	lock_var_t activity_track_lock;			/* Activity tracking lock */
	ftrack_context_t contextual_track_context; /*contextual data tracking context*/ 
	lock_var_t contextual_track_lock;			/* Contextual tracking lock */
	ftrack_context_t zone_track_context;
	lock_var_t zone_track_lock;
	ftrack_context_t pixel_blocked_track_context; 	/* Pixel Blocked data tracking context */
	lock_var_t pixel_blocked_track_lock;		/* Pixel blocked tracking lock */

	/* For tsv files */
        ftrack_context_t impr_track_context_tsv;
        lock_var_t impr_track_lock_tsv;
        ftrack_context_t click_track_context_tsv;
        lock_var_t click_track_lock_tsv;
        ftrack_context_t activity_track_context_tsv;
        lock_var_t activity_track_lock_tsv;
        ftrack_context_t contextual_track_context_tsv;
        lock_var_t contextual_track_lock_tsv;
        ftrack_context_t zone_track_context_tsv;
        lock_var_t zone_track_lock_tsv;
        ftrack_context_t pixel_blocked_track_context_tsv;
        lock_var_t pixel_blocked_track_lock_tsv;
} ad_track_thread_ft_context_t;

/* Ad Server thread parameter */
typedef struct ad_track_thread_param {
	ad_track_thread_ft_context_t ftcontext;	/* tracking file context */
	unsigned long thread_id;	/* lock */
} ad_track_thread_param_t;

#endif /* AD_TRACKER_THREAD_H */
