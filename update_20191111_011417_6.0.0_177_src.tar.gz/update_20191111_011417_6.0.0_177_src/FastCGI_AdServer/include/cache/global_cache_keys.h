/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef GLOBAL_CACHE_KEYS_H
#define GLOBAL_CACHE_KEYS_H
#include "local_cache_keys.h"

/* 
 * make - updates the value of this macro to checksum of FastCGI_AdServer code base 
 * make clean/clobber - reset the value to ""
 */

#define CODE_CKSUM "" 

//./cache/ad_context_cache.c
#define AD_CONTEXT_KEY "thread%ldadid%ld" CODE_CKSUM

//./cache/adserver_control_parameter_cache.c
#define OPTIMIZED_COLOR_MAX_RANGE_KEY "OPTIMIZED_COLOR_MAX_RANGE_KEY" CODE_CKSUM
#define OPTIMIZED_COLOR_RANDOM_RANGE_KEY "OPTIMIZED_COLOR_RANDOM_RANGE_KEY" CODE_CKSUM
#define MAX_RANGE_FOR_ECPM_KEY "MAX_RANGE_FOR_ECPM_KEY_%d" CODE_CKSUM
#define MIN_ECPM_WATERMARK_KEY "minRangeSite%ld" CODE_CKSUM
#define TOTAL_ACTIVE_ADSERVERS "TOTAL_ACTIVE_ADSERVERS" CODE_CKSUM
#define TOTAL_DC_ACTIVE_ADSERVERS_KEY "TOTAL_DC_ACTIVE_ADSERVERS" CODE_CKSUM
#define DEFAULT_SECOND_PRICE_MARGIN "DEFAULT_SECOND_PRICE_MARGIN" CODE_CKSUM
#define DEFAULT_ADFLEX_MARGIN "DEFAULT_ADFLEX_MARGIN" CODE_CKSUM
#define USE_LP_CAMP_SP_CALC "USE_LP_CAMP_SP_CALC" CODE_CKSUM
#define SHP_CONTROL_PARAMS_KEY "SHP_CONTROL_PARAMS_KEY" CODE_CKSUM
#define PRICING_2_0_PARAMS_KEY "PRICING_2_0_PARAMS_KEY" CODE_CKSUM
#define ENABLE_KRTBCOOKIE_NEW_NAME_KEY "ENABLE_KRTBCOOKIE_NEW_NAME" CODE_CKSUM
#define PREBID_FRAUD_CHECK_ENABLED_KEY "PREBID_FRAUD_CHECK_ENABLED" CODE_CKSUM
#define CROSS_DEVICE_VENDOR_LIST_KEY "CROSS_DEVICE_VENDOR_LIST_%d" CODE_CKSUM
#define FRA_CP_REDUCE_CONFIG_KEY "FRA_CP_REDUCE_CONFIG_KEY" CODE_CKSUM
#define PUBMATIC_PAYMENT_TAGID_KEY "PUBMATIC_PAYMENT_TAGID" CODE_CKSUM
#define LOG_CONSUMER_ID_KEY "LOG_CONSUMER_ID_KEY" CODE_CKSUM
#define STATS_SEND_TIMER_DIFF_KEY "STATS_SEND_TIMER_DIFF" CODE_CKSUM
#define GDPR_COUNTRY_GEO_LIST "GDPR_COUNTRY_GEO_LIST" CODE_CKSUM
#define ENABLE_APP_GEO_MSTATS_FLAG_KEY "ENABLE_APP_GEO_MSTATS_FLAG" CODE_CKSUM
//./cache/cache_ad_width_height.c
#define AD_SIZE_ID_KEY "AdSzId%ld" CODE_CKSUM
#define LOG_PMP_DEALS_KEY "LOG_PMP_DEALS%ld" CODE_CKSUM

//./cache/cache_ad_tracker_ecpm_encrption_algo_details.c
#define TRACKER_ECPM_ENCRYPTION_ALGO_DETAILS "TRCKR_ECPM_ENCRYPT_%d" CODE_CKSUM
#define OPENBID_INTEGRATION_LEVEL_SETTINGS_KEY  "OPENBID_INTEGRATION_LEVEL_SETTINGS_%ld" CODE_CKSUM

//./cache/cache_bot_trie_operations.c
#define BROWSER_LIST_TRIE_ARRAY "BROWSER_LIST_TRIE_ARRAY" CODE_CKSUM
#define BOT_LIST_TRIE_ARRAY "BOT_LIST_TRIE_ARRAY" CODE_CKSUM

//./cache/cache_contextual_data.c
#define URL_CONTEXTUAL_KEY_FMT   "site_id%luurl_crc%lu" CODE_CKSUM

//./cache/cache_default_timeout_mapping.c
#define DEFAULT_TIMEOUT_KEY_FMT "DEFTIMEOUTsiteid%ld_adnetwork%ld" CODE_CKSUM

//./cache/cache_dss_type_id_map.c
#define DSS_TYPE_ID_MAP_KEY_FMT   "dss_type_id_map_ad_id%d" CODE_CKSUM

//./cache/cache_get_app_info.c
#define SITE_APP_ID_KEY "siteappinfo2_%ld_%ld" CODE_CKSUM

//./cache/cache_get_app_info.c
#define PUB_SITE_SOFT_FLOOR_KEY "pubsitesoftfloor_%d_%d" CODE_CKSUM

//./cache/cache_hardfloor.c
#define PUB_SITE_HARD_FLOOR_KEY "pubsitehardfloor_%d_%d" CODE_CKSUM

//./cache/cache_get_iab_category_info.c
#define SITE_IAB_CAT_KEY "iabcatinfo2_%d_%s" CODE_CKSUM

//./cache/cache_get_defaulted_indirect_ad_tag_id.c
#define INDIRECTNETWORK_ADID_KEY "I_AdNIdad%ldadsrv%ldpub%ld" CODE_CKSUM

//./cache/cache_get_net_device_type_mapping.c
#define NET_DEVICE_TYPE_KEY_FMT   "networkdevicetypeadid%d" CODE_CKSUM

//./cache/cache_get_site_url_mapping.c
#define SITE_URL_ID_KEY "siteurlidappinfo2_%d" CODE_CKSUM
#define SITECODE_SITEURL_MAP_KEY "sc2su_pub%ld" CODE_CKSUM

//./cache/cache_intf.c
#define PUBLISHER_SITE_AD_KEY_FMT   "ad%dsite%dpub%d" CODE_CKSUM
#define PUBLISHER_SITE_KEY_FMT   "site%d_2" CODE_CKSUM
#define AD_ACTIVE_ACC_KEY_FMT   "pub%dad%dactiveacc" CODE_CKSUM
#define SITE_NETWORK_FREQ_KEY_FMT   "site%dqref" CODE_CKSUM
#define SITE_TO_ADSERVER_SITE_MAP_FMT "site%ldadserverid%ld" CODE_CKSUM
#define PUBLISHER_ADSERVER_SETTINGS_KEY_FMT "pubid%ldadserverid%ld" CODE_CKSUM
#define PUBLISHER_SETTINGS_KEY_FMT "pubglobalpubid%ld" CODE_CKSUM
#define AD_GEO_ACTIVE_ACC_KEY_FMT   "ad%dgeo%d_%d_%d_%dactiveacc" CODE_CKSUM
#define SITE_NETWORK_PIXEL_KEY_FMT   "networkretpixelad%d" CODE_CKSUM
#define SITE_CATEGORY_KEY_FMT "site%dcatelist" CODE_CKSUM
#define PUBLISHER_SITE_ADFLEX_SETTINGS_KEY_FMT "pubid%ldsiteid%ldadfxsettings_2" CODE_CKSUM
#define PUBLISHER_LEVEL_SETTINGS_KEY_FMT "2_pubid%ldpublevelsettings" CODE_CKSUM
#define DC_PUBLISHER_LEVEL_SETTINGS_KEY_FMT "dc%d_pubid%ldpublevelsettings" CODE_CKSUM
#define PUBLISHER_PASSBACK_KEY "pubid%ldpassback_network" CODE_CKSUM
#define CAMPAIGN_COUNTRY_MASKING_LIST_KEY "campiagnid%dcountry_masking_list%d" CODE_CKSUM
#define IS_PUBLISHER_AGGREGATOR_KEY "publisher%ld_aggregator_status" CODE_CKSUM
/*
 * Publisher level ACL setting Key
 */
#define PUBLISHER_ACL_SETTINGS_KEY_FMT "pubglbaclpubid%ld" CODE_CKSUM
/*#define SITE_TO_ADSERVER_SITE_MAP_FMT "sitetoadserversitemappk%ld" */ /*depending on what caller haves,
we can use this Primary-Key as a part of hash key*/

//./cache/cache_publisher_billing_details.c
#define PUBLISHER_BILLING_DETAILS_KEY "billing_pub%ld_site%ld" CODE_CKSUM

//./cache/cache_native_attributes_config.c
#define NATIVE_ATTR_CONF_KEY_FMT   "ad%dnativeattr" CODE_CKSUM

//./cache/cache_lucid_contextual_category.c
#define LUCID_CATEGORY_KEY_FMT "lucid_cat_id_%d" CODE_CKSUM

//./cache/cache_publisher_adservedtracking_component.c
#define SITE_SCRIPT_COMPONENT_KEY "sitescriptcompo%ld" CODE_CKSUM
#define PUBLISHER_EXCLUDED_NETWORK_KEY "excldntwkPubid%ldAdsrvid%ld" CODE_CKSUM

//./cache/cache_publisher_audience_target_site.c
#define PUB_AUDIENCE_TARGET_SITE_KEY_FMT "pub%ldaudtargetsite" CODE_CKSUM

//./cache/cache_publisher_global_settings.c
#define SITEWISE_AVG_ECPM_DISABLED "SITEWIESE_AVG_ECPM_BIDING_DISABLED" CODE_CKSUM
#define VARIABLE_PASSING_DISABLED "VARIABLE_PASSING_DISABLED" CODE_CKSUM

//./cache/cache_publisher_guaranteed_site_section_adscript.c
#define PUB_GA_SITE_SECTION_ADSCRIPT_KEY "gaAdscriptforad%ldid%dst%dsc%dgad%ldadsrver%ld" CODE_CKSUM

//./cache/cache_publisher_site_ad_geo_settings.c
#define AD_GEO_SETTINGS_KEY_FMT   "ad_id%dcountry_code%s" CODE_CKSUM
#define PUBLISHER_GEO_BLOCKLIST_KEY_FMT "PUB_GEO_BLK%d" CODE_CKSUM

//./cache/cache_publisher_site_ad_serving_rtb_status.c
#define PUBSITE_ADSERVING_RTB_STATUS_KEY_FMT    "adserving_rtb_status_pubid%ld_siteid%ld" CODE_CKSUM

//./cache/cache_publisher_site_default_params.c
#define PUBSITE_DEFAULT_PARAMS_KEY_FMT  "default_params_pubid%ld_siteid%ld" CODE_CKSUM

//./cache/cache_publisher_site_default_settings.c
#define PUBSITE_DEFAULT_SETTINGS_KEY_FMT        "0_DEFsTv1pubid%ld_site%ld" CODE_CKSUM

//./cache/cache_realtime_campaigns.c
#define RTB_CAMPAIGNS_KEY_FMT "DemandPartnerID_%ldpixel_ID_%ld" CODE_CKSUM

//./cache/cache_tracker_bypass.c ./CACHE_PUSHBACK/TRACKER_BYPASS/tracker_bypass_main.c
#define TRACKER_BYPASS_KEY "TRACKERBYPASS" CODE_CKSUM
#define TRACKER_SERVER_LIST_KEY "TRACKERLIST" CODE_CKSUM
#define TRACKERDNS_CONTEXT_KEY "trackdns%dcntxt" CODE_CKSUM

//./cache/cache_track_pub_site_ad.c
#define AD_ID_KEY "adid_%d" CODE_CKSUM

//./cache/cache_video_ad_tag_properties.c
#define VID_PROP_KEY "VAdProp%ld" CODE_CKSUM

//./cache/cache_audio_ad_tag_properties.c
#define AUD_PROP_KEY "AAdProp%ld" CODE_CKSUM

//./cache/color_cache.c
#define BK_COLOR_LIST_KEY   "global_bk_color_list" CODE_CKSUM
#define LIGHT_TEXT_COLOR_LIST_KEY "global_light_text_color_list" CODE_CKSUM
#define DARK_TEXT_COLOR_LIST_KEY "global_dark_text_color_list" CODE_CKSUM

//./cache/fixed_adscript_cache.c
#define FIXED_ADSCRIPT_KEY "fAdscriptforad%ldadsrver%ld" CODE_CKSUM

//./cache/fixed_color_cache.c
#define FIXED_COLOR_LIST_KEY   "fixed_color_ad%ld" CODE_CKSUM

//./cache/indirectnetwork_adscript_cache.c
#define INDIRECTNETWORK_ADSCRIPT_KEY "IAdNSad%ldadsrv%ldpub%ld" CODE_CKSUM

//./cache/media_script_cache.c
#define MEDIA_SCRIPT_KEY_FMT   "vertId%d" CODE_CKSUM

//./cache/piggyback_cookie_expiry.c
#define PIGGYBACK_COOKIE_EXPIRY  "piggyback_cookie_expiry_list" CODE_CKSUM

//./cache/pubmatic_one_adscript_cache.c
#define PM_ONE_FIXED_ADSCRIPT_KEY "pmOneads%ldsize%d" CODE_CKSUM
#define PM_ONE_DEFAULTFLAG_KEY "pmOneadsDefF%ldsize%d" CODE_CKSUM
#define PM_ONE_SIZE_FIXED_ADSCRIPT_KEY "pmOneSizeads%ldsize%d" CODE_CKSUM
#define PM_ONE_SIZE_DEFAULTFLAG_KEY "pmOneSizeadsDefF%ldsize%d" CODE_CKSUM
#define PM_ONE_VERTICAL_FIXED_ADSCRIPT_KEY "pmOneads%ldVert%dsize%d" CODE_CKSUM
#define PM_ONE_VERTICAL_DEFAULTFLAG_KEY "pmOneadsDefF%ldVert%dsize%d" CODE_CKSUM
#define PM_ONE_VERTICAL_SIZE_FIXED_ADSCRIPT_KEY "pmOneSizeads%ldVert%dsize%d" CODE_CKSUM
#define PM_ONE_VERTICAL_SIZE_DEFAULTFLAG_KEY "pmOneSizeadsDefF%ldVert%dsize%d" CODE_CKSUM
#define PM_ONE_SITE_SIZE_ADSCRIPT_KEY "pmOnepub%ldsite%ldad%ldads%ldsize%d" CODE_CKSUM
#define PM_ONE_SITE_SIZE_DEFAULTFLAG_KEY "pmOnepub%ldsite%ldad%ldadsDefF%ldsize%d" CODE_CKSUM

//./CACHE_PUSHBACK/cache/campaign_budget_total.c
#define CAMPAIGN_DAILY_AMOUNT_BUDGET_KEY_FMT "camImpBudget%ld" CODE_CKSUM

//./cache/retargeting_pixel.c
#define PIXEL_ACTIVE_KEY_FMT "pixel_%ld" CODE_CKSUM
#define PIXEL_ADVERTISER_KEY_FMT "pixel_advertiser_%ld" CODE_CKSUM

//./cache/test.c
#define DARK_TEXT_COLOR_LIST_KEY "global_dark_text_color_list" CODE_CKSUM

//./CookieStoreProtobuff/cookieless/cache/cache_get_max_pix_count.c
#define PIXEL_MAX_COUNT_KEY "pxmc%d" CODE_CKSUM

//./CookieStoreProtobuff/cookieless/cache/cache_get_pixel_block_list.c
#define PIXEL_BLCOK_PUB_SITE_LIST_KEY "pxb%d:%d" CODE_CKSUM

//./CookieStoreProtobuff/cookieless/cache/cache_get_syncup_meta.c
#define PIXEL_META_DATA_KEY "px%d" CODE_CKSUM

//./dss_lib/cache/cache_dss_site_network_frequency.c
#define DSS_SITE_NETWORK_FREQ_KEY_FMT   "dss_site%dnetfreq" CODE_CKSUM

//./dss_lib/cache/cache_frequency_ecpm_persite.c
#define FRQUENCY_ECPM_STRUCT_KEY_FMT1 "frequency%decpm1" CODE_CKSUM
#define FRQUENCY_ECPM_STRUCT_KEY_FMT2 "frequency%decpm2" CODE_CKSUM

//./dss_lib/cache/cache_geo_ecpm_persite.c
#define SITE_NETWORK_GEO_ECPM_KEY_FMT   "geo_ecpm:%d:%d" CODE_CKSUM

//./dss_lib/cache/cache_mapp_ecpm_persite.c
#define MAPP_ECPM_STRUCT_KEY_FMT "mapp_%d_ecpm" CODE_CKSUM

//./dss_lib/cache/dss_cache.c
#define DSS_AD_ACTIVE_ACC_KEY_FMT "dss%dadactiveacc" CODE_CKSUM

//./FTE/cache/ad_campaign.c
#define AD_CAMPAINS_KEY_FMT "ad%ldCam" CODE_CKSUM
#define ST_CAMPAING_KEY_FMT "st%ldCam" CODE_CKSUM

//./FTE/cache/ad_campaign_geo_settings.c
#define AD_CAMPAIGN_GEO_SETTINGS_KEY_FMT   "ad_id%ldcamgeo" CODE_CKSUM
#define GBL_CAMPAIGN_GEO_SETTINGS_KEY_FMT  "gbl_camgeo" CODE_CKSUM
#define AD_CAMPAIGN_ZIP_SETTINGS_KEY_FMT   "ad_id%ldCamZiP" CODE_CKSUM
#define AD_CAMPAIGN_ISP_KEY_FMT   "ad_id%ldcamisp" CODE_CKSUM
#define AD_CAMPAIGN_CONN_KEY_FMT   "ad_id%ldcamconn" CODE_CKSUM

//./FTE/cache/cache_campaign_ad_code_type.c
#define CAMPAIGN_AD_CODE_TYPE_KEY_FMT   "AdCodeType%d" CODE_CKSUM

//./FTE/cache/cache_campaign_browser_filter.c
#define AD_CAMPAIGN_BROWSER_KEY_FMT   "adId%ldBrowser" CODE_CKSUM

//./FTE/cache/cache_campaign_device_filter.c
#define AD_CAMPAIGN_MAKE_MODEL_KEY_FMT   "adId%ldmakeModel" CODE_CKSUM
#define AD_CAMPAIGN_DEVICE_CAPABILITY_KEY_FMT   "adId%lddev_ktk_map" CODE_CKSUM

//./FTE/cache/cache_campaign_os_filter.c
#define AD_CAMPAIGN_OS_KEY_FMT "adId%ldOs" CODE_CKSUM

//./FTE/cache/cache_campaign_platform_filter.c
#define AD_CAMPAIGN_PLATFORM_KEY_FMT "adId%ldplatform" CODE_CKSUM

//./FTE/cache/cache_campaign_privacy_compliance.c
#define AD_CAMPAIGN_PRIVACY_COMPLIANCE_KEY_FMT "campprivacycompliance" CODE_CKSUM
#define AD_DEFAULT_PRIVACY_COMPLIANCE_KEY_FMT "privacyscript%d_platform_%d_adtype" CODE_CKSUM
#define VIDEO_PRIVACY_ICON_CNTX_KEY_FMT       "VideoPrivacyIconScript_%d_platform" CODE_CKSUM

//./FTE/cache/cache_campaign_protocol.c
#define CAMPAIGN_PROTOCOL_KEY_FMT "CamPrtcl%ld" CODE_CKSUM

//./FTE/cache/cache_audio_campaign_properties.c
#define AUDIO_CAMPAIGN_PROP_KEY_FMT "AudioCamProp" CODE_CKSUM

//./FTE/cache/cache_creative.c
#define PUB_SITE_CRTYPE_LIST_KEY_FMT "crtypelist_pub%ld_site%ld" CODE_CKSUM

//./FTE/cache/cache_creative.c
#define AD_CREATIVES_KEY_FMT "crtv%ld" CODE_CKSUM
#define AD_CREATIVE_INFO_KEY_FMT "creativeinfo%d" CODE_CKSUM
#define CAMPAIGNS_CREATIVES_KEY_FMT "campcrtv%ldsize%d" CODE_CKSUM
#define AD_CAMPAIGN_CREATIVES_KEY_FMT "camcreativeadid%ld" CODE_CKSUM


//./FTE/cache/cache_creative_clicks.c
#define CREATIVE_OVER_PREDICTED_KEY_FMT "overprdtd%ldcrtv%ld" CODE_CKSUM

//./FTE/cache/cache_dp_header_mapping_list.c
#define DP_HEADER_MAPPING_KEY_FMT   "header_mapping" CODE_CKSUM

//./FTE/cache/cache_himpa_ga_site_section_user_frequency_rule.c
#define GA_RULE_KEY_FMT "ga_rule_site_%d_stn_%d_pub_%d_" CODE_CKSUM

//./FTE/cache/cache_publisher_site_ecpm.c
#define CAMPAIGN_SITE_ECPM_LIFT_KEY_FMT "cam%ldsite%ldprcntlift" CODE_CKSUM
#define SITE_AVG_ECPM_KEY_FMT "siteavgecpm%ld" CODE_CKSUM
#define PUBLISHER_SITE_CAMPAIGN_SETTINGS_KEY_FMT "ktk57pub%d_site%d_ktk57" CODE_CKSUM
#define DC_PUB_SITE_CAMPAIGN_SETTINGS_KEY_FMT "DPSC_D%d_P%d_S%d" CODE_CKSUM
#define PUB_SITE_BUYER_SETTINGS_KEY "PSBS_pub%d_site%d_" CODE_CKSUM

//./FTE/cache/cache_publisher_site_rtb_floor.c
#define PUBLISHER_SITE_FLOOR_KEY "publisher%ldsite%ldfloor_v2" CODE_CKSUM

//./FTE/cache/cache_publisher_site_variable_floors.c
#define PUBSITE_FIX_VARIABLE_FLOOR  "fixvariablefloorsite%ld" CODE_CKSUM
#define PUBSITE_FACTORED_FLOOR  "factoredfloorsite%ld" CODE_CKSUM
#define PUBLISHER_IAB_FLAG_FMT "publisher%ld_iab_flag" CODE_CKSUM
#define PUBLISHER_COUNTRY_ID_LIST "publisher%ld_country_id_list" CODE_CKSUM
#define PUBLISHER_BCC_FLAG_FMT "publisher%ld_bcc_flag" CODE_CKSUM
#define PUBSITE_IAB_VERTICALS_FMT "pubsite%ld_iab_verticals" CODE_CKSUM
#define ADSIZE_KEY_FMT "adsizecachekey" CODE_CKSUM

//./FTE/cache/dsp_campaign_block_list.c
#define DSP_CAM_BLK_LST "DPCM_BLK_DP%ldC%ld_BLM" CODE_CKSUM

#define CREATV_BLOOM "CREATV_BLOOM_%d" CODE_CKSUM

//./FTE/cache/dsp_campaign_block_list.c
//./FTE/cache/dsp_campaign_white_list.c
#define DSP_CAM_BLOOM_LST_KEY "DPCM_TLD_D%ldC%ldT%dI%d_BLM" CODE_CKSUM
// DSP_PUB_CAM_BLOOM_LST_KEY will have 2 parts
#define DSP_PUB_CAM_BLOOM_LST_KEY_PART1 "P%ld%s" CODE_CKSUM
#define DSP_PUB_CAM_BLOOM_LST_KEY_PART2 "DPPUB_CM_TLD_D%ldC%ldT%dI%d_BLM" 
//./FTE/cache/dsp_campaign_appurl_blocklist.c
#define DSP_CAM_AURL_BLOOM_LST_KEY "DPCM_AURL_D%ldC%ldT%dI%d_BLM" CODE_CKSUM
// DSP_PUB_CAM_AURL_BLOOM_LST_KEY will have 2 parts 
#define DSP_PUB_CAM_AURL_BLOOM_LST_KEY_PART1 "P%ld%s" CODE_CKSUM
#define DSP_PUB_CAM_AURL_BLOOM_LST_KEY_PART2 "DPPUB_CM_AURL_D%ldC%ldT%dI%d_BLM"

//./FTE/cache/dsp_campaign_appurl_whitelist.c
#define DSP_CAM_AURL_WHT_LST "DPCM_AURL_WHT_DP%ldC%ld_BLM" CODE_CKSUM

//./mobile/cache/cache_get_carrier_mapping.c
#define CARRIER_MAP_KEY_FMT "mobCarrier%s" CODE_CKSUM

//./mobile/cache/cache_get_device_make_model.c
#define DEVICE_MAKE_MODEL_KEY_FMT "#$PM_DEV_ID%d$#" CODE_CKSUM

//./mobile/cache/cache_get_device_mapping.c
#define DEVICE_MAP_KEY_FMT "mobMake%sModel%s" CODE_CKSUM

//./mobile/cache/cache_get_os_details.c
#define DEVICE_OS_KEY_FMT "MOBOSDT%d" CODE_CKSUM

//./mobile/cache/cache_get_os_mapping.c
#define OS_MAP_KEY_FMT "osname%sT%sL%s" CODE_CKSUM

//./network_mobile/cache/cache_campaign_to_adserver_interface_mapping.c
#define AD_CAMPAIGN_INTERFACE_SETTING_KEY_FMT   "ad_id%ldcams2sint" CODE_CKSUM

//./RTB/cache/cache_campaign_level_data_provider_settings.c
#define CACHE_CAMPAIGN_DATA_PROVIDER_SETTINGS_KEY   "cmpgn_%ld_dp_%d_settings" CODE_CKSUM

//./RTB/cache/cache_dynamic_campaign_sp_margin.c
#define DYNAMIC_CAMP_SP_MARGIN "D_C_SP_M_%ld" CODE_CKSUM

#define INTEGRAL_SETTINGS_KEY "IAS_SETTING_%ld" CODE_CKSUM
#define BID_BOOST_SETTINGS_KEY "BID_BOOST_SETTING_%ld_%ld" CODE_CKSUM

//./RTB/cache/cache_dc_camp_settings.c
#define DC_CAMP_SETTINGS_KEY "DC_CAMP_%s" CODE_CKSUM

//./RTB/cache/cache_dynamic_campaign_sp_margin.c
#define CMPG_SP_INFO "cmpg_3sp1_info_%d" CODE_CKSUM

//./RTB/cache/cache_currency_coversion.c
#define CURRENCY_XRATE_MAP "currency_xrate_map_%d" CODE_CKSUM

//./RTB/cache/cache_publisher_site_advertiser_floor.c
#define PUBLISHER_SITE_ADVERTISER_FLOOR_KEY "publisher%ldsite%ldadvfloor" CODE_CKSUM

//./RTB/cache/cache_publisher_site_dsp_advertiser_floor.c
#define PUBLISHER_SITE_DSP_ADVERTISER_FLOOR_KEY "publisher%ldsite%lddspadvfloor" CODE_CKSUM

//./RTB/cache/cache_publisher_site_dsp_floor.c
#define PUBLISHER_SITE_DSP_FLOOR_KEY "publisher%ldsite%lddspfloor" CODE_CKSUM

//./RTB/cache/cache_publisher_site_iframe_buster_tech.c
/*
 * Key used to locate JSON list of iframe buster technologies that have been
 * installed on Publisher's site in the Memcache.
 */
#define MEMCACHED_IFRAME_BUSTER_TECH_LIST_KEY "JSON_IFRAME_BUSTER_TECH_LIST_%ld_%ld" CODE_CKSUM

//./RTB/cache/cache_pub_site_advertiser_domain_white_list.c
#define PUB_SITE_ADV_DOM_WHT_LST "PB_SITE_ADV_DOM_WHT_PID0SID0" CODE_CKSUM

//./RTB/cache/cache_rtb_campaign_encryption_algo_details.c
#define RTB_CAMPAIGN_ECRYPTION_ALGO_DETAILS "RTB_CAMPAIGN_ECRYPTION_ALGO_DETAILS_PURPOSE_%d_%d" CODE_CKSUM

//./RTB/cache/publisher_site_block_list.c
#define PUB_SITE_GLOBAL_BLK_LST_KEY "PB_ST_GLBBLK_BLM_P%ldS%ldT%dI%d" CODE_CKSUM
#define PUB_SITE_DOM_BLOCKLIST_KEY "PB_ST_BLK_BLM_P%ldS%ldT%dI%d" CODE_CKSUM

//./RTB/cache/publisher_site_block_list.c
#define PUBLISHER_SITE_URL_BLOOM "PB_ST_URL_BLM_PID%ldSID%ldT%dID%d" CODE_CKSUM

//./RTB/cache/publisher_site_floor_filter.c
#define PUB_SITE_FLOOR_RULE_BLM_KEY "PB_ST_FLR_P%ldS%ldAE%dI%d" CODE_CKSUM

//inventory_quality/cache/cache_publisher_site_whitelisting.c
#define PUBLISHER_SITE_TLD_WHITELIST_KEY "PB_SITE_WHITELIST_PID%ld_SID%ld_indx%d" CODE_CKSUM

//./RTB/cache/cache_pub_site_advertiser_domain_category_list.c
#define PUB_SITE_DOM_ADV_BLK_KEY "PUB_SITE_DOM_ADV_BLK_PID%ld_SID%ld" CODE_CKSUM
#define PUB_SITE_DOM_CAT_BLK_KEY "PUB_SITE_DOM_CAT_BLK_PID%ld_SID%ld" CODE_CKSUM

//./RTB/cache/cache_get_buyer_blocklist.c
#define PUB_BUYER_BOCKLIST_KEY "PUB_BUYER_BLOCKLIST_%ld" CODE_CKSUM

//inventory_quality/cache/cache_get_publisher_prebid_sampling.c
#define PUB_PREBID_SAMPLING_CACHE_KEY "PUB_PREBID_SAMPLING_%ld"

//./RTB/cache/publisher_site_white_list.c
#define PUBLISHER_SITE_WL_LST "PB_ST_WL_BLM_PID%ldSID%ld" CODE_CKSUM
#define PUB_SITE_DOM_WHITELIST_KEY "PB_ST_WHT_BLM_P%ldS%ldT%dI%d" CODE_CKSUM

//./RTB/cache/global_blocklist.c
#define GLOBAL_SUPPY_SIDE_BLOCKLIST_KEY "GBL_BLK_LST_P%ldS%ldT%dI%d" CODE_CKSUM

// DAA Optout
#define DAA_DEVICEID_OPTOUT_KEY "DAA_DEV_OPTOUT_HASH%ldDEVT%ldT%dI%d" CODE_CKSUM

// ADS.TXT publisher level bloom cache key
#define ADS_TXT_DOM_PUB_BLOOM_KEY "ADS_TXT_DOM_PUB%ldBLMTYPE%ld" CODE_CKSUM
// APP-ADS.TXT publisher level bloom cache key
#define APP_ADS_TXT_DOM_PUB_BLOOM_KEY "APP_ADS_TXT_DOM_PUB%ldBLMTYPE%ld" CODE_CKSUM

// Pub level GEO blocklist cache key
#define PUB_GEO_DOM_BLK_BLOOM_KEY "PUB_GEO_DOM_BLK_KEY_PB%ld" CODE_CKSUM

//./RTB/cache/url_blocklist.c
#define URL_BLOCKLIST_FORMAT "URLBLOCKLIST_%ld_%ld" CODE_CKSUM

//./RTB/creative_filter/cache/cache_publisher_site_creative_filter_list.c
#define PUBLISHER_SITE_CREATIVE_FILTER_WHT_LIST "PB_ST_CRTV_FLTR_WHT_LST_PID%ldSID%ld" CODE_CKSUM
#define PUBLISHER_SITE_CREATIVE_FILTER_BLK_LIST "PB_ST_CRTV_FLTR_BLK_LST_PID%ldSID%ld" CODE_CKSUM
#define PUB_SITE_CREATIVE_LIST_KEY "PB_ST_CRTV_BLM_P%ldS%ldT%dI%d" CODE_CKSUM

#define GLOB_CREATIVE_LIST_KEY "GLB_CRTV_BLM_P%ldS%ldT%dI%d" CODE_CKSUM

//./RTB/deal/cache/cache_get_deals_params.c
#define PUBLISHER_SITE_DEALS_PARAMS_MEMCACHE_KEY "pub_%ld_deals_params" CODE_CKSUM

//./RTB/deal/cache/cache_get_deal_url_overriding_params.c
#define DEALS_URL_PARAMS_MEMCACHE_KEY "dsp_id_%d_deals_url_overriding_params" CODE_CKSUM

//./RTB/deal/cache/cache_get_dsp_buyer_mapping.c
#define DSP_BUYER_MAP_KEY_FORMAT "DSP_BUYER_MAP_KEY_%d" CODE_CKSUM

//./RTB/floor_rules/cache/cache_advertiser_domain.c
#define ADVERTISER_DOMAIN_ID_FORMAT "RULE_AD_DOM_ID_%ld_%ld" CODE_CKSUM

//./RTB/floor_rules/cache/cache_advertiser_domain_category_mapping.c
#define ADVERTISER_DOM_CAT_FORMAT "RULE_AD_DOM_CAT_ID_%ld_%ld" CODE_CKSUM

//./RTB/floor_rules/cache/cache_dsp_buyer.c
#define DSP_BUYER_KEY_FORMAT "RULE_DSP_BUYER_KEY_%ld_%ld" CODE_CKSUM

// ./FTE/cache/cache_pm_dsp_buyer_map.c
#define PM_DSP_BUYER_KEY_FORMAT "PM_DSP_BUYER_KEY_%d" CODE_CKSUM

//./RTB/floor_rules/cache/cache_get_unique_segments.c
#define UNIQUE_SEGMENT_LIST_KEY "PUB%ldSITE%ldLIST" CODE_CKSUM

//./RTB/floor_rules/cache/cache_publisher_site_floor_rules.c
#define PUBLISHER_SITE_FLOOR_RULES_KEY "publisher%ldsite%ldfloorrules" CODE_CKSUM

//./RTB/pubconnect/cache/cache_pc_margin.c
#define PC_MARGIN_KEY_FORMAT "PC_MARGIN_KEY_%ld%d" CODE_CKSUM

//./UNIVERSAL_PIXEL/cache/upixel_cache.c
#define UNIVERSAL_PIXEL_KEY_FMT "UpixelSite_id%ld" CODE_CKSUM

//./wrappers/utils/bidder_request_parse_util.c
#define PMB_PSWH_KEY "PMB_P%ld_S%ld_W%d_H%d" CODE_CKSUM

//./FTE/cache/cache_pub_camp_geo_filter.c
#define PUB_CAMP_GEO_LIST "P_C_G_%ld_%ld_1" CODE_CKSUM

//./RTB/cache/cache_publisher_site_deal_domain_list.c
#define PUBLISHER_SITE_DL_BLM_LST "PB_ST_DL_BLM_PID%ldSID%ld" CODE_CKSUM
#define PUB_SITE_DEAL_WHITELIST_KEY "PB_ST_DL_BLM_P%ldS%ldT%dI%d" CODE_CKSUM

//./mobile/util/get_wurfl_data.c
/*
 * Need to change when number of parameter changes in php side
 * Currently 14 parameters are coming so V14
 */
#define WURFL_DATA_KEY "Wurfl_V14_%s"

//Creating new WURFL DATA key to write new parsed structure into memcache
#define WURFL_DATA_KEY_NEW "GEN_WURFL_V3_0_%s"

//./FTE/cache/cache_bid_request_control.c
#define CAMP_FILTER_SETTING_LIST "CAMP_FILTER_SETTING_1_%d" CODE_CKSUM

//./FTE/cache/cache_browser_os_list.c
#define BROWSER_LIST "BROWSER_LIST" CODE_CKSUM

//./FTE/cache/cache_browser_os_list.c
#define OS_LIST "OS_LIST" CODE_CKSUM

//third_party_component/cache/cache_third_prty_componenet.c
#define THIRD_PARTY_COMPONENT_KEY_FORMAT "thirdpartycmpkeyforsite%ldkey" CODE_CKSUM

//third_party_component/cache/cache_get_third_party_pixel_info.c
#define THIRD_PARTY_PIXEL_INFO_KEY_FORMAT "third_party_pixel_pub%ld_site%ldkey" CODE_CKSUM

#define CUSTOM_TARGETING_TRIE_KEY "ctr_trie%d_" CODE_CKSUM
#define CUSTOM_TARGETING_VALUE_TRIE_KEY "ctr_val_trie_%d_" CODE_CKSUM
#define CUSTOM_TARGETING_SET_LIST_KEY "ctr_set_list_%d_" CODE_CKSUM
#define CUSTOM_TARGETING_CRITERIA_LIST_KEY "ctr_crit_list_%d_" CODE_CKSUM
#define BADV_CACHE_KEY "badv_%d_%d_%d" CODE_CKSUM

//./FTE/cache/cache_consumer_partner_campiagn_mapping.c
#define CONSUMER_CAMPAIGN_MAPPING_KEY "consumer_camp%ld_map" CODE_CKSUM
#define CONSUMER_PARTNER_DECODING_DETAILS_KEY "consumer_partner_decoding_details" CODE_CKSUM
#define CONSUMER_PARTNER_DETAILS_KEY "consumer_partners" CODE_CKSUM

#define PUB_PREFERRED_BLOCKLIST_ID_KEY_FORMAT "PUB_PREFERRED_BLOCKLIST_ID_KEY_%ld" CODE_CKSUM

#define CACHE_KEY_DOMAIN_THROTTLING "DOMAIN_THROTTLING_%ld_%ld" CODE_CKSUM

#endif //GLOBAL_CACHE_KEYS_H
