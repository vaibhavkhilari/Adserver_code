/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef LOCKING_H
#define LOCKING_H   

/* Other lock error codes */
#include "lock_err.h"
#include "error.h"
#include <pthread.h>

typedef struct lock_var {
	int lock_fd;
	char *lock_name;
	pthread_rwlock_t pt_rw_lock;
} lock_var_t;

#define MAX_LOCK_FILE_NAME_SZ	8192
#define MAX_LOCK_NAME_LEN	256
#define LOCK_FILE_NAME_BASE_DIR	"/tmp"

/* Inter thread locking only PTHREAD based */
void pt_free_lock_var(lock_var_t *lock);
int pt_init_lock_var(lock_var_t *lock);
int pt_write_lock(lock_var_t *lock);
int pt_read_lock(lock_var_t *lock);
int pt_un_lock(lock_var_t *lock);

/* Inter process locking FLOCK based */
void fi_free_lock_var(lock_var_t *lock);
int fi_init_lock_var(lock_var_t *lock, char *lock_name);
int fi_write_lock(lock_var_t *lock);
int fi_read_lock(lock_var_t *lock);
int fi_un_lock(lock_var_t *lock);

/* Inter process and inter thread locking using the above methods */
void free_lock_var(lock_var_t *lock);
int init_lock_var(lock_var_t *lock, char *lock_name);
int write_lock(lock_var_t *lock);
int read_lock(lock_var_t *lock);
int un_lock(lock_var_t *lock);

/* LOCKING macros */
#ifndef LOCKING_POLICY_OVERRIDE
/* Default is interthread */
#define LOCKING_INTERTHREAD_ONLY
#endif /*LOCKING_POLICY_OVERRIDE */

#ifdef LOCKING_INTERPROCESS_ONLY
#define FREE_LOCK_VAR fi_free_lock_var
#define INIT_LOCK_VAR fi_init_lock_var
#define WRITE_LOCK fi_write_lock
#define READ_LOCK fi_read_lock
#define UN_LOCK fi_un_lock
#endif /* LOCKING_INTERPROCESS_ONLY */
#ifdef LOCKING_INTERTHREAD_ONLY
#define FREE_LOCK_VAR pt_free_lock_var
#define INIT_LOCK_VAR pt_init_lock_var
#define WRITE_LOCK pt_write_lock
#define READ_LOCK pt_read_lock
#define UN_LOCK pt_un_lock
#endif /* LOCKING_INTERTHREAD_ONLY */
#ifdef LOCKING_INTERTHREADPROCESS
#define FREE_LOCK_VAR fi_free_lock_var
#define INIT_LOCK_VAR fi_init_lock_var
#define WRITE_LOCK fi_write_lock
#define READ_LOCK fi_read_lock
#define UN_LOCK fi_un_lock
#endif /* LOCKING_INTERTHREADPROCESS */


#endif /* LOCKING_H */
