#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>


#ifndef __MACRO_SUBSTITUTION_UTIL_H__
#define __MACRO_SUBSTITUTION_UTIL_H__

#define MAX_MACRO_IN_STR 100
#define MAX_MACRO_VAL_LEN 256

#define MAX_NON_STR_VAL_LEN 32

typedef union _subs_data{
	void* value_ptr;
	char value_str[MAX_NON_STR_VAL_LEN+1];
}subs_data;

typedef enum {
	MACRO_SUBS_INTERNAL,
	TYPE_INT,
	TYPE_LONG,
	TYPE_FLOAT,
	TYPE_DOUBLE,
	TYPE_CHAR,
	TYPE_STRING
}data_types_t;


typedef struct _macro_list{
	char *macro_name;
	int name_len;
	int macro_id;
	//int indirect_macro_id;
}macro_list_t;

//each thread will have independent DS
typedef struct _value_store{
	int macro_id;
	subs_data  value;
	data_types_t value_type;
	char * value_str;
	int value_char_len;
	int is_valid_val;
}value_store_t;

typedef struct _macro_subt_pos{
	int start_pos;
	value_store_t *substitution;
}macro_subst_pos_t;

macro_list_t* get_macro_id(char * macro_name, macro_list_t *sorted_macro_array, int nele);

int substitute_macro_opt(char *out_str, int max_out_str_len, char* in_str,
		value_store_t * value_store, char macro_start_ch, macro_list_t *macro_list, int nmacro);

int init_macro_list(macro_list_t *ad_macro, int nad_macro);

int reset_value_store(value_store_t *vs, int nvs);
extern void init_substitution_macro_list();

#endif 
