/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __UND_FILTER_H__
#define __UND_FILTER_H__

#include <stdio.h>
#include <stdlib.h>
#include "ad_optimizer.h"
#include "ad_server_constants.h"
#include "error.h"
#include "aso.h"
#include "aso_ecpm.h"
#include <string.h>
#include "ad_server_debug.h"
#include "cache_intf.h"
#include "db_ad_active_accounts.h"
#include "http_header_helper.h"
#include "stats.h"
#define USER_NETWORK_DEFAULT "UND"
#define MAX_SINGLE_NETWORK_VALUE_LEN (128+1)
#define MAX_COOKIE_VALUE_LEN (2048)
#define COUNT_FOR_BLOCKING 2
#define MAX_BLOCKING_TIME 900
#define MAX_NETWORKS_BLOCKED 100
#define MAX_EXPIRY_TIME 60*60
#define NETWORK_TOKEN_SEPERATOR ":"
#define VAL_TOKEN_SEPERATOR "_"
#define MAX_STATS_KEYSIZE 128

#define ZERO 0
#define ONE 1

typedef struct ad_network_und
{
int adserver_id;
int und_flag;
}ad_network_und_t;



void user_network_default_filter(
		ad_active_account_t ** in_active_accounts,
		int in_nactive_accounts,
		network_elimination_list_t *elimination_list,
		fte_additional_params_t *fte_additional_parameters,
		long site_id,
		cache_handle_t *cache_handle,
		db_connection_t *dbconn,
		ad_server_req_gen_param_t *in_req_gen_params);
int increment_elimination_count(uint16_t *stats_counter);

#endif
