/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __REDUX_PCIOPTIMIZER_H__
#define __REDUX_PCIOPTIMIZER_H__

#include "ad_optimizer.h"

#define REDUX_PCI_OPTIMIZER_ID		  1036					 /* REDUX_PCI_OPTIMIZER ID */
#define REDUX_PCI_OPTIMIZER_NAME	 "REDUX_PCI_OPTIMIZER"	 /* REDUX_PCI_OPTIMIZER NAME */

/* REDUX_OPTIMIZER interfaces */
long redux_pci_optimizer_get_id(void);
int  redux_pci_optimizer_get_name(char **name);
int  redux_pci_optimizer_initilize(void *data);
int  redux_pci_optimizer_exit(void *data);
int  redux_pci_optimizer_handle_change_notification(void *data);
int  redux_pci_optimizer_increment_priority(
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		double priority);
int  redux_pci_optimizer_decrement_priority(
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		double priority);
int  redux_pci_optimizer_get_priority(
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		double *priority);
int  redux_pci_optimizer_get_ctr(
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		double *ctr);
int  redux_pci_optimizer_get_ecpm(double *ecpm);
int redux_pci_optimizer_insert_keywords_to_adscript(char **adscript, ad_server_req_param_t *in_req_params, adserver_macro_variable_name_list_t * macro_list);
int  redux_pci_optimizer_get_ad_code(
		selected_compaign_context_t *selected_camp_cntx,
		ad_server_req_param_t *in_req_params,
		ad_server_req_gen_param_t *in_gen_params,
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		cache_handle_t *cache_handle,
		db_connection_t *dbconn,
		unsigned long ptid,
		ad_server_additional_params_t *additional_params, 
fte_additional_params_t *fte_additional_parameters);


extern ad_optimizer_ops_t g_redux_pci_optimizer_ops;
#endif
