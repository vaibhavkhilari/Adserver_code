/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __INDIRECTADNETWORKOPTIMIZER_H__
#define __INDIRECTADNETWORKOPTIMIZER_H__

#include "ad_optimizer.h"

#define INDIRECTADNETWORK_OPTIMIZER_NAME 			"INDIRECTADNETWORK_OPTIMIZER"

#define ONE2ONEMEDIA_OPTIMIZER_ID 				11		 	 	 
#define ONE2ONEMEDIA_OPTIMIZER_NAME				INDIRECTADNETWORK_OPTIMIZER_NAME                 
#define TWENTYFOURBYSEVEN_REALMEDIA_OPTIMIZER_ID                12                                                    
#define TWENTYFOURBYSEVEN_REALMEDIA_OPTIMMIZER_NAME             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define SEVEN_ADPOWER_OPTIMIZER_ID                              13                                                    
#define SEVEN_ADPOWER_OPTIMMIZER_NAME                           INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ABSOLUTE_AGENCY_OPTIMIZER_ID                            14                                                    
#define ABSOLUTE_AGENCY_OPTIMMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ACCELERATOR_DASH_MEDIA_OPTIMIZER_ID                     15                                                    
#define ACCELERATOR_DASH_MEDIA_OPTIMMIZER_NAME                  INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define AD_SOLUTIONS_NETWORK_OPTIMIZER_ID                       16                                                    
#define AD_SOLUTIONS_NETWORK_OPTIMMIZER_NAME                    INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define AD_WORLD_NETWORK_OPTIMIZER_ID                           17                                                    
#define AD_WORLD_NETWORK_OPTIMMIZER_NAME                        INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADAGENCY1_OPTIMIZER_ID                                  18                                                    
#define ADAGENCY1_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADBONUS_OPTIMIZER_ID                                    19                                                    
#define ADBONUS_OPTIMMIZER_NAME                                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADDYNAMIX_SLASH_PENNYWEB_NETWORKS_OPTIMIZER_ID          20                                                    
#define ADDYNAMIX_SLASH_PENNYWEB_NETWORKS_OPTIMMIZER_NAME       INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADFORCE_OPTIMIZER_ID                                    21                                                    
#define ADFORCE_OPTIMMIZER_NAME                                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADHEARUS_OPTIMIZER_ID                                   22                                                    
#define ADHEARUS_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADJUG_OPTIMIZER_ID                                      23                                                    
#define ADJUG_OPTIMMIZER_NAME                                   INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADKNOWLEDGE_OPTIMIZER_ID                                24                                                    
#define ADKNOWLEDGE_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADLINK_OPTIMIZER_ID                                     25                                                    
#define ADLINK_OPTIMMIZER_NAME                                  INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADORIGIN_OPTIMIZER_ID                                   26                                                    
#define ADORIGIN_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADPEPPER_OPTIMIZER_ID                                   27                                                    
#define ADPEPPER_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADSMART_OPTIMIZER_ID                                    28                                                    
#define ADSMART_OPTIMMIZER_NAME                                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADSONAR_OPTIMIZER_ID                                    29                                                    
#define ADSONAR_OPTIMMIZER_NAME                                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ADZUBA_OPTIMIZER_ID                                     31                                                    
#define ADZUBA_OPTIMMIZER_NAME                                  INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define AFFILIATE_FUTURE_OPTIMIZER_ID                           32                                                    
#define AFFILIATE_FUTURE_OPTIMMIZER_NAME                        INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define AFFILIATE_SENSOR_OPTIMIZER_ID                           33                                                    
#define AFFILIATE_SENSOR_OPTIMMIZER_NAME                        INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ALL_CLICKS_OPTIMIZER_ID                                 34                                                    
#define ALL_CLICKS_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ALLFEEDS_OPTIMIZER_ID                                   35                                                    
#define ALLFEEDS_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define AMAZON_DOT_COM_OPTIMIZER_ID                             36                                                    
#define AMAZON_DOT_COM_OPTIMMIZER_NAME                          INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define AMPIRA_MEDIA_OPTIMIZER_ID                               37                                                    
#define AMPIRA_MEDIA_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define AXILL_OPTIMIZER_ID                                      38                                                    
#define AXILL_OPTIMMIZER_NAME                                   INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define AZOOGLE_ADS_OPTIMIZER_ID                                39                                                    
#define AZOOGLE_ADS_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define BANNERBOXES_OPTIMIZER_ID                                40                                                    
#define BANNERBOXES_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define BANNERSPACE_OPTIMIZER_ID                                42                                                    
#define BANNERSPACE_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define BCLICK_OPTIMIZER_ID                                     43                                                    
#define BCLICK_OPTIMMIZER_NAME                                  INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define BIDCLIX_OPTIMIZER_ID                                    44                                                    
#define BIDCLIX_OPTIMMIZER_NAME                                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define BLOGADS_OPTIMIZER_ID                                    46                                                    
#define BLOGADS_OPTIMMIZER_NAME                                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CBPROSENSE_OPTIMIZER_ID                                 47                                                    
#define CBPROSENSE_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CHITIKA_OPTIMIZER_ID                                    48                                                    
#define CHITIKA_OPTIMMIZER_NAME                                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CLAXON_MEDIA_OPTIMIZER_ID                               49                                                    
#define CLAXON_MEDIA_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CLICK_AGENTS_OPTIMIZER_ID                               50                                                    
#define CLICK_AGENTS_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CLICKBANK_OPTIMIZER_ID                                  51                                                    
#define CLICKBANK_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CLICKBOOTH_OPTIMIZER_ID                                 52                                                    
#define CLICKBOOTH_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CLICKHYPE_OPTIMIZER_ID                                  53                                                    
#define CLICKHYPE_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CLICKSOR_OPTIMIZER_ID                                   54                                                    
#define CLICKSOR_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CLICKXCHANGE_OPTIMIZER_ID                               55                                                    
#define CLICKXCHANGE_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CNET_SHOPPER_OPTIMIZER_ID                               56                                                    
#define CNET_SHOPPER_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define COMMISSION_JUNCTION_SLASH_OPTIMIZER_ID_BEFREE           57                                                    
#define COMMISSION_JUNCTION_SLASH_BEFREE_OPTIMMIZER_NAME        INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define COMMISSION_MONSTER_OPTIMIZER_ID                         58                                                    
#define COMMISSION_MONSTER_OPTIMMIZER_NAME                      INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define COVERCLICKS_OPTIMIZER_ID                                59                                                    
#define COVERCLICKS_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CREAMAID_OPTIMIZER_ID                                   61                                                    
#define CREAMAID_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define CRISPADS_BLOG_ADVERTISING_NETWORK_OPTIMIZER_ID          62                                                    
#define CRISPADS_BLOG_ADVERTISING_NETWORK_OPTIMMIZER_NAME       INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define DARKBLUE_OPTIMIZER_ID                                   63                                                    
#define DARKBLUE_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define DMO_GLOBAL_OPTIMIZER_ID                                 64                                                    
#define DMO_GLOBAL_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define DRIVEPM_OPTIMIZER_ID                                    65                                                    
#define DRIVEPM_OPTIMMIZER_NAME                                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define EMARKETMAKERS_OPTIMIZER_ID                              66                                                    
#define EMARKETMAKERS_OPTIMMIZER_NAME                           INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define EUROCLICK_OPTIMIZER_ID                                  67                                                    
#define EUROCLICK_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define EXPERCLICK_OPTIMIZER_ID                                 68                                                    
#define EXPERCLICK_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define EXPOACTIVE_OPTIMIZER_ID                                 69                                                    
#define EXPOACTIVE_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define FEDERATED_MEDIA_OPTIMIZER_ID                            70                                                    
#define FEDERATED_MEDIA_OPTIMMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define GOLD_GROUP_OPTIMIZER_ID                                 71                                                    
#define GOLD_GROUP_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define GORILLA_NATION_MEDIA_OPTIMIZER_ID                       72                                                    
#define GORILLA_NATION_MEDIA_OPTIMMIZER_NAME                    INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define HERAGENCY_OPTIMIZER_ID                                  73                                                    
#define HERAGENCY_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define HISPANOCLICK_OPTIMIZER_ID                               74                                                    
#define HISPANOCLICK_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define HURRICANE_DIGITAL_MEDIA_OPTIMIZER_ID                    75                                                    
#define HURRICANE_DIGITAL_MEDIA_OPTIMMIZER_NAME                 INDIRECTADNETWORK_OPTIMIZER_NAME                          
#define HYPERBIDDER_OPTIMIZER_ID                                76                                                    
#define HYPERBIDDER_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define IMPRESSION_PIPE_UP_OPTIMIZER_ID                         77                                                    
#define IMPRESSION_PIPE_UP_OPTIMMIZER_NAME                      INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define INDUSTRYBRAINS_OPTIMIZER_ID                             78                                                    
#define INDUSTRYBRAINS_OPTIMMIZER_NAME                          INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define INTERCLICK_OPTIMIZER_ID                                 79                                                    
#define INTERCLICK_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define INTEREVCO_OPTIMIZER_ID                                  80                                                    
#define INTEREVCO_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define JOETEC_OPTIMIZER_ID                                     81                                                    
#define JOETEC_OPTIMMIZER_NAME                                  INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define LINKSHARE_OPTIMIZER_ID                                  82                                                    
#define LINKSHARE_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define MAMMA_MEDIA_SLASH_FOCUSIN_OPTIMIZER_ID                  83                                                    
#define MAMMA_MEDIA_SLASH_FOCUSIN_OPTIMMIZER_NAME               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define MAXBOUNTY_OPTIMIZER_ID                                  84                                                    
#define MAXBOUNTY_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define MAXONLINE_OPTIMIZER_ID                                  85                                                    
#define MAXONLINE_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define META_REWARD_OPTIMIZER_ID                                86                                                    
#define META_REWARD_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define MIRAGO_OPTIMIZER_ID                                     87                                                    
#define MIRAGO_OPTIMMIZER_NAME                                  INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define MIVA_OPTIMIZER_ID                                       88                                                    
#define MIVA_OPTIMMIZER_NAME                                    INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define NIXXIE_OPTIMIZER_ID                                     89                                                    
#define NIXXIE_OPTIMMIZER_NAME                                  INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ONE_MONKEY_OPTIMIZER_ID                                 90                                                    
#define ONE_MONKEY_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define OPT_DASH_MEDIA_OPTIMIZER_ID                             91                                                    
#define OPT_DASH_MEDIA_OPTIMMIZER_NAME                          INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define ORIDIAN_OPTIMIZER_ID                                    92                                                    
#define ORIDIAN_OPTIMMIZER_NAME                                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define OXADO_OPTIMIZER_ID                                      93                                                    
#define OXADO_OPTIMMIZER_NAME                                   INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define PAYPERPOST_OPTIMIZER_ID                                 94                                                    
#define PAYPERPOST_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define PAYPOPUP_OPTIMIZER_ID                                   95                                                    
#define PAYPOPUP_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define PEAKCLICK_OPTIMIZER_ID                                  96                                                    
#define PEAKCLICK_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define PHEEDO_RSS_AND_WEBLOG_MARKETING_SOLUTIONS_OPTIMIZER_ID    97                                                    
#define PHEEDO_RSS_AND_WEBLOG_MARKETING_SOLUTIONS_OPTIMMIZER_NAME INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define POINTROLL_OPTIMIZER_ID                                  98                                                    
#define POINTROLL_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define POPUPTRAFFIC_OPTIMIZER_ID                               99                                                    
#define POPUPTRAFFIC_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define PREMIUM_NETWORK_OPTIMIZER_ID                            100                                                   
#define PREMIUM_NETWORK_OPTIMMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define PRICEGRABBER_OPTIMIZER_ID                               101                                                   
#define PRICEGRABBER_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define PROFITCENTER_OPTIMIZER_ID                               102                                                   
#define PROFITCENTER_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define QUAKE_MARKETING_OPTIMIZER_ID                            103                                                   
#define QUAKE_MARKETING_OPTIMMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define QUIN_STREET_OPTIMIZER_ID                                104                                                   
#define QUIN_STREET_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define QUMANA_ADGENTA_BLOG_ADS_OPTIMIZER_ID                    105                                                   
#define QUMANA_ADGENTA_BLOG_ADS_OPTIMMIZER_NAME                 INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define REALCASTMEDIA_OPTIMIZER_ID                              106                                                   
#define REALCASTMEDIA_OPTIMMIZER_NAME                           INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define RESPONSE_REPUBLIC_OPTIMIZER_ID                          108                                                   
#define RESPONSE_REPUBLIC_OPTIMMIZER_NAME                       INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define REVENUE_DOT_NET_OPTIMIZER_ID                            109                                                   
#define REVENUE_DOT_NET_OPTIMMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define REVIEWME_OPTIMIZER_ID                                   110                                                   
#define REVIEWME_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define RIGHT_MEDIA_OPTIMIZER_ID                                111                                                   
#define RIGHT_MEDIA_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define RYDIUM_OPTIMIZER_ID                                     112                                                   
#define RYDIUM_OPTIMMIZER_NAME                                  INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define SHAREASALE_OPTIMIZER_ID                                 113                                                   
#define SHAREASALE_OPTIMMIZER_NAME                              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define SHOPPING_DOT_COM_OPTIMIZER_ID                           114                                                   
#define SHOPPING_DOT_COM_OPTIMMIZER_NAME                        INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define STRATEGIC_AFFILIATES_OPTIMIZER_ID                       115                                                   
#define STRATEGIC_AFFILIATES_OPTIMMIZER_NAME                    INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define TARGETPOINT_OPTIMIZER_ID                                116                                                   
#define TARGETPOINT_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define TEXT_LINK_ADS_OPTIMIZER_ID                              117                                                   
#define TEXT_LINK_ADS_OPTIMMIZER_NAME                           INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define TEXTADS_DOT_BIZ_OPTIMIZER_ID                            118                                                   
#define TEXTADS_DOT_BIZ_OPTIMMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define TEXTWISE_OPTIMIZER_ID                                   119                                                   
#define TEXTWISE_OPTIMMIZER_NAME                                INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define THE_ROBERT_SHERMAN_COMPANY_OPTIMIZER_ID                 120                                                   
#define THE_ROBERT_SHERMAN_COMPANY_OPTIMMIZER_NAME              INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define TMP_OPTIMIZER_ID                                        121                                                   
#define TMP_OPTIMMIZER_NAME                                     INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define TRADEDOUBLER_OPTIMIZER_ID                               122                                                   
#define TRADEDOUBLER_OPTIMMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define TREMOR_NETWORK_OPTIMIZER_ID                             123                                                   
#define TREMOR_NETWORK_OPTIMMIZER_NAME                          INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define TTZ_MEDIA_OPTIMIZER_ID                                  124                                                   
#define TTZ_MEDIA_OPTIMMIZER_NAME                               INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define VALUEAD_DOT_COM_OPTIMIZER_ID                            125                                                   
#define VALUEAD_DOT_COM_OPTIMMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define VIBRANT_MEDIA_OPTIMIZER_ID                              126                                                   
#define VIBRANT_MEDIA_OPTIMMIZER_NAME                           INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define WEBADVERTISING_DOT_CA_OPTIMIZER_ID                      127                                                   
#define WEBADVERTISING_DOT_CA_OPTIMMIZER_NAME                   INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define WEBSPONSORS_OPTIMIZER_ID                                128                                                   
#define WEBSPONSORS_OPTIMMIZER_NAME                             INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define WHENU_OPTIMIZER_ID                                      129                                                   
#define WHENU_OPTIMMIZER_NAME                                   INDIRECTADNETWORK_OPTIMIZER_NAME                         
#define YES_ADVERTISING_OPTIMIZER_ID                            130                                   
#define YES_ADVERTISING_OPTIMMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME                          
#define TYROO_OPTIMIZER_ID					131
#define TYROO_OPTIMIZER_NAME					INDIRECTADNETWORK_OPTIMIZER_NAME
#define OZONE_MEDIA_OPTIMIZER_ID				132
#define OZONE_MEDIA_OPTIMIZER_NAME				INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADIFY_OPTIMIZER_ID					133
#define ADIFY_OPTIMIZER_NAME					INDIRECTADNETWORK_OPTIMIZER_NAME
#define PULSE360_OPTIMIZER_ID					134
#define PULSE360_OPTIMIZER_NAME					INDIRECTADNETWORK_OPTIMIZER_NAME
#define TURN_OPTIMIZER_ID					135
#define TURN_OPTIMIZER_NAME					INDIRECTADNETWORK_OPTIMIZER_NAME
#define CONTEXTWEB_OPTIMIZER_ID					136
#define CONTEXTWEB_OPTIMIZER_NAME				INDIRECTADNETWORK_OPTIMIZER_NAME
#define TAKODA_OPTIMIZER_ID					137
#define TAKODA_OPTIMIZER_NAME					INDIRECTADNETWORK_OPTIMIZER_NAME
#define SPECIIFICMEDIA_OPTIMIZER_ID				138
#define SPECIIFICMEDIA_OPTIMIZER_NAME				INDIRECTADNETWORK_OPTIMIZER_NAME
#define COLLECTIVEMEDIA_OPTIMIZER_ID				139
#define COLLECTIVEMEDIA_OPTIMIZER_NAME				INDIRECTADNETWORK_OPTIMIZER_NAME
#define VIZI_OPTIMIZER_ID					140
#define VIZI_OPTIMIZER_NAME					INDIRECTADNETWORK_OPTIMIZER_NAME
#define BETNETWORKS_OPTIMIZER_ID				141
#define BETNETWORKS_OPTIMIZER_NAME				INDIRECTADNETWORK_OPTIMIZER_NAME
#define HOUSE_ADS_OPTIMIZER_ID					142
#define HOUSE_ADS_OPTIMIZER_NAME				INDIRECTADNETWORK_OPTIMIZER_NAME
#define DOUBLEcLICK_ADVERTISING_EXCHANGE_OPTIMIZER_ID		143
#define DOUBLEcLICK_ADVERTISING_EXCHANGE_OPTIMIZER_NAME		INDIRECTADNETWORK_OPTIMIZER_NAME
#define WIDGETBUCKS_INDIRECT_OPTIMIZER_ID				144
#define WIDGETBUCKS_INDIRECT_OPTIMIZER_NAME				INDIRECTADNETWORK_OPTIMIZER_NAME
#define INTERGI_OPTIMIZER_ID					145
#define INTERGI_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADROLL_OPTIMIZER_ID						146
#define ADROLL_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define BRADZOMEDIA_OPTIMIZER_ID						147
#define BRADZOMEDIA_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADREACTOR_OPTIMIZER_ID						148
#define ADREACTOR_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define USERPLANE_OPTIMIZER_ID						149
#define USERPLANE_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADENGAGE_OPTIMIZER_ID						150
#define ADENGAGE_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADVERTISING_REVSHARE_OPTIMIZER_ID						151
#define ADVERTISING_REVSHARE_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADONNETWORK_OPTIMIZER_ID						152
#define ADONNETWORK_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADCONION_OPTIMIZER_ID						153
#define ADCONION_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define SHOPPINGADS_OPTIMIZER_ID						154
#define SHOPPINGADS_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define BRAVENETMEDIANETWORK_OPTIMIZER_ID						155
#define BRAVENETMEDIANETWORK_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define TRAFFICMARKETPLACE_OPTIMIZER_ID						156
#define TRAFFICMARKETPLACE_OPTIMIZER_NAME	            			INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADSDAQ_OPTIMIZER_ID                     158
#define ADSDAQ_OPTIMIZER_NAME                           INDIRECTADNETWORK_OPTIMIZER_NAME
#define UNDERDOG_MEDIA_OPTIMIZER_ID                     159
#define UNDERDOG_MEDIA_OPTIMIZER_NAME                           INDIRECTADNETWORK_OPTIMIZER_NAME
#define CASALE_MEDIA_OPTIMIZER_ID                       160
#define CASALE_MEDIA_OPTIMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME
#define REVENUEPILOT_OPTIMIZER_ID                       161
#define REVENUEPILOT_OPTIMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME
#define UNRULY_MEDIA_OPTIMIZER_ID                       162
#define UNRULY_MEDIA_OPTIMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADNET_OPTIMIZER_ID                      163
#define ADNET_OPTIMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADMAX_OPTIMIZER_ID                      164
#define ADMAX_OPTIMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME
#define PUBLISHER_NETWORK_OPTIMIZER_ID                      165
#define PUBLISHER_NETWORK_OPTIMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME
#define CPX_INDIRECT_OPTIMIZER_ID                       166
#define CPX_INDIRECT_OPTIMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME
#define SOCIALMEDIA_OPTIMIZER_ID                        167
#define SOCIALMEDIA_OPTIMIZER_NAME                          INDIRECTADNETWORK_OPTIMIZER_NAME
#define ROCKYOU_ADS_OPTIMIZER_ID                        168
#define ROCKYOU_ADS_OPTIMIZER_NAME                          INDIRECTADNETWORK_OPTIMIZER_NAME
#define CUBICS_OPTIMIZER_ID                     169
#define CUBICS_OPTIMIZER_NAME                           INDIRECTADNETWORK_OPTIMIZER_NAME
#define VALUECLICK_EUROPE_OPTIMIZER_ID                      170
#define VALUECLICK_EUROPE_OPTIMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME
#define CPM_STAR_OPTIMIZER_ID                       171
#define CPM_STAR_OPTIMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME
#define XTENDMEDIA_OPTIMIZER_ID                     172
#define XTENDMEDIA_OPTIMIZER_NAME                           INDIRECTADNETWORK_OPTIMIZER_NAME
#define DIRECTACLICK_FOX_OPTIMIZER_ID                       173
#define DIRECTACLICK_FOX_OPTIMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME
#define ACTIVE_RESPONSE_GROUP_OPTIMIZER_ID                      174
#define ACTIVE_RESPONSE_GROUP_OPTIMIZER_NAME                            INDIRECTADNETWORK_OPTIMIZER_NAME
#define GOOGLE_INDIRECT_OPTIMIZER_ID                        175
#define GOOGLE_INDIRECT_OPTIMIZER_NAME                          INDIRECTADNETWORK_OPTIMIZER_NAME
#define ADS_FOR_INDIANS_OPTIMIZER_ID                        176
#define ADS_FOR_INDIANS_OPTIMIZER_NAME                          INDIRECTADNETWORK_OPTIMIZER_NAME
#define EXOCLICK_OPTIMIZER_ID                       177
#define EXOCLICK_OPTIMIZER_NAME                         INDIRECTADNETWORK_OPTIMIZER_NAME


/* INDIRECTADNETWORK_OPTIMIZER interfaces */
long indirectadnetwork_optimizer_get_id(void);
int  indirectadnetwork_optimizer_get_name(char **name);
int  indirectadnetwork_optimizer_initilize(void *data);
int  indirectadnetwork_optimizer_exit(void *data);
int  indirectadnetwork_optimizer_handle_change_notification(void *data);
int  indirectadnetwork_optimizer_increment_priority(
	publisher_site_ad_t *in_ad,
	ad_active_account_t **in_active_accounts ,
	int in_nactive_accounts,
	double priority);
int  indirectadnetwork_optimizer_decrement_priority(
	publisher_site_ad_t *in_ad,
	ad_active_account_t **in_active_accounts ,
	int in_nactive_accounts,
	double priority);
int  indirectadnetwork_optimizer_get_priority(
	publisher_site_ad_t *in_ad,
	ad_active_account_t **in_active_accounts ,
	int in_nactive_accounts,
	double *priority);
int  indirectadnetwork_optimizer_get_ctr(
	publisher_site_ad_t *in_ad,
	ad_active_account_t **in_active_accounts ,
	int in_nactive_accounts,
	double *ctr);
int  indirectadnetwork_optimizer_get_ecpm(double *ecpm);
int indirectadnetwork_optimizer_insert_keywords_to_adscript(char **adscript, ad_server_req_param_t *in_req_params, adserver_macro_variable_name_list_t * macro_list);
int  indirectadnetwork_optimizer_get_ad_code(
	selected_compaign_context_t *selected_camp_cntx,
	ad_server_req_param_t *in_req_params,
	ad_server_req_gen_param_t *in_gen_params,
	publisher_site_ad_t *in_ad,
	ad_active_account_t **in_active_accounts ,
	int in_nactive_accounts,
	cache_handle_t *cache_handle,
	db_connection_t *dbconn,
	unsigned long ptid,
	ad_server_additional_params_t *additional_params, 
fte_additional_params_t *fte_additional_parameters);


extern ad_optimizer_ops_t g_indirectadnetwork_optimizer_ops;
#endif
