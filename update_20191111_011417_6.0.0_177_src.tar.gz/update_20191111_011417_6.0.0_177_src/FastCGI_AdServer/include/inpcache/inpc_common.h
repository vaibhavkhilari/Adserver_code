/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __COMMON__
#define __COMMON__

#define true 1
#define false 0

#define min(a, b) (((a) > (b)) ? (b) : (a))

//#define CURRENT_TIME() time(NULL)
#define current_time() g_time
//#define EIGHT_BYTE_ALIGN(val)  ((val%8) ? (val + (8 - (val%8))) : val)
#define CLEANUP_THREAD_SLEEP_INTERVAL 100
#define BACKWARD_EXPIRY_CHECK_LIMIT 100
#define DEF_BACKWARD_EXPIRY_CHECK_LIMIT 20
#define AGGRESSIVE_EXPIRY_SIZE_CUTOFF 40000
#define GUARANTEED_EXPIRY_TIME 100
#define EXPIRE_CLAIMABLE_ITEM_FLAG (128)
#define __with_lock(args) (args)
#define __with_atomic(args) 
#ifdef WITH_ATOMIC
#define __with_atomic(args) args;
#else
#define __with_atomic(args) 
#endif
#ifdef STATS_ON
#define __stats_check(args) (args)
#else 
#define __stats_check(args)
#endif

#ifdef SEQ_CHECK
#define __seq_check(args) (args)
#else
#define __seq_check(args)
#endif


typedef struct {
	char* ptr;
	uint64_t max_size;
//	int paged_size;
//	int unpaged_size;
	uint64_t used_size;
//	int available_size;
	pthread_mutex_t lock;
}memory_details_t;

#endif
