/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


/* -*- Mode: C; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */
/*
 * libdatrie - Double-Array Trie Library
 * Copyright (C) 2006  Theppitak Karoonboonyanan <thep@linux.thai.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/*
 * trie.h - Trie data type and functions
 * Created: 2006-08-11
 * Author:  Theppitak Karoonboonyanan <thep@linux.thai.net>
 */

#ifndef __TRIE_H
#define __TRIE_H

#include "triedefs.h"
#include "alpha-map.h"
#include "darray.h"
#include "typedefs.h"
#include "tail.h"
#include <config.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <locale.h>


#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file trie.h
 * @brief Trie data type and functions
 */
#define TRIE_TYPE_BOT_LIST 2
#define TRIE_TYPE_BROWSER_LIST 1
#define TRIE_TYPE_IP_BLK 3
#define MAX_TRIE_TYPES 3
#define TRIE_ALPHAMAP_ARRAY_SIZE 25
#define TRIE_BASE_ARRAY_SIZE 8192
#define TRIE_CHECK_ARRAY_SIZE 8192
#define TRIE_TAIL_ARRAY_SIZE 8192

#define IP_TRIE_BASE_ARRAY_SIZE 10485760 //10MB
#define IP_TRIE_CHECK_ARRAY_SIZE 10485760
#define IP_TRIE_TAIL_ARRAY_SIZE 10485760
#define MAX_IP_TRIE_DATE_LEN 20 //YYYY-MM-DD HH:MM:SS
#define DEFAULT_IP_TRIE_DATE "0000-00-00 00:00:00"

#define TRIE_DIR "/SCRIPTS/TRIE_GENERATION/"
#define KAD_DSN_NAME "db.kad.dsn.name" 
#define DSN_USERNAME "db.dsn.user.name" 
#define DSN_PASSWORD "db.dsn.user.password"
#define TRIE_CONFIG_FILE_NAME "/SCRIPTS/TRIE_GENERATION/conf/config.ini"

#define MAX_IAB_PATTERN_LENGTH 128
#define MAX_IP_ADDR_LEN 255
#define MAX_DOMAIN_LEN 127
#define MAX_SEPARATOR 30


/**
 * @brief Trie data type
 */
typedef struct {
  AlphaMap   *alpha_map;
  DArray     *da;
  Tail       *tail;
}Trie;

typedef struct {
  AlphaChar *ptr_t;
  TrieIndex total_size;
  Trie *tr;
}CachedTrie;

CachedTrie *cached_trie_new();
void cached_trie_free(CachedTrie *ct);
int trie_pattern_matching (CachedTrie * ct, AlphaChar *str);
int __generic_trie_exact_pattern_matching (Trie * trie, AlphaChar *str, void **data);
int __generic_trie_partial_pattern_matching (Trie * trie, AlphaChar *str, void **data,
    const int ndata, const char delimit);
int __generic_trie_prefix_match (Trie * trie, AlphaChar *str, void **data);

/**
 * @brief Trie enumeration function
 *
 * @param key  : the key of the entry
 * @param data : the data of the entry
 *
 * @return TRUE to continue enumeration, FALSE to stop
 */
typedef bool (*TrieEnumFunc) (const AlphaChar  *key,
                              void             *user_data);

/**
 * @brief Trie walking state
 */
typedef struct {
  const Trie *trie;       /**< the corresponding trie */
  TrieIndex   index;      /**< index in double-array/tail structures */
  short       suffix_idx; /**< suffix character offset, if in suffix */
  short       is_suffix;  /**< whether it is currently in suffix part */
}TrieState;

/*-----------------------*
 *   GENERAL FUNCTIONS   *
 *-----------------------*/

Trie *  trie_new (AlphaMap *alpha_map);

void    trie_free (Trie *trie);

int     trie_save (Trie *trie, const char *path);


/*------------------------------*
 *   GENERAL QUERY OPERATIONS   *
 *------------------------------*/

bool    trie_retrieve (const Trie      *trie,
                       const AlphaChar *key);

bool    trie_store (Trie *trie, const AlphaChar *key);

bool    __generic_trie_store (Trie *trie, const AlphaChar *key, void * data, int data_size);

bool    trie_enumerate (const Trie     *trie,
                        TrieEnumFunc    enum_func,
                        void           *user_data);


/*-------------------------------*
 *   STEPWISE QUERY OPERATIONS   *
 *-------------------------------*/

TrieState * trie_root (const Trie *trie);


/*----------------*
 *   TRIE STATE   *
 *----------------*/

TrieState * trie_state_clone (const TrieState *s);

void        trie_state_copy (TrieState *dst, const TrieState *src);

void      trie_state_free (TrieState *s);

void      trie_state_rewind (TrieState *s);

bool      trie_state_walk (TrieState *s, AlphaChar c);

bool      trie_state_is_walkable (const TrieState *s, AlphaChar c);

/**
 * @brief Check for terminal state
 *
 * @param s    : the state to check
 *
 * @return boolean value indicating whether it is a terminal state
 *
 * Check if the given state is a terminal state. A terminal state is a trie
 * state that terminates a key, and stores a value associated with it.
 */
#define   trie_state_is_terminal(s) trie_state_is_walkable((s),TRIE_CHAR_TERM)

bool      trie_state_is_single (const TrieState *s);

/**
 * @brief Check for leaf state
 *
 * @param s    : the state to check
 *
 * @return boolean value indicating whether it is a leaf state
 *
 * Check if the given state is a leaf state. A leaf state is a terminal state 
 * that has no other branch.
 */
#define   trie_state_is_leaf(s) \
    (trie_state_is_single(s) && trie_state_is_terminal(s))


#ifdef __cplusplus
}
#endif

#endif  /* __TRIE_H */

/*
vi:ts=4:ai:expandtab
*/
