/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __AD_SERVER_MAIN_UTILS_H_
#define __AD_SERVER_MAIN_UTILS_H_

//#include "fcgi_config.h"
#include <pthread.h>
#include <sys/types.h>

#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif

#include "fcgiapp.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>

/* Include other required headers */
#include "ad_server_types.h"
#include "ad_server_constants.h"
#include "http_header_helper.h"
#include "ad_optimizer.h"
#include "aso.h"
#include "error.h"
#include "ad_server_thread.h"
#include "adflex_optimizer.h"

/* DB related */
#include "db_connection.h"
#include "db_publisher_site_ad.h"
#include "db_publisher_site.h"
#include "db_ad_active_accounts.h"
#include "db_error.h"
#include "db_ad_served_tracking.h"
#include "db_ad_display_priority.h"

/* Utility headers */
#include "google_util.h"
#include "guid_util.h"
#include "config.h"
#include "base64_encoding.h"
#include "adtag_converter.h"
#include "geo_util.h"
#include "freq_utils.h"
#include "media_script_cache.h"
#include "cache_lucid_contextual_category.h"
#include "rtb_util.h"
#include "stats_util.h"
#include "config_params.h"
#include "uol_cookie_util.h"
#include "cache_adserver_config.h"
#include "generic_macro_processor.h"
#include "flexible_rtb_margin.h"
#include "compare_util.h"
#include "bloom_filter.h"
//#include "config_util.h"

/* Caching related headers */
#include "cache.h"

/* include dss header */
#include "dss_handle.h"

/* Curl header files */
#include <curl/curl.h>
/*stats collection lib header*/
#include "stats.h"
#include "libstats_util.h"
#include "ad_server_debug.h" 
#include "publisher_adservedtracking_component.h"

//
#include <assert.h>
//~
//

/* get used while normal as it is ad tag serving */

#define IFRAME_HTML_START "<script type=\"text/javascript\"> document.write('<iframe name=\"pbeacon\" frameborder=\"0\" allowtransparency=\"true\" hspace=\"0\" vspace=\"0\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\"  width=\"0\"  height=\"0\" style=\"position:absolute;top:-20000px;\" src=\"http://" 
#define IFRAME_HTML_END "\"> </iframe>'); </script>" 

// IMG tracking macro
#define IMG_HTML_START "<script type=\"text/javascript\"> document.write('<img name=\"pbeacon\"  width=\"0\"  height=\"0\" style=\"width:0;height:0;\" src=\"http://"

#define IMG_HTML_END "\" />'); </script>" 

//PubMatic as Bidder-LSX
#define PMB_IFRAME_HTML_START "<iframe name=\"pbeacon\" frameborder=\"0\" allowtransparency=\"true\" hspace=\"0\" vspace=\"0\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\"  width=\"0\"  height=\"0\" style=\"position:absolute;top:-20000px;\" src=\"http://"

#define PMB_IMG_HTML_START "<img name=\"pbeacon\" width=\"0\"  height=\"0\" style=\"width:0;height:0;\" src=\"http://"

#define PMB_IFRAME_HTML_END  "\"> </iframe>"

#define PMB_IMG_HTML_END  "\" />"
//PubMatic as Bidder LSX-End

//FREQ_UPDATE
#define FREQ_HTML_START "<iframe name=\"pbeacon\" frameborder=\"0\" allowtransparency=\"true\" hspace=\"0\" vspace=\"0\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\"  width=\"0\"  height=\"0\" style=\"position:absolute;top:-20000px;\" src=\""
#define FREQ_HTML_END "\"> </iframe>"

/*
#define FREQ_HTML_START "<script type=\"text/javascript\"> document.write('<iframe name=\"pbeacon\" frameborder=\"0\" allowtransparency=\"true\" hspace=\"0\" vspace=\"0\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\"  width=\"0\"  height=\"0\" style=\"position:absolute;top:-20000px;\" src="
#define FREQ_HTML_END "\"> </iframe>'); </script>"
*/

//HTTPS TRACKER CALL IFRAME MACRO
#define HTTPS_IFRAME_HTML_START "<script type=\"text/javascript\"> document.write('<iframe name=\"pbeacon\" frameborder=\"0\" allowtransparency=\"true\" hspace=\"0\" vspace=\"0\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\"  width=\"0\"  height=\"0\" style=\"position:absolute;top:-20000px;\" src=\"https://" 
#define IMG_MID "/AdServer/AdDisplayTrackerServlet?operId=1"

#define PIXEL_TRACKING_URL_PARAMS "%s%s%s%so=1&u=%s&p=%ld&s=%ld&d=%d&cp=%d&sc=%d&rs=%d&os=%d%s%s"
#define SERVER_PIXEL_TRACKING_URL_MID "/AdServer/SPug?"
#define CLIENT_PIXEL_TRACKING_URL "%sads.pubmatic.com/AdServer/js/showad.js#PIX&ptask=DSP&p=%ld&s=%ld&SPug=1"

#define CLIENT_PIXEL_TRACKING_URL_FP "%sads.pubmatic.com/AdServer/js/showad.js#PIX&ptask=DSP&SPug=1&fp=1&mpc=%d&u=%s&p=%ld&s=%ld&d=%d&cp=%d&sc=%d&rs=%d&os=%d%s"

#define PIXEL_TRACKING_URL_GDPR_PARAMS_LEN (MAX_GDPR_CONSENT_STR_LEN + 30)

#define CLIENT_PIXEL_TRACKING_URL_NON_API "%sads.pubmatic.com/AdServer/js/showad.js#PIX&ptask=DSP&p=%ld&s=%ld&SPug=1%s"

#define CLIENT_PIXEL_TRACKING_URL_NON_API_FP "%sads.pubmatic.com/AdServer/js/showad.js#PIX&ptask=DSP&SPug=1&fp=1&mpc=%d&u=%s&p=%ld&s=%ld&d=%d&cp=%d&sc=%d&rs=%d&os=%d%s%s"


//HTTPS TRACKER CALL IMG MACRO
#define HTTPS_IMG_HTML_START "<script type=\"text/javascript\"> document.write('<img name=\"pbeacon\"  width=\"0\"  height=\"0\" style=\"width:0;height:0;\" src=\"https://" 

/* get used while normal as it is ad tag serving */
//#define IMG_HTML_START "<script type=\"text/javascript\"> document.write('<img id=\"pbeacon\" height=\"0\" width=\"0\" src=\"http://" 
//#define IMG_HTML_END "\"/>');</script>" 

//#define IMG_MID "/AdServer/AdDisplayTrackerServlet?operId=1" 



/* get used while script based serving */
#define IFRAME_SCRIPT_START_TAG "<iframe name=\"pbeacon\" frameborder=\"0\" allowtransparency=\"true\" hspace=\"0\" vspace=\"0\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\"  width=\"0\"  height=\"0\" style=\"position:absolute;top:-20000px;\" src=\"http://" 
#define IFRAME_SCRIPT_START "document.write('" IFRAME_SCRIPT_START_TAG

#define IMG_SCRIPT_START_TAG "<img name=\"pbeacon\"  width=\"0\"  height=\"0\"  style=\"width:0;height:0;\" src=\"http://" 
#define IMG_SCRIPT_START "document.write('" IMG_SCRIPT_START_TAG

//HTTPS IFRAME TRACKER CALL MACRO
#define HTTPS_IFRAME_SCRIPT_START_TAG "<iframe name=\"pbeacon\" frameborder=\"0\" allowtransparency=\"true\" hspace=\"0\" vspace=\"0\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\"  width=\"0\"  height=\"0\" style=\"position:absolute;top:-20000px;\" src=\"https://" 
#define HTTPS_IFRAME_SCRIPT_START "document.write('" HTTPS_IFRAME_SCRIPT_START_TAG

//HTTPS IMG TRACKER CALL MACRO
#define HTTPS_IMG_SCRIPT_START_TAG "<img name=\"pbeacon\" width=\"0\"  height=\"0\" style=\"width:0;height:0;\" src=\"https://" 
#define HTTPS_IMG_SCRIPT_START "document.write('" HTTPS_IMG_SCRIPT_START_TAG

#define IMG_SCRIPT_END_TAG "\" />"
#define IMG_SCRIPT_END IMG_SCRIPT_END_TAG "');" 

#define IFRAME_SCRIPT_END_TAG "\"> </iframe>" 
#define IFRAME_SCRIPT_END IFRAME_SCRIPT_END_TAG "');" 


/* Click URL */
#define CLICK_URL_START "document.write('<div id=\""
#define CLICK_URL_MID	"\" style=\"position: absolute; margin: 0px 0px 0px 0px; height: 0px; width: 0px; top: -10000px; \" clickdata="
#define CLICK_URL_END   "></div>');\n"		

/*contextual data track call*/
#define CONTEXTUAL_CALL_START_TAG "<iframe name=\"context_track\" frameborder=\"0\" allowtransparency=\"true\" hspace=\"0\"vspace=\"0\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\"width=\"0\"  height=\"0\" style=\"position:absolute;top:-20000px;\" src=\"http://"
#define CONTEXTUAL_CALL_END_TAG "\"> </iframe>" 

#define CONTEXTUAL_CALL_HTML_START "<script type=\"text/javascript\"> document.write('" CONTEXTUAL_CALL_START_TAG
#define CONTEXTUAL_CALL_HTML_END CONTEXTUAL_CALL_END_TAG "'); </script>" 

#define CONTEXTUAL_CALL_MID "/AdServer/AdDisplayTrackerServlet?operId=4" 

#define CONTEXTUAL_CALL_SCRIPT_START "document.write('" CONTEXTUAL_CALL_START_TAG
#define CONTEXTUAL_CALL_SCRIPT_END CONTEXTUAL_CALL_END_TAG "');" 

#define CONTEXTUAL_CALL_SCRIPT_MAX_SIZE 8192

#define PROXIMIC_ADSERVER_ID 354
/*Execution Time Logging Enabled*/
#define TIME_LOGGING_ENABLED 1

#define LOGGING_ENABLED "ads.logging.enabled"
#define LOGGING_BUFFER_SIZE "ads.logging.buffer.size"
#define LOGGING_RESERVED_WAITTIME_SEC "ads.logging.reserved.waittime.sec"
#define LOGGING_URL "ads.logging.url"
#define LOGGING_URL_PREMIUM "ads.logging.url.premium"
#define LOGGING_URL_RESERVED "ads.logging.url.reserved"
#define LOGGING_URL_ADHOC "ads.logging.adhoc.url"
#define LOGGING_COMPRESSION_ENABLED "ads.logging.compression.enabled"
#define LOGGING_COMPRESSION_LEVEL "ads.logging.compression.level"
#define LOGGING_CONNECTION_TIMEOUT_MS "ads.logging.logger.connect.timeout_ms"
#define LOGGING_SEND_TIMEOUT_MS "ads.logging.logger.send.timeout_ms"
#define LOGGING_ADHOC_LOGGER_SEND_TIMEOUT_MS "ads.adhoc.logger.send.timeout_ms"
#define DISABLE_PAGEURL_LOGGING "ads.disable.page.url.logging"
#define ADSERVER_QPS_LOGGER_SEND_TIMEOUT_MS "ads.qps.logger.send.timeout_ms"
#define ADSERVER_QPS_LOGGING_URL "ads.logging.qps.url"
#define ADSERVER_QPS_LOGGER_BUFFER_SIZE "ads.qps.logging.buffer.size"
#define ADSERVER_QPS_LOGGING_ENABLED_FLAG "ads.qps.logging.enabled.flag"

//BIDLESS LOGGER CONFIGS
#define ADS_LOGGING_BIDLESS_MAX_BATCH_COUNT "ads.logging.bidless.max.batch.count"
#define ADS_LOGGING_BIDLESS_LOGGER_URL "ads.logging.bidless.logger.url"

// DB environment global structure.
// ---> removed the below, header file should not contain global variables else multiple
// definition problem would arise
#if 0
db_env_t g_dbenv;

/* Global configuration paremeters */
unsigned int g_conf_thread_count;
char *g_conf_ad_tracker_domain_name;
char *g_conf_domain_name;
char *g_conf_contextual_domain_name;
char *g_odbc_dsn_name;
char *g_odbc_dsn_user_name;
char *g_odbc_dsn_user_password;
char *g_odbc_tracking_dsn_name;
char *g_odbc_tracking_dsn_user_name;
char *g_odbc_tracking_dsn_user_password;
char *g_cache_servers;
char *g_contextual_cache_servers;
char *g_conf_ad_server_domain_name;
char *g_conf_geo_binary_file_path;
int g_n_priority_cache_elements;
int g_n_priority_cache_hash;
int g_cache_timeout;
int g_contextual_cache_timeout;
int g_geo_enabled_flag;
int g_frequency_enabled_flag;
int g_bidding_enabled_flag;
int g_contextual_tracking_enabled_flag;
int g_contextual_response_timeout;
int g_contextual_connection_timeout;
int g_fte_enabled_flag;
int g_frequency_ecpm_time_window;
int g_realtimebidding_enable_flag;
int g_datacenter_id;
int g_stats_collection_enable;
int g_allow_config_reload_flag;
int g_tracking_zone_id_limit;

/*global flags*/
int g_fte_cpc_enabled;
int g_rtb_debug_flag;
int g_frequency_enabled_flag;
int g_rtb_enable_persistent_connections;
int g_rtb_connection_pool_size;
//moved
char* g_stats_server_name;
int g_stats_server_port_no;
int g_rtb_curl_handle_reinit_value;
#endif


/*Utility Functions*/
int initialise_handles(ad_server_additional_params_t *additional_params);
void free_handles(ad_server_additional_params_t *additional_params);
int print_config(adserver_config_params_t *config);
/*set config structure using file config*/
int set_file_config(adserver_config_params_t **config_params);
/*to init scrach buffer*/
void init_scrach_buffer(string_scrach_buffer_t *scrach_buff);

int set_configuration(void);
void filter_realtime_networks_with_missing_mandatory_params(
		FCGX_Request* request,
		const ad_server_req_param_t* in_req_params,
		const ad_server_req_gen_param_t* in_gen_params,
		ad_server_additional_params_t* additional_params
		);
char * extract_url( char *url);

//Always reset the pointer to zero
#define FREE_AND_RESET(pointer) {free(pointer); pointer=0;}

extern const char * get_client_ip_address(const FCGX_Request *request, char * client_ip_address,       const ad_server_req_param_t* params, const publisher_level_settings_t *publisher_level_settings);
extern char * get_ip_ptr_from_list(const char *ip_list, char *client_ip_address, const int ip_pos);

void Auto_detect_https(const FCGX_Request* request,
		       const ad_server_additional_params_t *additional_params,
		       ad_server_req_param_t *params,
		       fte_additional_params_t *fte_additional_parameters
			);
extern int adserver_set_configuration(void);
extern void mask_xff(const char* xff, char* masked_xff);
extern int get_pub_country_level_privacy_settings(cache_handle_t *cache,db_connection_t *dbconn,
		unsigned long pub_id,int country_id,
		int pub_level_user_privacy);
int check_if_uniq(BLOOM **creative_bloom, unsigned long long crc64_uniq_creative_id, const int  * t_max_active_blooms);
void extract_domains_from_page_urls(ad_server_req_param_t *params, const ad_server_req_gen_param_t *gen_params);
#endif /*__AD_SERVER_MAIN_UTILS_H_*/
