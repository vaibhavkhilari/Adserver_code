#ifndef __COMMON_UTIL_H__
#define __COMMON_UTIL_H__
typedef struct cmpg_sp_info {
	double var_A;
	double var_B;
	double var_D;
	double r;
	double s;
	double t;
	double cp_boost_factor;
	double cp_boost_var_D;
	int impr_percentage;
	int algo_v2_percent;
	//int mode;
} cmpg_sp_info_t;

double calculate_cp_v1(
		double fp,
		double shv,
		double var_A,
		double var_B,
		double var_D,
		double r,
		double s,
		double t,
		mt_state* state
		);
double calculate_cp_v2(
		double fp,
		double shv,
		double var_A,
		double var_B,
		double var_D,
		mt_state* state
		);
double applyF2(
		const struct vecd* v,
		double shv,
		double fp,
		uint32_t rand_n,
		int rand_range_f2
		// mt_state* rand_state
		);
#endif
