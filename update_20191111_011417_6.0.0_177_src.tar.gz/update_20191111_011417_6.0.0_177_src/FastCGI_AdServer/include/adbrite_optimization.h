/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef ADBRITE_OPTIMIZATION_H
#define ADBRITE_OPTIMIZATION_H   

#include "ad_optimizer.h"
#include "adbrite_fixedscript.h"
#include "adbrite_samebackground.h"
#include "adbrite_contrastcolor.h"
#include "adbrite_colorrotator.h"
#include "adbrite_fixedcolorrotator.h"
#include "adbrite_optimizedcolor.h"

#define MAX_ADBRITE_OPTIMIZERS 7

/* The entries below should be in a fixed order */
static ad_optimizer_t g_adbrite_optimizers[MAX_ADBRITE_OPTIMIZERS] = {
	{0, NULL},
	{ADBRITE_FIXEDSCRIPT_ID, &g_adbrite_fixedscript_ops},
	{ADBRITE_SAMEBACKGROUND_ID, &g_adbrite_samebackground_ops},
	{ADBRITE_CONTRASTCOLOR_ID, &g_adbrite_contrastcolor_ops},
	{ADBRITE_COLORROTATOR_ID, &g_adbrite_colorrotator_ops},
	{ADBRITE_FIXEDCOLORROTATOR_ID, &g_adbrite_fixedcolorrotator_ops},
	{ADBRITE_OPTIMIZEDCOLOR_ID, &g_adbrite_optimizedcolor_ops}};

#endif /* ADBRITE_OPTIMIZATION_H */
