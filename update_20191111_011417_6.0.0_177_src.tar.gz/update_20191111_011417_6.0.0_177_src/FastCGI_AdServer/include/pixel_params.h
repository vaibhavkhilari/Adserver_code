/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __PIXEL_PARAMS_H__
#define __PIXEL_PARAMS_H__

#include "ad_server_types.h"
#include "pixel_data.h"

/* URL parameters */
#define RETARGET_OPER_ID "o"
#define TIMELIMIT "tl"
#define OPERATIONTYPE "type"
#define CODE "code"
#define JS "js"

/* URL parameters for rtb piggy back cookie*/
#define DP_ID "dp_id"
#define CAM_ID "cam_id"

#define VCODE "vcode"
#define COOKIE_RTB "piggybackCookie"
//Digitrust Id - eids json 
#define EIDS "eids"
//url redirection support
#define URLREDIRECT "r"

/*Pug Operation Ids*/
#define OPER_RETARGETTING 1

/*pixel classification id got from db*/
#define PIXEL_CLASS_RETARGET 1
#define PIXEL_CLASS_PIGGY_BACK 2

#define PIXEL_COOKIE_NAME_NEW "PR"
#define PIXEL_COOKIE_NAME "PUBRETARGET"
#define PMOO_COOKIE_NAME "pmoo"
#define DUMMY_PUBRETARGET_COOKIE "dummy"
#define PUG_TIMESTAMP_COOKIE_NAME "PugT"
//#define MAX_COOKIE_LEN 4096
#define IMAGE_PIXEL_COOKIE "ipc"
//URL REDIRECT MAX LENGTH
#define MAX_URL_REDIRECT_LENGTH 8192

#define PUBMATIC_COOKIE_SUBSTITUTION_MACRO "${PUBMATIC_UID}"
#define PUBMATIC_GDPR_SUBSTITUTION_MACRO "PM_GDPR"
#define PUBMATIC_CONSENT_SUBSTITUTION_MACRO "PM_CONSENT"

/*
 * Component level global flag check - GDPR_IP_CHECK_DISABLED
 * 1=PUG, 2=SPUG, 3=PUG&SPUG
 */
typedef enum syncup_component_name {
	PUG = 1,
	SPUG = 2,
	UPUG = 4,
	UCOOKIESETPUG = 8
} syncup_component_name_t;

/* Structure to keep pixel -> dsp, GDPR config */
typedef struct dsp_sync {
	unsigned long demand_partner_id;
	gdpr_vendor_config_t gdpr;
} dsp_syncup_config_t;

/* Structure encapsulating general pixel parameters.*/
typedef struct pixel_gen_params
{
	unsigned int pub_id;
	unsigned int pixel_lane;
	char browser[MAX_BROWSER_NAME_LEN];
	char user_id[MAX_UNIQUE_ID_LEN];
	char referer_url[MAX_URL_LENGTH];
	char *remote_ip_adddress;
	char redirect_url[MAX_URL_REDIRECT_LENGTH];
	int pm_consent_verified;
	int gdpr; /* gdpr param received in request (0/1) */
	char consent[MAX_GDPR_CONSENT_STR_LEN + 1];
	gdpr_consent_req_param_t gdpr_req_params;
	gdpr_consent_object_t consent_obj;
	pixel_tracking_params_t *vcode_params;
	int n_vcodes;
	unsigned int sync_dsp_status;
} pixel_gen_params_t;

int get_pixel_parameters(
	char *,
	pixel_tracking_params_t **,
	int *,
	char *,
	db_connection_t *,
	cache_handle_t *);

int syncup_url_macro_substitution(
		gdpr_consent_req_param_t *gdpr_req_params,
		const char *consent_str,
		const unsigned int sync_dsp_status,
		FCGX_Request* request,
		char* decoded_redirect_url);

int redirect_helper(
		const char *redirect_url,
		gdpr_consent_req_param_t *gdpr_req_params,
		const char *consent_str,
		const unsigned int sync_dsp_status,
		FCGX_Request* request,
		char* decoded_redirect_url);

unsigned int gdpr_syncup_cookie_update_not_permitted(gdpr_consent_req_param_t *gdpr_req_params,
		gdpr_consent_object_t *consent_obj,
		gdpr_vendor_config_t *gdpr_vendor);

int is_gdpr_req_and_no_pm_consent(cache_handle_t *cache,
		db_connection_t *dbconn,
		int gdpr_flag_in_req,
		char *consent_str,
		gdpr_consent_req_param_t *gdpr_req_params,
		int country_id,
		gdpr_consent_object_t *parsed_consent_obj,
		const int publisher_id,
		const int syncup_component);
void get_pixel_gen_params(pixel_gen_params_t *gen_params, FCGX_Request *request);

void free_pixel_parameters(pixel_tracking_params_t **);

char* get_remote_ip(FCGX_Request *request);

// Piggyback states.
#define PIGGYBACK_BLANK			1
#define PIGGYBACK_UPDATE		2
#define PIGGYBACK_REFRESH		3

#ifdef DEBUG_PUG_LOGGER
#define DUMP_PIXEL_GEN_PARAMS(GEN_PARAMS)		do {					\
	fprintf(stderr, "Fn:%s:%d.\n", __FUNCTION__, __LINE__);				\
	fprintf(stderr, "Brsr:%s GUID:%s R_URL:%s R_IP:%s.\n", 				\
	(GEN_PARAMS)->browser, (GEN_PARAMS)->user_id, 						\
	(GEN_PARAMS)->referer_url, (GEN_PARAMS)->remote_ip_adddress);		\
} while (0)

#define DUMP_HTTP_HEADERS(REQUEST) 				do {										\
	char **p = NULL;																		\
	fprintf(stderr, "================== HTTP HEADERS BEGIN =========================\n");	\
	for (p = (REQUEST)->envp; *p; ++p) {													\
		fprintf(stderr, "%s.\n", *p);														\
	}																						\
	fprintf(stderr, "================== HTTP HEADERS END ===========================\n");	\
} while (0)

#define DUMP_PIXEL_TRACKING_PARAMS(PTP)          do {                                        \
	fprintf(stderr, "Fn:%s:%d.\n", __FUNCTION__, __LINE__);				                    \
	fprintf(stderr, "opid:%d tl:%d optype:%d code:%lu js:%d found:%d is_pb:%d ps:%d cs:%p.\n",  \
            (PTP)->oper_id,                                                                 \
            (PTP)->time_limit,                                                              \
            (PTP)->operation_type,                                                          \
            (PTP)->code,                                                                    \
            (PTP)->js,                                                                      \
            (PTP)->found_flag,                                                              \
            (PTP)->is_piggyback,                                                            \
            (PTP)->piggyback_state,                                                         \
            (PTP)->cookie_string);                                                          \
} while (0)

#else	// #ifdef DEBUG_PUG_LOGGER
#define DUMP_PIXEL_GEN_PARAMS(GEN_PARAMS)
#define DUMP_PIXEL_TRACKING_PARAMS(PTP)
#define DUMP_HTTP_HEADERS(REQUEST)
#endif	// #ifdef DEBUG_PUG_LOGGER

#define MAX_PUG_LATENCY_HEADER_VALUE_SIZE 30
#define PUG_LATENCY_HEADER_NAME "lat"
#define MAX_DB_RECONNECT_COUNT 5

#define PUG_ERROR_SUCCESS 0
#define PUG_ERROR_PM_OPT_OUT 1
#define PUG_ERROR_NO_PIXEL_PARAM 2
#define PUG_ERROR_MALLOC 3
#define PUG_ERROR_MYSQL 4
#define PUG_ERROR_GDPR_OPT_OUT 5

#endif 
