/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef ADSERVER_COMMON_UTIL_H   
#define ADSERVER_COMMON_UTIL_H   

#include "ad_server_types.h"
#include <regex.h>
/*random number keyword used for pubmatic one networks*/
#define PUB_RANDOM_KEY "PUB_ONE_RANDOM_HERE"

#define PUB_CACHE_BUSTER_KEY "[cache_buster]"

/*cache buster place holders in creative scripts*/
#define PUB_ADFLEX_CACHE_BUSTER_KEY "#PCACHEBUSTER"
#define UNIQUE_ID_LEN 36
#define PM_UID_REGEX "^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$"


/*Pubmatic UID Regular Expression */
regex_t g_pm_uid_regex;

/*common function to insert random number to adscript, used for pubone networks*/
int insert_random_no_to_adscript(char *adcode, char* adscript, char *keyword,
                        long int random);


/*common function that will insert keyword string w.r.t fence into the adscript*/
int insert_keywords_to_adscript(char *adcode, char *adscript, char *keyword_str, char *fence);

/*for def handling url macro substitution support , multi substitution*/
int insert_def_handling_url_to_adscript(char *adcode, char* adscript, char *keyword,
				char *def_url);

int apply_geo_filter_on_publisher_site( 
    ad_server_additional_params_t *additional_params,
    publisher_site_ad_serving_rtb_status_t *publisher_site_ad_serving_rtb_status, 
    geo_data_t *geo_data,                        
    int * matching_index);

int validate_pubmatic_uid(char *pubmaticUID);
void server_side_optout_cleanup(
		void **user_segment_list_info,
		char **user_cookie_value,
		ad_server_req_param_t *params);

#endif /* ADSERVER_COMMON_UTIL_H */
