/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

/* Consumer Id Object Params */
#define DIGITRUST_SOURCE_3X "digitru.st"
#define CONSUMERID_EID_OBJECT_KEY "eids"
#define CONSUMERID_UID_KEY "uids"
#define CONSUMERID_UID_JSON_KEY "\"uids\":["
#define CONSUMERID_SOURCE_KEY "source"
#define CONSUMERID_ID_KEY "id"
#define CONSUMERID_ATYPE_KEY "atype"
#define EXTENSION_KEY "ext"
#define CONSUMER_KEY_VERSION "keyv"
#define CONSUMERID_ORIGIN_KEY "org"
#define MAX_CUNSUMERID_UID_ID_LEN 384
#define MAX_CUNSUMERID_DECRYPT_UID_ID_LEN 64
#define MAX_CONSUMERID_SOURCE_LEN 64
#define MAX_CONSUMERID_UID_COUNT 3
#define MAX_CONSUMERID_EID_COUNT 5 //This is per partner count. Maximum partners supported by Pubmatic
#define MAX_CONSUMERID_UIDS_LEN 2 + MAX_CONSUMERID_UID_COUNT * (MAX_CUNSUMERID_UID_ID_LEN + sizeof(int) + 18)
#define MAX_CONSUMER_PER_EID_LEN MAX_CONSUMERID_SOURCE_LEN + MAX_CONSUMERID_UIDS_LEN + 20
#define MAX_CONSUMER_EIDS_LEN 2 + MAX_CONSUMERID_EID_COUNT * MAX_CONSUMER_PER_EID_LEN

#define MAX_PUBLIC_KEY_LEN 2048
#define CONSUMERID_ORIGIN_PUBMATIC 1
#define CONSUMERID_ORIGIN_PUBLISHER 0
#define ARRAY_START '['

typedef struct uids{
	char id[MAX_CUNSUMERID_UID_ID_LEN+1];
	int atype;
}uids_t;

/* 
 * Structures to Store eids object from Request
 */
typedef struct eid{
	char source[MAX_CONSUMERID_SOURCE_LEN+1];
	uids_t uids[MAX_CONSUMERID_UID_COUNT];
	int uid_count;
	char uids_json_buf[MAX_CONSUMER_PER_EID_LEN+1];
	int origin; //0: Received in Request, 1:Pubmatic Derived 
}eid_t;

typedef struct consumer_identifier{
	eid_t *eids;
	int eid_count;
}consumer_identifier_t;

/* this structure stores consumer partner details like DigiTrust */
typedef struct consumer_partner_decoding_details {
	int partner_id; // internal partner id
	char partner_source[MAX_CONSUMERID_SOURCE_LEN+1]; // partner source
	char partner_private_key[MAX_PUBLIC_KEY_LEN+1]; 
	int private_key_version_id;	
	int partner_id_base64_encoded;
	int ortb_version_format_touse;
} consumer_partner_decoding_details_t;

typedef struct consumer_partner_details {
	char partner_source[MAX_CONSUMERID_SOURCE_LEN+1]; // partner source
	int alternate_dsp_cookie_to_use;
	char uid_id[MAX_CUNSUMERID_UID_ID_LEN+1];
}consumer_partner_details_t;

typedef struct consumer_partners{
	consumer_partner_details_t *consumer_partner_details;
	int consumer_partners_count;
}consumer_partners_t;

void populate_consumer_identifier(char *var_value, 
		consumer_identifier_t **req_eid_obj,
		db_connection_t *dbconn,
		cache_handle_t *cache_handle);

consumer_partners_t * get_alternate_dspid_for_eids(
                        cache_handle_t *cache_handle,
                        db_connection_t *dbconn,
                        consumer_identifier_t *req_consumer_identifiers);

