/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __TIME_UTIL_H__
#define __TIME_UTIL_H__

#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif
int sec_remained_in_day();
int max_of_sec_in_hour_and_ten_min();

#define TIME_DIFF_MICRO(START_TIME, END_TIME) ((((END_TIME).tv_sec * 1000000) + (END_TIME).tv_usec) - (((START_TIME).tv_sec * 1000000) + (START_TIME).tv_usec))
#define TIME_DIFF_MILLI(START_TIME, END_TIME) (TIME_DIFF_MICRO((START_TIME), (END_TIME))/1000)

#define MAX_TIMESTAMP_SIZE_DDMMYY_HHMMSS_MS 64

typedef struct timediff {
	struct timeval start_time;
	struct timeval end_time;
	unsigned long int time_diff_in_microsecond;
} timediff_t;

void set_start_time (timediff_t *t);
void set_end_time (timediff_t *t);
unsigned long int get_time_diff (timediff_t *t);
int get_rfc3339_formatted_utc_timestamp(char *timestamp);
#ifdef __cplusplus
}
#endif
#endif
