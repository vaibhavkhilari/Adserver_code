#ifndef GET_ADVERTISER_ID_H
#define GET_ADVERTISER_ID_H
#include "khash.h"

// For a given domain url, we store the following information
// that is in a hash table, domain_url is the key and the "value" is the following

// Each domain can have maximum three different categories. (e.g Sony.com falls under Technology as well as Shopping category)
// We keep only sub categories in hash to save space.
// Primary category can be achieved easily using sub category
struct domain_adv_category_info {
	long advertiser_id;
	long domain_id;
	short int sub_iab_cat1;
	short int sub_iab_cat2;
	short int sub_iab_cat3;
};

// API to return IAB category as integers
int get_acd_id_for_domain(const char *advertiser_domain,
			long *advertiser_id,
			long *domain_id,
			int *sub1_iab_cat,
			int *pri_iab_cat,
			int *sub2_iab_cat,
			int *sub2_pri_iab_cat,
			int *sub3_iab_cat,
			int *sub3_pri_iab_cat);

// API to return IAB category as string(to be returned to publishers and
// used in UCF filter and for in_req_param filtering
int get_acd_str_for_domain(const char *advertiser_domain,
			long *advertiser_id,
			long *domain_id,
			char *sub1_iab_cat,
			char *pri_iab_cat,
			char *sub2_iab_cat,
			char *sub2_pri_iab_cat,
			char *sub3_iab_cat,
			char *sub3_pri_iab_cat,
			int *iab_sub_cat_int);

KHASH_MAP_INIT_STR(domainAdvCategoryInfo, struct domain_adv_category_info);
void destroy_domain_adv_htable(khash_t(domainAdvCategoryInfo) *);
#endif
