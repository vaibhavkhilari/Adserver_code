/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef _RTB_BID_PRICE_ENCRYPTION_H_ 
#define _RTB_BID_PRICE_ENCRYPTION_H_

#include <stdio.h>
#include <endian.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/time.h>
#include <stdint.h>
#include <inttypes.h>
#include "base64_encoding.h"
#include "hmac_sha2.h"
#include "sha2.h"

#define INTIALIZATION_VECTOR_SIZE 16
#define CIPHER_TEXT_SIZE 8
#define SIGNATURE_SIZE 4
#define TOTAL_ENCRYPTED_TEXT_SIZE (INTIALIZATION_VECTOR_SIZE + CIPHER_TEXT_SIZE + SIGNATURE_SIZE)
#define HASH_OUPUT_SIZE 32
#define TOTAL_B64_ENCRYPTED_TEXT_SIZE 50
#define WEB_SAFE_B64_ENCRYPTED_TEXT_SIZE 38

#define CIPHER_TEXT_SIZE_NEW 16
#define TOTAL_B64_ENCRYPTED_TEXT_SIZE_NEW 64
#define WEB_SAFE_B64_ENCRYPTED_TEXT_SIZE_NEW 48
#define TOTAL_ENCRYPTED_TEXT_SIZE_NEW (INTIALIZATION_VECTOR_SIZE + CIPHER_TEXT_SIZE_NEW + SIGNATURE_SIZE)

#define RTB_BID_PRICE_ENCRYPTION_FAILURE 0
#define RTB_BID_PRICE_ENCRYPTION_SUCCESS 1
#define RTB_BID_PRICE_DECRYPTION_FAILURE 0
#define RTB_BID_PRICE_DECRYPTION_SUCCESS 1


/* functions to encrypt/decrypt rtb_bid_price */
int32_t encrypt_rtb_bid_price(double bid_price,
                              const char *encryption_key,
                              const char *integrity_key,
                              char *b64_encrypted_rtb_bid_price);

int32_t decrypt_rtb_bid_price(char *b64_encrypted_rtb_bid_price,
                              char *encryption_key,
                              char *integrity_key,
                              double *bid_price);

/* Reason for introducing new encrypt_price function - 
 * Bug - encrypt_rtb_bid_price involves encryption of double values and buffer lengths  which support only 7 digits. For any number having digits greater than 7, the extra digits from the precision gets truncated.
 * eg - on encrypting 9999.9999, decryption results as 9999.9990
 * Solution - increasing the buffer sizes of cipher text and encryption output and converting the double prices to long double
 * Extra info - as the current function works in paring with the dsp, updating the function would lead to decryption issues on the dsp side. Because all the standard decryption functions work on decryption based on encrypted string length which in our case is increased.
*/

int32_t encrypt_price(long double bid_price,
		const char *encryption_key,
		const char *integrity_key,
		char *b64_encrypted_rtb_bid_price);

int32_t decrypt_price(char *b64_encrypted_rtb_bid_price,
		char *encryption_key,
		char *integrity_key,
		long double *bid_price);

int32_t encrypt_rtb_bid_price_helper(
		const char* bid_price,
		const char* encryption_key,
		const char* integrity_key,
		char* b64_encrypted_rtb_bid_price);

#endif /* _RTB_BID_PRICE_ENCRYPTION_H_ */
