/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current
PubMatic employees, managers or contractors who have executed
 Confidentiality and Non-disclosure agreements explicitly covering such access.

 The copyright notice above does not evidence any actual or intended publication or disclosure of this source
code, which includes
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION,
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE,
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION
DOES NOT CONVEY OR IMPLY ANY RIGHTS
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY
DESCRIBE, IN WHOLE OR IN PART.
 */

/*
 * signal_handler.h
 *
 *  Created on: Sep 11, 2017
 *      Author: srinivas
 */

#ifndef __SIGNAL_HANDLER_H__
#define __SIGNAL_HANDLER_H__

#define LOG_SIGNAL_FATAL(format, ...) fprintf(stderr, "\nFATAL|SIGNAL_HANDLER|"format"|%s:%d\n" , ##__VA_ARGS__, __FILE__, __LINE__)
#define LOG_SIGNAL_ERROR(format, ...) fprintf(stderr, "\nERROR|SIGNAL_HANDLER|"format"|%s:%d\n" , ##__VA_ARGS__, __FILE__, __LINE__)
#define LOG_SIGNAL_INFO(format, ...)  fprintf(stderr, "\nINFO |SIGNAL_HANDLER|"format"|%s:%d\n" , ##__VA_ARGS__, __FILE__, __LINE__)

#ifdef __SIGNAL_DEBUG__
#define LOG_SIGNAL_DEBUG(format, ...) fprintf(stderr, "\nDEBUG|SIGNAL_HANDLER|"format"|%s:%d\n" , ##__VA_ARGS__, __FILE__, __LINE__)
#else
#define LOG_SIGNAL_DEBUG(format, ...)
#endif

extern void Install_signal_handlers(int app_thread_count, int min_thread_threshold);
extern int Verify_signal_handlers(void);
extern int Shutdown_notice_given();
extern void Shutdown_notice_start();
extern void Start_thread_monitor(void);
extern void Shutdown_fcgx_threads(pthread_t *tlist, int tcount);
extern int Get_current_app_thread_count(void);
extern int Get_min_threadcount_threshold(void);
extern void Set_coredump_status(int);
extern int Is_coredumps_on(void);
#endif
