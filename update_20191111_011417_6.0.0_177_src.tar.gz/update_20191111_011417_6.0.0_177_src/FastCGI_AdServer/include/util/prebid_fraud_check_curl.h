/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __PREBID_FRAUD_CHECK__
#define __PREBID_FRAUD_CHECK__

#include <stdio.h>
#include <error.h>
#include <ctype.h>
#include "ad_server_types.h"
#include "rt_types.h"
#include "json.h"
#include "json_util.h"
#include "json_object_private.h"
#include "client_lb.h"
#include "url_util.h"
#include "time_util.h"
#include <string.h>
#include <openssl/hmac.h>
#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/buffer.h>

#if defined DEBUG || defined PREBID_CHECK_DEBUG
        #define PREBID_DEBUGLOG(format, ...) fprintf(stderr, "\nPREBID: " format " -> %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__)
#else
        #define PREBID_DEBUGLOG(format, ...)
#endif


#define PREBID_FRAUD_CHECK_CURL_NAME "PREBID FRAUD CHECK CURL"
#define MAX_CURL_PREBID_FRAUD_CHECK_DATA_SIZE 	1024

#define PREBID_DUMMY_USER_AGENT "useragent"
#define PREBID_CONTENT_TYPE "text/plain"
#define PREBID_REQ_TYPE "GET"
#define PREBID_MAX_STRING_TO_SIGN_LEN 2100  // max req_type=3 + Max http url=2000 + max timestamp=64 + max content_type=10 + max dummy ua=10

// Request headers
#define FRAUD_CHECK_IP_HDR "X-Tap-Ipv4: %s"
#define FRAUD_CHECK_HOST_DOMAIN_HDR "X-Tap-Host-Domain: %s"
#define FRAUD_CHECK_UA_HDR "X-Tap-User-Agent-Encoded: %s"
#define FRAUD_CHECK_CLI_UA_HDR "User-Agent: %s"
#define FRAUD_CHECK_CONT_TYPE_HDR "Content-Type: %s"
#define FRAUD_CHECK_APP_ID_HDR "X-Tap-AppID: %s"
#define FRAUD_CHECK_CACHE_TTL_HDR "X-Cache-Ttl: %ds"
#define FRAUD_CHECK_AUTH_HDR "Authorization: APIKey=%s,Signature=%s,Timestamp=%s"
#define FRAUD_CHECK_MAX_HDR_LEN 2048 //  Assuming the user-agent header(512 bytes) will be bigger one.

// Response headers
#define PRED_HTTP_RESP "HTTP/1.1"
#define PRED_ID_HEADER "X-Tap-Pred-Id:"
#define PRED_RESULT_HEADER "X-Tap-Bot:"
#define CACHE_RESULT_HEADER "X-Cache:"
#define PRED_RESULT_FALSE "false"
#define PRED_RESULT_TRUE "true"
#define WOPS_CACHE_RESULT_HIT "HIT"
#define WOPS_CACHE_RESULT_MISS "MISS"

typedef struct prebid_fraud_check_curl_data {
	char prediction_id[MAX_PREDICTION_ID_LEN + 1];
	char prediction_result[MAX_PREDICTION_RESULT_LEN + 1];
	char response_code[MAX_HTTP_RESP_CODE_LEN + 1];
	char cache_status[MAX_CACHE_STATUS_LEN + 1];
	int is_buffer_overflow;
	int is_data_received;
	struct timeval tv_curl_call_end;
}prebid_fraud_check_curl_data_t;

int set_prebid_fraud_check_options (char *ip_address,
		const ad_server_req_param_t *in_server_req_params,
		char *user_agent,
		CURL *curl,
		prebid_fraud_check_curl_data_t *prebid_fraud_check_chunk,
		prebid_fraud_check_data_t *prebid_fraud_check_data);

struct curl_slist* prepare_headers_for_prebid_request(struct curl_slist *fraud_chk_hdr_list,
		const char *ip,
		char *host_domain,
		char *user_agent,
		char *app_id,
		prebid_fraud_check_data_t *prebid_fraud_check_data);

int parse_prebid_fraud_check_data(const prebid_fraud_check_curl_data_t *prebid_fraud_check_chunk,
		prebid_fraud_check_data_t *prebid_fraud_check_data);

int init_prebid_fraud_check_curl_handle(CURL **curl_handle,
		const char* connection_name,
		const int connection_timeout,
		const int request_timeout,
		const int no_signal);
#endif

