/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef STRING_UTIL_H
#define STRING_UTIL_H   

#include<stdlib.h>
#include<stdio.h>
#include<openssl/sha.h>
#include<openssl/md5.h>

#define MAX_MD5_STRING_LENGTH (16*2)
#define MAX_SHA1_STRING_LENGTH (20*2)

#ifdef __cplusplus
extern "C"
{
#endif
	char* trim_right(char *szSource);
	void trim_spaces(char *szSource);
	char *trim_left(char *szSource);
	char *trim(char *szSource);
	char *url_encode(char *szSource,char szDestination[]);
	//char *url_decode(char *szSource,char szDestination[]);
	int decode_url(const char* source,char* dest,int dest_size);
	int nstrcpy(char *dest, const char *src, size_t n);
	typedef struct ads_string{
		char *str;
		int max_length;/*max buffer size above*/
		int str_length;/*lebgth of the string upto null char*/
		int freeit;/*if its 1 then str should be freed*/
	}ads_string_t;

	extern ads_string_t * malloc_ads_string_str(ads_string_t * ad_string,size_t string_buffer_size);
	extern ads_string_t * malloc_ads_string(size_t string_buffer_size);
	extern ads_string_t * realloc_ads_string_str(ads_string_t * ad_string,size_t string_buffer_new_size,int copy_old_data);
	extern void init_ads_string(ads_string_t * ad_string);
	int html_url_encode(const char *s, char *buf, int limit);
	void copy_user_guid(char *user_guid, char *user_cookie_value, int max_unique_id_len);
	int substitute_macro(
			char* dest,
			int max_size,
			const char* processing_script,
			const char* fence,
			const char* keyword,
			const char* value
			);
	int print_formatted_string(char *dest, const char *src, const int max_length);
	void truncate_str(char* str);
	void strtoupper(char *str, int max_len);
	void strtolower(char *str, int max_len);
	int get_sha1_hash(char * out_str, int max_out_len_with_null, const char *in_str);
	int get_md5_hash(char * out_str, int max_out_len_with_null, const char *in_str);
	int decode_url_with_special_case_handling(const char* source, char* dest, int dest_size);
	void free_ads_string(ads_string_t * ad_string);
	int dec4_binary(unsigned int num, char *buff, int *start);
	void ipv6_to_bin(char *addr, char *ip_buffer, int *start);
	int replacechar(char *str, char orig, char rep);
	int mask_ip_addr(char * addr,char* masked_ip_address);
#ifdef __cplusplus
}
#endif
#endif /* STRING_UTIL_H */
