/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef PUG_LIBSTATS_UTIL_H
#define PUG_LIBSTATS_UTIL_H

#include <time.h>

#define MAX_PIXEL_LEN_NUMBER 9
#define MAX_STATS_PUBLISHERS 1000
#define MAX_STATS_PIXELS     500

#define UNKNOWN_ENTITY_ID	1

typedef struct pixel_lane_stats {
        unsigned int entity_id;
        unsigned int count[MAX_PIXEL_LEN_NUMBER];
} pixel_lane_stats_t;

/* Actual pixel_counters. */
typedef struct pixel_counters {
    unsigned long               pixel_id;
    uint32_t                    set_count;
    uint32_t                    unset_count;
    uint32_t                    piggyback_set_count;
    uint32_t                    piggyback_unset_count;
} pixel_counters_t;


/* Wrapper around pixel_counters so that we can dynamically allocate the array and vary length as required. */
typedef struct pug_stats {
    uint32_t                    pixel_counter_length;
    pixel_counters_t            *pixel_counters;
    struct tm                   t1;
} pug_stats_t;


/* Update t1 at pug_stats. */
#define UPDATE_PUG_STATS_T1(PUG_STATS)      do {                        \
    time_t current_time;                                                \
    current_time = time(NULL);                                          \
    localtime_r(&current_time, &pug_stats->t1);                         \
} while(0)


/* Initial size of pixel_counters and step size to vary its length. */
#define PUG_STATS_INIT_COUNTER_SIZE         5
#define PUG_STATS_STEP_COUNTER_SIZE         5


/* Config file to read properties from. */
#define PUG_STATS_CONFIG_FILE               "/etc/pug_stats_collection.properties"


/* Property strings at config file. */
#define PUG_STATS_SERVER_NAME               "pug_stats.server.name"
#define PUG_STATS_PORT_NUMBER               "pug_stats.port.number"
#define PUG_STATS_PUGSERVER_NAME            "pug_stats.pugserver.name"
#define PUG_STATS_SERVER_DATACENTER_NAME    "pug_stats.datacenter.name"
#define PUG_STATS_COUNTER_SIZE              "pug_stats.counter.size"
#define PUG_STATS_LOGGING_ENABLED           "pug.stats.logging.enabled"


/* Events for PUG stats collection. */
#define PUG_PIXEL_SET                       0
#define PUG_PIXEL_UNSET                     1
#define PUG_PIXEL_PIGGYBACK_SET             2
#define PUG_PIXEL_PIGGYBACK_UNSET           3
#define PUG_PIXEL_MAX_EVENTS                4


/* Event strings for PUG stats collection. These strings have one-to-one correspondece with above pixel event macros. */ 
extern char *pug_pixel_event_str[PUG_PIXEL_MAX_EVENTS];


/* */
#define MAX_PUG_STATS_KEY_SIZE              256


/* Exported variables. */
extern char *g_pugs_name;
extern char *g_pug_stats_server_name;
extern int  g_pug_stats_server_port_no;
extern uint16_t g_pug_stats_counter_size;
extern char *g_pug_stats_datacenter_name;
extern int g_pug_stats_logging_enabled;


/* PUG stats collection interfaces. */
extern int pug_stats_set_config(void);
extern int pug_stats_util_init(pug_stats_t *pug_stats);
extern int pug_increment_pixel_counter(pug_stats_t *pug_stats, int event_id, pixel_tracking_params_t *params);
extern void increment_pixel_lane_stats( pixel_lane_stats_t *pixel_stats, 
		pixel_lane_stats_t *pub_stats, 
		const pixel_gen_params_t *gen_params, 
		const pixel_tracking_params_t *params);

/* Utility macro. Wrapper over pug_increment_pixel_counter. */
#define PUG_STATS_UTIL_INIT(PUG_STATS, RETVAL)                      do {                    \
    if (g_pug_stats_logging_enabled == 1)                                                   \
    {                                                                                       \
        (RETVAL) = pug_stats_util_init((PUG_STATS));                                        \
    }                                                                                       \
} while(0)

#ifdef DEBUG_PUG_STATS_COLLECTION
#define PUG_INCREMENT_PIXEL_COUNTER(PUG_STATS, EVENT_ID, PARAMS)    do {          	        \
    if (g_pug_stats_logging_enabled == 1)                                                   \
    {                                                                                       \
        fprintf(stderr, "Fn:%s:%d. Calling pug_increment_pixel_counter(%p, %d, %u).\n",	    \
                __FUNCTION__, __LINE__, (PUG_STATS), (EVENT_ID), (PARAMS)->code);      	    \
        pug_increment_pixel_counter((PUG_STATS), (EVENT_ID), (PARAMS));                 	\
    }                                                                                       \
} while (0)
#else
#define PUG_INCREMENT_PIXEL_COUNTER(PUG_STATS, EVENT_ID, PARAMS)    do {          	        \
    if (g_pug_stats_logging_enabled == 1)                                                   \
    {                                                                                       \
        pug_increment_pixel_counter((PUG_STATS), (EVENT_ID), (PARAMS));                 	\
    }                                                                                       \
} while (0)
#endif	// #ifdef DEBUG_PUG_STATS_COLLECTION

/* Following contruct is to help in debugging this sub-module. Comment(Uncomment) DEBUG_PUG_STATS_COLLECTION
to disable(enable) debugging tools for the module. */
extern void __dump_pug_stats__(pug_stats_t *pug_stats, const char *fn, unsigned int ln);

#ifdef DEBUG_PUG_STATS_COLLECTION
#define DUMP_PUG_STATS(PUG_STATS)           __dump_pug_stats__((PUG_STATS), __FUNCTION__, __LINE__)
#else   // #ifdef DEBUG_PUG_STATS_COLLECTION
#define DUMP_PUG_STATS(PUG_STATS)                
#endif  // #ifdef DEBUG_PUG_STATS_COLLECTION

#endif	// #ifndef PUG_LIBSTATS_UTIL_H

