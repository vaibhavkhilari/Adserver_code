/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current
PubMatic employees, managers or contractors who have executed
 Confidentiality and Non-disclosure agreements explicitly covering such access.

 The copyright notice above does not evidence any actual or intended publication or disclosure of this source
code, which includes
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION,
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE,
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION
DOES NOT CONVEY OR IMPLY ANY RIGHTS
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY
DESCRIBE, IN WHOLE OR IN PART.
 */

#ifndef VIDEO_STATS_H
#define VIDEO_STATS_H

#include "stats.h"

#define VIDEO_STAT_IMPRESSION "VIDEO:IMPR"	//Stats per adserver
#define VIDEO_STAT_ERROR_CREATIVE "VIDEO:ERR_CRTV"	// stats per adserver: creative error
#define VIDEO_STAT_ERROR_REQUEST "VIDEO:ERR_REQ"	// stats per adserver: ad tag request error
#define VIDEO_STAT_WIN_ADNETWORK "VIDEO:WIN_ADNW"	// stats per DC
#define VIDEO_STAT_WIN_RTB "VIDEO:WIN_RTB"	// stats per DC
#define VIDEO_STAT_RESP_VAST "VIDEO:RESP_VAST"	// stats per DC
#define VIDEO_STAT_RESP_URL "VIDEO:RESP_URL"	// stats per DC
#define VIDEO_STAT_REQ_API "VIDEO:IMPR_API"	// stats per DC
#define VIDEO_STAT_IMPR_FLASH "VIDEO:IMPR_FLASH"	// stats per DC
#define VIDEO_STAT_IMPR_HTML5 "VIDEO:IMPR_HTML5"	// stats per DC
#define VIDEO_STAT_EMPTY_VAST "VIDEO:EMPTY_VAST"       // stats per DC

#define AUDIO_STAT_IMPRESSION "AUDIO:IMPR"	//Stats per adserver
#define AUDIO_STAT_ERROR_CREATIVE "AUDIO:ERR_CRTV"	// stats per adserver: creative error
#define AUDIO_STAT_ERROR_REQUEST "AUDIO:ERR_REQ"	// stats per adserver: ad tag request error
#define AUDIO_STAT_WIN_ADNETWORK "AUDIO:WIN_ADNW"	// stats per DC
#define AUDIO_STAT_WIN_RTB "AUDIO:WIN_RTB"	// stats per DC
#define AUDIO_STAT_RESP_VAST "AUDIO:RESP_VAST"	// stats per DC
#define AUDIO_STAT_RESP_URL "AUDIO:RESP_URL"	// stats per DC
#define AUDIO_STAT_REQ_API "AUDIO:IMPR_API"	// stats per DC
#define AUDIO_STAT_IMPR_FLASH "AUDIO:IMPR_FLASH"	// stats per DC
#define AUDIO_STAT_IMPR_HTML5 "AUDIO:IMPR_HTML5"	// stats per DC
#define AUDIO_STAT_EMPTY_VAST "AUDIO:EMPTY_VAST"       // stats per DC

#define INIT_ADS_DC_WISE_STATS_METRIC(stats_metric, metric_name) {\
					sprintf(stats_metric.name, "%s:%s:%s", metric_name, \
                                                             g_ads_name, \
                                                             g_stats_datacenter_name); \
					stats_metric.count = 0;\
					}

#define INIT_DC_WISE_STATS_METRIC(stats_metric, metric_name) {\
					sprintf(stats_metric.name, "%s:%s", metric_name, \
                                                             g_stats_datacenter_name); \
					stats_metric.count = 0;\
					}

#define UPDATE_STAT_METRIC(stats_metric) {\
					if(stats_metric.count >= (uint32_t) (g_stats_counter_size * 10)){ \
						stats_add(stats_metric.name, stats_metric.count); \
					        stats_metric.count = 0; \
        				} \
				   }

typedef struct stats_metric{
        uint32_t count;
        char name[STATS_KEY_MAX_SIZE];
}stats_metric_t;

typedef struct video_stats{
        stats_metric_t impression;
        stats_metric_t error_crtv;
        stats_metric_t error_req;
        stats_metric_t adnetwork_win;
        stats_metric_t rtb_win;
        stats_metric_t vast_resp;
        stats_metric_t url_resp;
        stats_metric_t impr_api;
        stats_metric_t impr_flash;
        stats_metric_t impr_html5;
        stats_metric_t empty_vast;
}video_stats_t;

typedef struct audio_stats{
        stats_metric_t impression;
        stats_metric_t error_crtv;
        stats_metric_t error_req;
        stats_metric_t adnetwork_win;
        stats_metric_t rtb_win;
        stats_metric_t vast_resp;
        stats_metric_t url_resp;
        stats_metric_t impr_api;
        stats_metric_t empty_vast;
}audio_stats_t;

void init_video_stats(video_stats_t *video_stats);

void update_video_stats(video_stats_t *video_stats, int stats_collection_enable);

void init_audio_stats(audio_stats_t *audio_stats);

void update_audio_stats(audio_stats_t *audio_stats, int stats_collection_enable);

#endif /* VIDEO_STATS_H */
