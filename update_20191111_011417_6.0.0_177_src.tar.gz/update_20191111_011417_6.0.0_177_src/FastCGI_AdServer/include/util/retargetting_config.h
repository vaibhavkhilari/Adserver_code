/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __RETARGETTING_CONFIG_H__
#define __RETARGETTING_CONFIG_H__

/* configuration keys */
#define RETARGETTING_CONFIG_FILE_NAME "/etc/retargetting.properties"

#define PIXELTRACKER_THREAD_COUNT "pixeltracker.thread.count"
#define FTE_ODBC_DSN_NAME  "fte.odbc.dns.name"
#define FTE_ODBC_DSN_USERNAME "fte.odbc.dns.username"
#define FTE_ODBC_DSN_PASSWORD "fte.odbc.dns.password"
#define FTE_CACHE_SERVER "fte.cache.server"
#define FTE_CACHE_ELEMENT_TIMEOUT "fte.cache.element.timeout"
#define ADSERVER_ODBC_DSN_NAME	"adserver.odbc.dsn.name"
#define ADSERVER_ODBC_DSN_USERNAME	"adserver.odbc.dsn.user.name"
#define ADSERVER_ODBC_DSN_PASSSWORD	"adserver.odbc.dsn.user.password"
#define PUG_GEO_BINARY_FILE_PATH    "geo.binary.file.path"
#define PUG_NETACUITY_DATA_DIR    "netacuity.data.dir"
#define PIGGY_BACK_COOKIE_NEW_NAME  "piggyback.cookie.newname"
#define PUG_DATACENTER_ID	"pug.datacenter.id"
#define IMAGE_PIXEL_SYNCUP_END_PT "image.pixel.syncup.endpoint"
#endif 
