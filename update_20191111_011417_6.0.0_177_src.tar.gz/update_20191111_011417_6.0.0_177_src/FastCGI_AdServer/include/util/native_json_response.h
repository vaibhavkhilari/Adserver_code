#ifndef __NATIVE_JSON_RESPONSE_H__
#define __NATIVE_JSON_RESPONSE_H__

#include "json.h"

#define OPENRTB_NATIVE_RESPONSE_VERSION            1

typedef struct native_json_response_link {
   json_object *self;
   json_object *click_trackers;
} native_json_response_link_t;

typedef struct native_json_response_asset {
   json_object *self;
   json_object *asset;
   native_json_response_link_t link;
} native_json_response_asset_t;

typedef struct native_json_response {
   json_object *self;
   json_object *native;
   json_object *assets;
   json_object *imp_trackers;

   native_json_response_link_t link;
} native_json_response_t;

// Native Object
int init_native_json_response(native_json_response_t *response);

void free_native_json_response(native_json_response_t *response);

const char *native_json_response_to_string(native_json_response_t *response);

int njr_set_version(native_json_response_t *response);

int njr_add_impression_tracker(native_json_response_t *response, const char *tracker);

int njr_set_js_trackers(native_json_response_t *response, const char *jstrackers);

// Link Object
int njr_set_landing_page_url(native_json_response_t *response, const char *url);

int njr_add_click_tracker(native_json_response_t *response, const char *tracker);

int njr_set_fallback_url(native_json_response_t *response, const char *url);

// Asset Objects
//int njr_init_asset(native_json_response_asset_t *asset);
int njr_add_title(native_json_response_t *response, 
                  native_json_response_asset_t *asset, 
                  int id, int required,
                  const char *text);

int njr_add_image(native_json_response_t *response,
                  native_json_response_asset_t *asset,
                  int id, int required,
                  const char *url, int width, int height);

int njr_add_data(native_json_response_t *response,
                  native_json_response_asset_t *asset,
                  int id, int required,
                  const char *value, const char *text);

int njr_add_video(native_json_response_t *response,
                  native_json_response_asset_t *asset,
                  int id, int required,
                  const char *vasttag);

int njr_set_asset_landing_page_url(native_json_response_asset_t *asset, const char *url);

int njr_add_asset_click_tracker(native_json_response_asset_t *asset, const char *tracker);

int njr_set_asset_fallback_url(native_json_response_asset_t *asset, const char *url);

#endif
