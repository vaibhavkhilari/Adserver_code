#ifndef _GET_VIDEO_CREATIVE_ATTR_H_
#define _GET_VIDEO_CREATIVE_ATTR_H_
#include "khash.h"
/*
 * This structure has currentely one varibale
 * in future it will have more
 */
struct video_creative_info{
	int mime_type;
};
KHASH_MAP_INIT_STR(videoCreativeInfo, struct video_creative_info);
void destroy_video_creative_htable(khash_t(videoCreativeInfo) *);
#endif /* _GET_VIDEO_CREATIVE_ATTR_H_ */
