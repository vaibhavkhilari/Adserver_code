/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef API_Pubs_Track_thread
#define API_Pubs_Track_thread

#include "ad_server_types.h" //pageURL Length

#define ENCODED_MAX_PAGE_STR_LEN (3 * MAX_PAGE_STR_LEN)

#define OPER_ID "operId"
#define PUBLISHER_ID "pubId"
#define SITE_ID "siteId"
#define AD_ID "adId"
#define PUBLISHER_PAGE_URL "pubPgUrl"
#define RETRIVED_PAGE_URL "retPgUrl"
#define RETRIVED_REFERER_URL "retRefUrl"
#define TIMESTAMP "time"

typedef struct tracking_params_api_demand_safety {
	long operId;
	long pubId;
	long siteId;
	long adId;
	char pub_pgURL[MAX_PAGE_STR_LEN];
	char decoded_pub_pgURL[ENCODED_MAX_PAGE_STR_LEN];
	char ret_pgURL[MAX_PAGE_STR_LEN];
	char decoded_ret_pgURL[ENCODED_MAX_PAGE_STR_LEN];
	char ret_refURL[MAX_PAGE_STR_LEN/*TODO ??*/];
	char decoded_ret_refURL[ENCODED_MAX_PAGE_STR_LEN/*TODO 3*?? */];
	//long timestamp;
} tracking_params_api_demand_safety_t;

#endif 
