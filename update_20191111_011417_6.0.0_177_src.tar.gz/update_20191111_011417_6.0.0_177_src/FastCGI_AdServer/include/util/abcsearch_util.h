/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef ABCSEARCH_UTIL_H
#define ABCSEARCH_UTIL_H   


/*adscript size limits*/
#define ABCSEARCH_AD_SCRIPT_MAX_SIZE	8192
#define ABCSEARCH_TMP_BUFF_SIZE		50

/*start, mid, end values*/
#define ABCSEARCH_START_COMMENT "<!-- Begin: ABCSearch -->"

#define ABCSEARCH_SCRIPT_START "<script type='text/javascript'>"
#define SCRIPT_END "</script>"
#define ABCSEARCH_SCRIPT_END "<script type='text/javascript'   src='http://www.abcsearch.com/adntfy.js'>"

#define ABCSEARCH_END_COMMENT "<!-- End: ABCSearch -->\n"

/*abcsearch adentify params*/
#define ABC_AD_USER "abc_ad_user = "
#define ABC_BANNER_WIDTH_NAME "abc_banner_width = "
#define ABC_BANNER_HEIGHT_NAME "abc_banner_height = "
#define ABC_VERT_AD_COUNT "abc_v_ad_count = "
#define ABC_HORZ_AD_COUNT "abc_h_ad_count = "
#define ABC_SUB_ID "abc_subid = \"pm_"

/*abcsearch adentify params with constant values*/
#define ABC_SIZE_TITLE "abc_size_title = 13"
#define ABC_SIZE_TEXT  "abc_size_text = 10"
#define ABC_SIZE_URL  "abc_size_url = 0"
#define ABC_SIZE_BORDER  "abc_size_border = 1"
#define ABC_SIZE_BORDER_TEXT  "abc_size_border_text = 9"
#define ABC_AD_LINE_SPACE  "abc_ad_line_space = 3"

/*constant value adentify params*/
#define ABC_FONT_WEIGHT "abc_font_weight = \"bold\""
#define ABC_TEXT_ALIGNMENT "abc_text_alignment = \"left\""
#define ABC_SCROLL_TITLE "abc_scroll_title = \"noscroll\""
#define ABC_UNDERLINE_TITLE "abc_underline_title = \"nounderline\""
#define ABC_NEW_WINDOW "abc_new_window = \"no\""

/*abcsearch color params*/
#define ABC_COLOR_BORDER "abc_color_border = "
#define ABC_COLOR_BG "abc_color_bg = "
#define ABC_COLOR_TITLE "abc_color_title = "
#define ABC_COLOR_TEXT "abc_color_text = "
#define ABC_COLOR_URL "abc_color_url = "
#define ABC_COLOR_BORDER_TEXT "abc_color_border_text = "


/*abcsearch adsizes with their respective adcount mappings*/

/*SKYSCRAPPERS*/
#define ABC_WIDE_SKYSCRAPPER_WIDTH 160
#define ABC_WIDE_SKYSCRAPPER_HEIGHT 600
#define ABC_WIDE_SKYSCRAPPER_VERT_AD_COUNT 5
#define ABC_WIDE_SKYSCRAPPER_HORZ_AD_COUNT 1

#define ABC_SKYSCRAPPER_WIDTH 120
#define ABC_SKYSCRAPPER_HEIGHT 600
#define ABC_SKYSCRAPPER_VERT_AD_COUNT 4
#define ABC_SKYSCRAPPER_HORZ_AD_COUNT 1

#define ABC_VERTICLE_SKYSCRAPPER_WIDTH 120
#define ABC_VERTICLE_SKYSCRAPPER_HEIGHT 240
#define ABC_VERTICLE_SKYSCRAPPER_VERT_AD_COUNT 2
#define ABC_VERTICLE_SKYSCRAPPER_HORZ_AD_COUNT 1

/*BANNERS*/
#define ABC_BANNER_WIDTH 468
#define ABC_BANNER_HEIGHT 60
#define ABC_BANNER_VERT_AD_COUNT 1
#define ABC_BANNER_HORZ_AD_COUNT 1

#define ABC_LEADERBOARD_WIDTH 728
#define ABC_LEADERBOARD_HEIGHT 90
#define ABC_LEADERBOARD_VERT_AD_COUNT 1
#define ABC_LEADERBOARD_HORZ_AD_COUNT 2


#define ABC_HALFBANNER_WIDTH 234
#define ABC_HALFBANNER_HEIGHT 60
#define ABC_HALFBANNER_VERT_AD_COUNT 1
#define ABC_HALFBANNER_HORZ_AD_COUNT 1

/*SQUARES*/
#define ABC_SQUARE_WIDTH 250
#define ABC_SQUARE_HEIGHT 250
#define ABC_SQUARE_VERT_AD_COUNT 1
#define ABC_SQUARE_HORZ_AD_COUNT 2

#define ABC_BUTTON_WIDTH 125
#define ABC_BUTTON_HEIGHT 125
#define ABC_BUTTON_VERT_AD_COUNT 1
#define ABC_BUTTON_HORZ_AD_COUNT 1

/*RECTANGLES*/
#define ABC_LARGE_RECTANGLE_WIDTH 336
#define ABC_LARGE_RECTANGLE_HEIGHT 280
#define ABC_LARGE_RECTANGLE_VERT_AD_COUNT 2
#define ABC_LARGE_RECTANGLE_HORZ_AD_COUNT 1

#define ABC_SMALL_RECTANGLE_WIDTH 180
#define ABC_SMALL_RECTANGLE_HEIGHT 150
#define ABC_SMALL_RECTANGLE_VERT_AD_COUNT 1
#define ABC_SMALL_RECTANGLE_HORZ_AD_COUNT 1

#define ABC_MEDIUM_RECTANGLE_WIDTH 300
#define ABC_MEDIUM_RECTANGLE_HEIGHT 250
#define ABC_MEDIUM_RECTANGLE_VERT_AD_COUNT 2
#define ABC_MEDIUM_RECTANGLE_HORZ_AD_COUNT 1


#define ABC_DEFAULT_VERT_AD_COUNT 1
#define ABC_DEFAULT_HORZ_AD_COUNT 1

char *get_abcsearch_adscript(char *client_id,
			int width,
			int height,
			long ad_id,
			char *border_color,
			char *bg_color,
			char *title_color,
			char *url_color,
			char *text_color,
			char *border_text_color);

char *get_abcsearch_adscript_without_color(char *client_id,
			int width,
			int height,
			long ad_id);

#endif /* ABCSEARCH_UTIL_H */
