/*
	 PubMatic Inc. ("PubMatic") CONFIDENTIAL
	 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/


#ifndef __SLIST_H__
#define __SLIST_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

// Common function to free list element.
typedef void (*__free_function)(void *);

// Common function to print contents of the list.
typedef void (*__print_function)(void *);

// Common function to compare two elements of the list.
typedef int (*__compare_function)(const void *, const void *);

// Common function to find anything in the list.
typedef void* (*__find_function)(void *, const void *);


/* list structure defination */
typedef struct static_list {
	int iterator;
	int curr;
	int size;
	void **data;
	__free_function freefn;
	__print_function printfn;
	__compare_function comparafn;
	__find_function findfn;
} slist_t;


#define SLIST slist_t

/* Memeber functions  declared over structure. */

void slist_print ( SLIST *s );
int slist_create( SLIST *s, int no_list_elements, __free_function free_fun_ptr, __print_function print_fun_ptr, __compare_function comparator_fun_ptr, __find_function find_fun_ptr );
void slist_destroy( SLIST *s );
int slist_get_size( SLIST *s );
int slist_add (SLIST *s, void *data);
int slist_indexof( SLIST *s, void *data );
void slist_sort( SLIST *s );
void *slist_find( SLIST *s, const void *data );
void slist_sort( SLIST *s );
#ifdef __cplusplus
}
#endif
#endif /* __SLIST_H__ */
