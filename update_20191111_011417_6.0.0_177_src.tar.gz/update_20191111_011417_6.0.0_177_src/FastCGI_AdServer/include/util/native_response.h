#ifndef __NATIVE_RESPONSE_H__
#define __NATIVE_RESPONSE_H__

#include "native_common.h"

// Native Response Keys
#define NATIVE_RESPONSE_OBJECT_KEY                 "native"
#define NATIVE_RESPONSE_VERSION_KEY                "ver"
#define NATIVE_RESPONSE_JSTRACKER_KEY              "jstracker"
#define NATIVE_RESPONSE_ASSETS_KEY                 "assets"
#define NATIVE_RESPONSE_IMPTRACKERS_KEY            "imptrackers"
#define NATIVE_RESPONSE_ASSET_ID_KEY               "id"
#define NATIVE_RESPONSE_ASSET_REQUIRED_KEY         "required"
#define NATIVE_RESPONSE_ASSET_TITLE_KEY            "title" 
#define NATIVE_RESPONSE_ASSET_TITLE_TEXT_KEY       "text"
#define NATIVE_RESPONSE_ASSET_IMAGE_KEY            "img"
#define NATIVE_RESPONSE_ASSET_IMAGE_URL_KEY        "url"
#define NATIVE_RESPONSE_ASSET_IMAGE_WIDTH_KEY      "w"
#define NATIVE_RESPONSE_ASSET_IMAGE_HEIGHT_KEY     "h"
#define NATIVE_RESPONSE_ASSET_DATA_KEY             "data"
#define NATIVE_RESPONSE_ASSET_DATA_LABEL_KEY       "label"
#define NATIVE_RESPONSE_ASSET_DATA_VALUE_KEY       "value"
#define NATIVE_RESPONSE_ASSET_VIDEO_KEY            "video"
#define NATIVE_RESPONSE_ASSET_VIDEO_VASTTAG_KEY    "vasttag"
#define NATIVE_RESPONSE_ASSET_LINK_KEY             "link"
#define NATIVE_RESPONSE_ASSET_LINK_URL_KEY         "url"
#define NATIVE_RESPONSE_ASSET_LINK_FALLBACK_KEY    "fallback"
#define NATIVE_RESPONSE_ASSET_LINK_CLKTRACKER_KEY  "clicktrackers"
#define NATIVE_RESPONSE_ASSET_EXTENSION_KEY        "ext"

// Native Response Key Max Length
//#define MAX_NATIVE_CREATIVE_LEN                    10000
#define NATIVE_TITLE_TEXT_LEN                      64
#define NATIVE_IMAGE_URL_LEN                       1024
#define NATIVE_DATA_LABEL_LEN                      1024
#define NATIVE_DATA_VALUE_LEN                      1024
#define NATIVE_VIDEO_VASTTAG_LEN                   1024
#define NATIVE_LINK_URL_LEN                        1024
#define MAX_CLICK_TRACKERS                         5
#define NATIVE_CLICK_TRACK_LEN                     2048
#define NATIVE_LINK_FALLBACK_LEN                   1024
#define MAX_IMP_TRACKERS                           5
#define NATIVE_IMP_TRACK_LEN                       2048
#define NATIVE_JSTRACKER_LEN                       2048

typedef struct title {
  char text[NATIVE_TITLE_TEXT_LEN + 1];
//  extension_t ext;
} title_t;

typedef struct image {
  char img_url[NATIVE_IMAGE_URL_LEN + 1];
  int w;
  int h;
//  extension_t ext;
} image_t;

typedef struct dataAsset {
  char label[NATIVE_DATA_LABEL_LEN + 1];
  char value[NATIVE_DATA_VALUE_LEN + 1];
//  extension_t ext;
} data_t;

typedef struct video {
  char vasttag[NATIVE_VIDEO_VASTTAG_LEN + 1];
} video_t;

typedef struct link {
  char link_url[NATIVE_LINK_URL_LEN + 1];
  char clktracker[MAX_CLICK_TRACKERS][NATIVE_CLICK_TRACK_LEN + 1];
	int num_clk_trackers;
  char fallback[NATIVE_LINK_FALLBACK_LEN + 1];
//  extension_t ext;
} link_t;

typedef struct asset {
  int id;
  int required;
  int type;
  union {
    title_t title;
    image_t image;
    data_t data;
    video_t video;
  } native_asset;
  link_t link;
//  extension_t ext;
  int is_invalid;
} asset_t;

typedef struct native_response_assets_stats {
   int num_invalid_assets;
} native_response_assets_stats_t;

typedef struct native_object {
	int version;
	asset_t *asset_array;
	int num_assets;
	link_t parent_link;
	char imptracker[MAX_IMP_TRACKERS][NATIVE_IMP_TRACK_LEN + 1];
	int num_imp_trackers;
  char jstracker[NATIVE_JSTRACKER_LEN + 1];
//	extension_t parent_ext;
	long int random_clktrack_key;

   native_response_assets_stats_t stats;
} native_object_t;

// Native HTML template macro sustitution
#define MAX_MACROS                  5
#define MAX_MACRO_LEN               48
#define NATIVE_MACRO_COMMON_STRING  "{{PUBMATIC_NATIVE_"
#define MACRO_START                 "{{"
#define COMMON_STRING_LEN           18

// Invalid Object Error Codes
#define NATIVE_ASSETS_IMAGE_URL_NOT_FOUND                41
#define NATIVE_ASSETS_IMAGE_WIDTH_NOT_FOUND              42
#define NATIVE_ASSETS_IMAGE_HEIGHT_NOT_FOUND             43
#define NATIVE_ASSETS_DATA_VALUE_NOT_FOUND               44
#define NATIVE_ASSETS_VIDEO_VASTTAG_NOT_FOUND            45
#define NATIVE_ASSETS_LINK_URL_NOT_FOUND                 46
#define NATIVE_RESPONSE_RECREATE_ERROR                   47

enum macro_id {
   INVALID_MACRO = -1, 
   MACRO_IMAGE, 
   MACRO_TITLE, 
   MACRO_DATA, 
   MACRO_LURL, 
   MACRO_CLICKTRACK_KEY
};

//map of macros
static const char macro_map[MAX_MACROS][MAX_MACRO_LEN] = {
   "{{PUBMATIC_NATIVE_IMAGE}}", 
   "{{PUBMATIC_NATIVE_TITLE}}", 
   "{{PUBMATIC_NATIVE_DATA}}", 
   "{{PUBMATIC_NATIVE_LURL}}", 
   "{{PUBMATIC_NATIVE_CLICKTRACKING_KEY}}"
};

#define CLKTRACK_SUPPORT_START "<script type=\"text/javascript\">if(PubMatic && PubMatic.Native && typeof PubMatic.Native.setInfo == \"function\"){PubMatic.Native.setInfo(\""
#define CLKTRACK_SUPPORT_MID "\",{ectr: false,ctrs: ["
#define CLKTRACK_SUPPORT_END "]});}</script>"

#define NATIVE_IFRAME_SCRIPT_START_WO_HTTP "<iframe name=\"pbeacon\" frameborder=\"0\" allowtransparency=\"true\" hspace=\"0\" vspace=\"0\" marginheight=\"0\" marginwidth=\"0\" scrolling=\"no\"  width=\"0\"  height=\"0\" style=\"position:absolute;top:-20000px;\" src=\""
#define NATIVE_IMG_SCRIPT_START_WO_HTTP "<img name=\"pbeacon\"  width=\"0\"  height=\"0\"  style=\"width:0;height:0;\" src=\""

#define NATIVE_IFRAME_SCRIPT_END "\"> </iframe>"
#define NATIVE_IMG_SCRIPT_END "\" />"

#define MAX_CLK_TRACK_SNIPPET_LEN 5096
#define MAX_IMP_TRACK_SNIPPET_LEN 5096

#define APPEND_NATIVE_STRING(bytes_written, char_ptr, space_left, format, ...)   \
  do { \
    bytes_written = snprintf(char_ptr, space_left, format, ##__VA_ARGS__);    \
    if (bytes_written >= space_left) {                      \
      fprintf(stderr, "\nERROR buffer overflow while appending native imp tracker/clk tracker %s:%d\n", __FILE__, __LINE__); \
      return ADS_ERROR_BUFFER_OVERFLOW;                                        \
    } \
    space_left -= bytes_written;                        \
    char_ptr += bytes_written; \
  } while(0);

void print_parsed_native_object(const native_object_t *parsed_native_object);

void init_native_resp_object(native_object_t *native_obj);

int native_response_parser(const char *json_creative, native_object_t *parsed_native_object);

int append_native_imp_trackers(char **native_creative, native_object_t *parsed_native_object, int beacon_tracking_type);

int append_native_clk_trackers(char **native_creative, native_object_t *parsed_native_object);

void apply_native_macro_substitution(char **adscript, char *native_html_template, native_object_t *parsed_native_object);

void free_native_response(native_object_t *parsed_native_object);

int repair_json_response(char *json_creative, native_object_t *native_obj);

#endif
