/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef KEY_VALUE_H
#define KEY_VALUE_H   

#define STRING_TOKEN_ALLOC_SIZE 5

typedef struct key_value {
	struct key_value *next;
	char *key;
	void *value;
	unsigned int value_size;
} key_value_t;

typedef struct key_value_list {
	key_value_t *list_head;
	int nelements;
} key_value_list_t;

int add_to_kv_list(
		key_value_list_t *kvlist,
		char *key,
		void *value,
		unsigned int value_size);

int get_from_kv_list(
		key_value_list_t *kvlist,
		char *key,
		void **value,
		unsigned int *value_size);

void init_kv_list(
		key_value_list_t *kvlist);

void free_kv_list(
		key_value_list_t *kvlist);

/* gives interger array from source string by separating with separtor */
int get_token_integer_data_in_string(int *data, int *nelements, char *string,char *separator); 

/* gives string token from source string by separating with separtor */
int get_token_data_in_string(char ***out_string, int *nelements, char *string,char *separator); 


/* free all the strings in given pointeri array and then pointer it self */
int free_data_in_string(char **string_data,int nelements ); 

//manish porting.
int get_between_token_data_in_string(char ***, int *, char *, char *, char *);

int get_between_token_integer_data_in_string(int *, int *, char *, char *, char *);
//~manish porting.

#endif /* KEY_VALUE_H */
