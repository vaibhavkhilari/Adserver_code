/*
PubMatic Inc. ("PubMatic") CONFIDENTIAL
Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of
PubMatic. The intellectual and technical concepts contained herein are
proprietary to PubMatic and may be covered by U.S. and Foreign Patents,
patents in process, and are protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is
strictly forbidden unless prior written permission is obtained from PubMatic.
Access to the source code contained herein is hereby forbidden to anyone
except current PubMatic employees, managers or contractors who have executed
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended
publication or disclosure of this source code, which includes information
that is confidential and/or proprietary, and is a trade secret, of PubMatic.
ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC
DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN
CONSENT OF PubMatic IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE
AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
THAT IT MAY DESCRIBE, IN WHOLE OR IN PART. 
*/

#ifndef FRA_RECOVERY_H
#define FRA_RECOVERY_H

#include "fra_metrics.h"
#include "fte_types.h"
#include "rt_types.h"
#include "libstats_util.h"
#include "fte_util.h"
#include "adserver_control_parameter_cache.h"
/* Data Structures
 * ===============
 */

/* fra_modes_t
 * -----------
 * Modes that are enabled.
 */
typedef enum {
        // FRF_DISCOUNT_ENABLED = 1,
        FRA_RECOVERY_DRY_RUN = 1,
        FRA_ENABLED,
        FRA_PUB_MARGIN_RECOVERY_ENABLED,
        FRA_PUB_MARGIN_RECOVERY_DRY_RUN_ENABLED,
} fra_modes_t;


/* Functions
 * =========
 */

// See the ``.c`` file for static function declarations.

/* fra_read_start_metrics
 * ----------------------
 * Get a read-only copy of the FRA metrics corresponding to ``pub_id``,
 * ``camp_id`` pair.
 * This is called at the start of the auction to fetch a static, read-only
 * value of the FRA metrics.
 * Returns:
 *   - ADS error codes
 *   - ``out_metrics``: A read-only copy of the FRA metrics corresponding to
 *     ``pub_id``, ``camp_id`` pair, with:
 *     ``out_metrics->occupied == 1`` if valid  OR
 *     ``out_metrics->occupied == 0`` if otherwise
 */
int fra_read_start_metrics(
        unsigned long pub_id,
        unsigned long camp_id,
        double floor_reduction_factor,
        fra_modes_t recovery_algorithm_enabled,
        int recovery_factor,
        fra_metrics_t * const out_metrics
);

/* fra_should_apply_fra
 * --------------------
 * Determines whether to apply FRA.  It contains checks that are the common
 * denominator to discount and recovery.
 * Call it before operations that are used in both discount and recovery
 * (e.g. ``fra_read_start_metrics``).
 * Returns:
 *  True if FRA should be applied  OR
 *  False otherwise
 */
int fra_should_apply_fra(
        const fra_metrics_t * metrics,
        double floor_reduction_factor,
        fra_modes_t recovery_algorithm_enabled,
        int recovery_factor
);

/* fra_should_apply_discount
 * -------------------------
 * Determines whether discount should be applied.
 * It does not read the latest value from the FRA Metrics List.
 * Call it before performing price calculations for applying discount.  
 * Returns:
 *   - True: if discount should be applied
 *   - False: otherwise
 */
int fra_should_apply_discount(
        const fra_metrics_t * metrics,
        double floor_reduction_factor,
        fra_modes_t recovery_algorithm_enabled,
        int recovery_factor,
        double discount_limit
);

/* fra_should_apply_recovery
 * -------------------------
 * Determines whether recover should be performed.
 * It does not read the latest value from the FRA Metrics List.
 * Call it before performing price calculations for applying recovery.
 * Returns:
 *   - True: if recovery should be applied
 *   - False: otherwise
 */
int fra_should_apply_recovery(
        const fra_metrics_t * metrics,
        double floor_reduction_factor,
        fra_modes_t recovery_algorithm_enabled,
        int recovery_factor,
        int recovery_limit
);

/* fra_add_discount
 * ----------------
 * Add ``discount_amount`` to the discount sum.
 * Precondition: Caller is responsible for ``fra_should_apply_discount`` checks.
 * Returns:
 *   - ADS error code
 */
int fra_add_discount(
        unsigned long pub_id,
        unsigned long camp_id,
        double discount_amount,
        long int discount_impr
);

/* fra_add_recovery
 * ----------------
 * Add ``recovery_amount`` to the recovery sum.  If the recovery sum exceeds
 * ``recovery_limit``, perform a balance recovery.
 * Precondition: Caller is responsible for ``fra_should_apply_recovery`` checks.
 * Returns:
 *   - ADS error code
 */
int fra_add_recovery(unsigned long pub_id, unsigned long camp_id,
                double recovery_amount, double recovery_limit);

/* fra_apply_recovery
 * ------------------
 * Implements the auctioning algorithm for FRA Recovery.
 * Returns:
 *   - ADS Error codes
 * TODO: Debugs everywhere
 */
int fra_apply_recovery(
				selected_campaign_attribute_t* selected_camp,
        const publisher_site_ad_campaign_list_t * win_camp,
        fra_modes_t recovery_algorithm_enabled,
        int recovery_factor,
        int pub_recovery_percent,
        int recovery_threshold,
        int pub_id,
        const fra_metrics_t * metrics
);

/* fra_apply_discount
 * ------------------
 * Implements the discounting as applicable.
 * Returns:
 *   - final publisher_ecpm, closing_price, pubmatic_cut
 */
void fra_apply_discount(const publisher_site_ad_campaign_list_t *adcampaigns,
		ad_server_additional_params_t *additional_parameters,
		fte_additional_params_t *fte_additional_params,
		selected_campaign_attribute_t* selected_cam_attr,
		cache_handle_t *cache);

#endif  // FRA_RECOVERY_H
