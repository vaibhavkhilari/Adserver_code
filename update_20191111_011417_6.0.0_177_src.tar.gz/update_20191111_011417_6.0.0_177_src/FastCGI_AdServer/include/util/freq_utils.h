/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __FREQ_UTILS_H__
#define __FREQ_UTILS_H__

#define NETWORK_FRWQUENCY_ALLOC_SIZE 5
#define MAX_FREQ_VAR_NAME_LEN 200
#define MAX_FREQ_VAR_VALUE_LEN 200

#define MAX_FREQ_NETWORKS_IN_SITE 64

typedef struct adid_repeatation {
	long ad_id;
	int repeate_count;
}adid_repeatation_t;

/* free the network frequency list */
void free_net_freq_list(net_frequency_t *net_freq_list);
 
/* gives the list of adnetworks whose frequency quota is complete */
int get_network_frequencies(int *network_to_eliminate,
			int *nelimination_network, 
			int *db_freq_network_list,
			int *ndb_freq_networks,
			net_frequency_t *total_netfreq,
			int *ntotal_netfreq,
			FCGX_Request request,
			cache_handle_t *cache_handle, 
			db_connection_t *dbconn,
			ad_server_req_param_t *params,
			ad_server_req_gen_param_t *gen_params,
			string_scrach_buffer_t *tmp_cookie_buff);

/* inpot to this fuction will be a list of strings like "12-1:2-4:4-4" and output will be a strcure with values {{12,1},{2,4}{4,4}} */
int get_cookie_network_frequencies(net_frequency_t *net_freq, 
				int *nelements, 
				char string_data[][MAX_STRING_LIST_ELEMENT_LENGTH + 1], 
				int ncookie_elements);

/* gives networks with their possible frequency before current adtag request at page load time */
int get_current_pageload_freq_prediction(net_frequency_t *predicted_netfreq, 
					int *nelements, 
					cache_handle_t *cache_handle, 
					db_connection_t *dbconn, 
					FCGX_Request request, 
					ad_server_req_param_t *params);

int get_network_frequencies_cs(int *network_to_eliminate,
		int *nelimination_network,
		int *db_freq_network_list,
		int *ndb_freq_networks,
		net_frequency_t **db_netfreq_list,
		int *ndb_netfreq_list,
		net_frequency_t *total_netfreq,
		int *ntotal_netfreq,
		cache_handle_t *cache_handle,
		db_connection_t *dbconn,
		ad_server_req_param_t *params,
		net_freq_data_t *nfreq_data);

int set_network_frequency_data_cs(CURL* spug_curl_handle,
				net_frequency_t *db_nfreq,
				int db_nfreq_elements,
				net_frequency_t *nfreq,
				int nfreq_elements,
				int site_id,
				int net_id,
				char *partner_uid,
				char cookie_store_url[]);

int get_network_frequency_expiry(net_frequency_t *db_nfreq,
				int db_nfreq_elements,
				net_frequency_t *nfreq,
				int nfreq_elements,
				time_t *expiry,
				int net_id);

int get_network_freq_update_url(net_frequency_t *db_nfreq,
				int db_nfreq_elements,
				net_frequency_t *nfreq,
				int nfreq_elements,
				int site_id,
				int net_id,
				char *partner_uid,
				int secure,
				int client_call,
				char cookie_store_url[]);

bool is_fcap_update_required(long winning_adserver_id,
                             int * db_netfreq_list,int ndb_netfreq_list);
int apply_fcap_first_phase(int * frequency_flag, int *campaign_frequency_flag,
                           fte_additional_params_t *fte_additional_parameters,
                           ad_server_additional_params_t *additional_params,
                           FCGX_Request *request,string_scrach_buffer_t *tmp_cookie_buffer,
                           int * db_freq_network_list,int *ndb_freq_networks,
                           net_frequency_t * total_frequencies,int *ntotal_freq,
                           cache_handle_t *cache_handle,db_connection_t *dbconn,
                           ad_server_req_param_t *params,ad_server_req_gen_param_t *gen_params,
                           net_frequency_t **db_netfreq_list,int *ndb_netfreq_list);

#endif /* __FREQ_UTILS_H__ */
