/*
   PubMatic Inc. ("PubMatic") CONFIDENTIAL
   Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/



#ifndef __PARALLEL_CURL_CALLS_H__
#define __PARALLEL_CURL_CALLS_H__   

#include <curl/curl.h>
#include <stdio.h>
#include "get_user_audience_info.h"
#include "audience_targeting_util.h"
#include "rtb_util.h"
#include "cookie_store_util.h"
#include "ad_server_types.h"
#include "db_connection.h"
#include "error.h"
#include "dp_properties.h"
#include "dp_generic.h"
#include "dp_error.h"
#include "mobile_debug.h"
#include "mobile_header.h"
#include "fetch_cookie_from_store.h"
#include "libstats_util.h"
#include "url_categorization.h"
#include "audience_stat_aggregation.h"
#include "prebid_fraud_check_curl.h"


#define MAX_CONNETION_POOL_SIZE 10

typedef struct curl_params_populate
{
	rpug_memory_struct_t rpug_chunk;
	floor_rpug_memory_struct_t floor_rpug_chunk;
	memory_struct_t audience_chunk;
	wurfl_curl_data_t wurfl_chunk;
	dp_response_params_t dp_response_params[MAX_DP_COUNT];
	integral_curl_data_t integral_chunk;
	prebid_fraud_check_curl_data_t prebid_fraud_check_chunk;
}curl_params_populate_t;

typedef struct curl_handles_added
{
	int rpug_added;
	int floor_rpug_added;
	int audience_handle_added;
	int wurfl_handle_added;
	int dp_handle_added;
	int integral_handle_added;
	int prebid_fraud_check_handle_added;
}curl_handles_added_t;

int initialise_all_curl_handles(CURL **floor_rpug_curl_handle,
		CURL **rpug_curl_handle,
		CURL **audience_curl_handle,
		CURL **wurfl_curl_handle,
		CURL **integral_curl_handle,
		CURL **prebid_fraud_check_curl_handle,
		CURLM **multi_curl_handle,
		curl_handles_added_t *curl_handles_added);

int add_rpug_to_multi_handle(CURLM *multi_curl_handle,CURL *rpug_curl_handle,
		rpug_memory_struct_t *rpug_chunk,
		const char *partner_uid,
		int partner_id,
		int site_id,int *rpug_added);

int add_floor_rpug_to_multi_handle(CURLM *multi_curl_handle,CURL *floor_rpug_curl_handle,
		floor_rpug_memory_struct_t *floor_rpug_chunk,
		const char *pubmatic_uid,
		int site_id,int *floor_rpug_added);


int add_audience_to_multi_handle(CURLM *multi_curl_handle,CURL *audience_curl_handle,memory_struct_t *audience_chunk,const char *audience_url, const char *user_guid, const char *user_ip, int *audience_handle_added);

int add_wurfl_to_multi_handle(CURLM *multi_curl_handle,CURL *wurfl_curl_handle, 
		wurfl_curl_data_t *wurfl_chunk,
		wurfl_stats_t *wurfl_stats,
		const char *browser_name,ad_server_req_param_t *out_params, 
		int *wurfl_handle_added);

int add_dp_to_multi_handle(CURLM *multi_curl_handle,dp_response_params_t *dp_resp_params,
		dp_config_t *dp_config,dp_request_params_t *dp_req_params,
		ad_server_req_param_t *in_req_params,int max_dp_count, int *dp_handle_added);

int add_integral_to_multi_handle(CURLM *multi_curl_handle,CURL *integral_curl_handle,
		const ad_server_req_param_t *out_params,
		integral_curl_data_t *integral_chunk,
		integral_data_t *integral_data,
		varnish_stats_t *varnish_stats,
		int *integral_handle_added,
		int level);

int do_multi_perform_request(CURLM *multi_curl_handle, 
		curl_params_populate_t *curl_params_val,
		float *user_floor_value,int *default_site_flag,
		void **user_segment_list_refrence,ad_server_req_param_t *out_params,wurfl_stats_t *wurfl_stats,
		dp_config_t *dp_config,dp_request_params_t *dp_request_params,dp_response_params_t *dp_resp_params,int max_dp_count,
		integral_data_t *integral_data,
		prebid_fraud_check_data_t *prebid_fraud_check_data,
		curl_handles_added_t curl_handles_added,
		ad_server_additional_params_t *additional_params,
		int *wurfl_data_found_in_cache,
		int *generic_wurfl_data_parser_enabled_flag,
		char *md5_ua, cache_handle_t *cache, audience_stats_counter_t *audience_stats);

int add_prebid_fraud_check_to_multi_handle(CURLM *multi_curl_handle,
		CURL *prebid_fraud_check_curl_handle,
		char *ip_address,
		const ad_server_req_param_t *out_params,
		char *user_agent,
		prebid_fraud_check_curl_data_t *prebid_fraud_check_chunk,
		prebid_fraud_check_data_t *prebid_fraud_check_data,
		int *prebid_fraud_check_handle_added);

int remove_all_handles_from_multi(CURL *floor_rpug_curl_handle,
		CURL *rpug_curl_handle,
		CURL *audience_curl_handle,
		CURL *wurfl_curl_handle,
		CURL *integral_curl_handle,
		CURL *prebid_fraud_check_curl_handle,
		CURLM *multi_curl_handle,
		curl_handles_added_t *curl_handles_added);

void remove_multi_handle(CURLM **multi_curl_handle);

#endif
