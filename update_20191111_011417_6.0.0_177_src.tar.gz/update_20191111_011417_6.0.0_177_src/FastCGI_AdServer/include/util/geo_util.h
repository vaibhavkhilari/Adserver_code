/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef GEO_UTIL_H
#define GEO_UTIL_H

#include <GeoIP.h>
#include <GeoIPCity.h>
#include "ad_server_types.h"
#include "na_db_wrapper.h"

#define NETACUITY_USE_MM_FILE	1	// use memory mapped file flag
#define NETACUITY_EDGE_FC_CODE	4	// edge db feature code
#define NETACUITY_MC_FC_CODE	24	// mobile carrier feature code

int __initGeoIP(char * custom_dir, const char*, GeoIP **gi);
int freeGeoIP(GeoIP *g_geoip_handle);
int initGeoIP(GeoIP **g_geoip_handle);
int initISPhandle(GeoIP **isp_handle, const char* file_path);
int init_net_speed_handle(GeoIP** isp_handle, const char* file_path);

int get_geo_data(GeoIP *g_geoip_handle, geo_data_t *gd, char *host);
int get_isp(GeoIP* isp_handle, const char* host, char* isp_name, int len);
int get_connection_id(GeoIP* net_speed_handle, const char* host, char* conn_name, int len);

/*multi geo support*/
int compare_geo_data_by_level(const ad_geo_settings_t settings, geo_data_t *gdata, int level);
int get_geo_level_wise_list(const ad_geo_settings_t *src_list, geo_data_t *gdata, int nelements, int level, int *geo_list);

/*wrapper for geo at the tracker side*/
int get_geo_from_country_map(GeoIP *g_geoip_handle, geo_data_t *gd, char *host);
//kartik_porting
//static int get_geo_id_by_code(char *code);
int get_geo_id_by_code(char *code);
//~kartik_porting

void _GeoIP_setup_dbfilename();
//manish porting.

// NETACUITY FUNCTIONS
int initGeoNetAcuityClient(NetAcuityClient** na_client, const char* netacuity_database_dir);
int initMCNetAcuityClient(NetAcuityClient** na_client, const char* netacuity_database_dir);

int freeGeoNetAcuityClient(NetAcuityClient* na_client);
int freeMCNetAcuityClient(NetAcuityClient* na_client);

int get_na_geo_data(NetAcuityClient* na_client, geo_data_t *gd, char *host);
int get_na_isp(NetAcuityClient* na_client, const char* host, char* name, int len, const char* country_code);
int get_na_connection_id(NetAcuityClient* na_client, const char* host, char* name, int len);
int get_na_geo_from_country_map(NetAcuityClient* na_client, geo_data_t *gd, char *host);

void convert_to_lowercase(char* src);
void convert_to_uppercase(char *src);
void free_geo_id_blocklist(geo_id_blocklist_t* geo_id_blocklist);
#endif /* GEO_UTIL_H */
