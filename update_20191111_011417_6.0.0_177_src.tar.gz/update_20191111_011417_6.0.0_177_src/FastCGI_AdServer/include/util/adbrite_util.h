/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */



#ifndef ADBRITE_UTIL_H
#define ADBRITE_UTIL_H   

#define ADBRITE_BANNER_WIDTH 468
#define ADBRITE_BANNER_HEIGHT 60
#define ADBRITE_LEADERBOARD_WIDTH 728
#define ADBRITE_LEADERBOARD_HEIGHT 90

#define ADBRITE_SKYSCRAPER_WIDTH 120
#define ADBRITE_SKYSCRAPER_HEIGHT 600
#define ADBRITE_WIDESKYSCRAPER_WIDTH 160
#define ADBRITE_WIDESKYSCRAPER_HEIGHT 600

#define ADBRITE_MEDIUMRECT_WIDTH 300
#define ADBRITE_MEDIUMRECT_HEIGHT 250


/* SIZES FOR BANNER AND LEADERBOARD  */
#define BANNER_URADHERE_WIDTH 11
#define BANNER_URADHERE_HEIGHT 60
#define LEADERBOARD_URADHERE_WIDTH 14
#define LEADERBOARD_URADHERE_HEIGHT 90



#define ADBRITE_START_COMMENT "<!-- Begin: AdBrite -->"
#define SCRIPT_START "<script type=\"text/javascript\">"
#define SCRIPT_END "</script>"
#define ADBRITE_SCRIPT_END "<!-- End: AdBrite -->\n"
#define ADBRITE_AD_SCRIPT_START "<script src=\"http://ads.adbrite.com/mb/text_group.php?"
#define ADBRITE_AD_SCRIPT_END " type=\"text/javascript\"></script> "

#define ADBRITE_SID "sid="
#define ADBRITE_OPID "opid="

#define ADBRITE_LBandBANNER_URADHERE_START "<a target=\"_top\" href=\"http://www.adbrite.com/mb/commerce/purchase_form.php?"
#define ADBRITE_LBandBANNER_URADHERE_MID_START "&afsid=1\">"
#define ADBRITE_LBandBANNER_URADHERE_IMAGE_NAME	"<img src=\"http://files.adbrite.com/mb/images/"
#define ADBRITE_LBandBANNER_URADHERE_MID_END "style=\"background-color:#FFFFFF\" alt=\"Your Ad Here\" "

#define ADBRITE_LEADERBOARD_IMG_NAME "adbrite-your-ad-here-leaderboard.gif"
#define ADBRITE_BANNER_IMG_NAME "adbrite-your-ad-here-banner.gif"

#define ADBRITE_LBandBANNER_URADHERE_WIDTH		" width=" 
#define ADBRITE_LBandBANNER_URADHERE_HEIGHT		" height="
//#define ADBRITE_LBandBANNER_URADHERE_END		" border=\"0\" /></a>"
#define ADBRITE_LBandBANNER_URADHERE_END		"</a>"

#define ADBRITE_SKYSCRandMEDIUM_URADHERE_START "<div><a target=\"_top\" href=\"http://www.adbrite.com/mb/commerce/purchase_form.php?"
#define ADBRITE_SKYSCRandMEDIUM_URADHERE_END "&afsid=1\" style=\"font-weight:bold;font-family:Arial;font-size:13px;\">Your Ad Here</a></div>"

#define ADBRITE_COLOR_BORDER  "\tvar AdBrite_Border_Color = "
#define ADBRITE_COLOR_BG  "\tvar AdBrite_Background_Color = "
#define ADBRITE_COLOR_LINK  "\tvar AdBrite_Title_Color = "
#define ADBRITE_COLOR_TEXT  "\tvar AdBrite_Text_Color = "
#define ADBRITE_COLOR_URL  "\tvar AdBrite_URL_Color = "

#define ADBRITE_AD_HOST  "adbrite_ad_host="
#define ADBRITE_SPAN_START  "<span style=\"white-space:nowrap;\">"
#define ADBRITE_SPAN_END "</span>"

#define ADBRITE_AD_SCRIPT_MAX_SIZE	8192
#define ADBRITE_TMP_BUFF_SIZE		2048

char *get_adbrite_adscript(int width,
			int height,
			char *border_color,
			char *bg_color,
			char *link_color,
			char *url_color,
			char *text_color,
			char *channel_id);

char *get_adbrite_adscript_without_color(int width,
			int height,
			char *channel_id);

#endif /* ADBRITE_UTIL_H */
