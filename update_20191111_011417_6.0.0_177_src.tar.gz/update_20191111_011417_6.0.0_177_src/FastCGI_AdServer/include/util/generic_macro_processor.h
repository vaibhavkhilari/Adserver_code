/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __GENERIC_MACRO_PROCESSOR__H_
#define __GENERIC_MACRO_PROCESSOR__H_

#include "property.h"
#include "key_value.h"
#include "error.h"
#include "config.h"
#include "ad_server_types.h"
#include "rt_types.h"
#include "adserver_common_util.h"
#include "click_util.h"

#define ADSERVER_MACRO_CONFIG_FILE "/etc/adserver.macro.properties"

#define MACRO_LIST_ALLOC_SIZE 5

#define MACRO_COMMENT_CHAR '/'

#define CACHE_BUSTER_MACRO "INTERNAL_CACHE_BUSTER"
#define CLICK_TRACK_MACRO "INTERNAL_CLICK_TRACK"
#define ENCODED_CLICKURL_MACRO "INTERNAL_ENCODED_CLICK_TRACK"
#define DEF_HANDLING_MACRO "INTERNAL_DEF_URL"
#define DEF_IFRAME_HANDLING_MACRO "INTERNAL_IFRAME_DEF_URL"
#define PMOPTOUT_MACRO "INTERNAL_PMOPTOUT"
#define PAGEURL_ENCODED_MACRO "INTERNAL_PAGEURL_ENCODED"
#define COPPA_MACRO "INTERNAL_COPPA"
#define PM_USER_ID "INTERNAL_PM_USER_ID"
#define PUBLISHER_USER_ID_MACRO "INTERNAL_PUBLISHER_USER_ID"
#define WIN_AD_WIDTH_MACRO "kadwidth"
#define WIN_AD_HEIGHT_MACRO "kadheight"

//These IDs will be used at the time of macro substitution

enum macro_id_enum {
	PMOPTOUT_MACRO_ID = 1,
	COPPA_MACRO_ID,
	CACHE_BUSTER_MACRO_ID,
	CLICK_TRACK_MACRO_ID,
	ENCODED_CLICKURL_MACRO_ID,
	DEF_HANDLING_MACRO_ID,
	DEF_IFRAME_HANDLING_MACRO_ID,
	PAGEURL_ENCODED_MACRO_ID,
	PUBLISHER_USER_ID,
	WIN_AD_WIDTH_MACRO_ID,
	WIN_AD_HEIGHT_MACRO_ID,
	OTHER_MACRO_ID
};

#define CLICK_TRACK_MACRO_FLAG 1
#define ENCODED_CLICKURL_MACRO_FLAG 2

#define MAX_DEFAULT_URL_LENGTH 2048
#define MAX_KADNETWORK_PARAM_LENGTH 30

struct macro_position{
                int macro_index;
                int offset;
};
#define INITIAL_MACRO_POS_SIZE_MULTI_FACTOR 2
#define MACRO_POS_SIZE_MULTI_FACTOR 2
#define PREPEND_IF_NOT_EXIST 1
#define DONT_PREPEND_IF_NOT_EXIST 0

/*parse config file for macros*/
int get_macro_list_from_config_properties(char *filename,property_list_t **conf_properties);

/*function to poplulate macro list from property file -- called once in main thread or on reload*/
int getAdServerMacroList(adserver_macro_variable_name_list_t *macro_list);

/*read query string and fetch values for macros*/
int setValuesForAdServerMacroList(adserver_macro_variable_name_list_t *macro_list, char *query_string);

/*free macro list elements*/
int free_adserver_macro_variable_name_list(adserver_macro_variable_name_list_t *macro_list);

/*search for list of macros and replace it with corressponding value in adscript*/
int replace_adserver_macros_in_adscript(char *adcode, char* adscript, adserver_macro_variable_name_list_t *macro_list);

/*search for list of cache busting macros and replace it with random number in adscript*/
int replace_cache_buster_macros_in_adscript(char *adcode, char* adscript, long int random,adserver_macro_variable_name_list_t *macro_list);

/*search for list of click tracking macros and replace it with click track url in adscript*/
int replace_click_track_macros_in_adscript(char *adcode, char* adscript, adserver_macro_variable_name_list_t *macro_list, char *encoded_clickdata);

int __generate_new_query_string_for_defaults(char *new_query_string, char *query_string, int adserver_id);

/*optimized utility function to modify query string to form def url*/
int generate_new_query_string_for_defaults_new(char *default_url, char *query_string, int adserver_id);

/*function to apply all the macros supported*/
int apply_macro_substitution_to_adscript_new(selected_compaign_context_t *selected_camp_cntx, int selected_camp_idx, ad_server_req_param_t *in_req_params, char *query_string, cache_handle_t *cache_handle, ad_server_additional_params_t *additional_params, publisher_site_ad_t *site_ad, char *ad_server_domain_name, ad_server_req_gen_param_t *in_gen_params);
void display_macro_list(adserver_macro_variable_name_list_t *);

int __generate_new_query_string_for_iframe_defaults(char *new_query_string, char *query_string, int adserver_id);

/*optimized utility function to form iframe def url from def url*/
int generate_new_query_string_for_iframe_defaults_new(char *default_iframe_url, char *default_url);

/*
* function to prepare strings for click track macro replacement
* the purpose of this function is to populate click_url and enc_click_url
*/
int prepare_click_urls(selected_compaign_context_t *selected_camp_cntx, int selected_camp_idx, publisher_site_ad_t *site_ad,ad_server_additional_params_t *additional_params,  ad_server_req_gen_param_t *in_gen_params, char * click_url , char * enc_click_url);

/*search for list of macros and replace it with value in adscript depending on its type*/
int replace_all_macros_in_adscript(     char *adcode,//desc adcode
					char* adscript,//source adscript
					adserver_macro_variable_name_list_t *macro_list,//list of macros to be replaced
					int optout,//optout integer to be placed for PMPOPTOUT macro
					long int random,//random number to be placed for RANDOM_NUMBER
					char *default_iframe_ad_request_url,//to be placed for DEF_IFRAME_HANDLING_MACRO
					char *default_ad_request_url,//to be placed for DEF_HANDLING_MACRO
					char *click_url,//to be placed for CLICK_TRACK_MACRO
					char *enc_click_url,//to be placed for ENCODED_CLICKURL_MACRO
					ad_server_req_param_t *in_req_params,
					selected_campaign_attribute_t* selected_camp,
					ad_server_additional_params_t *additional_params);
/*
 *this function will replace 'param=*&' by 'key_value_str' from 'query_string' and form new string in 'new_query_string'
 * new_uery_string - dest string
 * query_string - source string
 * param - key to be replaced from query string
 * key_value_str - key value pair that must be put as a replacement for param
 * key_value_length - max length of key_value_str
 * append_if_not_exist - whether to append key_value_str to query_string if param is not found in query_string
 */
int __replace_param_from_query_string(  char *new_query_string,
					char *query_string,
					const char * param ,
					char * key_value_str ,
					int key_value_length ,
					int append_if_not_exist);

int replace_pm_user_id_macros_in_script(char* adcode, char* adscript, char* userId, adserver_macro_variable_name_list_t *macro_list);
#endif /*__GENERIC_MACRO_PROCESSOR__H_*/
