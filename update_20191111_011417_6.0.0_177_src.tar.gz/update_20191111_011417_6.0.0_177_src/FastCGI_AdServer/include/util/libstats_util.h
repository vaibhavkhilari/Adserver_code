/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __STATS_UTIL__
#define __STATS_UTIL__

#include "rt_types.h"

//Associate integer id to each of the stats key
enum STATS_KEYS {
	RTB_REQUESTS_ID,
	RTB_TIMED_OUT_ID,
	RTB_ZERO_BID_ID,
        RTB_NON_ZERO_BID_ID,
	RTB_FILTER_RMCF_ID, //Richmedia creative filters (rca, rct, rsb)
	RTB_FILTER_CREATIVE_ID_NA_ID,
	RTB_FILTER_CREATIVE_ID_BLOCKED_ID,
	RTB_FILTER_BID_PRICE_DECRYPTION_FAILURE_ID,
	RTB_WINNING_BID_ID,
	RTB_ERROR_RESPONSES_ID,
	RTB_BIDDER_TIMED_OUT_ID,
	RTB_BIDDER_DSP_CONN_UNAVAILABLE_ID,
	RTB_BIDDER_REQUESTS_ID,
	RTB_ABNORMAL_ECPM_ID,
	FILTERED_CAMPAIGN_ID,
	RTB_NEW_CONNECTION_ID,
	RTB_CONNECTION_REUSED_ID,
	RTB_SKIPPED_REQUESTS_ID,
	FTE_MARGIN_FILTERED_ADFLEX_CAMPAIGNS_ID,
	RTB_LANDING_PAGE_FILTER_ID,
	RTB_DEAL_WHITE_LIST_FILTER_ID,
	RTB_ADVERTISER_DOMAIN_FILTER_ID,
	RTB_FLOOR_FILTER_ID,
	RTB_DSP_FLOOR_FILTER_ID,
	RTB_ADVERTISER_FLOOR_FILTER_ID,
	RTB_DSP_ADVERTISER_FLOOR_FILTER_ID,
	RTB_MAX_DSP_FLOOR_ID,
	RTB_MAX_ADVERTISER_FLOOR_ID,
	RTB_MAX_DSP_ADVERTISER_FLOOR_ID,
	RTB_FLOOR_ERROR_ID,
	FTE_PUBMATIC_VARIABLE_MARGIN_ID,
	FTE_PUBMATIC_FIXED_CUT_FILTER_ID,
	FTE_ICAP_FILTER_ID,
	FTE_DSP_BLOCKLIST_FILTER_ID,
	RTB_MAX_DEAL_VIOLATION_COUNT_ID,
	AD_SERVING_BLOCKED_REQUESTS_COUNT_ID,
	RTB_BLOCKED_REQUESTS_COUNT_ID,
	RTB_SECOND_PRICE_ID,
	RTB_RICH_MEDIA_ID,
	RTB_F1_FILTER_ID,
	RTB_MUX_REQUESTS_ID,
	RTB_MULTI_ADSIZE_REQUESTS_ID,
	RTB_CAMP_THROTTLE_APPLIED_ID,
	RTB_ATT_APPLIED_ID,
	RTB_GDPR_CAMP_FILTERED_REQ_ID,
	FTE_DOMAIN_THROTTLING_FILTERED_ID,
	FLEXIDRPROXY_DSP_TIMED_OUT_ID,
	FLEXIDRPROXY_DSP_MAX_ROUTINEREACHED_ID,
	FLEXIDRPROXY_DSP_ERROR_ID,
	RTB_CAMP_COOKIED_REQ,
	RTB_CAMP_EIDS_REQ,
	RTB_CAMP_COOKIED_EIDS_REQ,
	RTB_TOTAL_CAMP_COOKIED_REQ,
	RTB_TOTAL_CAMP_EIDS_REQ,
	RTB_TOTAL_CAMP_COOKIED_EIDS_REQ
};

enum STATS_BDRQ {
	BLANK,
	BADRQ,
	IP_BLK,
	SKIPD_IP_BLK,
	FRA,
	RECOV,
	FRA_PAUSE,
	RECOV_PAUSE,
	IMPRESSION,
	A500,
	L500,
	L200,
	L180,
	L150,
	L135,
	L120,
	L110,
	L100,
	L50,
	L20,
	A_RTB_TO_PLUS_20MS,
	L_RTB_TO_PLUS_20MS,
	L_RTB_TO_PLUS_10MS,
	CLIENT_CLOSE,
	BID_PROB_FILTER_APPLIED_COUNT,
	FOUND_PUBMATIC_USERID,
	GDPR_PUB_TOTAL_REQ,
	GDPR_PUB_PM_HAS_CONSENT_REQ,
	GDPR_PUB_BLANK_CONSENT_REQ,
	GDPR_PUB_MALFORMED_CONSENT_REQ,
	GDPR_PUB_NON_GDPR_REGION_REQ,
	GDPR_PUB_CONS_EXP_EMPTY_APPLIED,
	GDPR_PUB_CONS_EXP_PASS_APPLIED,
	INVALID_ADSIZE_REQ,
	TRANSLATOR_TIMEOUT,
	INVALID_SCHAIN_OBJ_REQ,
	VALID_SCHAIN_OBJ_REQ
};

enum CAMP_EIDS_STATS_FLAG {
	CAMP_EIDS_STATS_ENABLE,
	CAMP_PUB_EIDS_STATS_ENABLE
};

enum PUB_EIDS_STATS_FLAG {
	PUB_EIDS_STATS_ENABLE,
	PUB_CAMP_EIDS_STATS_ENABLE
};

/* Collect inpc/distributed cache call miss stats */
#define increment_server_level_stats(stats_counter, stats_key) \
	do { \
		char stats_collection_buffer[MAX_STATS_KEYSIZE]; \
		stats_collection_buffer[0] = '\0'; \
		\
		if(stats_counter >= (g_stats_counter_size*2)) { \
			sprintf(stats_collection_buffer,"%s:%s:%s", stats_key, \
					g_ads_name, \
					g_stats_datacenter_name); \
			\
			stats_add(stats_collection_buffer, stats_counter); \
			stats_counter = 0; \
		} \
	} while(0);

#define MAX_STATS_KEYSIZE 128
		//kartik
#define MAX_ABNORMAL_ECPM_KEYSIZE 256
		//~kartik
	//kartik 29_12_2010
#define MAX_IMPRESSION_STATS_KEYSIZE 1024
#define MAX_FLOOR_ALARM_STATS_KEY_SIZE 128
#define IMPRESSION_BLANK "BLK_IMP"
#define SITE_ICAP_FILTER_KEY "site_icap"
	//~kartik
#define STATSCOLLECTION_CONFIG_FILE	"/etc/stats_collection.properties"
#define STATS_SERVER_NAME "stats.server.name"
#define STATS_SERVER_PORT_NUMBER "stats.port.number"
#define ADSERVERNAME_SERVER_NAME "stats.adserver.name"
#define STATS_SERVER_DATACENTER_NAME "stats.datacenter.name"
#define STATS_COUNTER_SIZE "stats.counter.size"

#define RTB_REQUESTS_KEY "RTB:requests"
#define RTB_MUX_REQUESTS_KEY "RTB:mux_req"
#define RTB_MULTI_ADSIZE_REQUESTS_KEY "RTB:multi_adsize_req"
#define RTB_TIMED_OUT_KEY "RTB:timed_out"
#define RTB_ZERO_BID_KEY "RTB:zero_bid"
#define RTB_NON_ZERO_BID_KEY "RTB:non_zero_bid"
#define RTB_FILTER_CREATIVE_ID_NA_KEY "RTB:creative_filter_crID_NA"
#define RTB_FILTER_CREATIVE_ID_BLOCKED_KEY "RTB:creative_filter_cr_blocked"
#define RTB_FILTER_BID_PRICE_DECRYPTION_FAILURE_KEY "RTB:bid_price_encryption_failure"
#define RTB_WINNING_BID_KEY "RTB:winning_bid"
#define RTB_ERROR_RESPONSES_KEY "RTB:error_response"

#define RTB_BIDDER_TIMED_OUT_KEY "RTB:bidder_timed_out"
#define RTB_BIDDER_DSP_CONN_UNAVAILABLE_KEY "RTB:conn_unavailable"
#define RTB_BIDDER_REQUESTS_KEY "RTB:bidder_requests"
#define REQST_BLANK_KEY "RQST:BLNKS"
#define FRA_APPLIED "FRA"
#define RECOV_APPLIED "REC"
#define FRA_PAUSE_KEY	"FRP"
#define RECOV_PAUSE_KEY "RCP"
#define REQST_BADRQ_KEY "RQST:BADRQS"
#define REQST_IMPR_KEY "RQST:IMPRN"
#define REQST_A500 "RQST:LATNCY"
#define REQST_CLIENT_CLOSE  "RQST:CCLOSE"
#define REQST_L500 "RQST:500LATENCY"
#define REQST_L200 "RQST:200LATENCY"
#define REQST_L180 "RQST:180LATENCY"
#define REQST_L150 "RQST:150LATENCY"
#define REQST_L135 "RQST:135LATENCY"
#define REQST_L120 "RQST:120LATENCY"
#define REQST_L110 "RQST:110LATENCY"
#define REQST_L100 "RQST:100LATENCY"
#define REQST_L50 "RQST:50LATENCY"
#define REQST_L20 "RQST:20LATENCY"
#define REQST_L_RTB_TO_PLUS_10MS "RQST:RTBTOPLUS10MSLATENCY"
#define REQST_L_RTB_TO_PLUS_20MS "RQST:RTBTOPLUS20MSLATENCY"
#define REQST_A_RTB_TO_PLUS_20MS "RQST:ABOVERTBTOPLUS20MSLATENCY"
#define REQST_IP_BLK "RQST:IP_BLK"
#define REQST_SKIPD_IP_BLK "RQST:SKIP"
#define REQST_TRANSLATOR_TIMEOUT "RQST:TRSTO"
//kartik 20_12_2010
#define RTB_ABNORMAL_ECPM "RTB:AECPM" //AECPM = Abnormal ECPM i.e bid price by campaign > ecmp threshold
//~kartik
#define DISTRI_MISS_COUNT_KEY	"DISTRI:MISS"
#define INPC_MISS_COUNT_KEY	"INPC:MISS"
#define RTB_SECOND_PRICE_KEY "RTB:second_price"
#define IMPRESSION_CNT_KEY	"Impressions"
#define INVALID_IMPRESSION_CNT_KEY	"BADRQ"
#define SVR_RESTARTED "SVR:RSTRTD"
#define PUB_CAMP_WINN "win:%ld:%ld:%s"
#define RT_MOB_NETW_FILETERED "RTMNWF"
#define RT_MOB_NETW_REQUESTS "RTMNRQ"
#define RT_MOB_NETW_TIMEOUTS "RTMNWTMT"
#define RT_MOB_NETW_INCOMPLETE_RESPONSE "RTMNWINC"
#define RT_MOB_NETW_PARSE_ERROR "RTMNWPERR"
#define RT_MOB_NETW_NOT_200_OK "RTMNWNT200"
#define RT_MOB_NETW_PARSE_SUCCESS "RTMNWPS"
#define MOB_MISTAKEN_REQ_CNT "MOBMISTKRQCNT"
#define IMPR_TPCNA_CNT_KEY "TPCNA_IMPR" //Third Party Cookie Not Allowed
#define FILTERED_CAMPAIGN_KEY	"RTB:filter_camp"
//
#define RTB_NEW_CONNECTION_KEY	"RTB:new_conn"
#define RTB_CONNECTION_REUSED_KEY	"RTB:reused_conn"
#define RTB_SKIPPED_REQUESTS "RTB:RTT"
#define STATS_KEY_BID_PROB_FILTER_APPLIED "FILTER:bpf_applied"
#define FTE_MARGIN_FILTERED_ADFLEX_CAMPAIGNS "FTE:mfil"
#define RTB_LANDING_PAGE_FILTER "RTB:LPF"
#define RTB_DEAL_WHITE_LIST_FILTER_KEY "RTB:DWF"
#define RTB_ADVERTISER_DOMAIN_FILTER "RTB:UCAF"
#define RTB_FLOOR_FILTER_KEY "RTB:floor_filter"
#define RTB_DSP_FLOOR_FILTER_KEY "RTB:dsp_floor_filter"
#define RTB_ADVERTISER_FLOOR_FILTER_KEY "RTB:adv_floor_filter"
#define RTB_DSP_ADVERTISER_FLOOR_FILTER_KEY "RTB:dsp_adv_floor_filter"
#define RTB_MAX_DSP_FLOOR_KEY "RTB:max_dsp_floor"
#define RTB_MAX_ADVERTISER_FLOOR_KEY "RTB:max_adv_floor"
#define RTB_MAX_DSP_ADVERTISER_FLOOR_KEY "RTB:max_dsp_adv_floor"
#define RTB_FLOOR_ERROR_KEY "RTB:floor_error"
#define FTE_PUBMATIC_VARIABLE_MARGIN_KEY "FTE:pubmatic_variable_margin"
#define FTE_PUBMATIC_FIXED_CUT_FILTER_KEY "FTE:pubmatic_fixed_cut_filter"
#define FTE_ICAP_FILTER_KEY	"FTE:icap_filter"
#define FTE_DSP_BLOCKLIST_FILTER_KEY	"FTE:dcpb_filter"
#define RTB_RICH_MEDIA_KEY			"RTB:rich_media"
#define RTB_FILTER_RMCF_KEY     "RTB:rmcf" //rich-media creative filtered
#define RTB_MAX_DEAL_VIOLATION_COUNT	"RTB:max_deal_vc"
#define RTB_F1_FILTER	"RTB:f1_filter"
#define STATS_KEY_RTB_CAMP_THROTTLE_APPLIED "RTB:camp_th_applied"
#define STATS_KEY_RTB_ATT_APPLIED "RTB:camp_att"
#define AD_SERVING_BLOCKED_REQUESTS_COUNT "ADSERVINGBLOCKED:Count"
#define RTB_BLOCKED_REQUESTS_COUNT "RTBBLOCKED:Count"
#define INVALID_BROWSER_FILTER_COUNT "BOT:Browser"
#define BOT_FILTER_COUNT "BOT:Bot"
#define AUD_REQ_KEY "AUD:req"
#define AUD_RES_TO_KEY "AUD:to"
#define AUD_RES_NO_DATA_KEY "AUD:nodata"
#define DCPM_HIGHER_PRICED_IMPRESSIONS "DCPMHPI"
#define DCPM_TOTAL_BALANCE_SAVED "DCPMTBS"
#define DCPM_TOTAL_BALANCE_UTILISED "DCPMTBU"
#define STATS_KEY_SIGSEGV_COUNT "SIGSEGV_COUNT"
//~
//#define MAX_STATS_COUNT 1000


#define RTB_PRICEGOAL_SKIPPED_AS_PMP "RTB:pricegoalskippedrule" 
#define RTB_PRICEGOAL_FILTER_ALL "RTB:pricegoalfiltredall"
#define RTB_PRICEGOAL_APPLICABLE "RTB:pricegoalapplicable"

#define VIDEO_RESPONSE_ERROR "VID:response_error"
#define TRUSTE_CALL_COUNT "TRUSTe:call_count"
#define ADTR_NO_PAYLOAD "ADTR:no_payload"
#define ADTR_DISABLED "ADTR:disabled"
#define ADTR_INVALID_ARGS "ADTR:invalid_args"
#define ADTR_PAYLOAD_MALFORMED "ADTR:malformed_payload"
#define ADTR_ID_GEN_FAILED "ADTR:id_gen_fail"
#define ADTR_NO_MEMORY "ADTR:no_mem"
#define ADTR_ID_GEN_SUCCESS "ADTR:id_gen_succ"

#define AERO_DIRECT_CALL "AERO:direct"
#define AERO_FRPUG_CALL "AERO:frpug"
#define AERO_N_FRPUG_CALL "AERO:n_frpug"
#define UNCONDITIONAL_AERO_DIRECT_CALL "AERO:unconditional"

#define PUID_TOTAL_REQ	"PUID:total_req"
#define PUID_CS_CALLS	"PUID:cs_calls"
#define PUID_CS_MAP_FOUND	"PUID:cs_map_found"
#define PUID_CS_DATA_FOUND	"PUID:cs_data_found"
#define PUID_CS_USERID_MISMATCH "PUID:cs_userid_mismatch"

//stats for userid found in request
#define FOUND_PUBMATIC_USERID_KEY "KUSER:pubm"

/* stats used for GDPR */
#define GDPR_PUB_TOTAL_REQ_KEY "GDPR:TOTREQ"
#define GDPR_PUB_PM_HAS_CONSENT_REQ_KEY "GDPR:PMCREQ"
#define GDPR_PUB_BLANK_CONSENT_REQ_KEY "GDPR:CSBLANK"
#define GDPR_PUB_MALFORMED_CONSENT_REQ_KEY "GDPR:CSFAIL"
#define GDPR_PUB_NON_GDPR_REGION_REQ_KEY "GDPR:NGREG"
#define GDPR_PUB_CNS_EXP_EMPTY_APPLIED_KEY  "GDPR:CEEMPT"
#define GDPR_PUB_CNS_EXP_PASS_APPLIED_KEY   "GDPR:CEPASS"

#define RTB_GDPR_CAMP_FILTERED_REQ_KEY "RTB:GDPRF"
#define FTE_DOMAIN_THROTTLING_FILTERED_KEY "FTE:dom_th_applied"
/*dsp status through flexidrproxy*/
#define	FLEXIDRPROXY_DSP_TIMED_OUT_ID_KEY "FLEXIDSP:TIMEDOUT"
#define	FLEXIDRPROXY_DSP_MAX_ROUTINEREACHED_KEY "FLEXIDSP:MAXROUTINE"
#define FLEXIDRPROXY_DSP_ERROR_KEY "FLEXIDSP:ERROR"

/*Digitrust Stats Keys */
#define STATS_KEY_RTB_CAMP_COOKIED_EIDS_REQ	"RTB:M:EIDSCOOKIE"
#define STATS_KEY_RTB_CAMP_EIDS_REQ	"RTB:M:EIDS"
#define STATS_KEY_RTB_CAMP_COOKIED_REQ	"RTB:M:COOKIED"
#define STATS_KEY_RTB_TOTAL_CAMP_COOKIED_EIDS_REQ	"RTB:EIDSCOOKIE"
#define STATS_KEY_RTB_TOTAL_CAMP_EIDS_REQ	"RTB:EIDS"
#define STATS_KEY_RTB_TOTAL_CAMP_COOKIED_REQ	"RTB:COOKIED"

//schain stat keys

#define INVALID_SCHAIN_STRING_KEY "RQST:INVLSCHAIN"
#define VALID_SCHAIN_STRING_KEY "RQST:VALIDSCHAIN"

//Unable to derive ad_size id stats
#define INVALID_ADSIZE_REQ_KEY "ADSIZE:INVALID"

// Mobile Network Stats Counter
// please update MAX_AD_ID_LEN in ad_server_types.h to a value greater
// than the max value of the below counters
#define RT_MOB_NETW_FILTERED_COUNTER             2
#define RT_MOB_NETW_REQUESTS_COUNTER             3
#define RT_MOB_NETW_TIMEOUTS_COUNTER             2
#define RT_MOB_NETW_INCOMPLETE_RESPONSE_COUNTER  2
#define RT_MOB_NETW_PARSE_ERROR_COUNTER          2
#define RT_MOB_NETW_NOT_200_OK_COUNTER           2
#define RT_MOB_NETW_PARSE_SUCCESS_COUNTER        2

#define RT_MOB_NW_REQ_BUCKET_INDEX        1
#define RT_MOB_NW_TIMEOUT_BUCKET_INDEX    2
#define RT_MOB_NW_INCOMPLETE_BUCKET_INDEX 3
#define RT_MOB_NW_ERROR_BUCKET_INDEX      4
#define RT_MOB_NW_PARSED_BUCKET_INDEX     5
#define RT_MOB_NW_NOT200_BUCKET_INDEX     6
#define RT_MOB_NW_FILTERED_BUCKET_INDEX   7

#define RT_MOB_NW_STATS_FLUSH_HOUR   23
#define RT_MOB_NW_STATS_FLUSH_MIN    55
//
int set_stats_client_config(void);
int get_stats_client_name(void);

extern int increment_impression_count(uint16_t *);
int increment_invalid_impression_count(long ad_id, uint16_t *stats_counter);
extern int increment_impression_TPCNA_count(uint16_t *);
extern int increment_stats_counters(libstat_counters_t *libstat_counters, const int stats_id, long int campaign_id);
int increment_margin_filtered_adflex_campaigns(uint32_t* stats_counter);
int increment_skipped_request_count(uint32_t *);
//kartik 20_12_2010
void send_abnormal_stats(const char* request_id, const char* tx_id, long campaign_id,double campaign_ecpm);
	//~kartik

	//kartik 29_12_2010
void increment_impression_stats(ad_server_additional_params_t* additional_params, const selected_compaign_context_t *selected_camp_cntx, int selected_camp_idx, const ad_server_req_param_t* request_params, const char* param, unsigned int adserver_id, unsigned int ad_size_id);
	//~kartik

void send_rtb_floor_alarm_stats(char param[], long int publisher_id);

void increment_publisher_site_ad_serving_blocked_requests_count(uint32_t *stats_counter);
void increment_publisher_site_rtb_blocked_requests_count(uint32_t *stats_counter);
void increment_dynamic_cpm_stats(dynamic_cpm_stats_t **dcpm_stat, int *dcpm_stats_count, unsigned int campaign_id, double offset, int default_flag);
void increment_video_response_error_count(uint32_t *stats_counter);
void increment_truste_call_count(unsigned int *stats_counter);
int increment_audience_stats_counters(uint32_t *stats_counter, const char* param);

void collect_aerospike_stats(aerospike_call_stats_t *aero_stats,
	const char *stats_key,
	unsigned int *stats_value);

void collect_puid_stats(puid_stats_t *puid_stats, long int pub_id);

int increment_publisher_level_stats_counters(libstats_badrq_counters_t *libstat_counters, int stats_id, long int pub_id);
void increment_bot_filter_count(uint32_t *stats_counter);
void send_pub_camp_stats (long int pub_id ,long int camp_id);
int send_rtb_float_stats (libstat_counters_t *libstat_counters, long int campaign_id, double value);

#define IS_TIME_TO_SEND_STATS(current, last, diff) \
	((current.tv_sec - last.tv_sec) < (long)diff )? 0:1

int flush_adserver_stats(libstat_counters_t *libstat_counters);
void flush_publisher_stats(libstats_badrq_counters_t *libstat_counters);
void increment_bot_filter_count(uint32_t *stats_counter);
void update_wurfl_stats(wurfl_stats_t *wurfl_stats, int type);
void update_prebid_fraud_check_stats(prebid_fraud_check_stats_t *fraud_check_stats, prebid_fraud_check_stats_type_t type);
void update_varnish_stats(varnish_stats_t *varnish_stats, int type, int server_id);
int send_rtb_float_stats(libstat_counters_t *libstat_counters, long int campaign_id, double value);
void send_pub_camp_stats(long int pub_id, long int camp_id);
void send_machine_restarted_stats(void);
void init_adtruth_stats(adtruth_stats_t *adtruth_stats);
void init_aerospike_stats(aerospike_call_stats_t *aero_stats);
void init_puid_stats(puid_stats_t *puid_stats);
void init_prebid_fraud_check_stats(prebid_fraud_check_stats_t *prebid_stats);
void send_pub_level_latency_reports ( libstats_badrq_counters_t *libstat_counters , unsigned long time_diff_in_mis, long publisher_id);
#endif
