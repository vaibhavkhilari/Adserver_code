/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


/*
* PubMatic Inc. (“PubMatic”) CONFIDENTIAL
* Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains the property of PubMatic. The intellectual and technical concepts contained
* herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material is strictly forbidden unless prior written permission is obtained
* from PubMatic.  Access to the source code contained herein is hereby forbidden to anyone except current PubMatic employees, managers or contractors who have executed 
* Confidentiality and Non-disclosure agreements explicitly covering such access.
*
* The copyright notice above does not evidence any actual or intended publication or disclosure  of  this source code, which includes  
* information that is confidential and/or proprietary, and is a trade secret, of  PubMatic.   ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE, 
* OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN CONSENT OF PubMatic IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
* LAWS AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS  
* TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART. 
*/
#ifndef ICAP_UTIL_H
#define ICAP_UTIL_H

#define ICAP_MAX_KEY_LENGTH 100
#define ICAP_FINISHED       -9999
#define ICAP_DOES_NOT_EXIST_IN_LOCAL_MEMCACHE -99999

#define MAX_DC 10
#define MIN_DC 1

/*number of times citrus update will be tried at least before fail*/
#define MAX_ICAP_CITRUS_UPDATE_RETRY 5
/*this will be used by tracker to update impression details and in icap_estimation will not be used by adserver*/
#define DC_SET_NAME_PREFIX "dcid"

/*tracker data may expire in 5 days*/
#define TRACKER_DATA_EXPIRY_TIME 24*60*60*5

/*all key should be more than 5 length*/
#define ICP_FINISHED_KEY_OFFSET 1
#define DYN_QUOTA_KEY_OFFSET 2

#define ESTIMATE_TYPE_KEY_OFFSET 3
#define MAX_ICAP_FOR_DAY_KEY_OFFSET 4
#define START_OF_DAY_KEY_OFFSET 5

typedef enum icap_kv_pair_type_e{
    unknown=0,
    network_icap,
    network_site_size_icap,
    campaign_icap
}icap_kv_pair_type;

typedef struct icap_kv_pair_s{
    char key[ICAP_MAX_KEY_LENGTH + 1];
    long impression_count;
    icap_kv_pair_type icap_type; 
    int key_length;
    /* this will be used to identify the id to minimize char comparision*/
    union{
	long campaign_id;
	long adserver_id;
    };
    char is_checked;
}icap_kv_pair;
typedef enum pacing_mode_e{
    PACING_DISABLED = 0,
    PACING_ENABLED = 1
}pacing_mode;

typedef enum icap_key_type_e{
    UNDEFINED_ICAP_KEY_TYPE = 0,
    CAMPAIGN_KEY,
    CAMPAIGN_IMPRESSION_DETAILS_KEY,
    CAMPAIGN_MAX_DAY_IMPRESSION_KEY,
    CAMPAIGN_DYNAMIC_QUOTA_KEY,
    NETWORK_KEY,
    NETWORK_IMPRESSION_DETAILS_KEY,
    NETWORK_MAX_DAY_IMPRESSION_KEY,
    NETWORK_DYNAMIC_QUOTA_KEY,
    SITE_SIZE_NETWORK_KEY,
    SITE_SIZE_NETWORK_MAX_DAY_IMPRESSION_KEY,
    SITE_SIZE_NETWORK_IMPRESSION_DETAILS_KEY,
    SITE_SIZE_NETWORK_DYNAMIC_QUOTA_KEY
}icap_key_type;
typedef struct network_site_size_details_s{
    long adserver_id;
    long size_id;
    long site_id;
}network_site_size_details;
typedef struct icap_inventory_details_s{
    union {
	network_site_size_details nss_details;
	long campaign_id;
	long adserver_id;
    };
    icap_key_type inventory_type;
}icap_inventory_details;


/*below structure will be saved as it is so please don't add pointer*/
typedef struct impression_details_s{
    long lifetime_impression_served[MAX_DC + 1];/* this will be lifetime impression*/
    long impression_served_today[MAX_DC + 1];/*impression served today*/
}impression_details;

//extern int create_network_site_size_key(int adserver_id,int site_id,int size_id,icap_kv_pair *kv_pair);
//extern int create_campaign_key(int campaign_id, icap_kv_pair *kv_pair);
//extern int create_network_key(int network_id, icap_kv_pair *kv_pair);
extern int init_icap_item_locks();
extern int destroy_icap_item_locks();
extern long icap_item_lock(long item_id);
extern long icap_item_unlock(long item_id);
/*
  impressions_to_serve => [outparam]icap for today
   impressions_to_serve_for_lifetime => input param icap remaining for lifetime
 */
extern int get_impression_for_day_with_pacing(
					      double impression_overdelivery_percentage,
					      long int end_time,long *impressions_to_serve,
					      long impressions_to_serve_for_lifetime);
/*
  This method will return length of the key as output, if return value is 0 it means error
  output param
     out_key => key will be generated and copied here, this need to be allocated already
     max_key_length => max key length
  input param
     icap_inventory_details => details of inventory
     key_type => type of key
*/
extern int create_icap_key(icap_inventory_details *icap_inventory_details, icap_key_type key_type,char* out_key,int max_key_length);
extern int get_tracker_set_name(int datacenter_id,char * key, int max_key_size);
extern void print_imp_details(const char *key,const impression_details *imp_details,const char* caller_name,int line_no);
extern void init_inventory(icap_inventory_details *inventory_details);
extern void init_impdetails(impression_details *imp_details);
extern int init_icap_configuration();
#endif
