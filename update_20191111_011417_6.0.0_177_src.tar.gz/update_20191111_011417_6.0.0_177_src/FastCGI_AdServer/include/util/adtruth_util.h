/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __ADTRUTH__
#define __ADTRUTH__

#include "http/http_header_types.h"

#define MAX_ADTRUTH_PAYLOAD_LEN 2560
#define MAX_USERID_LEN 40
#define MAX_PARTNER_KEY_SIZE 256 //128*2
#define MAX_ADTRUTH_RTB_JSON_LEN	256

#define NO_JSON 0
#define GENERATE_RTB_JSON 1
#define GENERATE_LOGGER_JSON 2

/*
"client": "Pubmatic",
"client_id": "00001651",
"serial": "165116739",
"expiry": "2015-10-31"
*/
#define ADTRUTH_LICENCE "/home/http/FCGI_ADSERVER/Build/deviceinsight-api-cpp-adtruth-4.6.1-2-dist/license_Pubmatic_00001651_165116739.json"
#define ADTRUTH_LOG_DIR "/home/http/FCGI_ADSERVER/Install/Apache2/logs/"

#define RECIPE_UNIVERSAL_4_6_1 "UNIVERSAL_4_6_1"
#define RECIPE_WEB_APP_BRIDGE_4_0 "WEB_APP_BRIDGE_4_0" 

typedef struct adtruth_data {
	char payload[MAX_ADTRUTH_PAYLOAD_LEN + 1];
	int tdl_seconds;
	char adtruth_rtb_json[MAX_ADTRUTH_RTB_JSON_LEN + 1];
	//adtruth id with old recipe
	char old_adtrurh_id[MAX_PARTNER_KEY_SIZE + 1];
	char* adtruth_logger_json;
	int adtruth_logger_json_len;
} adtruth_data_t;

typedef struct adtruth_stats {
	unsigned int truste_call_count;
	unsigned int no_payload_count;
	unsigned int disabled_count;
	unsigned int invalid_args_count;
	unsigned int payload_malformed_count;
	unsigned int id_gen_failed_count;
	unsigned int no_memory_error_count;
	unsigned int id_gen_success_count;
} adtruth_stats_t;


typedef struct aerospike_call_stats {
	unsigned int unconditional_direct_call;
	unsigned int direct_call_count;
	unsigned int frpug_call_count;
	unsigned int n_frpug_call_count;
} aerospike_call_stats_t;

#ifdef __cplusplus
extern "C" {
int nstrcpy(char *dest, const char *src, size_t n);
#endif
void set_server_time(int thread_id);
int set_adtruth_configuration(int ads_thread_count);
int get_adtruth_uid(const int thread_id, adtruth_data_t *in_data, const char *remote_ip_address, const http_header_map_t* header_map, char *adtruth_uid, const int generate_rtb_json_flag);
#ifdef __cplusplus
}
#endif

#ifdef DEBUG_ADTRUTH
#define ADTRUTH_DEBUG(format, ...) fprintf(stderr, "\nUID_LOG::"format, ##__VA_ARGS__)
#else
#define ADTRUTH_DEBUG(format, ...)
#endif /* DEBUG_ADTRUTH */

#endif
