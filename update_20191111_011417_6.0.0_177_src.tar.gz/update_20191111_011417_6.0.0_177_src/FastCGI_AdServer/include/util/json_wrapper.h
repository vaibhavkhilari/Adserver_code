#ifndef __JSON_WRAPPER__H__
#define __JSON_WRAPPER__H__
#include "ad_server_types.h"
#define JSON_OBJECT_START              "{"
#define JSON_OBJECT_END                "}"
#define JSON_ARRAY_START               "["
#define JSON_ARRAY_END                 "]"
#define JSON_KEY_VALUE_SEPARATOR       ":"
#define JSON_QUOTE                     "\""

#define ADD_COMMA    	    	         1
#define DONT_ADD_COMMA        	      0
#define ADD_QUOTE 		               1
#define DONT_ADD_QUOTE	    	         0

#define SIZE_OF_WO_EOF(value)          (sizeof(value)-1)

#define JSON_APPEND_OBJECT(value, KEY, add_separator) \
   json_append_fixed_value_string(value, JSON_QUOTE KEY JSON_QUOTE JSON_KEY_VALUE_SEPARATOR JSON_OBJECT_START, \
      sizeof(JSON_QUOTE KEY JSON_QUOTE JSON_KEY_VALUE_SEPARATOR JSON_OBJECT_START) - 1, add_separator);


// Need to explicitly append JSON_ARRAY_END "]" value
#define JSON_APPEND_ARRAY(value, KEY, add_separator) \
   json_append_fixed_value_string(value, JSON_QUOTE KEY JSON_QUOTE JSON_KEY_VALUE_SEPARATOR JSON_ARRAY_START, \
      sizeof(JSON_QUOTE KEY JSON_QUOTE JSON_KEY_VALUE_SEPARATOR JSON_ARRAY_START) - 1, add_separator);


// Append Object Start Symbol
#define JSON_APPEND_OBJECT_START(value, add_separator) \
   json_append_fixed_value_string(value, JSON_OBJECT_START, sizeof(JSON_OBJECT_START) - 1, add_separator);


// Append Array Start Symbol
#define JSON_APPEND_Array_START(value, add_separator) \
   json_append_fixed_value_string(value, JSON_ARRAY_START, sizeof(JSON_ARRAY_START) - 1, add_separator);


// Closing JSON Object
#define JSON_APPEND_OBJECT_CLOSE(ptr) \
   json_append_fixed_value_string(ptr, JSON_OBJECT_END, sizeof(JSON_OBJECT_END) - 1, 0);


//Closing JSON Array Object
#define JSON_APPEND_ARRAY_CLOSE(ptr) \
      json_append_fixed_value_string(ptr, JSON_ARRAY_END, sizeof(JSON_ARRAY_END) - 1, 0);

void json_append_escaped_string(char **buff, 
                                const char *name, 
                                const char *value, 
                                int add_separator, 
                                int max_len);


void json_append_value_string(char **buff, 
                              const char *name, 
                              int add_separator);


void json_append_fixed_value_string(char **buff, 
                                    const char *name, 
                                    int len, 
                                    int add_separator);


void json_append_value_int(char **buff, 
                           const int value, 
                           int add_separator, 
                           int add_quote);


void json_append_string(char **buff, 
                        const char *name, 
                        const char *value, 
                        int add_separator);


void json_append_int(char **buff, 
                     const char *name, 
                     const int value, 
                     int add_separator, 
                     int add_quote);


void json_append_double(char **buff, 
                        const char *name, 
                        const double value, 
                        int add_separator, 
                        int add_quote);

void json_append_double_truncated(char **buff, 
				  const char *name, 
				  const double value, 
				  int add_separator, 
				  int add_quote);

void validate_json(char *json_str);
void copy_iab_cat_from_db_in_json(char* iab_category,const publisher_site_t *site);
void json_append_object(char **buff,
                        const char *name,
                        const char *value,
                        int add_separator);
/* QA not yet done*/
int replace_json_obj_arr(char* json_str,
			 int * json_str_len,
			 int json_str_cacpacity,
			 const char* obj_name,
			 const char*new_obj_str
			 );
/* QA not yet done*/
int find_json_object_or_arr_size(const char* json_str,
				 int json_str_len,
				 const char* obj_name,
				 int *obj_start_offset
				 );
#endif
