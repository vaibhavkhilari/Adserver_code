#ifndef __NATIVE_COMMON_H__
#define __NATIVE_COMMON_H__

// Native Asset type
#define TITLE_ASSET 1
#define IMAGE_ASSET 2
#define DATA_ASSET 3
#define VIDEO_ASSET 4

#define NATIVE_EXTENSION_LEN 255

typedef struct extension {
  char ext_data[NATIVE_EXTENSION_LEN + 1];
} extension_t;

//Object invalid reasons
#define NATIVE_OBJ_VALID_JSON                            0
#define NATIVE_OBJ_INVALID_JSON                          1
#define NATIVE_VER_NOT_FOUND                             2
#define NATIVE_ASSETS_NOT_FOUND                          3
#define NATIVE_ASSETS_ARRAY_LENGTH_LESS_THAN_ONE         4
#define NATIVE_ASSETS_ID_NOT_FOUND                       5
#define NATIVE_ASSETS_OBJECT_NOT_DEFINED                 6
#define NATIVE_OBJECT_EMPTY                              7
#define NATIVE_MISSING_REQUIRED_ASSETS                   8
#define NATIVE_EXCESS_REQUIRED_ASSETS                    9
#define NATIVE_ASSETS_ARRAY_LENGTH_MISMATCH              10
#define NATIVE_MEMORY_ALLOCATION                         11


#endif
