/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __EXTERNAL_CONFIG_H_ 
#define __EXTERNAL_CONFIG_H_
#include "ad_optimizer.h"
#include "ctleaf_error.h"
#include "cleaf_icap_config.h"

//#include "include/ctleaf_util.h"
//#include "include/ctleaf_config.h"


extern int g_tracking_zone_id_limit;
extern ad_optimizer_t g_adservers[];
extern int g_adservers_size;
#ifdef COUNT_PROXY_REQUESTS
extern uint16_t g_stats_counter_size;
extern char* g_stats_datacenter_name;
#endif

extern uint64_t g_module_enabled;
extern int g_logging_enabled;
extern int g_logging_compression_level;
extern int g_logging_compression_enabled;

extern char *g_ads_name;
//DP config flag
extern int g_rtb_enable_contextual_data_providers;
//~DP config flag

extern int g_rtb_integral_enabled;

// cookie store config flags
extern int g_rtb_floor_rpug_conn_timeout;
extern int g_rtb_floor_rpug_req_timeout;
extern int g_rtb_rpug_conn_timeout;
extern int g_rtb_rpug_req_timeout;
extern int g_rtb_spug_conn_timeout;
extern int g_rtb_spug_req_timeout;

/*citrus leaf object*/
extern aerospike g_ctleaf_asc;
extern int g_ctleaf_timeout_ms;

#endif
