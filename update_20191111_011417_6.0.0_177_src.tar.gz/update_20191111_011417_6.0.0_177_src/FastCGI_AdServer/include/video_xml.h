/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef _XML_VIDEO_H_
#define _XML_VIDEO_H_
#include "video.h"

#define MAX_XML_OBJECT_SIZE ( MAX_VIDEO_CREATIVE_TAG_LEN * 2 ) //TUSHAR:70k
#define MAX_EXT_XML_OBJECT_SIZE 4096

#define APPEND_FIELD_TO_XML(written, buffer, cur_pos, size, format, ...) do { \
	written = snprintf((buffer + cur_pos), (size-cur_pos), format, ##__VA_ARGS__); \
	if (written >= (size - cur_pos)) { \
		error_log("BUFFER_OVERFLOW");	\
		return ADS_ERROR_BUFFER_OVERFLOW;	\
	}		\
	cur_pos += written; \
} while(0); 

#define error_log(format, ...) fprintf(stderr, "E:%s:%d:" format "\n", __FILE__, __LINE__, ##__VA_ARGS__);

typedef struct {
	char xml[MAX_XML_OBJECT_SIZE + 1]; 
	int cur_pos;
	int size;
}video_xml_t;

typedef struct {
	char xml[MAX_EXT_XML_OBJECT_SIZE + 1]; 
	int cur_pos;
	int size;
}pm_ext_xml_t;

//#define ADS_ERROR_BUFFER_OVERFLOW 1
#define ADS_ERROR_INVALID_PARAMETERS 2
#define ADS_ERROR_INVALID_PARAMS 3

#define INT_BITS sizeof(int)*8

#define VIDEO_TRACKING_EVENTS_NODE "TrackingEvents" 
#define VIDEO_IMPRESSION_NODE "Impression"
#define VIDEO_ERROR_NODE "Error" 
#define VIDEO_CREATIVES_NODE "Creatives"
#define VIDEO_CREATIVE_NODE "Creative"
#define VIDEO_LINEAR_NODE "Linear" 
#define VIDEO_NON_LINEAR_NODE "NonLinearAds" 
#define VIDEO_VAST_NODE "VAST"
#define VIDEO_VAST_NODE_VERSION "version"
#define VIDEO_AD_NODE "Ad" 
#define VIDEO_WRAPPER_NODE "Wrapper"
#define VIDEO_ADSYSTEM_NODE "AdSystem"
#define VIDEO_ADTAGURI_NODE "VASTAdTagURI"
#define VIDEO_TRACKING_EVENT_NODE "Tracking"
#define VIDEO_AD_NODE_ID_ATTRIBUTE "id"
#define PUBMATIC_AD_SERVER "PubMatic"

#define VIDEO_ERROR_TRACKING_MACRO "[ERRORCODE]"

typedef enum {
	VIDEO_RESPONSE_TYPE_INVALID = -1,
	VIDEO_RESPONSE_TYPE_URI = 0,
	VIDEO_RESPONSE_TYPE_VAST = 1,
} video_response_type_t;

#define NO_EVENT_TRACKING_HEADER_NEEDED 0
#define EVENT_TRACKING_HEADER_NEEDED 1

#define VID_EVENTS_BIT_MAP 63
#define VAST_VERSION_3_0 " version=\"3.0\""
#define EMPTY_VAST_2_RESPONSE "<VAST version=\"2.0\"></VAST>"

#endif
