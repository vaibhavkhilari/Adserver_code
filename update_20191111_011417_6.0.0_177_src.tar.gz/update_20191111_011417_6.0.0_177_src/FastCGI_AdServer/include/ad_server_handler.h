/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __AD_SERVER_HANDLER_H__
#define __AD_SERVER_HANDLER_H__

#include <ctype.h>

#include "ad_server_config.h"
#include "extern_config.h"
#include "ad_server_main_utils.h"
#include "fte_util.h"
#include "campaign_freq_util.h"
#include "db_geo_map.h"
#include "cache_publisher_global_settings.h"
#include "tracker_bypass.h"
#include "site_size_network_impression_capping.h"
#include "impressions_filter.h"
#include "network_impression_capping.h"
#include "ad_server_click_track_utils.h"
#include "fte_free_resouce.h"
#include "rtb_util.h"
#include "cache_publisher_adservedtracking_component.h"
#include "default_adapter.h"
#include "rtb_brand_control_util.h"
#include "cache_publisher_site_rtb_floor.h"
#include "handle_malware_debug.h"
#include "logger.h"
#include "logger_bidless.h"
#include "cache_publisher_site_default_settings.h"
#include "cache_publisher_site_default_params.h"
#include "cache_publisher_audience_target_site.h"
#include "audience_targeting_util.h"
#include "floor_rules_types.h"
#include "get_user_audience_info.h"
#include "privacy_compliance_util.h"
#include "cache_publisher_site_ad_serving_rtb_status.h"
#include "trie.h"
#include "dycpm_util.h"
#include "cache_bot_trie_operations.h"
#include "bot_pattern_matching.h" 
#include "http_header_helper.h"
#include "cache_publisher_billing_details.h"
//#include "adflex_optimizer.h"
//DP
#include "dp_generic.h"
#include "dp_properties.h"
#include "deal_util.h"
#include "himpa_edge_side_rule_engine_util.h"

//Mobile - Suraj
#include "mobile_header.h"
#include "mobile_debug.h"
#include "mobile_error.h"
#include "platform.h"
//zedo integration
#include "zedo_integration.h"
//zedo integration end
#include "cookie_store_util.h"
#include "fetch_cookie_from_store.h"
#include "ad_server_optimizer.h"
#include "adtruth_util.h"
#include "currency_conversion.h"
//niki
#include "parallel_curl_calls.h"
#include "cache_get_site_url_mapping.h" //This is actually application profile map not siteurl map
#include "cache_sitecode_siteurl_map.h" //sitecode to siteurl map

#include "cache_ad_width_height.h"
#include "cache_get_app_info.h"
#include "cache_get_iab_category_info.h"

//log framework ~ramakant
#include "log_fw.h"

//video response
#include "video_response_former.h"
//centralised icap
#include "rt_types.h"
#include "ad_server_types.h"

#include <openssl/md5.h>
#include "third_party_pixel.h"
#include "string_util.h"
#include "native_util.h"

#include "ad_server_constants.h"
#include "get_advertiser_id.h"

//Global BlockLsit
#include "daa_deviceid_optout_bloomfilter.h"
#include "ads_txt_unauthorized_inventory_check.h"

#include "db_get_app_iab_cat_info.h"
#include "entity_level_stats.h"
void extract_and_fill_final_urls(
	ad_server_req_param_t *params,
	ad_server_additional_params_t *additional_params
);

void set_pubmatic_uid(
		char **user_cookie_value,
		int user_id_preference,
		int *non_cookied_uid,
		ad_server_req_param_t* params,
		ad_server_additional_params_t* additional_params
);

void set_user_cookie_value(
		char **user_cookie_value,
		const char *req_uid,
		int *non_cookied_uid
);

void set_req_partner_uid(ad_server_req_param_t* params);

void set_req_pubmatic_uid(
		const char *user_cookie_value,
		ad_server_req_param_t* params,
		ad_server_additional_params_t* additional_params
);

//Always reset the pointer to zero
#define FREE_AND_RESET(pointer) {free(pointer); pointer=0;}

//Clean and wind up the request
#define FINISH_AND_CLEANUP()	do{ FCGX_Finish_r(&request); \
					free_ad_server_parameters(&params); \
				}while(0);

#define APPEND_CREATIVE_STRING(JUMP_TAG, bytes_written, char_ptr, space_left, format, ...)     \
        do{ \
                bytes_written = snprintf(char_ptr, space_left, format, ##__VA_ARGS__);      \
                if (bytes_written >= space_left) {                      \
                  space_left = -1; \
                  goto JUMP_TAG; \
                } \
                else {  \
                  space_left -= bytes_written;    \
                  char_ptr += bytes_written;  \
                } \
        }while(0);
#endif
