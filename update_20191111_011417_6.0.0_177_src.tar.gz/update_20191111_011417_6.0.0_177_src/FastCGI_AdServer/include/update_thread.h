#ifndef __UPDATE_THREAD_H__
#define __UPDATE_THREAD_H__
#include "mbf.h"
#include "bid_thrtl.h"

#ifdef __cplusplus
extern "C"
{
#endif

#define UPDATE_BID_THROTTLING_MODEL "BID_THROTTLING"

struct update_ctx {
	struct db_info *adflex_db_handle;
	struct db_info *komliadserver_db_handle;
	// name of program
	const char *name;
	// in seconds
	int wait_time;
};

int init_update_thread(const char *name);

#ifdef QA_AUTOMATION
typedef enum update_global_data_structure_types {
	DS_ADSERVER_CONTROL_PARAMS=100, // 0 to 99 are reserved for generic global data structures
	DS_BID_PROBABILITY_MODEL, //101
	DS_NBT_THROTTLING, //102
	DS_UPDATE_OS_LIST, //103
	DS_UPDATE_BROWSER_LIST, //104
	DS_UPDATE_MBF, //105
	DS_UPDATE_F1, //106
	DS_UPDATE_SINGLE_F2, //107
	DS_UPDATE_RTB_MUX_MODEL, //108
	DS_UPDATE_PRICING_CONTROL, //109
	/* Add new types above this line */
	MAX_UPDATE_GLOBAL_DS_TYPES
} update_global_data_structure_types_t;

void qa_automation_regenerate_update_global_data_structure(update_global_data_structure_types_t type);
#endif

#ifdef __cplusplus
}
#endif
#endif
