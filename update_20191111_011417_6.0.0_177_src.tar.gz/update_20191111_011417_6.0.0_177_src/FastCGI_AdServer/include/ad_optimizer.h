/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef AD_OPTIMIZER_H
#define AD_OPTIMIZER_H

#include <stdio.h>
#include "ad_server_types.h"
#include "rt_types.h"
#include "cache_types.h"
#include "db_connection.h"
#include "GeoIP.h"

/* Curl header files */
#include <curl/curl.h>
#include <curl/easy.h>

typedef long (* adop_get_id) (void);
typedef int (* adop_get_name) (char **name);
typedef int (* adop_initilize) (void *data);
typedef int (* adop_exit)(void *data);
typedef int (* adop_handle_change_notification) (void *data);
typedef int (* adop_get_ad_code)(
		selected_compaign_context_t *selected_camp_cntx,
		ad_server_req_param_t *in_req_params,
		ad_server_req_gen_param_t *in_gen_params,
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		cache_handle_t *cache_handle,
		db_connection_t *dbconn,
		unsigned long ptid,
		ad_server_additional_params_t *additional_params, 
fte_additional_params_t *fte_additional_parameters);
typedef int (* adop_increment_priority) (
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		double priority);
typedef int (* adop_decrement_priority) (
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		double priority);
typedef int (* adop_get_priority) (
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		double *priority);
typedef int (* adop_get_ctr) (
		publisher_site_ad_t *in_ad,
		ad_active_account_t **in_active_accounts ,
		int in_nactive_accounts,
		double *ctr);
typedef int (* adop_insert_keywords_to_adscript) (char **adscript, ad_server_req_param_t *in_req_params, adserver_macro_variable_name_list_t * macro_list);
typedef int (* adop_get_ecpm) (double *ecpm);

typedef struct ad_optimizer_ops {
	adop_get_id get_id;
	adop_get_name get_name;
	adop_initilize initilize;
	adop_exit exit;
	adop_get_ad_code get_ad_code;
	adop_handle_change_notification handle_change_notification;
	adop_increment_priority increment_priority;
	adop_decrement_priority decrement_priority;
	adop_get_ctr get_ctr;
	adop_get_priority get_priority;
	adop_insert_keywords_to_adscript insert_keywords_to_adscript;
	adop_get_ecpm get_ecpm;
} ad_optimizer_ops_t;

/*
 * Structure to maintain information of optimizers, will be used by higher
 * level algorithms
 */
typedef struct ad_optimizer {
	long id;
	ad_optimizer_ops_t *optimizer_ops;
} ad_optimizer_t;

/*
 * Structure to maintain information of ad server specific optimizers, will be
 * used by higher level algorithms
 */
typedef struct adserver_optimizer {
	long adserver_id;
	ad_optimizer_ops_t *optimizer_ops;
} adserver_optimizer_t;

/*
int initilize_optimizer(ad_optimizer_ops_t *optimizer_ops);
int shutdown_optimizer(ad_optimizer_ops_t *optimizer_ops);
*/
/*
typedef int (*realtime_network_fptr)(
		FCGX_Request* request,
		int is_api_request,
		char* ptr_mobile_network_url,
		char* mobile_network_url,
		int space_left,
		const ad_server_req_param_t* in_req_params,
		const ad_server_req_gen_param_t* in_gen_params,
		const ad_server_additional_params_t* additional_params,
		const ad_served_params_t* ad_srvd_parameter,
		const fte_additional_params_t* fte_additional_parameters
);
#define MAX_REALTIME_NETWORK_BUF 10240 // is this enough?
#define INMOBI_FPTR_INDEX 0
#define JUMPTAP_FPTR_INDEX 1
#define MOJIVA_FPTR_INDEX 2
#define MOCEAN_FPTR_INDEX 3
#define HUNTMADS_FPTR_INDEX 4
#define MADVERTISE_FPTR_INDEX 5
#define ADFONIC_FPTR_INDEX 6
#define MATOMY_FPTR_INDEX 7
#define TAPIT_FPTR_INDEX 8
#define INFO_4_FPTR_INDEX 9
#define VDOPIA_FPTR_INDEX 10
#define KOMLI_FPTR_INDEX 11
#define JIWIRE_FPTR_INDEX 12
#define NEXAGE_FPTR_INDEX 13
#define ADDYNAMO_FPTR_INDEX 14
*/

#endif /* AD_OPTIMIZER_H */
