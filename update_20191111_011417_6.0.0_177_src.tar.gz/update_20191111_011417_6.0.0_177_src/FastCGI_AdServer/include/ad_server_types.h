
/*
	 PubMatic Inc. ("PubMatic") CONFIDENTIAL
	 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/


#ifndef AD_SERVER_TYPES_H
#define AD_SERVER_TYPES_H   
#include <string_util.h>
#include "ad_server_type_helper.h"
#include <dss_handle.h>
#include <fte_handle.h>
#include "mtwist.h"
#include "adtruth_util.h"
#include "guid_util.h"
#include "csm_types.h"
/*MaxMind GeoIP header file*/
#include <GeoIP.h>

#include <na_db_wrapper.h>

/* Curl header files */
#include <curl/curl.h>
#include <curl/easy.h>
#include <stats.h>
#include "config_params.h"
#include "demand_partner_header_types.h"
#include "video.h"
#include "parsing_util.h"
#include "native_request.h"
#include "currency_conversion.h"
#include "db_get_device_id_type_map.h" 
#include "deal_def.h"
#include "publisher_level_stats.h"
#include "gdpr_types.h"
#include "consumer_id_util.h"
#include "entity_level_stats.h"
#include "bid_util.h"
#include "banner_util.h"

#define FREE(x)     \
	  free((x));    \
  (x) = NULL;   

#define CHECK_N_FREE(x)   \
	  if ((x) != NULL) {  \
			    free(x);  \
			    (x) = NULL; \
			  }

#define ADFLEX_OPTIMIZER_ID    243       /* ADFLEX_OPTIMIZER ID */
#define ADFLEX_OPTIMIZER_NAME  "ADFLEX_OPTIMIZER"  /* ADFLEX_OPTIMIZER NAME */

#define MAX_BASE_URL_LEN 128
#define MAX_PUB_ID_LEN 256
#define MAX_SITE_ID_LEN 256
#define MAX_TAG_ID_LEN 256

#define MAX_DATA_ID_LEN 32
#define RELOAD_FREQ 10
#define MAX_DOMAIN_NAME_LENGTH 768 //256*3 i18
#define MAX_MOBILE_NETWORKS 100
#define MAX_NUM_PARAMS 100
#define WURFL_MAX_NUM_PARAMS 15
#define MAX_AD_REQUEST_SEGMENT_LIST_SIZE 512
//Maximum number of bid supported for a campaign
#define MAX_BIDS_LIMIT 5
#define MAX_AUDIENCE_ID_LIST_LENGTH 4096
#define MAX_PAYMENT_TAGID_CHAIN_LEN 511
#define MAX_PUBMATIC_PAYMENT_TAGID_LEN 63
#define STATS_SEND_TIMER_DIFF_LEN 7
#define SKIP_ALL_CREATIVE 1
#define SKIP_ALL_BUT_WINNING_CREATIVE 2
#define SKIP_USER_AGENT_STRING 4
#define TRUNC_COOKIE 8
#define SKIP_ALL_BUT_WINNING_TID 16
#define SKIP_LANDING_PAGE_URL 32
#define MAX_ORG_PUBID_LENGTH 64
#define TRIE_TYPE_ADV_DOMAIN_LIST 4
#define MAX_LAT_LONG_LIMIT 8  //Valid range of latitude is -90 to +90 and longitude is -180 to +180
                             //We need truncated lat lon e.g 41.837898 should look like 41.83, total 8 bytes is enough to store it.
#define MAX_LEN_XFF 256 
#define MAX_ADS_MEMCACHE_OBJECT_SIZE_BYTES 1048576 //1MB 
// KGAP: Is this the right place?
// KGAP: X-* naming convention deprecated?
// http://stackoverflow.com/questions/3561381/custom-http-headers-naming-conventions
// TODO: eCPM precision whereever this occurs
// TODO: Replace by a header list (add_header)
#define HTTP_HEADER_NAME_SBIH "X-hbid"
#define MAX_ALLOWED_MULTIBID_RESPONSE 5
#define IMG_SCRIPT_MAX_SIZE 174120 //174080 + 40(original impression id size)
#define MAX_EVENT_TRACKING_URI_SIZE 1024
#define CLICK_URL_MAX_SIZE 2048

#define INVALID_WAKANDA_KEY -1
#define ALPHA2_CODE_LEN 2
#define ALPHA3_CODE_LEN 3
#define INVALID_DEFAULT_VALUE 0
#define DEFAULT_VALUE_MINUS_ONE -1 // Mcaro For Removing magic Number
#define DEFAULT_LEN_64 64
#define DEFAULT_LEN_256 256
#define MAXVERSIONLEN 10
#define MAX_GOOGLE_QUERY_ID_LEN 128


typedef enum macro_str_enum{
				EN_MACRO_STR_UNDEF = -1,
				ENPUBLISHER_ID,              
				ENOPER_ID,                   
				ENSITE_ID,                   
				ENAD_ID,                     
				ENCAMPAIGN_ID,               
				ENCREATIVE_ID,               
				ENPREDICTED_CTR,             
				ENPIXEL_ID,                  
				ENSPIXEL_ID,                 
				ENINDIRECT_AD_ID,            
				ENAD_SERVER_ID,              
				ENDEFAULTED_ADSERVER_ID,     
				ENECPM,
				ENAUXN_ECPM,                      
				ENPBMT_ECPM,                 
				ENFREQUENCY,                 
				ENDEFAULTED_NETWORK_FREQUENCY,
				ENDEFAULTED_CMPG_ID,         
				ENDEFAULTED_ECPM,            
				ENDEFAULTED_ACTUAL_ECPM,     
				ENIMPR_CAP_FLAG,             
				ENAD_HEIGHT,                 
				ENAD_WIDTH,                  
				ENAD_SIZE_ID,                
				ENDEFAULT_IMPRESSION,        
				ENAD_SERVER_OPTIMIZER_ID,    
				ENUNIQUE_ID,                 
				ENPAGE_URL,                  
				ENBG_COLOR,                  
				ENBORDER_COLOR,              
				ENLINK_COLOR,                
				ENURL_COLOR,                 
				ENTEXT_COLOR,                
				ENFRAME_NAME,                
				ENTIME_STAMP,                
				ENRANDOM_NUMBER,             
				ENCLICK_DATA,                
				ENUSER_AGENT,                
				ENUSER_IP,                   
				ENUSER_ID_COOKIE,            
				ENACTIVITY_ID,               
				ENACTIVITY_PARAM,            
				ENZONE,                      
				ENBLOCKED_PIXEL_LIST,        
				ENSECURE_HTTPS_REQUEST,               
				ENAUDIENCE_SEGMENT,                   
				ENWINNING_DEAL_ID,                    
				ENMOBILE_FLAG,                        
				ENUNIQUE_DEVICE_ID_TYPE,              
				ENMOBILE_NETTYPE,                     
				ENCOUNTRY,                            
				ENIS_MOBILE_APP,                      
				ENMOBILE_DEVICE_MODEL_ID,             
				ENMOBILE_DEVICE_OS_ID,                
				ENMOBILE_CARRIER_ID,                  
				ENMSDK_VERSION,                       
				ENDIRECT_TRACKING,                    
				ENDIN_AD_ID,                          
				ENDEFAULTED_ADSERVER_LIST,            
				ENDEFAULTED_ADSERVER_LIST_S2S_ADFLEX, 
				ENTC0,                                
				ENTC1,                                
				ENTC2,                                
				ENDATACENTER_ID,                      
				ENTOP_LEVEL_DOMAIN_ID,                
				ENPASSBACK_FLAG,                      
				ENIMPRESSION_UNIQUE_ID,               
				ENPAGE_CATEGORIES_USED,               
				ENSITECODE,                           
				ENSITE_DOMAIN_NAME,                   
				ENLANDING_PG_URL,
				ENWINNING_BUYER_ID,
				ENFEATURE_BIT_SET_PARAM,
				ENTHIRD_PARTY_PIXEL_BITMAP,
				ENCREATIVE_ID_NEW,
				/*	--------------------------
						all element should be added before this
						--------------------------
						*/
				EN_MACRO_STR_MAX
}macro_str_enum_t;

typedef enum {
				cs_resp_default_iframe =0,//backward compatibility
				cs_resp_js = 1,
				cs_resp_js_for_js =2,
				cs_resp_iframe=3,
				cs_resp_iframe_for_iframe=4
}cs_resp_type_t;

typedef struct macro_str_id_mapping{
				macro_str_enum_t id;
				char * macro_str; /*never required to free*/
}macro_str_id_mapping_t;

//schain status enum
typedef enum schain_parsing_status {
        SCHAIN_PARSING_NOT_DONE = -1,
        SCHAIN_PARSING_DONE,
        SCHAIN_PARSING_FAILED
} schain_parsing_status_t;

#define MAX_USER_LANGUAGE_LEN                           64
#define OPER_ID "operId"
#define PUBLISHER_ID "pubId"
#define SITE_ID "siteId"
#define AD_ID "adId"
#define MB_REQUEST "mb"
#define CAMPAIGN_ID "campaignId"
#define CREATIVE_ID "creativeId"
#define PREDICTED_CTR "pctr"
#define CPC_VALUE "c_cpc"
#define PIXEL_ID "pixelId"
#define PREV_AD_IDS "prevkadIds"
#define INDIRECT_AD_ID "indirectAdId"
#define AD_SERVER_ID "adServerId"
#define DEFAULTED_ADSERVER_ID "defaultedAdServerId"
#define AD_SERVER_OPTIMIZER_ID "adServerOptimizerId"
#define UNIQUE_ID "uniqueId"
#define USER_GUID "userGuid"
#define AD_TAG_TYPE "adtagtype"
#define AD_TYPE "adtype"
#define NATIVE_ASSET "native"
#define AD_HEIGHT "kadheight"
#define AD_WIDTH "kadwidth"
#define AD_SIZE_ID "kadsizeid"
#define AD_MULTI_SIZE "multisize"
#define IS_PHOENIX_REQ "isPhxReq"
#define PHOENIX_IMPRESSION_ID "phxIId"
#define RICH_MEDIA_PROTOCOL "rmp"
#define AD_NETWORK "kadNetwork"
#define FORCE_AD_NETWORK "pmForceAdNetwork"
#define ECPM "kefact"
#define AUXN_ECPM "kaxefact"
#define PBMT_ECPM "kpbmtpfact"
#define FREQUENCY "kadNetFrequecy"
#define DEFAULTED_NETWORK_FREQUENCY "kadDefNetFreq"
#define FOLD_POSITION "adVisibility" //Fold position passed from JS
#define SECURE_HTTPS_REQUEST "sec"
#define SPIXEL_ID "sPixelId"
#define WINNING_DEAL_ID "wDlId"
#define WINNING_BUYER_ID "wDSPByrId"
#define DMA_CODE "dma"       
#define STATE "state"
#define ETHNICITY "ethn"
#define INCOME "inc"
#define THIRD_PARTY_PIXEL_BITMAP "tpb"
#define DIRECT_TRACKING "directTracking"
#define DEFAULTED_CMPG_ID "defcmpgId"
#define DEFAULTED_ECPM "defecpm"
#define DEFAULTED_ACTUAL_ECPM "defactecpm"
#define DEFAULTED_DYNAMIC_CPM "defdcpm"
#define DEFAULTED_ADSERVER_LIST "def_mob"
#define DEFAULTED_ADSERVER_LIST_S2S_ADFLEX "def_s2s_adflex_mob"
#define DIN_AD_ID "dInAdId"
#define DATACENTER_ID "dcId"
#define SA_VERSION "SAVersion"
#define TOP_LEVEL_DOMAIN_ID "tldId"
#define PASSBACK_FLAG "passback"
#define IMPRESSION_UNIQUE_ID "imprId"
#define COPPA_COMPLIANCE "coppa"
#define PAGE_CATEGORIES_USED "pcu"
#define SITECODE "sitecode"
#define SITECODE_LEN 8
#define CHD              "chd"
#define SAME_AD_BLOCK_COOKIE_NAME "dV"
#define ONE_MINUTE_SECOND 60
#define MAX_CRC_COOKIE_SIZE 192
#define LANDING_PG_URL "lpu"
#define LANDING_PG_URL_LEN 3
#define PAYMENT_TAGID_CHAIN "pchain" //payment tag id chain
#define TRSWT "trswt"
/*Publisher click tracking support*/
#define PUBLISHER_CLK_URL "kadpubclkurl"
#define DEFAULT_PUBLISHER_CLK_URL ""
#define KADPUBUID  "puid"  // publisher's unique identifire that publisher will send in ad call; separate from pubUID
#define IMPRESSION_CURRENCY "impcur"
#define WRAPPER_IMPR_ID "wiid"

#define MAX_COOKIE_COUNT_FOR_CRC_BLOCKING 5
/*UOL specific params keywords*/
#define AD_USER_GENDER "kadgdr"
#define AD_USER_AGE "kadage"
#define AD_KEYWORDS "kadkw"
#define AD_HINTS "kadhints"
#define AD_USER_CITY "city"
#define AD_USER_POSTAL_CODE "kadupcode"
#define AD_USER_FIRST_NAME "kadufname"
#define AD_USER_URL "kadpageurl"
#define DEFAULT_IMPRESSION "defaultReq"
#define IMPR_CAP_FLAG "imprCap"

#define PAGE_URL "pageURL"
#define BROWSER "browser"
#define BG_COLOR "kbgColor"
#define BORDER_COLOR "kborderColor"
#define TEXT_COLOR "ktextColor"
#define LINK_COLOR "klinkColor"
#define URL_COLOR "kurlColor"
#define REMOTE_IP_ADDRESS "kipAddress"
#define FRAME_NAME "frameName"
#define DNT_SET_UID "kdntuid"
#define CLICK_DATA "clickData"
#define USER_AGENT "ua"
#define USER_IP "ip"
#define USER_ID_COOKIE "uc"
#define TIME_STAMP "kltstamp"
#define RANDOM_NUMBER "ranreq"
#define TIMEZONE "timezone"
#define SCREEN_RESOLUTION "screenResolution"
#define AD_POSITION "adPosition"
#define ACTIVITY_ID "activityId"
#define ACTIVITY_PARAM "activityParam"
#define DEBUGFLAG "debug"
#define DEBUG_IS_COREDUMP_ON "dbgCRDMPOn"
#define AD_IMPRESSION_DEBUG "pmAdsD"
#define WAKANDA_ENABLE "wakanda"
#define INIFRAME "inIframe"
#define IN_MULTIPLE_NESTED_IFRAMES "inMultipleNestedIframes"
#define ZONE "pmZoneId"
#define DYNAMIC_RTB_FLOOR "kadfloor"
#define INTL_AD_TYPE "instl"
#define GUARANTEED_CAMID "kadgcid"
#define GUARANTEED_ECPM "kadgecpm"
#define GUARANTEED_ID "kadgid"
#define GUARANTEED_SITE_ID "kadgsiteid"
#define GUARANTEED_SECTION_ID "kadgsectionid"
#define GUARANTEED_AD_ID "kadgadid"
#define PUBLISHER_BEACON "kadbeacon"
#define DYNAMIC_PAGE_URL "kadpageurl"
#define SKIP_IP_BOT  "sh"
#define REFERRER_URL "refurl"
#define TIMEOUT "tOut"
#define ADINDEX "adIndx"
#define PMUNIADID "pmUniAdId"
#define SAVERSION "SAVersion"
#define AVOID_FRAME_DEFAULT_FLAG "avoidFrameDefault"
#define DEFAULTED_CMPG_IDS "defcmpgIDs"
#define LAST_DEFAULTED_NETWORK_ID "lastdefadnwkID"
#define DEFAULT_COUNT "defcount"
#define OLD_DEFAULT_AD_TAG "oldDefTag"
#define NOINFO_FLAG "noInfo"
#define MAL_DEBUG "md"
#define SITE_URL_ID "sitecode"
#define AD_INSPECTOR_FLAG "noEnc"
#define ORIGINAL_IMPR_ID "oid"
#define IAS_SCORE_TRACK "ias"
#define FEATURE_BIT_SET_PARAM "fbs"
#define PUBLISHER_UID "pubUID"
#define FP_VISITOR_SEGMENTS "fpVisSeg"
#define FP_INVENTORY_SEGMENTS "fpInvSeg"
#define FP_COOKIE_SEGMENTS "fpCkSeg"
#define DEVICE_TYPE "devicetype"
#define CREAT_ID_NEW "crID"
#define GOOGLE_QUERY_ID "gqid"

//Used in case of PubMatic API to determine the response type - callback function/variable
#define PMAPIRESTYPE "rs"
//Used in case of PubMatic API to identify the request at the client side.
#define PMAPIREQID "rid"
//In case of API to identify the http response code to be returned in case of an error
#define HTTP_RESPONSE_CODE "hrc"
#define DYNAMIC_AUCTION_TYPE "at"
#define UDID_HASHING_METHOD "udidhash"
#define LOCATION_SOURCE "loc_source"
#define PMAPISYNC "sync"
#define BLOCKED_PIXEL_LIST "pixelIdList"
#define AUDIENCE_SEGMENT "audSeg"
#define AUDIENCE_SEGMENT_EXP   "wdse"
#define AUDIENCE_SEGMENT_PRICE "wdsp"
#define REQUEST_IP "kuip"
/* short names, made to minimize the size  suffixed with "S_"*/
#define S_OPER_ID "oId"
#define S_PUBLISHER_ID "pId"
#define S_SITE_ID "sId"
#define S_AD_ID "aId"
#define S_CAMPAIGN_ID "cId"
#define S_CREATIVE_ID "crId"
#define S_PREV_AD_IDS "prevkadIds"
#define S_INDIRECT_AD_ID "iaId"
#define S_AD_SERVER_ID "asId"
#define S_DEFAULTED_ADSERVER_ID "dasId"
#define S_AD_SERVER_OPTIMIZER_ID "asopId"
#define S_UNIQUE_ID "uId"
#define S_USER_GUID "ugid"
#define S_AD_HEIGHT "ht"
#define S_AD_WIDTH "wd"
#define S_AD_NETWORK "anw"
#define S_ECPM "kefact"
#define S_PBMT_ECPM "pbmtpf"
#define S_FREQUENCY "freq"
#define S_DEFAULTED_NETWORK_FREQUENCY "dfreq"
#define S_DEFAULT_IMPRESSION "dReq"
#define S_PAGE_URL "url"
#define S_BROWSER "bsr"
#define S_BG_COLOR "BgC"
#define S_BORDER_COLOR "BdC"
#define S_TEXT_COLOR "tc"
#define S_LINK_COLOR "lc"
#define S_URL_COLOR "uc"
#define S_REMOTE_IP_ADDRESS "rIP"
#define S_FRAME_NAME "frN"
#define S_CLICK_DATA "clickData"
#define S_TIME_STAMP "ts"
#define S_RANDOM_NUMBER "ranreq"
#define S_ACTIVITY_ID "actId"
#define S_ACTIVITY_PARAM "actPrm"
#define S_PIXEL_ID "pxId"
#define S_IMPR_CAP_FLAG "impCp"
#define S_DEFAULT_MAPPED_REQ "dmr"
#define VIEWABILITYVENDORS	"viewabilityvendors"
#define METRIC	"metric"
#define IS_METRIC_VIEWABILITY "mview"
#define THIRD_PARTY_BUYER_TOKEN "third_party_buyer_token"
#define EXT_RESPONSE_RATE "response-rate"	// In logger it will be log as rr
#define EXT_GOAL_TYPE "goal-type"	// In logger it will be log as gltype

#define MAX_VIEWABILITYVENDORS_LEN  2048
#define MAX_METRIC_LENGTH 2048

/*UOL specific params keywords*/
#define S_AD_USER_GENDER "kadgdr"
#define S_AD_USER_AGE "kadage"
#define S_AD_KEYWORDS "kadkw"
#define S_AD_HINTS "kadhints"
#define S_AD_USER_CITY "kaducty"
#define S_AD_USER_POSTAL_CODE "kadupcode"
#define S_AD_USER_FIRST_NAME "kadufname"
#define S_AD_USER_URL "kadpageurl"

#define BURSTMEDIA_ADSERVER_ID 7
#define ACERNO_ADFLEX 449

//Adtruth Payload for generation uid
#define ADTRUTH_PAYLOAD "at_payload"
#define PARTNERUID "at_id"
#define PUBMATIC_UID "pm_uid"
#define PUBMATIC_UID_FROM_BROWSER_CACHE "pm_uid_bc"

//first party cookie enable/disable flag; dnt flag
#define REQUEST_GET_POST_PARAM_DNT	"dnt"
#define FPCD "fpcd"
#define IS_MSHOWAD_REQ "ms"
#define WRAP_API_TRACKER_CALL "awt"

//Mobile request params which being passed to us as part of HTTP POST request.
#define HASHED_DEVICE_ID                                "did"
#define HASHED_DEVICE_ID_TYPE				"dpidtype"
#define HASHED_DEVICE_DID_TYPE				"didtype"
#define SHA1_HASHED_PLATFORM_SPECIFIC_ID                "dpid"
#define DEVICE_ID_HASHING_TYPE							"dpidhash"
#define UNIQUE_DEVICE_ID								"udid"
#define UNIQUE_DEVICE_ID_TYPE							"udidtype"
#define COUNTRY                                         "country"
#define USER_LANGUAGE                                   "lang"
#define MOBILE_CARRIER                                  "carrier"
#define MOBILE_NETTYPE									"nettype"
#define MOBILE_DEVICE_MAKE   	                          "make"
#define MOBILE_DEVICE_MODEL                             "model"
#define MOBILE_DEVICE_OS                                "os"
#define MOBILE_DEVICE_OS_VERSION                        "osv"
#define JS_ENABLED                                      "js"
#define MOBILE_DEVICE_LOCATION                          "loc"
#define DEVICE_TYPE_STRING                              "devicetype"
#define FLASH_VERSION_STRING                            "flashver"
#define LOC_CATEGORY																		"loccat"
#define LOC_BRAND																				"locbrand"
#define XAD_FIRST_PARTY_LOC_INFO												1
#define APPLICATION_ID                                  "aid"
#define APPLICATION_API                                  "api"
#define APPLICATION_NAME								"name"
#define APP_STORE_URL									"storeurl"
#define APPLICATION_VERSION                             "ver"
#define APPLICATION_BUNDLE                              "bundle"
#define APPSTORE_CATEGORY								"cat"

#define APP_SECTION_CATEGORY               "sectioncat"
#define APP_PAGE_CATEGORY                "pagecat"
#define APP_KEYWORDS               "keywords"
#define APP_PRIVACYPOLICY                "privacypolicy"

#define IAB_CATEGORY					"iabcat"
#define SITE_DOMAIN_NAME 								"domain"
#define SITE_DOMAIN_NAME_LEN	6
#define IS_PAID_APPLICATION                             "paid"
#define YEAR_OF_BIRTH                                   "yob"
#define GENDER                                          "gender"
#define ZIP_CODE                                        "zip"
#define KEYWORDS                                        "keywords"
#define COMPLIANCE_LEVEL_REQUIRED                       "ormma"
#define AD_ORIENTATION_ID                               "adOrientation"
#define DEVICE_ORIENTATION_ID                           "deviceOrientation"
#define AD_REFRESH_RATE                                 "adRefreshRate"
#define BLOCK_ADV_IDS					"blkadvtids"
#define BLOCK_DOMAIN_IDS			"blkdmns"
#define BLOCK_IABCATEG_IDS		"blkiabcats"
#define BLOCK_ADV_DOMAINS               "blkadvdmns"
//MOBILE PARAMS
#define IS_MOBILE_APP									"isMobileApp"
#define MSDK_VERSION                                    "msdkVersion"
#define MOBILE_CARRIER_ID                               "carrier"
#define IMP_MOBILE_CARRIER_ID                           "carrierid"
#define MOBILE_DEVICE_MAKE_ID 	                        "makeid"
#define MOBILE_DEVICE_MODEL_ID                          "modelid"
#define MOBILE_DEVICE_OS_ID                             "osid"
#define MOBILE_FLAG					"mobflag"
#define MOB_MRAID										"mraid"

#define APP_DOMAIN                                      "appdomain"

#define DEVICE_CONNECTIONTYPE "connectiontype"
#define DEVICE_OMIDPN "omidpn"
#define DEVICE_OMIDPV "omidpv"
#define IMP_DISPLAYMANAGER "displaymanager"
#define IMP_DISPLAYMANAGERVER "displaymanagerver"

#define DEVICE_GEOFETCH   "device_geofetch"
#define DEVICE_FLASHVER   "device_flashver"
#define DEVICE_MCCMNC     "device_mccmnc"

//Rich Media Params
#define BLOCKED_CREATIVE_ATTRIBUTES			"battr"
#define RICH_MEDIA_TECHNOLOGIES				"ifb"
#define AD_EXPANSION_DIRECTION				"expdir"

#define LIMIT_AD_TRACK					"lmt"	

// "uids" JSON in Ad Request
#define AD_REQ_UIDS "dspids"
#define UID_JSON_UID_ARRAY "uids"
#define UID_JSON_PX_ID "px"
#define UID_JSON_UID "uid"

/* sbih (Send Bid in Header)
 * If present in Ad Request, then send the winning eCPM as an HTTP header as
 * well.
 */
#define AD_REQ_SBIH "sbih"
#define OPUBLISHER_ID "opubid"

#define TMAX_VALUE "tmax"
//SOFT FLOOR VALUE ALIGNED WITH JSON OBJECTS
#define BID_GUIDE_FLOOR_STRING "bidguidefloor"

//custom_param_for_deal
#define DEALS_CUSTOM_TARGETING_JSON "dctr"

// Content object json string in rtb request
#define CONTENT_OBJ "contentobj"

/* Supply Chain Object parameters */
#define SUPPLY_CHAIN_COMPLETE_FLAG "schain_cmpl"
#define SUPPLY_CHAIN_NODES_OBJ_STR "schain_nodes"
#define SUPPLY_CHAIN_VERSION "schain_ver"
#define SUPPLY_CHAIN_NON_ORTB_STRING "schain"

/* Device Object */
#define DEVICE_MOBILE_DEVICE_LOCATION	"device_loc"
#define DEVICE_LOCATION_SOURCE	"device_loc_source"
#define DEVICE_AD_USER_CITY	"device_city"
#define DEVICE_DMA_CODE	"device_dma"
#define DEVICE_STATE	"device_state"
#define DEVICE_ZIP_CODE	"device_zip"
#define DEVICE_COUNTRY	"device_country"
#define DEVICE_UTCOFFSET	"device_utcoffset"
#define DEVICE_SCREEN_HEIGHT "device_h"
#define DEVICE_SCREEN_WIDTH  "device_w"
#define DEVICE_SCREEN_PPI  "device_ppi"
#define DEVICE_SCREEN_PXR  "device_pxr"
#define DEVICE_HWV  "device_hwv"
#define DEVICE_GEOACCURACY "device_accuracy"
#define DEVICE_GEOLASTFIX "device_lastfix"
#define DEVICE_GEOIPSERVICE "device_ipservice"

/* USER Object */

#define USER_MOBILE_DEVICE_LOCATION	"user_loc"
#define USER_LOCATION_SOURCE	"user_loc_source"
#define USER_AD_USER_CITY	"user_city"
#define USER_DMA_CODE	"user_dma"
#define USER_STATE	"user_state"
#define USER_ZIP_CODE	"user_zip"
#define USER_COUNTRY	"user_country"
#define USER_UTCOFFSET	"user_utcoffset"
#define USER_GEOACCURACY "user_accuracy"
#define USER_GEOLASTFIX "user_lastfix"
#define USER_GEOIPSERVICE "user_ipservice"
//VIDEO params
#define V_TYPE "vtype"
#define V_POSITION "vpos"
#define V_MIN_LENGTH "vminl"
#define V_MAX_LENGTH "vmaxl"
#define V_HAS_COMPANION "vcom"
#define V_COMPANION_WIDTH "vcomw"
#define V_COMPANION_HEIGHT "vcomh"
#define V_MINBITRATE "vminbtr"
#define V_MAXBITRATE "vmaxbtr"
#define V_PROTOCOL_VERSION "vver"
#define V_STREAM_FORMAT "vfmt"
#define V_AD_FORMAT "vadFmt"
#define V_PROTOCOLS "protocols"
#define V_API "vapi"
#define V_PAGE_CONTEXTUAL_INFO "vcont"
#define V_PAGE_URL "vurl"
#define V_PLAYBACK "vplay"
#define V_VIDEO_PLAYER_HEIGHT "vh"
#define V_VIDEO_PLAYER_WIDTH "vw"
#define V_WINDOW_HEIGHT  "vwndh"
#define V_WINDOW_WIDTH "vwndw"
#define V_AD_HEIGHT "vadh"
#define V_AD_WIDTH "vadw"
#define V_WINDOW_PAGE_URL "vwndurl"
#define V_WINDOW_REF_URL "vwndref"
#define IFRAME_DEPTH "depth"
#define V_ASPECT_RATIO "var"
#define V_PLAYER_STRETCHING_MODE "vsm"
#define V_LANGUAGE "vcln" 
#define V_SKIP                "vskip"
#define V_SKIP_DELAY          "vskipdelay"
#define V_NOSKIP_AD_LEN       "vnoskipadlen"
#define V_FULL_SCREEN_EXPANDABLE "vfullscreenexpandable"
#define V_VIDEO_CLIENT       "vc" 
#define V_PLACEMENT "placement"
#define V_STARTDELAY "startdelay"
#define DECISION_MANAGER_PRICE_POINTS "dmpp"

/* Native Params */
#define NTV_API_VER "nver"
#define NTV_ADM_SUPPORT "admsupport"
#define NTV_IMG_RATIO "imgratio"
#define NTV_SEQ_NUM "seq"
#define NTV_ICON_SIZE "iconSz"
#define NTV_IMAGE_SIZE "imgSz"
#define NTV_TITLE_LEN "titleln"
#define NTV_DESC_LEN "descln"
#define NTV_CTA_LEN "ctaln"

#define MAX_NTV_API_VERSION_LEN 32
#define MAX_NTV_ADMSUPPORT_LEN 32
#define MAX_NTV_PARSED_ADMSUPPORT_LEN 128
#define MAX_NTV_IMGRATIO_LEN 16
#define MAX_NTV_ICON_SIZE_LEN 16
#define MAX_NTV_IMG_SIZE_LEN 16

#define DEFAULT_NTV_API_VER "1.0"
#define DEFAULT_NTV_IMGRATIO "1.8963"
#define DEFAULT_NTV_ICON_SIZE "75x75"
#define DEFAULT_NTV_ICON_MAX_WIDTH 75
#define DEFAULT_NTV_ICON_MAX_HEIGHT 75
#define DEFAULT_NTV_IMAGE_SIZE "1200x627"
#define DEFAULT_NTV_IMAGE_MAX_WIDTH 1200
#define DEFAULT_NTV_IMAGE_MAX_HEIGHT 627
#define DEFAULT_NTV_TITLE_LEN 25
#define DEFAULT_NTV_DESC_LEN 100
#define DEFAULT_NTV_CTA_LEN 15
/* End of Native Params */

/* Pmp Object Params */
#define PUBREQ_PMP_OBJECT_KEY "pmp"
#define PUBREQ_PMP_DEAL_OBJECT_KEY "deals"
#define PUBREQ_PMP_DEALID_OBJECT_KEY "id"


/* Video specific params */
#define VIDEO_OPID 7
#define V_OPER_ID "operId"
#define V_PUB_ID "p"
#define V_SITE_ID "s"
#define V_AD_ID "a"
#define V_INDIRECT_AD_TAG_ID "ina"
#define V_CAMPAIGN_ID "wc"
#define V_AD_SERVER_ID "wa"
#define V_DEFAULTED_ADSERVER_ID "da"
#define V_DEFAULTED_CAMPAIGN_ID "dc"
#define V_EVENT_ID "e"
#define V_ERROR_ID "er"
//#define V_ECPM "pf"
//#define V_PM_ECPM "pmf"
#define V_TS "ts"
//#define V_PAGE_URL "pg"

#define PAGEURL_MACRO "%23PEPAGEURL"
#define NEW_PAGEURL_MACRO "insert_encoded_pageurl_here"

//PHOENIX PARAMS
#define DYNAMIC_PLATFORM_ID "platform"

#define MAX_VID_PARAMS 37
#define MAX_EVENT_ID_VAL 100
#define MIN_ERROR_ID_VAL 100
#define MAX_ERROR_ID_VAL 901
#define VID_UNDEFINED_ERROR_ID 900
#define MAX_COMPANY_NAME_LEN 64
#define MAX_SSP_NAME_LEN 64
/*these values is hard coded here for respective UnDefined ITEMS */
#define DB_DEFAULT_MODEL 1
/* MODEL value taken from KomliAdServer.pm_device table */
#define DB_DEFAULT_OS 86
/* OS value taken from KomliAdServer.pm_os table */
#define DB_DEFAULT_CARRIER 1
/* CARRIER value taken from KomliAdServer.pm_carrier table */

#define MAX_COLOR_STR_LEN   (10 + 1)
#define MAX_PAGE_STR_LEN    (2048 + 1) //(1024 + 1)*2 i18 
//#define MAX_UNIQUE_ID_LEN   (256 + 1)
#define MAX_UNIQUE_ID_LEN   (40 + 1) /* UUID length is 36 bytes (uuid 32+ four '-') */
#define MAX_SKIP_IP_PASSBACK_LEN ( 10 + 1)
#define MAX_BROWSER_NAME_LEN    (512 + 1)
#define MAX_ACCEPT_LANGUAGE_NAME_LEN    (512 + 1)
#define MAX_COLOR_BINCLASS_LEN	(32 + 1)
#define MAX_IPSTR_LEN	(46)  /* MAX IPV6 length 16 bytes */
#define MAX_ENCODED_IPSTR_LEN 64
#define MAX_FRAME_NAME_LEN	(1024 + 1)
#define MAX_TIME_STAMP_LEN	(1024 + 1)
#define MAX_RANDOM_NUMBER_LEN	(128 + 1)
#define MAX_ENCODED_LEN	(128 + 1)
#define MAX_DECODED_LEN	(128 + 1)
#define MAX_ACTIVITY_PARAM_LEN	(256 + 1)
#define MAX_COOOKIE_NAME_LEN (256+1)
#define MAX_LENGTH_DSP_LIST 2048 // Assuming that each dsp_id will be of 4 bytes + 1 ','
/*Publisher click tracking support url length*/
#define MAX_PUBLISHER_URL_LENGTH (2048 + 1) //(1024 + 1)*2 i18
// Moving this to common_constants.h
// Please find the reason in place @common_constants.h 
#if 0
#define MAX_PUBMATIC_OPT_OUT_LEN 5	//pubmatic out out value can be either true or false
#endif

/*  Length for site code corresponding to site url */
#define MAX_SITE_URL_ID_LENGTH (128)
#define MAX_SITE_CODE_LENGTH (32) //while storing in Memcache it is 32 bytes only
#define MAX_SITE_URL_LENGTH (256)

#define MAX_URL_PARAM_SIZE (512) /* As per RTB specs all URL's passed to DSP should be 512*/

//#define MAX_FIXED_ADSCRIPT_LEN 15360 //10240*1.5 i18
#define MAX_FIXED_ADSCRIPT_LEN 174080 //170K

/*each zone can be of max size 50 as per DB 1 for comma*/
#define MAX_SINGLE_ZONE_LENGTH (50+1)
#define MAX_ENCODED_ZONE_ID (MAX_SINGLE_ZONE_LENGTH*DEFAULT_ZONE_ID_LIMIT*2)

#define MAX_ENCODED_COOKIE_LEN 2816 
#define MAX_DIV_BUFF_SIZE MAX_ENCODED_COOKIE_LEN + 100

#define MAX_URL_LENGTH_CLICK 6000
#define MAX_URL_LENGTH 4096 //2048*2 i18
#define COLORCLASS_DARK	0
#define COLORCLASS_LIGHT	1

#define MAX_PAGE_URL_SIZE 4096 //(2048 + 1)*2 i18
/* Mobile Targetting Parameter Sizes */
#define MAX_OS_NAME_SIZE 64
#define MAX_BROWSER_NAME_SIZE 64


#define DEFAULT_PAGE_URL_STR	"NOPAGEURLSPECIFIED"
#define DEFAULT_FRAME_NAME_STR	"NOFRAMENAMESPECIFIED"
#define DEFAULT_TIME_STAMP_STR	""
#define DEFAULT_RANDOM_NUMBER_STR  "NORANDOMNUMBERSPECIFIED"
#define DEFAULT_UNIQUE_ID_STR  "NOUNIQUEIDSPECIFIED"
#define DEFAULT_USER_GUID_STR  "NOUSERGUIDSPECIFIED"
#define DEFAULT_BROWSER_STR  "NOBROWSERSPECIFIED"
#define DEFAULT_TIME_ZONE_STR	""
#define DEFAULT_SCREEN_RESOLUTION_STR	""
#define DEFAULT_AD_POSITION_STR	""
#define DEFAULT_ZONE_ID_STR ""
#define DEFAULT_ZONE_ID_LIMIT 50
#define DEFAULT_REMOTE_IP_ADDRESS_STR  "NOREMOTEIPADDRESSSPECIFIED"
#define DEFAULT_RANDOM_NUMBER_STR	"NORANDOMNUMBERSPECIFIED"
#define DEFAULT_ENCODED_STR	"NODATAONENCODING"
#define DEFAULT_DECODED_STR	"NODATAONDECODING"
#define DEFAULT_ADHISTORY_STR	""
#define DEFAULT_PUBLISHER_BEACON ""
#define DEFAULT_DYNAMIC_PAGE_URL ""
#define DEFAULT_SKIP_IP_BOT ""
#define DEFAULT_TRSWT 3600000	//time in milisecond-1hour

// Moving this to common_constants.h
// Please find the reason in place @common_constants.h 
#if 0
#define PUBMATIC_OPT_OUT_FALSE 0
#define PUBMATIC_OPT_OUT_TRUE 1
#define PUBMATIC_OPT_OUT_TRUE_VALUE "true"
#endif

#define MAX_URL_SIZE            4096 //2048*2 i18
//#define MAX_COOKIE_SIZE         2048
#define MAX_COOKIE_SIZE         4096 // this was done to avoid ambiguity and future bugs because there is another #define MAX_COOKIE_LEN with size = 4096, kartik

#define LUCID_CATEGORY_LEN 256
#define MAX_LUCID_CATEGORIES 3

#define MAX_RANGE_DISTIR	1
#define MIN_RANGE_DISTRI	2
#define DEFAULT_DISTRI		3

/* Frequency capping constants */
#define MAX_NETWORKS_IN_ELIMINATION_LIST 512
#define NETWORK_FREQ_COOKIE_START	"pubfreq_"
#define FREQ_TIME_COOKIE_START	"pubtime_"
#define ONE_HOUR_SECONDS (60*60)
#define MAX_ADTAG_ON_PAGE 20
#define HISTORY_ADID_SEPARATOR_STRING "_"
#define MAX_STRING_LIST_ELEMENTS 150
#define MAX_STRING_LIST_ELEMENT_LENGTH 300
#define MAX_COOOKIE_HEADER_LENGTH 8000

#define MAX_REGISTERED_SITE_NAME_LEN 256

#define MAX_MEDIA_SCRIPT_LEN 600 /* this is max size of tracking script */
#define MAX_DEFAULT_HANDLING_URL_LENGTH 1024 //728 i18
//#define MAX_RTB_CLICKTRACK_KEYWORD_LEN 256
#define MAX_RTB_CLICKTRACK_KEYWORD_LEN 63
#define MAX_TRANSACTION_ID_SIZE 256
#define MAX_REQUEST_URL_SIZE 10240 //6144*1.8 i18

//#define MAX_SECOND_PRICE_MACRO_SIZE 512
#define MAX_SECOND_PRICE_MACRO_SIZE 127
#define MAX_RESPONSE_URL_SIZE   5120 //3072 i18
//#define MAX_CREATIVE_TAG_SIZE   10240 //(8192) i18
#define MAX_CREATIVE_TAG_SIZE   155648 //152K
#define MAX_LOGGABLE_CREATIVE_TAG_SIZE	102400 //100K --changed as part of asd-4359
#define TRUNCATED_CREATIVE_SIZE	100
#define MAX_RESPONSE_BUFFER_SIZE (10240 + 5120 + 1) //(8192 + 5120 + 1) i18

#define UCRID_CRC64_KEY_FORMAT_NON_EMPTY_CREATIVE_ID "%d_%s_%d" // dsp_id, creative_id, adsize_id
#define UCRID_CRC64_KEY_FORMAT_EMPTY_CREATIVE_ID "%d_%s_%d_%d" // dsp_id, landing_page_tld, adsize_id, platform_id
#define DERIVED_CRTV_BUFF_MAX_SIZE (MAX_DOMAIN_NAME_LENGTH + (3 * MAX_LONG_DATATYPE_LEN))
#define MAX_LONG_DATATYPE_LEN 10
#define MAX_CREATIVE_ID_SIZE 256 //(100) i18
#define MIN_CREATIVE_TYPE_VALUE 1
#define MAX_CREATIVE_TYPE_VALUE 9 // Should be always less than MAX_BITMAP_SIZE
#define MIN_CREATIVE_ATTR_VALUE 1
#define MAX_CREATIVE_ATTR_VALUE 64 // Should be always less than MAX_BITMAP_SIZE
#define MAX_IURL_SIZE		255
#define MAX_DSP_CAMPAIGN_ID_LEN	63
#define MAX_RICH_MEDIA_TECH_ID_LEN 15
#define MAX_THIRD_PARTY_BUYER_TOKEN_LEN 256
#define MAX_GOAL_TYPE_LEN 64


#define MAX_RID_LEN 32
#define MAX_DSP_BUYER_ID_LEN 20
#define MAX_BID_ID_LEN 50

//TODO: Confirm Native creative max size
#define MAX_NATIVE_CREATIVE_LEN 1024*50 // 50k
#define MAX_NATIVE_ASSET_LEN 5120
#define MULTI_AD_DIM_LEN 512 /*"hgt1*width1,hgt2*width2,hgt3*width3,hgt4*width4"*/
#define RICH_MEDIA_PROTOCOL_LEN 32
#define AD_DIMENSIONS_COUNT 10
#define AD_DIMENSIONS_COUNT_MUX 5
#define HTTP_METHOD_GET 1
#define HTTP_METHOD_POST 2

/*UOL specific params keywords size*/
#define MAX_AD_USER_GENDER_LEN (1 + 1)
#define MAX_AD_USER_AGE_LEN 4 
#define MAX_AD_KEYWORDS_LEN 256
#define MAX_AD_HINTS_LEN 256
#define MAX_AD_USER_CITY_LEN 256
#define MAX_AD_USER_POSTAL_CODE_LEN 256
#define MAX_AD_USER_FIRST_NAME_LEN 256
#define MAX_BIDS_PER_RTB_CAMPAIGN 1


/* RichMedia params related macros. */
#define MAX_AVAILABLE_IFRAME_BUSTER_TECH_LIST_LEN 128
#define MAX_ALLOWED_CREATIVE_ATTRIBUTES_LIST_LEN 64
#define MAX_BLOCKED_CREATIVE_ATTRIBUTES_LIST_LEN 256
#define MAX_RICH_MEDIA_POST_DATA_LEN (MAX_AVAILABLE_IFRAME_BUSTER_TECH_LIST_LEN + MAX_ALLOWED_CREATIVE_ATTRIBUTES_LIST_LEN + 256)

//POST DATA LENGTH is set to fix 80K
//(increased by 15000 bytes for EB GDPR provider list)
//Rest for deal related JSON objects ( 400 max )
//80000 => 91000 , 11K for bapp and btype
#define MAX_POST_DATA_LEN 91000

/*Mobile request params related macros. */
/* MAX_HASHED_DEVICE_ID_LEN, MAX_SHA1_HASHED_PLATFORM_SPECIFIC_ID_LEN,
 * MAX_UNIQUE_DEVICE_ID_LEN, MAX_DEVICE_ID_HASH_KEY_VAL_JSON and
 * MAX_PARTNER_KEY_SIZE are interrelated and must be consistent*/
#define MAX_HASHED_DEVICE_ID_LEN                        256 //128*2
#define MAX_SHA1_HASHED_PLATFORM_SPECIFIC_ID_LEN        256 //128*2
#define MAX_UNIQUE_DEVICE_ID_LEN			256 //128*2 i18
#define MAX_COUNTRY_LEN                                 80 //8*10 i18
#define MAX_MOBILE_CARRIER_LEN                          32
#define MAX_MOBILE_NETTYPE_LEN							32
#define MAX_MOBILE_DEVICE_MAKE_LEN	                    32
#define MAX_MOBILE_DEVICE_MODEL_LEN                     32
#define MAX_MOBILE_DEVICE_OS_LEN                        16
#define MAX_MOBILE_DEVICE_OS_VERSION_LEN                16
#define MAX_MOBILE_DEVICE_LOCATION_LEN                  128
#define MAX_APPLICATION_BUNDLE_LEN                      256
#define MAX_APPLICATION_NAME				                 512 //128*2 i18
#define MAX_APPLICATION_API_LEN							32
#define MAX_APPLICATION_ID								64
#define MAX_APPLICATION_VERSION							32
#define MAX_YEAR_OF_BIRTH_LEN                           4
#define MAX_GENDER_LEN                                  1
#define MAX_ZIP_CODE_LEN                                8
#define MAX_KEYWORDS_LEN                                127
#define MAX_DMA_LEN										256
#define MAX_STATE_LEN									256
#define MAX_ETHNICITY_LEN								256
#define MAX_INCOME_LEN									256
#define MAX_DMA_LEN										256
#define MAX_STATE_LEN									256
#define MAX_ETHNICITY_LEN								256
#define MAX_INCOME_LEN									256
#define MAX_DMA_LEN										256
#define MAX_STATE_LEN									256
#define MAX_ETHNICITY_LEN								256
#define MAX_INCOME_LEN									256

#define MAX_CATEGORY_LEN								3500
#define MAX_QUERY_STRING_PARAM_LEN			MAX_CATEGORY_LEN

#define MAX_LENGTH_SITE_IAB_VERTICALS                                                   512
#define MAX_LENGTH_ENCODED_SITE_IAB_VERTICALS                                                   1024
#define MAX_COUNT_SITE_IAB_VERTICALS                                                    60
#define IAB_CAT_MAX_LIMIT_IN_REQUEST                                                    20

#define MAX_UDID_TYPE_LEN									64
#define MAX_MOBILE_SDK_VERSION_LEN			20
#define MAX_FLASH_VERSION_LEN           20

#define UNKNOWN_MOBILE_DEVICE_ID						"<Unknown>"
#define UNKNOWN_MOBILE_PLATFORM_ID						"<Unknown>"


#define MAX_AED_LEN	31
#define MAX_BATTR_LEN	63
#define BATTR_VALUE_MAX 17
#define MAX_RMT_LEN	127
#define MAX_BLOCK_DOMAIN_IDS 20
#define MAX_BLOCK_ADV_IDS 20
#define MAX_IAB_CAT_LEN 16
#define IAB_START_INDEX 44                //In DB, IAB category id is being started from 44.
#define MAX_PUB_TO_IAB_CAT_MAPPING 6      //Accoding to iab guidelines, one pubmatic category can map to 1 primary and

#define MAX_COUNTRY_ID_COUNT 260 
#define MAX_BLOCK_CATEG_IDS 20
#define MAX_IAB_CAT_LEN 16
#define MAX_ADV_ID_BYTE_LEN sizeof(long)
#define SIZE_DATA_ADVT_DOMAIN_IAB_CAT (2*MAX_ADV_ID_BYTE_LEN + (MAX_PUB_TO_IAB_CAT_MAPPING)*(sizeof(char))*(MAX_IAB_CAT_LEN+1))
#define MAX_BLOCK_DOMAIN_LENGTH 3000
#define MAX_BLOCKED_ADV_DOM     40
#define MAX_ADV_DOM_LEN         256
#define MAX_BLOCKED_ADV_DOM_JSON_LENGTH   3500 
#define MAX_BLOCKED_CATEG_IDS_JSON_LENGTH 500

#define MAX_CTR_LEN 512
#define MAX_CTR_PARAM_COUNT 50
#define MAX_VALUES_PER_KEY 10

// content object json string length in rtb request
#define MAX_CONTENT_OBJ_STR_LEN 4096
/* Supply Chain nodes object as encoded string */
#define MAX_SUPPLY_CHAIN_NODES_OBJECT_STR 2048

//Categorized Avertiser Whitelist size : 3.2 Million
#define MAX_ADV_INFO_ROW_COUNT 3200000
/* Video Creative optiomisation info table size : 1 Million*/
#define MAX_VIDEO_CREATIVE_INFO_ROW_COUNT 1000000
//Max number of campaign defaults allowed in case no threshold limit is set.
#define DEFAULT_CAMPAIGN_THRESHOLD 4
//Max number of campaign/network defaults allowed in case no threshold limit is set.
#define DEFAULT_THRESHOLD 4

// Encryption/Decryption Algo names. This list can be extended in future
#define HMAC_SHA2_BASE64 "hmac-sha2-base64"

#define MAX_ENCRYPTION_KEY_LENGTH 16
#define MAX_INTEGRITY_KEY_LENGTH 16
#define MAX_ENCRYPTION_ALGO_NAME_LENGTH 32
/*multi geo support parameters*/
#define MAX_GEO_NAME_LEN (GENERAL_STRING_LEN +1)
#define RED_MAX_GEO_NAME_LEN 32
#define MAX_ISP_NAME_LEN (GENERAL_STRING_LEN +1)
#define MAX_CONNECTION_NAME_LEN 50
#define MAX_GEO_CODE_LEN (THREE_COUNTRY_LEN +1)
#define MAX_POSTAL_CODE_LEN 5120
#define MAX_GEO_POSTAL_CODE_LEN (POSTAL_CODE_LEN +1)
#define MAX_AREA_CODE_LEN (AREA_CODE_LEN +1)
//MAX post lengh for video
#define MAX_VID_POST_DATA_LEN (sizeof(video_param_t) + 256)
#define MAX_OS_NAME_LEN 25

#define DEFAULT_PRICE_ENCRYPTION_KEY "l4MJeao4lauHt9"
#define DEFAULT_PRICE_INTEGRITY_KEY "FDOBgBnRcYjaZh"

//xad location category feature
#define MAX_LOC_CATEGORY 256
#define MAX_LOC_BRAND 256

#define NON_GEO_ID -1
#define ROW_GEO_ID 0

#define MAX_GEO_LEVELS 4

#define GEO_LEVEL_COUNTRY 1
#define GEO_LEVEL_STATE 2
#define GEO_LEVEL_CITY 3
#define GEO_LEVEL_DMA 4
#define GEO_LEVEL_ZIP 5

typedef enum {
  DEVICE_TYPE_UNDEFINED               = -1,
  DEVICE_TYPE_MOBILE_OR_TABLET        = 1,
  DEVICE_TYPE_PERSONAL_COMPUTER       = 2,
  DEVICE_TYPE_CONNECTED_TV            = 3,
  DEVICE_TYPE_PHONE                   = 4,
  DEVICE_TYPE_TABLET                  = 5,
  DEVICE_TYPE_CONNECTED_DEVICE        = 6,
  DEVICE_TYPE_SET_TOP_BOX             = 7
}device_type_t;

#define GEO_SOURCE_GPS_OR_LOCATION  1
#define GEO_SOURCE_IP_ADDRESS       2
#define GEO_SOURCE_USER_PROVIDED    3

#define MAX_GEO_PARAMS_POST_DATA_LEN (sizeof (geo_data_t) + 80)

#define INVALID_LAT_LONG -10000
/*for active tag count*/
#define ACTIVE_TAG_COUNT_UNDEFINED 0
#define ACTIVE_TAG_COUNT_MAX  999999

// max size of ad_id array to store ad_id level stats for mobile s2s networks
// this value should be greater than max bucket counter for mob nw stats
#define MAX_AD_ID_LEN 10

#define RT_MOB_NW_BUCKET_LEN 8


#define IS_VALID_LATITUDE(x) (-90.0 <= x && x <= 90)

#define IS_VALID_LONGITUDE(x) (-180.0 <= x && x <= 180)

#define IS_BIT_SET(flag, bit) ((flag & (1 << bit)) ? true : false)

#define EQUALS '='
#define COMMA ','
#define KEY_VAL_DELIMITER '|'

#include "logger_types.h"
//#include "deal.h"

#define SHOWADS_DOMAIN_NAME "showads.pubmatic.com"
// adflex margin flexibility setting
#define MAX_PLATFORMS 2

typedef struct dynamic_cpm_stats {
				unsigned int campaign_id;
				int32_t no_impressions_monetized_above_cpm;
				double total_balance_utilised;
				double total_balance_saved;
}dynamic_cpm_stats_t;

#define DYNAMIC_CPM_STAT_COUNT 20
#define DYNAMIC_CPM_HPIC 10
#define DYNAMIC_CPM_TSB 2.0

typedef enum {
				NOT_DOING_PASSBACK = 0,
				//PUB_AGGRT_TLD_NA = 1,
				PASSBACK_KADPAGEURL_PAGEURL_SITECODE_NF = 1,
				PASSBACK_NON_WHITELISTED_URL = 2,
				PASSBACK_THROUGH_AUCTION = 3,
				INVALID_WEB_BROWSER_REQUEST = 4,
				WEB_BOT_REQUEST = 5,
				BOT_REQUEST_PASS_BLANK =6,
				KADPAGEURL_BLOCKLIST = 8,
				PAGEURL_BLOCKLIST = 9,
				REFERERURL_BLOCKLIST = 10,
				IP_BLOCKLIST = 11,
				PASSBACK_THROUGH_AUCTION_NONAGG = 25,
				PASSBACK_PREBID_FRAUD_CHECK = 26,
				GEO_ID_BLOCKLIST = 27,
				PASSBACK_PUB_GEO_ID_BLOCKLIST = 28,
				PASSBACK_ADS_TXT_UNAUTH_INVENTORY = 29,
				PASSBACK_GDPR_PM_HAS_NO_CONSENT = 30,
				PASSBACK_UNIDENTIFIED_AD_SIZE = 31,
				PASSBACK_RESPONSE_TIME_EXCEED_PUB_THRESHOLD = 32,
				GSS_APP_BLOCKLIST_PASSBACK = 33,
				PASSBACK_APP_ADS_TXT_UNAUTH_INVENTORY = 34
}impression_passback_reason_t;

typedef enum pub_auction_type {
	AT_PUB_UNKNOWN = -1,
	//AT=0 : refer bid_price_auction_enabled flag
	AT_PUB_DYNAMIC_FIRST_PRICE = 1,
	AT_PUB_DYNAMIC_SECOND_PRICE = 2,
	AT_PUB_CONF_FIRST_PRICE = 3,
	AT_PUB_CONF_SECOND_PRICE = 4
} pub_auction_type_t;

typedef enum app_id_type{
  APP_ID_TYPE_UNKOWN = 0,           // Unknown App ID 
  APP_ID_TYPE_PUBLISHER_DATA,       // Publisher Data
  APP_ID_TYPE_DERIVED_DATA,         // Derived from Store URL
  APP_ID_TYPE_DB_DATA,              // DB Data
  APP_ID_TYPE_AGGREGATOR_DB_DATA    // DB Data for Aggregator Publisher
}app_id_type_t;


typedef enum {
				UDID_TYPE_OTHER                     = 0,
				UDID_TYPE_IDFA                      = 1,
				UDID_TYPE_IDFV                      = 2,
				UDID_TYPE_ANDROID                   = 3,
				UDID_TYPE_UDID                      = 4,
				UDID_TYPE_OPEN_UDID                 = 5,
				UDID_TYPE_SECURE_UDID               = 6,
				UDID_TYPE_MAC                       = 7,
				UDID_TYPE_ODIN_1                    = 8,
				UDID_TYPE_ANDROID_ADVERTISING_ID    = 9
}udid_type_t;

typedef enum {
				UDID_HASH_FUCNTION_UNKOWN     = 0,
				UDID_HASH_FUNCTION_RAW        = 1,
				UDID_HASH_FUNCTION_SHA1       = 2,
				UDID_HASH_FUNCTION_MD5        = 3
}udid_hash_t;

typedef enum{
				PRIVACY_PARTNER_TAG_USED = 0
}feature_bit_set_t;

typedef struct{
				uint32_t invalid_browser_filter_count;
				uint32_t bot_filter_count;
}web_bot_filter_stats_t;

typedef struct impression_stats{
				uint32_t count_blank_ads;
				uint32_t site_icap_filter_count;
}impression_stats_t;

// moved from rt_types.h to here to remove recursive include dependencies
typedef struct rt_handle {
				CURLM *	curl_multi_handle;
				int epoll_fd;		// epoll file discriptor for listen epoll event
				int time_left_ms;    // Time left out of 100 ms/or whatever the timeout we are going to set
				int wait_time_ms; // Time that libcurl tells us to wait in epoll_wait
				int fd_time_left; // fd for timerfd_* API, this fd is "read" ready when rtb time is OVER
}rt_handle_t;
//~

#define MAX_SIZE_DYNAMIC_FLOOR_ARRAY 10
#define MAX_FLOOR_ID_LEN  10
#define MAX_DECODED_STRING_LEN  100
#define MAX_ENCODED_STRING_LEN  134
typedef struct decision_manager_price_point{
				int campaign_id; //guaranteed/non-guaranteed campaign id of publisher
				int campaign_type;// type of publisher campaign
				double ecpm;
}decision_manager_price_point_t;


typedef struct df_network_list{
				int nw_id;
				double ecpm;
				double o_ecpm;
				int nt_impr_cap_flag;
				long pixel_id;
				unsigned long oo_id;
}df_network_list_t;


typedef struct df_network_s2s_adflex_list{
				int campaign_id;
				int network_id;
				double ecpm;
				double o_ecpm;
				double campaign_price;
				double pbmt_ecpm;
				double predicted_ctr;
}df_network_s2s_adflex_list_t;

typedef struct ad_served_tracking_params {
				long oper_id;
				long publisher_id;
				long site_id;
				long ad_id;
				long campaign_id;
				long creative_id;
				char crId[MAX_CREATIVE_ID_SIZE + 1];
				double predicted_ctr;
				long pixel_id;
				long spixel_id; //super pixel id
				long indirect_ad_tag_id;
				long ad_server_id;
				long defaulted_adserver_id;
				double ecpm; //original paid ecpm.
				double auxn_ecpm; //ecpm used for the auction(gross ecpm value if depritization enabled else paid ecpm value)
				double pbmt_ecpm;
				double cpc_value;
				int frequency;
				int def_net_frequency;
				int impr_cap_flag;
				int width;
				int height;
				unsigned long ad_size_id;
				int default_handled; /* flag to indicate whether ad request was for default handling */
				long ad_server_optimizer_id;
				char unique_id[MAX_UNIQUE_ID_LEN];
				//char user_guid[MAX_UNIQUE_ID_LEN];
				char page[MAX_PAGE_STR_LEN];
				//char browser[MAX_BROWSER_NAME_LEN];
				char bg_color[MAX_COLOR_STR_LEN];
				char border_color[MAX_COLOR_STR_LEN];
				char link_color[MAX_COLOR_STR_LEN];
				char url_color[MAX_COLOR_STR_LEN];
				char text_color[MAX_COLOR_STR_LEN];
				char frame_name[MAX_FRAME_NAME_LEN];
				long  time_stamp;
				char random_number[MAX_RANDOM_NUMBER_LEN];
				long activity_id;
				char activity_param[MAX_ACTIVITY_PARAM_LEN];
				char *zone;
				int is_https_request_flag;
				char *blocked_pixel_list; // format pixelID:numberOfTimesBlocked, ....
				char aud_segment[MAX_USER_SEGMENT_LIST_SIZE + 1];
				int winning_buyer_id;
				int winning_deal_id;
				//MOBILE PARAM
				int mobile_request_type;
				int is_mobile_app;
				int model_id;
				int os_id;
				int carrier_id;
				char msdk_version[MAX_MOBILE_SDK_VERSION_LEN];	
				//udid type
				char udid_type[MAX_UDID_TYPE_LEN + 1];
				/* NetType : wifi, carrier */
				char mobile_nettype[MAX_MOBILE_NETTYPE_LEN + 1];
				// Publisher provided country
				char country[MAX_COUNTRY_LEN + 1];
				//~ MOBILE PARAM
				//direct default tracking
				long direct_defaulted_adserver_id;
				int direct_default_tracking;
				//~direct default tracking

				/* 
				 * Adding defaulted campaign parameters for tracking, these will be tracked only
				 * if defaulted_campaign_id is non zero i.e campaign defaulted in last ad call.
				 */

				/* It will have ID of last defaulted campaign. */
				long defaulted_campaign_id;

				/* It will have the publisher ecpm of last defaulted campaign. */
				double defaulted_ecpm;

				/* It will have the campaign price of last defaulted campaign. */
				double defaulted_actual_ecpm;
				int df_nw_cnt;
				df_network_list_t df_nw_list[MAX_MOBILE_NETWORKS];
				/* The defaulted S2S AdFlex campaigns*/
				int df_nw_s2s_adflex_cnt;
				df_network_s2s_adflex_list_t df_nw_s2s_adflex_list[MAX_MOBILE_NETWORKS];
				long def_indirect_ad_id;
} ad_served_tracking_params_t;

typedef struct adsize{
  int ad_size_id;
  int ad_height;
  int ad_width;
} adsize_t;

/* Only required parameters for serving ads */
typedef struct publisher_site_ad {
				unsigned long ad_id; /* AD ID */
				unsigned long publisher_id; /* Publisher ID */
				unsigned long site_id; /* Site ID */
				unsigned long aso_type_id; /* ASO type ID */
				unsigned long ad_type_id; /* AD type ID */
				unsigned long ad_geo_level; /* AD GEO Level */
				unsigned long ad_size_id;
				unsigned long default_handling_threshold; /* AD type ID */
				int fold_placement_id; /*Fold Placement id */
				int ad_expansion_direction_id; /* Ad Expansion direction. */
				int platform_id;
				int refresh_rate;
				int prefetch_enabled;
				int rtb_skip_percentage;
				int device_type_targeting_enabled;
				int multi_adsize_count;
				adsize_t ad_dimensions_from_tag[AD_DIMENSIONS_COUNT];
				unsigned long primary_ad_size_id; //copy of ad_size_id. ad_size_id may get changed if multi size enabled RTB campaign wins
				/* multi_level_auction_enabled is header_bidding_enabled
				* - 1: publisher / publisher-site sends impression through header bidding tag level based
				* - 0: otherwise
				*/
				int multi_level_auction_enabled; /* MLA flag for header bidding extention*/
} publisher_site_ad_t;

/* OLD Native Protocol Implementation */
typedef struct native_params {
				char api_ver[MAX_NTV_API_VERSION_LEN + 1];
				char admsupport[MAX_NTV_ADMSUPPORT_LEN + 1];
				int icon_img_selected;
				int cover_img_selected;
				int title_selected;
				int desc_selected;
				int cta_selected;
				char parsed_admsupport[MAX_NTV_PARSED_ADMSUPPORT_LEN + 1];
				char imgratio[MAX_NTV_IMGRATIO_LEN + 1];
				long seq_num;
				char icon_size[MAX_NTV_ICON_SIZE_LEN + 1];
				char img_size[MAX_NTV_IMG_SIZE_LEN + 1];
				int title_len;
				int desc_len;
				int cta_len;
				int get_native_in_post;
} native_params_t;


typedef struct native_attributes_config {
				char native_object[MAX_NATIVE_ASSET_LEN + 1];
				char native_html_template[MAX_NATIVE_CREATIVE_LEN + 1];
				int is_adm_support;
} native_attributes_config_t;

typedef struct ad_dimension_limit{
				int hmin;
				int hmax;
				int wmin;
				int wmax;
}ad_dimension_limit_t;

/*
 * structures to support pmp object through openrtb integration
 */
#define PUB_MAX_DEALS 60
//below macro size need to be changed if other field in deal is added 
#define PUBREQ_DEAL_JSON_MAX_SIZE ((MAX_DEAL_ID_LEN + 25) * PUB_MAX_DEALS ) + 64 
typedef struct publisher_request_deal  {
	char id[MAX_DEAL_ID_LEN + 1];
}publisher_request_deal_t;

typedef struct publisher_requested_pmp{
	publisher_request_deal_t  *deals[PUB_MAX_DEALS];
	int ndeals; //number of deals
}publisher_requested_pmp_t;

/*
 * Consumer partner mapping data for campaign
 * To store data from DB
 */
typedef struct consumer_partner_campaign_map{
	char partner_source[MAX_CONSUMERID_SOURCE_LEN+1];
	bool send_consumer_id;
	int ortb_version_to_use;
}consumer_partner_campaign_map_t;

/* Ad Request UID
 * pixel-uid pairs obtained from the Ad Request query parameters.
 */

#if defined (UID_TEST) || defined (DEBUG)
#define UID_DEBUG(fmt, ...)  \
        do { fprintf(stderr, "\nUID_TEST:D: " fmt "  %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__); } while (0);
#else
#define UID_DEBUG(fmt, ...)
#endif // UID_TEST ends

#define UID_ERROR(fmt, ...)  \
        do { fprintf(stderr, "\nUID_TEST:E: " fmt "  %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__); } while (0);

#define MAX_AD_REQ_UIDS_VALUE_LEN 2047

#define MAX_USER_IDENTIFIER_LEN 127
typedef struct pixel_uid {
        long pixel_id;
        char uid[MAX_USER_IDENTIFIER_LEN + 1];
} pixel_uid_t;

// XXX: If MAX_PIXEL_UID_LEN need to be increased beyond 64, it might make
// sense to revisit the associated algorithm.
#define MAX_PIXEL_UID_LIST_LEN 64
typedef struct pixel_uid_list {
        pixel_uid_t px_uid[MAX_PIXEL_UID_LIST_LEN];
        unsigned int len;
} pixel_uid_list_t;

typedef struct app_info{
	char store_url[MAX_DOMAIN_NAME_LENGTH + 1];
	char store_url_orig[MAX_DOMAIN_NAME_LENGTH + 1];
	/*Application Name*/
	char application_name[MAX_APPLICATION_NAME + 1];
	/* Application ID on the exchange (Only in case of app view). */
	char application_id[MAX_APPLICATION_ID + 1];
	char application_id_orig[MAX_APPLICATION_ID + 1];
	/* Application version */
	char application_version[MAX_APPLICATION_VERSION + 1];
	/* Application bundle (e.g., com.foo.mygame) */
	char application_bundle[MAX_APPLICATION_BUNDLE_LEN + 1];
	char application_bundle_orig[MAX_APPLICATION_BUNDLE_LEN + 1];
	/*Application API*/
	char application_api[MAX_APPLICATION_API_LEN +1];
	char iab_category[MAX_CATEGORY_LEN+1];
	char app_domain[MAX_DOMAIN_NAME_LENGTH + 1];     
	char appstore_category[MAX_CATEGORY_LEN + 1];
	char appstore_category_encoded[MAX_CATEGORY_LEN + 1];

	/* 1 if the application is a paid version; else 0 (i.e., free) */
	int is_paid_application;
	int application_publisher_override;

	app_id_type_t app_id_type;
	char app_sectioncat[MAX_CATEGORY_LEN + 1];
        char app_pagecat[MAX_CATEGORY_LEN + 1];
        char keywords[DEFAULT_LEN_256 + 1];
        char keywords_encoded[DEFAULT_LEN_256 + 1];
        int privacypolicy;
}app_info;

typedef struct geo_obj_info {
	char location[MAX_MOBILE_DEVICE_LOCATION_LEN + 1];
	int loc_source;
	char city[MAX_AD_USER_CITY_LEN + 1];
	char dma[MAX_DMA_LEN + 1];
	char state[MAX_STATE_LEN + 1];
	char zip_code[MAX_ZIP_CODE_LEN + 1];
	char country[MAX_COUNTRY_LEN + 1];
	int utcoffset;
	int accuracy;
        int lastfix;
        int ipservice;
} geo_obj_info_t;

#define MAX_MOBILE_DEVICE_FIELD_STR_LEN 64
typedef struct device_obj_info { //Add all further device fields here
	geo_obj_info_t geo; //geo details related to device 
	char hwv[MAX_MOBILE_DEVICE_FIELD_STR_LEN +1];
	int h;
	int w;
	int ppi;
	double pxratio;
	int geofetch;
	char flashver[DEFAULT_LEN_64 + 1];
	char mccmnc[DEFAULT_LEN_64 + 1];
	int device_type_orig;
	char mobile_device_make_orig[MAX_MOBILE_DEVICE_MAKE_LEN + 1];
	char mobile_device_model_orig[MAX_MOBILE_DEVICE_MODEL_LEN + 1];
	char mobile_device_os_orig[MAX_MOBILE_DEVICE_OS_LEN + 1];
	char mobile_device_os_version_orig[MAX_MOBILE_DEVICE_OS_VERSION_LEN + 1];
} device_obj_info_t;

typedef struct user_obj_info {
	geo_obj_info_t geo; //User related geo details
} user_obj_info_t;

typedef struct ad_server_req_param {
  long oper_id;
  long publisher_id;
  char orig_publisher_id[MAX_ORG_PUBID_LENGTH + 1];//pubid of publisher passed in opubid param. This is publisher.id field of ortb request at translator
  long site_id;
  long ad_id;
  int multibid_req;
  long selected_adserver_id;
  int ad_tag_type;
  int ad_height;
  int ad_width;
  ad_dimension_limit_t ad_size_limit;
  char rich_media_protocol[RICH_MEDIA_PROTOCOL_LEN+1];

  int defaulted_adserver_id;
  int force_adnetwork;
  char *adhistory;
  int n_adtags_on_page;
  int n_campaign_tag_count;/* will be used in new approach*/
  /* is_phoenix_request flag is used to mark the request as Phoenix/UAS request. Values, 1=Phoenix Req, 0=SSP req*/
  int is_phoenix_request;
  char phx_impr_id[MAX_UNIQUE_ID_LEN];
  char *page_url;
  char *non_decoded_page_url;
  char *frame_name;
  char *bg_color;
  char *text_color;
  char *link_color;
  char *time_stamp;
  char *random_number;
  char *timezone;
  char *screen_resolution;
  char *ad_position;
  int debug_flag;
  int ad_impression_debug_flag;
  int wakanda_key;
  int wakanda_enabled;
  /*is iframe based tag*/
  int inIframe;
  /* Is tag is served in more than one nested iframes? */
  int in_multiple_nested_Iframes;
  int s_fold_position_id;
  char *zone;
  double gross_dynamic_floor_ecpm;/* gross dynamic floor */
  double incoming_dynamic_floor_ecpm;/* incoming floor in request */
  decision_manager_price_point_t dm_floor;
  char *publisher_beacon;
  char *dynamic_page_url;
  char *orig_dynamic_page_url;
  int is_https_request_flag;
  int is_https_derived;
  //Parameter used in case of PubMatic API to determine the response type. 0,1= JSON 2= JSONP Callback Function 
  int res_type;
  //Parameter used in case of PubMatic API JsonP response to identify the request.
  //long rid;
  char rid[MAX_RID_LEN + 1];
  /* Mobile Targetting parameters */
  //OS Id from the PubMatic Master OS List
  int os_id;
  int os_type_id;
  //Make Id from the PubMatic Master Make List
  int make_id;
  //Model Id from the PubMatic Master Model List
  int make_model_id;
  int inv_source;
  int phone_type; // smart or feature?
  int browser_id; // browser_id id
  int supports_iframe;// supports iframe or not
  int pointing_method; // pointing method
  int has_qwerty_keyboard; // pointing method
  int supports_video_streaming; // supports video streaming
  int is_tablet;
  int has_built_in_camera;
  int flash_lite_version;
	char brv[MAXVERSIONLEN + 1];

  //MObile Carrier Id 
  int carrier_id;
  //Flag:0 non mobile request 1:Mobile App Request 2:Mobile Web Request
  int mobile_request_type;
  //Stroes os_name in case of mobile web
  //	char *os_name;
  //Stores the concatenated major and minor version. (major.minor)
  //	char *os_version;
  int timeout;   	// Publishers who want us to respond in specific time. Added in context of Glam.
  int adindex;	// When timing out this variable helps in finding which particular adindex time out incase of multiple adindexes.
  char *uni_ad_id;
  int sa_version;	//This variable is used to identify the version of showad.js 
  int avoid_frame_default; /* Flag to indicate if defaulting via iframe */
  int ga_id;		// Guaranteed AdServer Id eg. Dart,AdTech etc
  int ga_site_id;		// Guaranteed AdServer Site Id
  int ga_section_id;	// Guaranteed AdServer Section Id
  long ga_ad_id;	// placement id i.e. id of the actual ad-unit to which a banner (creative) is booked(used in case of guaranteed AdServing[eg. AdTech])

  /* Campaign default handling parameters */

  /* Flag to tell if old default ad tag came into use in an ad call(current or previous) */
  int old_def_tag;

  /* Count of elements in a default list. */	
  int ndefaults;

  /*
   * Flag to determine if a generic default ad tag has been set up for a
   * publisher who does have generic default enabled. If it is set then
   * we need to give an impression to guaranteed delivery network/campaign.
   */
  int noinfo;
  /* Campaign default handling parameters end */

  int original_oper_id;

  /*publisher click tracking support*/
  char pubclkurl[MAX_PUBLISHER_URL_LENGTH];

  /* Parameter to decide whether to append the sync up call in the response. 
     Used only in case of API, sync=1 -> iframe response, sync=2 -> script*/
  int sync;
  int malD;
  /* "sitecode" passed in Ad requset instead of dynamic page url*/
  char site_url_id[MAX_SITE_URL_ID_LENGTH +1];
  // (_ktk_)
  /* SHA1 hashed device ID; IMEI when available, else MEID or ESN. */
  char device_id[MAX_HASHED_DEVICE_ID_LEN + 1];
  char device_id_udid_orig[MAX_HASHED_DEVICE_ID_LEN + 1];
  char device_id_dpid_orig[MAX_HASHED_DEVICE_ID_LEN + 1];
  /* SHA1 hashed platform-specific ID (e.g., Android ID or UDID for iOS). */
  char platform_specific_id[MAX_SHA1_HASHED_PLATFORM_SPECIFIC_ID_LEN + 1];
  /* Country derived from the IP address using ISO-3166-1 Alpha-3. */
  char country[MAX_COUNTRY_LEN + 1];
  /* User language */
  char usr_lang[MAX_USER_LANGUAGE_LEN + 1];
  /* Carrier or ISP derived from the IP address. */
  char mobile_carrier[MAX_MOBILE_CARRIER_LEN + 1];
  /* NetType : wifi, carrier */
  char mobile_nettype[MAX_MOBILE_NETTYPE_LEN + 1];
  /* Device make (e.g., Apple). */
  char mobile_device_make[MAX_MOBILE_DEVICE_MAKE_LEN + 1];
  /* Device model (e.g., iPhone). */
  char mobile_device_model[MAX_MOBILE_DEVICE_MODEL_LEN + 1];
  /* Device Operating System (e.g., iOS). */
  char mobile_device_os[MAX_MOBILE_DEVICE_OS_LEN + 1];
  /* Device operating system version (e.g., 3.1.2). */
  char mobile_device_os_version[MAX_MOBILE_DEVICE_OS_VERSION_LEN + 1];
  /* Device type Tablet, Feature Phone, Smart Phone */
  int device_type_id;
  /*device type 0 for mobile or tablet 1 for personal computer and 2 for smart tv */
  int device_type;
  /* 1 if the device supports JavaScript; else 0. */
  int js_enabled;
	int js_enabled_orig;
  /* Lat/Long as -999.99,-999.99 (i.e., south and west are negative). */
  char mobile_device_location[MAX_MOBILE_DEVICE_LOCATION_LEN + 1];
  char mobile_device_location_to_log[MAX_MOBILE_DEVICE_LOCATION_LEN + 1]; //Incase of GDPR PM-NO-CONSENT we keep the backup here
  char viewabilityvendors[MAX_VIEWABILITYVENDORS_LEN  + 1];
	char metric[MAX_METRIC_LENGTH + 1];

  /* Year of birth as a 4-digit integer. */
  char year_of_birth[MAX_YEAR_OF_BIRTH_LEN + 1];
  /* Gender as M male, F female, O other (We are fair to all :)). */
  char gender[MAX_GENDER_LEN + 1];
  /* Home zip code if USA; else postal code. */
  char zip_code[MAX_ZIP_CODE_LEN + 1];
  /* Comma separated list of keywords of consumer interests or intent. */
  char keywords[MAX_KEYWORDS_LEN + 1];
  /* Minimum compliance level required. */
  int min_compliance_level_required;
  /* Ad orientation Id for given ad request. */
  int ad_orientation_id;
  /* Device orientation Id. */
  int device_orientation_id;
  /* Number of times ad is refreshed per minute. */
  float ad_refresh_rate;
  /* Set to 1 if all mandatory params have been passed. */
  //int enabled;
  /* SDK ID (0= for mobile browser, non zero for PubMatic SDK)*/
  int is_mobile_app;
  /* Version string of mobile SDK */
  char msdk_version[MAX_MOBILE_SDK_VERSION_LEN + 1];
  /*The city name*/
  char city[MAX_AD_USER_CITY_LEN +1];
  /*The dma*/
  char dma[MAX_DMA_LEN +1];
  /*State*/
  char state[MAX_STATE_LEN];
  /*Ethnicity*/
  char ethnicity [MAX_ETHNICITY_LEN];
  /*User Income*/
  char income[MAX_INCOME_LEN];
  // geo source type 
  int geo_source_type;
  unsigned long landing_page_crc[MAX_COOKIE_COUNT_FOR_CRC_BLOCKING];
  int landing_page_crc_count;
  //udid type
  char udid_type[MAX_UDID_TYPE_LEN];
  //VIDEO PARAMETERS
  video_param_t video_params;

  //iframe depth
  int iframe_depth;

  // Do not set USERID cookie if flag is set
  int dnt_set_uid;
  //AdTruth data
  adtruth_data_t adtruth_data;
  //adtruth user_id
  char partner_uid[MAX_PARTNER_KEY_SIZE + 1];
  char pubmatic_uid[MAX_USERID_LEN + 1];
  char pubmatic_uid_browser_cache[MAX_USERID_LEN + 1];
  //API dnt flag
  int request_dnt_flag;
  //first party cookie disabled
  int fpcd;
  // is mshowad.js request
  int is_mshowad_req;

  publisher_site_ad_t *site_ad;
  // if site is COPPA Compliant
  int is_coppa_compliant;
  int chd;  // chunck header disable flag 
  int wrap_api_tracker_call;
  int http_error_code; // The http error code to be returned for API publishers
  /*This field is populated from Ad impression(field IAB_CATEGORY).
    But if appstore category(APPSTORE_CATEGORY) is avaiable in impression then 
    corresponding IAB categories of the appstore category will be consumed. 
    Fields in request: APPSTORE_CATEGORY "cat"
    IAB_CATEGORY      "iabcat"
    */
  /*This field is populated from Ad impression(field IAB_CATEGORY)*/
  char pubsite_iab_category[MAX_CATEGORY_LEN + 1];
  float adserver_load_fraction;	//Current load on AdServer in the range of 0 to 1
  int udid_hash;
  int loc_source;
  /* OLD Native Protocol Implementation
     native_params_t in_native_params;
     */
  char native_asset[MAX_NATIVE_ASSET_LEN + 1];
  char native_html_template[MAX_NATIVE_CREATIVE_LEN + 1];
  int ad_type;
  //Rich Media params.. Adding here because some of them are generic
  char blocked_creative_attr[MAX_BATTR_LEN + 1]; //Received runtime
  int battr_len;
  unsigned long blocked_richmedia_creative_attr_map;
  char rich_media_technologies[MAX_RMT_LEN + 1]; //list of iframebuster technologies
  int rmt_len;
  char ad_expansion_direction[MAX_AED_LEN + 1];  //list of possible ad expansion directions
  int aed_len;
  decision_manager_price_point_t dm_campaigns[MAX_SIZE_DYNAMIC_FLOOR_ARRAY];
  int no_of_dm_floors;
  char verizon_id[MAX_HASHED_DEVICE_ID_LEN + 1];
  int ad_inspector_flag;
  char loc_category[MAX_LOC_CATEGORY + 1];
  char loc_brand[MAX_LOC_BRAND + 1];
  int loc_cat_src;
  int blk_advt_id_count;
  long int blk_advt_id[MAX_BLOCK_ADV_IDS];
  int blk_domain_id_count;
  long int blk_domain_id[MAX_BLOCK_DOMAIN_IDS];
  int blk_cat_id_count;
  char blk_cat_id[MAX_BLOCK_CATEG_IDS][MAX_IAB_CAT_LEN+1];
  //TODO ASD_784 barkha: add original imprid variable here, get length info
  //original impresssion id
  char or_impr_id[ MAX_UNIQUE_ID_LEN ];
  char skip_ip_bot [ MAX_SKIP_IP_PASSBACK_LEN  ];
  int blk_adv_dom_count;
  char blk_adv_dom[MAX_BLOCKED_ADV_DOM][MAX_ADV_DOM_LEN + 1];
  int blk_adv_dom_json_length;
  char blk_adv_dom_json[MAX_BLOCKED_ADV_DOM_JSON_LENGTH];
  int blk_cat_id_json_length;
  char blk_cat_id_json[MAX_BLOCKED_CATEG_IDS_JSON_LENGTH];
  int force_pre_filter_logging;

  //Following parameters are added for IAC integration. As of now these
  //parameter wil be used in logging only
  char *pubUID;
  char *fpVisSeg;
  char *fpInvSeg;
  char *fpCkSeg;

  //Used to check if app data is present or not
  int unknown_app;
  int intl;

  char anonymized_sitedomain[MAX_DOMAIN_NAME_LENGTH];

  ctr_patam_t deal_ctr[MAX_CTR_PARAM_COUNT];
  int ndeal_ctr;
  char dkeyval[MAX_CTR_LEN  + 1];
  native_request_t native_request;
  char *kadpubuid; //publisher's unique identifire that publisher will send in ad call; separate from pubUID
  char impression_currency[MAX_CURRENCY_CODE_SIZE];
  int currency_id;

  int lmt; //limit ad tracking flag

  /* uids
   * The list of pixel and user identifiers received in the ad request.
   */
  pixel_uid_list_t uids;

  /* sbih (Send Bid In Header)
   * If set to 1, then send winning eCPM in header (HTTP_HEADER_NAME_SBIH)
   * (along with in body).  Else, only send in body.
   */
  int sbih;
  int is_mobile_device;
  app_info mobile_data;
  char *encoded_final_extracted_url;
  char *decoded_final_extracted_url;
  char decoded_final_extracted_domain[MAX_DOMAIN_NAME_LENGTH];
  char domain_kadpageurl[MAX_DOMAIN_NAME_LENGTH + 1];
  char domain_pageurl[MAX_DOMAIN_NAME_LENGTH + 1];
  char domain_refurl[MAX_DOMAIN_NAME_LENGTH + 1];
  int final_url_used;
  int thread_id;

  //Stores the id of platform from which the request is made.
	int isapp;
  int platform_id;
  int dynamic_platform_id;
  int wurfl_platform_id;
  int req_platform_id;
  int wurfl_js_support;
  int wurfl_appwebview;

  char content_obj_str[MAX_CONTENT_OBJ_STR_LEN + 1];
  char *wrapper_impr_id;
  publisher_requested_pmp_t *pub_pmp_obj; //pmp object passed in request from publisher
  char *pub_deals_json ;//pmp object in json format need to keep to be logged later
  consumer_identifier_t *req_eid_obj;	//consumer identifier object recieved in request
  int debug_is_coredump_on;
  char payment_tagid_chain[MAX_PAYMENT_TAGID_CHAIN_LEN+1]; //payment tag id chain - pchain
  int log_consumer_id;
  int gdpr; /* gdpr param received in request (0/1) */
  char consent[MAX_GDPR_CONSENT_STR_LEN + 1]; /* consent object base64 string receieved in request */
  char eb_cp_list_int[MAX_CP_LIST_STRING_PARAM_LEN + 1]; /* Google EB consented provider list of integers */
  char eb_cp_list_str[MAX_CP_LIST_STRING_PARAM_LEN + 1]; /* Google EB consented provider list of strings */
  /*Added as part of dynamic consent management for DBM ASD-6238 */
  char static_eb_cp_list_int[MAX_CP_LIST_STRING_PARAM_LEN + 1]; /* Google EB consented provider list (integers), static list */
  char dynamic_eb_cp_list_int[MAX_CP_LIST_STRING_PARAM_LEN + 1]; /* Google EB consented provider list (integers), dynamic list (translated) */
  char translated_eb_cp_list_str[MAX_CP_LIST_STRING_PARAM_LEN + 1]; /* Google EB consented provider list of strings, static+dynamic */
  gdpr_consent_req_param_t gdpr_req_params; /* GDPR request params derived */
  int is_default_mapped_req; /*1: Request has default ad_id and site_id mapping,2:any size slot mapped request*/
	device_obj_info_t device_obj;
	user_obj_info_t user_obj;
	int is_metric_obj;			//  This will be used in logging. 1 if metric_obj comes in request otherwise 0;
	int is_metric_viewability; // This will be used in logging. 1 if metric_obj contains viewabilty type
	int is_inmobi_viewability;  //  This will be used for inmob logging. 1 if inMob sends viewablity in request otherwise 0;
  int req_tmax; /* tmax received in request */
  int db_tmax; /* tmax set in DB */
  int dynamic_auction_type; /* at=1 means 1P, at=2 means 2P, default=-1 */
  int trswt; /* translator waiting time */
	int connectiontype;
	char omidpn[DEFAULT_LEN_64 + 1];
	char omidpv[DEFAULT_LEN_64 + 1];
	char displaymanager[DEFAULT_LEN_64 + 1];
	char displaymanagerver[DEFAULT_LEN_64 + 1];
	int schain_complete; /* Supply Chain 'complete' flag */
	char schain_nodes_str[MAX_SUPPLY_CHAIN_NODES_OBJECT_STR + 1]; /* Supply Chain 'nodes' JSON object in url encoded string format */
	char schain_pubmatic_asi[MAX_SSP_NAME_LEN + 1]; /* Supply Chain 'asi' attribute value for PubMatic */
	char schain_version[MAXVERSIONLEN + 1]; /* Supply Chain version */
	schain_parsing_status_t schain_parse_status; /*schain_parse_status has 3 possible values. -1 for SCHAIN_PARSING_NOT_DONE, 0 for SCHAIN_PARSING_SUCCESS, 1 for SCHAIN_PARSING_FAILED */
	bapp_info_t bapp_info;
	btype_info_t btype_info;
	char google_query_id[MAX_GOOGLE_QUERY_ID_LEN + 1]; /* This will hold url-decoded value of google query id */
	char invalid_msize[DEFAULT_LEN_256];
} ad_server_req_param_t;

typedef struct wurfl_data{

	int os_id;
	int make_id;
	int model_id;
	int browser_id;
	int supports_iframe;
	int pointing_method;
	int supports_video_streaming;
	int has_built_in_camera;
	int has_qwerty_keyboard;
	int is_tablet;
	int is_mobile_device;
	int platform_id;
	int is_appwebview;
	int js_support;
	char brv[MAXVERSIONLEN + 1];
	int total;

}wurfl_data_t;


typedef struct soft_floor_info{
				int publisher_id;
				int site_id;
				double soft_floor;
				int currency_id ;
}soft_floor_info;

typedef struct hard_floor_info{
				int publisher_id;
				int site_id;
				double hard_floor;
				int currency_id ;
}hard_floor_info;

typedef struct iab_category_info{
				int platform_id;
				char appstore_category[MAX_CATEGORY_LEN + 1];
				char iab_category[MAX_CATEGORY_LEN + 1];
}iab_category_info;

typedef struct ad_server_req_gen_param {
				char browser[MAX_BROWSER_NAME_LEN];
				char accept_lang[MAX_ACCEPT_LANGUAGE_NAME_LEN];
				char user_guid[MAX_UNIQUE_ID_LEN];
				//Added for PMB::suraj
				char user_partner_guid[MAX_UNIQUE_ID_LEN];
				char unique_id[MAX_UNIQUE_ID_LEN];
				char remote_ip_addr[MAX_IPSTR_LEN+1];
				char masked_ip_addr[MAX_IPSTR_LEN+1];
				char masked_ip_addr_to_log[MAX_IPSTR_LEN+1];
				char xff_ip_addr[MAX_IPSTR_LEN+1];
				char xff_masked_ip_addr[MAX_IPSTR_LEN+1];
				char referer_url[MAX_URL_LENGTH];
				int pubmatic_opt_out; //pubmatic opt out value can true(1) or false (0). if its true then donot track user
				int dnt_opt_out_req_value; // HTTP_DNT read from browser
				int dnt_opt_out; // HTTP_DNT value & g_honor_dnt_flag
				time_t server_timestamp; // current timestamp of server
				int refresh_freq_time_window_mins; //time window in minutes for which fcap is restricted, it is used to set expiry of pubtime_ cookie. If pubtime_ cookie is absent, frequency counter shoud get reset in pubfreq_ cookie for site-netowrk
} ad_server_req_gen_param_t;

/* this is the size of encoded string for the below strcture, KINDLY CHANGE WHENEVER STRUCT SIZE CHANGES */
//#define ENCODESTR_MIN_LEN 202
#define ENCODESTR_MIN_LEN 192 
struct ad_clicked_params {
				int publisher_id;
				int site_id;
				int ad_id;
				int campaign_id;
				int creative_id ; // must be INT
				int indirect_ad_tag_id;
				int ad_server_id;
				int ad_size_id;
				char user_guid[MAX_UNIQUE_ID_LEN];
				//MOBILE PARAM
				int mobile_request_type;
				int is_mobile_app;
				int model_id;
				int os_id;
				int carrier_id;
				char msdk_version[MAX_MOBILE_SDK_VERSION_LEN];	
				//~ MOBILE PARAM
				/*publisher click url support*/
				char pubclkurl[MAX_PUBLISHER_URL_LENGTH];
				long tld_id;
				impression_passback_reason_t passback_flag;
				char impression_id[MAX_UNIQUE_ID_LEN];
				int pmc; /* pubmatic consent for GDPR */
} __attribute__((packed));

typedef struct ad_clicked_params ad_clicked_params_t;

typedef struct user_data{

				char user_agent[MAX_BROWSER_NAME_LEN + 1];
				char user_guid[MAX_UNIQUE_ID_LEN + 1];
				char user_ip[MAX_IPSTR_LEN + 1];
				long geo_id;
				int dma_code;
				char country_code[MAX_GEO_CODE_LEN + 1];
				char region_code[MAX_GEO_CODE_LEN + 1];
				char city[MAX_GEO_NAME_LEN + 1];
				char postal_code[MAX_GEO_POSTAL_CODE_LEN + 1];
}user_data_t;

typedef struct impression_receipt{
				long oper_id;
				long publisher_id;
				long site_id;
				long ad_id;
				long campaign_id;
				long creative_id;
				char crId[MAX_CREATIVE_ID_SIZE + 1];
				double predicted_ctr;
				long pixel_id;
				long spixel_id; //super pixel id
				long indirect_ad_tag_id;
				long ad_server_id;
				long defaulted_adserver_id;
				double ecpm; //original paid ecpm.
				double auxn_ecpm; //ecpm used for the auction(gross ecpm value if depritization enabled else paid ecpm value)
				double pbmt_ecpm;
				double cpc_value;
				int frequency;
				int def_net_frequency;
				int impr_cap_flag;
				int width;
				int height;
				unsigned long ad_size_id;
				int default_handled; /* flag to indicate whether ad request was for default handling */
				long ad_server_optimizer_id;
				char unique_id[MAX_UNIQUE_ID_LEN];
				//char user_guid[MAX_UNIQUE_ID_LEN];
				char page[MAX_PAGE_STR_LEN];
				char decoded_page[MAX_PAGE_STR_LEN];
				//char browser[MAX_BROWSER_NAME_LEN];
				char bg_color[MAX_COLOR_STR_LEN];
				char border_color[MAX_COLOR_STR_LEN];
				char link_color[MAX_COLOR_STR_LEN];
				char url_color[MAX_COLOR_STR_LEN];
				char text_color[MAX_COLOR_STR_LEN];
				char frame_name[MAX_FRAME_NAME_LEN];
				long  timestamp;
				char random_number[MAX_RANDOM_NUMBER_LEN];
				long activity_id;
				char activity_param[MAX_ACTIVITY_PARAM_LEN];
				char *zone;
				int is_https_request_flag;
				char *blocked_pixel_list; // format pixelID:numberOfTimesBlocked, ....
				char aud_segment[MAX_USER_SEGMENT_LIST_SIZE + 1];
				int winning_deal_id;
				int winning_buyer_id;
				//MOBILE PARAM
				int mobile_request_type;
				int is_mobile_app;
				int model_id;
				int os_id;
				int carrier_id;
				char msdk_version[MAX_MOBILE_SDK_VERSION_LEN];	
				//udid type
				char udid_type[MAX_UDID_TYPE_LEN + 1];
				/* NetType : wifi, carrier */
				char mobile_nettype[MAX_MOBILE_NETTYPE_LEN + 1];
				char country[MAX_COUNTRY_LEN + 1];
				//~ MOBILE PARAM
				//direct default tracking
				long direct_defaulted_adserver_id;
				int direct_default_tracking;
				//~direct default tracking

				/* 
				 * Adding defaulted campaign parameters for tracking, these will be tracked only
				 * if defaulted_campaign_id is non zero i.e campaign defaulted in last ad call.
				 */

				/* It will have ID of last defaulted campaign. */
				long defaulted_campaign_id;

				/* It will have the publisher ecpm of last defaulted campaign. */
				double defaulted_ecpm;

				/* It will have the campaign price of last defaulted campaign. */
				double defaulted_actual_ecpm;
				int df_nw_cnt;
				df_network_list_t df_nw_list[MAX_MOBILE_NETWORKS];

				/*The defaulted S2S AdFlex campaign list*/
				int df_nw_s2s_adflex_cnt;
				df_network_s2s_adflex_list_t df_nw_s2s_adflex_list[MAX_MOBILE_NETWORKS];

				long def_indirect_ad_id;
				char *click_data;
				int tc0;
				int tc1;
				int tc2;
				ad_clicked_params_t click_params;
				int datacenter_id;
				user_data_t user_data;
				long tld_id;
				impression_passback_reason_t passback_flag;
				int page_categories_used;
				int ias_score;
				char impr_unique_id[GUID_LEN + 1];
				char domain_name[MAX_PUBLISHER_URL_LENGTH + 1];
				char site_code[MAX_SITE_URL_ID_LENGTH + 1];
				char landing_pg_url[MAX_RESPONSE_URL_SIZE + 1];
				//TODO ASD_784 barkha: check if GUID + 1 needed here
				char or_impr_id[ MAX_UNIQUE_ID_LEN ];
				uint64_t feature_bit_set;
				int bitmap_third_p_pixel;
} impression_receipt_t;

typedef struct video_receipt {

				long oper_id;
				long publisher_id;
				long site_id;
				long ad_id;
				int event_id;
				long campaign_id;
				long adserver_id;
				long defaulted_adserver_id;
				long defaulted_campaign_id;
				//double pub_ecpm; //original paid ecpm.
				//double pbmt_ecpm;
				//	char page[MAX_PAGE_STR_LEN];
				//char decoded_page[MAX_PAGE_STR_LEN];
				long timestamp;
				user_data_t user_data;
}video_receipt_t;


struct ad_clicked_params_old {
				int publisher_id;
				int site_id;
				int ad_id;
				int campaign_id;
				int creative_id;
				double cpc_value;
				int indirect_ad_tag_id;
				int ad_server_id;
				int width;
				int height;
				int ad_size_id;
				int default_handled; // flag to indicate whether ad request was for default handling 
				int ad_server_optimizer_id;
				char user_guid[MAX_UNIQUE_ID_LEN];
				char bg_color[MAX_COLOR_STR_LEN];
				char border_color[MAX_COLOR_STR_LEN];
				char link_color[MAX_COLOR_STR_LEN];
				char url_color[MAX_COLOR_STR_LEN];
				char text_color[MAX_COLOR_STR_LEN];
				//MOBILE PARAM
				int mobile_request_type;
				int is_mobile_app;
				int model_id;
				int os_id;
				int carrier_id;
				char msdk_version[MAX_MOBILE_SDK_VERSION_LEN];	
				//~ MOBILE PARAM
} __attribute__((packed));

typedef struct ad_clicked_params_old ad_clicked_params_old_t;


struct memcached_blocklist;
struct memcached_publisher_site_iframe_buster_tech;
/* Parasm thats need to be pass to DSPs for serving Rich Media Ads */
typedef struct publisher_site_ad_rich_media_params
{
				/* List of blocked Creative attributes, Creative category & Allowed creative attributes. */
				struct memcached_blocklist *blocked_list;
				/*
				 * Memcached JSON list of iframe buster technologies that have been installed
				 * on Publisher's site along with its length.
				 */
				//struct memcached_publisher_site_iframe_buster_tech *psf_tech_list;
				/* Ad expansion direction. */
				int ad_expansion_direction_id;
} publisher_site_ad_rich_media_params_t;

/*This structure contains  settings for features available to adservers*/
typedef struct publisher_adserver_settings {
				/*Variable passing enable / disable for adserver*/
				int variable_passing_enabled;
} publisher_adserver_settings_t;


/*This structure contains  settings for features available to adflex*/
typedef struct publisher_site_adflex_settings {
				double pubmatic_adflex_cut_percentage;//used to apply fixed pubmatic cut while campaign bidding

				/* reverse_auction_margin
				 * ----------------------
				 * A minimum, fixed PM cut applied for reverse
				 * auction publishers.  This is to ensure that
				 * we get _some_ cut, even if the publisher
				 * closes at the FP.
				 */
				double reverse_auction_margin;

				int pay_second_price_enabled; //used to enable max second price pay out to publisher in RTB floating margin algo
				int pubmatic_variable_margin_enabled; //This flag is used in adflex bidding algo where pubamtic margin is fixed. If this flag is enable then pmatic cut gets
				int platform_id;
				//recalculated for camapign that may get filtered after deducting pubmatic fixed cut 
				double pubmatic_bid_price_threshold; 
				int random_margin_slab;
} publisher_site_adflex_settings_t;

/*This structure contains  settings for features available to AdFlex*/
typedef struct publisher_settings {
				int adflex_active;
				int sitewise_ecpm_biding_disabled;
} publisher_settings_t;

typedef struct psc {
	double margin;
	double pmp_margin;
	/* flag to indicate if for a particular campaign, user data needs to be NOT SENT */
	int disable_user_data_over_rtb;

	/* campaign_throttle_enabled
	 * 1 => throttle publisher-site-campaign.
	 * else => don't throttle.
	 */
	int campaign_throttle_enabled;
	unsigned int zero_margin_bitmap; // Disable margin for pub-site-camp combination
	bool send_pmp_req_only;
	double tech_fee; //fixed fees applicable on CP for open exchange
	double pmp_tech_fee; //fixed fees applicable on CP for open pmp exchange
	int send_origin_pubid_enabled;// did campaign agreed to do passthrough. if 1 then ads.txt filter not applied
	double max_take_rate;
	double fix_take_rate;
	double pmp_max_take_rate;
	double pmp_fix_take_rate;
} psc_t;



typedef struct pub_site_camp_settings {
	int pub_id;
	int site_id;
	int campaign_id;
	psc_t psc;
} pub_site_camp_settings_t;

typedef struct dc_pub_site_camp_settings {
	int campaign_id;
	int one_adsz_mux_count; //mux with single ad-szie
	int multi_adsz_mux_count; //mux with multi ad-size
	int mux_control_bitmap; //features bitmap for which mux is enabled
	int multi_adsz_control_bitmap; //features bitmap for which multi ad size is enabled
} dc_pub_site_camp_settings_t;

typedef struct pub_site_camp {
				pub_site_camp_settings_t* psc_settings;
				int nelements;
				//dc level psc settings
				dc_pub_site_camp_settings_t* dc_psc_settings;
				int dc_nelements;
} pub_site_camp_t;

typedef struct pub_site_buyer_level_settings{
	int pub_id;
	int site_id;
	int buyer_id;
	double margin;
	double pmp_margin;
	double max_take_rate;
	double pmp_max_take_rate;
	double fix_take_rate;
	double pmp_fix_take_rate;
} pub_site_buyer_level_settings_t;

typedef struct pub_site_buyer_settings{
	int nelements;
	const pub_site_buyer_level_settings_t *pub_site_buyer_level_settings;
}pub_site_buyer_settings_t;

typedef struct site_verticals {
				char iab_vertical[MAX_IAB_CAT_LEN];
				int iab_vertical_id;
}site_verticals_t;

/*This structure contains settings frem publisher_level_settings */
typedef struct publisher_level_settings {
	int pmp_enabled;     //enable - disable flag for pmp floor rules for publisher site
	int rtb_creative_review_enabled; // enable - disable flag for creative filter for publisher site
	int default_creative_preference; // Default preference of publishe. 1=Blacklist, 2=Whiltelist
	int cookie_store_enabled; //flag indicating weather to call SSCS for RTB,freq,user floors cookies for this publisher.
	int filter_rtb_resp_without_creative_id; //flag indicating weather to filter RTB response with no creative id OR not. This is applicable only if default_creative_preference is BLACKLIST
	int is_aggregator; //flag for publisher aggregator type: 1- indidactes publisher is	aggregator publisher, 0- indicates publisher is not an aggregator pulisher, default value is 0.
	int acl_aggregator_flag; //value feature flag 140 indicates if publisher is aggregator or not. if flag is_aggregator and acl_aggregator_flag both are 1, indicates publisher is aggregator publisher
	int client_auction_enabled;
	int landing_page_filter; // filter bids which don't have landing page URL or landing page TLD
	int skip_logging_params ;    // pub level setting to skip usr_data_string in RTB JSON 
	int gssbl;//Global Supply side blocklist
	int premium_logging_enabled;//Enable premium logging
	int max_allowed_creative_size_kb; //filter RTB bid with creative greater than this size
	int enable_uniq_winning_creative ;
	int append_privacy_compliance_script; //append privacy compl script, 0 for conditional, Non 0:forced,
	double cp_boost_factor;
	int enable_bcc_logging;//brand control creative logging
	//Floor recovery algorithm variables
	int recovery_factor; //factor of impressions in which loss to recover 
	int pub_recovery_percent; //fraction of recovery amout to get from publisher
	// int pub_recovert_precent; //fraction of recovery amout to get from publisher
	int recovery_threshold;	//Max CPM limit for recovery/loss
	int user_privacy;   /*If this flag is 2 then mask IP-address irrespective of user's geo. 
			      If flag is 1 then mask ip address if lookup into DB/cache to mask IP-address.*/
	int is_phoenix_enabled;
	int send_pub_level_stats;  // enable few  publevel stats : A500 ; Impr Count
	int optimize_for_price; // binary flag
	long long op_start_date; // this time is in seconds since epoch
	long long op_end_date;// this time is in seconds since epoch
	bool openrtb_api_enabled; // 1 = publisher is integrated with openRTB. 0 = publisher is integrated with Pubmatic api
	bool dont_send_winning_deal;//if enabled we will not send dealid in response to publisher.
	int preferred_ip_header;
	int gdpr_compliance_enabled; /* If gdpr compliance is enabled for publisher or not */
	int gdpr_consent_given_for_all; /* If enabled, means publisher has given consent for all vendors on user's behalf */
	int disable_gdpr_ip_check; /* If enabled, ip address will not be used in gdpr req identification */
	int enable_gdpr_country_check; /* If 1, region in request will be cross verified if EU or not, along with gdpr param. */
	int send_ucrid_in_response; /* If 1, UCrId will be sent in SSP API response as creative ID */
	int whiteops_caching_enabled; /* If enabled, all WhiteOps calls for this Publisher will go through Varnish cache */
	int video_send_wh_in_response; /* If enabled, Ad Server will send width and height in api response */
	int is_gdpr_map_consent_macros_to_empty; /* If 1, treat it as unknown consent and use the PII; but send empty consent downstrean */
	int is_gdpr_map_consent_macros_pass_asis; /* If 1, treat it as unknown consent and use the PII; but send consents downstrean */
	char company_name[MAX_COMPANY_NAME_LEN +1];//company name of publisher
	int is_mobile_params_pass_asis; /* If 1, treat it as unknown consent and use the PII; but send consents downstrean */
	int badv_domain_feedback_enabled; /* If 1, blocked advertizer domain needs to be send in rtb bid request */
	int enable_pub_syncup_stats; /*Bitwise flag, 1st bit: enable publisher level stats, 2nd bit: enable publisher_campaign_level stats for that publisher*/
	int tmax_enabled; /* 0=tmax feature disabled, 1=tmax feature enabled */
	int avg_adserver_ptime; /* Avg Adserver processing time in milliseconds. if set 0, the global avg time will be referred */
	int max_deal_count_in_bidreq ; //maximum number of deals that can be sent in bidrequests for impressions from this publisher

	/* use_dynamic_auction_type
	 * ------------------------
	 * Whether to refer to "at" to decided which type of auction to
	 * perform (1P or 2P).
	 */
	int use_dynamic_auction_type;
	char ssp_name[MAX_SSP_NAME_LEN +1];
	int log_pmp_deals_enabled;
	int wurfl_enabled_for_all_inventory; /* If this is enabled, then we will make WURFL call for all requests from this publisher */
	int send_supply_chain_object_in_rtb; /* feature flag to send Supply Chain Object in RTB */
	int apply_dsp_buyer_take_rate;
	int enable_bidless_logging; /* Enable bidless logging */
	int full_log_percent_for_bidless_impr; /* Percentage of bidless impressions for which both bidless + full logging is done */
	int rtas_max_creatives_to_send; /* Max number of creatives(per impression) to be sent to RTAS for scanning */
	int user_id_preference; /* Flag to give preference to publisher uid and PubMatic uid. Possible values are 0,1,2,3 */
} publisher_level_settings_t;

/* This structure contains settings from dc_pub_level_settings */
typedef struct dc_publisher_level_settings {
	int network_latency; /* Network latency(in ms) for a given Publisher in the given DC */
	int tmax_value; /* Static timeout(in ms) that Publisher will wait for bid response */
} dc_publisher_level_settings_t;

/* This structure contains settings from dc_level_settings */
typedef struct dc_level_settings {
	int min_rtb_timeout; /* Minimum thresold value (in ms) for RTB timeout */
	int max_rtb_timeout; /* Maximum thresold value (in ms) for RTB timeout */
} dc_level_settings_t;

/* This structure contains the one pair of IAB vendorId, Google EB ProviderId and purposeId */
typedef struct vendor_provider_pair {
	int iab_vendor_id;
	int eb_provider_id;
	int purpose_id_list;
} vendor_provider_pair_t;

/* This structure contains the mapping between IAB vendorIds to Google EB ProviderIds */
typedef struct gdpr_vendor_provider_mapping {
	vendor_provider_pair_t *vp_map;
	int nelements;
} gdpr_vendor_provider_mapping_t;

/* This structure contains the campaign settings for current DC*/
typedef struct dc_camp_settings{
    long campaign_id;
    int enable_qps_logging;
} dc_camp_settings_t;

typedef struct dc_level_camp_settings{
	dc_camp_settings_t *camp_settings;
	int nelements;
}dc_level_camp_settings_t;


/*This structure contains the buyer blocklist*/

typedef struct buyer_block_list {
        int n_elements;
        int *buyers;
} buyer_block_list_t;

/* Only required parameters for serving ads */
typedef struct publisher_site {
				char site_url[MAX_REGISTERED_SITE_NAME_LEN + 1];
				long vertical_id;
				int iab_vertical_count; 
				site_verticals_t* iab_verticals;
				int media_tracking_enabled;
				int edgeside_tracking_enabled;
				int tld_check_enabled; //flag for publisher aggregator type: 1- indidactes publisher is aggregator publisher, 0- indicates publisher is not an aggregator pulisher, default value is 0.
				int support_js;
} publisher_site_t;

/* this is used to store site levl impression cap settings */ 
typedef struct publisher_site_impression_cap {
				unsigned long adserver_id;
				unsigned long impression_cap;
				int icap_dc_awarness_enabled;
				int centralised_icap_enabled;
}publisher_site_impression_cap_t;

/*This will be used to keep track of all site_size_network with icap*/
typedef struct  publisher_site_impression_cap_wrapper{
				publisher_site_impression_cap_t * capped_network;
				int nelements;
}publisher_site_impression_cap_wrapper_t;

/* this is used to store served impression numbers for a site, size and network for a current day*/ 
typedef struct publisher_site_impression_total {
				unsigned long adserver_id;
				unsigned long impression_total;
				int refresh_flag;
}publisher_site_impression_total_t;

/* this used to get total impressions in DC and total impression across DCs */
typedef struct datacenter_daily_impression_total {
				unsigned long dc_daily_impression_total; 
				unsigned long daily_impression_total;
}datacenter_daily_impression_total_t;

/* this is used to store network level impression cap settings */
typedef struct network_impression_cap {
				unsigned long adserver_id;
				unsigned long daily_impression_cap;
				int daily_impression_unlimited_flag;
				unsigned long lifetime_impression_cap;
				int lifetime_impression_unlimited_flag;
				int impression_pacing_flag;
				int icap_dc_awarness_enabled;
				int centralised_icap_enabled;/* 1 means enabled 0 means disabled*/
}network_impression_cap_t;

/* this is used to store network level impression capping settings */
typedef struct network_impression_total {
				unsigned long adserver_id;
				unsigned long day_impression_total;
				unsigned long lifetime_impression_total;
					int refresh_flag; /* this flag will be set only if data is updated from DB to cache*/
	}network_impression_total_t;

	/* used to store pixel mapped to the network in network retargeting */
	typedef struct ad_network_pixel_map {
					unsigned long adserver_id;
					unsigned long pixel_id;
					int found_flag; 
	}ad_network_pixel_map_t;



	/* This is used for reading different third party media scrits from DB */
	typedef struct media_tracking_script {
					char media_script[MAX_MEDIA_SCRIPT_LEN];
					char https_media_script[MAX_MEDIA_SCRIPT_LEN];
	}media_tracking_script_t;

	typedef struct site_to_adserver_site_map {
					unsigned long id; /* site_to_adserver_site_map -- auto increment in database*/
					unsigned long site_id; /*Site ID */
					unsigned long adserver_id; /* Adserver ID */
					char adserver_site_id[MAX_ADSERVER_SITE_ID_LEN + 1];
	} site_to_adserver_site_map_t;

	/* Background color for color rotation */
	typedef struct bk_color {
					char color[MAX_COLOR_STR_LEN]; /* color */
					unsigned int color_class; /* color class */
	} bk_color_t;

	/* Text color for color rotation */
	typedef struct text_color {
					char text_color[MAX_COLOR_STR_LEN]; /* Text color */
					char link_color[MAX_COLOR_STR_LEN]; /* link color */
					unsigned int color_class; /* color class */
	} text_color_t;

	typedef struct fixed_color {
					char border_color[MAX_COLOR_STR_LEN];
					char bg_color[MAX_COLOR_STR_LEN];
					char link_color[MAX_COLOR_STR_LEN];
					char url_color[MAX_COLOR_STR_LEN];
					char text_color[MAX_COLOR_STR_LEN];
	} fixed_color_t;



	typedef struct geo_map{
					int geo_id;
					char geo_code[MAX_GEO_CODE_LEN];
					char geo_name[MAX_GEO_NAME_LEN];
	}geo_map_t;

	typedef struct isp_map{
					int isp_id;
					char isp_name[MAX_ISP_NAME_LEN + 1];
	}isp_map_t;
	typedef struct net_speed_map{
					int id;
					char name[MAX_CONNECTION_NAME_LEN + 1];
	}net_speed_map_t;

	/*maxmind geo data structure*/
	typedef struct alpha2_to_alpha3_map_t{
					char alpha2[ALPHA2_CODE_LEN + 1];
					char alpha3[ALPHA3_CODE_LEN + 1];
	}alpha2_to_alpha3_map_t;


	typedef struct geo_data{
					char country_code[MAX_GEO_CODE_LEN + 1];
					char iso_country_code[MAX_GEO_CODE_LEN + 1]; //this is country code in capital and UK is treated as GB
					char region_code[MAX_GEO_CODE_LEN + 1];
					char city[MAX_GEO_NAME_LEN + 1];
					char postal_code[MAX_GEO_POSTAL_CODE_LEN + 1];
					int dma_code;
					float latitude;
					float longitude;
					char area_code[MAX_AREA_CODE_LEN];
					int geo_id;
					int geo_source_type;
					int country_id; //respective geoID for this country in geo table
					int region_id;  //respective geoID for this region in geo table
					int city_id; //respective geoID for this city in geo table
					int dma_id; //respective geoID for this dma in geo table
	}geo_data_t;

	/*Structure for global level geo blocklist */
	typedef struct geo_id_blocklist{
		int *geo_id_blocklist_ptr;
		int nelements;
	}geo_id_blocklist_t;

	/*Structure for publisher level geo blocklisting*/
	typedef struct pub_geo_blocklist{
		int pub_id;
		geo_id_blocklist_t pub_level_blocked_geo_id;
	}pub_geo_blocklist_t;

	/* Structures for publisher directness map */
	typedef struct publisher_directness_map_node {
		int pub_id;
		int directness;
	} publisher_directness_map_node_t;

	typedef struct publisher_directness_map {
		publisher_directness_map_node_t *map;
		int nelements;
	} publisher_directness_map_t;

	/*geo settings mapping table*/
	typedef struct ad_geo_settings{
					unsigned long publisher_site_ad_id;
					unsigned long publisher_adserver_account_id;
					int geo_id;
					int geo_level;
					char country_code[MAX_GEO_CODE_LEN];
					char region_code[MAX_GEO_CODE_LEN];
					char city[MAX_GEO_NAME_LEN];
					int dma_code;
	}ad_geo_settings_t;

	typedef struct net_frequency {
					int adserver_id;
					int frequency;
					int frequency_time_window;
					int buffer;
	} net_frequency_t;


	typedef struct network_elimination_list {
					int adserver_ids[MAX_NETWORKS_IN_ELIMINATION_LIST + 1];
					int elimination_type[MAX_NETWORKS_IN_ELIMINATION_LIST + 1];
					int reason_for_filtering[MAX_NETWORKS_IN_ELIMINATION_LIST + 1];
					int eliminated[MAX_NETWORKS_IN_ELIMINATION_LIST + 1];
					int nelements;
	}network_elimination_list_t;

	typedef struct total_network_frequency {
					net_frequency_t *total_frequencies;
					int total_freq_network;	
	} total_network_frequency_t;

	/*dss type id map for an ad*/
	typedef struct dss_type_id_map {
					unsigned long dss_type_id; /* dss  type id */
	}dss_type_id_map_t;

	typedef struct site_category {
					int category_id;
					int mapping_type;
	}site_category_t;

	typedef struct site_category_list {
					site_category_t *site_categories;
					int ncategories;
	}site_category_list_t;

	/*this structure contains the publisher pass back network list*/
	typedef struct publisher_passback_list {
					int passback_network_id;
	}publisher_passback_list_t;


	/*ADSERVER MACRO DEFINITION BEGINS HERE*/

	#define MAX_MACRO_LENGTH 40
	#define MAX_VAR_NAME_LENGTH 40
	#define MAX_VAR_VALUE_LENGTH (256 + 1)

	/*macro variable name mapping*/
	typedef struct adserver_macro_variable_name{
					char macro_name[MAX_MACRO_LENGTH];
					char var_name[MAX_VAR_NAME_LENGTH];
					char macro_value[MAX_VAR_VALUE_LENGTH];
					int macro_type_id;
					int macro_name_length;
	}adserver_macro_variable_name_t;

	/*list of adserver_macro_variable_name_t*/
	typedef struct adserver_macro_variable_name_list {
					adserver_macro_variable_name_t *macro_var_list;
					int nmacro;
	}adserver_macro_variable_name_list_t;

	/*ADSERVER MACRO DEFINITION ENDS HERE*/

	// NOTE: All macros here are shifted above in same file. please keep them up only. khemraj 

typedef enum {
	AWT_DEFAULT_DB_VALUE = -1, //default value we set in the db
	AWT_DEFAULT_REQUEST_VALUE = 0, //Tracker & Creative are fired separately (default awt is 0)
	AWT_AS_IFRAME = 1, //Tracker call (iframe) is appended to creative
	AWT_AS_JS_TAG =2 //Tracker call (JS tag) is appended to creative
} override_awt_settings_in_request_t;

//Values that describe to enforce https trackers in case of sec=0?
typedef enum {
	HTTPS_TRACKERS_OFF = 0,
	HTTPS_TRACKERS_DERIVE,
	HTTPS_TRACKERS_FORCE
}enforce_https_trackers_t;

/*
 * enum to keep bit positions corresponds to binary 
 * valued columns from publisher_site_settings table
 * NOTE: This avoids unncessary variable creation in
 * publisher_site_default_settings.feature_flag_bitmap strucure variable
 */
typedef enum {
	PS_BIT_POS_RTB_PASS_GRANULAR_SITE_ID = 0,
	PS_BIT_USE_API_PARAM_FROM_DB,
	PS_BIT_PUB_HAS_NON_FRAUD_INVENTORY,
	PS_BIT_APPLY_RTB_MUX,
	PS_BIT_ENABLE_MULTISIZE_IN_IFRAME,
	PS_BIT_ENABLE_VIDEO_CREATIVE_OPTIMIZATION,
	PS_BIT_CHANGE_NATIVE_IMAGE_TYPE,
	PS_BIT_REVERSE_MAP2_P2_FOR_SP_MLA,
	PS_BIT_SEND_MAX_HEIGHT_WIDTH,
	PS_BIT_PM_HAS_NO_CONSENT_PASSBACK,
	PS_BIT_ENABLE_VAST_4,
	PS_BIT_REVERSE_MAP0_P2_FOR_SP_MLA,
	PS_BIT_USE_DERIVED_PLATFORM_FROM_REQ
} publisher_site_settings_feature_flags_t;

#define SET_PUBLISHER_SITE_FEATURE_BIT(bitval, bitpos) (bitval |= (1u << bitpos))
#define CHECK_PUBLISHER_SITE_FEATURE_BIT(bitval, bitpos) (bitval & (1u << bitpos))

#define IS_PUBLISHER_FPMLA(publisher_auction_type) (AT_PUB_CONF_SECOND_PRICE == publisher_auction_type || AT_PUB_DYNAMIC_SECOND_PRICE == publisher_auction_type)

	typedef struct publisher_site_default_settings {
		int url_hiding_enabled; /*flag indicating pageurl passing is enabled/disabled */
		int pass_pmp_enabled_flag_to_dsp; /*If 1, pass pmp_enabled flag to DSPs o.w. don't pass it. */
		//int force_secure_ad; /*If 1, should only accept creatives from DSPs over HTTPS*/
		int is_ip_address_blocked; /*If 1, IP addressed passing has been blocked by Publisher. */
		int override_referrer_url; /*If 1, Override referrer url which been passed as part of AdServer params. */
		int tracking_beacon_first; /* If 1, Tracker call will be before the network script call */
		int floor_rule_engine_enabled; /* If 1, then floor rule engine is enabled for publisher/site */
		int proactive_tracking_enabled;
		int beacon_tracking_type;
		int filter_uncategorized_advertisers_enabled; /* if 1, filter uncategorised advertisers RTB campaigns  */
		int same_ad_block_enabled;

		/* bid_price_enabled
		 * Does publisher perform SP auction?
		 * 0: Perform SP auction at PubMatic (no SP auction at publisher)
		 * 1: Skip auction at PubMatic (SP auction at publisher);
		 */
		int bid_price_enabled;
		int block_bot_requests;
		int blank_response_on_bot_request;
		int is_coppa_compliant;
		int whitelist_enabled;

		/* edge_side_margin_enabled
		 * Should ADS generate layer call in response
		 * 0: Generate layer call
		 * 1: Don't generate layer call
		 */
		int edge_side_margin_enabled;
		int api_brand_safety_enabled;
		int client_auction_enabled;
		int rtb_timeout;
		int network_dynamic_floor_enabled;
		int creative_syncup_enabled ; 
		int pass_n_block_advt_info_enabled;
		int dm_enabled;
		int mbf_enabled;
		int pf_discount_enabled; //Flag to allow bid above cp for MAP2
		int throttling_enabled;
		int ip_blocklist_disabled;
		double throttling_percent;
		double throttling_threshold;
		double impression_log_perc;
		double mbf_unbiased_impr_percentage;
		double mbf_max_margin;
		int url_block_list_enabled;
		int vast_ext_api_fields_enabled;
		int rm_blocklist_check_method;
		int realtime_domain_enabled;
		int cookieless_mobile_syncup;
		int pubnet_fcap_optimization_enabled;
		int rtf_info;
		double floor_reduction_factor;
		int recovery_algorithm_enabled;
		int cors_enabled;
		int ias_tld_level;
		int skip_platform_override;
		int use_storeurl_for_appid;
		double f2_skip_percentage;
		int rtb_send_hard_floor_enable_percentage;
		int rtb_reduce_hard_floor_percentage;
		int send_pub_camp_winning_logs;
		int use_dynamic_floor;
		int user_bid_price_caching_percent;
		int url_transparency_bitmap;

		double pricing_2_0_percentage; 
		double pi;
		int ltp_rtf_info; // rtf_info for LTP(LONG TERM PRICING)
		int force_pageurl_transparency; // ON if publisher agreed to pass on actual page url in RTB
		int adhoc_random_percentage;
		int multi_adsize_mapping_enabled; // ON, if multi ad size is enabled on publisher/site level.
		int net_bid_response_enabled; //ON, if publisher demands for net price while bidding
		int use_wurfl_platform; //ON, if publisher/site wants us to use platfrom derived from WURFL.
		int enable_pm_vpaid; //ON, if publisher/site wants us to send PubMatic Video Client in S2S Video API response.
		int supported_vast_adparam; //ON, if publisher/site wants us to us send Video Creative Information in AdParameter of VAST Node.
	        int skip_secure_creative_check; // if enabled will skip some of secure URL check for secure inventory on creative
		int prebid_fraud_check_percentage; // Prebid fraud check percentage to control total calls to whiteops at pub_site level
		int encode_video_error_macro; // enable url encoding for video error macro at pub_site level
		unsigned long feature_flag_bitmap; //Bitmap to store enabled/disabled status of multiple features at pub/site level
		int video_creative_buff_size; // video creative buffer size at pub_site level
		override_awt_settings_in_request_t override_awt_from_request; //setting to change value from request of awt parameter. functionality applicable for api publisher only
		enforce_https_trackers_t enforce_https_trackers; // refer to enum enforce_https_trackers_t
		int exclude_unauthorized_inventory; /* Pub/site level flag for ADS.TXT check, to decide whether we want to passback the impression */
		int exclude_unauthorized_app_inventory; /* Pub/site level flag for APP-ADS.TXT check, to decide whether we want to passback the impression */
		int multibid_response_count; //by default it will be 1 and max value for it is MAX_ALLOWED_MULTIBID_RESPONSE.
		int video_creative_syncup_enabled; //by default it will be 1 and max value for it is MAX_ALLOWED_MULTIBID_RESPONSE.

		int error_tracking_method; // By default it will be 0 and it will decide what error tracker will go for VAST 2.0
		int video_placement_default;//video placement value if 0 will not be sent . it's value is between 0-5 
		/** domain_filter_filter_percent decimal
		 * The percentage of Bids for which the domains specified in
		 * AdFlex.domain_filters should be filtered
		 */
		double domain_filter_filter_percent;

		/** domain_filter_simulation_percent
		 * The percentage of impressions for which domain filtering
		 * should not be applied to enable learning
		 */
		double domain_filter_simulation_percent;
		
		bool enable_server_side_notification; //1: This will enable tracker call as server side notification such that add ip in tracker call
		int nbt_enabled; // 0 by default 1 for enabling new_bid_throttling
		int nbt_algo_version; // 1 for old, 2 for new
		int nbt_dc2_enabled; // 0 for disabled, 1 of on
	} publisher_site_default_settings_t;

	typedef struct publisher_acl_settings {
		int acl_whitelist_flag;
	} publisher_acl_settings_t;

	typedef struct publisher_site_default_params {
					char anonymized_pageurl[MAX_PAGE_URL_SIZE]; /*pageurl to be used when url hiding is enabled */
					char overriding_referrer_url[MAX_URL_LENGTH + 1]; /*Referrer URL to be used when referrer url overriding is enable. */
	} publisher_site_default_params_t;

	// to store ad_id list for network stat bucket
	typedef struct rt_mob_network_ad_id_info {
					long ad_id_list[MAX_AD_ID_LEN];
					int ad_id_index;
	} rt_mob_network_ad_id_info_t; 

	//To store publisher_billing_details  
	typedef struct publisher_billing_details {
		float percentage_of_revenue_to_charge;
		float pmp_percentage_of_revenue_to_charge;
	} publisher_billing_details_t;
		

	// For collecting the stats for realtime mobile network filter
	typedef struct rt_mob_network_stats {
					int filtered;
					int requests;
					int timeouts;
					int incomplete_response;
					int parse_error;
					int not_200_ok;
					int parse_success;
					int campaign_id;
					rt_mob_network_ad_id_info_t ad_id[RT_MOB_NW_BUCKET_LEN];
					/*uint16_t inmobi_filtered;
						uint16_t jumptap_filtered;
						uint16_t mojiva_filtered;
						uint16_t mocean_filtered;
						uint16_t huntmads_filtered;
						uint16_t adfonic_filtered;
						uint16_t matomy_filtered;
						uint16_t madvertise_filtered;
						uint16_t tapit_filtered;
						uint16_t info_4_filtered;
						uint16_t komli_filtered;
						uint16_t jiwire_filtered;
						uint16_t nexage_filtered;
						uint16_t addynamo_filtered;*/
	} rt_mob_network_stats_t;

	typedef struct {
		int rtb_request;
		int rtb_zerobid;
		int rtb_non_zerobid;
		int rtb_winning_bid;
		int rtb_timeout;
	}impression_level_stat_t;

#define INCREMENT_IMPRESSION_LEVEL_STAT(key_name) (((impression_level_stats->key_name)) += 1)

	typedef struct ad_server_additional_params {
		network_elimination_list_t elimnation_list;
		dss_handle_t dss_handle;
		/*max mind geoip handle*/
		GeoIP* geoip_handle;
		/*curl session handle*/
		CURL *curl_handle;
		
		/* site inofo */
		publisher_site_t *site;

		/*max mind geoip data*/
		geo_data_t gd;

		/* total network frequency history */
		total_network_frequency_t frequency_total;

		/*This structure contains  publisher level settings for features available to adservers*/
		publisher_adserver_settings_t publisher_adserver_settings;

		/*contains adserver config elements*/
		adserver_config_params_t *adserver_config_params;
		
		/*macro list structure to hold PubMatic Supported macros*/
		adserver_macro_variable_name_list_t macro_list;
		impression_stats_t imp_stats;

		/* structure for pub/site level default settings */
		publisher_site_default_settings_t pubsite_default_settings;

		/* structure for pub/site level default params */
		publisher_site_default_params_t pubsite_default_params;

		/* structure for publisher billing details i.e percentage of revenue to charge*/
		publisher_billing_details_t publisher_billing_details;

		// no of hops (parallel calls made for mobile impression)
		int no_of_parallel_calls;

		// Stats of mobile networks
		rt_mob_network_stats_t mob_nw_stats[MAX_MOBILE_NETWORKS];

		// Stats of mobile s2s AdFlex networks
		rt_mob_network_stats_t mob_nw_s2s_adflex_stats[MAX_MOBILE_NETWORKS];

		/* total adserver count in all DC */
		int total_active_adservers;
		/*total adserver count in DC from adserver_control_parameter table retrieved based on id(adserver.datacenter.id) in property file*/
		int total_dc_active_adservers;
		/* map containing header and its value*/
		http_header_map_t header_map;

		int has_mediation_network_won;

		mt_state rand_state;
		GeoIP* isp_handle; // Internet Service Provider handle
		GeoIP* net_speed_handle; // Connection speed handle
		int isp_id; // ISP id for that remote address
		char isp_name[MAX_ISP_NAME_LEN + 1]; // ISP id for that remote address
		char connection_name[MAX_CONNECTION_NAME_LEN + 1]; // ISP id for that remote address
		int connection_id; // id for connection speed
		/* number of requests for which ad serving was blocked */
		uint32_t ad_serving_blocked_requests_count;
		/* number of requests for which rtb was blocked */
		uint32_t rtb_blocked_requests_count;
		/* counters for dynamic cpm*/
		dynamic_cpm_stats_t *dcpm_stats;
		int dcpm_stats_count;
		int http_method;
		int is_bot_request;
		int is_bot_pattern_in_ua_checked;
		web_bot_filter_stats_t bot_filter_stats;
		/*Publisher aggregator top level domain id*/
		int tld_id;
		/*Publisher Aggregator passback flag*/
		impression_passback_reason_t passback_flag;
		//int chd;   
		double soft_floor;
		int application_profile_id;
		unsigned int platform_id;
		unsigned int global_SSBL_flag;
		publisher_site_impression_cap_wrapper_t capped_site_network;
		double pub_rtb_floor;
		int pub_rtb_floor_type;
		unsigned int pub_country_level_privacy_flag;
		char masked_xff[MAX_LEN_XFF+1];
		char masked_xff_to_log[MAX_LEN_XFF+1];
		int multi_adsize_disabled;
		char granular_site_id[MAX_SITE_ID_LEN+1];
		publisher_acl_settings_t publisher_acl_settings;
		long long rtb_processing_time_ms;
		publisher_stats_table_t * pub_level_stats_table;
		mobile_param_stats_t mobile_param_flags;
		general_param_stats_t general_param_flags;
		int selected_mbf_alg; //MAP0 or MAP1 or MAP2
		impression_level_stat_t impression_level_stats;
		int enable_app_geo_mstats_flag;
		int rtb_timeout;
		int cp_qps_packet_size;
		int ingest_pm_vpaid_client_type;
		char req_pubmatic_uid[MAX_USERID_LEN + 1];
}ad_server_additional_params_t;


/*typedef struct rtb_connection_pool{
	CURLM *curl_multi_handle;
	}rtb_connection_pool_t;
	*/
enum StatsMarkerStatus{
	STATS_MARKER_DISABLED=0,
	STATS_MARKER_ENABLED,
};

typedef struct libstat_counters{
				unsigned long campaign_id;
				uint16_t rtb_requests;
				uint16_t rtb_timed_out;
				uint16_t rtb_bidder_timed_out;
				uint16_t rtb_bidder_dsp_conn_unavailable;
				uint16_t rtb_bidder_requests;
				uint16_t rtb_zero_bids;
                                uint16_t rtb_non_zero_bids;
				uint16_t rtb_rmcf;
				uint16_t rtb_creative_filtered_crid_na;
				uint16_t rtb_creative_filtered_cr_blocked;
				uint16_t rtb_filter_bid_price_decryption_failure;
				uint16_t rtb_winning_bids;
				uint16_t rtb_error_response;
				uint16_t rtb_second_price;
				uint16_t rtb_filtered_camp;
				uint16_t rtb_landing_page_filter;
				uint16_t rtb_advertiser_domain_filter;
				uint16_t rtb_site_level_floor;
				uint16_t rtb_dsp_level_floor;
				uint16_t rtb_dsp_advertiser_level_floor;
				uint16_t rtb_advertiser_level_floor;
				uint16_t fte_pubmatic_variable_margin;
				uint16_t fte_pubmatic_fixed_cut_filter; 
				uint16_t fte_icap_filter;
				uint16_t fte_dc_blocklist_fitler;
				uint16_t rtb_f1_filter;
				uint16_t rtb_multi_adsize_requests;
				uint16_t rtb_mux_requests;
				//
				uint32_t rtb_new_connections;
				uint32_t rtb_reused_connections;
				uint32_t rtb_max_deal_violation_count;
				uint32_t rtb_rich_media_responses;
				uint32_t rtb_camp_throttle_applied_count;
				uint32_t rtb_att_applied_count; // per campaign level
				double rtb_revenue_stats;
				uint16_t rtb_gdpr_camp_has_consent_req;
				uint16_t fte_domain_throttling_filtered_bids;
				uint16_t flexidrproxy_dsp_timeout_count;
				uint16_t flexidrproxy_dsp_max_routinereached_count;
				uint16_t flexidrproxy_dsp_error_count;
				int marker;
				uint32_t rtb_camp_cookied_req;
				uint32_t rtb_camp_eids_req;
				uint32_t rtb_camp_cookied_eids_req;
				uint32_t rtb_total_camp_cookied_req;
				uint32_t rtb_total_camp_eids_req;
				uint32_t rtb_total_camp_cookied_eids_req;
//uint16_t global_impression_cnt;
}libstat_counters_t;

typedef struct libstats_badrq_counters {
	unsigned long pub_id;
	uint16_t blank_count;
	uint16_t baddr_count;
	uint16_t ip_blk_count;
	uint16_t skipd_ip_blk_count;
	uint16_t fra_count;
	uint16_t recov_count;
	uint16_t fra_pause;
	uint16_t recov_pause;
	uint16_t impression_count;
	uint16_t a500_count;
	uint16_t l500_count;
	uint16_t l200_count;
	uint16_t l180_count;
	uint16_t l150_count;
	uint16_t l135_count;
	uint16_t l120_count;
	uint16_t l110_count;
	uint16_t l100_count;
	uint16_t l50_count;
	uint16_t l20_count;
	uint16_t a_rtb_to_plus_20ms;
	uint16_t l_rtb_to_plus_20ms;
	uint16_t l_rtb_to_plus_10ms;
	uint16_t client_time_out;
	uint16_t bid_prob_filter_applied_count;
	uint16_t bid_thrtl_new_filter_applied_count;
	uint16_t found_pubmatic_userid;
	uint16_t gdpr_total_req;
	uint16_t gdpr_pm_has_consent_req;
	uint16_t gdpr_blank_consent_req;
	uint16_t gdpr_malformed_consent_req;
	uint16_t gdpr_non_gdpr_region_req;
	uint16_t gdpr_cons_exp_empty_applied;
	uint16_t gdpr_cons_exp_pass_applied;
	uint16_t invalid_ad_size;
	uint16_t translator_timeout_count;
	uint16_t invalid_schain_string;
	uint16_t valid_schain_string;
}libstats_badrq_counters_t;

/*
	 typedef struct audience_stats_counter{
	 uint32_t aud_request_count;
	 uint32_t aud_response_timeout_count;
	 uint32_t aud_response_no_data_count;
	 }audience_stats_counter_t;
	 */
//

typedef struct kadpubuid_stats {
				unsigned int kadpubuid_total_req;
				unsigned int kadpubuid_cs_calls;
				unsigned int kadpubuid_cs_map_found;
				unsigned int kadpubuid_cs_data_found;
				unsigned int kadpubuid_cs_userid_mismatch;
} puid_stats_t;



//#define MAX_RT_MOB_NETWORK 25

//typedef struct rt_mob_network_filtered_info {
//	int rt_mob_filtered_network[MAX_RT_MOB_NETWORK];
//	int rt_mob_filtered_network_count;
//}rt_mob_network_filtered_info_t;

// Stucture declarations for collecting stats for realtime mobile network filter - end
typedef struct rtb_pair {
				CURL* easy_handle;
				long campaign_id;
}rtb_pair_t;

typedef struct easy_handle_to_campaign_id_map {
				rtb_pair_t pair_vector[MAX_REALTIME_CAMPAIGNS];
				int nelements;
}easy_handle_to_campaign_id_map_t;

/* AD Servint Time CutOff */
#define AD_SERVING_TIME_BELOW_10_CUTOFF 100
#define AD_SERVING_TIME_BELOW_20_CUTOFF 100
#define AD_SERVING_TIME_BELOW_50_CUTOFF 100
#define AD_SERVING_TIME_BELOW_100_CUTOFF 200
#define AD_SERVING_TIME_BELOW_110_CUTOFF 200
#define AD_SERVING_TIME_BELOW_120_CUTOFF 200
#define AD_SERVING_TIME_BELOW_135_CUTOFF 200
#define AD_SERVING_TIME_BELOW_150_CUTOFF 200
#define AD_SERVING_TIME_BELOW_180_CUTOFF 200
#define AD_SERVING_TIME_BELOW_200_CUTOFF 200
#define AD_SERVING_TIME_BELOW_500_CUTOFF 5
#define AD_SERVING_TIME_ABOVE_500_CUTOFF 5
#define AD_SERVING_TIME_OUT_CUTOFF 50

#define MICRO_SEC_IN_10_MS   10000
#define MICRO_SEC_IN_20_MS   20000
#define MICRO_SEC_IN_50_MS   50000
#define MICRO_SEC_IN_100_MS  100000
#define MICRO_SEC_IN_110_MS  110000
#define MICRO_SEC_IN_120_MS  120000
#define MICRO_SEC_IN_135_MS  135000
#define MICRO_SEC_IN_150_MS  150000
#define MICRO_SEC_IN_180_MS  180000
#define MICRO_SEC_IN_200_MS  200000
#define MICRO_SEC_IN_500_MS  500000

#define AD_SERVING_TOTAL_TIME_SERVED_CUTOFF_IN_MS 5000

typedef struct ad_serving_time {
				uint16_t total_below_20_ms_req;
				uint16_t total_below_50_ms_req;
				uint16_t total_below_100_ms_req;
				uint16_t total_below_110_ms_req;
				uint16_t total_below_120_ms_req;
				uint16_t total_below_135_ms_req;
				uint16_t total_below_150_ms_req;
				uint16_t total_below_180_ms_req;
				uint16_t total_below_200_ms_req;
				uint16_t total_below_500_ms_req;
				uint16_t total_above_500_ms_req;
				uint16_t total_adserver_timeout;
				uint16_t total_adserver_l_rtb_to_plus_10ms;
				uint16_t total_adserver_l_rtb_to_plus_20ms;
				uint16_t total_adserver_a_rtb_to_plus_20ms;
				//uint16_t total_time_served;
}ad_serving_time_t;

/* Cookie Store Request/Response Stats Collection*/
#define CS_FOUND "cs_found"
#define CS_NOT_FOUND "cs_notfound"
#define CS_TIME_OUT "cs_timeout"
#define CS_CURL_FAIL "cs_curlfail"
#define CS_REQUESTS "cs_requests"
#define CS_STATS_CUTOFF 100
#define MAX_API_PUB 5

typedef struct cookie_store_stats {
				unsigned long pub_id;
				uint16_t total_requests;
				uint16_t total_found;
				uint16_t total_not_found;
				uint16_t total_time_out;
				uint16_t total_curl_fail;
} cookie_store_stats_t;

//~
/* Collect Logger Stats */
/* Collet Logger Stats */
#define LOGGER_SUCCESS_CALLS_STATS_SEND_CUTOFF 500
#define LOGGER_FAILED_CALLS_STATS_SEND_CUTOFF 10

#define LOGGER_REQUEST_SUCCESS 1
#define LOGGER_FAILED_REQUEST 2
#define LOGGER_INVALID_JSON 3
#define LOGGER_NOT200_OK 4

#define RTB_QUICK_STATS_CUTOFF 10
#define RTB_SLOW_STATS_CUTOFF 50
#define PUB_IMPR_STATS 300

#define ATS_SEND_CUTOFF 50
#define MAX_AK_PUB_LIMIT 20
typedef struct akamai_tracking_stats {
				uint16_t pub_id[MAX_AK_PUB_LIMIT];
				uint16_t call_count[MAX_AK_PUB_LIMIT];
}akamai_tracking_stats_t;

typedef struct network_device_type_list {
				int adserver_id;
				int device_type_id;
} network_device_type_list_t;


//For WURFL STATS

#define WURFL_TOTAL_REQUEST 1
#define WURFL_CURL_TIMEOUT 2
#define WURFL_CURL_ERROR 3
#define WURFL_CURL_SUCCESS 4
#define WURFL_CURL_SUCCESS_CACHE 5

typedef struct wurfl_stats {
				uint16_t operation_timed_out;
				uint16_t curl_error;
				uint16_t parse_success;
				uint16_t parse_success_cache;
				uint16_t total_requests;
}wurfl_stats_t;
//end

//For Data provider Stats

#define DP_TOTAL_REQUEST 1
#define DP_DATA_ERROR 2
#define DP_CURL_TIMEDOUT 3 

typedef struct varnish_stats {
				uint16_t total_requests;
				uint16_t parse_error;
				uint16_t timedout;
}varnish_stats_t;

//For prebid fraud check stats
typedef enum prebid_fraud_check_stats_type{
	PREBID_CHECK_TOTAL_REQ = 0,
	PREBID_CHECK_DELAYED_REQ,
	PREBID_CHECK_PARSE_ERR_REQ,
	PREBID_CHECK_TIMEOUT_REQ,
	//Please add more entries before this
	PREBID_CHECK_MAX_STAT_TYPE
}prebid_fraud_check_stats_type_t;

/* For prebid fraud check varnish cache stats */
typedef enum prebid_fraud_check_varnish_cache_stats_type {
	PREBID_CHECK_VARNISH_CACHE_MISS_REQ = 0,
	PREBID_CHECK_VARNISH_CACHE_HIT_REQ,
	PREBID_CHECK_VARNISH_CACHE_TIMEOUT_REQ,
	PREBID_CHECK_VARNISH_CACHE_TOTAL_REQ,
	PREBID_CHECK_VARNISH_CACHE_PARSE_ERR,
	//Please add more entries before this
	PREBID_CHECK_VARNISH_CACHE_MAX_STAT_TYPE
} prebid_fraud_check_varnish_cache_stats_type_t;

#define PREBID_CHECK_MAX_TIMEOUT_SOFT_LIMIT 10 // 10 ms
#define PREBID_CHECK_TOTAL_REQ_STATS_KEY "PBFC:RQ:%s"  // PBFC:TREQ:<DataCenterName>:<AdServerName>
#define PREBID_CHECK_PARSE_ERR_REQ_STATS_KEY "PBFC:PE:%s"
#define PREBID_CHECK_TIMEOUT_REQ_STATS_KEY "PBFC:TO:%s"
#define PREBID_CHECK_DELAYED_REQ_STATS_KEY "PBFC:DR:%s"

#define PREBID_CHECK_VARNISH_CACHE_MISS_STATS_KEY "PBFC:VNSH%d:MS:%s"
#define PREBID_CHECK_VARNISH_CACHE_HIT_STATS_KEY "PBFC:VNSH%d:HT:%s"
#define PREBID_CHECK_VARNISH_CACHE_TIMEOUT_STATS_KEY "PBFC:VNSH%d:TO:%s"
#define PREBID_CHECK_VARNISH_CACHE_REQ_STATS_KEY "PBFC:VNSH%d:RQ:%s"
#define PREBID_CHECK_VARNISH_CACHE_PARSE_ERR_STATS_KEY "PBFC:VNSH%d:PE:%s"

typedef struct prebid_fraud_check_stats_data{
	char *stats_key;
	uint16_t req_count;
}prebid_fraud_check_stats_data_t;

typedef struct prebid_fraud_check_stats {
	prebid_fraud_check_stats_data_t stats[PREBID_CHECK_MAX_STAT_TYPE];
}prebid_fraud_check_stats_t;

typedef struct prebid_fraud_check_varnish_cache_stats {
	prebid_fraud_check_stats_data_t cache_stats[PREBID_CHECK_VARNISH_CACHE_MAX_STAT_TYPE];
} prebid_fraud_check_varnish_cache_stats_t;

typedef struct string_scrach_buffer{
				char cookie_processing_string[MAX_COOOKIE_HEADER_LENGTH + 1];
				char list_of_string[MAX_STRING_LIST_ELEMENTS + 1][MAX_STRING_LIST_ELEMENT_LENGTH + 1];
}string_scrach_buffer_t;

typedef struct publisher_site_geo_filter_settings {
				char country_code[MAX_GEO_CODE_LEN];
				char region_code[MAX_GEO_CODE_LEN];
				char city[MAX_GEO_NAME_LEN];
				int dma_code;
				int geo_level;
				int ad_serving_blocked;
				int rtb_blocked;
}publisher_site_geo_filter_settings_t;

typedef struct publisher_site_ad_serving_rtb_status {
				unsigned long pub_id;
				unsigned long site_id;
				publisher_site_geo_filter_settings_t *publisher_site_geo_filter_settings;
				int filter_settings_count;
} publisher_site_ad_serving_rtb_status_t;

#define MAX_TRACKER_DOMAIN_NAME_LEN 100

typedef struct tracker_server_list {
				char server_dns[MAX_TRACKER_DOMAIN_NAME_LEN + 1];
}tracker_server_list_t;


typedef struct dp_cookie_max_expiry_map{
				unsigned long dp_id;
				unsigned long cookie_expiry_time;
}dp_cookie_max_expiry_map_t;

typedef struct adserver_activation_window{
				unsigned long adserver_id;
				time_t end_time;
				time_t start_time;
}adserver_activation_window_t;

/*HIMPA RULE STRUCTURES*/
typedef struct ga_site_section_user_frequency_rule {
				int frequency;//it is the total failed attempts
				int block_time;//time in seconds
} ga_site_section_user_frequency_rule_t;

typedef struct sp_control_params {
				double a;
				double b;
				double c;
}sp_control_params_t;

#define PRICING_2_0__STP__EPSILON 0.05 //epsilon in case of Pricing 2.0 STP should be 30.0 as per disscusion with ML team
#define PRICING_2_0__STP__CAP 30.0 //cap in case of Pricing 2.0 STP should be 30.0 as per disscusion with ML team

struct pricing_2_0_global_params {
	double cap; // in dollars
	double epsilon; // in dollars
	double mu_threshold; // valid value between 0 to 1
};

struct pricing_2_0_params {
	struct pricing_2_0_global_params global_params;
	int campaign_id;
	int algo_selected;
	double ro;
	double r;
};

int get_shp_control_params(
								db_connection_t *dbconn,
								sp_control_params_t *sp_control_params
								);

int get_pricing_2_0_global_params(		
		db_connection_t *dbconn,
		struct pricing_2_0_global_params *pricing_g_params
	);
/* OLD Native Protocol Implementation
	 void print_native_params(native_params_t *native_params);
	 */

int get_ad_server_parameters(
								ad_server_additional_params_t *additional_params,
								adserver_macro_variable_name_list_t *macro_list,
								ad_server_req_gen_param_t *gen_params,
								char *in_query_string,
								parse_util_struct_t *parse_util_struct,
								ad_server_req_param_t* ret_params,
								puid_stats_t* puid_stats,
								publisher_site_ad_t* site_ad,
								db_connection_t *dbconn,
								cache_handle_t *cache
								);
void init_req_params(
								ad_server_req_param_t *ret_params,
								adserver_macro_variable_name_list_t* macro_list
								);
int get_req_post_data(
								ad_server_additional_params_t *additional_params,
								adserver_macro_variable_name_list_t *macro_list,
								ad_server_req_gen_param_t *gen_params,
								char* in_post_data,
								parse_util_struct_t *parse_util_struct,
								ad_server_req_param_t* ret_params,
								publisher_site_ad_t* site_ad,
								db_connection_t *dbconn,
								cache_handle_t *cache
								);
void free_ad_server_parameters(ad_server_req_param_t **);
int get_defaulted_campaigns(char *, ad_server_req_param_t *);
void update_akamai_tracking_stats(akamai_tracking_stats_t *, int);
void cache_get_defalted_indirect_ad_tag_id(cache_handle_t *cache,
								db_connection_t *dbconn,
								unsigned long *indirect_ad_tag_id, 
								int defaulted_adserver_id,
								int pub_id,
								int ad_id);

void update_adserving_time_stats(ad_serving_time_t *time_stats, int time_in_micros, int timeout_ms, int ads_proc_time);

void print_params_struct(const ad_server_req_param_t* params);

void init_general_params(ad_server_req_gen_param_t *gen_params);
void init_additional_params(ad_server_additional_params_t *additional_params);
const adsize_t * cache_get_adsize_id(cache_handle_t *cache,db_connection_t *dbconn,int * row_counter);
int is_both_geo_object_same(ad_server_req_param_t* ret_params);

/* For Pub Agg TLD Whitelisting */

#define MAX_PUB_AGG_CACHE_OBJ                2
#define MAX_TLD_LIMIT_PUB_SITE_PER_CACHE_OBJ 50000

#define MAX_IAB_PRIMARY_CAT_LEN   15
#define MAX_IAB_SECONDARY_CAT_LEN 30
#define TRUNCATED_APP_BUNDLE_LEN 2

/* App Data - IAB Categories */
typedef struct app_iab_cat_info {
				unsigned int app_crc32;
				char iab_primary_cat[MAX_IAB_PRIMARY_CAT_LEN + 1];
				char iab_secondary_cat[MAX_IAB_SECONDARY_CAT_LEN + 1];
				char application_bundle[TRUNCATED_APP_BUNDLE_LEN + 1];
				unsigned short platform_id;
} app_iab_cat_info_t;

#define UNKNOWN_APP_IOS 1
#define UNKNOWN_APP_ANDROID 2

#define DERIVED_MOBILE_APP_ENTITY_IOS 1
#define DERIVED_MOBILE_APP_ENTITY_ANDROID 2

// os_id types
#define MOB_INVAL_OS_TYPE 0
#define MOB_ANDROID_OS_TYPE 1
#define MOB_IOS_OS_TYPE 2
#define MOB_BLACKBERRY_OS_TYPE 3
#define MOB_WINDOWS_OS_TYPE 4
#define MOB_NOKIA_OS_TYPE 5
#define MOB_WEBOS_OS_TYPE 6
#define MOB_MAEMO_OS_TYPE 7
#define MOB_MEEGO_OS_TYPE 8
#define MOB_BADA_OS_TYPE 9
#define MOB_KINDLE_OS_TYPE 10
#define MOB_OTHER_OS_TYPE 11


//Mapping for sitecode to siteurl for non-aggr publishers
//site_url is a non encoded page url
typedef struct sitecode_siteurl_map {
				char site_code[MAX_SITE_CODE_LENGTH+1];
				char site_url[MAX_SITE_URL_LENGTH+1];
} sitecode_siteurl_map_t;

	
#define AD_ID_LEVEL 0
#define SITE_ID_LEVEL 1

typedef enum ad_type_id_list {
	AD_TYPE_TEXT_ONLY = 1,
	AD_TYPE_IMAGE_ONLY,
	AD_TYPE_TEXT_IMAGE,
	AD_TYPE_LINKUNIT,
	AD_TYPE_HTML,
	AD_TYPE_FLASH,
	AD_TYPE_TEXT_FLASH,
	AD_TYPE_TEXT_IMAGE_FLASH,
	AD_TYPE_TEXT_IMAGE_FLASH_HTML,
	AD_TYPE_TEXT_HTML,
	AD_TYPE_TEXT_IMAGE_RICHMEDIA,
	AD_TYPE_NATIVE,
	AD_TYPE_VIDEO,
	AD_TYPE_AUDIO,
} ad_type_id_t;

typedef enum platform_id_list {
  PLATFORM_UNKNOWN            = -1,
  PLATFORM_DESKTOP            = 1,
  PLATFORM_MOBILE_WEB         = 2,
  PLATFORM_NOT_DEFINED        = 3,
  PLATFORM_MOBILE_APP_IOS     = 4,
  PLATFORM_MOBILE_APP_ANDROID = 5,
  PLATFORM_MOBILE_APP_WINDOWS = 6
} platform_id_t;

#define MOBILE_APP_ANDROID_STR "android"
#define MOBILE_APP_IOS_STR     "ios"

typedef enum iab_inventory_type {
	IAB_BANNER_INVENTORY = 1,
	IAB_VIDEO_INVENTORY,
	IAB_NATIVE_INVENTORY
} iab_inventory_type_t;

#define AD_SIZE_VIDEO 97
char * extract_url( char *url);
/*increase below macro if  ad_id/site_id icrease more than 2000000*/
#define ADID_SITEID_MAX_FORFCAP 2000000

typedef struct ad_tracker_ecpm_encryption_algo_details{
	char encryption_key[MAX_ENCRYPTION_KEY_LENGTH + 1];
	char integrity_key[MAX_INTEGRITY_KEY_LENGTH + 1];
}ad_tracker_ecpm_encryption_algo_details_t;

typedef enum modified_bid2pub_bit_field {
	BID2PUB_IS_PAY2PUB = 0,
	BID2PUB_REDUCED_BY_REVERSE_AUCTION_MARGIN = 1,
	BID2PUB_IS_NET_BID_VALUE = 2,
	BID2PUB_CHANGED_BY_MAP2 = 4,
	BID2PUB_CHANGED_BY_MAP0 = 8
} modified_bid2pub_bit_field_t;

/*
 * Note : Here Flags Are Not Sequential
 * so ALWAYS assign the vlaue.
 * If you are adding something here
 * then also add in it's structure and db call
 */
typedef enum acl_feature_flags {
	ACL_WHITELIST_FLAG = 194
}acl_feature_flags_t;
//set bid2pub to new value. Also set corresponding reason bit
#define UPDATE_BID2PUB_IF_CHANGED(new_publisher_ecpm, selected_camp, BID2PUB_BIT_FIELD) do{\
	  if (new_publisher_ecpm != selected_camp->bid2pub_ecpm) {\
			    selected_camp->bid2pub_ecpm = new_publisher_ecpm;\
			    selected_camp->bid2pub_bit_field |= BID2PUB_BIT_FIELD;\
			  }\
}while(0);

void malloc_decode_url(const char * src_str,char**dest_str, const int size);


typedef enum user_id_preference_list {
	PREFER_UID_UNKNOWN = -1,
	PREFER_UID_DEFAULT,
	PREFER_PUBLISHER_UID_ONLY,
	PREFER_PUBLISHER_OR_PUBMATIC_UID,
	PREFER_PUBMATIC_UID_ONLY
} user_id_preference_list_t;


#endif /* AD_SERVER_TYPES_H */
