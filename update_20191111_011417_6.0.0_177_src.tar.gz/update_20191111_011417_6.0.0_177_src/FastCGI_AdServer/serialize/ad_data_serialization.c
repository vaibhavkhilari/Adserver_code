/*
 * PubMatic Inc. (“PubMatic”) CONFIDENTIAL
 * Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains the property of PubMatic. The intellectual and technical concepts contained
 * herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly forbidden unless prior written permission is obtained
 * from PubMatic.  Access to the source code contained herein is hereby forbidden to anyone except current PubMatic employees, managers or contractors who have executed 
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication or disclosure  of  this source code, which includes  
 * information that is confidential and/or proprietary, and is a trade secret, of  PubMatic.   ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE, 
 * OR PUBLIC DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN CONSENT OF PubMatic IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 * LAWS AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS  
 * TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 */
//#include <ad_serialize.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ad_serialize.h>
static const int id_length_size = sizeof(int) *2;
/*
  This method will serialize data in a buffer and allocate that
  It will be caller responsibility to free that returned buffer
  
  Input:
  obj_list => object list to be serialized
  list_count=> number of object in above structure
  Output:
  out_data_length => serialized buffer length
  serialised buffer will be return as output
  return: buffer if its serialized else NULL
  
 */
void * ad_serialize_object(ad_serialize_str_t * obj_list,int list_count,int *out_data_length)
{
	int i = 0;
	int total_length = sizeof(int);
	int serialized_str_length =  sizeof(int);
	void * out_data = NULL;
	
	if(obj_list == NULL || list_count <= 0 || out_data_length == NULL){
		fprintf(stderr,"Error: passed data for serialization is bad obj_list:%s list_count:%d \n",
				((obj_list == NULL)?"NULL":"Not NULL") , list_count);
		return NULL;
	}
	*out_data_length = 0;
	
	for(i = 0; i < list_count ;i++){
		serialized_str_length += (obj_list[i].length + id_length_size);
	}

	out_data = malloc(serialized_str_length );
	
	for(i = 0; i < list_count; i++){
		
		if(obj_list[i].data && obj_list[i].length > 0){

			memcpy(out_data + total_length ,obj_list + i,id_length_size); /*copy id & length*/
			total_length += id_length_size;
			memcpy(out_data + total_length, obj_list[i].data,obj_list[i].length); /*copy data*/
			total_length += obj_list[i].length;
 		}
		else{
			fprintf(stderr,"Error:data is NULL or length is null its not supported %s:%d\n",__FILE__,__LINE__);
		}
	}
	
	/*final verification of size*/
	if(total_length <= id_length_size || serialized_str_length != total_length){
		free(out_data);
		fprintf(stderr,"Error:invalid length or total valid object for serialization is less than 1 %s:%d\n",__FILE__,__LINE__);
		return NULL;
	}
	
	memcpy(out_data , &total_length,sizeof(int));/*copy total length*/
	*out_data_length = serialized_str_length;
	return out_data;
}
/*
  This method will de-serialse buffer which was serilized by above method
  input 
  serialised_str =>buffer to be serialized
  data_list_out=> array of ad_serialize_str_t object in which de-serilized object will be stored
  list_max_count=> max number of object in above array
  output
  data_list_out=> array of ad_serialize_str_t object in which de-serilized object will be stored
  return
  number of object after de-serialization in above structure
 */
int ad_deserialize_object(void * serialised_str,ad_serialize_str_t * data_list_out,int list_max_count)
{
	int total_length = 0;
	int offset = sizeof(int);
	ad_serialize_str_t *tmp_obj = NULL;
	int obj_count = 0;
	
	if(serialised_str == NULL || data_list_out == NULL){
		fprintf(stderr,"Error:data sent is NULL %s:%d\n",__FILE__,__LINE__);
		return -1;
	}

	total_length = *((int*)serialised_str);

	if(total_length <= id_length_size){
		fprintf(stderr,"Info: it can be dummy entry as data length is very small %d %s:%d\n",total_length,__FILE__,__LINE__);
		return 0;
	}
	
	while(offset < total_length && obj_count < list_max_count){
		
		tmp_obj = (ad_serialize_str_t*)(serialised_str + offset);
		data_list_out[obj_count].data = (void*)(tmp_obj) + id_length_size;
		data_list_out[obj_count].id = tmp_obj->id;
		data_list_out[obj_count].length = tmp_obj->length;
		offset += (id_length_size + tmp_obj->length);

		obj_count++;
	}
	return obj_count;
}
#ifdef DONT_COMPILE
int main()
{
	ad_serialize_str_t obj[10];
	int x =10;
	obj[0].id = 1;
	obj[0].length = sizeof(int);
	obj[0].data = &x;
	
	obj[1].id = 2;
	obj[1].length = strlen("two") + 1;
	obj[1].data = "two";
	
	obj[2].id = 3;
	obj[2].length = strlen("three") + 1;
	obj[2].data = "three";
	
	obj[3].id = 4;
	obj[3].length = strlen("four") + 1;
	obj[3].data = "four";
	
	obj[4].id = 5;
	obj[4].length = strlen("five") + 1;
	obj[4].data = "five";

	obj[5].id = 6;
	obj[5].length = strlen("six") + 1;
	obj[5].data = "six";
	
	obj[6].id = 7;
	obj[6].length = strlen("seven") + 1;
	obj[6].data = "seven";
	
	obj[7].id = 8;
	obj[7].length = strlen("eight") + 1;
	obj[7].data = "eight";
	
	obj[8].id = 9;
	obj[8].length = strlen("nine") + 1;
	obj[8].data = "nine";
	
	int i = 0;
	printf("id:%d,length:%d data:%d i=%d\n",obj[i].id,obj[i].length,*((int*)obj[i].data),i);

	printf("before serialize\n");
	for(i = 1;i<=8;i++){
		printf("id:%d,length:%d data:%s i=%d\n",obj[i].id,obj[i].length,(char*)obj[i].data,i);
	}
	char serialized_str[500];
	int length = 0;
	ad_serialize_str_t obj1[10] = {0};
	void * data = ad_serialize_object(obj,9,&length);
	printf("serialized string length %d\n",length);
	
	length = ad_deserialize_object(data,obj1,10);
	i = 0;
	printf("id:%d,length:%d data:%d i=%d\n",obj[i].id,obj[i].length,*((int*)obj[i].data),i);
	for(i = 1;i < length;i++){
        printf("id:%d,length:%d data:%s i=%d\n",obj1[i].id,obj1[i].length,(char*)(obj1[i].data),i);
    }
	
	return 0;
}
#endif
