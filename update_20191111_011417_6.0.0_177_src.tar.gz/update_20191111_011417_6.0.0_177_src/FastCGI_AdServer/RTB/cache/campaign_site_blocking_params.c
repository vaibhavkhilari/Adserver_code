/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "campaign_site_blocking_params.h"
#include "fte_util.h"
#include "error.h"
#include "db_error.h"
#include "rt_types.h"
#include "ad_server_types.h"
#include "cache_libmemcached.h"
//kartik_porting
#include "db_campaign_site_blocking_params.h"
//~kartik_porting

#include <sys/time.h>
#include <errno.h>


int cache_get_campaign_site_context (int threadid, 
									campaign_site_blocking_context_t  **campaign_site_blocking_context,
									long site_id,
									cache_handle_t *cache,
									int *ret_list
									){

    /* Local variables */
    char camp_site_block_context[MAX_KEY_SIZE];
    campaign_site_blocking_context_t *cached_campaign_site_blocking_context=NULL;
    int key_length=0;
    unsigned int ret_len = 0;
    //campaign_site_blocking_context_t data;

	sprintf(camp_site_block_context, CAMP_SITE_BLOCKING_CONTEXT, threadid, site_id);
	key_length = strlen(camp_site_block_context);
	
	cached_campaign_site_blocking_context = (campaign_site_blocking_context_t*)libmemcached_local_get(cache,
                                         camp_site_block_context, key_length, (int *)&ret_len);

    if (cached_campaign_site_blocking_context != NULL) {

        /*
         * Found the information in cache, so return it now,
         * by coping it to the o/p parameter
         */

        (*ret_list) = (ret_len/sizeof(campaign_site_blocking_context_t));
        (*campaign_site_blocking_context) = cached_campaign_site_blocking_context;

        return ADS_ERROR_SUCCESS;
    }

    /*
     * If ret_len is 0, that means there was some error, try to reinit the
     * connection
     */
    if (ret_len == 0) {
        reinit_cache(cache);
    }
	return ADS_ERROR_NOT_FOUND;
}


int cache_get_campaign_site_blocking_params(
		int threadid,
        campaign_site_blocking_params_t  **campaign_site_blocking_params,
        long site_id,
        cache_handle_t *cache,
        db_connection_t *dbconn,
        int *ret_list){
	/* Local variables */
	char camp_site_block_params[MAX_KEY_SIZE];
	campaign_site_blocking_params_t *cached_campaign_site_blocking_params=NULL;
	int retval = 0;
	int key_length=0;
	unsigned int ret_len = 0;
	int i=0;

	sprintf(camp_site_block_params, CAMP_SITE_BLOCK_PARAMS, threadid, site_id);
	key_length = strlen(camp_site_block_params);


	/*
	 * Check if the information about this ad's active account is present in
	 * the cache based on the key
	 */
	cached_campaign_site_blocking_params = (campaign_site_blocking_params_t*)libmemcached_local_get(cache,
										 camp_site_block_params, key_length, (int *)&ret_len);
	
	if (cached_campaign_site_blocking_params != NULL) {

		/*
		 * Found the information in cache, so return it now,
		 * by coping it to the o/p parameter
		 */
	
		(*ret_list) = (ret_len/sizeof(campaign_site_blocking_params_t));	
		(*campaign_site_blocking_params) = cached_campaign_site_blocking_params;

		return ADS_ERROR_SUCCESS;
	}

	/*
	 * If ret_len is 0, that means there was some error, try to reinit the
	 * connection
	 */
	if (ret_len == 0) {
		reinit_cache(cache);
	}

	/*
	 * Reaches here when we do not find the ad's account information in the cache, so now
	 * get it from the database and add it to the cache and return
	 */
	retval = get_campaign_site_blocking_params(campaign_site_blocking_params, site_id, dbconn, ret_list);
	if (retval != DB_ERROR_SUCCESS) {
		if (retval == DB_ERROR_INTERNAL) {
			/* Return internal error */
			llog_write(L_DEBUG,"\n DB call failed for campaign_site_blocking_params");	
			return ADS_ERROR_INTERNAL;
		}
		/* element not found in the database */
		return ADS_ERROR_NOT_FOUND;
	}


	
	cached_campaign_site_blocking_params = NULL;	
	if((*ret_list) > 0 && (*campaign_site_blocking_params) != NULL){
		
		/* Element found in the database add it to the cache */
			retval = libmemcached_local_set(cache, camp_site_block_params, key_length, (void *) (*campaign_site_blocking_params),
						sizeof(campaign_site_blocking_params_t)*(*ret_list), get_fte_cache_timeout(), 0);
	} 
	else{
			
    	    cached_campaign_site_blocking_params = (campaign_site_blocking_params_t *)malloc(sizeof(campaign_site_blocking_params_t) );
			if(cached_campaign_site_blocking_params != NULL){

            /* copy the list  data here */
				
            	cached_campaign_site_blocking_params[i].campaign_id = 0;
				cached_campaign_site_blocking_params[i].blocking_percentage = 0;
				retval = libmemcached_local_set(cache, camp_site_block_params, key_length, (void *)cached_campaign_site_blocking_params,
                        sizeof(campaign_site_blocking_params_t), get_fte_cache_timeout(), 0);
				(*ret_list) = 1;
				(* campaign_site_blocking_params) = cached_campaign_site_blocking_params;
			}else {
				llog_write(L_DEBUG,"\n Couldnt set to campaign site blocking params");
			}

	}
	/*
	 * If we could not add the value, probably the server went down in between,
	 * so reinit the server
	 */
	if (retval != 0) {
		reinit_cache(cache);
	}

	
	return ADS_ERROR_SUCCESS;

}

int set_context_campaign_site_blocking_params(	int threadid, 
												campaign_site_blocking_context_t  **campaign_site_blocking_context,
												int nelements,
        										long site_id,
        										cache_handle_t *cache){

    char camp_site_block_context[MAX_KEY_SIZE]="";
    int retval = 0;
    int key_length=0;

	if((*campaign_site_blocking_context) == NULL || nelements == 0 || site_id <= 0 || cache == NULL){
		return ADS_ERROR_INTERNAL;
	}

	sprintf(camp_site_block_context, CAMP_SITE_BLOCKING_CONTEXT, threadid, site_id);
	key_length = strlen(camp_site_block_context);

	retval = libmemcached_local_set(cache, camp_site_block_context, key_length, (void *) (*campaign_site_blocking_context),
		sizeof(campaign_site_blocking_context_t)*(nelements), get_fte_cache_timeout(), 0);
	
	if (retval != 0) {
		reinit_cache(cache);
    }

    return ADS_ERROR_SUCCESS;
}
