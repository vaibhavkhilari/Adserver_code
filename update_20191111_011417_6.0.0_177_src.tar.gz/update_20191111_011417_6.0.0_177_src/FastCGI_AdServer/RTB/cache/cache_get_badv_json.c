/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "error.h"
#include "db_error.h"
#include "db_connection.h"
#include "cache_libmemcached.h"
#include "db_badv_domain.h"
#include "log_fw.h"
#include "assert.h"
#include "cache_conf_intf.h"

const char * cache_get_badv_domain_json( cache_handle_t* cache, db_connection_t* dbconn, int pub_id, int site_id, int campaign_id ){
	const char *badv_domain_json = NULL;
	char cache_key[MAX_KEY_SIZE+1];
	char dummy_str[]="_";
	cache_key[0]='\0';	
	unsigned int cache_keylen = 0;
	unsigned int ret_len = 0;

	cache_keylen=sprintf(cache_key, BADV_CACHE_KEY, pub_id, site_id, campaign_id);

	badv_domain_json = (const char *) memcached_get_object_reference(cache, cache_key, cache_keylen, (int *)&ret_len);

	//get the data from DB
	if(badv_domain_json == NULL){
		badv_domain_json = db_get_badv_domain_json( dbconn, pub_id, site_id,campaign_id);
	}else {
		goto done;
	}

	//if still not found, set DUMMY value
	if ( NULL == badv_domain_json) {
		libmemcached_set(cache, cache_key, cache_keylen, (void *)dummy_str,
				sizeof(dummy_str), get_cache_timeout(), 0);
	}else {
		libmemcached_set(cache, cache_key, cache_keylen,
				(void	*)badv_domain_json, strlen(badv_domain_json)+1,
				get_cache_timeout(), 0);
	}

done:
	if( badv_domain_json != NULL && badv_domain_json[0] !='['){
		memcached_release_object_reference((char**)&badv_domain_json);
		badv_domain_json=NULL;
	}
	return badv_domain_json;
}
