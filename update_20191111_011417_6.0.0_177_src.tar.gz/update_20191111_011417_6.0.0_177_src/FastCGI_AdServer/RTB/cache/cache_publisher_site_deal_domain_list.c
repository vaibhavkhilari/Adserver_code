/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


/* Include required header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "cache_publisher_site_deal_domain_list.h"
#include "fte_util.h"
#include "error.h"
#include "db_error.h"
#include "rt_types.h"
#include "cache_libmemcached.h"
#include "db_publisher_site_deal_white_list.h"


int cache_get_publisher_site_deal_domain_list(
				long pub_id,
				long site_id,
				BLOOM** publisher_site_deal_domain_name,
				cache_handle_t* cache,
				db_connection_t* dbconn,
				size_t* ret_size) {

	/* Local variables */
	char publisher_site_deal_domain_list_key[MAX_KEY_SIZE];
	BLOOM *cached_publisher_site_deal_domain_name = NULL;
	const BLOOM dummy_entry = { .bit_array_size=0, .nelements=0};
	int retval = 0;
	int key_length=0;
	int ret_len = 0;
	(*publisher_site_deal_domain_name) = NULL;
	(*ret_size) = 0;
	/* Create the key */
	snprintf(publisher_site_deal_domain_list_key, MAX_KEY_SIZE, PUBLISHER_SITE_DL_BLM_LST, pub_id, site_id);
	key_length = strlen(publisher_site_deal_domain_list_key);

	/*
	 * Check if the information about this ad's active account is present in
	 * the cache based on the key
	 */
	cached_publisher_site_deal_domain_name = 
		(BLOOM*) memcached_get_object_reference(cache,  
				publisher_site_deal_domain_list_key, 
				key_length, 
				&ret_len);

	if (cached_publisher_site_deal_domain_name != NULL) {
		BLOCKLIST_DEBUG("\nDL_Bloom:pub:%ld site:%ld:: memcache_obj_size:%d, domain_count:%d, bit_array_size_bits:%zd, bit_array_size_bytes:%ld, %s:%d\n",
				pub_id, site_id, ret_len,
				cached_publisher_site_deal_domain_name->nelements,
				cached_publisher_site_deal_domain_name->bit_array_size,
				BIT_ARRAY_SIZE_BYTES(cached_publisher_site_deal_domain_name->bit_array_size),
				__FILE__, __LINE__);
		
		if(INVALID_FILTER_IN_CACHE(cached_publisher_site_deal_domain_name)) {
			memcached_release_object_reference((char**)&cached_publisher_site_deal_domain_name);
			return ADS_ERROR_SUCCESS; // return success if no/invalid whitelist for the publisher/site
		}
		//reaches here only if valid whitelist found in cache
		(*publisher_site_deal_domain_name) = cached_publisher_site_deal_domain_name;
		return ADS_ERROR_SUCCESS;
	}

	/*
	 * If ret_len is 0, that means there was some error, try to reinit the
	 * connection
	 */
	if (ret_len == -1) {
		reinit_cache(cache);
	}

	/*
	 * Reaches here when we do not find the ad's account information in the cache, so now
	 * get it from the database and add it to the cache and return
	 */
	retval = db_get_publisher_site_deal_white_list(dbconn, 
			pub_id,
			site_id,
			publisher_site_deal_domain_name,
			ret_size);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG,"\n ERROR: DB call failed for db_get_publisher_site_deal_white_list");	
		return retval;
	}

	if( (*publisher_site_deal_domain_name) != NULL) {

		/* Element found in the database add it to the cache */
		retval = libmemcached_set(cache, publisher_site_deal_domain_list_key, 
				key_length, (void *) (*publisher_site_deal_domain_name),
				(*ret_size), 
				get_fte_cache_timeout(), 0);
	INPC_REFERENCE_DEBUG("\nINPC_REFERENCE:: %p key:%s, fetched from DB\n", *publisher_site_deal_domain_name, publisher_site_deal_domain_list_key);
	} else {
		retval = libmemcached_set(cache, publisher_site_deal_domain_list_key, 
				key_length, (void *)(&dummy_entry),
				sizeof(BLOOM), 
				get_fte_cache_timeout(), 0);
	}
	/*
	 * If we could not add the value, probably the server went down in between,
	 * so reinit the server
	 */
	if (retval != 0) {
		reinit_cache(cache);
	}

	return ADS_ERROR_SUCCESS;
}
