/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "cache_libmemcached.h"
#include "rt_types.h"
#include "db_pub_site_advertiser_domain_category_list.h"
#include "cache_pub_site_advertiser_domain_category_list.h"
#include <ad_server_types.h>

int cache_get_pub_site_domain_advertiser_blocklist(
		db_connection_t *dbconn,
		cache_handle_t *cache,
		long **pub_site_domain_advertiser_blocklist,
		int* ret_list,
		long pub_id,
		long site_id) {

	/*Local Variables*/
	char cache_key[MAX_KEY_SIZE];
	int key_length = 0;
	int ret_len = 0;
	int retval = ADS_ERROR_SUCCESS;
	int adv_len = 0;
	long dummy_adv = 0;
	long *cache_data = NULL;
	(*pub_site_domain_advertiser_blocklist) = NULL;
	(*ret_list) = 0;

	/* Create key */
	key_length = snprintf(cache_key, MAX_KEY_SIZE, PUB_SITE_DOM_ADV_BLK_KEY, pub_id, site_id);

	if((key_length <= 0) || (key_length >= MAX_KEY_SIZE)){
		llog_write(L_DEBUG,"\nERROR: snprintf failed or exceeded Max Limit: %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	cache_data = (long *) memcached_get_object_reference(cache,
			cache_key,
			key_length,
			&ret_len);

	if(NULL != cache_data){
		adv_len = (ret_len/sizeof(long));
		/* check for dummy entry */
		if((1 == adv_len) && (0 == cache_data[0])){
			memcached_release_object_reference((char**)&cache_data);
			return ADS_ERROR_SUCCESS;
		}

		(*pub_site_domain_advertiser_blocklist) = cache_data;
		(*ret_list) = adv_len;
		return ADS_ERROR_SUCCESS;
	}

	/* If ret_len is -1, that means there was some error, try to reinit the connection */
	if (-1 == ret_len) {
		reinit_cache(cache);
	}

	/*
	 * Reaches here when we do not find the data in the cache.
	 * Get it from the database and add it to the cache and return
	 */
#ifdef DEBUG_BLOCKLIST
	llog_write(L_DEBUG,"\nINFO: Going for DB Call : '%s' %s:%d\n", cache_key, __FILE__, __LINE__);
#endif
	retval = db_get_pub_site_domain_advertiser_blocklist(
				dbconn,
				pub_site_domain_advertiser_blocklist,
				ret_list,
				pub_id,
				site_id);
	if (ADS_ERROR_SUCCESS == retval) {

		adv_len = *ret_list;

		if ((adv_len > 0) && (NULL != (*pub_site_domain_advertiser_blocklist))) {
			/* Element found in the database, add it to the cache */
			retval = libmemcached_set(
					cache,
					cache_key,
					key_length,
					(void *) (*pub_site_domain_advertiser_blocklist),
					sizeof(long) * adv_len,
					get_cache_timeout(),
					0);
		}
		else{ /* else set dummy record in cache */
			libmemcached_set(
					cache,
					cache_key,
					key_length,
					(void *) (&dummy_adv),
					sizeof(long),
					get_cache_timeout(),
					0);
		}

		/*
		 * If we could not add the value, probably the server went down in between,
		 * so reinit the connection
		 */
		if (0 != retval) {
			reinit_cache(cache);
		}
	}

	return retval;
}

int cache_get_pub_site_domain_category_blocklist(
		db_connection_t *dbconn,
		cache_handle_t *cache,
		int **pub_site_domain_category_blocklist,
		int* ret_list,
		long pub_id,
		long site_id) {

	/*Local Variables*/
	char cache_key[MAX_KEY_SIZE];
	int key_length = 0;
	int ret_len = 0;
	int retval = ADS_ERROR_SUCCESS;
	int cat_len = 0;
	int dummy_cat = 0;
	int *cache_data = NULL;
	(*pub_site_domain_category_blocklist) = NULL;
	(*ret_list) = 0;

	/* Create key */
	key_length = snprintf(cache_key, MAX_KEY_SIZE, PUB_SITE_DOM_CAT_BLK_KEY, pub_id, site_id);

	if((key_length <= 0) || (key_length >= MAX_KEY_SIZE)){
		llog_write(L_DEBUG,"\nERROR: snprintf failed or exceeded Max Limit: %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_SUCCESS;
	}

	cache_data = (int *) memcached_get_object_reference(cache,
			cache_key,
			key_length,
			&ret_len);

	if(NULL != cache_data){
		cat_len = (ret_len/sizeof(int));
		/* check for dummy entry */
		if((1 == cat_len) && (0 == cache_data[0])){
			memcached_release_object_reference((char**)&cache_data);
			return ADS_ERROR_SUCCESS;
		}

		(*pub_site_domain_category_blocklist) = cache_data;
		(*ret_list) = cat_len;
		return ADS_ERROR_SUCCESS;
	}

	/* If ret_len is -1, that means there was some error, try to reinit the connection */
	if (-1 == ret_len) {
		reinit_cache(cache);
	}

	/*
	 * Reaches here when we do not find the data in the cache.
	 * Get it from the database and add it to the cache and return
	 */
#ifdef DEBUG_BLOCKLIST
	llog_write(L_DEBUG,"\nINFO: Going for DB Call : '%s' %s:%d\n", cache_key, __FILE__, __LINE__);
#endif
	retval = db_get_pub_site_domain_category_blocklist(
				dbconn,
				pub_site_domain_category_blocklist,
				ret_list,
				pub_id,
				site_id);
	if (ADS_ERROR_SUCCESS == retval) {

		cat_len = *ret_list;

		if ((cat_len > 0) && (NULL != (*pub_site_domain_category_blocklist))) {
			/* Element found in the database, add it to the cache */
			retval = libmemcached_set(
					cache,
					cache_key,
					key_length,
					(void *) (*pub_site_domain_category_blocklist),
					sizeof(int) * cat_len,
					get_cache_timeout(),
					0);
		}
		else{ /* else set dummy record in cache */
			libmemcached_set(
					cache,
					cache_key,
					key_length,
					(void *) (&dummy_cat),
					sizeof(int),
					get_cache_timeout(),
					0);
		}

		/*
		 * If we could not add the value, probably the server went down in between,
		 * so reinit the connection
		 */
		if (0 != retval) {
			reinit_cache(cache);
		}
	}

	return retval;
}
