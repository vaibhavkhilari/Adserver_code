/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "error.h"
#include "fte_util.h"
#include "db_error.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "db_publisher_site_dsp_advertiser_floor.h"
#include "cache_publisher_site_dsp_advertiser_floor.h"


int cache_get_publisher_site_dsp_advertiser_floor_settings(long publisher_id,
		long site_id,
		cache_handle_t *cache,
		db_connection_t *dbconn,
		publisher_site_dsp_advertiser_floor_settings_t **publisher_site_dsp_advertiser_floor_settings,
		unsigned int *nelements){

	char publisher_site_dsp_advertiser_floor_key[MAX_KEY_SIZE];
	unsigned int publisher_site_dsp_advertiser_floor_key_len = 0;
	int retval = 0;	
	int ret_len = 0;
	publisher_site_dsp_advertiser_floor_settings_t *tmp_dsp_advertiser_floor_settings = NULL;

	(*publisher_site_dsp_advertiser_floor_settings) = NULL;
	(*nelements) = 0;

	sprintf(publisher_site_dsp_advertiser_floor_key, PUBLISHER_SITE_DSP_ADVERTISER_FLOOR_KEY, publisher_id, site_id);
	publisher_site_dsp_advertiser_floor_key_len = strlen(publisher_site_dsp_advertiser_floor_key);

	tmp_dsp_advertiser_floor_settings = (publisher_site_dsp_advertiser_floor_settings_t *)libmemcached_get(cache, publisher_site_dsp_advertiser_floor_key, publisher_site_dsp_advertiser_floor_key_len, &ret_len);
	if (tmp_dsp_advertiser_floor_settings != NULL){
		(*publisher_site_dsp_advertiser_floor_settings) = tmp_dsp_advertiser_floor_settings;
		(*nelements) = (ret_len/sizeof(publisher_site_dsp_advertiser_floor_settings_t));
		return ADS_ERROR_SUCCESS;
	}

	retval = get_publisher_site_dsp_advertiser_floor_settings(publisher_id, site_id, dbconn, publisher_site_dsp_advertiser_floor_settings, nelements);
	if (retval != DB_ERROR_SUCCESS){
		llog_write(L_DEBUG, "Failed to get publisher site advertiser floor settings from DB. Error %d\n", retval);
		return ADS_ERROR_INTERNAL;
	}

	if ((*nelements) <= 0 && (*publisher_site_dsp_advertiser_floor_settings) == NULL){
		(*publisher_site_dsp_advertiser_floor_settings) = (publisher_site_dsp_advertiser_floor_settings_t *)malloc(sizeof(publisher_site_dsp_advertiser_floor_settings_t));
		if ((*publisher_site_dsp_advertiser_floor_settings) == NULL){
			return ADS_ERROR_INTERNAL;
		}
		(*publisher_site_dsp_advertiser_floor_settings)[0].dsp_id = 0;
		(*publisher_site_dsp_advertiser_floor_settings)[0].domain_name[0] = '\0';
		(*publisher_site_dsp_advertiser_floor_settings)[0].floor_ecpm = 0;
		(*nelements) = 1;
	}
	
	retval = libmemcached_set(cache, publisher_site_dsp_advertiser_floor_key, publisher_site_dsp_advertiser_floor_key_len,
			(void *)(*publisher_site_dsp_advertiser_floor_settings), (sizeof(publisher_site_dsp_advertiser_floor_settings_t) * (*nelements)),
			get_fte_cache_timeout(), 0);

	if (retval != 0) {
		reinit_cache(cache);
	}
	return ADS_ERROR_SUCCESS;
}
