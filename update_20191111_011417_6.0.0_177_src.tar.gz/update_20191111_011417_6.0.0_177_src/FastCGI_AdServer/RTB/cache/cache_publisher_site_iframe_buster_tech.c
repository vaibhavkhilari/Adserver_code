/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ad_server_types.h"
#include "cache_publisher_site_iframe_buster_tech.h"
#include "db_publisher_site_iframe_buster_tech.h"
#include "cache_types.h"
#include "db_connection.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "db_error.h"
#include "error.h"
#include "fte_util.h"

//We shall set NULL settings in memcache if we have failed to get the same neither from DB nor from cache.
#define MEMCACHED_NULL_IFRAME_BUSTER_TECH_LIST "@#$NULL_JSON_IFRAME_BUSTER_TECH_LIST@#$"


/*
 * From Memcache, get the list of iFrame buster technlogies that Publisher has installed on its site.
 * If failed to get it from Memcache then get the same from DB.
 *
 * On Success: From pub_site_rich_media_params set json_available_iframe_buster_tech_list to the list
 *             return by Memcache/DB & Save it's length in json_available_iframe_buster_tech_list_len.
 *
 * On Failure: From pub_site_rich_media_params set json_available_iframe_buster_tech_list to empty
 *             string & Save it's length (zero) in json_available_iframe_buster_tech_list_len.
 */
int cache_get_publisher_site_iframe_buster_tech(long pub_id,
                                                long site_id,
                                                cache_handle_t *cache_handle,
                                                db_connection_t *conn,
                                                ad_server_additional_params_t *additional_parameters,
                                                publisher_site_ad_rich_media_params_t *pub_site_rich_media_params)
{
	int ret_len = 0, retval = 0;
	char json_iframe_buster_tech_key[MAX_KEY_SIZE + 1] = "";
	unsigned int json_iframe_buster_tech_key_len = 0;
	memcached_publisher_site_iframe_buster_tech_t *cached_tech_list = NULL, *caching_tech_list = NULL;

 	//Sanity checks.
	if (	cache_handle == NULL ||
		conn == NULL ||
		additional_parameters == NULL ||
		pub_site_rich_media_params == NULL)
	{
		llog_write(L_DEBUG, "%s(): Invalid input argument(s) provided to the function.\n",
                         __FUNCTION__);
		return ADS_ERROR_INVALID_ARGS;
	}

	//Initialize iframe buster tech list.
	pub_site_rich_media_params->psf_tech_list = NULL;

	//Compose Memcache key.
	json_iframe_buster_tech_key[MAX_KEY_SIZE] = '\0';
	snprintf(json_iframe_buster_tech_key,
		MAX_KEY_SIZE,
		MEMCACHED_IFRAME_BUSTER_TECH_LIST_KEY,
		pub_id,
		site_id);
	json_iframe_buster_tech_key_len = strlen(json_iframe_buster_tech_key);

	//Get the iframe buster technologies list from Memcache.
	cached_tech_list = (memcached_publisher_site_iframe_buster_tech_t *) libmemcached_get(
                                                                            cache_handle,
                                                                            json_iframe_buster_tech_key,
                                                                            json_iframe_buster_tech_key_len,
                                                                            &ret_len);
	if (cached_tech_list != NULL)
	{
		//Cache hits.
		if (strncmp(cached_tech_list->json_available_iframe_buster_tech_list,
				MEMCACHED_NULL_IFRAME_BUSTER_TECH_LIST,
				(sizeof (MEMCACHED_NULL_IFRAME_BUSTER_TECH_LIST) - 1)) == 0)
		{
			free(cached_tech_list);
			cached_tech_list = NULL;
		}
		pub_site_rich_media_params->psf_tech_list = cached_tech_list;
#ifdef DEBUG
		if (cached_tech_list != NULL)
		{
			 int i;

	                 llog_write(L_DEBUG, "cache iframe buster list: %d ", cached_tech_list->json_available_iframe_buster_tech_list_len);
	                 for (i = 0; i < cached_tech_list->json_available_iframe_buster_tech_list_len; i++)
	                         llog_write(L_DEBUG, "%c", cached_tech_list->json_available_iframe_buster_tech_list[i]);
	                 llog_write(L_DEBUG, "\n");
		}
		else
		{
			llog_write(L_DEBUG, "%s(): We have found NULL iFrame Buster list from cache.\n",
					__FUNCTION__);
		}
#endif //DEBUG
		return ADS_ERROR_SUCCESS;
	}

	/*
	 * FIXME: Reinit is NOP as of now so if memcache fails, there is a sword lurking right above
	 *        your neck.
	 */
	if (ret_len == -1)
	{
		reinit_cache(cache_handle);
	}

	//Cache misses, Get the iframe buster technologies list from DB.
	retval = get_publisher_site_iframe_buster_tech_list(
				pub_id,
				site_id,
				conn,
				additional_parameters,
				pub_site_rich_media_params);
	if (retval != DB_ERROR_SUCCESS)
	{
		return ADS_ERROR_INTERNAL;
	}

	//Cache it.
	caching_tech_list = pub_site_rich_media_params->psf_tech_list;
	if (caching_tech_list->json_available_iframe_buster_tech_list_len == 0)
	{
		//Set NULL settings into Memcache as we have not found record in DB.
		memcpy(caching_tech_list->json_available_iframe_buster_tech_list,
			MEMCACHED_NULL_IFRAME_BUSTER_TECH_LIST,
			sizeof (MEMCACHED_NULL_IFRAME_BUSTER_TECH_LIST));
	}
	retval = libmemcached_set(
			cache_handle,
			json_iframe_buster_tech_key,
			json_iframe_buster_tech_key_len,
			(void *) caching_tech_list,
			sizeof (memcached_publisher_site_iframe_buster_tech_t),
			get_fte_cache_timeout(),
			0);

 	/*
	 * If we could not add the value, probably the server went down in between,
	 * so reinit the server
	 *
	 * FIXME: change this later, right now this function doesn't work
	 */
	if (retval != 0)
	{
		reinit_cache(cache_handle);
	}
	return ADS_ERROR_SUCCESS;
}

