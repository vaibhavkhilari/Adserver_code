/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include "db_rtb_campaign_encryption_algo_details.h"
#include "cache_rtb_campaign_encryption_algo_details.h"
#include "cache_conf_intf.h"
#include "db_rtb_campaign_encryption_algo_details.h"


void dump_rt_campaign_encryption_algo_details(rt_campaign_encryption_algo_details_t *details,
                                              int count,
                                              int algorithm_purpose) {
    int i=0;
    llog_write(L_DEBUG, "\n %s : %d", __FUNCTION__, __LINE__);
    if (details != NULL) {
        for (i = 0; i < count; i++) {
            llog_write(L_DEBUG, "\n campaign_id = %ld, algorithm_name = %s,"
                    "encryption_key = %s, integirty_key = %s, algorithm_purpose = %s",
                    details[i].campaign_id,
                    details[i].algorithm_name,
                    details[i].encryption_key,
                    details[i].integrity_key,
                    (algorithm_purpose == 0) ? "RTB_BID_PRICE_ENCRYPTION" : "RTB_SECOND_PRICE_ENCRYPTION");
        }
    }
}

int cache_get_rtb_campaign_encryption_algo_details(int algorithm_purpose,
        cache_handle_t *cache,
        db_connection_t *dbconn,
        rt_campaign_encryption_algo_details_t  **rt_campaign_encryption_algo_details,
        int *rt_campaign_count) {

    /* Local variables */
    rt_campaign_encryption_algo_details_t *cached_rt_campaign_encryption_algo_details = NULL;
    char rtb_campaign_encryption_algo_details_key[MAX_KEY_SIZE] = {'\0'};
    rt_campaign_encryption_algo_details_t dummy_entry = {.campaign_id = -1L,
        .algorithm_name[0] = '\0',
        .encryption_key[0] = '\0',
        .integrity_key[0] = '\0'
    };
    int retval = 0;
    int key_length=0;
    int ret_len = 0;

#ifdef DEBUG
    llog_write(L_DEBUG, "\n%s:%d", __FUNCTION__, __LINE__);
#endif

    /* Validate input parameters */
    if (cache == NULL ||
        dbconn == NULL ||
        rt_campaign_encryption_algo_details == NULL ||
        *rt_campaign_encryption_algo_details != NULL) {

        llog_write(L_DEBUG, "\n(%s:%d): One of the input param is NULL, return.\n", __FILE__,  __LINE__);
        return ADS_ERROR_INVALID_ARGS;
    }

    /* Initialise.*/
    (*rt_campaign_encryption_algo_details) = NULL;
    (*rt_campaign_count) = 0;

    /* Create the key */
    snprintf(rtb_campaign_encryption_algo_details_key, MAX_KEY_SIZE, RTB_CAMPAIGN_ECRYPTION_ALGO_DETAILS, algorithm_purpose, cache->thread_id);
    key_length = strlen(rtb_campaign_encryption_algo_details_key);

    /*
     * Check if the information about this publisher/site's creative_filter_list 
     * is present in the cache based on the key.
     */
    cached_rt_campaign_encryption_algo_details =
        (rt_campaign_encryption_algo_details_t*) libmemcached_get(cache,
                rtb_campaign_encryption_algo_details_key,
                key_length,
                &ret_len);

    if (cached_rt_campaign_encryption_algo_details != NULL) {

        /*
         * Found the information in cache, so return it now,
         * by copying it to the o/p parameter
         */
        if (ret_len == sizeof(rt_campaign_encryption_algo_details_t)
                &&
                cached_rt_campaign_encryption_algo_details->campaign_id == -1L
           ) {
#ifdef DEBUG
            llog_write(L_DEBUG, "%s(): Found dummy settings in memcache\n", __FUNCTION__);
#endif //DEBUG

            free(cached_rt_campaign_encryption_algo_details);
            cached_rt_campaign_encryption_algo_details = NULL;
        }
        if (cached_rt_campaign_encryption_algo_details != NULL) {
            (*rt_campaign_count) = ret_len/sizeof(rt_campaign_encryption_algo_details_t);
        }
        (*rt_campaign_encryption_algo_details) = cached_rt_campaign_encryption_algo_details;
        return ADS_ERROR_SUCCESS;
    }

    /*
     * If ret_len is 0, that means there was some error, 
     *  try to reinit the connection.
     */
    if (ret_len == -1) {
        reinit_cache(cache);
    }

    /*
     * Reaches here when we do not find the  signs encryption algo information in the cache, so now
     * get it from the database and add it to the cache and return
     */
    retval = db_get_rtb_campaign_encryption_algo_details(algorithm_purpose,
            dbconn,
            rt_campaign_encryption_algo_details,
            rt_campaign_count);

    if (retval != ADS_ERROR_SUCCESS) {
        llog_write(L_DEBUG, "\n(%s:%d) : DB call failed for db_get_rtb_campaign_encryption_algo_details" , __FILE__, __LINE__);
        return retval;
    }

    if( (*rt_campaign_encryption_algo_details) != NULL) {

        /* Element found in the database add it to the cache */
        retval = libmemcached_set(cache, rtb_campaign_encryption_algo_details_key,
                key_length, (void *) (*rt_campaign_encryption_algo_details),
                sizeof(rt_campaign_encryption_algo_details_t)*(*rt_campaign_count),
                get_fte_cache_timeout(), 0);
    } else {
        retval = libmemcached_set(cache, rtb_campaign_encryption_algo_details_key,
                key_length, (void *)(&dummy_entry),
                sizeof(rt_campaign_encryption_algo_details_t),
                get_fte_cache_timeout(), 0);
    }

#ifdef DEBUG
    dump_rt_campaign_encryption_algo_details((*rt_campaign_encryption_algo_details), *rt_campaign_count, algorithm_purpose);
#endif

    /*
     * If we could not add the value, probably the server went down in between,
     * so reinit the server
     */
    if (retval != 0) {
        reinit_cache(cache);
    }

    return ADS_ERROR_SUCCESS;

}

