/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


/* Include required header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "fte_util.h"
#include "error.h"
#include "db_error.h"
#include "rt_types.h"
#include "cache_libmemcached.h"
#include "cache_get_bkt_bloom_filters.h"
#include "db_get_bkt_bloom_filters.h"

void memcached_release_object_reference(char** data_ptr);

static int __cache_set_bkt_bloom_filters(
		cache_handle_t *cache,
		db_connection_t *dbconn,
		const char *cache_key,
		const char *db_query,
		BKT_BLOOM_ARRAY *bkt_bloom_array) {
	char cache_key_with_index[MAX_KEY_SIZE + 1];
	char update_time[MAX_TIMESTAMP_SIZE_YYYYMMDD + 1];
	const BKT_BLOOM dummy_entry = {.bit_array_size=0, .nelements=0, .first_element={0}};
	int retval = ADS_ERROR_INTERNAL;
	int cache_key_len = 0;
	int blm_idx = 0;
	size_t ret_size[MAX_ALLOWED_BKT_BLOOMS] = {0};

	DEBUG_LOG("CACHE_BKT_BLOOM_NOT_FOUND:: Going for DB Call: db_query:'%s'", db_query);

	retval = db_get_bkt_bloom_filters(dbconn,
			db_query,
			bkt_bloom_array->bkt_bloom,
			&bkt_bloom_array->bkt_bloom_count,
			ret_size,
			update_time,
			MAX_BLOOM_COUNT_FOR_CACHE);
	if (ADS_ERROR_SUCCESS != retval) {
		ERROR_LOG("DB call failed for db_get_bkt_bloom_filters(), retval:%d", retval);
		return retval;
	}

	/* Bkt_bloom found in DB, set it in cache */
	if ((0 < bkt_bloom_array->bkt_bloom_count) && (NULL != bkt_bloom_array->bkt_bloom[0])) {
		void *tmp_ptr = NULL;
		/* We need to append bloom count to first bloom object, allocate space for it */
		tmp_ptr = realloc(bkt_bloom_array->bkt_bloom[0], ret_size[0] + sizeof(char));
		if (NULL == tmp_ptr) {
			for (blm_idx=0; blm_idx<bkt_bloom_array->bkt_bloom_count; blm_idx++) {
				bkt_bloom_destroy(&bkt_bloom_array->bkt_bloom[blm_idx]);
			}
			bkt_bloom_array->bkt_bloom_count = 0;
			return ADS_ERROR_NOMEMORY;
		}
		bkt_bloom_array->bkt_bloom[0] = (BKT_BLOOM*)tmp_ptr;

		/* append bloom count to first bloom object */
		char nblooms = (char)(bkt_bloom_array->bkt_bloom_count);
		memcpy((char*)bkt_bloom_array->bkt_bloom[0] + ret_size[0], &nblooms, sizeof(char));
		ret_size[0] += sizeof(char);

		/* Set all bkt blooms one by one */
		for (blm_idx=0; (blm_idx < bkt_bloom_array->bkt_bloom_count) && (bkt_bloom_array->bkt_bloom[blm_idx] != NULL); blm_idx++) {
			cache_key_len = snprintf(cache_key_with_index, MAX_KEY_SIZE, "%s_%d", cache_key, blm_idx);
			cache_key_with_index[MAX_KEY_SIZE] = 0;
			if ((0 >= cache_key_len) || (MAX_KEY_SIZE <= cache_key_len)) {
				ERROR_LOG("cache_key exceeds the max size or snprintf failed. cache_key:'%s'", cache_key);
			} else {

				retval = libmemcached_set(cache,
						cache_key_with_index,
						cache_key_len,
						(void *)(bkt_bloom_array->bkt_bloom[blm_idx]),
						ret_size[blm_idx],
						get_cache_timeout(),
						0);
				if (0 != retval) {
					ERROR_LOG("Failed to set key:%s, retval:%d", cache_key_with_index, retval);
				}
			}
		}
	} else { /* bkt_bloom not found in DB, set dummy entry in cache */
		cache_key_len = snprintf(cache_key_with_index, MAX_KEY_SIZE, "%s_%d", cache_key, 0);
		cache_key_with_index[MAX_KEY_SIZE] = 0;
		if ((0 >= cache_key_len) || (MAX_KEY_SIZE <= cache_key_len)) {
			ERROR_LOG("cache_key exceeds the max size or snprintf failed. cache_key:'%s'", cache_key);
		} else {

			retval = libmemcached_set(cache,
					cache_key_with_index,
					cache_key_len,
					(void *)(&dummy_entry),
					sizeof(BKT_BLOOM),
					get_cache_timeout(),
					0);
		}
	}

	if (0 != retval) {
		reinit_cache(cache);
	}
	return ADS_ERROR_SUCCESS;
}

void cache_release_bkt_bloom_array(BKT_BLOOM_ARRAY *bkt_bloom_array) {
	int i;
	if (!bkt_bloom_array)
		return;
	for (i=0; i<MAX_ALLOWED_BKT_BLOOMS; i++) {
		if (NULL != bkt_bloom_array->bkt_bloom[i]) {
			memcached_release_object_reference((char**)&bkt_bloom_array->bkt_bloom[i]);
			bkt_bloom_array->bkt_bloom[i] = NULL;
		}
	}
	bkt_bloom_array->bkt_bloom_count = 0;
}

int cache_get_bkt_bloom_filters(cache_handle_t *cache,
		db_connection_t *dbconn,
		const char *cache_key,
		const char *db_query,
		BKT_BLOOM_ARRAY *bkt_bloom_array) {
	char cache_key_with_index[MAX_KEY_SIZE + 1];
	BKT_BLOOM *cached_bkt_bloom = NULL;
	int retval = ADS_ERROR_INTERNAL;
	int cache_key_len = 0;
	int ret_len = 0;
	int blm_idx = 0;

	/* Initialize the out param: bkt_bloom_array */
	bkt_bloom_array->bkt_bloom[0] = NULL;
	bkt_bloom_array->bkt_bloom_count = 0;

	/* Prepare the cache key */
	cache_key_len = snprintf(cache_key_with_index, MAX_KEY_SIZE, "%s_%d", cache_key, blm_idx);
	cache_key_with_index[MAX_KEY_SIZE] = 0;
	if ((0 >= cache_key_len) || (MAX_KEY_SIZE <= cache_key_len)) {
		ERROR_LOG("cache_key exceeds the max size or snprintf failed. cache_key:'%s'", cache_key);
		return retval;
	}

	/* Get the bkt_bloom object from cache */
	cached_bkt_bloom = (BKT_BLOOM*) memcached_get_object_reference(
			cache,
			cache_key_with_index,
			cache_key_len,
			&ret_len);

	if (NULL != cached_bkt_bloom) {
		DEBUG_LOG("CACHE_BKT_BLOOM_FOUND::key:%s memcache_obj_size:%d, element_count:%d, bit_array_size_bits:%zd, first_element:%s",
				cache_key_with_index,
				ret_len,
				cached_bkt_bloom->nelements,
				cached_bkt_bloom->bit_array_size,
				cached_bkt_bloom->first_element);

		/* Check if retrieved bkt_bloom is dummy */
		if (INVALID_FILTER_IN_CACHE(cached_bkt_bloom)) {
			memcached_release_object_reference((char**)&cached_bkt_bloom);
			/* return success if dummy bloom present */
			return ADS_ERROR_SUCCESS;
		}

		blm_idx++;

		/* At the end of first bloom we have appended total bloom count */
		bkt_bloom_array->bkt_bloom[0] = cached_bkt_bloom;
		bkt_bloom_array->bkt_bloom_count = (int)(*((char*)cached_bkt_bloom + (ret_len - sizeof(char))));

		/* get remaining bkt bloom objects from cache one by one */
		int is_failure = 0;
		while ((bkt_bloom_array->bkt_bloom_count > blm_idx) && (MAX_ALLOWED_BKT_BLOOMS > blm_idx)) {
			/* Prepare the cache key */
			cache_key_len = snprintf(cache_key_with_index, MAX_KEY_SIZE, "%s_%d", cache_key, blm_idx);
			cache_key_with_index[MAX_KEY_SIZE] = 0;
			if ((0 >= cache_key_len) || (MAX_KEY_SIZE <= cache_key_len)) {
				ERROR_LOG("cache_key exceeds the max size or snprintf failed. cache_key:'%s'", cache_key);
				is_failure = 1;
				break;
			}

			cached_bkt_bloom = (BKT_BLOOM*) memcached_get_object_reference(
					cache,
					cache_key_with_index,
					cache_key_len,
					&ret_len);
			if (NULL != cached_bkt_bloom) {
				/* If current bkt_bloom is dummy, return bkt_blooms got so far */
				if (INVALID_FILTER_IN_CACHE(cached_bkt_bloom)) {
					bkt_bloom_array->bkt_bloom_count = blm_idx;
					memcached_release_object_reference((char**)&cached_bkt_bloom);
					return ADS_ERROR_SUCCESS;
				}

				bkt_bloom_array->bkt_bloom[blm_idx] = cached_bkt_bloom;
				blm_idx++;

				DEBUG_LOG("CACHE_BKT_BLOOM_FOUND::key:%s memcache_obj_size:%d, element_count:%d, bit_array_size_bits:%zd, first_element:%s",
						cache_key_with_index,
						ret_len,
						cached_bkt_bloom->nelements,
						cached_bkt_bloom->bit_array_size,
						cached_bkt_bloom->first_element);

			} else {
				DEBUG_LOG("CACHE_MULTI_BLOOM_WARNING::Cache Get Failed OR cache Expired, key:%s", cache_key_with_index);
				is_failure = 1;
				break;
			}
		}

		/* Cache call failed, release all cache objects got so far and go for DB call */
		if (is_failure) {
			cache_release_bkt_bloom_array(bkt_bloom_array);
		} else {
			return ADS_ERROR_SUCCESS;
		}
	}

	if (-1 == ret_len) {
		reinit_cache(cache);
	}

	/* bkt_bloom is not present in cache, so get it from DB */
	return __cache_set_bkt_bloom_filters(cache, dbconn, cache_key, db_query, bkt_bloom_array);
}
