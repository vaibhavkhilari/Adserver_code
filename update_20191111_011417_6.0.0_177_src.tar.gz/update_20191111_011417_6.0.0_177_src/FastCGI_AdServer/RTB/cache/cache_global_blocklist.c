/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

/* Include required header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "error.h"
#include "db_error.h"
#include "cache_libmemcached.h"
#include "cache_global_blocklist.h"
#if 0
int cache_get_global_blocklist(BLOOM** global_blocklist_domain, 
																cache_handle_t* cache_handle, 
																db_connection_t* dbconn, 
																size_t *global_bl_domain_length){

	char global_blocklist_key[MAX_KEY_SIZE];
	int key_length = 0;
	BLOOM *cache_global_blocklist_domain = NULL;
	int ret_len = 0;
	int retval = 0;
	const BLOOM dummy_entry = { .bit_array_size=0, .nelements=0};

	(*global_blocklist_domain) = NULL;
	(*global_bl_domain_length) = 0;
	
	snprintf(global_blocklist_key, MAX_KEY_SIZE, GLOBAL_BLOCKLIST, 0, 0);
	key_length = strlen(global_blocklist_key);

	/*Check if data is present in cache*/
	cache_global_blocklist_domain = (BLOOM*) libmemcached_get(cache_handle,
																		global_blocklist_key,
																		key_length,
																		&ret_len);

	if(cache_global_blocklist_domain != NULL) {
		if(INVALID_FILTER_IN_CACHE(cache_global_blocklist_domain)) {
			free(cache_global_blocklist_domain);
			cache_global_blocklist_domain = NULL;
			return ADS_ERROR_SUCCESS;
		}

		(*global_blocklist_domain) = cache_global_blocklist_domain;
		return ADS_ERROR_SUCCESS;
	}

	/*if ret_len is 0, then there was some error, reinit the connection*/
	if(ret_len == -1) {
		reinit_cache(cache_handle);
	}

	/*
   * Reaches here when we do not find the ad's account information in the cache, so now
   * get it from the database and add it to the cache and return
   */
	retval = db_get_global_blocklist(dbconn, global_blocklist_domain, global_bl_domain_length);
	if(retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG,"\nDB call failed for db_get_global_blocklist()");\
		return retval;
	}

	/*if element found in DB*/
	if((*global_blocklist_domain) != NULL) {
		/*Element found in db*/
		retval = libmemcached_set(cache_handle,
										global_blocklist_key,
										key_length,
										(void *) (*global_blocklist_domain),
										(*global_bl_domain_length),
										get_cache_timeout(),
										0);
	} else {
		/*Element not found in DB, set dummy entry*/
		retval = libmemcached_set(cache_handle,
                    global_blocklist_key,
                    key_length,
                    (void *)(&dummy_entry),
                    sizeof(BLOOM),
										get_cache_timeout(),
                    0);
	}
	/*
   * If we could not add the value, probably the server went down in between,
   * so reinit the server
   */
  if (retval != 0) {
    reinit_cache(cache_handle);
  }

  return ADS_ERROR_SUCCESS;
}
#endif
