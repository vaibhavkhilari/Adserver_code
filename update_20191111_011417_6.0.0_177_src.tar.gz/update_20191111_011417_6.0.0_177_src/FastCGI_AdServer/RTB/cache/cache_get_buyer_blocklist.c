/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "cache_libmemcached.h"
#include "cache_get_buyer_blocklist.h"
#include "error.h"

#define DUMMY_BUYER_ID -99

int cache_get_buyer_blocklist(
		db_connection_t *dbconn,
		cache_handle_t *cache,
		buyer_block_list_t **buyer_block_list,
		long pub_id) {

	/*Local Variables*/
	char cache_key[MAX_KEY_SIZE + 1];
	int key_length = 0;
	int ret_len = 0;
	int retval = ADS_ERROR_SUCCESS;
	int dummy_buyer = DUMMY_BUYER_ID;
	int *cache_data = NULL;

	if (NULL == dbconn || NULL == cache || NULL == buyer_block_list) {
		ERROR_LOG("Invalid Parameters passed.");
		return ADS_ERROR_INVALID_ARGS;
	}
	/* Initialize the output params */
	(*buyer_block_list) = NULL;

	/* Create key */
	key_length = snprintf(cache_key, MAX_KEY_SIZE, PUB_BUYER_BOCKLIST_KEY, pub_id);

	if((key_length <= 0) || (key_length >= MAX_KEY_SIZE)){
		ERROR_LOG("snprintf failed or exceeded Max Limit");
		return ADS_ERROR_INTERNAL;
	}

	cache_data = (int *) memcached_get_object_reference(cache,
			cache_key,
			key_length,
			&ret_len);

	if(NULL != cache_data){
		int len = (ret_len) / (sizeof(int));
		/* check for dummy entry */
		if(1 == len && DUMMY_BUYER_ID == cache_data[0]) {
			memcached_release_object_reference((char**)&cache_data);
			return ADS_ERROR_SUCCESS;
		}

		(*buyer_block_list) = (buyer_block_list_t *) malloc (sizeof(buyer_block_list_t));
		if (NULL == (*buyer_block_list)) {
			memcached_release_object_reference((char**)&cache_data);
			ERROR_LOG("Malloc failed.");
			return ADS_ERROR_NOMEMORY;
		}
		(*buyer_block_list)->buyers = cache_data;
		(*buyer_block_list)->n_elements = len;
		return ADS_ERROR_SUCCESS;
	}

	/* If ret_len is -1, that means there was some error, try to reinit the connection */
	if (-1 == ret_len) {
		reinit_cache(cache);
	}

	/*
	 * Reaches here when we do not find the data in the cache.
	 * Get it from the database and add it to the cache and return
	 */
	INFO_LOG("Going for DB Call : '%s'", cache_key);

	retval = db_get_buyer_blocklist(dbconn,
			buyer_block_list,
			PUB_LEVEL_BUYER_BLOCKLIST,
			pub_id);
	if (ADS_ERROR_SUCCESS == retval && NULL != (*buyer_block_list)) {
		if (0 < (*buyer_block_list)->n_elements && NULL != (*buyer_block_list)->buyers) {
			/* Element found in the database, add it to the cache */
			retval = libmemcached_set(
					cache,
					cache_key,
					key_length,
					(void *) (*buyer_block_list)->buyers,
					sizeof(int)*((*buyer_block_list)->n_elements),
					get_cache_timeout(),
					0);
			return retval;

		}
	}

	/* In error case or when table is empty, we will set dummy entry in cache, to avoid frequent db calls */
	libmemcached_set(
			cache,
			cache_key,
			key_length,
			(void *) (&dummy_buyer),
			sizeof(int),
			get_cache_timeout(),
			0);

	return retval;
}

