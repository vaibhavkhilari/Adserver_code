/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "publisher_site_block_list.h"
#include "fte_util.h"
#include "error.h"
#include "db_error.h"
#include "rt_types.h"
#include "cache_libmemcached.h"
#include "db_publisher_site_block_list.h"
#include "dynamic_dsp_sp_margin.h"
#include "url_categorization.h"
#include "common_util.h"
#include "log_fw.h"
#include "assert.h"
#include "cache_dynamic_campaign_sp_margin.h"
#include "db_dynamic_campaign_sp_margin.h"
 

void print_margin_map ( dsp_sp_margin_map_t *margin_map, int ret_size , char msg[]) {
	int no_of_records = ( ret_size / sizeof(dsp_sp_margin_map_t) );
	int i = 0;

	llog_write(L_DEBUG,"\nDSPM: No of records found: %d %s",no_of_records,msg);
	for ( ; i < no_of_records; i++ ) {
		llog_write(L_DEBUG,"\nDSPM: LP:%f,UP:%f,SPM:%f",
			margin_map[i].lower_price, margin_map[i].upper_price, margin_map[i].sp_margin);
	}
	return;
	
}

void print_ias_settings ( integral_settings_t *settings, int ret_size , char msg[]) {
	int no_of_records = ( ret_size / sizeof(integral_settings_t) );
	int i = 0;

	llog_write(L_DEBUG,"\nUCAT: No of settings found: %d %s",no_of_records,msg);
	for ( ; i < no_of_records; i++ ) {
		llog_write(L_DEBUG,"\nUCAT: Cid:%d, bitmap:%d",
			settings[i].campaign_id, settings[i].enabled_ias_services);
	}
	return;
}

int cache_get_campaign_dynamic_sp_margin(
					cache_handle_t* cache_handle,
                        		db_connection_t* adflex_dbconn,
					long campaign_id,
					dsp_sp_margin_map_t **margin_map,
					size_t *no_of_records ) {
	
	char dynamic_campaign_sp_margin_key[MAX_KEY_SIZE];
	dsp_sp_margin_map_t dummy_map = {.lower_price=-1, .upper_price=-1, .sp_margin = -1};
	dsp_sp_margin_map_t *cached_margin_map = NULL;
	int retval = 0;
        int key_length=0;       
        int ret_len = 0;

	key_length = snprintf(dynamic_campaign_sp_margin_key, MAX_KEY_SIZE, DYNAMIC_CAMP_SP_MARGIN, campaign_id);

	cached_margin_map = (dsp_sp_margin_map_t *) libmemcached_get(cache_handle, dynamic_campaign_sp_margin_key, key_length,&ret_len);
	if ( cached_margin_map != NULL ) {
#ifdef DSPM_DEBUG 
		print_margin_map(cached_margin_map,ret_len,"from cache");
#endif
		(*no_of_records) = (size_t) ( ret_len / sizeof(dsp_sp_margin_map_t) );
		if ( (*no_of_records == 1 ) && DUMMY_DATA_FOUND(cached_margin_map) ) {
			DSPM_DEBUGLOG("Dummy data found in cache");
			free(cached_margin_map);
                        cached_margin_map = NULL;
			(*no_of_records) = 0;
                        return ADS_ERROR_SUCCESS;
		}

		//reached here means found valid data in cache
		(*margin_map) = cached_margin_map;
                return ADS_ERROR_SUCCESS;
	}

	/*
         * If ret_len is -1, that means there was some error, try to reinit the
         * connection 
         */
        if (ret_len == -1) {
                reinit_cache(cache_handle);
        }
	
	
	retval = db_get_campaign_dynamic_sp_margin(adflex_dbconn, margin_map, campaign_id, no_of_records);

	if (retval != DB_ERROR_SUCCESS) {
                llog_write(L_DEBUG,"\nERROR: DB call failed for db_get_campaign_dynamic_sp_margin()");
		(*no_of_records) = 0;
                return retval;
        }

#ifdef DSPM_DEBUG 
        print_margin_map(*margin_map,(*no_of_records)*sizeof(dsp_sp_margin_map_t),"from DB");
#endif

	if( ((*no_of_records) != 0 ) && (*margin_map) != NULL ) {
        	/* Element found in the database add it to the cache */
                retval = libmemcached_set(cache_handle, dynamic_campaign_sp_margin_key,
                                key_length, (void *) (*margin_map),
                                (*no_of_records)*sizeof(dsp_sp_margin_map_t),
                                get_fte_cache_timeout(), 0);
        } else {
                retval = libmemcached_set(cache_handle, dynamic_campaign_sp_margin_key,
                                key_length, (void *) (&dummy_map),
                                sizeof(dsp_sp_margin_map_t),
                                get_fte_cache_timeout(), 0);
        }
        /*
         * If we could not add the value, probably the server went down in between,
         * so reinit the server
         */
        if (retval != 0) {
                reinit_cache(cache_handle);
        }

        return ADS_ERROR_SUCCESS;
}

int cache_get_cmpg_sp_info(
		cache_handle_t* cache_handle,
		db_connection_t* adflex_dbconn,
		int campaign_id,
		cmpg_sp_info_t** sp_info
		)
{

	char cmpg_sp_info_key[MAX_KEY_SIZE];
	cmpg_sp_info_t dummy_cmpg_sp_info = {.var_D = -1.0};
	cmpg_sp_info_t* cached_cmpg_sp_info = NULL;
	int retval = 0;
	int key_length=0;       
	int ret_len = 0;

	*sp_info = NULL;

	key_length = snprintf(cmpg_sp_info_key, MAX_KEY_SIZE, CMPG_SP_INFO, campaign_id);

	cached_cmpg_sp_info = (cmpg_sp_info_t*) libmemcached_get(cache_handle, cmpg_sp_info_key, key_length, &ret_len);
	if (cached_cmpg_sp_info != NULL ) {
		if (cached_cmpg_sp_info->var_D <= 0.0) {
			free(cached_cmpg_sp_info);
			return ADS_ERROR_SUCCESS;
		}

		//reached here means found valid data in cache
		(*sp_info) = cached_cmpg_sp_info;
		return ADS_ERROR_SUCCESS;
	}

	/*
	 * If ret_len is -1, that means there was some error, try to reinit the
	 * connection 
	 */
	if (ret_len == -1) {
		reinit_cache(cache_handle);
	}


	retval = db_get_cmpg_sp_info(adflex_dbconn, sp_info, campaign_id);

	if (retval != DB_ERROR_SUCCESS) {
		LOG_CRITICAL(DB_ERROR, MOD_DEFAULT, "db_get_cmpg_sp_info()");
		(*sp_info) = NULL;
		return retval;
	}

	if ((*sp_info) != NULL) {
		/* Element found in the database add it to the cache */
		retval = libmemcached_set(cache_handle, cmpg_sp_info_key, key_length, (void *) (*sp_info), sizeof(cmpg_sp_info_t), get_fte_cache_timeout(), 0);
	} else {
		retval = libmemcached_set(cache_handle, cmpg_sp_info_key, key_length, (void *) (&dummy_cmpg_sp_info), sizeof(cmpg_sp_info_t), get_fte_cache_timeout(), 0);
	}
	/*
	 * If we could not add the value, probably the server went down in between,
	 * so reinit the server
	 */
	if (retval != 0) {
		reinit_cache(cache_handle);
	}

	return ADS_ERROR_SUCCESS;
}

/*
 *
 * cache get the pub camp level boost factor value from DB
 *
 */


int cache_get_bid_boost_settings( cache_handle_t* cache_handle, db_connection_t* komli_dbconn, bid_boost_settings_t *bid_boost_data, long pub_id, long camp_id ) {


	char bid_boost_settings_key[MAX_KEY_SIZE];
	bid_boost_settings_t *cached_settings = NULL;

	int retval = 0;
        int key_length=0;       
        int ret_len = 0;

	key_length = snprintf( bid_boost_settings_key, MAX_KEY_SIZE, BID_BOOST_SETTINGS_KEY , pub_id , camp_id);

	cached_settings = ( bid_boost_settings_t *) libmemcached_get(cache_handle,bid_boost_settings_key , key_length ,&ret_len);
	if ( cached_settings ) {
#ifdef BIDBOOST_DEBUG
		llog_write(L_DEBUG,"BIDBOOST:PUB:%ld:CAMP:%ld:BOOST:%f",pub_id,cached_settings->campaign_id,cached_settings->bid_boost_factor); 
#endif
		bid_boost_data->campaign_id = cached_settings->campaign_id;
		bid_boost_data->bid_boost_factor = cached_settings->bid_boost_factor;
		bid_boost_data->disable_pubmatic_cut = cached_settings->disable_pubmatic_cut;
		free(cached_settings);
		cached_settings=NULL;
                return ADS_ERROR_SUCCESS;
	}

	/* this will serve the purpose of dummy*/
  bid_boost_data->bid_boost_factor = -1.0;
  bid_boost_data->campaign_id = camp_id;

	
	retval = db_get_bid_boost_settings(komli_dbconn, bid_boost_data, pub_id ,camp_id);

	if (retval != DB_ERROR_SUCCESS) {
                llog_write(L_DEBUG,"\nERROR: DB call failed for db_get_bid_boost_settings()");
		bid_boost_data->bid_boost_factor = -1.0;
                return retval;
        }

#ifdef BIDBOOST_DEBUG
    llog_write(L_DEBUG,"\nBIDBOOST:PUB:%d:CAMP:%d:BOOST:%f:DIABLE_CUT:%d\n",pub_id,bid_boost_data->campaign_id,bid_boost_data->bid_boost_factor,bid_boost_data->disable_pubmatic_cut);
#endif



	retval = libmemcached_set(cache_handle, bid_boost_settings_key ,
                                key_length, (void *) (bid_boost_data),
                                sizeof(bid_boost_settings_t),
                                get_fte_cache_timeout(), 0);


        return ADS_ERROR_SUCCESS;
}



int cache_get_integral_settings( cache_handle_t* cache_handle, db_connection_t* komli_dbconn,integral_data_t *integral_data, long pub_id) {
	char integral_settings_key[MAX_KEY_SIZE];
	integral_settings_t dummy_settings = {.campaign_id=-1, .enabled_ias_services=-1 , .score_field=-1 };
	integral_settings_t *cached_settings = NULL;
	int retval = 0;
        int key_length=0;       
        int ret_len = 0;

#ifdef URLCAT_DEBUG
	assert(integral_data->integral_settings == NULL);
#endif

	key_length = snprintf(integral_settings_key, MAX_KEY_SIZE, INTEGRAL_SETTINGS_KEY, pub_id);

	cached_settings = (integral_settings_t *) libmemcached_get(cache_handle, integral_settings_key, key_length,&ret_len);
	if ( cached_settings != NULL ) {
#ifdef URLCAT_DEBUG 
		print_ias_settings(cached_settings,ret_len,"from cache");
#endif
		integral_data->number_of_settings = ( ret_len / sizeof(integral_settings_t) );
		if ( (integral_data->number_of_settings == 1 ) && DUMMY_IAS_SETTINGS_FOUND(cached_settings) ) {
			UCAT_DEBUGLOG("Dummy data found in cache");
			free(cached_settings);
                        cached_settings = NULL;
			integral_data->number_of_settings = 0;
                        return ADS_ERROR_SUCCESS;
		}

		//reached here means found valid data in cache
		integral_data->integral_settings = cached_settings;
                return ADS_ERROR_SUCCESS;
	}

	/*
         * If ret_len is -1, that means there was some error, try to reinit the
         * connection 
         */
        if (ret_len == -1) {
                reinit_cache(cache_handle);
        }
	
	
	retval = db_get_integral_settings(komli_dbconn, &(integral_data->integral_settings), pub_id, &(integral_data->number_of_settings));

	if (retval != DB_ERROR_SUCCESS) {
                llog_write(L_DEBUG,"\nERROR: DB call failed for db_get_integral_settings()");
		integral_data->number_of_settings = 0;
                return retval;
        }

#ifdef URLCAT_DEBUG 
        print_ias_settings(integral_data->integral_settings,(integral_data->number_of_settings)*sizeof(integral_settings_t),"from DB");
#endif

	if( ((integral_data->number_of_settings) != 0 ) && (integral_data->integral_settings) != NULL ) {
        	/* Element found in the database add it to the cache */
                retval = libmemcached_set(cache_handle, integral_settings_key,
                                key_length, (void *) (integral_data->integral_settings),
                                (integral_data->number_of_settings)*sizeof(integral_settings_t),
                                get_fte_cache_timeout(), 0);
        } else {
                retval = libmemcached_set(cache_handle, integral_settings_key,
                                key_length, (void *) (&dummy_settings),
                                sizeof(integral_settings_t),
                                get_fte_cache_timeout(), 0);
        }
        /*
         * If we could not add the value, probably the server went down in between,
         * so reinit the server
         */
        if (retval != 0) {
                reinit_cache(cache_handle);
        }

        return ADS_ERROR_SUCCESS;
}
