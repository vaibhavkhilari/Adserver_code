/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current
PubMatic employees, managers or contractors who have executed
 Confidentiality and Non-disclosure agreements explicitly covering such access.

 The copyright notice above does not evidence any actual or intended publication or disclosure of this source
code, which includes
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION,
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE,
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION
DOES NOT CONVEY OR IMPLY ANY RIGHTS
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY
DESCRIBE, IN WHOLE OR IN PART.
 */


#include <stdio.h>
#include <stdlib.h>
#include "fte_types.h"
#include <error.h>
#include "ad_server_types.h"
#include "rt_types.h"
#include "libstats_util.h"
#include "rtb_brand_control_util.h"
#include "publisher_site_block_list.h"
#include "creative_filter.h"
#include "generic_thread.h"

extern global_bloom_filter_data g_bloom_filter_data[MAX_GLOBAL_BLOOM_FILTERS];
extern unsigned long long local_sent_ucrids_cache[MAX_SENT_UCRIDS_CACHE_LIMIT];

/* Check if creative was sent to RTAS in past, by looking into local cache */
int is_creative_already_sent_to_rtas(unsigned long long ucrid_to_check) {
	int hash_index = ucrid_to_check % MAX_SENT_UCRIDS_CACHE_LIMIT;
	unsigned long long ucrid_from_cache = local_sent_ucrids_cache[hash_index];

	/* Found in cache, that means we had sent this ucrid to RTAS */
	if (ucrid_from_cache == ucrid_to_check) {
		DEBUG_LOG("SENT_UCRID_HASHMAP: Ucrid[%llu] found in cache, at index[%d]", ucrid_to_check, hash_index);
		return 1;
	}

	/* Not found in cache, will be added to cache later after sending (in file logger/rtas_logger.c) */
	DEBUG_LOG("SENT_UCRID_HASHMAP: Ucrid[%llu] NOT found in cache, at index[%d]", ucrid_to_check, hash_index);
	return 0;
}

/* Check if creative is classified, by looking into classified creatives bloom  */
static int is_creative_classified(unsigned long long ucrid_to_check) {

	BKT_BLOOM_ARRAY* classified_crtv_bloom_filter = GET_GLOBAL_BLOOM_FILTER(UNIQUE_CREATIVE_BLOOM_FILTER);
	int len = 0;
	char str_ucrid_to_check[MAX_CRC64_CREATIVE_BLOOM_KEY_SZ + 1];

	len = snprintf(str_ucrid_to_check, MAX_CRC64_CREATIVE_BLOOM_KEY_SZ, "%llu", ucrid_to_check);
	str_ucrid_to_check[MAX_CRC64_CREATIVE_BLOOM_KEY_SZ] = '\0';

	if ((len > 0) && (NULL != classified_crtv_bloom_filter) && (NULL != classified_crtv_bloom_filter->bkt_bloom[0])) {
		if (bkt_bloom_check(str_ucrid_to_check,
					(const BKT_BLOOM**)classified_crtv_bloom_filter->bkt_bloom,
					classified_crtv_bloom_filter->bkt_bloom_count)) {
			DEBUG_LOG("CLASSIFIED_BLOOM: Ucrid[%llu] found in bloom filter.", ucrid_to_check);
			return 1;
		}
	}

	DEBUG_LOG("CLASSIFIED_BLOOM: Ucrid[%llu] NOT found in bloom filter.", ucrid_to_check);
	return 0;
}

/*
 * This function does two things
 * 1) If strict mode is ON for publisher, then filter the BID if creative is not classified,
 * 2) Decide whether we need to send the creative to RTAS for scanning.
 */
int apply_aq_strict_mode_filter(const fte_additional_params_t *fte_additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		rt_response_params_t* rt_response_params,
		int rt_response_count) {
	(void) fte_additional_parameters;
	int i;

	/* Loop over each bid to apply strict mode filter */
	for (i=0; i < rt_response_count; i++) {
		/* Skip already filtered campaigns */
		if(1 == adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag) {
			continue;
		}

		unsigned long long ucrid = rt_response_params[i].bid_response_params.crc64_uniq_creative_id;
		/* Check if creative is classified or not, And skip classified Creative bids */
		if(is_creative_classified(ucrid)) {
			DEBUG_LOG("AQ_STRICT_MODE::camp_id:[%d], Ucrid:[%llu] is classified",
					adcampaigns[rt_response_params[i].campaign_index].campaign_id, ucrid);
			continue;
		}

		/* This code will be un-commented in next phase of strict mode feature */
#if 0
		/* If creative is not classified and strict mode is ON for Publisher, filter this bid with AQ_STRICT_MODE_FILTER */
		if (1 == fte_additional_parameters->publisher_level_settings.publisher_acl_settings.acl_aq_strict_mode_flag) {
			adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
			adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = AQ_STRICT_MODE_FILTER;
		}
#endif
		/*
		 * If creative is not classified, we need to send it to RTAS for scanning.
		 * Check if it was not sent in past.
		 */
		if(!is_creative_already_sent_to_rtas(rt_response_params[i].bid_response_params.crc64_uniq_creative_id)) {
			adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->send_crtv_to_rtas_for_scanning = 1;
			DEBUG_LOG("AQ_STRICT_MODE::camp_id:[%d], Ucrid:[%llu] NOT found in sent ucrid hashmap",
					adcampaigns[rt_response_params[i].campaign_index].campaign_id, ucrid);
		}
	}

	return ADS_ERROR_SUCCESS;
}
