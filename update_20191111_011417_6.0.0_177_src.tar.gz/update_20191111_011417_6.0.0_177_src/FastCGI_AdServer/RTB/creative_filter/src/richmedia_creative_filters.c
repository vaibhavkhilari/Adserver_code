/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "fte_types.h"
#include <error.h>
#include <debug.h>
#include <typedefs.h>
#include "ad_server_types.h"
#include "rt_types.h"
#include "libstats_util.h"
#include "rtb_brand_control_util.h"
#include "publisher_site_block_list.h"
#include "url_blocklist.h"
#include "str_bitmap.h"
#include "log_fw.h"

#include "str_bitmap.h"
#include "richmedia_creative_filters.h"
#include "cache_publisher_site_crtype_filter_list.h"


void prepare_richmedia_creative_filters(richmedia_creative_filters_t *richmedia_creative_filters,
										cache_handle_t *cache_handle, 
										rt_request_params_t *rt_req_params,
										fte_additional_params_t *fte_additional_parameters) 
{
	richmedia_creative_filters->pubsite_battr_bitmap = 0;
	richmedia_creative_filters->pubsite_battr_bitmap = 0;

	//Prepare publisher site BATTR bitmap
	bitmap_t battr_bitmap = 0;
	const char * req_battr = rt_req_params->in_server_req_params->blocked_creative_attr;
	if( req_battr && *req_battr) { //battr found in ad request
		DPRINTF("Apply filter using request attr bitmap:%s", req_battr);
		battr_bitmap = (bitmap_t)rt_req_params->in_server_req_params->blocked_richmedia_creative_attr_map;
	} else { //get battr from db
		memcached_blocklist_t *blocked_list = (NULL != rt_req_params->pub_site_rich_media_params) 
								? rt_req_params->pub_site_rich_media_params->blocked_list : NULL;
		if(NULL != blocked_list) {
			const char * db_battr = (blocked_list->json_blocked_creative_attributes_len > 0
						&& blocked_list->json_blocked_creative_attributes_len < MAX_BLOCKED_CREATIVE_ATTRIBUTES_LIST_LEN)
						? (blocked_list->json_url_blocked_list + 4) : NULL;
			if(NULL != db_battr) {
				int db_battr_len = blocked_list->json_blocked_creative_attributes_len;
				char str_battr[db_battr_len+1];
				memcpy(str_battr, db_battr, db_battr_len);
				str_battr[db_battr_len] = '\0';
				DPRINTF("Apply filter using db attr bitmap:%s", str_battr);
				battr_bitmap = prepare_bitmap(str_battr, ",");
			} else {
				llog_write(L_DEBUG, "\nRMCF ERROR:Found invalid battr length... [p:%ld,s:%ld]",
						rt_req_params->in_server_req_params->publisher_id,
						rt_req_params->in_server_req_params->site_id);
			}
		}
	}
	richmedia_creative_filters->pubsite_battr_bitmap = battr_bitmap;

	//Prepare publisher site CRTYPE bitmap
	publisher_site_crtype_filter_list_t *publisher_site_crtype_filter_list 
		= cache_get_publisher_site_crtype_filter_list( 
						cache_handle,
						(fte_additional_parameters->kadserver_dbconn),
						rt_req_params->in_server_req_params->publisher_id,
						rt_req_params->in_server_req_params->site_id
						);
	
	if(0 != publisher_site_crtype_filter_list) {
		richmedia_creative_filters->pubsite_crtype_bitmap = publisher_site_crtype_filter_list->crtype_id_bitmap;
		free(publisher_site_crtype_filter_list);
	}
}

#define IS_VALID_RANGE(value, min, max) ((value)>=(min) && (value) <= (max))

bool apply_richmedia_creative_filters(richmedia_creative_filters_t *richmedia_creative_filters,
									  rt_response_params_t *rt_rsp_params,
									  ad_server_additional_params_t* additional_params,
									  publisher_site_ad_campaign_list_t *adcampaign)
{
	if(1 == adcampaign->ad_campaign_list_setings->filtered_flag) {
		// if already filtered, ignore.
		DPRINTF("Campaign %u already filtered... ignored...", adcampaign->campaign_id);
		return false;
	}
	
	//Check if publisher has any richmedia block list configured
	bitmap_t pubsite_battr_bitmap = richmedia_creative_filters->pubsite_battr_bitmap;
	bitmap_t pubsite_crtype_bitmap = richmedia_creative_filters->pubsite_crtype_bitmap;
	if(pubsite_battr_bitmap <=0 && pubsite_crtype_bitmap <= 0) {
		DPRINTF("No block lists found for the publisher; No filter applied");
		return false;
	}
	
	//Validate attr and crtype in RTB response and mark invalid if absent or not in range
	int rm_blocklist_check_method = additional_params->pubsite_default_settings.rm_blocklist_check_method;
	int rtb_attr_checkbit = rt_rsp_params->bid_response_params.rich_media_ad_creative_attribute_id;
	if(!IS_VALID_RANGE(rtb_attr_checkbit, MIN_CREATIVE_ATTR_VALUE, MAX_CREATIVE_ATTR_VALUE)) {
		rtb_attr_checkbit = 0;
	}
	int rtb_crtype_checkbit = rt_rsp_params->bid_response_params.creative_type;
	if(!IS_VALID_RANGE(rtb_crtype_checkbit, MIN_CREATIVE_TYPE_VALUE, MAX_CREATIVE_TYPE_VALUE)){
		rtb_crtype_checkbit = 0;
	}
	
	//Apply strict checking if enabled on invalid richmedia values in RTB response
	if(2 == rm_blocklist_check_method && 0 == rtb_attr_checkbit && 0 == rtb_crtype_checkbit) {
		adcampaign->ad_campaign_list_setings->filtered_flag = 1;
		adcampaign->ad_campaign_list_setings->reason_for_filtering = FILTER_RM_BLOCKLIST_STRICT_CHECK;
		DPRINTF("FILTER_RM_BLOCKLIST_STRICT_CHECK applied on Campaign %u [RTB_ATTR:%d, RTB_CRTYPE:%d]", 
				adcampaign->campaign_id, rtb_attr_checkbit, rtb_crtype_checkbit);
		return true;		
	}
	
	//Try to apply BATTR filter...
	if(0 != rtb_attr_checkbit && pubsite_battr_bitmap > 0 && CHECK_BIT_ON(pubsite_battr_bitmap, rtb_attr_checkbit)) {
		adcampaign->ad_campaign_list_setings->filtered_flag = 1;
		adcampaign->ad_campaign_list_setings->reason_for_filtering = FILTER_RM_CREATIVE_ATTR_BLOCKED;
		DPRINTF("FILTER_CREATIVE_ATTR_BLOCKED applied on Campaign %u [RTB_ATTR:%d PUB_BATTR_BITMAP:%lu]",
				adcampaign->campaign_id, rtb_attr_checkbit, pubsite_battr_bitmap);
		return true;
	}

	//Try to apply CRTYPE filter...
	if( 0 != rtb_crtype_checkbit && pubsite_crtype_bitmap > 0 && CHECK_BIT_ON(pubsite_crtype_bitmap, rtb_crtype_checkbit)) {
		adcampaign->ad_campaign_list_setings->filtered_flag = 1;
		adcampaign->ad_campaign_list_setings->reason_for_filtering = FILTER_RM_CRTYPE_BLOCKED;
		DPRINTF("FILTER_CRTYPE_BLOCKED applied on Campaign %u [RTB_CRTYPE:%d PUB_CRTYPE_BITMAP:%lu]",
				adcampaign->campaign_id, rtb_crtype_checkbit, pubsite_crtype_bitmap);
		return true;
	}
	
	DPRINTF("No richmedia filter applied on Campaign %u [RTB_ATTR:%d PUB_BATTR_BITMAP:%lu] [RTB_CRTYPE:%d PUB_CRTYPE_BITMAP:%lu]", 
				adcampaign->campaign_id, rtb_attr_checkbit, pubsite_battr_bitmap, rtb_crtype_checkbit, pubsite_crtype_bitmap);

	return false;	
}

