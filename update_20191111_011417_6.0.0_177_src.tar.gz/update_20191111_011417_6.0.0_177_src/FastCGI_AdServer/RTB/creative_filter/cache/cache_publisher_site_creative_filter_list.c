/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "fte_util.h"
#include "error.h"
#include "db_error.h"
#include "rt_types.h"
#include "cache_libmemcached.h"
#include "creative_filter.h"


int cache_get_publisher_site_creative_filter_list(
				long pub_id,
				long site_id,
				cache_handle_t* cache,
				db_connection_t* dbconn,
				BLOOM** publisher_site_creative_filter_list,
				int default_creative_preference) {

	/* Local variables */
	char publisher_site_creative_filter_wht_list_key[MAX_KEY_SIZE];
	char publisher_site_creative_filter_blk_list_key[MAX_KEY_SIZE];
	BLOOM *cached_publisher_site_creative_filter_list = NULL;
	BLOOM *publisher_site_creative_filter_wht_list = NULL;
	BLOOM *publisher_site_creative_filter_blk_list = NULL;
	const BLOOM dummy_entry = { .bit_array_size=0, .nelements=0};
	int retval = 0;
	int wht_list_key_length=0, blk_list_key_length=0;
	int ret_len = 0;
	size_t whitelist_ret_size = 0, blacklist_ret_size = 0;

	/* Validate input parameters */
	if (cache == NULL ||
			dbconn == NULL ||
			publisher_site_creative_filter_list == NULL ||
			*publisher_site_creative_filter_list != NULL) {
		llog_write(L_DEBUG, "\n(%s:%d): One of the input param is NULL, return.\n", __FILE__,  __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	(*publisher_site_creative_filter_list) = NULL;

	/* Create the key */
	snprintf(publisher_site_creative_filter_wht_list_key, MAX_KEY_SIZE, PUBLISHER_SITE_CREATIVE_FILTER_WHT_LIST, pub_id, site_id);
	snprintf(publisher_site_creative_filter_blk_list_key, MAX_KEY_SIZE, PUBLISHER_SITE_CREATIVE_FILTER_BLK_LIST, pub_id, site_id);
	wht_list_key_length = strlen(publisher_site_creative_filter_wht_list_key);
	blk_list_key_length = strlen(publisher_site_creative_filter_blk_list_key);

	/*
	 * Check if the information about this ad's active account is present in
	 * the cache based on the key
	 */
	 if(default_creative_preference == PUBLISHER_DEFAULT_PREFERENCE_BLACKLIST) {
		cached_publisher_site_creative_filter_list =
			(BLOOM*) libmemcached_get(cache,
					publisher_site_creative_filter_blk_list_key,
					blk_list_key_length,
					&ret_len);
	}
	else if(default_creative_preference == PUBLISHER_DEFAULT_PREFERENCE_WHITELIST) {
		cached_publisher_site_creative_filter_list = 
			(BLOOM*) libmemcached_get(cache,  
					publisher_site_creative_filter_wht_list_key, 
					wht_list_key_length, 
					&ret_len);
	}
	else {
		llog_write(L_DEBUG, "Error: Invalid default creative preference, pub:%ld site:%ld, default_preference:%d, %s:%d\n",
				pub_id, site_id, default_creative_preference, __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	if (cached_publisher_site_creative_filter_list != NULL) {
		BLOCKLIST_DEBUG("\nCreative_Bloom:pub:%ld site:%ld:: memcache_obj_size:%d, creative_id_count:%d, "
				"bit_array_size_bits:%zu, bit_array_size_bytes:%ld, default_preference:%d, %s:%d\n",
				pub_id, site_id, ret_len,
				cached_publisher_site_creative_filter_list->nelements,
				cached_publisher_site_creative_filter_list->bit_array_size,
				(long int)BIT_ARRAY_SIZE_BYTES(cached_publisher_site_creative_filter_list->bit_array_size),
				default_creative_preference,
				__FILE__, __LINE__);
		
		if(INVALID_FILTER_IN_CACHE(cached_publisher_site_creative_filter_list)) {
			free(cached_publisher_site_creative_filter_list);
			cached_publisher_site_creative_filter_list = NULL;
			return ADS_ERROR_SUCCESS; // return success if no/invalid dsp_creative_id_list for the publisher/site
		}
		//reaches here only if valid blocklist found in cache
		(*publisher_site_creative_filter_list) = cached_publisher_site_creative_filter_list;
		return ADS_ERROR_SUCCESS;
	}

	/*
	 * If ret_len is 0, that means there was some error, try to reinit the
	 * connection
	 */
	if (ret_len == -1) {
		reinit_cache(cache);
	}

	/*
	 * Reaches here when we do not find the ad's account information in the cache, so now
	 * get it from the database and add it to the cache and return
	 */
	retval = db_get_publisher_site_creative_filter_list(dbconn, 
			pub_id,
			site_id,
			&publisher_site_creative_filter_wht_list,
			&publisher_site_creative_filter_blk_list,
			&whitelist_ret_size,
			&blacklist_ret_size);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG,"\n DB call failed for db_get_publisher_site_creative_filter_list(), %s:%d\n",__FILE__,__LINE__);
		bloom_destroy(&publisher_site_creative_filter_wht_list);
		bloom_destroy(&publisher_site_creative_filter_blk_list);
		return retval;
	}

	if(publisher_site_creative_filter_wht_list != NULL) {

		/* Element found in the database add it to the cache */
		retval = libmemcached_set(cache, publisher_site_creative_filter_wht_list_key, 
				wht_list_key_length, (void *) (publisher_site_creative_filter_wht_list),
				whitelist_ret_size, 
				get_fte_cache_timeout(), 0);
	} else {
		retval = libmemcached_set(cache, publisher_site_creative_filter_wht_list_key, 
				wht_list_key_length, (void *)(&dummy_entry),
				sizeof(BLOOM), 
				get_fte_cache_timeout(), 0);
	}

	if(publisher_site_creative_filter_blk_list != NULL) {

		/* Element found in the database add it to the cache */
		retval = libmemcached_set(cache, publisher_site_creative_filter_blk_list_key, 
				blk_list_key_length, (void *) (publisher_site_creative_filter_blk_list),
				blacklist_ret_size, 
				get_fte_cache_timeout(), 0);
	} else {
		retval = libmemcached_set(cache, publisher_site_creative_filter_blk_list_key, 
				blk_list_key_length, (void *)(&dummy_entry),
				sizeof(BLOOM), 
				get_fte_cache_timeout(), 0);
	}

	if(default_creative_preference == PUBLISHER_DEFAULT_PREFERENCE_BLACKLIST) {
		bloom_destroy(&publisher_site_creative_filter_wht_list);
		(*publisher_site_creative_filter_list) = publisher_site_creative_filter_blk_list;
	}
	else if(default_creative_preference == PUBLISHER_DEFAULT_PREFERENCE_WHITELIST) {
		bloom_destroy(&publisher_site_creative_filter_blk_list);
		(*publisher_site_creative_filter_list) = publisher_site_creative_filter_wht_list;
	}
	else {
		bloom_destroy(&publisher_site_creative_filter_wht_list);
		bloom_destroy(&publisher_site_creative_filter_blk_list);
	}

	/*
	 * If we could not add the value, probably the server went down in between,
	 * so reinit the server
	 */
	if (retval != 0) {
		reinit_cache(cache);
	}

	return ADS_ERROR_SUCCESS;
}
