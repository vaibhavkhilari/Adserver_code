/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "video.h"
#include "error.h"
#include "json.h"
#include "json_util.h"
#include "json_object_private.h"
#include "default_adapter.h"
#include "rtb_brand_control_util.h"
#include "video_xml.h"
#include "log_fw.h"
#include "string_util.h"
#include "native_resp_handler.h"
#include "url_util.h"

json_object *get_json_child_from_parent(json_object *parent_json_object, const char *key, json_type child_json_type);
void initialize_bid_response(rt_bid_response_params_t *bid_response_params){

	
	bid_response_params->ecpm = 0.0;
	bid_response_params->ebid[0] = '\0';
	bid_response_params->u_url.html_url[0] = '\0';
	bid_response_params->request_id[0] = '\0';
	bid_response_params->transaction_id[0] = '\0';
        bid_response_params->cookie[0] = '\0';
        bid_response_params->landing_page_url[0] = '\0';
        bid_response_params->landing_page_tld[0] = '\0';
        bid_response_params->creative_id[0] = '\0';
        bid_response_params->creative_type = -1;
	bid_response_params->creative_len = 0;
        bid_response_params->dsp_buyer_id = 0;
				bid_response_params->pubmatic_dsp_buyer_id = 0;
        bid_response_params->rich_media_ad_creative_attribute_id = -1 ;
        bid_response_params->pub_deal_id[0] = '\0';
	bid_response_params->iurl[0] = '\0';
	bid_response_params->dsp_campaign_id[0] = '\0';
	bid_response_params->response_buffer = NULL;

        /* Native params initialization */
/* OLD Native Protocol Implementation
	bid_response_params->native_resp_params.title[0] = '\0';
	bid_response_params->native_resp_params.text[0] = '\0';
	bid_response_params->native_resp_params.iconImg[0] = '\0';
	bid_response_params->native_resp_params.mainImg[0] = '\0';
	bid_response_params->native_resp_params.ctatext[0] = '\0';
	bid_response_params->native_resp_params.rating = -1;
	bid_response_params->native_resp_params.clickUrl[0] = '\0';
	bid_response_params->native_resp_params.impTracker[0] = '\0';
	bid_response_params->native_resp_params.clickTracker[0] = '\0';
*/

	bid_response_params->rich_media_tech_name[0] = '\0';
}


void printbid(long oper_id, int campaign_id, rt_bid_response_params_t *bid_response_params, ad_server_additional_params_t *additional_parameter, int bid_currency, int deal_no_bid_reason)
{
  if(!bid_response_params){
    return;
  }

  if(additional_parameter->adserver_config_params->rtb_debug_flag >= 1
     && oper_id == SERV_ADS_VIDEO_OPER){
     logVidMessage("VIDEO_INFO|Multi-BidRESP: CId:%ld BidId:%s ReqId:%s BID:%f\n",
                campaign_id,
                bid_response_params->transaction_id,
                bid_response_params->request_id,
                bid_response_params->ecpm);
  }

  if(additional_parameter->adserver_config_params->rtb_debug_flag == 1){
        fprintf(
                stderr,"\nMULTI BID RESPONSE: cid : %d"
                "%s : %s"  // Transaction ID
                "%s : %s"  // Request ID
                "%s : %f"  // eCPM
                "%s : %s"  // ebid
                "%s : %s"  // Piggyback Cookie
                "%s : %s"  // Landing page URL
                "%s : %s"  // Landing page TLD
                "%s : %s"  // Creative ID
                "%s : %d"  // Creative Type
                "%s : %d"  // Seat ID
                "%s : %d"  // Creative Attribute
                "%s : %s"  // Deal ID
                "%s : %d"  // Currency ID
                "%s : %s"  // iUrl
                "%s : %s"  // Campaign ID
                "%s : %d"  // dnbr
                "%s : %s"  // Rich Media Tech. Name
                ,
                campaign_id,
                ID, bid_response_params->transaction_id,
                REQUEST_ID, bid_response_params->request_id,
                BID, bid_response_params->ecpm,
                EBID, bid_response_params->ebid,
                PIGGYBACK_COOKIE, bid_response_params->cookie,
                LANDING_PAGE_URL, bid_response_params->landing_page_url,
                LANDING_PAGE_TLD, bid_response_params->landing_page_tld,
                CREATIVEID, bid_response_params->creative_id,
                CREATIVE_TYPE, bid_response_params->creative_type,
                SEAT, bid_response_params->dsp_buyer_id,
                RICH_MEDIA_AD_CREATIVE_ATTRIBUTE, bid_response_params->rich_media_ad_creative_attribute_id,
                DEAL_ID, bid_response_params->pub_deal_id,
                BID_CURRENCY, bid_currency,
                IURL, bid_response_params->iurl,
                DSP_CAMP_ID, bid_response_params->dsp_campaign_id,
                DEAL_NO_BID_REASON, deal_no_bid_reason,
                RICH_MEDIA_TECH_ID, bid_response_params->rich_media_tech_name
	);
    if (bid_response_params->type == JS_URL_TYPE) {
      llog_write(L_DEBUG," %s : %s", CREATIVE_JS, bid_response_params->u_url.js_url);
    }
    else if (bid_response_params->type == HTML_URL_TYPE) {
      llog_write(L_DEBUG," %s : %s", CREATIVE_HTML, bid_response_params->u_url.html_url);
    } else if(bid_response_params->type == VIDEO_CREATIVE_TAG_TYPE) {
      llog_write(L_DEBUG, "Video %s:%s", CREATIVE_TAG, bid_response_params->u_url.video_creative_tag);
    }

  }
}

void remove_char(char *str, char c)
{
  char *s;
  char *d;
  if(str == NULL)
  {
   return;
  }
  for (s=d=str;*s;s++){
    if(*s == c){
      continue;
    }
    *d = *s;
    d++;
  }
  *d = '\0';
 
}

//get the bid details into RTB response from the given Bid JSON object
static void get_dsp_bids(long oper_id, json_object *bid_obj, rt_response_params_t *rt_response_params, int currency_id, fte_additional_params_t *fte_additional_params, const ad_server_additional_params_t * additional_params){

  json_object *transaction_id = NULL;
  json_object *request_id = NULL;
  json_object *ecpm  = NULL;
  json_object *ebid = NULL;
  json_object *creativeJSURL = NULL;
  json_object *creativeHTMLURL = NULL;
  json_object *creativeTAG = NULL;
  json_object *creativeURL = NULL;
  json_object *cookie = NULL;
  json_object *landing_page_tld = NULL;
  json_object *landing_page_url = NULL;
  json_object *creative_id = NULL;
  json_object *creative_type = NULL;
  json_object *dsp_buyer_id = NULL;
  json_object *rich_media_ad_creative_attribute_id = NULL;
  json_object *rich_media_tech_id  = NULL;
  json_object *pub_deal_id = NULL;
  json_object *iurl = NULL;
  json_object *dsp_camp_id = NULL;
/* OLD Native Protocol Implementation
  json_object *native_object = NULL;
*/
  rt_bid_response_params_t *bid_params = NULL;
  char tmp_landing_page_tld[MAX_DOMAIN_NAME_LENGTH + 1] = {'\0'};
  int len = 0;

/* OLD Native Protocol Implementation
  int is_native_request = (fte_additional_params->in_server_req_params->ad_type == AD_TYPE_NATIVE) ? 1 : 0;
*/
  bid_params = &rt_response_params->bid_response_params;
  if (bid_obj == NULL){
    DEBUG_LOG( "\nMultibid: bid_obj is NULL %ld",rt_response_params->campaign_id);
    return;
  }

  transaction_id = get_json_child_from_parent(bid_obj, ID, json_type_string);
  if (transaction_id){
    strcpy( bid_params->transaction_id, transaction_id->o.c_string);
  }
  request_id = get_json_child_from_parent(bid_obj, REQUEST_ID , json_type_string);
  if(request_id){
    strcpy( bid_params->request_id, request_id->o.c_string);
  }
  ecpm = get_json_child_from_parent(bid_obj, BID, json_type_int);
  if(ecpm && ecpm->o.c_int){
    bid_params->ecpm = ecpm->o.c_int;
    bid_params->ecpm = CONVERT_NATIVE_CURRENCY_TO_USD(bid_params->ecpm, currency_id,fte_additional_params->currency_xrate_map,  fte_additional_params->currency_count);
  }
  else
  {
     ecpm = get_json_child_from_parent(bid_obj, BID, json_type_double);
     if(ecpm)
     {
        bid_params->ecpm = ecpm->o.c_double;
	bid_params->ecpm = CONVERT_NATIVE_CURRENCY_TO_USD(bid_params->ecpm, currency_id,fte_additional_params->currency_xrate_map,  fte_additional_params->currency_count);
     }
  }
  ebid = get_json_child_from_parent(bid_obj, EBID , json_type_string);
  if(ebid){
    strcpy(bid_params->ebid, ebid->o.c_string);
  }

  creativeJSURL  = get_json_child_from_parent(bid_obj, CREATIVE_JS, json_type_string);
  if(creativeJSURL){
    strncpy(bid_params->u_url.js_url, creativeJSURL->o.c_string, MAX_RESPONSE_URL_SIZE);
    //remove_char(creativeJSURL->o.c_string, '\\');
    bid_params->type = JS_URL_TYPE;
  }

  creativeHTMLURL = get_json_child_from_parent(bid_obj, CREATIVE_HTML, json_type_string);
  if(creativeHTMLURL){
    strncpy(bid_params->u_url.html_url, creativeHTMLURL->o.c_string, MAX_RESPONSE_URL_SIZE);
    bid_params->type = HTML_URL_TYPE;
  }

  creativeTAG = get_json_child_from_parent(bid_obj, CREATIVE_TAG, json_type_string);
  if(creativeTAG){
    char *tmpStr = creativeTAG->o.c_string;
    if(oper_id == SERV_ADS_VIDEO_OPER) {
       bid_params->u_url.video_creative_tag[0] = '\0';
       bid_params->type = VIDEO_CREATIVE_TAG_TYPE;
       if(tmpStr && *tmpStr) {
	  int allowed_creative_buff_size = additional_params->pubsite_default_settings.video_creative_buff_size;
          nstrcpy(bid_params->u_url.video_creative_tag, tmpStr, allowed_creative_buff_size);
          bid_params->u_url.video_creative_tag[allowed_creative_buff_size] = '\0';
       }
/* OLD Native Protocol Implementation
    } else if (is_native_request) {
	bid_params->u_url.creative_tag[0] = '\0';
*/
    } else  {
       nstrcpy(bid_params->u_url.creative_tag, creativeTAG->o.c_string, MAX_CREATIVE_TAG_SIZE);
       bid_params->type = CREATIVE_TAG_TYPE;
   }
  }

  //Video Creative URL
  if(oper_id == SERV_ADS_VIDEO_OPER) {
     creativeURL = get_json_child_from_parent(bid_obj, VIDEO_CREATIVE_URL, json_type_string);
     if(creativeURL){
        bid_params->u_url.video_creative_tag[0]='\0';
        bid_params->type = VIDEO_CREATIVE_TAG_TYPE;
        char *tmpStr = creativeURL->o.c_string;
        if(tmpStr && *tmpStr) {
	   int allowed_creative_buff_size = additional_params->pubsite_default_settings.video_creative_buff_size;
           nstrcpy(bid_params->u_url.video_creative_tag, tmpStr, allowed_creative_buff_size);
           bid_params->u_url.video_creative_tag[allowed_creative_buff_size]='\0';
        } 
     }
  }

  /* NATIVE object */
/* OLD Native Protocol Implementation
  if (is_native_request) {
          native_object = get_json_child_from_parent(bid_obj, NATIVE_CREATIVE, json_type_object);
          if ( native_object != NULL ) {
          	  get_native_resp_params(native_object, bid_params);
                  form_native_creative_json(bid_params);
		//bid_params->type = NATIVE_CREATIVE_TYPE;
#ifdef NATIVE_DEBUG
                  llog_write(L_DEBUG,"\nMB_NATIVE Multibid native JSON creative: %s, %s:%d\n", bid_params->u_url.native_creative_json, __FILE__,__LINE__);
#endif
          } else {
                  bid_params->u_url.native_creative_json[0] = '\0';
#ifdef NATIVE_DEBUG
                  llog_write(L_DEBUG,"\nMB_NATIVE Multibid native JSON creative is NULL %s:%d\n", __FILE__,__LINE__);
#endif
          }
  }
*/


  cookie  = get_json_child_from_parent(bid_obj, PIGGYBACK_COOKIE, json_type_string);
  if(cookie){
    strncpy(bid_params->cookie, cookie->o.c_string, MAX_COOKIE_SIZE);
  }

  landing_page_url = get_json_child_from_parent(bid_obj, LANDING_PAGE_URL , json_type_string);
  if(landing_page_url){
    strncpy(bid_params->landing_page_url, landing_page_url->o.c_string, MAX_RESPONSE_URL_SIZE);
    bid_params->landing_page_flag|=1;
  }

  landing_page_tld = get_json_child_from_parent(bid_obj, LANDING_PAGE_TLD , json_type_string);
  if(landing_page_tld){
    strncpy(bid_params->landing_page_tld, landing_page_tld->o.c_string, MAX_DOMAIN_NAME_LENGTH);
    bid_params->landing_page_flag|=2;
  }
  creative_id = get_json_child_from_parent(bid_obj, CREATIVEID , json_type_string);
  if(creative_id == NULL){
  creative_id = get_json_child_from_parent(bid_obj, CREATIVEID1 , json_type_string);
 	 if(creative_id){
   		 strncpy(bid_params->creative_id ,  creative_id->o.c_string, MAX_CREATIVE_ID_SIZE);
	}
  }
  else{
  		strncpy(bid_params->creative_id ,  creative_id->o.c_string, MAX_CREATIVE_ID_SIZE);
  }

  creative_type = get_json_child_from_parent(bid_obj, CREATIVE_TYPE,
                  json_type_int);
  if (creative_type) {
          int t = creative_type->o.c_int;
          if (MIN_CREATIVE_TYPE_VALUE <= t && t <= MAX_CREATIVE_TYPE_VALUE) {
                  bid_params->creative_type = t;
          }
  }

  dsp_buyer_id = get_json_child_from_parent(bid_obj, SEAT, json_type_int);
  if(dsp_buyer_id){
    bid_params->dsp_buyer_id = dsp_buyer_id->o.c_int;
  }

  rich_media_ad_creative_attribute_id = 
    get_json_child_from_parent(bid_obj, RICH_MEDIA_AD_CREATIVE_ATTRIBUTE, json_type_int);
  if(rich_media_ad_creative_attribute_id){
    bid_params->rich_media_ad_creative_attribute_id = rich_media_ad_creative_attribute_id->o.c_int;
  }

  rich_media_tech_id  = get_json_child_from_parent(bid_obj, RICH_MEDIA_TECH_ID, json_type_string);
  if(rich_media_tech_id){
    nstrcpy(bid_params->rich_media_tech_name, rich_media_tech_id->o.c_string, MAX_RICH_MEDIA_TECH_ID_LEN);
    bid_params->rich_media_tech_name[MAX_RICH_MEDIA_TECH_ID_LEN] = '\0';
  }

  pub_deal_id = get_json_child_from_parent(bid_obj, DEAL_ID , json_type_string);
  if(pub_deal_id){
    strncpy(bid_params->pub_deal_id, pub_deal_id->o.c_string, MAX_DEAL_ID_LEN);
  }        

  iurl = get_json_child_from_parent(bid_obj, IURL, json_type_string);
  if(iurl){
    nstrcpy(bid_params->iurl, iurl->o.c_string, MAX_IURL_SIZE);
    bid_params->iurl[MAX_IURL_SIZE] = '\0';
  } 
       
  dsp_camp_id = get_json_child_from_parent(bid_obj, DSP_CAMP_ID, json_type_string);
  if(dsp_camp_id){
    nstrcpy(bid_params->dsp_campaign_id, dsp_camp_id->o.c_string, MAX_DSP_CAMPAIGN_ID_LEN);
    bid_params->dsp_campaign_id[MAX_DSP_CAMPAIGN_ID_LEN] = '\0';
  }       
 
  //check for verifying mandatory params. If either of these are invalid, we invalidate the request
  if (
      bid_params->transaction_id[0] == '\0'
      ||
      bid_params->request_id[0] == '\0'
      ||
      (
       bid_params->ecpm > 0.0
       &&
       bid_params->u_url.html_url[0] == '\0'
      )
     ) {
    DEBUG_LOG("\n Multibid: Realtime response incomplete for campaign %ld. Invalidating the entry ",rt_response_params->campaign_id);
    bid_params->ecpm = 0.0;
    return;
  }


  bid_params->response_complete = 1;
  if (bid_params->landing_page_flag == 1 || bid_params->landing_page_flag == 3) {
    // extract the tld and store in landing_page_tld
    len = strlen(bid_params->landing_page_url);
    // this can be commented if we are sure that DSP will never send the url or tld in upper case
    lowercase_string(bid_params->landing_page_url, 0, len - 1);
    get_domain_name_from_url(bid_params->landing_page_url, bid_params->landing_page_tld, MAX_DOMAIN_NAME_LENGTH + 1);
  } else if (bid_params->landing_page_flag == 2) {
    // We have only got tld
    len = strlen(bid_params->landing_page_tld);
    lowercase_string(bid_params->landing_page_tld, 0, len - 1);
    // remove the http:// OR https:// which might be present in the TLD and also remove '?' or '/' and remaining characters after that from TLD
    get_domain_name_from_url(bid_params->landing_page_tld, tmp_landing_page_tld, MAX_DOMAIN_NAME_LENGTH + 1);
    strncpy (bid_params->landing_page_tld, tmp_landing_page_tld,  MAX_DOMAIN_NAME_LENGTH);
    bid_params->landing_page_tld[MAX_DOMAIN_NAME_LENGTH] = '\0';
  }
  DEBUG_LOG("\nlanding page url=  %s \n landing page tld = %s ", bid_params->landing_page_url, bid_params->landing_page_tld);


  return;

}

/*
 * Copy realtime api config of the campaign to its multibid structure
 */
void copy_rt_response_params(rt_response_params_t *src, rt_response_params_t *dest){

	// initialization rt_response_params
	rt_bidding_initialize(dest);
	//initialize_bid_response(&dest->bid_response_params); //initialized in rt_bidding_initialize()
  dest->campaign_id = src->campaign_id;
  dest->campaign_index = src->campaign_index;
  dest->dp_id= src->dp_id;
  dest->dsp_user_match_found = src->dsp_user_match_found;
  dest->digitrust_id_present = src->digitrust_id_present;
  dest->log_qps_logger = src->log_qps_logger;
  dest->skip_user_floor = src->skip_user_floor;
  dest->apply_normal_distribution = src->apply_normal_distribution;
  dest->bid_price_encryption_enabled = src->bid_price_encryption_enabled;
  dest->second_price_encryption_enabled = src->second_price_encryption_enabled;
  dest->click_tracking_url_encoding_enabled = src->click_tracking_url_encoding_enabled;
	dest->pass_blank_click_tracking_url = src->pass_blank_click_tracking_url;
  dest->send_winloss_info = src->send_winloss_info;
  dest->protocol = src->protocol;
  dest->enabled_ias_services = src->enabled_ias_services;
  dest->currency_id = src->currency_id;
  dest->deal_no_bid_reason = src->deal_no_bid_reason;
	dest->is_multibid = src->is_multibid;
	dest->buyer_id_passing_enable_flag = src->buyer_id_passing_enable_flag;
	dest->supress_second_price_auction_on_same_campaign =	src->supress_second_price_auction_on_same_campaign;
	dest->rt_req_id_index = src->rt_req_id_index;
	dest->parent_index = src->parent_index;
	dest->req_ad_dimensions_from_tag = src->req_ad_dimensions_from_tag;
	dest->res_ad_dimension = src->res_ad_dimension;
	dest->log_full_user_id = src->log_full_user_id;
	dest->open_auction_type = src->open_auction_type;
	dest->rtc_settings = src->rtc_settings;
	nstrcpy(dest->bid_response_params.second_price_macro,
			src->bid_response_params.second_price_macro,
			MAX_SECOND_PRICE_MACRO_SIZE);

	nstrcpy(dest->bid_response_params.clicktrack_keyword,
			src->bid_response_params.clicktrack_keyword,
			MAX_RTB_CLICKTRACK_KEYWORD_LEN);
	dest->bid_response_params.clicktrack_keyword[MAX_RTB_CLICKTRACK_KEYWORD_LEN] = '\0';

}

void  parse_response_multi(long oper_id, rt_response_params_t **ptr_rt_response_params,
                          int *response_alloc_count,
                          int index,
                          ad_server_additional_params_t *additional_parameter,
                          int *response_count,
			  fte_additional_params_t *ptr_fte_additional_params, 
			  rt_request_params_t *rt_request_params ){
  int i = 0;
  json_object *json_obj = NULL;
  json_object * bid_obj = NULL;
  json_object *bid_arr = NULL;
  json_object *currrency_obj= NULL;
  json_object *dnbr_obj = NULL;
  int bid_array_len = 0;
  char *buffer = NULL;
  rt_response_params_t *rt_response_params = NULL;
  fte_additional_params_t *fte_additional_params = (fte_additional_params_t*) ptr_fte_additional_params;

  rt_response_params = *ptr_rt_response_params;
  // Initialize to default : USD
  rt_response_params[index].currency_id = USD_CURRENCY_ID;

  buffer = rt_response_params[index].bid_response_params.response_buffer;

  if(buffer == NULL){
    //llog_write(L_DEBUG,"\n ERROR: Multibid API RESPONSE: NULL for Campaign %d", rt_response_params[index].campaign_id);
	LOG_WARNING(MBID_API_RESP,MOD_DEFAULT,rt_response_params[index].campaign_id,"null");
    return;
  }
  if (additional_parameter->adserver_config_params == NULL){
     //llog_write(L_DEBUG,"adserver config passed is null");
	 LOG_MESSAGE(MOD_DEFAULT,"AdServer config NULL\n");
     return;
  }
  
  if(additional_parameter->adserver_config_params->rtb_debug_flag ==  1 ){
	ad_server_req_param_t *in_server_req_params = rt_request_params->in_server_req_params;
	llog_write(L_DEBUG, "\nMULTIBID API RESPONSE for Campaign %ld, P:%ld,S:%ld,A:%ld,O:%ld, start:  %s :end \n", rt_response_params[index].campaign_id, in_server_req_params->publisher_id,in_server_req_params->site_id, in_server_req_params->ad_id, in_server_req_params->oper_id, buffer);
	//LOG_WARNING(MBID_API_RESP,1,rt_response_params[index].campaign_id,buffer);
	   
  }

  json_obj = json_tokener_parse(buffer);
  if ((json_obj == NULL) || (is_error(json_obj))) {
    //llog_write(L_DEBUG,"\nMultibid : json_tokener_parse failed for Campaign %d\n", rt_response_params[index].campaign_id);
	LOG_WARNING(MBID_JSON_TOK_PARSE,MOD_DEFAULT,rt_response_params[index].campaign_id,"FAIL");
    return;    
  }

  currrency_obj = get_json_child_from_parent(json_obj, BID_CURRENCY, json_type_string);
  if(currrency_obj == NULL){

    rt_response_params[index].currency_id = USD_CURRENCY_ID;
  }else {
                rt_response_params[index].currency_id =  get_currency_id_from_hash(fte_additional_params->currency_xrate_map, currrency_obj->o.c_string);
        }

  dnbr_obj = get_json_child_from_parent(json_obj, DEAL_NO_BID_REASON, json_type_int);
  if ( dnbr_obj != NULL ) {
    rt_response_params[index].deal_no_bid_reason = dnbr_obj->o.c_int;
  }


  
  bid_arr = get_json_child_from_parent(json_obj, BID_ARRAY, json_type_array);
  if(bid_arr == NULL){
	//llog_write(L_DEBUG,"\nMultibid: Bid array is null or currency code is invalid.");
	LOG_WARNING(MBID_NULL_ARRAY,MOD_DEFAULT);
    if ((json_obj != NULL) && (!is_error(json_obj))){
      json_object_put(json_obj);
      json_obj = NULL;
    }
    return;
  }
  bid_array_len = json_object_array_length(bid_arr);

  //first bid will be copied to original rt_response_params
  if(bid_array_len > 0){
    bid_obj = json_object_array_get_idx(bid_arr, 0);
    rt_response_params[index].child_index = -1;
    get_dsp_bids(oper_id, bid_obj, &rt_response_params[index], rt_response_params[index].currency_id,  fte_additional_params, additional_parameter);
    rt_response_params[index].bid_response_params.bid_id = 0;
    printbid(oper_id, rt_response_params[index].campaign_id, &rt_response_params[index].bid_response_params, additional_parameter, rt_response_params[index].currency_id, rt_response_params[index].deal_no_bid_reason);
  }

  //Now increase the response object array to accomodate the additional bids
  //Each additional bid-object in the multi-bid response will be treated as 
  //a different RTB response from different DSPs
  if(*response_alloc_count < *response_count + bid_array_len - 1){
    rt_response_params = realloc(*ptr_rt_response_params, ((*response_alloc_count) + RT_RESPONSE_INCREMENT_COUNT) * sizeof(rt_response_params_t));
    if(rt_response_params){
      *ptr_rt_response_params =  rt_response_params;
      *response_alloc_count =  (*response_alloc_count) + RT_RESPONSE_INCREMENT_COUNT;
    }
    else{
      DEBUG_LOG("Multibid : Not enough  memory to accomodate bids");
      if ((json_obj != NULL) && (!is_error(json_obj))){
        json_object_put(json_obj);
        json_obj = NULL;
      }
      return;
    }
  }


  //If dsp send more than one bid we will treat it as a deferent response.
  //We will add other bids to the end of array
  for(i = 1; i < bid_array_len && i < MAX_BIDS_LIMIT; i++){
    bid_obj = json_object_array_get_idx(bid_arr, i);
    if(bid_obj)
    {
	copy_rt_response_params(&rt_response_params[index], &rt_response_params[*response_count]);
	rt_response_params[*response_count].bid_response_params.req_processed = 1;

      get_dsp_bids(oper_id, bid_obj, &rt_response_params[*response_count], rt_response_params[index].currency_id,  fte_additional_params, additional_parameter);
      rt_response_params[*response_count].bid_response_params.bid_id = i;


      strncpy(rt_response_params[*response_count].bid_response_params.clicktrack_keyword,
              rt_response_params[index].bid_response_params.clicktrack_keyword,
              MAX_RTB_CLICKTRACK_KEYWORD_LEN);
      rt_response_params[*response_count].bid_response_params.clicktrack_keyword[MAX_RTB_CLICKTRACK_KEYWORD_LEN] = '\0';

      strncpy(rt_response_params[*response_count].bid_response_params.second_price_macro,
              rt_response_params[index].bid_response_params.second_price_macro,
              MAX_SECOND_PRICE_MACRO_SIZE);
      rt_response_params[*response_count].bid_response_params.second_price_macro[MAX_SECOND_PRICE_MACRO_SIZE] = '\0';

      printbid(oper_id, rt_response_params[*response_count].campaign_id, &rt_response_params[*response_count].bid_response_params, additional_parameter, rt_response_params[index].currency_id, rt_response_params[index].deal_no_bid_reason);
			rt_response_params[index].child_index = *response_count;
			index = *response_count;
      *response_count = *response_count + 1;
    }
  }

  //free json object
  if ((json_obj != NULL) && (!is_error(json_obj))){
    json_object_put(json_obj);
    json_obj = NULL;
  }
}

/*
main(int argc, char** argv) {

        rt_bid_response_params_t *bid_list;
        char filename[] = "input";
        FILE *file = fopen ( filename, "r" );
        char line [1000000]; 
        if ( file != NULL )
        {
               if(!fgets ( line, sizeof line, file ))
               { 
                      fputs ( line, std
               }
       }
       printf("%s",line);
       fclose ( file );
       bid_list = parse_json(line);
       return;
}
*/
