/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <rtb_util.h>
#include <default_adapter.h>
#include "errno.h"
#include <string_util.h>
#include "http_response_wrapper.h"
#include "rtb_brand_control_util.h"
#include "deal.h"
#include "price_encryption.h"
#include <string.h>
#include "video.h"
#include "platform.h"
#include "log_fw.h"
#include "native_resp_handler.h"
#include "json.h"
#include "url_util.h"

#define PC_TARGET_KEY "i"
#define HTTP_SCHEME "http://"
#define LEN_HTTP_SCHEME 7
#define HTTPS_SCHEME "https://"
#define LEN_HTTPS_SCHEME 8
#define ENCODED_XFF_MAX_LEN (2*MAX_LEN_XFF)
extern currency_hash_t g_currency_hash[]; 
extern char* g_drproxy_url;
extern char* g_local_primary_drproxy_url;
extern char* g_local_secondary_drproxy_url;

extern const char* get_header_value( const http_header_map_t* header_map, const char* key);

extern json_object *get_json_child_from_parent(json_object *parent_json_object, const char *key, json_type child_json_type);
void validate_request_url(char *url) {
	int i;
	for ( i = 0; url[i] != '\0'; i++ ) {
		if( url[i] == ' ' ) {
			llog_write(L_DEBUG,"\nRTBERROR: Invalid url '%s'\n",url);
			break;
		}
	}
}

void lowercase_string(
		char* str,
		int left,
		int right
		)
{
	int i;
	for (i = left; i <=right; i++) {
		//str[i] = toLower(str[i]);
		if ( str[i] >= 'A' && str[i] <= 'Z') {
			str[i] += 32;
		}
	}
}

/* Creates a request url which is sent to ad network */
int default_get_request_url(
		rt_request_params_t *rt_request_params,
		const rt_request_url_params_mask_t * rt_request_url_mask,
		rt_response_params_t *out_response_params,
		ad_server_additional_params_t *additional_parameter,
		char *request_url_with_mandatory_params,
		char* campaign_cookie,
		publisher_site_ad_campaign_list_t *adcampaigns
		)
{
	char* strptr = NULL;
	char ts_buff[50] = "\0";
	int optout_set = 0;

	int len = 0;
	int i,ret=0,val=0;
	int space_left = MAX_REQUEST_URL_SIZE + 1; // this is the maximum space in the buffer containing the DSP url
	int iab_vertical_count = 0;
	site_verticals_t* iab_verticals = NULL;
	char iab_verticals_for_dsp[MAX_LENGTH_SITE_IAB_VERTICALS]; 
	char encoded_iab_verticals[MAX_LENGTH_ENCODED_SITE_IAB_VERTICALS]; 
        int avail_space = MAX_LENGTH_SITE_IAB_VERTICALS;
	iab_verticals_for_dsp[0]='\0';
	encoded_iab_verticals[0]='\0';

	strptr = (char *)out_response_params->bid_response_params.request_url;
	bool ip_masking_enabled = adcampaigns->ad_campaign_list_setings->ip_masking_enabled;	
	/* print the url eg: http://www.my.com/ads */
	if(
			additional_parameter->adserver_config_params != NULL
			&&
			additional_parameter->adserver_config_params->rtb_debug_flag == 1
		) {
		llog_write(L_DEBUG, "\n---------------create request URL-----------------------\n");
	}

	switch(rt_request_url_mask->use_drproxy) {
                case 1:
                        len = snprintf(strptr, space_left, "%s", g_drproxy_url);
			break;
                case 2:
			len = snprintf(strptr, space_left, "%s", g_local_primary_drproxy_url);
                        break;
                case 3:
			len = snprintf(strptr, space_left, "%s", g_local_secondary_drproxy_url);
                        break;
                default:
			len = snprintf(strptr, space_left, "%s", rt_request_url_mask->ad_nw_url);
        }



	if (len >= space_left) {
		llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
		return RTB_SUCCESS;
	}

	space_left -= len;
	strptr = strptr + len;

	//request_url_with_mandatory_params
	len = snprintf(strptr, space_left, "%s", request_url_with_mandatory_params);	
	if (len >= space_left) {
		llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
		return RTB_SUCCESS;
	}

	//keep track of start and end of each parameter to be replaced from source request
	rt_request_params->replace_info[RT_REQUEST_ID].start =	strptr + (rt_request_params->replace_info[RT_REQUEST_ID].start - request_url_with_mandatory_params);
	rt_request_params->replace_info[RT_REQUEST_ID].end = strptr + (rt_request_params->replace_info[RT_REQUEST_ID].end - request_url_with_mandatory_params);
	rt_request_params->replace_info[RT_AD_SIZE].start = strptr + (rt_request_params->replace_info[RT_AD_SIZE].start - request_url_with_mandatory_params);
	rt_request_params->replace_info[RT_AD_SIZE].end = strptr + (rt_request_params->replace_info[RT_AD_SIZE].end - request_url_with_mandatory_params);

	/*llog_write(L_DEBUG, "\nMUX_MANDATORY_REPLACE:\nmandat:%s\nrq_s:%s\nrq_e:%s\nad_s:%s\nad_e:%s\n",
			request_url_with_mandatory_params,
			rt_request_params->replace_info[RT_REQUEST_ID].start,
			rt_request_params->replace_info[RT_REQUEST_ID].end,
			rt_request_params->replace_info[RT_AD_SIZE].start,
			rt_request_params->replace_info[RT_AD_SIZE].end);*/

	space_left -= len;
	strptr = strptr + len;

	//currency of the bid/deal floor values
	len = snprintf(strptr, space_left, "&bidCurrency=%s", GET_CURRENCY_CODE_FROM_ID(adcampaigns->dsp_currency_id, 
				rt_request_params->fte_additional_params->currency_xrate_map,
				rt_request_params->fte_additional_params->currency_count));	
	if (len >= space_left) {
		llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
		return RTB_SUCCESS;
	}
	space_left -= len;
	strptr = strptr + len;

	// Get the x_forwarded_for header's value
	const char* xff_header = get_header_value(&(additional_parameter->header_map), "HTTP_X_FORWARDED_FOR");
	if (xff_header != NULL && xff_header[0] != '\0') {
		char encoded_xff_header[ENCODED_XFF_MAX_LEN+1];
		encoded_xff_header[0] = '\0';
		encoded_xff_header[ENCODED_XFF_MAX_LEN] = '\0';
		if(((additional_parameter->pub_country_level_privacy_flag ==1) || 
			(1 == ip_masking_enabled)) &&
			(additional_parameter->masked_xff[0]!='\0')){
		  html_url_encode(additional_parameter->masked_xff, encoded_xff_header,ENCODED_XFF_MAX_LEN);
		}
		else{
		  html_url_encode(xff_header, encoded_xff_header,ENCODED_XFF_MAX_LEN);
		}
		len = snprintf(strptr, space_left, "&xff=%s", encoded_xff_header);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}

	//We should pass User's IP if it has not been blocked by the Publisher.
	if (additional_parameter->pubsite_default_settings.is_ip_address_blocked != 1 && 
	    rt_request_params->ad_server_req_gen_params->remote_ip_addr[0] != '\0')
	{
	  if (1 == ip_masking_enabled){
	    len = snprintf(strptr, space_left, "&ip=%s", rt_request_params->ad_server_req_gen_params->masked_ip_addr);
	  }
	  else{
	    len = snprintf(strptr, space_left, "&ip=%s", rt_request_params->ad_server_req_gen_params->remote_ip_addr);
	  }

	  if (len >= space_left)
	    {
		  llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
		  return RTB_SUCCESS;
	    }
	  space_left -= len;
	  strptr = strptr + len;
	}

	if (get_mandatory_site_url(&strptr, &space_left, additional_parameter, rt_request_params, 
													(additional_parameter->pubsite_default_settings.force_pageurl_transparency != DEFAULT_PAGEURL &&
													 adcampaigns->force_pageurl_transparency != DEFAULT_PAGEURL)) != RTB_SUCCESS)
	{
					return RTB_SUCCESS;
	}

	if ( get_mandatory_pageurl(&strptr, &space_left, additional_parameter, rt_request_params,
													(additional_parameter->pubsite_default_settings.force_pageurl_transparency != DEFAULT_PAGEURL &&
													 adcampaigns->force_pageurl_transparency != DEFAULT_PAGEURL) ) != RTB_SUCCESS)
	{
					return RTB_SUCCESS;
	}

	/* If Publisher has given overridding Referrer URL then override Referrer URL which has been received as params with it.*/
	if ( get_mandatory_refurl(&strptr, &space_left, additional_parameter, rt_request_params,
													(additional_parameter->pubsite_default_settings.force_pageurl_transparency != DEFAULT_PAGEURL &&
													 adcampaigns->force_pageurl_transparency != DEFAULT_PAGEURL) ) != RTB_SUCCESS)
	{
					return RTB_SUCCESS;
	}

	if (rt_request_url_mask->adid == 1) {
		len = snprintf(strptr, space_left, "&adId=%ld", rt_request_params->in_server_req_params->ad_id);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}

	if (rt_request_url_mask->pubId == 1) {
		len = snprintf(strptr, space_left, "&pubId=%ld", rt_request_params->in_server_req_params->publisher_id);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}

	if (rt_request_url_mask->siteId == 1) {
		len = snprintf(strptr, space_left, "&siteId=%ld", rt_request_params->in_server_req_params->site_id);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}
	/*passing whether adtag is within iframe flag*/
	if (rt_request_url_mask->use_in_iframe == 1) {
		/*SERV_ADS_HTML_OPER : iframe based so pass iniframe as true ie.. 1*/
		if (rt_request_params->in_server_req_params->oper_id == SERV_ADS_HTML_OPER){
			len = snprintf(strptr, space_left, "&inIframe=%d", 1);
			if (len >= space_left) {
				llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
				return RTB_SUCCESS;
			}
			space_left -= len;
			strptr = strptr + len;
		}
		else {
			/*SERV_ADS_JSCRIPT_OPER : js based so check for iniframe parameter*/
			len = snprintf(strptr, space_left, "&inIframe=%d", rt_request_params->in_server_req_params->inIframe);
			if (len >= space_left) {
				llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
				return RTB_SUCCESS;
			}
			space_left -= len;
			strptr = strptr + len;
		}
	}

	/* Passing param to indicate whether adtag is served in multiple nested iframes or not. */
	if (rt_request_params->in_server_req_params->in_multiple_nested_Iframes != -1) {		
		len = snprintf(strptr, space_left, "&inMultipleNestedIframes=%d", rt_request_params->in_server_req_params->in_multiple_nested_Iframes);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}

	//passing of atf, btf params
	if (rt_request_url_mask->fold_position == 1) {
		//checking the sanity of the values fbefore passing. Params from db are sanity checked. so validate s_*
		if ((rt_request_params->in_server_req_params->s_fold_position_id >= MIN_FOLD_POS_VALUE) &&
				(rt_request_params->in_server_req_params->s_fold_position_id <= MAX_FOLD_POS_VALUE)) {
			len = snprintf(strptr, space_left, "&uFoldPos=%d&sFoldPos=%d", rt_request_params->fte_additional_params->u_fold_position_id, rt_request_params->in_server_req_params->s_fold_position_id);
			if (len >= space_left) {
				llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
				return RTB_SUCCESS;
			}
			space_left -= len;
			strptr = strptr + len;
		} else {
			llog_write(L_DEBUG, "\nFOLDPOS ERROR: s:%d u:%d", 
					rt_request_params->in_server_req_params->s_fold_position_id,	
					rt_request_params->fte_additional_params->u_fold_position_id);
		}
	}
	if (rt_request_url_mask->frequency == 1) {
		len = snprintf(strptr, space_left, "&freq=%d",
				get_frequency(out_response_params->campaign_id, rt_request_params->fte_additional_params));
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}

	if ((rt_request_url_mask->timezone == 1) && (rt_request_params->in_server_req_params->timezone[0] != '\0')) {
		len = snprintf(strptr, space_left, "&timezone=%s", rt_request_params->in_server_req_params->timezone);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}

	if ((rt_request_url_mask->catagory == 1) && (rt_request_params->request_url_params.catagory_list[0]!= '\0')) {
		len = snprintf(strptr, space_left, "&category=%s", rt_request_params->encoded_request_params.encoded_catagory);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}

	if ((rt_request_url_mask->screen_resolution == 1) && (rt_request_params->in_server_req_params->screen_resolution[0]!= '\0')) {
		len = snprintf(strptr, space_left, "&screenResolution=%s", rt_request_params->in_server_req_params->screen_resolution);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}
	if ((rt_request_url_mask->ad_position == 1) && (rt_request_params->in_server_req_params->ad_position[0]!= '\0')) {
		len = snprintf(strptr, space_left, "&adPosition=%s", rt_request_params->in_server_req_params->ad_position);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}
	if ((rt_request_url_mask->language == 1) && (rt_request_params->ad_server_req_gen_params->accept_lang[0] != '\0')) {
		len = snprintf(strptr, space_left, "&language=%s", rt_request_params->encoded_request_params.encoded_language);		
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}
	if ((rt_request_url_mask->browser == 1) && (rt_request_params->ad_server_req_gen_params->browser[0] != '\0')) {
		len = snprintf(strptr, space_left, "&browser=%s", rt_request_params->encoded_request_params.encoded_browser); 
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}
	if ((rt_request_url_mask->cookie == 1) && (rt_request_params->request_url_params.cookie[0] != '\0')) {
		if( rt_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE ) {

			len = snprintf(strptr, space_left, "&cookie=%s", rt_request_params->request_url_params.cookie);
			if (len >= space_left) {
				llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
				return RTB_SUCCESS;
			}
			space_left -= len;
			strptr = strptr + len;
			// store this cookie for logging purposes
			strncpy(campaign_cookie, rt_request_params->request_url_params.cookie, MAX_COOKIE_SIZE);
			campaign_cookie[MAX_COOKIE_SIZE] = '\0';
		}
	}
  if (rt_request_params->in_server_req_params->is_coppa_compliant == 1) {

    len = snprintf(strptr, space_left, "&coppa=%d", rt_request_params->in_server_req_params->is_coppa_compliant);
    if (len >= space_left) {
      llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
      return RTB_SUCCESS;
    }
    space_left -= len;
    strptr = strptr + len;

    len = snprintf(strptr, space_left, "&optout=%d", rt_request_params->in_server_req_params->is_coppa_compliant);
    optout_set = 1;
    if (len >= space_left) {
      llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
      return RTB_SUCCESS;
    }
    space_left -= len;
    strptr = strptr + len;
  }
	if (rt_request_url_mask->use_pmoptout == 1 && optout_set == 0) {

		/* 
		 * if (pmoo == HTTP_DNT) {
		 * 	log pmoo;
		 * } else if( pmoo == TRUE ) {
		 *	log pmoo;
		 * } else if ( HTTP_DNT == TRUE ) {
		 * 	log HTTP_DNT;}
		 */
		if( rt_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_TRUE ) {
			len = snprintf(strptr, space_left, "&optout=%d", rt_request_params->ad_server_req_gen_params->dnt_opt_out_req_value); 
			if (len >= space_left) {
                        	llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
                        	return RTB_SUCCESS;
                	}
    			space_left -= len;
                	strptr = strptr + len;
		} 
    		else if (rt_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_TRUE){
			len = snprintf(strptr, space_left, "&optout=%d", rt_request_params->ad_server_req_gen_params->pubmatic_opt_out);
			if (len >= space_left) {
                                llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
                                return RTB_SUCCESS;
                        }
                        space_left -= len;
                        strptr = strptr + len;	
    		}	
	}

	if (	additional_parameter->pubsite_default_settings.pass_pmp_enabled_flag_to_dsp == 1 &&
		rt_request_params->fte_additional_params->publisher_level_settings.pmp_enabled == 1 &&
		rt_request_url_mask->use_pmp_enabled == 1) {
		len = snprintf(strptr, space_left, "&pmpEnable=%d", rt_request_params->fte_additional_params->publisher_level_settings.pmp_enabled); 
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}

	if(rt_request_params->in_server_req_params->intl == 1){
		len = snprintf(strptr, space_left, "&instl=%d",	rt_request_params->in_server_req_params->intl);
		if (len >= space_left) {
        llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
        return RTB_SUCCESS;
      }
      space_left -= len;
      strptr = strptr + len;
	}

	if(rt_request_url_mask->send_hardfloor == 1) {
		if(adcampaigns->ad_campaign_list_setings->camp_rtb_floor > 0.0000 && adcampaigns->ad_campaign_list_setings->camp_rtb_floor <999) {
			len = snprintf(strptr, space_left, "&hardfloor=%f",
					CONVERT_USD_TO_NATIVE_CURRENCY(adcampaigns->ad_campaign_list_setings->camp_rtb_floor,
					adcampaigns->dsp_currency_id,
					rt_request_params->fte_additional_params->currency_xrate_map,
					rt_request_params->fte_additional_params->currency_count));
			if (len >= space_left) {
				llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
        return RTB_SUCCESS;
			}
			space_left -= len;
      strptr = strptr + len;
			if(adcampaigns->dsp_currency_id != USD_CURRENCY_ID) {
				len = snprintf(strptr, space_left, "&hardfloorcur=%s", GET_CURRENCY_CODE_FROM_ID(adcampaigns->dsp_currency_id,
							rt_request_params->fte_additional_params->currency_xrate_map,
							rt_request_params->fte_additional_params->currency_count));
				if(len >= space_left){
					llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
					return RTB_SUCCESS;
				}
				space_left -= len;
				strptr = strptr + len;
			}
		}
	}

    if (rt_request_url_mask->use_secure_params == 1 &&
        rt_request_params->fte_additional_params->is_https_request_flag == 1) {
        len = snprintf(strptr, space_left, "&secure=%d", rt_request_params->fte_additional_params->is_https_request_flag); 
		if (len >= space_left) {
			llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}

    if (rt_request_url_mask->use_price_floor){
	    if(adcampaigns->ad_campaign_list_setings->minimum_clearing_price > 0){


		    len = snprintf(strptr, space_left, "&mcp=%f", CONVERT_USD_TO_NATIVE_CURRENCY(adcampaigns->ad_campaign_list_setings->minimum_clearing_price,
									adcampaigns->dsp_currency_id,
									rt_request_params->fte_additional_params->currency_xrate_map,
									rt_request_params->fte_additional_params->currency_count));
		    if(len >= space_left){
			    llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			    return RTB_SUCCESS;
		    }
		    space_left -= len;
		    strptr = strptr + len;
/*
		    if(rt_request_params->fte_additional_params->minimum_clearing_price_type == FLOOR_TYPE_USER_BASED_FLOOR){

			    len = snprintf(strptr, space_left, "&mcptype=%d", FLOOR_TYPE_USER_BASED_FLOOR);
			    if(len >= space_left){
				    llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
				    return RTB_SUCCESS;
			    }
			    space_left -= len;
			    strptr = strptr + len;
		    }
*/
	    }
    }

    // TODO: Should the following be place inside
    // ``if (rt_request_url_mask->use_vertical_id == 1)``?
    iab_vertical_count = rt_request_params->fte_additional_params->iab_vertical_count; 
    iab_verticals = rt_request_params->fte_additional_params->iab_verticals;

    for(i=0,val=0;((i<iab_vertical_count) && (val<MAX_LENGTH_SITE_IAB_VERTICALS-10));i++){
      ret=snprintf(iab_verticals_for_dsp+val,avail_space,"%s,",iab_verticals[i].iab_vertical);
      avail_space-=ret;
      val+=ret;
    }

    if (val > 0) {
            iab_verticals_for_dsp[val-1]='\0';
            html_url_encode(iab_verticals_for_dsp,encoded_iab_verticals,MAX_LENGTH_ENCODED_SITE_IAB_VERTICALS);
    }

    if (rt_request_url_mask->use_vertical_id == 1) {
      len = snprintf(strptr, space_left, "&vertical=%ld", rt_request_params->fte_additional_params->vertical_id);
      if (len >= space_left) {
	llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
	return RTB_SUCCESS;
      }
      space_left -= len;
      strptr = strptr + len;

      if(encoded_iab_verticals[0] != '\0'){
	len = snprintf(strptr, space_left, "&iab_verticals=%s",encoded_iab_verticals);
	if (len >= space_left) {
	  llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
	  return RTB_SUCCESS;
	}
	space_left -= len;
	strptr = strptr + len;	
      }
    }

    if(rt_request_params->in_server_req_params->platform_id != MOBILE_APP_PLATFORM)
    {
		len = snprintf(strptr, space_left, "&platform=%d", rt_request_params->in_server_req_params->platform_id);
		if (len >= space_left) {
				llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
				return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
    }else if ( rt_request_params->in_server_req_params->site_ad != NULL )
    {		len = snprintf(strptr, space_left, "&platform=%d", rt_request_params->in_server_req_params->site_ad->platform_id);
			if (len >= space_left) {
				llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE DSP URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
				return RTB_SUCCESS;
		}
	space_left -= len;
	strptr = strptr + len;

    }

	if(
			additional_parameter->adserver_config_params != NULL
			&&
			additional_parameter->adserver_config_params->rtb_debug_flag == 1
		) {
		llog_write(L_DEBUG, "\nadId: %ld cId: %ld %s ts=[%s]\n------------ end request url -------------------\n", rt_request_params->in_server_req_params->ad_id, out_response_params->campaign_id, out_response_params->bid_response_params.request_url, get_current_timestamp(ts_buff) );
	}
	
#ifdef RTB_JSON_TESTING
	validate_request_url(out_response_params->bid_response_params.request_url);
#endif
	return(RTB_SUCCESS);
}



// This is the callback registered with curl_easy. This is called when get response from reatime ad campaign
int default_process_response (
            void *response_buffer, 
			size_t size, 
			size_t nmemb, 
			void* bid_response_params_ptr){

	int total_size = size*nmemb;
	int bytes_to_be_copied = 0;
  int realloc_count = 0;
  char *temp_buffer = NULL;

  /* this removel is handled in parse_response */
  /*for(i=0; i< total_size; i++){
    if(buffer[i] == '\r'){
      buffer[i] = '\n';
    }
  }
  */
	rt_bid_response_params_t* bid_response_params = (rt_bid_response_params_t*)bid_response_params_ptr;	
	if ( ! bid_response_params->stamp_after_api_call.tv_sec && ! bid_response_params->stamp_after_api_call.tv_usec ) 
		gettimeofday(&bid_response_params->stamp_after_api_call, NULL);
	if(bid_response_params->response_buffer == NULL){
    bid_response_params->response_buffer = (char *) malloc( MAX_RESPONSE_BUFFER_SIZE);
    bid_response_params->response_buffer_alloc_count = MAX_RESPONSE_BUFFER_SIZE;
	}
  realloc_count = bid_response_params->response_buffer_length;
  /*if available size in the buffer is more than the size of the recieved buffer then append the total buffer*/
  if((bid_response_params->response_buffer_alloc_count - bid_response_params->response_buffer_length -1) >=  total_size){
    bytes_to_be_copied = total_size;
  }
  else{
    realloc_count = bid_response_params->response_buffer_alloc_count;
    while(realloc_count - bid_response_params->response_buffer_length - 1 < total_size){
       realloc_count += RESPONSE_BUFFER_INCREMENT_COUNT * MAX_RESPONSE_BUFFER_SIZE;
    }
    temp_buffer = (char *) realloc (bid_response_params->response_buffer, realloc_count);
    if(temp_buffer){
      bid_response_params->response_buffer = temp_buffer;
      bid_response_params->response_buffer_alloc_count = realloc_count;
      bytes_to_be_copied = total_size;
    }
    else{
      bytes_to_be_copied = bid_response_params->response_buffer_alloc_count - bid_response_params->response_buffer_length -1; 
    }
	}
	
  if(bytes_to_be_copied != 0){
		/*copy the recievied buffer upto the limit calculated above*/
    memcpy(&bid_response_params->response_buffer[bid_response_params->response_buffer_length],
				response_buffer,
				bytes_to_be_copied);


		bid_response_params->response_buffer_length = bid_response_params->response_buffer_length + bytes_to_be_copied;
		bid_response_params->req_processed = 1;
		bid_response_params->response_buffer[bid_response_params->response_buffer_length] = '\0';
	}


	/*returning byte read sucessfully*/
	return(size*nmemb);	
}

/* this function removes '\r' from bid_response */
static void remove_extra_chars_from_resp_value(char * value)
{
  int i = 0 ;
  if (value != NULL) {
    while (value[i]!= '\0') {
      if (value[i] == '\r') {
        value[i] = '\0';
      }
      i++;
    }
  }
}
bool check_if_json(const char *buffer)
{
  int i = 0;
  for(;i < MAX_CHARACTER_TO_CHECK && buffer[i] != '\0';i++)
  {
    if(buffer[i] == '{')
    {
      return true;
    }
  }
  return false;
}


/*
*	json_string : {"pckv":{"i":["16610"],"s":[]}}
*	parse json to extract value in "i" parameter.
*	This parameter represents pubmatic_campaign_id from pubconnect campaigns running through DSP.  
*/

static void parse_pc_target_key(char *json_string, int *dsp_selected_pc_campaign_id){
  
  json_object * jobj = NULL;
  json_object *child_json_object = NULL;
  json_object *grand_child_json_object = NULL;
  json_object *attr_obj = NULL;
  int attr_arr_len,campaign_id= 0;
  
  *dsp_selected_pc_campaign_id = 0;
  
  jobj = json_tokener_parse(json_string);
  if (jobj == NULL || is_error(jobj)){
    llog_write(L_DEBUG, "ERROR: PC : Invalid json response. Failed to parse json\n");
    return;
  }

  //get "pckv" object from json
  //{"pckv":{"i":[cmpg_id],"s":[]}}
  child_json_object = get_json_child_from_parent(jobj,PUBCONNECT_TARGET_KEY,json_type_object);
  if (child_json_object == NULL){
    llog_write(L_DEBUG, "ERROR: PC: Invalid json response. Failed to create child object\n");
    goto cleanup;
  }

  //get "i" object from json
  grand_child_json_object = get_json_child_from_parent(child_json_object, PC_TARGET_KEY , json_type_array);
  if (grand_child_json_object == NULL){
    llog_write(L_DEBUG, "ERROR: PC: Invalid json response. Failed to create nested child object\n");
    goto cleanup;
  }

  attr_arr_len = json_object_array_length(grand_child_json_object);
  if (attr_arr_len < 1 ) {
    llog_write(L_DEBUG, "ERROR4: PC: Invalid json response. Number of elements in array is less than 1\n");
    goto cleanup;
  } else {
    //Read the first value in array
    attr_obj = json_object_array_get_idx(grand_child_json_object, 0);
    campaign_id = json_object_get_int(attr_obj);
  }
  
  *dsp_selected_pc_campaign_id = campaign_id;
 cleanup:
  //free json object
  if ((jobj != NULL) && (!is_error(jobj))){
    json_object_put(jobj);
    jobj = NULL;
  }
}

/********
Any new parameter added to RTB-BID Response should be added prior to CREATIVE_TAG.
The parsing has assumtion that only CREATIVE_TAG can be on more than one line.
********/
void parse_response(rt_response_params_t* response_params,
                    ad_server_additional_params_t *additional_parameter,
                    long campaign_id, long oper_id, fte_additional_params_t *fte_additional_params,
		    rt_request_params_t *rt_request_params)
{
	char *buffer = NULL;
	char *token=NULL;
	char *name=NULL;
	char *value=NULL;
	char *delimit="\n";
	char **last=NULL;
	int len = 0;

	int token_len = 0;
	int current_ctag_len = 0;
	char *current_ctag_pos = NULL;
	char ctag_found = 0;
	char url_found = 0;
	int new_line_len = strlen("\n");

	double temp = 0.0;
	int t_seat = 0;// i have taken int even though RTB spec provides size to be 8 bytes[which really really sucks]
	int rich_media_ad_creative_attribute_id = -1;
	char tmp_landing_page_tld[MAX_DOMAIN_NAME_LENGTH + 1] = {'\0'};
	rt_bid_response_params_t *bid_response_params =  &response_params->bid_response_params;


	if (additional_parameter->adserver_config_params == NULL){
		//llog_write(L_DEBUG, "adserver config passed is null to func : %s\n", __FUNCTION__);
		return;
	}
        buffer = (char *)bid_response_params->response_buffer;
	if(additional_parameter->adserver_config_params->rtb_debug_flag == 1){
		//llog_write(L_DEBUG, "API RESPONSE: %s", buffer);
		LOG_INFO(API_RESP,MOD_DEFAULT,buffer);
	}
        bid_response_params->bid_id = 0;
        bid_response_params->creative_type = -1;
 	//Initialized Rich Media Ad creative attribute.
	bid_response_params->rich_media_ad_creative_attribute_id = -1;
	bid_response_params->pub_deal_id[0] = '\0';
	response_params->currency_id = USD_CURRENCY_ID; // initialize currency id to dollar
	bid_response_params->dsp_selected_pc_campaign_id = 0;
	last=&buffer;

	//llog_write(L_DEBUG, "\nAfter parsing the response: cId: %ld", campaign_id);

	do{
		token = strtok_r(buffer,delimit,last);
		if(token == NULL){
			break;
		}
		name = token;
		value = strchr(token,'=');

		if(value != NULL){
			*value='\0';
			value++;
		}

		if((strncmp(name,ID, sizeof(ID))==0) && (value != NULL)){
      remove_extra_chars_from_resp_value(value);
                  strncpy(bid_response_params->transaction_id, value, MAX_TRANSACTION_ID_SIZE);	
                  bid_response_params->transaction_id[MAX_TRANSACTION_ID_SIZE] = '\0';
                  ctag_found = 0;
		}
		else if((strncmp(name,REQUEST_ID, sizeof(REQUEST_ID))==0) && (value != NULL)){
      remove_extra_chars_from_resp_value(value);
			strncpy(bid_response_params->request_id, value, (MAX_UNIQUE_ID_LEN - 1));
			bid_response_params->request_id[(MAX_UNIQUE_ID_LEN-1)] = '\0';
			ctag_found = 0;
		}
		else if((strncmp(name, BID_CURRENCY, sizeof(BID_CURRENCY))==0) && (value != NULL)){
			remove_extra_chars_from_resp_value(value);
			response_params->currency_id = get_currency_id_from_hash(fte_additional_params->currency_xrate_map, value); 
			ctag_found = 0;
                }
		else if((strncmp(name,BID, sizeof(BID))==0) && (value != NULL)){
      remove_extra_chars_from_resp_value(value);
			temp = (double)atof(value);
			errno = 0;
			bid_response_params->ecpm = temp;
			ctag_found = 0;
		}
    else if((strncmp(name, EBID, sizeof(EBID))==0) && (value != NULL)){
      remove_extra_chars_from_resp_value(value);
      memcpy(bid_response_params->ebid, value, WEB_SAFE_B64_ENCRYPTED_TEXT_SIZE);
      bid_response_params->ebid[WEB_SAFE_B64_ENCRYPTED_TEXT_SIZE] = '\0';
      ctag_found = 0;
    }
		else if((strncmp(name,CREATIVE_JS, sizeof(CREATIVE_JS))==0) && (value != NULL)){
      remove_extra_chars_from_resp_value(value);
			strncpy(bid_response_params->u_url.js_url, value, MAX_RESPONSE_URL_SIZE);	
			bid_response_params->u_url.js_url[MAX_RESPONSE_URL_SIZE] = '\0';
			if(bid_response_params->u_url.js_url[0] != '\0') {
				bid_response_params->type = JS_URL_TYPE;
			}
			ctag_found = 0;
		}
		else if((strncmp(name, CREATIVE_HTML, sizeof(CREATIVE_HTML))==0) && (value != NULL)){
      remove_extra_chars_from_resp_value(value);
			strncpy(bid_response_params->u_url.html_url, value, MAX_RESPONSE_URL_SIZE);
			bid_response_params->u_url.html_url[MAX_RESPONSE_URL_SIZE] = '\0';
			if(bid_response_params->u_url.html_url[0] != '\0') {
				bid_response_params->type = HTML_URL_TYPE;
			}
			ctag_found = 0;
		}
		else if((strncmp(name,PIGGYBACK_COOKIE, sizeof(PIGGYBACK_COOKIE))==0) && (value != NULL)){
      remove_extra_chars_from_resp_value(value);
			strncpy(bid_response_params->cookie, value, MAX_COOKIE_SIZE);
			bid_response_params->cookie[MAX_COOKIE_SIZE] = '\0';
			ctag_found = 0;
		}
		else if ( (strncmp(name, LANDING_PAGE_URL, sizeof(LANDING_PAGE_URL))== 0 ) && (value != NULL)){
      remove_extra_chars_from_resp_value(value);
			strncpy(bid_response_params->landing_page_url, value, MAX_RESPONSE_URL_SIZE);
			bid_response_params->landing_page_url[MAX_RESPONSE_URL_SIZE] = '\0';
			bid_response_params->landing_page_flag|=1;
			ctag_found = 0;
		}
		else if ( (strncmp(name, LANDING_PAGE_TLD, sizeof(LANDING_PAGE_TLD))== 0 ) && (value != NULL)){
      remove_extra_chars_from_resp_value(value);
			strncpy(bid_response_params->landing_page_tld, value, MAX_DOMAIN_NAME_LENGTH);
			bid_response_params->landing_page_tld[MAX_DOMAIN_NAME_LENGTH] = '\0';
			bid_response_params->landing_page_flag|=2;
			ctag_found = 0;
		}
		else if ( ((strncmp(name, CREATIVEID1, sizeof(CREATIVEID1))== 0 ) || (strncmp(name, CREATIVEID, sizeof(CREATIVEID))== 0 )) && (value != NULL)) {
      remove_extra_chars_from_resp_value(value);
			strncpy(bid_response_params->creative_id, value, MAX_CREATIVE_ID_SIZE);
			bid_response_params->creative_id[MAX_CREATIVE_ID_SIZE] = '\0';
			ctag_found = 0;

		} else if (strncmp(name, CREATIVE_TYPE, sizeof(CREATIVE_TYPE)) == 0 &&
                                value != NULL) {
                        /* NOTE: 'value' contains the int followed by the
                         * remaining RTB response.
                         */
                        remove_extra_chars_from_resp_value(value);
                        char * end = "";
                        errno = 0;
                        int t = strtol(value, &end, 10);

                        int is_crtype_invalid =
                                errno != 0 ||
                                end == value ||  // crtype is NaN
                                MAX_CREATIVE_TYPE_VALUE < t ||
                                t < MIN_CREATIVE_TYPE_VALUE;
                        if (is_crtype_invalid) {
                                llog_write(L_DEBUG, "ERROR creative type '%s' "
                                        "is not a proper number for campaign %ld.  "
                                        "Creative type will be set to -1. %s:%d\n",
                                        value, campaign_id, __FILE__, __LINE__);
                                bid_response_params->creative_type = -1;
                                errno = 0;
                        } else {
                                bid_response_params->creative_type = t;
                        }

                        ctag_found = 0;

                }
		else if ((strncmp(name, SEAT, sizeof(SEAT))== 0) && (value != NULL)) {
      remove_extra_chars_from_resp_value(value);
			errno = 0;
			t_seat = strtol(value, NULL, 10);
			if(errno != 0) {
				llog_write(L_DEBUG, "\nERROR the SEAT %s is not a proper number for campaign %ld , seat id will be set to 0 %s:%d\n", value, campaign_id, __FILE__, __LINE__);
				errno = 0;
			} else {
				bid_response_params->dsp_buyer_id = t_seat;
			}
			ctag_found = 0;
		}
		else if ((strncmp(name, RICH_MEDIA_AD_CREATIVE_ATTRIBUTE, sizeof(RICH_MEDIA_AD_CREATIVE_ATTRIBUTE))== 0) && (value != NULL)) {
      remove_extra_chars_from_resp_value(value);
			errno = 0;
			rich_media_ad_creative_attribute_id = strtol(value, NULL, 10);
			if(errno != 0) {
				llog_write(L_DEBUG, "\nERROR the RICH_MEDIA_AD_CREATIVE_ATTRIBUTE %s is not a proper number %s:%d\n",
					value, __FILE__, __LINE__);
				errno = 0;
				bid_response_params->rich_media_ad_creative_attribute_id = -1;
			} else {
				bid_response_params->rich_media_ad_creative_attribute_id = rich_media_ad_creative_attribute_id;
			}
			ctag_found = 0;
		}
		else if ((strncmp(name, DEAL_ID, sizeof(DEAL_ID)) == 0) && (value != NULL)) {
      remove_extra_chars_from_resp_value(value);
			strncpy(bid_response_params->pub_deal_id, value, MAX_DEAL_ID_LEN);
			bid_response_params->pub_deal_id[MAX_DEAL_ID_LEN] = '\0';
			ctag_found = 0;
		}
		else if ((strncmp(name, DEAL_NO_BID_REASON, sizeof(DEAL_NO_BID_REASON)) == 0) && (value != NULL)) {
      			remove_extra_chars_from_resp_value(value);
			response_params->deal_no_bid_reason = atoi(value);
			ctag_found = 0;
		}
		else if ((strncmp(name, IURL, sizeof(IURL)) == 0) && (value != NULL)) {
      			remove_extra_chars_from_resp_value(value);
			nstrcpy(bid_response_params->iurl, value, MAX_IURL_SIZE);
			bid_response_params->iurl[MAX_IURL_SIZE] = '\0';
			ctag_found = 0;
		}
		else if ((strncmp(name, DSP_CAMP_ID, sizeof(DSP_CAMP_ID)) == 0) && (value != NULL)) {
			remove_extra_chars_from_resp_value(value);
			nstrcpy(bid_response_params->dsp_campaign_id, value, MAX_DSP_CAMPAIGN_ID_LEN);
			bid_response_params->dsp_campaign_id[MAX_DSP_CAMPAIGN_ID_LEN] = '\0';
			ctag_found = 0;
		}
		else if ((strncmp(name, RICH_MEDIA_TECH_ID, sizeof(RICH_MEDIA_TECH_ID))== 0) && (value != NULL)) {
			remove_extra_chars_from_resp_value(value);
			nstrcpy(bid_response_params->rich_media_tech_name, value, MAX_RICH_MEDIA_TECH_ID_LEN);
			bid_response_params->rich_media_tech_name[MAX_RICH_MEDIA_TECH_ID_LEN] = '\0';
			ctag_found = 0;
		}
		//VIDEO PARAMETERS
		else if((strncmp(name, VIDEO_CREATIVE_URL, sizeof(VIDEO_CREATIVE_URL))==0) && (value != NULL)) {
				remove_extra_chars_from_resp_value(value);
				nstrcpy(bid_response_params->u_url.video_creative_tag, value, MAX_VIDEO_CREATIVE_TAG_LEN);
				bid_response_params->u_url.video_creative_tag[MAX_VIDEO_CREATIVE_TAG_LEN] = '\0';
				bid_response_params->type = VIDEO_CREATIVE_TAG_TYPE;
				ctag_found = 0;
				url_found  = 1;
		}
		else if (((strncmp(name, PUBCONNECT_TARGET_KEY, sizeof(PUBCONNECT_TARGET_KEY))) == 0) && (value != NULL)) {
		  parse_pc_target_key (value, &(bid_response_params->dsp_selected_pc_campaign_id));
		  ctag_found = 0;
		}

/* NATIVE resp params parsing */
/* OLD Native Protocol Implementation
    else if (((strncmp(name, NATIVE_RESP_TITLE, sizeof(NATIVE_RESP_TITLE))) == 0) && (value != NULL)) {
        remove_extra_chars_from_resp_value(value);
	nstrcpy(bid_response_params->native_resp_params.title, value, MAX_NTV_TITLE_LEN);
	bid_response_params->native_resp_params.title[MAX_NTV_TITLE_LEN] = '\0';
	ctag_found = 0;
    }

    else if (((strncmp(name, NATIVE_RESP_TEXT, sizeof(NATIVE_RESP_TEXT))) == 0) && (value != NULL)) {
        remove_extra_chars_from_resp_value(value);
	nstrcpy(bid_response_params->native_resp_params.text, value, MAX_NTV_TEXT_LEN);
	bid_response_params->native_resp_params.text[MAX_NTV_TEXT_LEN] = '\0';
	ctag_found = 0;
    }

    else if (((strncmp(name, NATIVE_RESP_ICON_IMG, sizeof(NATIVE_RESP_ICON_IMG))) == 0) && (value != NULL)) {
        remove_extra_chars_from_resp_value(value);
	nstrcpy(bid_response_params->native_resp_params.iconImg, value, MAX_NTV_ICON_IMAGE_LEN);
	bid_response_params->native_resp_params.iconImg[MAX_NTV_ICON_IMAGE_LEN] = '\0';
	ctag_found = 0;
    }

    else if (((strncmp(name, NATIVE_RESP_MAIN_IMG, sizeof(NATIVE_RESP_MAIN_IMG))) == 0) && (value != NULL)) {
        remove_extra_chars_from_resp_value(value);
	nstrcpy(bid_response_params->native_resp_params.mainImg, value, MAX_NTV_MAIN_IMAGE_LEN);
	bid_response_params->native_resp_params.mainImg[MAX_NTV_MAIN_IMAGE_LEN] = '\0';
	ctag_found = 0;
    }

    else if (((strncmp(name, NATIVE_RESP_CTATEXT, sizeof(NATIVE_RESP_CTATEXT))) == 0) && (value != NULL)) {
        remove_extra_chars_from_resp_value(value);
	nstrcpy(bid_response_params->native_resp_params.ctatext, value, MAX_NTV_CTATEXT_LEN);
	bid_response_params->native_resp_params.ctatext[MAX_NTV_CTATEXT_LEN] = '\0';
	ctag_found = 0;
    }

    else if (((strncmp(name, NATIVE_RESP_RATING, sizeof(NATIVE_RESP_RATING))) == 0) && (value != NULL)) {
        remove_extra_chars_from_resp_value(value);
        bid_response_params->native_resp_params.rating = (double)atof(value);
        errno = 0;
	ctag_found = 0;
    }

    else if (((strncmp(name, NATIVE_RESP_CLICK, sizeof(NATIVE_RESP_CLICK))) == 0) && (value != NULL)) {
        remove_extra_chars_from_resp_value(value);
	nstrcpy(bid_response_params->native_resp_params.clickUrl, value, MAX_NTV_CLICK_LEN);
	bid_response_params->native_resp_params.clickUrl[MAX_NTV_CLICK_LEN] = '\0';
	ctag_found = 0;
    }

    else if (((strncmp(name, NATIVE_RESP_IMP_TRACKER, sizeof(NATIVE_RESP_IMP_TRACKER))) == 0) && (value != NULL)) {
        remove_extra_chars_from_resp_value(value);
	nstrcpy(bid_response_params->native_resp_params.impTracker, value, MAX_NTV_IMP_TRACK_LEN);
	bid_response_params->native_resp_params.impTracker[MAX_NTV_IMP_TRACK_LEN] = '\0';
	ctag_found = 0;
    }

    else if (((strncmp(name, NATIVE_RESP_CLICK_TRACKER, sizeof(NATIVE_RESP_CLICK_TRACKER))) == 0) && (value != NULL)) {
        remove_extra_chars_from_resp_value(value);
	nstrcpy(bid_response_params->native_resp_params.clickTracker, value, MAX_NTV_CLICK_TRACK_LEN);
	bid_response_params->native_resp_params.clickTracker[MAX_NTV_CLICK_TRACK_LEN] = '\0';
	ctag_found = 0;
    }
*/

    else if((strncmp(name, CREATIVE_TAG, sizeof(CREATIVE_TAG)) == 0) && (value != NULL) && url_found == 0) {
			token_len = strlen(value);
			if (token_len < MAX_CREATIVE_TAG_SIZE && value[0]!='\0') {
				if(oper_id == SERV_ADS_VIDEO_OPER){
					current_ctag_pos = bid_response_params->u_url.video_creative_tag;
					bid_response_params->type = VIDEO_CREATIVE_TAG_TYPE;
				}else{
					current_ctag_pos = bid_response_params->u_url.creative_tag;
					bid_response_params->type = CREATIVE_TAG_TYPE;
				}
				memcpy(current_ctag_pos , value, token_len);
				current_ctag_pos[token_len] = '\0';
					current_ctag_len += token_len;
					current_ctag_pos +=token_len;
					ctag_found = 1;
			}
    }
	/* PLZ DONT ADD ANY KEY BELOW THIS */
		else if (ctag_found == 1) {
			if (value != NULL) {	
				*(value - 1) = '=';
			}
			token_len = strlen(token);
			current_ctag_len += new_line_len + token_len;
			if(current_ctag_len < MAX_CREATIVE_TAG_SIZE) {
				strcpy(current_ctag_pos, "\n");
				current_ctag_pos += new_line_len;

				strcpy(current_ctag_pos, token);
				current_ctag_pos += token_len;
				*current_ctag_pos = '\0';
			}
		}

	}while(token!= NULL);

	/* TODO: NATIVE CREATIVE AS JSON: add code here */
/* OLD Native Protocol Implementation
	if (rt_request_params->in_server_req_params->ad_type == AD_TYPE_NATIVE) {
#ifdef NATIVE_DEBUG
                llog_write(L_DEBUG,"\nMB_NATIVE Calling form_native_creative_json %s:%d\n",__FILE__,__LINE__);
#endif

		form_native_creative_json(&(response_params->bid_response_params));
	}
*/

	if(additional_parameter->adserver_config_params->rtb_debug_flag >= 1 
	   && oper_id == SERV_ADS_VIDEO_OPER ) {
		logVidMessage("VIDEO_INFO|BidRESP: CId:%ld BidId:%s ReqId:%s BID:%f\n",
			campaign_id,
			bid_response_params->transaction_id,
			bid_response_params->request_id,
			bid_response_params->ecpm);
	}

	if(additional_parameter->adserver_config_params->rtb_debug_flag == 1){
		ad_server_req_param_t *in_server_req_params = rt_request_params->in_server_req_params;
		fprintf(
                        stderr, 
                        "\nRESPONSE: cid : %ld, P:%ld,S:%ld,A:%ld,O:%ld, "
                        "%s %s : "  // Transaction ID
                        "%s %s : "  // Request ID
                        "%s %f : "  // eCPM
                        "%s %s : "  // ebid
                        "%s %s : "  // Piggyback Cookie
                        "%s %s : "  // Landing Page URL
                        "%s %s : "  // Landing Page TLD
                        "%s %s : "  // Creative ID
                        "%s %d : "  // Creative Type
                        "%s %d : "  // Seat ID
                        "%s %d : "  // Creative Attribute
                        "%s %s : "  // PMP Deal ID
                        "%s %d : "  // Currency ID
                        "%s %s : "  // iUrl
                        "%s %s : "  // Campaign ID
                        "%s %d : "  // dnbr
                        "%s %s : "  // Rich Media Tech. Name
                        ,
                        campaign_id,
                        in_server_req_params->publisher_id,
                        in_server_req_params->site_id, 
                        in_server_req_params->ad_id,
                        in_server_req_params->oper_id,
                        ID, bid_response_params->transaction_id,
                        REQUEST_ID, bid_response_params->request_id,
                        BID, bid_response_params->ecpm,
                        EBID, bid_response_params->ebid,
                        PIGGYBACK_COOKIE, bid_response_params->cookie,
                        LANDING_PAGE_URL, bid_response_params->landing_page_url,
                        LANDING_PAGE_TLD, bid_response_params->landing_page_tld,
                        CREATIVEID, bid_response_params->creative_id,
                        CREATIVE_TYPE, bid_response_params->creative_type,
                        SEAT, bid_response_params->dsp_buyer_id,
                        RICH_MEDIA_AD_CREATIVE_ATTRIBUTE, bid_response_params->rich_media_ad_creative_attribute_id,
                        DEAL_ID, bid_response_params->pub_deal_id,
                        BID_CURRENCY, response_params->currency_id,
                        IURL, bid_response_params->iurl,
                        DSP_CAMP_ID, bid_response_params->dsp_campaign_id,
                        DEAL_NO_BID_REASON, response_params->deal_no_bid_reason,
                        RICH_MEDIA_TECH_ID, bid_response_params->rich_media_tech_name
                );
		if (bid_response_params->type == JS_URL_TYPE) {
			llog_write(L_DEBUG, " %s : %s", CREATIVE_JS, bid_response_params->u_url.js_url);
		}
		else if (bid_response_params->type == HTML_URL_TYPE) {
			llog_write(L_DEBUG, " %s : %s", CREATIVE_HTML, bid_response_params->u_url.html_url);
		}
		else if (bid_response_params->type == CREATIVE_TAG_TYPE) {
			llog_write(L_DEBUG, " %s : %s", CREATIVE_TAG, bid_response_params->u_url.creative_tag);
		}
		if (bid_response_params->dsp_selected_pc_campaign_id) {
			llog_write(L_DEBUG, " %s : %d ", DSP_SELECTED_CMPG_ID, bid_response_params->dsp_selected_pc_campaign_id);
		}
	}

	//check for verifying mandatory params. If either of these are invalid, we invalidate the request  
	if ( 
			bid_response_params->transaction_id[0] == '\0'
			||
			bid_response_params->request_id[0] == '\0'
           		|| 
			IS_INVALID_CURRENCY_ID(response_params->currency_id, fte_additional_params->currency_count)		
			||
			(
			 bid_response_params->ecpm > 0.0
			 &&
			 bid_response_params->u_url.html_url[0] == '\0'
			)
		 ) {
/* Disabled logging
		llog_write(L_DEBUG,"\n Realtime response incomplete. Invalidating the entry");
*/
		bid_response_params->ecpm = 0.0;	
		return;
	}
	else {
		bid_response_params->ecpm = CONVERT_NATIVE_CURRENCY_TO_USD(bid_response_params->ecpm, response_params->currency_id,fte_additional_params->currency_xrate_map,  fte_additional_params->currency_count);
	}
	bid_response_params->response_complete = 1;
	if (bid_response_params->landing_page_flag == 1 || bid_response_params->landing_page_flag == 3) {
		// extract the tld and store in landing_page_tld
		len = strlen(bid_response_params->landing_page_url);
		// this can be commented if we are sure that DSP will never send the url or tld in upper case
		lowercase_string(bid_response_params->landing_page_url, 0, len - 1);
		get_domain_name_from_url(bid_response_params->landing_page_url, bid_response_params->landing_page_tld, MAX_DOMAIN_NAME_LENGTH + 1);
	} else if (bid_response_params->landing_page_flag == 2) {
		// We have only got tld
		len = strlen(bid_response_params->landing_page_tld);
		lowercase_string(bid_response_params->landing_page_tld, 0, len - 1);
		// remove the http:// OR https:// which might be present in the TLD and also remove '?' or '/' and remaining characters after that from TLD
        get_domain_name_from_url(bid_response_params->landing_page_tld, tmp_landing_page_tld, MAX_DOMAIN_NAME_LENGTH + 1);
        strncpy (bid_response_params->landing_page_tld, tmp_landing_page_tld,  MAX_DOMAIN_NAME_LENGTH);
        bid_response_params->landing_page_tld[MAX_DOMAIN_NAME_LENGTH] = '\0';
	}
}
