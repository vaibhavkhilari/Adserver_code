/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stddef.h>
#include <string>
#include <iostream>
#include "error.h"
#include "db_error.h"
#include "db_constants.h"
#include "floor_rules_types.h"
extern "C" {
#include "audience_targeting_util.h"
#include "time_parting.h"
#include "day_parting.h"
#include "bloom_filter.h"
#include "floor_rule_bloom.h"
}
#include "common_constants.h"
#include "advertiser_domain_buyer_rule_entities.h"
#include "get_user_segments.h"
#include "cache_publisher_site_floor_rules.h"
#include "cache_advertiser_domain_category_mapping.h"
#include "deal_util.h"
#include "publisher_site_floor_rules.pb.h"
#include "floor_rule_engine.h"
#include "fte_types.h"

using namespace floor_rules;
using namespace std;

#define DEFAULT_GEO_CODE "PUB_GC"
#define DEFAULT_GEO_CODE_LEN 6


#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
extern "C" void _dump_floor_rule(publisher_site_floor_rule *floor_rule, const char *fn, int ln);
#endif

extern "C" int char_counter(const char* str, char c);

static int evaluate_floor_rules(const rt_response_params_t * rt_response_params,
				publisher_site_ad_campaign_list_t *adcampaign,
				publisher_site_floor_rule *floor_rule,
				ad_server_req_param_t *in_req_params,
				publisher_site_ad_t *in_ad,
				int *applicable_deal_id_flag,
				fte_additional_params_t *fte_additional_parameters,
				unsigned int *applicable_rule_flag,
				floor_rule_evalaluation_result_holders_t *result_holders,
				MULTI_BLOOM floor_bloom[]);

#if 0
int floor_rule_substring_bloom_search(
                const char* processing_string,
                const int rule_id,
                const BLOOM* bloom
                )
{
        int subdomain_levels = 0;
        int domain_found = 0;
        int i;
        char subdomain_delimiter = '.';
	char floor_bloom_string[MAX_RULE_ID_LENGTH + MAX_DOMAIN_NAME_LENGTH];
	floor_bloom_string[0] = '\0';

	if(bloom == NULL || processing_string == NULL){
		return domain_found;
	}

        subdomain_levels = char_counter(processing_string, subdomain_delimiter);
        // for a.b.c.com, we want to search for a.b.c.com, b.c.com and c.com

        for (i=1; i<=subdomain_levels; i++) {
		sprintf(floor_bloom_string,"%d_%s", rule_id, processing_string);

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		fprintf(stderr,"\nsearching %s\n", floor_bloom_string);
#endif
                if(bloom_check(bloom, floor_bloom_string)) {
                        //We found the domain in list
                        domain_found = 1;
                        break;
                }
                // Above ensures that strchr will never return NULL
                processing_string = strchr(processing_string, subdomain_delimiter);
                processing_string++;
        }
        return domain_found;
}
#endif

static double get_price_goal_floor_value(double bid_value,
        site_impressions_ecpm_total_t *impr_ecpm_tot,
        int *floor_application_flag,
        double floor_ecpm_usd,
        double min_floor_ecpm_usd);

/*
 * This function evaluate if rule is applicable for each RTB bid. If rule is applicable it applies floor to RTB bid.
 */

extern "C" int apply_floor_rules_filter(
		publisher_site_ad_campaign_list_t *adcampaigns,
		int nelements,
		const rt_response_params_t *rt_response_params,
		void *protobuff_floor_rules_ctxt,
		ad_server_req_param_t *in_req_params,
		fte_additional_params_t *fte_additional_parameters,
		publisher_site_ad_t *in_ad,
		site_impressions_ecpm_total_t *impr_ecpm_tot,
		MULTI_BLOOM floor_bloom[],
		const ad_server_additional_params_t *additional_parameters
		) {

	publisher_site_floor_rules *floor_rules = NULL;
	publisher_site_floor_rule *floor_rule = NULL;
	unsigned int applicable_rule_flag = 0;
	publisher_site_ad_campaign_list_t *tmp_adcampaign = NULL;
	int rule_index = 0;
	int campaign_index =0;
	const rt_response_params_t *tmp_rt_response_params = NULL;
	int rt_response_index = -1;
	int applicable_deal_id_flag = 0;
	floor_rule_evalaluation_result_holders_t result_holders;
	double floor_tobe_set = 0.0, bid_value = 0.0, soft_floor_to_be_set = 0.0;

	if (protobuff_floor_rules_ctxt == NULL) {
		//its dummy rule, so no evaluation needed
		return ADS_ERROR_SUCCESS;
	}

	floor_rules = (publisher_site_floor_rules *) protobuff_floor_rules_ctxt;

	/*
	 * If rule type and the campaign type matches then only we will try to evaluate and apply the rule.
	 * This is because if publisher wants to set rules for both RTB and AdFlex campaigns then he has to
	 * explicitly define two rules, one for RTB and one for AdFlex.
	 */
	for (rule_index = 0; rule_index < floor_rules->floor_rules_size(); rule_index++) {
		floor_rule = floor_rules->mutable_floor_rules(rule_index); 
		if (floor_rule->rule_type() == RULE_INVALID) {
			continue;
		}

		//Init floor rules result holders.
		result_holders.user_segment_evaluation_result = USER_SEGMENT_NOT_EVALUATED;
		result_holders.geo_evaluation_result = GEO_NOT_EVALUATED;
		result_holders.time_parting_evaluation_result = TIME_PARTING_NOT_EVALUATED;
		result_holders.day_parting_evaluation_result= DAY_PARTING_NOT_EVALUATED;
		result_holders.fold_position_evaluation_result = FOLD_POSITION_NOT_EVALUATED;
		result_holders.site_section_evaluation_result = SITE_SECTION_NOT_EVALUATED;


		for (campaign_index = 0; campaign_index < nelements; campaign_index++) {
			tmp_adcampaign = &(adcampaigns[campaign_index]);

			///eithercampaign is filtered or some 
			//some rule is already applied on it (i.e when floor_rule_id != RULE_DEFAULT) ..continue\

			int currency_id = floor_rule->currency_id() ;
			double floor_ecpm_usd = CONVERT_NATIVE_CURRENCY_TO_USD( floor_rule->floor_ecpm(), currency_id,
												fte_additional_parameters->currency_xrate_map,  fte_additional_parameters->currency_count ) ;

			if ( (tmp_adcampaign->ad_campaign_list_setings->filtered_flag == 1)  ||
											( (tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id != RULE_DEFAULT) &&
												( (tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority < floor_rule->priority()) || 
													(tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm >= floor_ecpm_usd )) ) ) {
							continue;
			}

			if ((tmp_adcampaign->realtime_flag == 1 && floor_rule->rule_type() == RULE_STANDARD_ADFLEX) ||
				(tmp_adcampaign->realtime_flag != 1 &&
				(floor_rule->rule_type() == RULE_RTB ))) {
				continue;
			}
			if (result_holders.user_segment_evaluation_result == USER_SEGMENT_EVALUATION_FAIL ||
				result_holders.geo_evaluation_result == GEO_EVALUATION_FAIL ||
				result_holders.time_parting_evaluation_result == TIME_PARTING_EVALUATION_FAIL ||
				result_holders.day_parting_evaluation_result == DAY_PARTING_EVALUATION_FAIL ||
				result_holders.site_section_evaluation_result == SITE_SECTION_EVALUATION_FAIL) {
				//continue in case user geo and segmentation evaluation is failed during first check in evaluate_floor_rules
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				cerr << "FLOOR FILTER: rule: " << floor_rule->rule_id()
					 <<	"is not applicable as segment, geo, time_parting, day_parting or "
					 <<	"site_section in rule was found to be not applicable in first check, so continue" << endl;
#endif
				break;
			}
			rt_response_index = -1;

			if (tmp_adcampaign->realtime_flag == 1) {
				if (tmp_adcampaign->ad_campaign_list_setings->rtb_campaign_response_index == -1) {
					continue;
				}
				rt_response_index = tmp_adcampaign->ad_campaign_list_setings->rtb_campaign_response_index;
				tmp_rt_response_params = &(rt_response_params[rt_response_index]);
				if (tmp_rt_response_params == NULL) {
					cerr << endl << endl
						 << "FLOOR FILTER: rt_response_params is NULL" << endl;
					continue;
				}

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				cerr << endl << endl
					 << "FLOOR FILTER: "
					 << "camapign id: " << rt_response_params[rt_response_index].campaign_id << ", "
					 << "dsp_id: " << rt_response_params[rt_response_index].dp_id << ", "
					 << "pubmatic_buyer_id: " << rt_response_params[rt_response_index].bid_response_params.pubmatic_buyer_id << ", "
					 << "advertiser_id: " << rt_response_params[rt_response_index].bid_response_params.advertiser_id << ", "
					 << "domain_id: " << rt_response_params[rt_response_index].bid_response_params.domain_id << ", "
					 << "country_code: " << fte_additional_parameters->gd.country_code << ", "
					 << "region_code: " << fte_additional_parameters->gd.region_code << ", "
					 << "city: " << fte_additional_parameters->gd.city << ", "
					 << "dma_code: " << fte_additional_parameters->gd.dma_code << ", "
					 << "aread_code: " << fte_additional_parameters->gd.area_code << ", "
					 << "ad_size_id: " << rt_response_params[rt_response_index].res_ad_dimension.ad_size_id << endl;
#endif
				//Process only those rules for the given campaign that have applicability=0(PMP and non-PMP targeted deals) and where rule priority >= deal priority
if( (tmp_adcampaign->ad_campaign_list_setings->dsp_interested_deal != NULL) &&
	(floor_rule->applicability()==1) ) 
{
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
					cerr << endl << endl
						 << "FLOOR FILTER: Rule: " << floor_rule->rule_id()
						 << "is skipped for campaign id: "<<rt_response_params[rt_response_index].campaign_id
						 << " with dsp bid response"
						 <<" applicability: "<<floor_rule->applicability()
						 << " rule priority: "<<floor_rule->priority()
						 <<" deal priority: "<<tmp_adcampaign->ad_campaign_list_setings->dsp_interested_deal->deal_pub.priority
						 <<endl;
						 
#endif
					DEBUG_LOG("\nRTB BID RESPONSE FILTER FLOOR FILTER: Rule: %d is skipped for campaign id: %d"
													" with dsp bid response bid_id: %d  applicability: %u "
													"rule_priority: %d deal_priority: %d\n",floor_rule->rule_id(),
													tmp_adcampaign->campaign_id,
													tmp_rt_response_params->bid_response_params.bid_id, 
													floor_rule->applicability(), floor_rule->priority(),
													tmp_adcampaign->ad_campaign_list_setings->dsp_interested_deal->deal_pub.priority
										);
					continue;
}
}

			applicable_deal_id_flag = 0;
			applicable_rule_flag = 0;
			evaluate_floor_rules(
							tmp_rt_response_params,
							tmp_adcampaign,
							floor_rule,
							in_req_params,
							in_ad,
							&applicable_deal_id_flag,
							fte_additional_parameters,
							&applicable_rule_flag,
							&result_holders,
							floor_bloom);

			if (applicable_rule_flag == 1) {
      
				double min_floor_ecpm_usd = CONVERT_NATIVE_CURRENCY_TO_USD( floor_rule->min_floor_ecpm(), currency_id,
												fte_additional_parameters->currency_xrate_map,  fte_additional_parameters->currency_count ) ;

				/* Disqualify rule having inactive currency */
				if ((floor_ecpm_usd == 0 && floor_rule->floor_ecpm() != 0) || 
					(min_floor_ecpm_usd == 0 && floor_rule->min_floor_ecpm() != 0)) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
					fprintf(stderr,"\nERROR::INVALID_CURRENCY_ID: floor_rule_id:%d currency_id:%d\n", 
                                                floor_rule->rule_id(), currency_id);
#endif
                                        LOG_FATAL( INVALID_DB_ENTRY, MOD_DEFAULT, "AdFlex.publisher_site_floor_rules.currency_id");
					applicable_rule_flag = 0;
					continue;
				}

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				cerr << "APPLIED FLOOR "
					 << "applicable rule id: " << floor_rule->rule_id() << ", "
					 << "floor ecpm: " << floor_ecpm_usd << ", "
					 << "campaign price: " << tmp_adcampaign->campaign_price << endl;

				fprintf( stderr, "Floor rule currency conversion while applying floor rule filter: Floor rule id: %d, Native ECPM: %f, Native minimum ECPM: %f,"
												" Native currency id: %d, USD ECPM: %f, USD minimum ECPM: %f\n",
												floor_rule->rule_id(), floor_rule->floor_ecpm(), floor_rule->min_floor_ecpm(),
												currency_id, floor_ecpm_usd, min_floor_ecpm_usd ) ;
#endif
				DEBUG_LOG("\nRTB BID RESPONSE FILTER APPLIED FLOOR applicable rule id: %d"
											 	"campaign id: %d floor_ecpm: %lf  min_floor_ecpm: %lf native currency id: %d"
												" USD ECPM: %lf USD minimum ECPM: %lf campaign_price: %lf\n",
												floor_rule->rule_id(), tmp_adcampaign->campaign_id,  
												floor_rule->floor_ecpm(),	floor_rule->min_floor_ecpm(), currency_id,
											 	floor_ecpm_usd, min_floor_ecpm_usd, tmp_adcampaign->campaign_price);

				bid_value = tmp_adcampaign->campaign_price;

				tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority = floor_rule->priority();
				tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm = floor_ecpm_usd;
				tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id = floor_rule->rule_id();
				tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type = floor_rule->fixed_price_flag();
				tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_type = floor_rule->floor_type();
				tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.guide_floor = 0;

				/*floor_application_flag is used to track if applied floor is hard_floor (always 0) or price_goal (greater than zero)
					in case of price_goal_floor floor_application can have following values
1 : bid >= floor_ecpm
2 : min_floor_epcm <= bid < floor_ecpm
3 : bid < min_floor_ecpm
*/
				//set initial value for floor_application_flag (i.e 0 for HARD floor rule and 1 for price goal floor) 
				tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_application_flag =
								floor_rule->floor_type() !=  PRICE_GOAL_FLOOR ? FR_DEFAULT_APPLICATION:FR_HIGH_BID;

					if (floor_rule->floor_type() == HARD_FLOOR ){
						if ( bid_value >= floor_ecpm_usd)
						{
							continue;
						}
						// asd1177
						floor_tobe_set = floor_ecpm_usd;

					}else if (floor_rule->floor_type() == PRICE_GOAL_FLOOR){
						/* Get average floor value */	
						floor_tobe_set = get_price_goal_floor_value(bid_value, impr_ecpm_tot, 
							&(tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_application_flag), floor_ecpm_usd, min_floor_ecpm_usd); 
					}else if (floor_rule->floor_type() == SOFT_FLOOR && bid_value <= floor_ecpm_usd){
						floor_tobe_set = min_floor_ecpm_usd;
						soft_floor_to_be_set = floor_ecpm_usd;
						tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.guide_floor = floor_ecpm_usd;

					}else if (floor_rule->floor_type() == SOFT_FLOOR && bid_value > floor_ecpm_usd){
						floor_tobe_set = floor_ecpm_usd;
					}

					//reset applied floor value based on calculated value
					tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm = floor_tobe_set;
					
					if (
                                                ((floor_rule->floor_type() != HARD_FLOOR) && (bid_value < floor_tobe_set)) || 
                                                (compare_with_reduced_floor(
                                                        in_req_params->publisher_id,
                                                        floor_tobe_set,
                                                        tmp_adcampaign,
                                                        additional_parameters,
                                                        fte_additional_parameters,
                                                        AND_NOTHING)
                                         )) {
					//camapign price is less then floor price so mark it filtered
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
						cerr << "FLOOR FILTER: "
							<< "rule_id: " << floor_rule->rule_id()
							 << " Filtered campaign: " << tmp_adcampaign->campaign_id << " floor : "<< floor_tobe_set  
							 << "bid_value: "<< bid_value << "floor_type: "<< floor_rule->floor_type() << "floor_flag "
							 << tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_application_flag << endl;
#endif
						DEBUG_LOG("\nRTB BID RESPONSE FILTER FLOOR FILTER: rule_id: %d Filtered campaign: %d bid_id: %d floor : %lf bid_value: %lf"
														" floor_type: %d floor_flag: %d\n", floor_rule->rule_id(), tmp_adcampaign->campaign_id,
														tmp_rt_response_params->bid_response_params.bid_id, floor_tobe_set, bid_value, floor_rule->floor_type(), tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_application_flag);

						tmp_adcampaign->ad_campaign_list_setings->filtered_flag = 1;
						tmp_adcampaign->ad_campaign_list_setings->reason_for_filtering = PMP_FLOOR_FILTER;
						continue;
					}


					if (floor_rule->floor_type() == SOFT_FLOOR && tmp_adcampaign->supports_first_price == 1 &&  bid_value <= soft_floor_to_be_set ){

						if(soft_floor_to_be_set < floor_tobe_set )
						{
							cerr << "ERROR: Soft Floor is set to be lesser than hard floor, soft floor= " << soft_floor_to_be_set<< " hard floor:" <<floor_tobe_set << endl;
							continue;

						}
						tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_application_flag = FR_SOFT_FLOOR;

					//camapign price is less then floor price so mark it filtered
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
						cerr << "Soft floor Applied: "
							<< "rule_id" << floor_rule->rule_id()
							 << "Filtered campaign: " << tmp_adcampaign->campaign_id << "floor : "<< floor_tobe_set
							 << "bid_value: "<< bid_value << "floor_type: "<< floor_rule->floor_type() << "floor_flag "
							 << tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_application_flag <<"soft_floor"<< soft_floor_to_be_set << endl;
#endif
						DEBUG_LOG("\nRTB BID RESPONSE FILTER Soft floor Applied: rule_id: %d Filtered campaign: %d bid_id: %d floor: %lf"
														"bid_value: %lf	floor_type: %d floor_flag: %d soft_floor: %lf\n", floor_rule->rule_id(),
														tmp_adcampaign->campaign_id, tmp_rt_response_params->bid_response_params.bid_id,
														floor_tobe_set, bid_value, floor_rule->floor_type(), tmp_adcampaign->ad_campaign_list_setings->applied_floor_rules_settings.floor_application_flag, soft_floor_to_be_set);			
						continue;
					}
		  	}
		}
	}

	return ADS_ERROR_SUCCESS;
}

/* Get average floor value  in case floor type is price goal */
static double get_price_goal_floor_value(double bid_value, 
	site_impressions_ecpm_total_t *impr_ecpm_tot,
	int *floor_application_flag,
	double floor_ecpm_usd,
	double min_floor_ecpm_usd) {

	//If floor to be set id less than mininum floor value than return minimum floor as floor value and this bid will get filtered
	if (bid_value < min_floor_ecpm_usd){
		(*floor_application_flag) = FR_LOW_BID;
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		fprintf (stderr , "cpm_goal: bid_value:%f, min_floor_ecpm_usd:%f\n", bid_value, min_floor_ecpm_usd); 
#endif
		return min_floor_ecpm_usd;
	}

	(*floor_application_flag) = FR_AVERAGE_BID;

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		fprintf (stderr , "cpm_goal: current_total_impression:%ld, current_total_ecpm:%f\n", 
				impr_ecpm_tot->impression_totol,impr_ecpm_tot->ecpm_total);
#endif
	//check if average can be maintained by considering min floor value,
	//If average can be maintained consider min floor value as floor
	//This calculation could be redundant as its done for all campaign and since rule is it at sight level and applicable to RTB campaign
	//To keep code genric and its done here
	if(floor_ecpm_usd * (impr_ecpm_tot->impression_totol+1) < (impr_ecpm_tot->ecpm_total + min_floor_ecpm_usd)){
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		fprintf (stderr , "cpm_goal: current_total_impression:%ld, current_total_ecpm:%f min_floor_ecpm_usd:%f\n", 
				impr_ecpm_tot->impression_totol,impr_ecpm_tot->ecpm_total, min_floor_ecpm_usd);
#endif
		return min_floor_ecpm_usd;
	}else{
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		fprintf (stderr , "cpm_goal: current_total_impression:%ld, current_total_ecpm:%f floor_ecpm_usd:%f\n", 
				impr_ecpm_tot->impression_totol,impr_ecpm_tot->ecpm_total, floor_ecpm_usd);
#endif
		return floor_ecpm_usd;
	}

}

/*
* This function evaluate if rule is applicable to rtb bid response by comapring dsp, buyer, advertiser and domainid id and also do 
* evaluation for geo and also  dp_segment expression for user segments
*/

static int evaluate_floor_rules(const rt_response_params_t * rt_response_params,
		publisher_site_ad_campaign_list_t *adcampaign,
		publisher_site_floor_rule *floor_rule,
		ad_server_req_param_t *in_req_params,
		publisher_site_ad_t *in_ad,
		int *applicable_deal_id_flag,
		fte_additional_params_t *fte_additional_parameters,
		unsigned int *applicable_rule_flag,
		floor_rule_evalaluation_result_holders_t *result_holders,
		MULTI_BLOOM floor_bloom[]) {

	(void)in_ad;
	int active_entity = 0;
	int user_segment_evaluation_result = USER_SEGMENT_EVALUATION_FAIL;
	int active_elements_array_index = 0;
	int time_parting_evaluation_result = TIME_PARTING_EVALUATION_FAIL;
	int day_parting_evaluation_result = DAY_PARTING_EVALUATION_FAIL;
	char *token = NULL, *saveptr = NULL, *zones;
	int index = 0;
	int is_deal_active = 0;
	

	(*applicable_rule_flag) = 1; 

	if (floor_rule == NULL) {
		(*applicable_rule_flag) = 0;
		return ADS_ERROR_INTERNAL;

	}
	if (adcampaign->realtime_flag == 1 && rt_response_params == NULL) {
		(*applicable_rule_flag) = 0;
		return ADS_ERROR_INTERNAL;
	}

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	dump_floor_rule(floor_rule, __FUNCTION__, __LINE__);
	if (rt_response_params != NULL) {
#if 0
	fprintf (stderr, "\nFLOOR FILTER: camapign id:%ld, dsp_id:%d, pubmatic_buyer_id:%d, advertiser_id:%d, domain_id:%d\n", 
			rt_response_params[0].campaign_id, rt_response_params[0].dp_id, rt_response_params[0].bid_response_params.pubmatic_buyer_id,
			rt_response_params[0].bid_response_params.advertiser_id, rt_response_params[0].bid_response_params.domain_id); 
#endif
	}
#endif
	//camapre rule value for each entity mentioned in active entity list  against rtb bid response to evalue if rule applicable
		
	for ( active_elements_array_index = 0; 
		active_elements_array_index < floor_rule->active_entities_array_size() && (*applicable_rule_flag) == 1; 
		active_elements_array_index++) {

		active_entity = floor_rule->active_entities_array(active_elements_array_index);



#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		cerr << "FLOOR FILTER: active entity: " << active_entity << endl;
#endif
		switch(active_entity) {
			case NO_ENTITY_SET:
					//NO_ENTITY_SET=0 indicates no entity is set, rule is applicable to all bids
					break;
			case DSP_ID:
				for (index = 0; index < floor_rule->dsp_ids_size(); index++) {
					if (adcampaign->dp_id == floor_rule->dsp_ids(index)) {
						(*applicable_rule_flag) = 1;
						break;
					} else {
						(*applicable_rule_flag) = 0;
					}
				}
				break;

			case BUYER_ID:
				if (floor_rule->rule_type() == RULE_STANDARD_ADFLEX) {
					(*applicable_rule_flag) = 0;
					break;
				}
				for (index = 0; index < floor_rule->buyer_ids_size(); index++) {
					if (rt_response_params->bid_response_params.pubmatic_buyer_id == floor_rule->buyer_ids(index)) {
						(*applicable_rule_flag) = 1;
						break;
					} else {
						(*applicable_rule_flag) = 0;
					}
				}
				break;

			case ADVERTISER_ID:
				if (floor_rule->rule_type() == RULE_STANDARD_ADFLEX) {
					(*applicable_rule_flag) = 0;
					break;
				}
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				cerr << "FLOOR FILTER: Advertiser floor domain " << rt_response_params->bid_response_params.landing_page_tld << endl;
#endif
				if ( substring_multi_concat_bloom_search(floor_rule->rule_meta_id(), rt_response_params->bid_response_params.landing_page_tld, &floor_bloom[ADVERTISER_BLOOM_INDEX])){
						(*applicable_rule_flag) = 1;
						break;
				} else {
						(*applicable_rule_flag) = 0;
				}
				break;

			case DOMAIN_ID:
				if (floor_rule->rule_type() == RULE_STANDARD_ADFLEX) {
					(*applicable_rule_flag) = 0;
					break;
				}
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                                cerr << "FLOOR FILTER: Domain floor domain " << rt_response_params->bid_response_params.landing_page_tld << endl;
#endif
				if ( substring_multi_concat_bloom_search(floor_rule->rule_meta_id(), rt_response_params->bid_response_params.landing_page_tld, &floor_bloom[DOMAIN_BLOOM_INDEX])){
						(*applicable_rule_flag) = 1;
						break;
				} else {
						(*applicable_rule_flag) = 0;
				}
				break;

			case SEGMENT_ID:
        // coppa impression filter this rule.
        if (fte_additional_parameters->in_server_req_params->is_coppa_compliant == 1) {
          (*applicable_rule_flag) = 0; 
          result_holders->user_segment_evaluation_result = USER_SEGMENT_EVALUATION_FAIL; 
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
          cerr << "FLOOR FILTER COPPA" << endl;
#endif
          break;
        }

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				cerr << "FLOOR FILTER user_segment_evaluation_result flag: "
					 <<	result_holders->user_segment_evaluation_result << endl;
#endif
				if (result_holders->user_segment_evaluation_result == USER_SEGMENT_NOT_EVALUATED) {
					if (fte_additional_parameters->audience_params.user_segment_list_info != NULL ) {
						for (index = 0; index < floor_rule->segments_size(); index++) {
							user_segment_evaluation_result = USER_SEGMENT_NOT_EVALUATED;
							evaluate_audience_user_segments(
								floor_rule->segments(index).c_str(),
								fte_additional_parameters->audience_params.user_segment_list_info, 
								&user_segment_evaluation_result,
								NULL);
							if (user_segment_evaluation_result == USER_SEGMENT_EVALUATION_PASS) {
								(*applicable_rule_flag) = 1;
								break;
							} else {
								(*applicable_rule_flag) = 0;
							}
						} 
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
						cerr << "FLOOR FILTER: user segment evaluation result: "
							 << result_holders->user_segment_evaluation_result << endl;
#endif
						/*	value in user_segment_evaluation_result will set 
							publisher_site_floor_rule_settings->user_segment_evaluation_result as USER_SEGMENT_EVALUATION_FAIL
							or  USER_SEGMENT_EVALUATION_PASS
						 */
						result_holders->user_segment_evaluation_result = user_segment_evaluation_result;
					}else {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
						cerr << "FLOOR FILTER: user_segment_list is NULL or empty" << endl;
#endif
						result_holders->user_segment_evaluation_result = USER_SEGMENT_EVALUATION_FAIL;
					}
				}
				if (result_holders->user_segment_evaluation_result == USER_SEGMENT_EVALUATION_FAIL) {
					(*applicable_rule_flag) = 0;
				}
				break;

			case GEO_COUNTRY_CODE:
				if (result_holders->geo_evaluation_result != GEO_NOT_EVALUATED) {
					(*applicable_rule_flag) = (result_holders->geo_evaluation_result == GEO_EVALUATION_PASS)? 1: 0;
					break;
				}
				(*applicable_rule_flag) = 0;
				for (index = 0; index < floor_rule->country_codes_size(); index++) {
					if ( (strncmp(fte_additional_parameters->gd.country_code, floor_rule->country_codes(index).c_str(), MAX_GEO_CODE_LEN) == 0) ||
						(strncmp(floor_rule->country_codes(index).c_str() , DEFAULT_GEO_CODE, DEFAULT_GEO_CODE_LEN ) == 0) ) {
						(*applicable_rule_flag) = 1;
						break;
					}
				}
				if ((*applicable_rule_flag) == 0){
					result_holders->geo_evaluation_result = GEO_EVALUATION_FAIL;
				}
				break;

			case GEO_REGION_CODE:
				if (result_holders->geo_evaluation_result != GEO_NOT_EVALUATED) {
					(*applicable_rule_flag) = (result_holders->geo_evaluation_result == GEO_EVALUATION_PASS)? 1: 0;
					break;
				}
				(*applicable_rule_flag) = 0;
				for (index = 0; index < floor_rule->region_codes_size(); index++) {
					if ( (strncmp(fte_additional_parameters->gd.region_code, floor_rule->region_codes(index).c_str(), MAX_GEO_CODE_LEN) == 0) ||
						(strncmp(floor_rule->region_codes(index).c_str(), DEFAULT_GEO_CODE, DEFAULT_GEO_CODE_LEN ) == 0) ) {
						(*applicable_rule_flag) = 1;
						break;
					} 
				}
				if ((*applicable_rule_flag) == 0){
					result_holders->geo_evaluation_result = GEO_EVALUATION_FAIL;
				}
				break;

			case GEO_CITY_NAME:
				if (result_holders->geo_evaluation_result != GEO_NOT_EVALUATED) {
					(*applicable_rule_flag) = (result_holders->geo_evaluation_result == GEO_EVALUATION_PASS)? 1: 0;
					break;
				}
				(*applicable_rule_flag) = 0;
				for (index = 0; index < floor_rule->city_names_size(); index++) {
					if ( (strncmp(fte_additional_parameters->gd.city, floor_rule->city_names(index).c_str(), MAX_GEO_NAME_LEN) == 0) ||
						(strncmp(floor_rule->city_names(index).c_str(), DEFAULT_GEO_CODE, DEFAULT_GEO_CODE_LEN ) == 0) ) {
						(*applicable_rule_flag) = 1;
						break;
					}
				}
				if ((*applicable_rule_flag) == 0){
					result_holders->geo_evaluation_result = GEO_EVALUATION_FAIL;
				}
				break;

			case GEO_DMA_CODE:
				if (result_holders->geo_evaluation_result != GEO_NOT_EVALUATED) {
					(*applicable_rule_flag) = (result_holders->geo_evaluation_result == GEO_EVALUATION_PASS)? 1: 0;
					break;
				}
				(*applicable_rule_flag) = 0;
				for (index = 0; index < floor_rule->dma_codes_size(); index++) {
					if (fte_additional_parameters->gd.dma_code == floor_rule->dma_codes(index) || 
						floor_rule->dma_codes(index) == 0) {
						(*applicable_rule_flag) = 1;
						break;
					} 
				}
				if ((*applicable_rule_flag) == 0){
					result_holders->geo_evaluation_result = GEO_EVALUATION_FAIL;
				}
				break;

           	case TIME_PARTING:
				if (result_holders->time_parting_evaluation_result == TIME_PARTING_NOT_EVALUATED) {
					if (floor_rule->end_time_parting() != floor_rule->start_time_parting() &&
						in_req_params->time_stamp != NULL) {
						do_time_parting(floor_rule->start_time_parting(),
										floor_rule->end_time_parting(),
										in_req_params,
										&time_parting_evaluation_result);
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                        cerr << "TIME PARTING RESULT: "  << time_parting_evaluation_result << endl;
#endif
						result_holders->time_parting_evaluation_result = time_parting_evaluation_result;
                	} else {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                    	  cerr << "FLOOR FILTER: Data from user and/or db is NULL or empty or invalid" << endl;
#endif
                    	  result_holders->time_parting_evaluation_result = TIME_PARTING_EVALUATION_FAIL;
					}
				}
                if (result_holders->time_parting_evaluation_result == TIME_PARTING_EVALUATION_FAIL) {
					(*applicable_rule_flag) = 0;
                }
                break;

			case DAY_PARTING:
				if (result_holders->day_parting_evaluation_result == DAY_PARTING_NOT_EVALUATED) {
					if (floor_rule->days_of_week() != 0 && in_req_params->time_stamp != NULL) {
						do_day_parting(floor_rule->days_of_week(), in_req_params, &day_parting_evaluation_result);
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
						cerr << "DAY PARTING RESULT: " << day_parting_evaluation_result << endl;
#endif
						result_holders->day_parting_evaluation_result = day_parting_evaluation_result;
                	} else {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
						cerr << "FLOOR FILTER: Data from user and/or db is NULL or empty or invalid" << endl;
#endif
						result_holders->day_parting_evaluation_result = DAY_PARTING_EVALUATION_FAIL;
					}
				}
				if (result_holders->day_parting_evaluation_result == DAY_PARTING_EVALUATION_FAIL) {
					(*applicable_rule_flag) = 0;
				}
				break;

			case AD_SIZE: 
				for (index = 0; index < floor_rule->ad_size_ids_size(); index++) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
					cerr << "\nFLOOR_RULES_AD_SIZE: rID:" << floor_rule->rule_id() 
							<< " CadszId:" << rt_response_params->res_ad_dimension.ad_size_id 
							<< " FadszId:" << floor_rule->ad_size_ids(index) 
							<< " cId:" << rt_response_params->campaign_id 
							<< " rqIdx:" << rt_response_params->rt_req_id_index << endl;
#endif
					if ((unsigned)rt_response_params->res_ad_dimension.ad_size_id == floor_rule->ad_size_ids(index)) {
						(*applicable_rule_flag) = 1;
						break;
					} else {
						(*applicable_rule_flag) = 0;
					}
				}
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				cerr << "AD SIZE RESULT: " << (*applicable_rule_flag) << endl;
#endif
				break;

			case FOLD_POS: 
				if (result_holders->fold_position_evaluation_result != FOLD_POSITION_NOT_EVALUATED) {
					(*applicable_rule_flag) = (result_holders->fold_position_evaluation_result == FOLD_POSITION_EVALUATION_PASS)? 1: 0;
					break;
				}
				for (index = 0; index < floor_rule->fold_position_ids_size(); index++) {
					/* Check if we got this from the showad.js */
                    if (in_req_params->s_fold_position_id) {
                        if (in_req_params->s_fold_position_id == floor_rule->fold_position_ids(index)) {
							result_holders->fold_position_evaluation_result = FOLD_POSITION_EVALUATION_PASS;
							break;
                        } else {
                             result_holders->fold_position_evaluation_result = FOLD_POSITION_EVALUATION_FAIL;
                        }
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
					    cerr << "FOLD from Adtag " << in_req_params->s_fold_position_id << "," 
							 << " From Rule: " << floor_rule->fold_position_ids(index) << endl
							 << " FOLD POS RESULT: " << result_holders->fold_position_evaluation_result << endl;
#endif
                    } else if (fte_additional_parameters->u_fold_position_id) {
                    	/* check if it matches the one in the database */
                        if (fte_additional_parameters->u_fold_position_id == floor_rule->fold_position_ids(index)) {
                            result_holders->fold_position_evaluation_result = FOLD_POSITION_EVALUATION_PASS;
							break;
                        } else {
                            result_holders->fold_position_evaluation_result = FOLD_POSITION_EVALUATION_FAIL;
                        }
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
    					cerr << "FOLD from DB: " << fte_additional_parameters->u_fold_position_id << ","
							 << " From Rule: " << floor_rule->fold_position_ids(index) << endl
							 << " FOLD POS RESULT: " << result_holders->fold_position_evaluation_result << endl;
#endif
                    } else {
                        /* Either it was zero (or it was non-zero and did not match the ad_size_id from the showad.js or the db) */
                        result_holders->fold_position_evaluation_result = FOLD_POSITION_EVALUATION_FAIL;
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
					    cerr << "FOLD_POSITION_EVALUATION_RESULT: " <<  result_holders->fold_position_evaluation_result << endl;
#endif
                    }
				}

				if (result_holders->fold_position_evaluation_result == FOLD_POSITION_EVALUATION_FAIL) {
					(*applicable_rule_flag) = 0;
				} else {
					(*applicable_rule_flag) = 1;
				}
				break;	

			case ADVERTISER_CATEGORIES : 
				if (floor_rule->rule_type() == RULE_STANDARD_ADFLEX) {
					(*applicable_rule_flag) = 0;
					break;
				}
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
							cerr << "FLOOR FILTER: category floor domain " << rt_response_params->bid_response_params.landing_page_tld << endl;
#endif
				if(substring_multi_concat_bloom_search(floor_rule->rule_meta_id(), rt_response_params->bid_response_params.landing_page_tld, &floor_bloom[CATEGORY_BLOOM_INDEX])){
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
					cerr << "Category Found, Rule Applicable" << endl;
#endif
					(*applicable_rule_flag) = 1;
                			break;
                        	} else{
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                                        cerr << "Category Not Found, Rule Not Applicable" << endl;
#endif
					(*applicable_rule_flag) = 0;
				}
				
			break;

			case SITE_SECTION :
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
 				cerr << "SITE SECTION FROM AD-TAG: " <<  in_req_params->zone << endl;
#endif
				if (result_holders->site_section_evaluation_result == SITE_SECTION_NOT_EVALUATED &&
					in_req_params->zone != NULL
					&& in_req_params->zone [0] != '\0') {
					for (index = 0; index < floor_rule->site_sections_size(); index++) {
						zones = strdup(in_req_params->zone);
						if (zones == NULL) {
							cerr << "Memory not available :: " << __FILE__ << " ," << __LINE__ << endl;
							(*applicable_rule_flag) = 0;
							break;
						}

						token = strtok_r(zones, ",", &saveptr);
						while (token != NULL) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
							cerr << "TOKEN: " <<  token << endl;
#endif
							if (!strncmp (token, floor_rule->site_sections(index).c_str(), MAX_SITE_SECTION_SIZE )) {
								result_holders->site_section_evaluation_result = SITE_SECTION_EVALUATION_PASS;
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
 								cerr << "SITE SECTION FOUND" << endl;
#endif
								break;
							}
							token = strtok_r(NULL, ",", &saveptr);
						}

						// Free the strdup'd string
						if (zones != NULL) {
							free(zones);
							zones = NULL;
						}
						if (result_holders->site_section_evaluation_result == SITE_SECTION_EVALUATION_PASS) {
							break;
						}
					}
				}

				if (result_holders->site_section_evaluation_result != SITE_SECTION_EVALUATION_PASS) {
					result_holders->site_section_evaluation_result = SITE_SECTION_EVALUATION_FAIL;
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
					cerr << "SITE SECTION NOT FOUND" << endl;
#endif
					(*applicable_rule_flag) = 0;
				}
				break;

			case CMPG_ID:
				for (index = 0; index < floor_rule->campaign_ids_size(); index++) {
					if (adcampaign->campaign_id == floor_rule->campaign_ids(index)) {
						(*applicable_rule_flag) = 1;
						break;
					} else {
						(*applicable_rule_flag) = 0;
					}
				}
				break;
	
			case DEAL_ID:

				if (adcampaign->ad_campaign_list_setings->dsp_interested_deal == NULL || adcampaign->ad_campaign_list_setings->dsp_interested_deal->parent_deal_params == NULL){

						(*applicable_rule_flag) = 0;
						(*applicable_deal_id_flag) = 0;
				}else{
					for (index = 0; index < floor_rule->deal_meta_id_size(); index++) {
						if ( adcampaign->ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_meta_id == floor_rule->deal_meta_id(index)) {
							(*applicable_rule_flag) = 1;
							(*applicable_deal_id_flag) = 1;
							is_deal_active = 1;
							break;
						} else {
							(*applicable_rule_flag) = 0;
							(*applicable_deal_id_flag) = 0;
						}
					}
				}
				break;

			case RM_CREATIVE_ID:
				for (index = 0; index < floor_rule->rich_media_creative_attribute_ids_size(); index++) {
					if ( rt_response_params->bid_response_params.rich_media_ad_creative_attribute_id > 0 && 
						(rt_response_params->bid_response_params.rich_media_ad_creative_attribute_id == floor_rule->rich_media_creative_attribute_ids(index) || floor_rule->rich_media_creative_attribute_ids(index) == 0) ) {
						(*applicable_rule_flag) = 1;
						break;
					} else {
						(*applicable_rule_flag) = 0;
					}
				}
				break;

			case LINE_ITEM_ID:
			  (*applicable_rule_flag) = 0;
			  break;
			 case MATCHED_USER:
					if((rt_response_params->dsp_user_match_found == 1 && (floor_rule->matched_user() == MATCHD_USER_RULE)) ||
							(rt_response_params->dsp_user_match_found == 0 && (floor_rule->matched_user() == UNMATCHD_USER_RULE))){
						break;
					}
					else {
						(*applicable_rule_flag) = 0;
					}
					break;
			case PLATFORM_ID:
					if(floor_rule->platform_id() == in_req_params->site_ad->platform_id){
						break;
					} else {
						(*applicable_rule_flag) = 0;
						DEBUG_LOG("\n PLATFORM_RULE_FAILED floor_pf = %d and pfi = %d\n", floor_rule->platform_id(), in_req_params->site_ad->platform_id);
					}
					break;
			default:
				//ERROR: unknown entity
				cerr << "ERROR: Unknown entity number (" << active_entity << ")"
					<< " found in floor rules active entity list in DB, " << __FILE__ ":" << __LINE__ << endl;
				(*applicable_rule_flag) = 0;
				break;

		}
	}
	
	//if floor_rule geo evaluation did not fail then there is no geo entity in rule or it matches rule so marked geo evaltion pass
	if (result_holders->geo_evaluation_result != GEO_EVALUATION_FAIL) {
		result_holders->geo_evaluation_result = GEO_EVALUATION_PASS;
	}

	/* If there is bid for deal (LAST_LOOK_BUY), ignore all rules except the rule targeted on deal */  
	if (IS_DEAL_LEVEL_FEATURE_FLAG_SET(adcampaign, LAST_LOOK_BUY) ==  1 && is_deal_active != 1){
		(*applicable_rule_flag) = 0;	
	}

	return ADS_ERROR_SUCCESS;

}


//Return ADS_ERROR_SUCCESS on success & ADS_ERROR_INTERNAL on failure.
extern "C" void *copy_floor_rule_from_db(	long publisher_id,
								long site_id,
								db_publisher_site_floor_rules_settings_t *db_row,
								int *active_entities_array,
								int active_entities_array_elements_count,
								int prev_rule_id,
								int *rc,
								void *floor_rules_protobuff_ctxt)
{
	publisher_site_floor_rules *floor_rules  = NULL;
	publisher_site_floor_rule *floor_rule  = NULL;
	int i = 0;
	//int *active_entities_array = NULL;
	int active_entity = 0;

	if (db_row == NULL ||
		active_entities_array == NULL)
	{
		*rc =  ADS_ERROR_INTERNAL;
		return NULL;
	}

	floor_rules = (publisher_site_floor_rules *) floor_rules_protobuff_ctxt;
	//Allocate Floor rules protobuff object if not already allocated.
	if (floor_rules == NULL)
	{
		floor_rules = new publisher_site_floor_rules();
		if (floor_rules == NULL)
		{
			*rc = ADS_ERROR_INTERNAL;
			return NULL;
		}
		floor_rule = floor_rules->add_floor_rules();
		if (floor_rule == NULL)
		{
			*rc = ADS_ERROR_INTERNAL;
			free_floor_rules_protobuff_ctxt(floor_rules);
			return NULL;
		}
	}
	else if (prev_rule_id != db_row->s_rule_id)
	{
		//Allocate new Floor rule object for new rule.
		floor_rule = floor_rules->add_floor_rules();
		if (floor_rule == NULL)
		{
			*rc = ADS_ERROR_INTERNAL;
			return floor_rules;
		}
	}
	else
	{
		//Should call copy_floor_rule_active_entities_from_db() instead. This function is for copying rule specific data.
		*rc = ADS_ERROR_INTERNAL;
		return floor_rules;
	}

	floor_rule->set_pub_id(publisher_id);
	floor_rule->set_site_id(site_id);
	floor_rule->set_rule_id(db_row->s_rule_id);
	floor_rule->set_rule_type(db_row->s_rule_type);
	floor_rule->set_floor_type(db_row->s_floor_type);
	floor_rule->set_priority(db_row->s_priority);
	floor_rule->set_fixed_price_flag(db_row->s_fixed_price_flag);
	floor_rule->set_floor_ecpm(db_row->s_floor_ecpm);
	floor_rule->set_min_floor_ecpm(db_row->s_min_floor_ecpm);
	floor_rule->set_start_time_parting(db_row->s_start_time_parting);
	floor_rule->set_end_time_parting(db_row->s_end_time_parting);
	floor_rule->set_days_of_week(db_row->s_days_of_week);
	floor_rule->set_rule_meta_id(db_row->s_rule_meta_id);
	floor_rule->set_matched_user(db_row->s_matched_user);
	floor_rule->set_platform_id(db_row->s_platform_id);
	floor_rule->set_currency_id(db_row->s_currency_id);
  floor_rule->set_applicability(db_row->s_applicability);
	//Copy active entities array.
	for (i = 0; i < active_entities_array_elements_count; i++)
	{
		active_entity = active_entities_array[i];
		floor_rule->add_active_entities_array(active_entity);
	}
	*rc = ADS_ERROR_SUCCESS;
	return floor_rules;
}

//Return ADS_ERROR_SUCCESS on success & ADS_ERROR_INTERNAL on failure.
extern "C" int copy_floor_rule_active_entities_from_db(	db_publisher_site_floor_rules_settings_t *db_row,
												void *floor_rules_protobuff_ctxt)
{
	publisher_site_floor_rules *floor_rules  = NULL;
	publisher_site_floor_rule *floor_rule  = NULL;
	int i = 0;
	int active_entity = 0;

	if (db_row == NULL ||
		floor_rules_protobuff_ctxt == NULL)
	{
		return ADS_ERROR_INTERNAL;
	}

	floor_rules = ((publisher_site_floor_rules *) floor_rules_protobuff_ctxt);
	floor_rule = floor_rules->mutable_floor_rules(floor_rules->floor_rules_size() - 1);

	for (i = 0; i < floor_rule->active_entities_array_size(); i++)
	{
		active_entity = floor_rule->active_entities_array(i);
		switch (active_entity)
		{
			case NO_ENTITY_SET:
				//NO_ENTITY_SET=0 indicates no entity is set.
				break;

			case DSP_ID:
				floor_rule->add_dsp_ids(db_row->s_dsp_id);
				break;

			case BUYER_ID:
				floor_rule->add_buyer_ids(db_row->s_buyer_id);
				break;

			case ADVERTISER_ID:
				//Not applicable
				break;

			case DOMAIN_ID:
				//Not applicable
				break;

			case SEGMENT_ID:
				if (db_row->cb_segment != SQL_NULL_DATA && db_row->cb_segment != 0){
					floor_rule->add_segments((char *) db_row->s_segment);
				}
				break;

			case GEO_COUNTRY_CODE:
				if (db_row->cb_country_code != SQL_NULL_DATA && db_row->cb_country_code != 0){
					floor_rule->add_country_codes((char *) db_row->s_country_code);
				}else{
					/* BUG FIX. Geo values can be NULL even in case it is set as active entity since rule implementation requires all rules under give rule id have same number of active entities, because in case rule is on country US,UK and city as NY. then rule with UK will not have city it will have default value and city will be marked as active entity. To handle any such  case it will have default value i.e ALL */ 
					floor_rule->add_country_codes((char *) DEFAULT_GEO_CODE);
				}
				
				break;

			case GEO_REGION_CODE:
				if (db_row->cb_region_code != SQL_NULL_DATA && db_row->cb_region_code != 0){
					floor_rule->add_region_codes((char *) db_row->s_region_code);
				}else{
					floor_rule->add_region_codes((char *) DEFAULT_GEO_CODE);
				}
				break;

			case GEO_CITY_NAME:
				if (db_row->cb_city_name != SQL_NULL_DATA && db_row->cb_city_name != 0){
					floor_rule->add_city_names((char *) db_row->s_city_name);
				}else{
					floor_rule->add_city_names((char *) DEFAULT_GEO_CODE);
				}
				break;

			case GEO_DMA_CODE:
				//DMA is by default 0
				floor_rule->add_dma_codes(db_row->s_dma_code);
				break;

			case TIME_PARTING:
				//Not applicable
				break;

			case DAY_PARTING:
				//Not applicable
				break;

			case AD_SIZE:
				floor_rule->add_ad_size_ids(db_row->s_ad_size_id);
				break;

			case FOLD_POS:
				floor_rule->add_fold_position_ids(db_row->s_fold_position_id);
				break;

			case ADVERTISER_CATEGORIES:
				//Not applicable
				break;

			case SITE_SECTION:
				floor_rule->add_site_sections((char *) db_row->s_site_section);
				break;

			case CMPG_ID:
				floor_rule->add_campaign_ids(db_row->s_campaign_id);
				break;

			case DEAL_ID:
				//Rule_meta_id is same as  deal meta id, so setting deal meta id = rule_meta_id
				floor_rule->add_deal_meta_id(db_row->s_rule_meta_id);
				break;

			case RM_CREATIVE_ID:
				floor_rule->add_rich_media_creative_attribute_ids(db_row->s_rich_media_creative_attribute_id);
				break;
			case LINE_ITEM_ID:
				floor_rule->add_line_item_ids(db_row->s_line_item_id);
				break;
		}
	}
	return ADS_ERROR_SUCCESS;
}

/*
 * 1. Allocate memcached_floor_rules along with buffer to store proto buff serialized object.
 * 2. Serialized proto buff object to string & copy this string to the buff allocated in step 1.
 * 
 * Returns ADS_ERROR_SUCCESS on success & ADS_ERROR_INTERNAL on failure.
 */
extern "C" int serialize_memcached_floor_rules(memcached_floor_rules_t **memcached_floor_rules, void *floor_rules_protobuff_ctxt)
{
	publisher_site_floor_rules *floor_rules = (publisher_site_floor_rules *) floor_rules_protobuff_ctxt;
	string serialized_string;
	ssize_t serialized_string_len = 0;

	if (memcached_floor_rules == NULL ||
		*memcached_floor_rules != NULL ||
		floor_rules_protobuff_ctxt == NULL)
	{
		return ADS_ERROR_INTERNAL;
	}

	if (!floor_rules->SerializeToString(&serialized_string))
	{
		fprintf(stderr, "(%s:%d) Not able to serailized floor_rules.\n",
						__FUNCTION__,
						__LINE__);
		return ADS_ERROR_INTERNAL;
	}
	serialized_string_len = serialized_string.length();
	*memcached_floor_rules = (memcached_floor_rules_t *) malloc(sizeof (memcached_floor_rules_t) + serialized_string_len);
	if (*memcached_floor_rules == NULL)
	{
		fprintf(stderr, "(%s:%d) Not able to allocate memory for memcached_floor_rules_t.\n",
						__FUNCTION__,
						__LINE__);
		return ADS_ERROR_INTERNAL;
	}
	char *protobuff_floor_rules = (char *) &((*memcached_floor_rules)[1]);
	memcpy(protobuff_floor_rules, serialized_string.c_str(), serialized_string_len);

	//Init rest of the fields of memcached_floor_rules.
	(*memcached_floor_rules)->nelements = floor_rules->floor_rules_size();
	(*memcached_floor_rules)->total_sizeof_protobuff_floor_rules = sizeof (memcached_floor_rules_t) + serialized_string_len;

	return ADS_ERROR_SUCCESS;
}

/*
 * 1. Deserialize memcached_floor_rules.
 * 2. Create protobuff object from given memcached_floor_rules.
 *
 * Returns protobuff object on success & NULL on failure.
 */ 
extern "C" void *deserialize_memcached_floor_rules(memcached_floor_rules_t *memcached_floor_rules)
{
	string string_to_parse;
	ssize_t string_to_parse_len = 0;

	if (memcached_floor_rules == NULL)
	{
		return NULL;
	}

	//Deserialize memcached_floor_rules.
	char* protobuff_floor_rules = (char *) &((memcached_floor_rules)[1]);;
	publisher_site_floor_rules *floor_rules = new publisher_site_floor_rules();

	if (protobuff_floor_rules == NULL || floor_rules == NULL) {
		return NULL;
	}

	string_to_parse_len = (memcached_floor_rules->total_sizeof_protobuff_floor_rules - sizeof (memcached_floor_rules_t));
	string_to_parse.assign(protobuff_floor_rules, string_to_parse_len);
	if (!floor_rules->ParseFromString(string_to_parse))
	{
		fprintf(stderr, "(%s:%d) Not able to parse memcached_floor_rules from string.\n",
						__FUNCTION__,
						__LINE__);
		goto handle_error;
	}
	return floor_rules;

handle_error:
	delete floor_rules;
	return NULL;
}

extern "C" void free_memcached_floor_rules(memcached_floor_rules_t **memcached_floor_rules)
{
	if (memcached_floor_rules == NULL ||
		*memcached_floor_rules == NULL)
	{
		return;
	}

	free(*memcached_floor_rules);
	*memcached_floor_rules = NULL;
}

extern "C" void free_floor_rules_protobuff_ctxt(void *floor_rules_protobuff_ctxt)
{
	publisher_site_floor_rules *floor_rules = (publisher_site_floor_rules *) floor_rules_protobuff_ctxt;

	if (floor_rules != NULL)
	{
		delete floor_rules;
	}
}

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
extern "C" void dump_floor_rule(void *floor_rule_proto_ctxt, const char *fn, int ln)
{
	int active_entity = 0;
	int index = 0, i = 0;
	publisher_site_floor_rule *floor_rule = (publisher_site_floor_rule *) floor_rule_proto_ctxt;

	if (floor_rule == NULL)
	{
		return;
	}

	cerr << endl << "INFO: floor rules" << endl
		 << "================================== (" << fn
		 << ":" << ln << ") ===================================" << endl
	     <<  endl << "rule_id:" << floor_rule->rule_id() << " "
		 << "pub_id " << floor_rule->pub_id() << " "
		 << "rule_type " << floor_rule->rule_type() << " "
		 << "site_id " << floor_rule->site_id() << " "
		 << "floor_type " << floor_rule->floor_type() << " "
		 << "minimum_floor_ecpm " << floor_rule->min_floor_ecpm() << " "
		 << "floor_ecpm " << floor_rule->floor_ecpm() << " "
		 << "priority" << floor_rule->priority() << " "
		 << "fixed_priced_flag" << floor_rule->fixed_price_flag() << " "
		 << "start_time_parting" << floor_rule->start_time_parting() << " "
		 << "end_time_parting" << floor_rule->end_time_parting() << " "
		 << "days_of_week" << floor_rule->days_of_week() << " "
		 << "applicability " << floor_rule->applicability() << " "
		 << endl << endl;
	for (i = 0; i < floor_rule->active_entities_array_size(); i++)
	{
		active_entity = floor_rule->active_entities_array(i);
		switch (active_entity)
		{
			case NO_ENTITY_SET:
				//NO_ENTITY_SET=0 indicates no entity is set.
				break;

			case DSP_ID:
				cerr << " ,dsp_ids:[";
				for (index = 0; index < floor_rule->dsp_ids_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->dsp_ids(index);
				}
				cerr << "]";
				break;

			case BUYER_ID:
				cerr << " ,buyer_ids:[";
				for (index = 0; index < floor_rule->buyer_ids_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->buyer_ids(index);
				}
				cerr << "]";
				break;

			case ADVERTISER_ID:
				cerr << " Advertiser_id rule exist";
				break;

			case DOMAIN_ID:
				cerr << "domain_ids rule exist";
				break;

			case SEGMENT_ID:
				fprintf(stderr, " ,segments:[");
				for (index = 0; index < floor_rule->segments_size(); index++)
				{
					cerr << ((index == 0)? "": ", ") << floor_rule->segments(index);
				}
				cerr << "]";
				break;

			case GEO_COUNTRY_CODE:
				cerr << " ,country_codes:[";
				for (index = 0; index < floor_rule->country_codes_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->country_codes(index);
				}
				cerr << "]";
				break;

			case GEO_REGION_CODE:
				cerr << " ,region_codes:[";
				for (index = 0; index < floor_rule->region_codes_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ")<< floor_rule->region_codes(index);
				}
				cerr << "]";
				break;

			case GEO_CITY_NAME:
				cerr << " ,city_names:[";
				for (index = 0; index < floor_rule->city_names_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->city_names(index);
				}
				cerr << "]";
				break;

			case GEO_DMA_CODE:
				cerr << " ,dma_codes:[";
				for (index = 0; index < floor_rule->dma_codes_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->dma_codes(index);
				}
				cerr << "]";
				break;

			case TIME_PARTING:
				//Not applicable
				break;

			case DAY_PARTING:
				//Not applicable
				break;

			case AD_SIZE:
				cerr << " ,ad_size_ids:[";
				for (index = 0; index < floor_rule->ad_size_ids_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->ad_size_ids(index);
				}
				cerr << "]";
				break;

			case FOLD_POS:
				cerr << " ,fold_position_ids:[";
				for (index = 0; index < floor_rule->fold_position_ids_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->fold_position_ids(index);
				}
				cerr << "]";
				break;

			case ADVERTISER_CATEGORIES:
				cerr << "advertiser_category_id exist";
				break;

			case SITE_SECTION:
				cerr << " ,site_sections:[";
				for (index = 0; index < floor_rule->site_sections_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->site_sections(index);
				}
				cerr << "]";
				break;

			case CMPG_ID:
				cerr << " ,campaign_ids:[";
				for (index = 0; index < floor_rule->campaign_ids_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->campaign_ids(index);
				}
				cerr << "]";
				break;

			case DEAL_ID:
				cerr << " ,deal_meta_ids: [";
				for (index = 0; index < floor_rule->deal_meta_id_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->deal_meta_id(index);
				}
				cerr << "]";
				break;

			case RM_CREATIVE_ID:
				cerr << " ,rich_media_creative_attribute_id:[";
				for (index = 0; index < floor_rule->rich_media_creative_attribute_ids_size(); index++)
				{
					cerr << ((index == 0)? " ": ", ") << floor_rule->rich_media_creative_attribute_ids(index);
				}
				cerr << "]";
				break;

			case LINE_ITEM_ID:
				cerr << " ,line_item_id:[";
				for (index = 0; index < floor_rule->line_item_ids_size() ; index++) {
					cerr << ((index == 0)? " ": ", ") << floor_rule->line_item_ids(index);
				}
				cerr  << "]";
				break;
		}
	}
	cerr << " ,active_entities_array: [";
	for (index = 0; index < floor_rule->active_entities_array_size(); index++)
	{
		cerr << ((index == 0)? " ": ", ") << floor_rule->active_entities_array(index);
	}
	cerr << "]" << endl;
	cerr << "================================== END " << __FUNCTION__
		 << " ===================================" << endl;
}

extern "C" void dump_floor_rules(void *floior_rules_protobuff_ctxt, const char *fn, int ln)
{
	publisher_site_floor_rules *floor_rules = (publisher_site_floor_rules *) floior_rules_protobuff_ctxt;
	int index = 0;

	if (floor_rules == NULL)
	{
		return;
	}

	for (index = 0; index < floor_rules->floor_rules_size(); index++)
	{
		dump_floor_rule(floor_rules->mutable_floor_rules(index), fn, ln);
	}
}
#endif //PMP_FLOOR_RULES_FUNCTIONAL_TESTING


