#include <assert.h>
#include <stdio.h>
#include <stddef.h>
#include "error.h"
#include "db_error.h"
#include "db_constants.h"
#include "floor_rules_types.h"
extern "C" {
#include "audience_targeting_util.h"
#include "time_parting.h"
#include "day_parting.h"
#include "bloom_filter.h"
#include "floor_rule_bloom.h"
#include <setjmp.h>
#include <cmocka.h>
}
#include "common_constants.h"
#include "advertiser_domain_buyer_rule_entities.h"
#include "get_user_segments.h"
#include "cache_publisher_site_floor_rules.h"
#include "cache_advertiser_domain_category_mapping.h"
#include "deal_util.h"
#include "publisher_site_floor_rules.pb.h"
#include "floor_rule_engine.h"
#include "fte_types.h"

using namespace floor_rules;
int gbl_log_level;


extern "C"{
	int __wrap_stats_add() {
		return 0;
	}

	int __wrap_compare_with_reduced_floor(){
		return 1;
	}	

	void __wrap_elog(){
	}
	int __wrap_substring_multi_concat_bloom_search(){
		return 1;
	}
	int __wrap_evaluate_audience_user_segments(){
		return 1;
	}	
	int __wrap_do_time_parting(){
		return 1;
	}
	int __wrap_do_day_parting(){
		return 1;
	}	
}

/*Campaign with dsp bid response that gets evaluated and becomes applicable and deal ecpm is less than floor ecpm so the campaign settings should be populated with floor rule settings*/
static void test_deal_eval_ecmp_less_than_rule(void **state){
	if (state == NULL)
	{
		abort();
	}	
	int j=0;   
	publisher_site_floor_rules *floor_rules  = NULL;
	publisher_site_floor_rule *floor_rule  = NULL;
	int active_entity = 0;
	ad_server_req_param_t in_req_params ;
	fte_additional_params_t fte_additional_parameters;
	publisher_site_ad_campaign_list_t adcampaigns[2];
	rt_response_params_t rt_response_params[2];
	int ncampaigns = 2;
	fte_additional_parameters.in_server_req_params = &in_req_params;
	int ret_val =0;

	//Allocate Floor rules protobuff object if not already allocated.
	if (floor_rules == NULL)
	{
		floor_rules = new publisher_site_floor_rules();
		if (floor_rules == NULL)
		{
			abort();
		}
		floor_rule = floor_rules->add_floor_rules();
		if (floor_rule == NULL)
		{
			delete floor_rules;
			abort() ;
		}
	}
	//Create a deal floor rule
	floor_rule->set_pub_id(156517);
	floor_rule->set_site_id(24826);
	floor_rule->set_rule_id(RULE_DEFAULT);
	floor_rule->set_rule_type(RULE_RTB);
	floor_rule->set_floor_type(HARD_FLOOR);
	floor_rule->set_priority(1);
	//floor_rule->set_fixed_price_flag(db_row->s_fixed_price_flag);
	floor_rule->set_floor_ecpm(5);
	floor_rule->set_min_floor_ecpm(0);
	floor_rule->set_rule_meta_id(2512238);
	floor_rule->set_currency_id(1);
	floor_rule->set_applicability(0);
	//Copy active entities array.
	floor_rule->add_active_entities_array(active_entity);

	MULTI_BLOOM floor_bloom[MAX_FLOOR_BLOOM_ACTIVE_ENTITY_SIZE];

	memset(floor_bloom, 0, sizeof(MULTI_BLOOM)*MAX_FLOOR_BLOOM_ACTIVE_ENTITY_SIZE);

	currency_xrate_map_t test_currency_xrate_map[2];
	test_currency_xrate_map[0].currency_id = 1;
	test_currency_xrate_map[0].precision_rate = 1.0;
	test_currency_xrate_map[0].inverse_rate = 1.0;
	strncpy(test_currency_xrate_map[0].currency_code,"USD", MAX_CURRENCY_CODE_SIZE);

	test_currency_xrate_map[1].currency_id = 1;
	test_currency_xrate_map[1].precision_rate = 1.0;
	test_currency_xrate_map[1].inverse_rate = 1.0;
	strncpy(test_currency_xrate_map[1].currency_code,"USD", MAX_CURRENCY_CODE_SIZE);

	fte_additional_parameters.currency_xrate_map = test_currency_xrate_map;
	fte_additional_parameters.currency_count =2;

	for(j =0; j<2; j++){
		adcampaigns[j].campaign_id = j;
		adcampaigns[j].realtime_flag=1;
		adcampaigns[j].ad_campaign_list_setings = (ad_campaign_list_setings_t *)malloc(sizeof(ad_campaign_list_setings_t));
		adcampaigns[j].ad_campaign_list_setings->reason_for_filtering = 0;
		adcampaigns[j].ad_campaign_list_setings->filtered_flag = 0;
		adcampaigns[j].ad_campaign_list_setings->rtb_campaign_response_index=j;
		adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal=(dsp_buyer_t*)malloc(sizeof(dsp_buyer_t));
		//Configure Deal ECPM and Priority
		adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->deal_pub.deal_ecpm_usd=2.0;
		adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->deal_pub.priority=10;
		adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params = (struct deal_params *)malloc(sizeof(struct deal_params));
		adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_meta_id = 223456;			
		adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_level_feature_flag = 1;			

		//Set RT Response param settings per campaign
		rt_response_params[j].campaign_index = j;
		rt_response_params[j].campaign_id = adcampaigns[j].campaign_id;
		//Set the default floor settings in campaign
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority = 15;
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm = 4 ;
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id =  RULE_DEFAULT;
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_type = HARD_FLOOR;
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor = 0;
	}

	//Call the apply floor function
	ret_val = apply_floor_rules_filter(
			adcampaigns,
			ncampaigns,
			rt_response_params,
			floor_rules,
			&in_req_params,
			&fte_additional_parameters,
			NULL,
			NULL, 
			floor_bloom,
			NULL); 
	//Chedk if the function returns success
	assert_int_equal(ret_val, ADS_ERROR_SUCCESS);

	//Check if campaign floor settings are not overridden as no settings should be applied
	for(j=0; j<2; j++){
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->filtered_flag, 0);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority, 1);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm, 5);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id, RULE_DEFAULT);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_type, HARD_FLOOR);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor, 0);

	}

	//Free up dynamic memory
	for(j=0; j<2; j++){
		free(adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params);
		free(adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal);
		free(adcampaigns[j].ad_campaign_list_setings);
		//free(rt_response_params[j].ad_dimensions_from_tag);
	}
	delete floor_rules;
}

/*Tests a scenario where there is a single deal rule in rule engine and two RTB campaigns 
Both the campiagns should get skipped for rule evaulation and have the original floor settings.*/ 
static void test_deal_skip(void **state){
	if (state == NULL)
	{
		abort();
	}	
	int j=0;   
	publisher_site_floor_rules *floor_rules  = NULL;
	publisher_site_floor_rule *floor_rule  = NULL;
	int active_entity = 0;
	ad_server_req_param_t in_req_params ;
	fte_additional_params_t fte_additional_parameters;
	publisher_site_ad_campaign_list_t adcampaigns[2];
	rt_response_params_t rt_response_params[2];
	int ncampaigns = 2;
	fte_additional_parameters.in_server_req_params = &in_req_params;
	int ret_val =0;

	//Allocate Floor rules protobuff object if not already allocated.
	if (floor_rules == NULL)
	{
		floor_rules = new publisher_site_floor_rules();
		if (floor_rules == NULL)
		{
			abort();
		}
		floor_rule = floor_rules->add_floor_rules();
		if (floor_rule == NULL)
		{
			delete floor_rules;
			abort() ;
		}
	}
	//Create a deal floor rule
	floor_rule->set_pub_id(156517);
	floor_rule->set_site_id(24826);
	floor_rule->set_rule_id(RULE_DEFAULT);
	floor_rule->set_rule_type(RULE_DEAL);
	floor_rule->set_floor_type(HARD_FLOOR);
	floor_rule->set_priority(11);
	floor_rule->set_floor_ecpm(5);
	floor_rule->set_min_floor_ecpm(0);
	floor_rule->set_rule_meta_id(2512238);
	floor_rule->set_currency_id(1);
	floor_rule->set_applicability(0);
	//Copy active entities array.
	floor_rule->add_active_entities_array(active_entity);

	MULTI_BLOOM floor_bloom[MAX_FLOOR_BLOOM_ACTIVE_ENTITY_SIZE];

	memset(floor_bloom, 0, sizeof(MULTI_BLOOM)*MAX_FLOOR_BLOOM_ACTIVE_ENTITY_SIZE);

	currency_xrate_map_t test_currency_xrate_map[2];
	test_currency_xrate_map[0].currency_id = 1;
	test_currency_xrate_map[0].precision_rate = 1.0;
	test_currency_xrate_map[0].inverse_rate = 1.0;
	strncpy(test_currency_xrate_map[0].currency_code,"USD", MAX_CURRENCY_CODE_SIZE);

	test_currency_xrate_map[1].currency_id = 1;
	test_currency_xrate_map[1].precision_rate = 1.0;
	test_currency_xrate_map[1].inverse_rate = 1.0;
	strncpy(test_currency_xrate_map[1].currency_code,"USD", MAX_CURRENCY_CODE_SIZE);

	fte_additional_parameters.currency_xrate_map = test_currency_xrate_map;
	fte_additional_parameters.currency_count =2;

	for(j =0; j<2; j++){
		adcampaigns[j].campaign_id = j;
		adcampaigns[j].realtime_flag=1;
		adcampaigns[j].ad_campaign_list_setings = (ad_campaign_list_setings_t *)malloc(sizeof(ad_campaign_list_setings_t));
		adcampaigns[j].ad_campaign_list_setings->reason_for_filtering = 0;
		adcampaigns[j].ad_campaign_list_setings->filtered_flag = 0;
		adcampaigns[j].ad_campaign_list_setings->rtb_campaign_response_index=j;
		adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal=(dsp_buyer_t*)malloc(sizeof(dsp_buyer_t));
		//Configure Deal ECPM and Priority
		adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->deal_pub.deal_ecpm_usd=2.0;
		adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->deal_pub.priority=10;
	        adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params = (struct deal_params *)malloc(sizeof(struct deal_params));

		//Set RT Response param settings per campaign
		rt_response_params[j].campaign_index = j;
		rt_response_params[j].campaign_id = adcampaigns[j].campaign_id;
		rt_response_params[j].bid_response_params.bid_id=0;
		//Set the default floor settings in campaign
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority = 15;
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm = 4 ;
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id =  RULE_DEFAULT;
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type = AUCTION_TYPE_FIRST_PRICE;
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_type = HARD_FLOOR;
		adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor = 0;
	}

	//Call the apply floor function
	ret_val = apply_floor_rules_filter(
			adcampaigns,
			ncampaigns,
			rt_response_params,
			floor_rules,
			&in_req_params,
			&fte_additional_parameters,
			NULL,
			NULL, 
			floor_bloom,
			NULL); 
	//Chedk if the function returns success
	assert_int_equal(ret_val, ADS_ERROR_SUCCESS);

	//Check if campaign floor settings are not overridden as no settings should be applied
	for(j=0; j<2; j++){
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->filtered_flag, 0);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority, 15);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm, 4);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id, RULE_DEFAULT);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type, AUCTION_TYPE_FIRST_PRICE);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_type, HARD_FLOOR);
		assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor, 0);

	}

	//Free up dynamic memory
	for(j=0; j<2; j++){
		free(adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params);
		free(adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal);
		free(adcampaigns[j].ad_campaign_list_setings);
	}

	delete floor_rules;
}

/*Tests a campaign with dsp bid response that has deal targeting and  gets filtered out as applicable rule has different deal targeting*/
static void test_filter_campaign(void **state){
	if (state == NULL)
	{
		abort();
	}	
	int j=0;   
	publisher_site_floor_rules *floor_rules  = NULL;
	publisher_site_floor_rule *floor_rule  = NULL;
	int active_entity = DEAL_ID;
	ad_server_req_param_t in_req_params ;
	fte_additional_params_t fte_additional_parameters;
	publisher_site_ad_campaign_list_t adcampaigns[2];
	rt_response_params_t rt_response_params[2];
	int ncampaigns = 1;
	fte_additional_parameters.in_server_req_params = &in_req_params;
	int ret_val =0;

	//Allocate Floor rules protobuff object if not already allocated.
	if (floor_rules == NULL)
	{
		floor_rules = new publisher_site_floor_rules();
		if (floor_rules == NULL)
		{
			abort();
		}
		floor_rule = floor_rules->add_floor_rules();
		if (floor_rule == NULL)
		{
			delete floor_rules;
			abort() ;
		}
	}
	//Create a deal floor rule
	floor_rule->set_pub_id(156517);
	floor_rule->set_site_id(24826);
	floor_rule->set_rule_id(RULE_DEFAULT);
	floor_rule->set_rule_type(RULE_RTB);
	floor_rule->set_floor_type(HARD_FLOOR);
	floor_rule->set_priority(1);
	floor_rule->set_floor_ecpm(5);
	floor_rule->set_min_floor_ecpm(0);
	floor_rule->set_rule_meta_id(2512238);
	floor_rule->add_deal_meta_id(2512238);
	floor_rule->set_currency_id(1);
	floor_rule->set_applicability(0);
	//Copy active entities array.
	floor_rule->add_active_entities_array(active_entity);

	MULTI_BLOOM floor_bloom[MAX_FLOOR_BLOOM_ACTIVE_ENTITY_SIZE];

	memset(floor_bloom, 0, sizeof(MULTI_BLOOM)*MAX_FLOOR_BLOOM_ACTIVE_ENTITY_SIZE);

	currency_xrate_map_t test_currency_xrate_map[2];
	test_currency_xrate_map[0].currency_id = 1;
	test_currency_xrate_map[0].precision_rate = 1.0;
	test_currency_xrate_map[0].inverse_rate = 1.0;
	strncpy(test_currency_xrate_map[0].currency_code,"USD", MAX_CURRENCY_CODE_SIZE);

	test_currency_xrate_map[1].currency_id = 1;
	test_currency_xrate_map[1].precision_rate = 1.0;
	test_currency_xrate_map[1].inverse_rate = 1.0;
	strncpy(test_currency_xrate_map[1].currency_code,"USD", MAX_CURRENCY_CODE_SIZE);

	fte_additional_parameters.currency_xrate_map = test_currency_xrate_map;
	fte_additional_parameters.currency_count =2;

	adcampaigns[0].campaign_id = 0;
	adcampaigns[0].realtime_flag=1;
	adcampaigns[0].campaign_price=10;
	adcampaigns[0].ad_campaign_list_setings = (ad_campaign_list_setings_t *)malloc(sizeof(ad_campaign_list_setings_t));
	adcampaigns[0].ad_campaign_list_setings->reason_for_filtering = 0;
	adcampaigns[0].ad_campaign_list_setings->filtered_flag = 0;
	adcampaigns[0].ad_campaign_list_setings->rtb_campaign_response_index=0;
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal=(dsp_buyer_t*)malloc(sizeof(dsp_buyer_t));
	//Configure Deal ECPM and Priority
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->deal_pub.deal_ecpm_usd=2.0;
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->deal_pub.priority=10;
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params = (struct deal_params *)malloc(sizeof(struct deal_params));
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_meta_id = 223456;			
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_level_feature_flag = 1;			

	//Set RT Response param settings per campaign
	rt_response_params[0].campaign_index = 0;
	rt_response_params[0].campaign_id = adcampaigns[0].campaign_id;

	//Set the default floor settings in campaign
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority = 12;
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm = 5 ;
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id =  RULE_DEFAULT;
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type = AUCTION_TYPE_FIRST_PRICE;
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_type = HARD_FLOOR;
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor = 0;

	//Call the apply floor function
	ret_val = apply_floor_rules_filter(
			adcampaigns,
			ncampaigns,
			rt_response_params,
			floor_rules,
			&in_req_params,
			&fte_additional_parameters,
			NULL,
			NULL, 
			floor_bloom,
			NULL); 
	//Chedk if the function returns success
	assert_int_equal(ret_val, ADS_ERROR_SUCCESS);

	//Check if campaign floor settings are not overridden as no settings should be applied since
	//campaign should be filtered out
	assert_int_equal(adcampaigns[j].ad_campaign_list_setings->filtered_flag, 0);
	assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority, 12);
	assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm, 5);
	assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id, RULE_DEFAULT);
	assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type, AUCTION_TYPE_FIRST_PRICE);
	assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.floor_type, HARD_FLOOR);
	assert_int_equal(adcampaigns[j].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor, 0);


	//Free up dynamic memory
	free(adcampaigns[0].ad_campaign_list_setings);
	free(adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal);
	free(adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params);

	delete floor_rules;
}

/*Tests the case where two campaigns both have dsp bid response and one of them has deal priority greater than
floor rule priority(only one rule is configured) and other has lower priority. Thus the deal with lower priority should get evaluated and one with higher priority should not and floor settings in campaign should
reflect the same.*/
static void test_deal_with_dsp_bid(void **state){
	if (state == NULL)
	{
		abort();
	}	
	publisher_site_floor_rules *floor_rules  = NULL;

	publisher_site_floor_rule *floor_rule  = NULL;
	int active_entity = 0;
	ad_server_req_param_t in_req_params ;
	fte_additional_params_t fte_additional_parameters;
	publisher_site_ad_campaign_list_t adcampaigns[2];
	rt_response_params_t rt_response_params[2];
	int ncampaigns = 2;
	fte_additional_parameters.in_server_req_params = &in_req_params;
	int ret_val =0;
	int j=0;

	//Allocate Floor rules protobuff object if not already allocated.
	if (floor_rules == NULL)
	{
		floor_rules = new publisher_site_floor_rules();
		if (floor_rules == NULL)
		{
			abort();
		}
		floor_rule = floor_rules->add_floor_rules();
		if (floor_rule == NULL)
		{
			delete floor_rules;
			abort() ;
		}
	}
	//Create a deal floor rule with priority <= deal priority
	floor_rule->set_pub_id(156517);
	floor_rule->set_site_id(24826);
	floor_rule->set_rule_id(RULE_DEFAULT);
	floor_rule->set_rule_type(RULE_RTB);
	floor_rule->set_floor_type(HARD_FLOOR);
	floor_rule->set_priority(10);
	floor_rule->set_floor_ecpm(5);
	floor_rule->set_min_floor_ecpm(0);
	floor_rule->set_rule_meta_id(2512238);
	floor_rule->set_currency_id(1);
	floor_rule->set_applicability(0);
	//Copy active entities array.
	floor_rule->add_active_entities_array(active_entity);

	MULTI_BLOOM floor_bloom[MAX_FLOOR_BLOOM_ACTIVE_ENTITY_SIZE];

	memset(floor_bloom, 0, sizeof(MULTI_BLOOM)*MAX_FLOOR_BLOOM_ACTIVE_ENTITY_SIZE);

	currency_xrate_map_t test_currency_xrate_map[2];
	test_currency_xrate_map[0].currency_id = 1;
	test_currency_xrate_map[0].precision_rate = 1.0;
	test_currency_xrate_map[0].inverse_rate = 1.0;
	strncpy(test_currency_xrate_map[0].currency_code,"USD", MAX_CURRENCY_CODE_SIZE);

	test_currency_xrate_map[1].currency_id = 1;
	test_currency_xrate_map[1].precision_rate = 1.0;
	test_currency_xrate_map[1].inverse_rate = 1.0;
	strncpy(test_currency_xrate_map[1].currency_code,"USD", MAX_CURRENCY_CODE_SIZE);

	fte_additional_parameters.currency_xrate_map = test_currency_xrate_map;
	fte_additional_parameters.currency_count =2;

	adcampaigns[0].campaign_id = 0;
	adcampaigns[0].realtime_flag=1;
	adcampaigns[0].campaign_price=9;

	adcampaigns[0].ad_campaign_list_setings = (ad_campaign_list_setings_t *)malloc(sizeof(ad_campaign_list_setings_t));
	adcampaigns[0].ad_campaign_list_setings->reason_for_filtering = 0;
	adcampaigns[0].ad_campaign_list_setings->filtered_flag = 0;
	adcampaigns[0].ad_campaign_list_setings->rtb_campaign_response_index=0;
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal=(dsp_buyer_t*)malloc(sizeof(dsp_buyer_t));
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params = (struct deal_params *)malloc(sizeof(struct deal_params));
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_meta_id = 23456;			
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_level_feature_flag = 1;			
	//Configure Deal ECPM and Priority
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->deal_pub.deal_ecpm_usd=7.0;
	adcampaigns[0].ad_campaign_list_setings->dsp_interested_deal->deal_pub.priority=8;

	//Set RT Response param settings per campaign
	rt_response_params[0].campaign_index = 0;
	rt_response_params[0].campaign_id = adcampaigns[0].campaign_id;
	//Set the default floor settings in campaign
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority = 14;
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm = 2 ;
	//adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id =  RULE_DEFAULT;
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id =  23456;
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_type = HARD_FLOOR;
	adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor = 0;

	//Campaign with priority
	adcampaigns[1].campaign_id = 1;
	adcampaigns[1].realtime_flag=1;
	adcampaigns[1].campaign_price=9;

	adcampaigns[1].ad_campaign_list_setings = (ad_campaign_list_setings_t *)malloc(sizeof(ad_campaign_list_setings_t));
	adcampaigns[1].ad_campaign_list_setings->reason_for_filtering = 0;
	adcampaigns[1].ad_campaign_list_setings->filtered_flag = 0;
	adcampaigns[1].ad_campaign_list_setings->rtb_campaign_response_index=1;
	adcampaigns[1].ad_campaign_list_setings->dsp_interested_deal=(dsp_buyer_t*)malloc(sizeof(dsp_buyer_t));
	adcampaigns[1].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params = (struct deal_params *)malloc(sizeof(struct deal_params));
	adcampaigns[1].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_meta_id = 12345;			
	adcampaigns[1].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_level_feature_flag = 1;			
	//Configure Deal ECPM and Priority
	adcampaigns[1].ad_campaign_list_setings->dsp_interested_deal->deal_pub.deal_ecpm_usd=6.0;
	adcampaigns[1].ad_campaign_list_setings->dsp_interested_deal->deal_pub.priority=12;
	adcampaigns[1].ad_campaign_list_setings->dsp_interested_deal->deal_pub.auction_id=AUCTION_TYPE_FIRST_PRICE;

	//Set RT Response param settings per campaign
	rt_response_params[1].campaign_index = 1 ;
	rt_response_params[1].campaign_id = adcampaigns[1].campaign_id;
	//Set the default floor settings in campaign
	//adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority = 14;
	adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority = 9;
	adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm = 2 ;
	//adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id =  RULE_DEFAULT;
	adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id =  12345;
	adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type = AUCTION_TYPE_FIRST_PRICE;
	adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_type = HARD_FLOOR;
	adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor = 0;
	//Call the apply floor function
	ret_val = apply_floor_rules_filter(
			adcampaigns,
			ncampaigns,
			rt_response_params,
			floor_rules,
			&in_req_params,
			&fte_additional_parameters,
			NULL,
			NULL, 
			floor_bloom,
			NULL); 
	//Chedk if the function returns success
	assert_int_equal(ret_val, ADS_ERROR_SUCCESS);

	assert_int_equal(adcampaigns[0].ad_campaign_list_setings->filtered_flag, 0);
	assert_int_equal(adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority, 10);
	assert_int_equal(adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm, 5);
	assert_int_equal(adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id, RULE_DEFAULT);
	assert_int_equal(adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.floor_type, HARD_FLOOR);
	assert_int_equal(adcampaigns[0].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor, 0);

	assert_int_equal(adcampaigns[1].ad_campaign_list_setings->filtered_flag, 0);
	assert_int_equal(adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_priority, 9);
	assert_int_equal(adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_max_ecpm, 2);
	assert_int_equal(adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_id, 12345);
	assert_int_equal(adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type, AUCTION_TYPE_FIRST_PRICE);
	assert_int_equal(adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.floor_type, HARD_FLOOR);
	assert_int_equal(adcampaigns[1].ad_campaign_list_setings->applied_floor_rules_settings.guide_floor, 0);
	//Free up dynamic memory
	for(j=0; j<2; j++){
		free(adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params);
		free(adcampaigns[j].ad_campaign_list_setings->dsp_interested_deal);
		free(adcampaigns[j].ad_campaign_list_setings);
	}

	delete floor_rules;
}

int main(){
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_deal_skip),
		cmocka_unit_test(test_deal_with_dsp_bid),
		cmocka_unit_test(test_filter_campaign),
		cmocka_unit_test(test_deal_eval_ecmp_less_than_rule)

	};
	return cmocka_run_group_tests(tests, NULL, NULL);
}
