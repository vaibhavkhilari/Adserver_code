/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include "db_connection.h"
#include "cache_types.h"
#include "rt_types.h"
#include "advertiser_domain_buyer_rule_entities.h"
#include "cache_advertiser_domain.h"
#include "cache_dsp_buyer.h"
#include "error.h"
#include "crc32_util.h"

#define CATEGORY_ALLOC_COUNT 5 
/*
 * Don't use tolower() in the standard library as its behaviours is dependent upon current locale, 
 * this function's behaviours is consistent to (remember EBCDIC).
 * 
 */

#if 0
static char toLower(char in)
{
	switch(in) {
		case 'A':
			return 'a';
		case 'B':
			return 'b';
		case 'C':
			return 'c';
		case 'D':
			return 'd';
		case 'E':
			return 'e';
		case 'F':
			return 'f';
		case 'G':
			return 'g';
		case 'H':
			return 'h';
		case 'I':
			return 'i';
		case 'J':
			return 'j';
		case 'K':
			return 'k';
		case 'L':
			return 'l';
		case 'M':
			return 'm';
		case 'N':
			return 'n';
		case 'O':
			return 'o';
		case 'P':
			return 'p';
		case 'Q':
			return 'q';
		case 'R':
			return 'r';
		case 'S':
			return 's';
		case 'T':
			return 't';
		case 'U':
			return 'u';
		case 'V':
			return 'v';
		case 'W':
			return 'w';
		case 'X':
			return 'x';
		case 'Y':
			return 'y';
		case 'Z':
			return 'z';
	}
	return in;
}
#endif


/*static void swap(
		char* a,
		char* b
		)
{
	char temp;
	temp = *a;
	*a = *b;
	*b = temp;
}*/
// Above function is inlined
#define swap(a, b) \
	do { \
		char temp = a; \
		a = b; \
		b = temp; \
	} while(0);


// Uncomment this if you want to avoid a function call overhead(ofcourse, at the expense of debugging time)
#if 0
#define reverse_string(str, left, right) \
	do { \
		while (left < right) { \
			swap(str[left], str[right]); \
			left++; \
			right--; \
		} \
	} while(0);
#endif

/*static void reverse_string(
		char* str,
		int left,
		int right
		)
{
	while (left < right) {
		//swap(&str[left], &str[right]);
		swap(str[left], str[right]);
		left++;
		right--;
	}
}*/

int char_counter(const char* str, char c);

static int binary_search(
		const char* needle,
		const advertiser_domain_id_t* haystack,
		int left,
		int right
		)
{
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "needle = %s %s:%d\n", needle, __FILE__, __LINE__);
#endif
	int middle, tmp_middle;
	unsigned int crc_32_needle = calculate_crc ((unsigned char *)needle, strlen(needle));

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
        llog_write(L_DEBUG, "crc32 of needle = %u\n", crc_32_needle);
#endif

	while (left <= right) {
		middle = (left + right)/2;
	//	result = strcmp(needle, haystack[middle].domain); 
		if (crc_32_needle < haystack[middle].crc_32) {
			right = middle - 1;
		} else if (crc_32_needle > haystack[middle].crc_32) {
			left = middle + 1;
		} else {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
			llog_write(L_DEBUG, "\nBSearch CRC match, needle = %s, crc_32_needle = %u, %s:%d\n", needle,  crc_32_needle, __FILE__, __LINE__);
#endif
			//	return middle;
			/* CrC match occurred, Now validate the domain name by traversing up and down until the domain_name matches */
//TODO include a check here of the domain_name before the while loop

			/* Check if we hit at the right place ? then return */
			if (!(strncmp(needle, haystack[middle].domain, strlen(haystack[middle].domain)))) {	
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				llog_write(L_DEBUG, "Both CRC: %u and domain_name : %s\n", crc_32_needle, needle);
#endif
				return middle;
			}
				
			tmp_middle = middle;
			/* Check upwards first */

			while (tmp_middle >= left && crc_32_needle == haystack[tmp_middle].crc_32) {
				//haystack[tmp_middle].domain will always be lesser than or equal to needle as left(string,n) returns the leftmost n bytes or less than n bytes depending on the length of the string.
				if (!(strncmp(needle, haystack[tmp_middle].domain, strlen(haystack[tmp_middle].domain)))) {
					/* Found the Match */
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                        		llog_write(L_DEBUG, "Both CRC: %u and domain_name : %s\n", crc_32_needle, needle);
#endif
					return tmp_middle;
				}					
				tmp_middle--;
			}

			middle += 1; /* Since We have already covered the middle case */
			/* Unfortunatly we couldnt find it upwards so find it till the right(downwards) */
			while (middle <= right && crc_32_needle == haystack[middle].crc_32) {
				if (!(strncmp(needle, haystack[middle].domain, strlen(haystack[middle].domain)))) {
					/* Found the Match */
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                                        llog_write(L_DEBUG, "Both CRC: %u and domain_name: %s\n", crc_32_needle, needle);
#endif
					return middle;
				}
				middle++;
			}

			/* if we reached here that means that the crc matched but the domain name did not match. Hope We NEVER REACH HERE!  */
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                        llog_write(L_DEBUG, "\nINFO: CRC matched but URL did not match\n");
#endif
			return	-1;
		}				
	}
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
        llog_write(L_DEBUG, "\nNot Found the CRC\n");
	llog_write(L_DEBUG, "\nBSearch CRC NOT match, needle = %s, crc_32_needle = %u, %s:%d\n",needle,crc_32_needle, __FILE__,__LINE__);
#endif
	return -1;
}

static int substring_binary_search(
		char* processing_string,
		const advertiser_domain_id_t* ad_domain_list,
		int left,
		int right
		)
{
	int subdomain_levels = 0;
	int index = -1;
	int i;
	char subdomain_delimiter = '.';

	subdomain_levels = char_counter(processing_string, subdomain_delimiter);

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "\nRTB response TLD = %s, subdomain_levels = %d %s:%d\n", processing_string, subdomain_levels, __FILE__, __LINE__);
#endif
	// for a.b.c.com, we want to search for a.b.c.com, b.c.com and c.com

	for (i=1; i<=subdomain_levels; i++) {
		index = binary_search(processing_string, ad_domain_list, left, right);
		if (index != -1 || i == subdomain_levels) {
			// We have found the domain or we have made all the searches
			break;
		}
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "\nMatch didn't happen. Searching for parent TLD %s:%d\n", __FILE__, __LINE__);
#endif
		// Above ensures that strchr will never return NULL
		processing_string = strchr(processing_string, subdomain_delimiter);
		processing_string++;
	}
	return index;
}



static inline int binary_search_dsp_buyer(
		int nee,
		/* wow these 2 make a nee-dle, any comments about my intuitive name convention? Huh!*/
		int dle,
		const rt_dsp_buyer_map_t* haystack,
		int left,
		int right
		)
{
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "nee = %d and dle = %d %s:%d\n", nee, dle, __FILE__, __LINE__);
#endif
	int middle;
	while (left <= right) {
		middle = (left + right)/2;
		if (haystack[middle].dsp_id == nee) {
			// we got the dsp_id match, now let's find dsp_buyer_id
			// check your pants first
			if(haystack[middle].dsp_buyer_id == dle) {
				// Yaay!!! got it
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				llog_write(L_DEBUG, "BSearch match, nee = %d, dle  = %d  match = %d, %d %d %s:%d\n", nee, dle, haystack[middle].dsp_id, haystack[middle].dsp_buyer_id, haystack[middle].buyer_id, __FILE__, __LINE__);
#endif
				return middle;
			} else if(dle < haystack[middle].dsp_buyer_id) {
				// go left baby
				right = middle - 1;
			} else {
				// go right dolt
				left = middle + 1;
			}
		} else if(nee < haystack[middle].dsp_id) {
			// go left baby
			right = middle - 1;
		} else {
			// go right dolt
			left = middle + 1;
		}
	}
	return -1;
}
// TODO Discuss the error return from this function, in that case, all the rules having an
// entry for advertiser_id or domain_id will not "match" to any of the bid responses even
// though it might be matching, so we will end up skipping those rules

static inline int bin_search_advertiser_id (advertiser_domain_category_id_t *ad_domain_category_id_list, int ncategory, int advertiser_id) {
        int low = 0;
        int high = ncategory - 1; /* ncategory is the count */
        int mid;
        int index = -1;

        while (low <= high) {
                mid = (low + high)/2;
                if (ad_domain_category_id_list [mid].advertiser_id == advertiser_id) {
                        index = mid;
                        break;
                } else if (advertiser_id > ad_domain_category_id_list [mid].advertiser_id ) {
                        low = mid + 1;
                } else {
                        high = mid - 1;
                }
        }
        return index;
}


#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
void print_domain_advertiser_data(
 const advertiser_domain_id_t* ad_domain_id_list,
 int nelements
 )
{
	int i;
	for ( i = 0; i < nelements; i++) {
		fprintf(
				stderr,
				"%9d, %9d, %s %u\n",
				ad_domain_id_list[i].domain_id,
				ad_domain_id_list[i].advertiser_id,
				ad_domain_id_list[i].domain,
				ad_domain_id_list[i].crc_32
				);
	}
}
void print_dsp_buyer_data(
		rt_dsp_buyer_map_t* dsp_buyer_map,
		int nelements
		) 
{
	int i;
	for ( i = 0; i < nelements; i++ ) {
		fprintf(
				stderr,
				"%9d, %9d, %9d\n",
				dsp_buyer_map[i].dsp_id,
				dsp_buyer_map[i].dsp_buyer_id,
				dsp_buyer_map[i].buyer_id
				);
	}
}
#endif
int get_advertiser_and_domain_id(
		long pub_id,
		long site_id,
		db_connection_t* conn,
		cache_handle_t* cache,
		const publisher_site_ad_campaign_list_t* adcampaigns, 
		rt_response_params_t* response_params,
		int rt_response_count,
		advertiser_domain_category_id_t *ad_domain_category_id_list,
		int ncategory	
		)
{
	int i;
	int len = 0;
	advertiser_domain_id_t* ad_domain_id_list = NULL;
	int nelements = 0;
	int retval = 0;
	int index = -1;
	char processing_string[MAX_DOMAIN_NAME_LENGTH + 1];

	if (rt_response_count > 0) {
		// get the ad_domain_id_list
		retval = cache_get_advertiser_domain_id(pub_id, site_id, conn, cache, &ad_domain_id_list, &nelements);
		if (retval != ADS_ERROR_SUCCESS) {
			return retval;
		}
		/* since even on SUCCESS, ad_domain_id_list could be NULL */
		if (ad_domain_id_list != NULL) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
			llog_write(L_DEBUG, "Received a list of %d elements from cache or db for get_advertiser_and_domain_id() %s:%d\n", nelements, __FILE__, __LINE__);
#endif
			for (i = 0; i < rt_response_count; i++) {
				if (adcampaigns[response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag == 1) {
					continue;
				}
				strncpy(processing_string, response_params[i].bid_response_params.landing_page_tld, MAX_DOMAIN_NAME_LENGTH);
				processing_string[MAX_DOMAIN_NAME_LENGTH] = '\0';
				len = strlen(processing_string);
				if (len == 0) {
					// this dsp hasn't neither sent landing page url nor landing page tld
					// TODO should I log it?
					continue;
				}
				if (processing_string[len -1 ] == '/') {
					// Use Case :- www.google.com/
					processing_string[len - 1] = '\0';
					len = len - 1;
				}

				//reverse_string(processing_string, 0, len - 1);
				index = substring_binary_search(processing_string, ad_domain_id_list, 0, nelements - 1);
				if (index == -1) {
					// response domain not found in the list of domains
					// This is redundant but is there for code readablity
					response_params[i].bid_response_params.domain_id = 0;
					response_params[i].bid_response_params.advertiser_id = 0;
				} else {
					response_params[i].bid_response_params.domain_id = ad_domain_id_list[index].domain_id;
					response_params[i].bid_response_params.advertiser_id = ad_domain_id_list[index].advertiser_id;
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                        llog_write(L_DEBUG, "Found Advertiser_id: %d , Domain_id: %d %s:%d\n", ad_domain_id_list[index].advertiser_id, ad_domain_id_list[index].domain_id , __FILE__, __LINE__);
                        //print_dsp_buyer_data(dsp_buyer_map, nelements);
#endif
					/* This function gets all the categories belonging to this advertiser_id and domain_id */
					get_advertiser_categories(ad_domain_id_list[index].advertiser_id, ad_domain_id_list[index].domain_id, 
						&(response_params [i].bid_response_params), ad_domain_category_id_list, ncategory); 			
						
				}
			}
			free(ad_domain_id_list);
		}
	}
	return ADS_ERROR_SUCCESS;
}
// TODO Discuss the error return from this function, in that case, all the rules having an
// entry for a pubmatic_buyer_id not "match" to any of the bid responses even
// though it might be matching, so we will end up skipping those rules

int get_buyer_id(
		long pub_id,
		long site_id,
		db_connection_t* conn,
		cache_handle_t* cache,
		const publisher_site_ad_campaign_list_t* adcampaigns, 
		rt_response_params_t* response_params,
		int rt_response_count
		)
{
	int i;
	rt_dsp_buyer_map_t* dsp_buyer_map = NULL;
	int nelements = 0;
	int retval = 0;
	int index = -1;
	if (rt_response_count > 0) {
		// get the dsp_buyer_map
		retval = cache_get_dsp_buyer_map(pub_id, site_id, conn, cache, &dsp_buyer_map, &nelements);
		if (retval != ADS_ERROR_SUCCESS) {
			return retval;
		}
		// since even on SUCCESS, dsp_buyer_map could be NULL
		if (dsp_buyer_map != NULL) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
			llog_write(L_DEBUG, "Received a list of %d elements from cache or db for get_buyer_id() %s:%d\n", nelements, __FILE__, __LINE__);
			//print_dsp_buyer_data(dsp_buyer_map, nelements);
#endif
			for (i = 0; i < rt_response_count; i++) {
				if (adcampaigns[response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag == 1) {
					continue;
				}
				if (response_params[i].bid_response_params.dsp_buyer_id == DEFAULT_DSP_BUYER_ID) {
					// this dsp hasn't sent any buyer id info 
					// TODO should I log it?
					continue;
				}
				index = binary_search_dsp_buyer(response_params[i].dp_id, response_params[i].bid_response_params.dsp_buyer_id, dsp_buyer_map, 0, nelements - 1);
				if (index == -1) {
					// This is redundant but is there for code readablity
					response_params[i].bid_response_params.pubmatic_buyer_id = 0;
				} else {
					response_params[i].bid_response_params.pubmatic_buyer_id = dsp_buyer_map[index].buyer_id;
				}
			}
			free(dsp_buyer_map);
		}
	}
	return ADS_ERROR_SUCCESS;
}

/* This function searches for the categories corresponding to the advertiser_id and domain_id and populates the rt_response_params structure with the list of categories and its count. If no categories found, then it makes the list for that  response as NULL and the corresponding count as 0 */

int get_advertiser_categories (
	int advertiser_id, 
	int domain_id, 
	rt_bid_response_params_t *bid_response_params,
	advertiser_domain_category_id_t *ad_domain_category_id_list, 
	int ncategory
	) {

	/* This function does a two level search in advertiser_id and domain_id and makes a list of all the categories associated with it */

	/* Locals */
	int index = 0, tmp_index = 0; /* Stores the Index where we find advertiser_id. Why we need two? Read down... */
	int alloc_count = CATEGORY_ALLOC_COUNT;
	int *tmp_list = NULL;

	bid_response_params->advertiser_category_id.count = 0; /* At present there are no elements in the list */
	bid_response_params->advertiser_category_id.list = NULL;

	if (ad_domain_category_id_list == NULL){
		llog_write(L_DEBUG,"ERROR: Invalid argument FILE: %s, LINE: %d", __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;

	}

	if (ncategory == 1 && ad_domain_category_id_list->category_id == 0 && 
			ad_domain_category_id_list->domain_id == 0 && ad_domain_category_id_list->advertiser_id == 0){
		/* Its dumy entry so need to evaluate category list*/
			return ADS_ERROR_SUCCESS;
	}	
	/* Allocate some memory for the category list */
	bid_response_params->advertiser_category_id.list = malloc (sizeof(int) * alloc_count);
	if (bid_response_params->advertiser_category_id.list == NULL) {
		llog_write(L_DEBUG,"ERROR: insufficient memory FILE: %s, LINE: %d", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	/* Search the advertiser id first */
	index = bin_search_advertiser_id (ad_domain_category_id_list, ncategory, advertiser_id);
	if (index == -1) {
		llog_write(L_DEBUG, "INFO: Advertiser_id: %d Not present in the advertiser_domain_category_mapping\n", advertiser_id);
		if (bid_response_params->advertiser_category_id.list != NULL) {
			free (bid_response_params->advertiser_category_id.list);
			bid_response_params->advertiser_category_id.list = NULL;
		}
	} else { /* Advertiser-id was found */
		llog_write(L_DEBUG, "INFO: Advertiser_id: %d found in the list\n", advertiser_id);
		/* Now search for the corresponding equal domain_id and if this combination found, populate the category list */
		//  if (domain_id == ad_domain_category_id_list [index].domain_id) 
			/* save the index as we need to go both up the list as well as down the list */
			tmp_index = index;
			/* UP */
//validate index before checking the advertiser_id, domain_id
		 	while (tmp_index >= 0 && advertiser_id == ad_domain_category_id_list[tmp_index].advertiser_id && domain_id <= ad_domain_category_id_list [tmp_index].domain_id) {
				if (domain_id == ad_domain_category_id_list [tmp_index].domain_id) {
					/* Check the alloc size, realloc if necessary */
					if (bid_response_params->advertiser_category_id.count == alloc_count) {
						alloc_count += CATEGORY_ALLOC_COUNT;
						tmp_list = realloc (bid_response_params->advertiser_category_id.list, sizeof(int) * alloc_count);
						if (tmp_list == NULL) {
							free (bid_response_params->advertiser_category_id.list);
							bid_response_params->advertiser_category_id.list = NULL;
							llog_write(L_DEBUG,"ERROR: insufficient memory FILE: %s, LINE: %d", __FILE__, __LINE__);
							return ADS_ERROR_INTERNAL;
						}
						
						bid_response_params->advertiser_category_id.list = tmp_list;
					}
					bid_response_params->advertiser_category_id.list [bid_response_params->advertiser_category_id.count++] = ad_domain_category_id_list [tmp_index].category_id;
				}	
				tmp_index--;
			}
		/* Now search down */
// validate index before checking advertiser and domain to prevent invalid check at boundary condition
			index += 1; /* as we have already included the case with this index value. So to prevent duplicacy, lets move ahead by 1 */
			while (index < ncategory && advertiser_id == ad_domain_category_id_list[index].advertiser_id && domain_id >= ad_domain_category_id_list [index].domain_id) {
				if (domain_id == ad_domain_category_id_list [index].domain_id) {
					/* Check the alloc size, realloc if necessary */
					if (bid_response_params->advertiser_category_id.count == alloc_count) {
						alloc_count += CATEGORY_ALLOC_COUNT;
						//change tmp_count to tmp_list
						tmp_list = realloc (bid_response_params->advertiser_category_id.list, sizeof(int) * alloc_count);
						if (tmp_list == NULL) {
							free (bid_response_params->advertiser_category_id.list);
							bid_response_params->advertiser_category_id.list = NULL;
							llog_write(L_DEBUG,"\n insufficient memory ");
							return ADS_ERROR_INTERNAL;
						}

						bid_response_params->advertiser_category_id.list = tmp_list;
					}
				
					bid_response_params->advertiser_category_id.list [bid_response_params->advertiser_category_id.count++] = ad_domain_category_id_list [index].category_id;
				}
				index++;
			}
		
	}	
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	if (bid_response_params->advertiser_category_id.list != NULL && bid_response_params->advertiser_category_id.count != 0) {
		index = 0;
		llog_write(L_DEBUG, "Category List count: %d\n", bid_response_params->advertiser_category_id.count);
		llog_write(L_DEBUG, "Category List for this advertiser: %d, Domain: %d\n", advertiser_id, domain_id);
		for (index = 0; index < bid_response_params->advertiser_category_id.count; index++) {
			llog_write(L_DEBUG, "%d\n", bid_response_params->advertiser_category_id.list [index]);
		}
	}
#endif
	return ADS_ERROR_SUCCESS;	
} 

