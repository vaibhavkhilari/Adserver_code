/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include "time_parting.h"
#include "ad_server_click_track_utils.h"
#include "floor_rules_types.h"
#include "ad_server_types.h"
#include "error.h"

/* 
The following function is sakamoto's algorithm which maps a particular date to days of week. It returns the following: 
Sun - 0
Mon - 1
Tue - 2
Wed - 3
Thu - 4
Fri - 5
Sat - 6

This algo is modified slightly to return the following map as per our convention where every day represents only one set bit: 
Sun -   1
Mon -   64
Tue -   32
Wed -   16
Thu -   8
Fri -   4
Sat -   2
*/

static inline int dow(int y, int m, int d)
{
    static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
    int day_of_week;
    y -= m < 3;
    day_of_week = ((y + y/4 - y/100 + y/400 + t[m-1] + d) % 7);
	/* In case of Sun (day_of_week = 0) return 1 directly, otherwise calculate the day_of_week as per convention described by the above mapping */
    return day_of_week?2<<(6-day_of_week):1;
}

/* This function checks if the specific bit in the integer returned by dow(bit representation of the current day of week) is also set in days_of_week */
int do_day_parting (int days_of_week, 
					 ad_server_req_param_t *in_req_params,	
					 int *day_parting_evaluation_result
					) {
	/* Local Variables */
	int impr_year=-1, impr_month=-1, impr_date=-1, impr_hr=-1, impr_min=-1, impr_sec=-1;
	char *cli_date = NULL;

	/* decode time variable from user page */
	if(in_req_params->time_stamp != NULL && in_req_params->time_stamp[0] != '\0') {
		decode_click_url(&cli_date, in_req_params->time_stamp);
		if(cli_date != NULL) {
			sscanf(cli_date,"%d-%d-%d %d:%d:%d", &impr_year, &impr_month, &impr_date, &impr_hr, &impr_min, &impr_sec);
			free(cli_date);
		} else {
			llog_write(L_DEBUG, "ERROR: Not able to decode user time_stamp %s:%d\n", __FILE__, __LINE__);
			*day_parting_evaluation_result = DAY_PARTING_EVALUATION_FAIL;
			return ADS_ERROR_SUCCESS;
		}
	} 
	/* Validate whether we got correct time or not. If not we have to filter all the campaigns that are time-targetted */
	/* Since javascript returns months mapping from 0-11 */
	if (impr_month > 12 || impr_month < 1 || impr_date < 1 || impr_date > 31 || impr_year < 0 || impr_year > 3000) { /*Won't exist till 30th century ;) */
		/* Time Stamp is wrong. Filter the rule and return */
		llog_write(L_DEBUG, "\nERROR: Wrong Month:%d or Date:%d or Year:%d %s:%d\n", impr_month, impr_date, impr_year, __FILE__, __LINE__);
		*day_parting_evaluation_result = DAY_PARTING_EVALUATION_FAIL;
	} else {
	#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
    		llog_write(L_DEBUG, "INFO: impr_year:%d, impr_month:%d, impr_date:%d, %s:%d\n",impr_year, impr_month, impr_date, __FILE__, __LINE__);
    		llog_write(L_DEBUG, "INFO: days_of_week: %d, current_user_day: %d, %s:%d\n", days_of_week, dow(impr_year, impr_month, impr_date),  __FILE__, __LINE__);
	#endif

		/* Get the day of week and decide if the rule should be valid or not */
		if (dow(impr_year, impr_month, impr_date) & days_of_week) {
			*day_parting_evaluation_result = DAY_PARTING_EVALUATION_PASS;
		} else {
			*day_parting_evaluation_result = DAY_PARTING_EVALUATION_FAIL;
		}
	}
	return ADS_ERROR_SUCCESS;
}

