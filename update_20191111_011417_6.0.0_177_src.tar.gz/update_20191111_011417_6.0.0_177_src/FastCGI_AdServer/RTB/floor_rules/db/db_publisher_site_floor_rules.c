/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <error.h>
#include "rt_types.h"
#include "db_error.h"
#include "db_constants.h"
#include "floor_rules_types.h"
#include "db_publisher_site_floor_rules.h"
#include "floor_rule_engine.h"
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include "fte_util.h"

/* This query loads rules selectively i.e. only rules that are valid for today, yesterday and tomorrow are loaded */

#define FLOOR_RULES_ALLOC_SIZE 50
#define GET_PUBLISHER_SITE_FLOOR_RULES "select rule_id, rule_type, floor_type, campaign_id, dsp_id, buyer_id, segment_expression, lower(country_code), lower(region_code), lower(city_name), dma_code, minimum_floor_ecpm, floor_ecpm , priority, fixed_price_flag, start_time_parting, end_time_parting, days_of_week, ad_size_id, fold_position_id, section_id, active_entities, rich_media_creative_attribute_id, line_item_id, ext_campaign_id, ext_strategy_id, rule_meta_id, matched_user, platform_id, currency_id, applicability from publisher_site_floor_rules where pub_id=? and site_id in (?,0) and status=1 and days_of_week & ? and start_time < '%s' and '%s' <= end_time and rule_type!=3 group by rule_id, rule_type, floor_type, campaign_id, dsp_id, buyer_id, segment_expression, country_code, region_code, city_name, dma_code, minimum_floor_ecpm, floor_ecpm , priority, fixed_price_flag, start_time_parting, end_time_parting, days_of_week, ad_size_id, fold_position_id, section_id, active_entities, rich_media_creative_attribute_id, line_item_id, ext_campaign_id, ext_strategy_id,rule_meta_id,platform_id order by priority asc, floor_ecpm desc, rule_id asc limit 10000"

void *get_publisher_site_floor_rules_settings(long publisher_id,
	long site_id,
	db_connection_t *dbconn,
	memcached_floor_rules_t **memcached_floor_rules,
	int *rc)
{
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN];
	db_publisher_site_floor_rules_settings_t db_row;
	int active_entities_array[MAX_ACTIVE_ENTITIES]; ///this willl hold the id for active entities in in rule
	int active_entities_array_elements_count = 0;
	void *protobuff_ctxt = NULL, *tmp_protobuff_ctxt = NULL;
	char *saveptr = NULL, *token=NULL;
	int prev_rule_id = -1;


	memset(&db_row, 0, sizeof (db_publisher_site_floor_rules_settings_t));
	(*memcached_floor_rules) = NULL;
	protobuff_ctxt = NULL;
	(*rc) = DB_ERROR_SUCCESS;
	
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);
	snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_PUBLISHER_SITE_FLOOR_RULES, dbconn->timestamp, 
					dbconn->timestamp);
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);


#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG,  "INFO: db floor rules query: \"%s\"\n", sql_statement );
#endif		
        if(sql_retval!=SQL_SUCCESS) {
                printf("Error preparing statement:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
                (*rc) = DB_ERROR_INTERNAL;
				goto handle_error;
        }
	
	
        sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &db_row.s_publisher_id, 0, &db_row.cb_publisher_id);
       if(sql_retval!=SQL_SUCCESS) {
                printf("Error binding:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
                (*rc) = DB_ERROR_INTERNAL;
				goto handle_error;
        }

        sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &db_row.s_site_id, 0, &db_row.cb_site_id);
        if(sql_retval!=SQL_SUCCESS) {
                printf("Error binding:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
                (*rc) = DB_ERROR_INTERNAL;
				goto handle_error;
        }

        sql_retval = SQLBindParameter(statement_handle, 3, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &db_row.s_dow_bitmask, 0, &db_row.cb_dow_bitmask);
        if(sql_retval!=SQL_SUCCESS) {
                printf("Error binding:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
                (*rc) = DB_ERROR_INTERNAL;
				goto handle_error;
        }

        db_row.s_publisher_id = publisher_id;
        db_row.s_site_id = site_id;
	    db_row.s_dow_bitmask = get_current_date();

        sql_retval = SQLExecute(statement_handle);
	if (sql_retval == SQL_SUCCESS) {

		SQLBindCol(statement_handle, 1, SQL_C_ULONG, &db_row.s_rule_id,
				0, &db_row.cb_rule_id);
		SQLBindCol(statement_handle, 2, SQL_C_ULONG, &db_row.s_rule_type,
				0, &db_row.cb_rule_type);
		SQLBindCol(statement_handle, 3, SQL_C_ULONG, &db_row.s_floor_type,
				0, &db_row.cb_floor_type);
		SQLBindCol(statement_handle, 4, SQL_C_ULONG, &db_row.s_campaign_id,
				0, &db_row.cb_campaign_id);
		SQLBindCol(statement_handle, 5, SQL_C_ULONG, &db_row.s_dsp_id,
				0, &db_row.cb_dsp_id);
		SQLBindCol(statement_handle, 6, SQL_C_ULONG, &db_row.s_buyer_id,
				0, &db_row.cb_buyer_id);
		SQLBindCol(statement_handle, 7, SQL_C_CHAR, db_row.s_segment,
				MAX_SEGMENT_EXPR_SIZE, &db_row.cb_segment);
		SQLBindCol(statement_handle, 8, SQL_C_CHAR, db_row.s_country_code,
				MAX_GEO_CODE_LEN, &db_row.cb_country_code);
		SQLBindCol(statement_handle, 9, SQL_C_CHAR, db_row.s_region_code,
				MAX_GEO_CODE_LEN, &db_row.cb_region_code);
		SQLBindCol(statement_handle, 10, SQL_C_CHAR, db_row.s_city_name,
				MAX_GEO_NAME_LEN, &db_row.cb_city_name);
		SQLBindCol(statement_handle, 11, SQL_C_ULONG, &db_row.s_dma_code,
				0, &db_row.cb_dma_code);
		SQLBindCol(statement_handle, 12, SQL_C_DOUBLE, &db_row.s_min_floor_ecpm,
				0, &db_row.cb_min_floor_ecpm);
		SQLBindCol(statement_handle, 13, SQL_C_DOUBLE, &db_row.s_floor_ecpm,
				0, &db_row.cb_floor_ecpm);
		SQLBindCol(statement_handle, 14, SQL_C_ULONG, &db_row.s_priority,
				0, &db_row.cb_priority);
		SQLBindCol(statement_handle, 15, SQL_C_ULONG, &db_row.s_fixed_price_flag,
				0, &db_row.cb_fixed_price_flag);
		SQLBindCol(statement_handle, 16, SQL_C_ULONG, &db_row.s_start_time_parting,
                		0, &db_row.cb_start_time_parting);
		SQLBindCol(statement_handle, 17, SQL_C_ULONG, &db_row.s_end_time_parting,
                		0, &db_row.cb_end_time_parting);
		SQLBindCol(statement_handle, 18, SQL_C_ULONG, &db_row.s_days_of_week,
                		0, &db_row.cb_days_of_week);
		SQLBindCol(statement_handle, 19, SQL_C_ULONG, &db_row.s_ad_size_id,
				0, &db_row.cb_ad_size_id);
		SQLBindCol(statement_handle, 20, SQL_C_ULONG, &db_row.s_fold_position_id,
				0, &db_row.cb_fold_position_id);
		SQLBindCol(statement_handle, 21, SQL_C_CHAR, db_row.s_site_section,
				MAX_SITE_SECTION_SIZE, &db_row.cb_site_section);
		SQLBindCol(statement_handle, 22, SQL_C_CHAR, db_row.s_active_entities,
				MAX_ACTIVE_ENTITY_SIZE, &db_row.cb_active_entities);		
		SQLBindCol(statement_handle, 23, SQL_C_ULONG, &db_row.s_rich_media_creative_attribute_id,
				0, &db_row.cb_rich_media_creative_attribute_id);
		SQLBindCol(statement_handle, 24, SQL_C_ULONG, &db_row.s_line_item_id,
				0, &db_row.cb_line_item_id);
		SQLBindCol(statement_handle, 25, SQL_C_ULONG, &db_row.s_pubconnect_campaign_id,
				0, &db_row.cb_pubconnect_campaign_id);
		SQLBindCol(statement_handle, 26, SQL_C_ULONG, &db_row.s_strategy_id,
				0, &db_row.cb_strategy_id);
		SQLBindCol(statement_handle, 27, SQL_C_ULONG, &db_row.s_rule_meta_id,
                                0, &db_row.cb_rule_meta_id);
		SQLBindCol(statement_handle, 28, SQL_C_ULONG, &db_row.s_matched_user,
						                                0, &db_row.cb_matched_user);
		SQLBindCol(statement_handle, 29, SQL_C_ULONG, &db_row.s_platform_id,
						                                0, &db_row.cb_platform_id);
		SQLBindCol(statement_handle, 30, SQL_C_ULONG, &db_row.s_currency_id,
						                                0, &db_row.cb_currency_id);
                SQLBindCol(statement_handle, 31, SQL_C_UTINYINT, &db_row.s_applicability,
						                                0, &db_row.cb_applicability);



		while (sql_retval != SQL_NO_DATA) {
			sql_retval = SQLFetch (statement_handle);
			if (sql_retval != SQL_NO_DATA) {
				if (prev_rule_id != db_row.s_rule_id) {
				    //Mark number of elemenst as 0 in active entities array. Parse active entities and store it in array
                    active_entities_array_elements_count = 0;
                    if (db_row.cb_active_entities != SQL_NULL_DATA && db_row.cb_active_entities != 0) {
						token = strtok_r((char *) db_row.s_active_entities, ",", &saveptr);
                        while (token != NULL) {
                               active_entities_array[active_entities_array_elements_count] = atoi(token);
                               errno = 0;
                               active_entities_array_elements_count += 1;
                               token = strtok_r(NULL, ",", &saveptr);
                        }
					}
					(*rc) = 0;
					tmp_protobuff_ctxt = copy_floor_rule_from_db(
                                            publisher_id,
                                            site_id,
                                            &db_row,
                                            active_entities_array,
                                            active_entities_array_elements_count,
                                            prev_rule_id,
											rc,
											protobuff_ctxt);
                     if ((*rc) != ADS_ERROR_SUCCESS) {
                         llog_write(L_DEBUG, "\n(%s:%d) Not able to copy floor rules into protobuff object.\n",
                                         __FUNCTION__,
                                         __LINE__);
                         (*rc) = DB_ERROR_INTERNAL;
						 goto handle_error;
                     }
					 protobuff_ctxt = tmp_protobuff_ctxt;
                     prev_rule_id = db_row.s_rule_id;
				}
                
                if (copy_floor_rule_active_entities_from_db(&db_row, protobuff_ctxt) != ADS_ERROR_SUCCESS) {
                    llog_write(L_DEBUG, "(%s:%d) Not able to copy floor rules active entities.\n",
                                    __FUNCTION__,
                                    __LINE__);
                    (*rc) = DB_ERROR_INTERNAL;
					goto handle_error;
				}
			}
		}
				
        } else {
                 llog_write(L_DEBUG, "Error executing select statement:\n");
                 db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                               sql_retval,__LINE__,__FILE__ );
                 (*rc)  = DB_ERROR_INTERNAL;
				 goto handle_error;
         }


       if (	protobuff_ctxt != NULL && 
			serialize_memcached_floor_rules(memcached_floor_rules, protobuff_ctxt) != ADS_ERROR_SUCCESS) {
			llog_write(L_DEBUG, "(%s:%d) Not able to serialized memcached_floor_rules.\n",
							__FUNCTION__,
							__LINE__);
			(*rc) = DB_ERROR_INTERNAL;
			goto handle_error;
	   }

       (*rc) = DB_ERROR_SUCCESS;
		// Free The SQL Statement Handle
        if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return protobuff_ctxt;

handle_error:
		free_floor_rules_protobuff_ctxt(protobuff_ctxt);
		// Free The SQL Statement Handle
         if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return NULL;;
}

