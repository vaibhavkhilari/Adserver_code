/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_connection.h"
#include "db_advertiser_domain.h"
#include "db_error.h"
#include "db_constants.h"
#include "error.h"
#include "rt_types.h"
#include "db_advertiser_domain_category_mapping.h"

//#define GET_ADVERTISER_DOMAIN_CATEGORY_ID 
//"select distinct ADCM.advertiser_id, ADCM.domain_id, ADCM.category_id from advertiser_domain_category_mapping as ADCM, publisher_site_floor_rules as PSFR where PSFR.pub_id = ?  and PSFR.site_id in (0, ?) and PSFR.status = 1 and PSFR.start_time < '%s' and '%s' <= PSFR.end_time and PSFR.advertiser_category_id != 0 and ADCM.category_id = PSFR.advertiser_category_id order by ADCM.advertiser_id, ADCM.domain_id"

#define GET_ADVERTISER_DOMAIN_CATEGORY_ID \
"select distinct ADCM.advertiser_id, ADCM.domain_id, ADCM.category_id from advertiser_domain_category_mapping ADCM  inner join (select distinct advertiser_category_id from publisher_site_floor_rules PSFR where PSFR.pub_id = ?  and PSFR.site_id in (0, ?) and PSFR.status = 1 and PSFR.start_time < '%s' and '%s' <= PSFR.end_time and PSFR.advertiser_category_id != 0)as t on t.advertiser_category_id = ADCM.category_id order by ADCM.advertiser_id, ADCM.domain_id limit 50000"

#define INITIAL_ADVERTISER_DOMAIN_CATEGORY_ID 50 

int get_advertiser_domain_category_id (
	long pub_id, 
	long site_id, 
	db_connection_t* dbconn,
	advertiser_domain_category_id_t** ad_domain_category_id_list,
	int* nelements
	) { 
	
	/* Local Variables */
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	int alloc_count = INITIAL_ADVERTISER_DOMAIN_CATEGORY_ID;
	int use_count = 0;
	SQLINTEGER s_pub_id;
	SQLINTEGER s_site_id;
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	int count = 0;
#endif

	SQLLEN len_domain_id = 0; // Length of each column fetched from the DB
	SQLLEN len_advertiser_id = 0; // Length of each column fetched from the DB
	SQLLEN len_category_id = 0; // Length of each column fetched from the DB

	advertiser_domain_category_id_t buf; // To store data fetched from DB

	advertiser_domain_category_id_t* temp_ptr = NULL;
	advertiser_domain_category_id_t* result_ptr = NULL;

	(*ad_domain_category_id_list) = NULL;
	(*nelements) = 0;

	// Allocate the statement handle
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	// Create SQL char string which contains the query
//	strncpy((char *) sql_statement, GET_ADVERTISER_DOMAIN_CATEGORY_ID, MAX_SQL_QUERY_STR_LEN);
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_ADVERTISER_DOMAIN_CATEGORY_ID, dbconn->timestamp,
											dbconn->timestamp);
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

        // Create a prepared statement
        sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
        if (sql_retval != SQL_SUCCESS) {
                llog_write(L_DEBUG, "ERROR Preparing statement and error code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return ADS_ERROR_INTERNAL;
        }

        // Bind parameters
        sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_pub_id, 0, NULL);
        if (sql_retval != SQL_SUCCESS) {
                llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval, __LINE__, __FILE__);
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return ADS_ERROR_INTERNAL;
        }
        s_pub_id=pub_id;

        sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_site_id, 0, NULL);
        if(sql_retval != SQL_SUCCESS) {
                llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return ADS_ERROR_INTERNAL;
        }
        s_site_id=site_id;

	/* Fetch the data */
	sql_retval = SQLExecute(statement_handle);

	// If The SQL Statement Executed Successfully, Retrieve
	if (sql_retval == SQL_SUCCESS) {
		SQLBindCol(statement_handle, 1, SQL_C_LONG, &(buf.advertiser_id), 0, &len_advertiser_id);
		SQLBindCol(statement_handle, 2, SQL_C_LONG, &(buf.domain_id), 0, &len_domain_id);
		SQLBindCol(statement_handle, 3, SQL_C_LONG, &(buf.category_id), 0, &len_category_id);

		result_ptr = (advertiser_domain_category_id_t*) malloc(sizeof(advertiser_domain_category_id_t) * alloc_count);
                if ( result_ptr == NULL ) {
                        if (statement_handle != 0) {
                                SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                        }
                        return ADS_ERROR_NOMEMORY;
                }

                while (sql_retval != SQL_NO_DATA) {
                        sql_retval = SQLFetch(statement_handle);

                        if (sql_retval != SQL_NO_DATA) {
                                if (use_count == alloc_count) {
                                        alloc_count <<= 1;
                                        temp_ptr = realloc(result_ptr, alloc_count * sizeof(advertiser_domain_category_id_t));
                                        if (temp_ptr == NULL) {
                                                llog_write(L_DEBUG, "ERROR realloc failed %s:%d\n", __FILE__, __LINE__);
                                                free(result_ptr);
                                                result_ptr = NULL;
                                                // Free The SQL Statement Handle
                                                if (statement_handle != 0) {
                                                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                                                }
                                                return ADS_ERROR_NOMEMORY;
                                        }

					result_ptr = temp_ptr;
                                }
                                if (
                                                len_domain_id != SQL_NULL_DATA
                                                &&
                                                len_advertiser_id != SQL_NULL_DATA
                                                &&
                                                len_category_id != SQL_NULL_DATA
                                             
                                         ) {
                                        // None of the columns is NULL or empty string
                                        result_ptr[use_count].domain_id = buf.domain_id;
                                        result_ptr[use_count].advertiser_id = buf.advertiser_id;
                                        result_ptr[use_count].category_id = buf.category_id;
                                        use_count++;
                                } else {
                                        // Dhokaaaaaaa ....these 3 fields cannot be NULL
                                        // Print the error
                                        llog_write(L_DEBUG, "ERROR, some rows in the table advertiser_domain have NULL values or empty strings for the pub_id : %ld and site_id : %ld %s:%d", pub_id, site_id, __FILE__, __LINE__);
                                }
                        }
                }
        } else {

                llog_write(L_DEBUG,"ERROR executing select statement : %s,  return code = %d %s:%d\n", sql_statement, sql_retval, __FILE__,__LINE__);
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__ ,__FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
		
		/* If we are here, we never malloc'd it, so no need to free it. Just in case to be on safer side if somebody modifies the code in future */
		if (result_ptr != NULL) {
                	free(result_ptr);
                	result_ptr = NULL;
		}

                return ADS_ERROR_INTERNAL;
        }

        if(use_count == 0) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                llog_write(L_DEBUG, "\n No non-NULL records found in the table advertiser_domain for pub_id : %ld, site_id : %ld %s:%d\n", pub_id, site_id, __FILE__, __LINE__);
#endif
			if (result_ptr != NULL) {
                	free(result_ptr);
                	result_ptr = NULL;
			}
		}
        // Free The SQL Statement Handle
        if (statement_handle != 0) {
                SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
        }
        
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	if (result_ptr != NULL) {
		llog_write(L_DEBUG, "\nInfo: List from DB\n");
		llog_write(L_DEBUG, "Advertiser-id Domain-id Category-id\n");
		for (count = 0; count < use_count; count++) {
			llog_write(L_DEBUG, "%d %d %d\n", result_ptr [count].advertiser_id, result_ptr [count].domain_id, result_ptr [count].category_id );
		}
	}
#endif
	
        (*nelements) = use_count;
        (*ad_domain_category_id_list) = result_ptr;
				llog_write(L_DEBUG, "NDBRecords:%d:%s.%d\n", use_count, __FILE__,  __LINE__);
        return ADS_ERROR_SUCCESS;
}


			
