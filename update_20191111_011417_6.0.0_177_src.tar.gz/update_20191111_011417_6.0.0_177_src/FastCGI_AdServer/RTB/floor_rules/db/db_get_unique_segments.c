/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "error.h"
#include "db_get_unique_segments.h"

#define GET_SEGMENT_LIST "select unique_segments from publisher_site_floor_rules where pub_id=? and site_id in (?,0) and status = 1 and start_time < '%s' and '%s' <= end_time"

#define UNIQUE_SEGMENTS_ALLOC_SIZE 5
#define MAX_SEG_LIST_LEN 1024
#define MAX_LEN_SEGMENT 20

int db_get_unique_segment_list(
	long publisher_id, 
	long site_id, 
	db_connection_t *dbconn, 
	char **segment_list
	){
	/* Local Variables */
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN];
	SQLINTEGER s_site_id;
	SQLINTEGER s_publisher_id;
	SQLCHAR s_list[MAX_SEG_LIST_LEN];
	SQLLEN cb_site_id = 0;
	SQLLEN cb_publisher_id = 0;
	SQLLEN cb_segment_vector = SQL_NTS;
	char *token;
	char (*segment_vector)[MAX_LEN_SEGMENT + 1] = NULL;
	char (*tmp_segment_vector) [MAX_LEN_SEGMENT + 1];
	int index = 0;
	int seg_count = 0;  /* No of Unique segments at publisher/site level */ 
	int found = 0; /* flag to identify unique segments */
	int seg_len = 0; /* Total lenght of all the segments in bytes */
	int alloc_count = 0; /* No of allocations done for the segments */
	int use_count = 0; /* Actual number of segments we found */
	char *saveptr;
	int segments_list_size = 0;

	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

//	strncpy((char *) sql_statement, GET_SEGMENT_LIST, MAX_SQL_QUERY_STR_LEN);
	snprintf((char *)sql_statement, MAX_SQL_QUERY_STR_LEN, GET_SEGMENT_LIST, dbconn->timestamp, dbconn->timestamp);
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if(sql_retval!=SQL_SUCCESS) {
		llog_write(L_DEBUG, "ERROR: Error preparing statement \n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
                // Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}

	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_publisher_id, 0, &cb_publisher_id);

	if(sql_retval!=SQL_SUCCESS) {
		llog_write(L_DEBUG, "ERROR: Error binding\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}


	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_site_id);
	if(sql_retval!=SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}

	s_publisher_id = publisher_id;
	s_site_id = site_id;

	sql_retval = SQLExecute (statement_handle);

	if (sql_retval == SQL_SUCCESS) {
		SQLBindCol(statement_handle, 1, SQL_C_CHAR, &s_list,
                       MAX_SEG_LIST_LEN, &cb_segment_vector );

		segment_vector = malloc(UNIQUE_SEGMENTS_ALLOC_SIZE * sizeof (*segment_vector));
		if (segment_vector == NULL) {
			if (statement_handle != 0) {
				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			}
			return DB_ERROR_NO_MEMORY;
		}

		alloc_count = UNIQUE_SEGMENTS_ALLOC_SIZE;

		while (sql_retval != SQL_NO_DATA) {
			sql_retval = SQLFetch(statement_handle);
                        if (sql_retval != SQL_NO_DATA) {

				/* skip null values */
				if (cb_segment_vector == SQL_NULL_DATA || cb_segment_vector == 0) {
					continue;	
				}

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING 
                                llog_write(L_DEBUG, "custom_segment_list - %s\n", (char *)s_list);
#endif
				token = strtok_r ((char *)s_list, ",", &saveptr);
				found = 0;

				while (token != NULL) {
					for (index = 0; index < seg_count; index++) {
						if (!strncmp(token, segment_vector [index], MAX_LEN_SEGMENT)) {
							found = 1;
						break;
						}
					} /* for */

					if (!found) {
                                		if (use_count == alloc_count) {
                                        		alloc_count += UNIQUE_SEGMENTS_ALLOC_SIZE;
                                        		tmp_segment_vector = realloc(segment_vector, sizeof(*segment_vector) * alloc_count);
                                        		if (tmp_segment_vector == NULL) {
                                                		if (segment_vector != NULL){
                                                        		free (segment_vector);
                                                        		segment_vector = NULL;
                                                		}

                                                		/* Free The SQL Statement Handle */
                                                		if (statement_handle != 0) {
                                                        		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                                                		}	
                                                		return DB_ERROR_NO_MEMORY;
                                        		}
                                        		segment_vector = tmp_segment_vector;
                                		}

						strncpy (segment_vector[seg_count], token, MAX_LEN_SEGMENT); //TODO remove -1and add NUL to the segment_vector . Change 'do while' to while.
						segment_vector [seg_count][MAX_LEN_SEGMENT] = '\0';
						seg_count++;

						/* adding 1 to tokenlength  for '\0' or ',' */
						seg_len += strlen(token) + 1;
                                                use_count++;
					}
					found = 0;
					token = strtok_r(NULL, ",", &saveptr);
				} //while(strtok_r(NULL, ",", &saveptr);
			}
		}
	} else {
		llog_write(L_DEBUG,"get_unique_segment_list: error executing select statement :: line: %d file :%s\n", __LINE__, __FILE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );

                /* Free The SQL Statement Handle */
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}

	if (use_count == 0) {
		/* Free The SQL Statement Handle */
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		/* Initialize list to NULL */
		(*segment_list) = NULL;

		/* Free the segment_vector that we have allocated */
		if (segment_vector) {
			free (segment_vector);
			segment_vector = NULL;
		}
		return DB_ERROR_SUCCESS;
	}
	/* Alright we got the list of unique segments, now lets create a comma separated list */

	/* Allocate space for list */
	segments_list_size = (seg_len * sizeof (char)) ;	
	(*segment_list) = malloc (segments_list_size);
	if((*segment_list) == NULL) {
		llog_write(L_DEBUG,"\n MEMORY IS NOT AVAILABLE :: line: %d file :%s  \n", __LINE__, __FILE__);
		return ADS_ERROR_NOMEMORY;
	}

	strncpy ((*segment_list), segment_vector [0], segments_list_size - 1);

	for (index = 1; index < seg_count; index++) {
		strcat ((*segment_list), ",");
		strcat ((*segment_list), segment_vector [index]);
	}
		
	(*segment_list) [segments_list_size - 1] = '\0';
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "DEBUG LOG: UNIQUE LIST FROM THE DATABASE: %s\n", (*segment_list));
#endif
	/* finally FREE the whole chunk in one go !!! */
	free (segment_vector);
	segment_vector = NULL;

	/* Free The SQL Statement Handle */
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}

	return DB_ERROR_SUCCESS;
}

