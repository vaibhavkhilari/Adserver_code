/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>
#include "cache_types.h"
#include "db_connection.h"
#include "db_error.h"
#include "error.h"
#include "cache_get_unique_segments.h" 
#include "get_user_segments.h"

extern char *g_rtb_audience_url;

size_t
write_memory_callback(void *ptr, size_t size, size_t nmemb, void *data) {
        size_t realsize = size * nmemb;
        memory_struct_t *mem = (memory_struct_t *)data;

	if ((mem->size + realsize + 1) > mem->segment_length) {
		llog_write(L_DEBUG, "ERROR: Wrong data from Artemis, %s:%d\n", __FILE__, __LINE__);
		return 0; /* Return some invalid value to stop any more call back */
	}
/*	mem->memory = realloc(mem->memory, mem->size + realsize + 1);
  	if (mem->memory == NULL) {
    		llog_write(L_DEBUG, "ERROR: not enough memory (realloc returned NULL)\n");
		return -1; 
  	}
*/

        memcpy(&(mem->memory[mem->size]), ptr, realsize);
        mem->size += realsize;
        mem->memory[mem->size] = 0;
        return realsize;
}

int get_user_segments (
	CURL *curl, 
	cache_handle_t *cache, 
	db_connection_t *dbconn, 
	long publisher_id, 
	long site_id, 
	char *user_guid, 
	char **segment_list
	)
{
	/* Local Variables */
	char *tmp_segment_list = NULL;
        int retval = 0;
        memory_struct_t artemis_list;
        char artemis_request_url [MAX_URL_LEN];
	int segments_list_length = 0;
	CURLcode curl_retval = CURLE_OK;
        retval = cache_get_unique_segment_list (cache, dbconn, publisher_id, site_id, &tmp_segment_list);
	if (retval != ADS_ERROR_SUCCESS) {
		/* We got some error */
		(*segment_list) = NULL;
		llog_write(L_DEBUG, "ERROR: retval: %d, %s:%d\n", retval, __FILE__, __LINE__);
        	return retval;
        }

	/* Check if there are no segments. In this case, we would get a dummy variable '\0'. So we do not need to do make the Artemis Call in this case */
	if (tmp_segment_list [0] != '\0') {
		segments_list_length = strlen (tmp_segment_list);
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING 
		llog_write(L_DEBUG, "DEBUG LOG: segment_list from cache/database: %s segment list length:%d\n", tmp_segment_list, segments_list_length);
#endif
        	artemis_list.memory = malloc ((sizeof(char) * segments_list_length) + 1);
		if(artemis_list.memory == NULL) {
			/* free and come out */
			free (tmp_segment_list);
			tmp_segment_list = NULL;
			llog_write(L_DEBUG,"Memory not available :: %s:%d\n", __FILE__, __LINE__);
			return ADS_ERROR_NOMEMORY;
		}	

		/* Initialize the chunk.size and chunk.memory to NUL to check in case we do not get any data from the Artemis */
        	artemis_list.size = 0;
		artemis_list.memory [0] = '\0';
		artemis_list.segment_length = segments_list_length + 1; /* Set the limit for the data received from the audience */

        	/* Make the artemis call */

		/* Create the url with the given guid and the segment_list */
        	snprintf(artemis_request_url, MAX_URL_LEN, "%s&userId=%s&segId=%s", g_rtb_audience_url, user_guid, tmp_segment_list);
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING 
		llog_write(L_DEBUG, "DEBUG LOG: Artemis artemis_request_url: %s\n", artemis_request_url);
#endif		

        	curl_retval = curl_easy_setopt(curl, CURLOPT_URL, artemis_request_url);
		if (curl_retval != CURLE_OK) {
			free (tmp_segment_list);	
			tmp_segment_list = NULL;
			free (artemis_list.memory);
			artemis_list.memory = NULL;
			llog_write(L_DEBUG, "ERROR CURL: error setting url: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
			return ADS_ERROR_INTERNAL;
		}

        	/* send all data to this function  */
        	curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_memory_callback);
		if (curl_retval != CURLE_OK) {
		/* Free memory and Return */	
			free (tmp_segment_list);
                        tmp_segment_list = NULL;
                        free (artemis_list.memory);
                        artemis_list.memory = NULL;
			llog_write(L_DEBUG, "ERROR CURL: error setting callback function: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
			return ADS_ERROR_INTERNAL;
		}
        	/* we pass our 'chunk' struct to the callback function */
        	curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&artemis_list);
		if (curl_retval != CURLE_OK) {
		/* Free memory and Return */	
			free (tmp_segment_list);
                        tmp_segment_list = NULL;
                        free (artemis_list.memory);
                        artemis_list.memory = NULL;
			llog_write(L_DEBUG, "ERROR CURL: error setting write buffer: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
			return ADS_ERROR_INTERNAL;
		}

        	/* get the data */
        	curl_retval = curl_easy_perform(curl);
		if (curl_retval != CURLE_OK) {
			/* Free memory and Return */	
			free (tmp_segment_list);
                        tmp_segment_list = NULL;
                        free (artemis_list.memory);
                        artemis_list.memory = NULL;
			if (curl_retval == CURLE_OPERATION_TIMEOUTED) {
				llog_write(L_DEBUG, "ERROR CURL: Operation Timed out, %s:%d\n", __FILE__, __LINE__);
				return ADS_ERROR_SUCCESS;
			}	
			
			llog_write(L_DEBUG, "ERROR CURL: error doing easy perform: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
			return ADS_ERROR_INTERNAL;
		}

		if (artemis_list.size > 0) {  /* We got something from the Artemis to bite upon */
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
			llog_write(L_DEBUG, "DEBUG LOG: No of bytes received : %zu, %s:%d\n", artemis_list.size, __FILE__, __LINE__);
			llog_write(L_DEBUG, "DEBUG LOG: Segment list received: %s, %s:%d\n", artemis_list.memory, __FILE__, __LINE__);
#endif
        		/* copy the data received from the Artemis to our list */
        		strncpy (tmp_segment_list, artemis_list.memory, segments_list_length);
			tmp_segment_list [segments_list_length] = '\0'; 
			(*segment_list) = tmp_segment_list; /* Assign our original argument pointer to this pointer */
		} else {
			free (tmp_segment_list);
			tmp_segment_list = NULL;
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
			llog_write(L_DEBUG, "DEBUG LOG: user segment list is empty\n");
#endif
		}
			
        	if (artemis_list.memory)
                	free(artemis_list.memory);
	} else {
		//found DUMMY user segment list from cache, so free it and mark it NULL	
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "INFO: cache returned dummy entry, %s:%d\n", __FILE__, __LINE__);
#endif
		free(tmp_segment_list);
		tmp_segment_list = NULL;
		(*segment_list) = NULL;
	}
        return ADS_ERROR_SUCCESS;
}

