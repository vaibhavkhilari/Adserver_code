/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __FLOOR_RULES_TYPES_H__
#define __FLOOR_RULES_TYPES_H__
//this is max size for list of active entities in rule 
#define MAX_ACTIVE_ENTITY_SIZE 128 
//this is lowest priority set for open bid and non applicable bids
#define RULE_DEFAULT 0
#define PLOWEST 100
#define MIN_PRIORITY (PLOWEST + 1) 
#define MAX_PRIORITY 1


/*MAX_ACTIVE_ENTITIES indicate number of entities in rule that need to be evaluated. 
*This has to be in sync with entities in DB.
*Any change in active entities will bring changes in MAX_ACTIVE_ENTITIES macro, and floor_rules_filter.c ( check ACTIVE_ENTITIES_CODE, evaluate_floor_rules() )
*/
#define MAX_SITE_SECTION_SIZE 50


#include "ad_server_types.h"
#include "deal.h"

/*
 * The following have been put in here because they are needed in both
 * seoncd_price.c and fte.c
 */
#define OLD_CLOSING_PRICE_ALGORITHM 0
#define NEW_CLOSING_PRICE_ALGORITHM 1
#define PRICING_V_2_0 2

#define MODE_SIMULATED 0
#define MODE_ACTIVE 1

enum ACTIVE_ENTITIES_CODE{
	NO_ENTITY_SET = 0,
	DSP_ID = 1,
	BUYER_ID = 2,
	ADVERTISER_ID = 3,
	DOMAIN_ID = 4,
	SEGMENT_ID = 5,
	GEO_COUNTRY_CODE = 6,
	GEO_REGION_CODE = 7,
	GEO_CITY_NAME = 8,
	GEO_DMA_CODE = 9,
	TIME_PARTING = 10,
	DAY_PARTING = 11,
	AD_SIZE = 12,
	FOLD_POS = 13,
	ADVERTISER_CATEGORIES = 14,
	SITE_SECTION = 15,
	DEAL_ID = 16,
	CMPG_ID = 17,
	RM_CREATIVE_ID = 18,
	ADTAG_ID = 19,
	LINE_ITEM_ID = 20,
	//Active entities used for pubconnect
	PUBCONNECT_EXT_STRATEGY_ID = 23,
	PUBCONNECT_EXT_CAMPAIGN_ID = 24,
	OS_TYPE_ID = 25,
	MOBILE_DEVICE_TYPE_ID = 26,
	CARRIER_ID = 27,
	BROWSER_ID = 28,
	MAKE_MODEL_ID = 29,
	MOBILE_REQUEST_TYPE_ID  = 30,
	MOBILE_UDID_TYPE_VALIDATION  = 31,
	MOBILE_LATLONG_VALIDATION  = 32,
	VIDEO_AD_TYPE = 33,
	VIDEO_AD_POSITION = 34,
	VIDEO_PLAYBACK = 35,
	OS_ID = 36,
	MATCHED_USER = 37,
	RICHMEDIA_CREATIVE_ATTRIBUTE = 38,
	VIDEO_SKIPPABLE = 39,
	VIDEO_SKIP_OFFSET = 40,
	VIDEO_NOSKIP_ADLEN = 41,
	VIDEO_PLAYER_SIZE = 42,
	AD_TYPE_ID = 43,
	PLATFORM_ID = 44,
	SOURCE = 45

	/* When ever you add new entity, update below MAX_ACTIVE_ENTITIES also verify activity entity bitmap size(currently 64) in deal.h */
};
#define MAX_ACTIVE_ENTITIES 45

enum FLOOR_RULE_USER_SEGMENT_EVALUATION_RESULT{
	USER_SEGMENT_NOT_EVALUATED = -1,
	USER_SEGMENT_EVALUATION_FAIL = 0,
	USER_SEGMENT_EVALUATION_PASS = 1
};

enum FLOOR_RULE_GEO_EVALUATION_RESULT{
	GEO_NOT_EVALUATED = -1,
	GEO_EVALUATION_FAIL = 0,
	GEO_EVALUATION_PASS = 1
};


enum FLOOR_RULE_OS_EVALUATION_RESULT{
	OS_ID_NOT_EVALUATED = -1,
	OS_ID_EVALUATION_FAIL = 0,
	OS_ID_EVALUATION_PASS = 1
};

enum FLOOR_RULE_OS_TYPE_EVALUATION_RESULT{
	OS_TYPE_ID_NOT_EVALUATED = -1,
	OS_TYPE_ID_EVALUATION_FAIL = 0,
	OS_TYPE_ID_EVALUATION_PASS = 1
};

enum FLOOR_RULE_MAKE_MODEL_EVALUATION_RESULT{
	MAKE_MODEL_ID_NOT_EVALUATED = -1,
	MAKE_MODEL_ID_EVALUATION_FAIL = 0,
	MAKE_MODEL_ID_EVALUATION_PASS = 1
};

enum FLOOR_RULE_BROWSER_EVALUATION_RESULT{
	BROWSER_ID_NOT_EVALUATED = -1,
	BROWSER_ID_EVALUATION_FAIL = 0,
	BROWSER_ID_EVALUATION_PASS = 1
};


enum FLOOR_RULE_MOBILE_DEVICE_TYPE_ID_EVALUATION_RESULT{
	MOBILE_DEVICE_TYPE_ID_NOT_EVALUATED = -1,
	MOBILE_DEVICE_TYPE_ID_EVALUATION_FAIL = 0,
	MOBILE_DEVICE_TYPE_ID_EVALUATION_PASS = 1
};


enum FLOOR_RULE_MOBILE_REQUEST_TYPE_ID_EVALUATION_RESULT{
	MOBILE_REQUEST_TYPE_ID_NOT_EVALUATED = -1,
	MOBILE_REQUEST_TYPE_ID_EVALUATION_FAIL = 0,
	MOBILE_REQUEST_TYPE_ID_EVALUATION_PASS = 1
};


enum FLOOR_RULE_MOBILE_UDID_TYPE_EVALUATION_RESULT{
	MOBILE_UDID_TYPE_NOT_EVALUATED = -1,
	MOBILE_UDID_TYPE_EVALUATION_FAIL = 0,
	MOBILE_UDID_TYPE_EVALUATION_PASS = 1
};

enum FLOOR_RULE_MOBILE_LATLONG_EVALUATION_RESULT{
	MOBILE_LATLONG_NOT_EVALUATED = -1,
	MOBILE_LATLONG_EVALUATION_FAIL = 0,
	MOBILE_LATLONG_EVALUATION_PASS = 1
};

enum FLOOR_RULE_VIDEO_PLAYBACK_EVALUATION_RESULT{
        VIDEO_PLAYBACK_NOT_EVALUATED = -1,
        VIDEO_PLAYBACK_EVALUATION_FAIL = 0,
        VIDEO_PLAYBACK_EVALUATION_PASS = 1
};

enum FLOOR_RULE_VIDEO_AD_TYPE_EVALUATION_RESULT{
        VIDEO_AD_TYPE_NOT_EVALUATED = -1,
        VIDEO_AD_TYPE_EVALUATION_FAIL = 0,
        VIDEO_AD_TYPE_EVALUATION_PASS = 1
};

enum FLOOR_RULE_VIDEO_AD_POSITION_EVALUATION_RESULT{
        VIDEO_AD_POSITION_NOT_EVALUATED = -1,
        VIDEO_AD_POSITION_EVALUATION_FAIL = 0,
        VIDEO_AD_POSITION_EVALUATION_PASS = 1
};

enum FLOOR_RULE_VIDEO_SKIPPABLE_EVALUATION_RESULT{
        VIDEO_SKIPPABLE_NOT_EVALUATED = -1,
        VIDEO_SKIPPABLE_EVALUATION_FAIL = 0,
        VIDEO_SKIPPABLE_EVALUATION_PASS = 1
};

enum FLOOR_RULE_VIDEO_SKIP_OFFSET_EVALUATION_RESULT{
        VIDEO_SKIP_OFFSET_NOT_EVALUATED = -1,
        VIDEO_SKIP_OFFSET_EVALUATION_FAIL = 0,
        VIDEO_SKIP_OFFSET_EVALUATION_PASS = 1
};

enum FLOOR_RULE_VIDEO_NOSKIP_ADLEN_EVALUATION_RESULT{
        VIDEO_NOSKIP_ADLEN_NOT_EVALUATED = -1,
        VIDEO_NOSKIP_ADLEN_EVALUATION_FAIL = 0,
        VIDEO_NOSKIP_ADLEN_EVALUATION_PASS = 1
};

enum FLOOR_RULE_VIDEO_PLAYER_SIZE_EVALUATION_RESULT{
        VIDEO_PLAYER_SIZE_NOT_EVALUATED = -1,
        VIDEO_PLAYER_SIZE_EVALUATION_FAIL = 0,
        VIDEO_PLAYER_SIZE_EVALUATION_PASS = 1
};

enum FLOOR_RULE_CARRIER_EVALUATION_RESULT{
	CARRIER_ID_NOT_EVALUATED = -1,
	CARRIER_ID_EVALUATION_FAIL = 0,
	CARRIER_ID_EVALUATION_PASS = 1
};


enum FLOOR_RULE_TIME_PARTING_EVALUATION_RESULT{
	TIME_PARTING_NOT_EVALUATED = -1,
	TIME_PARTING_EVALUATION_FAIL = 0,
	TIME_PARTING_EVALUATION_PASS = 1
};

enum FLOOR_RULE_DAY_PARTING_EVALUATION_RESULT{
	DAY_PARTING_NOT_EVALUATED = -1,
	DAY_PARTING_EVALUATION_FAIL = 0,
	DAY_PARTING_EVALUATION_PASS = 1
};

enum FLOOR_RULE_AD_PLACEMENT_EVALUATION_RESULT{
	FOLD_POSITION_NOT_EVALUATED = -1,
	FOLD_POSITION_EVALUATION_FAIL = 0,
	FOLD_POSITION_EVALUATION_PASS = 1
};

enum FLOOR_RULE_AD_SIZE_EVALUATION_RESULT{
	AD_SIZE_NOT_EVALUATED = -1,
	AD_SIZE_EVALUATION_FAIL = 0,
	AD_SIZE_EVALUATION_PASS = 1
};

enum FLOOR_RULE_AD_ID_EVALUATION_RESULT{
	AD_ID_NOT_EVALUATED = -1,
	AD_ID_EVALUATION_FAIL = 0,
	AD_ID_EVALUATION_PASS = 1
};


enum FLOOR_RULE_SITE_SECTION_EVALUATION_RESULT{
	SITE_SECTION_NOT_EVALUATED = -1,
	SITE_SECTION_EVALUATION_FAIL = 0,
	SITE_SECTION_EVALUATION_PASS = 1
};

enum FLOOR_RULE_MATCHED_USER_EVALUATION_RESULT{
	MATCHED_USER_NOT_EVALUATED = -1,
	MATCHED_USER_EVALUATION_FAIL = 0,
	MATCHED_USER_EVALUATION_PASS = 1
};

enum FLOOR_RULE_RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_RESULT{
	  RICHMEDIA_CREATIVE_ATRIBUTE_NOT_EVALUATED = -1,
	  RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL = 0,
	  RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_PASS = 1
};

enum FLOOR_RULE_AD_TYPE_ID_EVALUATION_RESULT{
        AD_TYPE_ID_NOT_EVALUATED = -1,
        AD_TYPE_ID_EVALUATION_FAIL = 0,
        AD_TYPE_ID_EVALUATION_PASS = 1
};

enum FLOOR_RULE_PLATFORM_ID_EVALUATION_RESULT{
        PLATFORM_ID_NOT_EVALUATED = -1,
        PLATFORM_ID_EVALUATION_FAIL = 0,
        PLATFORM_ID_EVALUATION_PASS = 1
};

enum SOURCE_EVALUATION_RESULT{
	SOURCE_NOT_EVALUATED = -1,
	SOURCE_EVALUATION_FAIL = 0,
	SOURCE_EVALUATION_PASS = 1
};

enum FLOOR_RULE_TYPE{
	RULE_INVALID = 0,
	RULE_RTB = 1,
	RULE_STANDARD_ADFLEX = 2,
	RULE_DEAL = 3
};

enum CUSTOM_TARGETING_DEALS_EVALUATION_RESULT_T{
	CUSTOM_TARGETING_EVALUATION_RESULT_NOT_EVALUATED = -1,
	CUSTOM_TARGETING_EVALUATION_RESULT_FAIL = 0,
	CUSTOM_TARGETING_EVALUATION_RESULT_PASS = 1
};

enum PUBLISHER_REQUESTED_DEAL_EVALUATION_RESULT_T{
	PUBLISHER_REQUESTED_DEAL_NOT_EVALUATED = -1,
	PUBLISHER_REQUESTED_DEAL_EVALUATION_FAIL = 0,
	PUBLISHER_REQUESTED_DEAL_EVALUATION_PASS = 1
};

typedef struct publisher_site_floor_rules_settings{
	int rule_id;
	int rule_meta_id;
	int rule_type;
	long pub_id;
	long site_id;
	unsigned int campaign_id;
	unsigned int dsp_id;
	int advertiser_id;
	int domain_id;
	int buyer_id;
	char segment[MAX_SEGMENT_EXPR_SIZE + 1];
	//floor_rule_user_segment_evaluation_result_t segment_evaluation_result;
	int user_segment_evaluation_result;
	char country_code[MAX_GEO_CODE_LEN+1];
	char region_code[MAX_GEO_CODE_LEN+1];
	char city_name[MAX_GEO_NAME_LEN+1];
	unsigned int ad_size_id;
	int fold_position_id;
	int dma_code;
	//floor_rule_geo_evaluation_result_t geo_evaluation_result;
	int geo_evaluation_result;
	double floor_ecpm;
	int priority;
	int currency_id ;
//	int override_flag;
	int start_time_parting;
	int end_time_parting;
	int days_of_week;
	int advertiser_category_id;
	char site_section [MAX_SITE_SECTION_SIZE + 1];
	int fixed_price_flag;
// Rule Evaluation result holders
	int time_parting_evaluation_result;
	int day_parting_evaluation_result;
	int ad_size_evaluation_result;
	int fold_position_evaluation_result;
	int site_section_evaluation_result;
	// Deal ID as entered by Publisher.
	char pub_deal_id[MAX_DEAL_ID_LEN + 1];
	int rich_media_creative_attribute_id;

	char active_entities[MAX_ACTIVE_ENTITY_SIZE+1];
	int active_entities_array[MAX_ACTIVE_ENTITIES]; ///this willl hold the id for active entities in in rule
	int active_entities_array_elements_count;
}publisher_site_floor_rules_settings_t;

typedef struct db_publisher_site_floor_rules_settings {
	SQLINTEGER s_rule_count;
	SQLLEN cb_rule_count;
	SQLINTEGER s_site_id;
	SQLLEN cb_site_id;
	SQLINTEGER s_publisher_id;
	SQLLEN cb_publisher_id;
	SQLINTEGER s_rule_id;
	SQLLEN cb_rule_id;
	SQLINTEGER s_rule_meta_id;
	SQLLEN cb_rule_meta_id;
	SQLINTEGER s_rule_type;
	SQLLEN cb_rule_type;
	SQLINTEGER s_floor_type;
	SQLLEN cb_floor_type;
	SQLINTEGER s_dsp_id;
 SQLLEN cb_dsp_id;
	SQLINTEGER s_advertiser_id;
 SQLLEN cb_advertiser_id;
	SQLINTEGER s_domain_id;
 SQLLEN cb_domain_id;
	SQLINTEGER s_buyer_id;
 SQLLEN cb_buyer_id;
	SQLINTEGER s_campaign_id;
 SQLLEN cb_campaign_id;
	SQLCHAR s_segment[MAX_SEGMENT_EXPR_SIZE + 1];
	SQLLEN cb_segment;
	SQLDOUBLE s_floor_ecpm;
	SQLLEN cb_floor_ecpm;
	SQLDOUBLE s_min_floor_ecpm;
	SQLLEN cb_min_floor_ecpm;
	SQLCHAR s_country_code[MAX_GEO_CODE_LEN+1];
	SQLLEN cb_country_code;
	SQLCHAR s_region_code[MAX_GEO_CODE_LEN+1];
	SQLLEN cb_region_code;
	SQLCHAR s_city_name[MAX_GEO_NAME_LEN+1];
	SQLLEN cb_city_name;
	SQLINTEGER s_dma_code;
	SQLLEN cb_dma_code;
	SQLINTEGER s_priority;
	SQLLEN cb_priority;
	SQLINTEGER s_fixed_price_flag;
	SQLLEN cb_fixed_price_flag;
	SQLCHAR s_active_entities[MAX_ACTIVE_ENTITY_SIZE+1];
	SQLLEN cb_active_entities;
	SQLINTEGER s_start_time_parting;
 SQLLEN cb_start_time_parting;
	SQLINTEGER s_end_time_parting;
 SQLLEN cb_end_time_parting;
	SQLINTEGER s_days_of_week;
 SQLLEN cb_days_of_week;
	SQLINTEGER s_ad_size_id;
	SQLLEN cb_ad_size_id;
	SQLINTEGER s_fold_position_id;
	SQLLEN cb_fold_position_id;
	SQLINTEGER s_dow_bitmask;
 SQLLEN cb_dow_bitmask;
	SQLINTEGER s_advertiser_category_id;
 SQLLEN cb_advertiser_category_id;
	SQLCHAR s_site_section [MAX_SITE_SECTION_SIZE + 1];
	SQLLEN cb_site_section;
	SQLINTEGER s_rich_media_creative_attribute_id;
 SQLLEN cb_rich_media_creative_attribute_id;
	SQLINTEGER s_line_item_id;
	SQLLEN  cb_line_item_id;
	SQLINTEGER s_pubconnect_campaign_id;
	SQLLEN cb_pubconnect_campaign_id;
	SQLINTEGER s_strategy_id;
	SQLLEN cb_strategy_id;
	SQLINTEGER s_matched_user;
	SQLLEN cb_matched_user;
	SQLINTEGER s_platform_id;
	SQLLEN cb_platform_id;
	SQLINTEGER s_currency_id;
	SQLLEN cb_currency_id ;
	SQLCHAR s_applicability;
	SQLLEN cb_applicability;
} db_publisher_site_floor_rules_settings_t;


typedef struct memcached_floor_rules {
	unsigned int nelements;
	ssize_t total_sizeof_protobuff_floor_rules;
} memcached_floor_rules_t;


#endif //__FLOOR_RULES_TYPES_H__ 



