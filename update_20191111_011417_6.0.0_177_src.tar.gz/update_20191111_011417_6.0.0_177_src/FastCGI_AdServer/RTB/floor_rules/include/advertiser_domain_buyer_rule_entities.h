/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef _ADVERTISER_DOMAIN_BUYER_RULE_ENTITIES_H__
#define _ADVERTISER_DOMAIN_BUYER_RULE_ENTITIES_H__
#include "db_connection.h"
#include "cache_types.h"
#include "rt_types.h"

int get_advertiser_and_domain_id(
                long pub_id,
                long site_id,
                db_connection_t* conn,
                cache_handle_t* cache,
                const publisher_site_ad_campaign_list_t* adcampaigns,
                rt_response_params_t* response_params,
                int rt_request_count,
                advertiser_domain_category_id_t *ad_domain_category_id_list,
                int ncategory
                );

int get_buyer_id(
		long pub_id,
		long site_id,
		db_connection_t* conn,
		cache_handle_t* cache,
		const publisher_site_ad_campaign_list_t* adcampaigns, 
		rt_response_params_t* response_params,
		int rt_request_count
		);

int get_advertiser_categories (
        int advertiser_id,
        int domain_id,
        rt_bid_response_params_t *bid_response_params,
        advertiser_domain_category_id_t *ad_domain_category_id_list,
        int ncategory
        );

#endif
