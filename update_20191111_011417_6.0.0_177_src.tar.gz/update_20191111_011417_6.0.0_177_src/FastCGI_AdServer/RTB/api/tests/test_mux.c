/*
   PubMatic Inc. ("PubMatic") CONFIDENTIAL
   Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "ad_server_types.h"
#include "rt_bidding.h"
#include <typedefs.h>
#include "rt_types.h"
#include "rtb_util.h"
#include "rt_campaign_config.h"
#include "campaign_data_provider_data.h"
#include "url_blocklist.h"
#include "cache_publisher_site_iframe_buster_tech.h"
#include "deal.h"
#include "mobile_header.h"
#include <error.h>
#include <errno.h>
#include "video.h"
#include "http_response_wrapper.h"
#include "win_loss_notification.h"
#include "url_categorization.h"
#include "mbf.h"
#include <assert.h>

#include <cmocka.h>
#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <curl/curl.h>
#include <typedefs.h>
#include <rt_types.h>
#include <rtb_util.h>

#include "libstats_util.h"
#include "curlstat_util.h"
#include "default_adapter.h"
#include "openrtb.h"
#include "mux.h"
#include "server_side_cookie_store.h"
#include "realtime_bidding_tasks.h"
#include "json_wrapper.h"
#include "logger.h"

int gbl_log_level = L_DEBUG;
struct curl_slist* header_list_post = NULL;
struct curl_slist* header_list_get = NULL;

extern int rtbnreplace(char* dest, char* src, 
						const rt_mux_info_t* rt_mux, 
						const rt_request_params_t *rt_request_params,
						const int c_idx,
						const int campaign_id,
						int* len_str,
						int *used_ad_size_index);

int __wrap_increment_stats_counters(){
	return 0;
}
int __wrap_get_winloss_info_str(char *dest,
								int max_len,
								int camp_id,
								const win_loss_table_t * wlt) {
	strcpy(dest, mock_ptr_type(char *));
	(void)max_len;
	(void) camp_id;
	(void)wlt;
	return mock_type(int);
}
int __wrap_default_process_response (
            void *response_buffer,
            size_t size,
            size_t nmemb,
            void* bid_response_params_ptr){
	return mock_type(int);
}
int __wrap_set_response_compress_flags(){
	return mock_type(int);
}
size_t __wrap_openrtb_process_header() {
	return mock_type(size_t);
}

int __wrap_get_guid(char **guid){
	return mock_type(int);
}
//Note: Error handling is left on user
int nstrcpy(char *dest, const char *src, size_t n) //Optimised strncpy
{
	size_t i;
	int lenstr = 0;

	for (i = 0; i < n && src[i] != '\0'; i++) {
		dest[i] = src[i];
		lenstr++;
	}

	if ( i < n )
		dest[i] = '\0';
	else{
		llog_write(L_DEBUG,"Info/Error: Buffer length exceeded its limit total buffer size %zu:%s:%d\n",n,__FILE__,__LINE__);
	}
	return lenstr;
}
uint8_t* __wrap_try_compression( const char* post_data, int* p_post_data_len, unsigned int campaign_id, uint8_t debug  ) {
	return mock_type(uint8_t*);
}
uint8_t __wrap_registerBuffer( buffer_tracker_t *p_buffer_tracker, uint8_t *buf ) {
	return mock_type(uint8_t);
}
int __wrap_rt_bidding_add_request(rt_handle_t *in_handle, CURL* curl_handle){
	return mock_type(int);
}
char * __wrap_get_current_timestamp(char *buff){
	return mock_type(char*);
}
void __wrap_copy_rt_response_params(rt_response_params_t *src, rt_response_params_t *dest){
}
const rt_request_url_params_mask_t * __wrap_get_realtime_campaign_config_for_campaign(
	unsigned long campaign_id,
	const rt_request_url_params_mask_t * rt_request_url_params_mask,
	int nelements
	){
	return mock_type(rt_request_url_params_mask_t*);
}
void __wrap_IncrReqCounter(int tid, int c){
}
void __wrap_logger_fill_cmpg_qps_logger(
	rt_response_params_t *rt_response_params,
	pm_json_object_t **pm_json_array){
	
}
static int multi_size_ptr[10];
typedef struct test_start_end{
	int start;
	int end;
}test_start_end_t;
typedef struct test_rtbnreplace_table{
	rt_mux_info_t rt_mux;
	test_start_end_t start_end[MAX_REPLACE_PARAMS];
	char *win_loss_str;
	char *src;
	char *expected_str;
}test_rtbnreplace_table_t;
static test_rtbnreplace_table_t test_rtbnreplace_arr[]={
	{//0 
		.rt_mux.protocol = 1,
		.rt_mux.multi_size_ptr = multi_size_ptr,
		.start_end[0].start=0,
		.start_end[1].start=0,
		.start_end[2].start=0,
		.start_end[3].start=146,
		.start_end[3].end=263,
		.win_loss_str = "",
		.src = "{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{\"wli\":{\"rId\":\"6C88D4B8-3594-479B-B793-B0E3AC7BEC32\",\"bCur\":\"USD\",\"wBid\":10,\"csa\":1,\"bInfo\":[{\"bId\":\"abc123\",\"st\":0}]}}}",
		.expected_str="{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{}}"
	},
	{//1 
		.rt_mux.protocol = 1,
		.rt_mux.multi_size_ptr = multi_size_ptr,
		.start_end[0].start=0,
		.start_end[1].start=0,
		.start_end[2].start=0,
		.start_end[3].start=146,
		.start_end[3].end=263,
		.win_loss_str = "\"wli\":{\"rId\":\"6C88D4B8-3594-479B-B793-B0E3AC7dsadsadBEC32\",\"bCur\":\"USD\",\"wBid\":10,\"csa\":1,\"bInfo\":[{\"bId\":\"adadasdsadsadbc123\",\"st\":0}]}",
		.src = "{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{\"wli\":{\"rId\":\"6C88D4B8-3594-479B-B793-B0E3AC7BEC32\",\"bCur\":\"USD\",\"wBid\":10,\"csa\":1,\"bInfo\":[{\"bId\":\"abc123\",\"st\":0}]}}}",
		.expected_str="{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{\"wli\":{\"rId\":\"6C88D4B8-3594-479B-B793-B0E3AC7dsadsadBEC32\",\"bCur\":\"USD\",\"wBid\":10,\"csa\":1,\"bInfo\":[{\"bId\":\"adadasdsadsadbc123\",\"st\":0}]}}}"
		},
	{//2 
		.rt_mux.protocol = 0,
		.rt_mux.multi_size_ptr = multi_size_ptr,
		.start_end[0].start=0,
		.start_end[1].start=0,
		.start_end[2].start=0,
		.start_end[3].start=146,
		.start_end[3].end=263,
		.win_loss_str = "",
		.src = "{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{\"wli\":{\"rId\":\"6C88D4B8-3594-479B-B793-B0E3AC7BEC32\",\"bCur\":\"USD\",\"wBid\":10,\"csa\":1,\"bInfo\":[{\"bId\":\"abc123\",\"st\":0}]}}}",
		.expected_str="{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{\"wli\":{\"rId\":\"6C88D4B8-3594-479B-B793-B0E3AC7BEC32\",\"bCur\":\"USD\",\"wBid\":10,\"csa\":1,\"bInfo\":[{\"bId\":\"abc123\",\"st\":0}]}}}"
	},
	{//3 
		.rt_mux.protocol = 1,
		.rt_mux.multi_size_ptr = multi_size_ptr,
		.start_end[0].start=0,
		.start_end[1].start=0,
		.start_end[2].start=0,
		.start_end[3].start=159,
		.start_end[3].end=276,
		.win_loss_str = "",
		.src = "{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{\"wlin\":\"abc\",\"wli\":{\"rId\":\"6C88D4B8-3594-479B-B793-B0E3AC7BEC32\",\"bCur\":\"USD\",\"wBid\":10,\"csa\":1,\"bInfo\":[{\"bId\":\"abc123\",\"st\":0}]},\"sb\":1}}",
		.expected_str="{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{\"wlin\":\"abc\",\"sb\":1}}"
	},
	{//4 
		.rt_mux.protocol = 2,
		.rt_mux.multi_size_ptr = multi_size_ptr,
		.start_end[0].start=0,
		.start_end[1].start=0,
		.start_end[2].start=0,
		.start_end[3].start=159,
		.start_end[3].end=276,
		.win_loss_str = "",
		.src = "{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{\"wlin\":\"abc\",\"wli\":{\"rId\":\"6C88D4B8-3594-479B-B793-B0E3AC7BEC32\",\"bCur\":\"USD\",\"wBid\":10,\"csa\":1,\"bInfo\":[{\"bId\":\"abc123\",\"st\":0}]},\"sb\":1}}",
		.expected_str="{\"id\":\"5D7ABEF1-9207-4D0F-B5EB-EA026FE29FFE\",\"imp\":[{\"id\":\"1\",\"video\":{\"api\":[1,2],\"ext\":{\"ploc\":\"-1x-1\"}}}],\"app\":{\"bundle\":\"1093108529\"},\"ext\":{\"wlin\":\"abc\",\"sb\":1}}"
	},
};

static void test_rtbnreplace(void **state){
		(void) state; /* unused */
		int len_str = 0;
		char destination[100000];
		rt_mux_info_t *mux = NULL;
		int i = 0;
		int j = 0;
		rt_request_params_t rt_request_params;
		rt_request_params.in_server_req_params = (ad_server_req_param_t*)malloc(sizeof(ad_server_req_param_t));
		rt_request_params.in_server_req_params->site_ad = (publisher_site_ad_t*)malloc(sizeof(publisher_site_ad_t));
		rt_request_params.fte_additional_params = (fte_additional_params_t*)malloc(sizeof(fte_additional_params_t));
		for(i =0; i < sizeof(test_rtbnreplace_arr)/sizeof(test_rtbnreplace_table_t);i++){
			len_str = 0;
			memset(destination,0,sizeof(destination));
			mux = &(test_rtbnreplace_arr[i].rt_mux);
			mux->replace_info[0].start = mux->replace_info[1].start = mux->replace_info[2].start =mux->replace_info[3].start = NULL;
			for(j = 0;j<4;j++){
				if (test_rtbnreplace_arr[i].start_end[j].start != 0){
					mux->replace_info[j].start = test_rtbnreplace_arr[i].src + test_rtbnreplace_arr[i].start_end[j].start;
				}
				if (test_rtbnreplace_arr[i].start_end[j].end != 0){
					mux->replace_info[j].end = test_rtbnreplace_arr[i].src + test_rtbnreplace_arr[i].start_end[j].end;
				}
			}
			if(test_rtbnreplace_arr[i].rt_mux.protocol > 0){
				will_return(__wrap_get_winloss_info_str, test_rtbnreplace_arr[i].win_loss_str);
				will_return(__wrap_get_winloss_info_str,strlen(test_rtbnreplace_arr[i].win_loss_str));
			}
			rtbnreplace(destination,
						test_rtbnreplace_arr[i].src, 
						mux, 
						&rt_request_params,
						0,
						100,
						&len_str,
						&len_str);
			assert_string_equal(destination,test_rtbnreplace_arr[i].expected_str);

		}

}

int main(){
		const struct CMUnitTest tests[] = { 
			cmocka_unit_test(test_rtbnreplace),
		};
	return cmocka_run_group_tests(tests, NULL, NULL);
}
