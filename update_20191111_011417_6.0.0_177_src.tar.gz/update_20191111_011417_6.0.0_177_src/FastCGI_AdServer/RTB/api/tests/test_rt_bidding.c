#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "ad_server_types.h"
#include "rt_bidding.h"
#include <typedefs.h>
#include "rt_types.h"
#include "rtb_util.h"
#include "rt_campaign_config.h"
#include "campaign_data_provider_data.h"
#include "url_blocklist.h"
#include "cache_publisher_site_iframe_buster_tech.h"
#include "deal.h"
#include "mobile_header.h"
#include <error.h>
#include <errno.h>
#include "video.h"
#include "http_response_wrapper.h"
#include "win_loss_notification.h"
#include "url_categorization.h"
#include "mbf.h"
#include <assert.h>
#define MAX_IPSTR_LEN   (46)
int g_allow_config_reload_flag = 0;
int g_curlstat_enabled_flag = 0;
int g_rtb_ms_timeout;
int g_mob_nw_timeout;
struct curl_slist* header_list_get = NULL;
struct curl_slist* header_list_post = NULL;
int gbl_log_level = L_DEBUG;
CURLcode __wrap_curl_easy_setopt(CURL *handle, CURLoption option, void *parameter){
    (void) handle;
    (void) option;
    (void) parameter;
    return CURLE_OK;
}

CURLMcode __wrap_curl_multi_add_handle(CURLM *multi_handle, CURL *easy_handle){
    (void) multi_handle;
    (void) easy_handle;
    return CURLM_OK;
}

CURLMcode __wrap_curl_multi_perform(CURLM *multi_handle, int *running_handles){
    (void) multi_handle;
    (void) running_handles;
    return CURLM_OK;
}

CURLMcode __wrap_curl_multi_remove_handle(CURLM *multi_handle, CURL *easy_handle){
    (void) multi_handle;
    (void) easy_handle;
    return CURLM_OK;
}

struct curl_slist *__wrap_curl_slist_append(struct curl_slist * list, const char * string ){
	struct curl_slist *slist=NULL;
	(void)list;
	(void)string;
	return slist;
}

CURL *__wrap_curl_easy_init( ){
	static CURL *curl;
	return curl;
}

CURLMcode __wrap_curl_multi_fdset(CURLM *multi_handle,
                           fd_set *read_fd_set,
                           fd_set *write_fd_set,
                           fd_set *exc_fd_set,
                           int *max_fd){
	(void)multi_handle;
	(void)read_fd_set;
	(void)write_fd_set;
	(void)exc_fd_set;
	(void)max_fd;
	return CURLM_OK;
}
void __wrap_json_append_escaped_string(char **buff, 
                                const char *name,  
                                const char *value, 
                                int add_separator, 
                                int max_len){
	(void)buff;
	(void)name;  
	(void)value; 
	(void)add_separator; 
	(void) max_len;
}

void __wrap_json_append_fixed_value_string(char **buff, const char *name, int len, int add_separator) {
}

void __wrap_json_encode_double_truncated(char **buff, char *name, double value, int add_separator){
}


int __wrap_default_process_response (
            void *response_buffer,
            size_t size,
            size_t nmemb,
            void* bid_response_params_ptr){
	return mock_type(int);
}

int __wrap_default_get_request_url(
        rt_request_params_t *rt_request_params,
        const rt_request_url_params_mask_t * rt_request_url_mask,
        rt_response_params_t *out_response_params,
        ad_server_additional_params_t *additional_parameter,
        char *request_url_with_mandatory_params,
        char* campaign_cookie,
        publisher_site_ad_campaign_list_t *adcampaigns
        ){
	return mock_type(int);
}
void __wrap_log_curlstat(CURL* curl_handle, const char *file, int line){
}

const char * __wrap_get_alpha3_from_alpha2(const char *country){
	return mock_type(char *);
}
int __wrap_IsValidTimeZone(const char *timezone){
	return mock_type(int);
}
void __wrap_compose_deals_params_post_data(char **post_data,
                                    publisher_site_ad_campaign_list_t *adcampaigns,
                                    const rt_request_url_params_mask_t * rt_request_url_params_mask1,
                                    fte_additional_params_t *fte_additional_parameters,
                                    int *flag){
}
int __wrap_get_winloss_info_str(char *dest, int max_len, int camp_id, const win_loss_table_t *wlt) {
	return mock_type(int);
}

const char* __wrap_get_header_value(
	const http_header_map_t* header_map,
	const char* key
	){
	return mock_type(char *);
}

int __wrap_cache_get_pubmatic_payment_tagid(
	cache_handle_t *cache,
	db_connection_t *dbconn,
	char *pubmatic_payment_tagid){
	strcpy(pubmatic_payment_tagid, mock_ptr_type(char *));
	return mock_type(int);
}
void __wrap_gdpr_object_creation_decision(ad_server_req_param_t* req_params,
		fte_additional_params_t *fte_additional_params,
		int dont_pass_iab_consent_obj,
		int *add_gdpr_ext,
		int *add_iab_gdpr_consent,
		int *add_eb_provider_list,
		char **eb_provider_list) {
}

static void test_truncate_ip_address(char *ip, char *required_ip){
	char *truncated_ip= (char*) malloc(MAX_IPSTR_LEN);
	truncate_ip_address(truncated_ip, ip);
	assert_string_equal(truncated_ip,required_ip);
}
static void test_truncate_ip_address_main(void **state){
	char * ip_list[][2]={
	{"172.16.4.63","172.16.4"},
	{"2001:0db8:85a3:0000:0000:8a2e:0370:7334","2001:0db8:85a3:0000:0000:8a2e"},
	{"2001:0db8:85a3:0370:7334::","2001:0db8:85a3:0370:7334:0000"},	
	{"::8a2e:0370:7334","0000:0000:0000:0000:0000:8a2e"},
	{"::ffff","0000:0000:0000:0000:0000:0000"}
	};
	int i=0;
	for(i=0; i<5; i++){
		test_truncate_ip_address(ip_list[i][0], ip_list[i][1]);
	}
	
}

static void test_truncate_xff(char *xff, char *required_xff){
	char *truncated_xff= (char*) malloc(MAX_LEN_XFF+1);
	//truncate_ip_address(truncated_ip, ip);
	truncate_xff(xff, truncated_xff);
	assert_string_equal(truncated_xff,required_xff);
}

static void test_truncate_xff_main(void **state){
	char * ip_list[][2]={
	{"172.16.4.63","172.16.4"},
	{"2001:0db8:85a3:0000:0000:8a2e:0370:7334","2001:0db8:85a3:0000:0000:8a2e"},
	{"2001:0db8:85a3:0370:7334::,::ffff","2001:0db8:85a3:0370:7334:0000,0000:0000:0000:0000:0000:0000"},	
	{"::8a2e:0370:7334","0000:0000:0000:0000:0000:8a2e"},
	{"172.16.4.63,2001:0db8:85a3:0370:7334::","172.16.4,2001:0db8:85a3:0370:7334:0000"}
	};
	int i=0;
	for(i=0; i<5; i++){
		test_truncate_xff(ip_list[i][0], ip_list[i][1]);
	}
	
}

static void test_append_pubmatic_pay_tagid(void **state){

	publisher_level_settings_t publisher_level_settings;
	cache_handle_t cache;
	db_connection_t dbconn;
	char pubmatic_payment_tagid[MAX_PUBMATIC_PAYMENT_TAGID_LEN+1];
	int retval;
	long pub_id = 31400;
	char payment_tagid_chain[MAX_PAYMENT_TAGID_CHAIN_LEN+1];
	pubmatic_payment_tagid[0] = '\0';
	payment_tagid_chain[0] = '\0';
	publisher_level_settings.is_aggregator = 1;
	publisher_level_settings.acl_aggregator_flag = 1;

	/*Test Case 1
	 *pubmatic_payment_tagid NULL
	 *payment_tagid_chain is NULL
	 *channel partner
	 */
	will_return( __wrap_cache_get_pubmatic_payment_tagid, pubmatic_payment_tagid);
	will_return( __wrap_cache_get_pubmatic_payment_tagid,ADS_ERROR_SUCCESS);
	retval = append_pubmatic_pay_tagid(&cache, &dbconn, &publisher_level_settings, pub_id, payment_tagid_chain);
	assert_string_equal(payment_tagid_chain, "");
	assert_int_equal(retval, ADS_ERROR_NOT_FOUND);

	/*Test Case 2
	 *ADS_ERROR_INTERNAL
	 *pubmatic_payment_tagid NULL
	 *payment_tagid_chain is NULL
	 *channel partner
	 */
	payment_tagid_chain[0] = '\0';
	will_return( __wrap_cache_get_pubmatic_payment_tagid, pubmatic_payment_tagid);
	will_return( __wrap_cache_get_pubmatic_payment_tagid, ADS_ERROR_INTERNAL);
	retval = append_pubmatic_pay_tagid(&cache, &dbconn, &publisher_level_settings, pub_id, payment_tagid_chain);
	assert_string_equal(payment_tagid_chain, "");
	assert_int_equal(retval, ADS_ERROR_NOT_FOUND);

	/*Test Case 3
	 *pubmatic_payment_tagid Present
	 *payment_tagid_chain is NULL
	 *channel partner
	 */
	strcpy(pubmatic_payment_tagid, "5555");
	will_return( __wrap_cache_get_pubmatic_payment_tagid, pubmatic_payment_tagid);
	will_return( __wrap_cache_get_pubmatic_payment_tagid,ADS_ERROR_SUCCESS);
	retval = append_pubmatic_pay_tagid(&cache, &dbconn, &publisher_level_settings, pub_id, payment_tagid_chain);
	assert_string_equal(payment_tagid_chain, "-5555:31400");
	assert_int_equal(retval, ADS_ERROR_SUCCESS);

	/*Test Case 4 
	 *pubmatic_payment_tagid 5555
	 *payment_tagid_chain is 8967:9078
	 *channel partner
	 */
	strcpy(payment_tagid_chain, "8967:9078");
	will_return( __wrap_cache_get_pubmatic_payment_tagid, pubmatic_payment_tagid);
	will_return( __wrap_cache_get_pubmatic_payment_tagid,ADS_ERROR_SUCCESS);
	retval = append_pubmatic_pay_tagid(&cache, &dbconn, &publisher_level_settings, pub_id, payment_tagid_chain);
	assert_string_equal(payment_tagid_chain, "8967:9078-5555:31400");
	assert_int_equal(retval, ADS_ERROR_SUCCESS);

	/*Test Case 5
	 *pubmatic_payment_tagid 5555
	 *payment_tagid_chain is 8967:9078
	 *direct publisher
	 */
	publisher_level_settings.acl_aggregator_flag = 0;
	strcpy(payment_tagid_chain, "8967:9078");
	will_return( __wrap_cache_get_pubmatic_payment_tagid, pubmatic_payment_tagid);
	will_return( __wrap_cache_get_pubmatic_payment_tagid,ADS_ERROR_SUCCESS);
	retval = append_pubmatic_pay_tagid(&cache, &dbconn, &publisher_level_settings, pub_id, payment_tagid_chain);
	assert_string_equal(payment_tagid_chain, "8967:9078-5555:31400");
	assert_int_equal(retval, ADS_ERROR_SUCCESS);


	/*Test Case 6
	 *pubmatic_payment_tagid 5555
	 *payment_tagid_chain is NULL
	 *direct publisher
	 */
	payment_tagid_chain[0] = '\0';
	will_return( __wrap_cache_get_pubmatic_payment_tagid, pubmatic_payment_tagid);
	will_return( __wrap_cache_get_pubmatic_payment_tagid,ADS_ERROR_SUCCESS);
	retval = append_pubmatic_pay_tagid(&cache, &dbconn, &publisher_level_settings, pub_id, payment_tagid_chain);
	assert_string_equal(payment_tagid_chain, "5555:31400");
	assert_int_equal(retval, ADS_ERROR_SUCCESS);

	/*Test Case 7
	 *pubmatic_payment_tagid NULL
	 *payment_tagid_chain is 8967:9078
	 *direct publisher
	 */
	strcpy(payment_tagid_chain, "8967:9078");
	pubmatic_payment_tagid[0] = '\0';
	will_return( __wrap_cache_get_pubmatic_payment_tagid, pubmatic_payment_tagid);
	will_return( __wrap_cache_get_pubmatic_payment_tagid,ADS_ERROR_SUCCESS);
	retval = append_pubmatic_pay_tagid(&cache, &dbconn, &publisher_level_settings, pub_id, payment_tagid_chain);
	assert_string_equal(payment_tagid_chain, "");
	assert_int_equal(retval, ADS_ERROR_NOT_FOUND);
}

int main(){
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_truncate_ip_address_main),
		cmocka_unit_test(test_truncate_xff_main),
		cmocka_unit_test(test_append_pubmatic_pay_tagid)
	};
	 return cmocka_run_group_tests(tests, NULL, NULL);
}
