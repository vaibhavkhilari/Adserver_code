/*
   PubMatic Inc. ("PubMatic") CONFIDENTIAL
   Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/

#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <curl/curl.h>
#include <typedefs.h>
#include <rt_types.h>
#include <rtb_util.h>
#include <ad_server_types.h>
#include <rt_campaign_config.h>
#include "campaign_data_provider_data.h"
#include "url_blocklist.h"
#include "cache_publisher_site_iframe_buster_tech.h"
#include "deal.h"
#include "mobile_header.h"
#include <error.h>
#include <errno.h>
#include "video.h"
#include "http_response_wrapper.h"
#include "win_loss_notification.h"
#include "url_categorization.h"
#include "mbf.h"
#include "libstats_util.h"
#include "curlstat_util.h"
#include "default_adapter.h"
#include "openrtb.h"
#include "mux.h"
#include "rtb_cookie_handler.h"
#include "server_side_cookie_store.h"
#include "realtime_bidding_tasks.h"
#include "json_wrapper.h"
#include "logger.h"
#include "fte_util.h"

extern int g_rtb_ms_connection_timeout;
extern int g_rtb_ms_timeout;
extern char* g_drproxy_url;
extern char* g_local_primary_drproxy_url;
extern char* g_local_secondary_drproxy_url;
extern struct curl_slist* header_list_get;
extern struct curl_slist* header_list_post;

char* OPENRTB_REPLACE_FORMAT[MAX_REPLACE_PARAMS] = { "\"id\":\"%s\"",
													 "\"w\":%d,\"h\":%d",
													 ",\"rid\":\"%s\"",
													 "%s"
};
char* PMRTB_REPLACE_FORMAT[MAX_REPLACE_PARAMS] = { "requestId=%s",
												   "&adWidth=%d&adHeight=%d",
												   "",
												   ""};

void copy_rt_response_params(rt_response_params_t *src, rt_response_params_t *dest);

void update_mux_camp_cookie_stats(libstat_counters_t *libstat_counters,
		int is_cookied,
		int is_digitrust,
		long campaign_id){
	if (1 == is_cookied){
		increment_stats_counters(libstat_counters, RTB_CAMP_COOKIED_REQ, campaign_id);
	}
	if (1 == is_digitrust){
		increment_stats_counters(libstat_counters, RTB_CAMP_EIDS_REQ, campaign_id);
	}
	if (1 == is_cookied && 1 == is_digitrust){
		increment_stats_counters(libstat_counters, RTB_CAMP_COOKIED_EIDS_REQ, campaign_id);
	}
}

void update_camp_cookie_stats(libstat_counters_t *libstat_counters,
		int is_cookied,
		int is_digitrust,
		long campaign_id){
	if (1 == is_cookied){
		increment_stats_counters(libstat_counters, RTB_TOTAL_CAMP_COOKIED_REQ, campaign_id);
	}
	if (1 == is_digitrust){
		increment_stats_counters(libstat_counters, RTB_TOTAL_CAMP_EIDS_REQ, campaign_id);
	}
	if (1 == is_cookied && 1 == is_digitrust){
		increment_stats_counters(libstat_counters, RTB_TOTAL_CAMP_COOKIED_EIDS_REQ, campaign_id);
	}
}
void update_pub_camp_eids_map(pub_camp_stats_map_t *pub_camp_stats_map,
		int is_cookied,
		int is_digitrust,
		long campaign_id){
	pub_camp_stats_map->camp_id = campaign_id;
	pub_camp_stats_map->eids = is_digitrust;
	pub_camp_stats_map->cookied = is_cookied;
}

/*
 * This function return the index of
 * Non Throttle Ad size
 */

static int get_valid_rtbnreplace_adsize(const rt_mux_info_t* rt_mux, const int c_idx , int *ad_size_index) {
	int ret = RTB_SUCCESS;
	int z;
	if (1 == rt_mux->multi_size_ptr[c_idx]){
		int found = 0;
		for(z = c_idx + 1; z < AD_DIMENSIONS_COUNT_MUX; z++){
			if (0 == rt_mux->multi_size_ptr[z]){
				found = 1;
				DEBUG_LOG("MUX_ERROR rtbnreplace:  Changing the Index old = %d new = %d", c_idx, z);
				*ad_size_index = z;
				rt_mux->multi_size_ptr[z] = 1; // Set it to 1 it will restric making duplicate request.
				break;
			}
		}
		if (0 == found) {
			DEBUG_LOG("MUX_ERROR rtbnreplace:  size was filter for this campaign index = %d", c_idx);
			ret = RTB_ERROR;
		}
	}
	return ret;
}
/*
 * replace rtb request params for mux
 */
STATIC int rtbnreplace(char* dest, char* src, 
		const rt_mux_info_t* rt_mux, 
		const rt_request_params_t *rt_request_params,
		const int c_idx,
		const int campaign_id,
		int* len_str,
		int *used_ad_size_index) {
	int i =0;
	char* *replace_format;
	char *strptr = NULL, *src_ptr = NULL;
	int space_left, len = 0;
	char win_loss_str[MAX_WINLOSS_STR_LEN + 1];
	*len_str = 0;
	int ad_size_index = c_idx;

	if (RTB_ERROR == get_valid_rtbnreplace_adsize(rt_mux, c_idx , &ad_size_index)){
		return RTB_ERROR;
	}
	*used_ad_size_index = ad_size_index;

	const adsize_t* ad_dimensions_from_tag = &(rt_request_params->in_server_req_params->site_ad->ad_dimensions_from_tag[ad_size_index]);
	if (rt_mux->protocol == PUBMATIC_RTB) {
		space_left = MAX_REQUEST_URL_SIZE + 1;
		replace_format = PMRTB_REPLACE_FORMAT;
	}
	else {
		space_left = MAX_POST_DATA_LEN + 1;
		replace_format = OPENRTB_REPLACE_FORMAT;
	}
	strptr = dest;
	src_ptr = src;

	for (i=0; i<MAX_REPLACE_PARAMS; i++) {
		//continue to next replace param if start is NULL.. Case : no further replacement needed for video/native
		if (!(rt_mux->replace_info[i].start) || '\0' == replace_format[i][0])
			continue;
		len = rt_mux->replace_info[i].start - src_ptr;
		snprintf(strptr, len+1, "%s", src_ptr);
		//llog_write(L_DEBUG,"\nMUX_REPLACE:%d | src:%s | mid:%s | dest:%s\n",k++,src,strptr,dest);
		space_left -= len;
		strptr = strptr + len;
		
		switch(i) {
			case RT_REQUEST_ID:
			case RT_SCO_REQUEST_ID:
				{
					len = sprintf(strptr, replace_format[i], rt_request_params->request_url_params.request_id[c_idx]);
					if (len >= space_left) {
						llog_write(L_DEBUG, "MUX_ERROR:: BUFFER OVERFLOW IN CREATING THE MUX REQUEST, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
						return RTB_ERROR;
					}
					//llog_write(L_DEBUG,"\nMUX_REPLACE:%d | src:%s | mid:%s | dest:%s\n",k++,src,strptr,dest);
					space_left -= len;
					strptr = strptr + len;
					break;
				}
			case RT_AD_SIZE:
				{
					if (rt_mux->mux_mode != MULTI_AD_SIZE_MUX){
						len = rt_mux->replace_info[RT_AD_SIZE].end - rt_mux->replace_info[RT_AD_SIZE].start;
						snprintf(strptr, len+1, "%s", rt_mux->replace_info[RT_AD_SIZE].start);
					}
					else {
						len = sprintf(strptr, replace_format[RT_AD_SIZE], 
								ad_dimensions_from_tag->ad_width, ad_dimensions_from_tag->ad_height);
						if (len >= space_left) {
							llog_write(L_DEBUG, "MUX_ERROR:: BUFFER OVERFLOW IN CREATING THE MUX REQUEST, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
							return RTB_ERROR;
						}
					}
					//llog_write(L_DEBUG,"\nMUX_REPLACE:%d | src:%s | mid:%s | dest:%s\n",k++,src,strptr,dest);
					space_left -= len;
					strptr = strptr + len;
					break;
				}
			case RT_WINLOSS_DATA:
				{
					len = get_winloss_info_str(win_loss_str,
										 (MAX_WINLOSS_STR_LEN < space_left) ? MAX_WINLOSS_STR_LEN:space_left,
										 campaign_id,
										 rt_request_params->fte_additional_params->wlt);
					if(len > 0){//win loss enabled need to update win loss info
						win_loss_str[len] = '\0';
						sprintf(strptr, replace_format[RT_WINLOSS_DATA],win_loss_str);
						space_left -= len;
						strptr = strptr + len;
					}else{
						//remove , if any
						if( *(strptr - 1) == ','){
							strptr--;
							space_left++;
						}
					}
					break;
				}
			default:
				{
					llog_write(L_DEBUG, "\nMUX_ERROR:%d: INVALID REPLACE PARAMETER %s:%d\n", 
							rt_mux->mux_mode, __FILE__, __LINE__);
					break;
				}
		}
		src_ptr = rt_mux->replace_info[i].end;
	}

	len = snprintf(strptr, space_left, "%s", src_ptr);
	if (len >= space_left) {
		llog_write(L_DEBUG, "ERROR BUFFER OVERFLOW IN CREATING THE MUX REQUEST, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
		return RTB_ERROR;
	}
	//llog_write(L_DEBUG,"\nMUX_REPLACE:%d | src:%s | mid:%s | dest:%s | fmts:%s:%s\n",k++,src,strptr,dest,replace_format[RT_REQUEST_ID],replace_format[RT_AD_SIZE]);
	space_left -= len;
	strptr = strptr + len;

	*len_str = strptr - dest;
	
	return RTB_SUCCESS;
}


static struct curl_slist* mux_rtb_req_proxy_get_headers(
		struct curl_slist** header_list, 
		int *size_header_list, 
		const int protocol,
		uint8_t compressed_request,
		const int post_data_len,
		char *x_purl_buff) {
	struct curl_slist *result = NULL;
	if (post_data_len > 0) { 
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "Content-Type:application/json");
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "Expect:");
	}
  
	if( compressed_request )
	{
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "Content-Encoding: gzip");
	}

	if (protocol == OPENRTB)
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "x-openrtb-version: 2.1");
	else if (protocol == OPENRTB2_3)
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "x-openrtb-version: 2.3");
	else if (protocol == OPENRTB2_5)
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "x-openrtb-version: 2.5");


	result = header_list[*size_header_list] ;
 
	(*size_header_list)++;
#ifdef DEBUG
	if( x_purl_buff[0] != '\0' )
	{
		llog_write(L_DEBUG, "\nMUX:: proxy: hdr: %s, data = %s, next = %p, size_of_header_lists = %d\n", 
				x_purl_buff, result->data,
				result->next, *size_header_list);
	}
#else
	(void) x_purl_buff;
#endif

	return result;
}


/*
 * set all options to easy handle for mux
 */
static int rt_curl_easy_setopt(CURL *easy_handle,
		rt_request_params_t *in_request_params,
		rt_response_params_t *out_response_params,
		const char* request_url,
		const char* post_data,
		const int post_data_len,
		const int protocol,
		const char* drproxy_dsp_url,
		uint8_t compressed_request,
		uint8_t bidresponse_compress,
		void *header_list_x,
		int *size_header_list,
	        long campaign_id ,
		int adstimeout) {
	(void) in_request_params;

	CURLcode curl_retval=CURLE_OK;	
	struct curl_slist *hdr = NULL;

	struct curl_slist **header_list = (struct curl_slist**) header_list_x;

	curl_retval = curl_easy_setopt(easy_handle, 
			CURLOPT_URL, 
			request_url);
	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}

	curl_retval = curl_easy_setopt(easy_handle,
			CURLOPT_WRITEFUNCTION,
			default_process_response);
	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}

	curl_retval = curl_easy_setopt(easy_handle,
			CURLOPT_WRITEDATA, 
			(void *)&(out_response_params->bid_response_params));
	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}

	curl_retval = curl_easy_setopt(easy_handle,
			CURLOPT_NOSIGNAL, 1);
	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}

	if( bidresponse_compress )
	{
		curl_retval = set_response_compress_flags( easy_handle ) ;
		if(curl_retval != CURLE_OK ){
                  return(RTB_ERROR);
		}
	}


	if (post_data_len > 0 && post_data[0] != '\0') {

		//set post headers
		hdr = header_list_post;

		curl_retval =  curl_easy_setopt(easy_handle, 
				CURLOPT_POSTFIELDSIZE, 
				post_data_len);
		if(curl_retval != CURLE_OK ){
			return(RTB_ERROR);
		}

		curl_retval =  curl_easy_setopt(easy_handle, 
				CURLOPT_POSTFIELDS, 
				post_data);
		if(curl_retval != CURLE_OK ){
			return(RTB_ERROR);
		}
	}
	else {
		//set get headers
		hdr = header_list_get;
		
		curl_retval = curl_easy_setopt(easy_handle,
				CURLOPT_HTTPGET, 
				1L);
		if(curl_retval != CURLE_OK ){
			return(RTB_ERROR);
		}
	}

	char x_purl_buff[1024];
	x_purl_buff[0] = '\0' ;

	const char* proxy_url = NULL;

	if (NULL != drproxy_dsp_url) {
		proxy_url = drproxy_dsp_url;
	}

	if (NULL != proxy_url) {
		char header[32];
		int n = snprintf(header, 32, "X-cid: %ld", campaign_id);
		if (32 <= n) {
			ERROR_LOG("String buffer overflow while writing X-cid.  Buffer length required = %d", n); 
		}   
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list],header);

		sprintf(x_purl_buff, "X-purl: %s", proxy_url );
		
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list],x_purl_buff);
		//append timeout
		snprintf(header, sizeof(header)-1, REQ_ADSERVER_TIMEOUT_HEADER_TEMPLATE, adstimeout );
		header[sizeof(header)-1] = '\0';
		
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list],header);
	}

	if (protocol != PUBMATIC_RTB) 
	{		
		hdr = mux_rtb_req_proxy_get_headers(header_list, size_header_list, protocol,
				compressed_request, post_data_len, x_purl_buff); 
	}

	// for PUBMATIC_RTB, hdr = header_list_get OR header_list_post

	curl_retval =  curl_easy_setopt(easy_handle,
			CURLOPT_HTTPHEADER, 
			hdr);

	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}

	if (protocol == PUBMATIC_RTB) {

		curl_retval = curl_easy_setopt(easy_handle, 
				CURLOPT_HEADERFUNCTION, 
				NULL);      
		if(curl_retval != CURLE_OK ){
			return(RTB_ERROR);
		}

		curl_retval = curl_easy_setopt(easy_handle, 
				CURLOPT_HEADERDATA, 
				NULL);
		if(curl_retval != CURLE_OK ){
			return(RTB_ERROR);
		}
	}
	else { //OPENRTB or OPENRTB2_3
		curl_retval = curl_easy_setopt(easy_handle, 
				CURLOPT_HEADERFUNCTION, 
				openrtb_process_header);      
		if(curl_retval != CURLE_OK ){
			return(RTB_ERROR);
		}

		curl_retval = curl_easy_setopt(easy_handle, 
				CURLOPT_HEADERDATA, 
				(void *)&(out_response_params->bid_response_params));
		if(curl_retval != CURLE_OK ){
			return(RTB_ERROR);
		}
	}


	/* Keeping high versose level for testing and debugging */
#ifdef FUNCTIONAL_TESTING_LOGGER_CURL
	curl_easy_setopt(easy_handle,CURLOPT_VERBOSE, 1);
#endif

	/* we are done with setting up the request */
	return(RTB_SUCCESS);
}

/*
 * prepare request url, post data for mux enabled campaigns
 * add easy handles to multi
 */
int prepare_mux_requests(rt_mux_info_t rt_mux[],
		const int mux_campaign_count,
		int *max_rt_batch_count,
		int *rt_requests_count,
		rt_response_params_t *rt_response_params,
		rt_request_params_t *rt_request_params,
		char post_data[][MAX_POST_DATA_LEN + 1],
		int *curl_handle_count,
		void *header_list_x,
		int *size_header_list,
		const int rtb_debug_flag,
		ad_server_additional_params_t* additional_parameters,
		const rt_request_url_params_mask_t *rt_request_url_params_mask,
		int cache_ret_cnt,
		buffer_tracker_t *p_buffer_tracker,
		int adstimeout,
		int pub_camp_stats_map_cnt) {

	int rt_call_status=0, i=0, j=0;
	int url_len=0, post_data_len=0;
	char buff[26] = {0}; /* realtime timestamp tmp buffer */
	CURL *easy_handle = NULL;
	const int stats_collection_enable = additional_parameters->adserver_config_params->stats_collection_enable;
	impression_level_stat_t * impression_level_stats = &additional_parameters->impression_level_stats;
	rt_handle_t* rt_handle = &(rt_request_params->fte_additional_params->realtime_api_handle); //real time api handle
	fte_additional_params_t *fte_additional_params = rt_request_params->fte_additional_params;
	// j starts from 1 as 0th request is already generated in campaign loop
	for (j=1; j <= *max_rt_batch_count; j++) {

		//Generate reuqest id for a batch j
		char *unique_id = NULL; /* Unique ID for real time API request */

		if (*rt_requests_count>=MAX_REALTIME_REQUESTS) {
			*max_rt_batch_count = j-1;
			llog_write(L_DEBUG,"\nRTB_WARNING: MAX RTB REQUESTS LIMIT=%d IS REACHED\n",MAX_REALTIME_REQUESTS);
			break;
		}

		/* Create an unique ID for the realtime API request */
		get_guid(&unique_id);
		if (unique_id) {
			nstrcpy(rt_request_params->request_url_params.request_id[j], unique_id, MAX_UNIQUE_ID_LEN - 1);
			rt_request_params->request_url_params.request_id[j][MAX_UNIQUE_ID_LEN - 1] = '\0';

			free(unique_id);
			unique_id = NULL;
		} else {
			rt_request_params->request_url_params.request_id[j][0] = '\0';
		}


		//iterate over mux enabled camapigns in batches 
		for (i=0; (i<mux_campaign_count) && (*rt_requests_count<MAX_REALTIME_REQUESTS); i++) {

			//skip the campaign as its max_multi_requests limit reached
			if (rt_mux[i].max_multi_requests<=0)
				continue;
			
			char *printfbuf = NULL ;

			if( rt_mux[i].protocol == PUBMATIC_RTB )
			{
				printfbuf= "PUBMATIC RTB"  ;
			}
			else if( rt_mux[i].protocol == OPENRTB2_3 )
			{
				printfbuf =  "OPENRTB 2.3"  ;
			}
			else if( rt_mux[i].protocol == OPENRTB2_5 )
			{
				printfbuf = "OPENRTB 2.5" ;
			}
			else
			{
				printfbuf = "OPENRTB" ;
			}

			if ( rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB) {

			
				llog_write(L_DEBUG,"\nMUX:%d: CREATING %s REQUEST FOR CAMPAIGN :%ld REQ_ID:%s",
						rt_mux[i].mux_mode, printfbuf,
						rt_response_params[rt_mux[i].orig_request_index].campaign_id,
						rt_request_params->request_url_params.request_id[j]);
				if (j==1)
					llog_write(L_DEBUG,"\nMUX:%d: cid:%ld max_multi_requests:%d\n",
							rt_mux[i].mux_mode,
							rt_response_params[rt_mux[i].orig_request_index].campaign_id,
							rt_mux[i].max_multi_requests);
			}

			easy_handle = rt_request_params->fte_additional_params->curl_handle_cache[*curl_handle_count];

			if (!easy_handle) {
				easy_handle = curl_easy_init(); 
				if (!easy_handle) {
					llog_write(L_DEBUG,"\nMUX_ERROR: Curl easy handle failed %s:%d\n",__FILE__,__LINE__);
					goto end_loop;
				}
			}

			// copy request url
			char* request_url = rt_response_params[*rt_requests_count].bid_response_params.request_url;
			char* request_url_0 = rt_response_params[rt_mux[i].orig_request_index].bid_response_params.request_url;

			url_len = 0;
			int used_ad_size_index = j;
			if (rt_mux[i].protocol == PUBMATIC_RTB) {
			  if (RTB_ERROR == rtbnreplace(request_url, request_url_0, &rt_mux[i], rt_request_params, j,rt_response_params[rt_mux[i].orig_request_index].campaign_id, &url_len, &used_ad_size_index)) {
					DEBUG_LOG("MUX_ERROR:%d: Failed to replace params in request url:%s\n", rt_mux[i].mux_mode, request_url);
					goto end_loop;
				}
			}
			else {
				url_len = nstrcpy(rt_response_params[*rt_requests_count].bid_response_params.request_url, rt_response_params[rt_mux[i].orig_request_index].bid_response_params.request_url, MAX_REQUEST_URL_SIZE + 1);
				rt_response_params[*rt_requests_count].bid_response_params.request_url[MAX_REQUEST_URL_SIZE] = '\0';
			}

			if ( rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB) {
				llog_write(L_DEBUG,"\nMUX:%d: %s: Request URL is '%s', cId:%ld",
						rt_mux[i].mux_mode, printfbuf,
						rt_response_params[*rt_requests_count].bid_response_params.request_url,
						rt_response_params[rt_mux[i].orig_request_index].campaign_id);
			}

			post_data_len = 0;
			//set post data to mux handle, post data can be empty in case of PUBMATIC_RTB
			if (post_data[rt_mux[i].orig_request_index][0] != '\0') {
				// copy post data
				if (rt_mux[i].protocol == PUBMATIC_RTB) {
					post_data_len = nstrcpy(post_data[*rt_requests_count], post_data[rt_mux[i].orig_request_index], MAX_POST_DATA_LEN + 1);
				}
				else if (RTB_ERROR == rtbnreplace(post_data[*rt_requests_count], post_data[rt_mux[i].orig_request_index], &rt_mux[i], rt_request_params, j, rt_response_params[rt_mux[i].orig_request_index].campaign_id, &post_data_len,&used_ad_size_index)) {
					DEBUG_LOG("MUX_ERROR:%d: Failed to replace params in post data:%s protocol:%d\n",
							rt_mux[i].mux_mode, post_data[rt_mux[i].orig_request_index], rt_mux[i].protocol);
					goto end_loop;
				}
			}

			if (!request_url || (rt_mux[i].protocol != PUBMATIC_RTB && post_data[*rt_requests_count][0] == '\0')) {
				llog_write(L_DEBUG,"\nMUX_WARNING:%d: No request data for cam:%ld\n", 
						rt_mux[i].mux_mode,	rt_response_params[rt_mux[i].orig_request_index].campaign_id);
				goto end_loop;
			}

			post_data[*rt_requests_count][post_data_len]='\0';
#ifdef RTB_JSON_TESTING
			validate_json(post_data[*rt_requests_count]);
#endif

			if( rt_request_params->in_server_req_params->wakanda_enabled )
			{
				dsp_message_t *dsp_msg = (dsp_message_t*)malloc( sizeof(dsp_message_t) ) ;
				dsp_msg->message = strndup( post_data[*rt_requests_count], post_data_len ) ;
				dsp_msg->message_len = post_data_len ;
				dsp_msg->campaignid = rt_response_params[rt_mux[i].orig_request_index].campaign_id ;
				dsp_msg->next = rt_request_params->fte_additional_params->dsp_req ;

				rt_request_params->fte_additional_params->dsp_req = dsp_msg ;
			}

			size_t org_post_data_len = post_data_len; //Used for only debugging
			uint8_t *compressed_buf = NULL ;
			uint8_t bidresponse_compress = ( rt_mux[i].protocol == PUBMATIC_RTB ) ? ( 0 ) : ( rt_mux[i].bidresponse_compress ) ;

			if( rt_mux[i].protocol != PUBMATIC_RTB &&
				rt_mux[i].bidrequest_compress )
			{
				compressed_buf = try_compression( post_data[*rt_requests_count], &post_data_len,
						rt_response_params[rt_mux[i].orig_request_index].campaign_id,
						( rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB )) ;

				if( compressed_buf )
				{
					registerBuffer( p_buffer_tracker, compressed_buf ) ;
				}
			}

			rt_call_status = rt_curl_easy_setopt(easy_handle,
					rt_request_params,
					&rt_response_params[*rt_requests_count],
					request_url,
					 ( compressed_buf ) ? ( (char*)compressed_buf ) : ( post_data[*rt_requests_count] ),
					post_data_len,
					rt_mux[i].protocol,
					rt_mux[i].drproxy_dsp_url,
					( compressed_buf != NULL ),
					bidresponse_compress,
					header_list_x,
					size_header_list,
					rt_response_params[rt_mux[i].orig_request_index].campaign_id,
					adstimeout);

			if( rt_call_status != 0 ) {
				llog_write(L_DEBUG,"\nMUX:%d: Could not create RT request for campaign id: %ld, Response code was: %d\n",
						rt_mux[i].mux_mode,
						rt_response_params[rt_mux[i].orig_request_index].campaign_id, 
						rt_call_status);
			} else {

				if (rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB) {
					llog_write(L_DEBUG,"\nMUX:%d: cid: %ld compressed_post_data_len=%d org_post_data_len=%lu and post_data = ",
							rt_mux[i].mux_mode, 
							rt_response_params[rt_mux[i].orig_request_index].campaign_id, post_data_len, org_post_data_len);
					llog_write(L_DEBUG,"%.*s\n", (int)org_post_data_len, post_data[*rt_requests_count]);
				}

				// make a call to the bidding API module to add the request to the queue 
				rt_call_status = rt_bidding_add_request(rt_handle, easy_handle);

				if( rt_call_status != RTB_SUCCESS ) {
					llog_write(L_DEBUG,"\nMUX ERROR [%s] Could not add RT request to queue, Response code was: %d",
							get_current_timestamp(buff), rt_call_status);
				}
				else {

					//increment direct dsp requests count by 1
					(*curl_handle_count)++;

					//copy campaign settings from orig rt_response_params
					copy_rt_response_params(&rt_response_params[rt_mux[i].orig_request_index], &rt_response_params[*rt_requests_count]);

					//keep request_id, ad_size_id for logging purpose
					rt_response_params[*rt_requests_count].rt_req_id_index = j;
					if (rt_mux[i].mux_mode == MULTI_AD_SIZE_MUX){
						memcpy(&(rt_response_params[*rt_requests_count].req_ad_dimensions_from_tag), &(rt_request_params->in_server_req_params->site_ad->ad_dimensions_from_tag[used_ad_size_index]), sizeof(adsize_t));
						memcpy(&(rt_response_params[*rt_requests_count].res_ad_dimension), &(rt_request_params->in_server_req_params->site_ad->ad_dimensions_from_tag[used_ad_size_index]), sizeof(adsize_t));
						DEBUG_LOG(" MUX INFO camp_id=%ld wxh=%dx%d and ad_size_id=%d used_ad_size_index=%d\n ", rt_response_params[*rt_requests_count].campaign_id, rt_response_params[*rt_requests_count].req_ad_dimensions_from_tag.ad_width, rt_response_params[*rt_requests_count].req_ad_dimensions_from_tag.ad_height,rt_response_params[*rt_requests_count].req_ad_dimensions_from_tag.ad_size_id,used_ad_size_index);
					}
					if (rtb_debug_flag) {
						llog_write(L_DEBUG,"\nMUX [%s] Realtime request added to queue: campaign %ld",
								get_current_timestamp(buff), 
								rt_response_params[*rt_requests_count].campaign_id);
					}
					// Added by kartik for ATT(adaptive timedout throttling)
					const rt_request_url_params_mask_t *const rtc_settings = get_realtime_campaign_config_for_campaign(rt_response_params[*rt_requests_count].campaign_id, rt_request_url_params_mask, cache_ret_cnt);
					// Update the counter in case ATT is enabled
					if (rtc_settings != NULL && (rtc_settings ->att_bitmap == ATT_ENABLED || rtc_settings ->att_bitmap == ATT_DISABLED_FOR_SYNCED_USER)) {
#ifdef ATT
						llog_write(L_DEBUG, "\nATT Incrementing the request counter for campaign %ld\n", rt_response_params[*rt_requests_count].campaign_id);
#endif
						IncrReqCounter(rt_request_params->fte_additional_params->fte_handle.thread_id, rt_response_params[*rt_requests_count].campaign_id);
					}

					if(stats_collection_enable == 1) {
						/*
						 * here, we increment total rtb_requests counter 
						 * as well as mux mode specific counter 
						 */
						if (rt_mux[i].mux_mode == MULTI_AD_SIZE_MUX){
							increment_stats_counters(&(rt_request_params->fte_additional_params->libstat_counters[0]),RTB_MULTI_ADSIZE_REQUESTS_ID, rt_response_params[*rt_requests_count].campaign_id);
						}
						else{
							increment_stats_counters(&(rt_request_params->fte_additional_params->libstat_counters[0]),RTB_MUX_REQUESTS_ID, rt_response_params[*rt_requests_count].campaign_id);
						}
						if(CHECK_CONTROL_BIT(rt_mux[i].enable_camp_syncup_stats, CAMP_EIDS_STATS_ENABLE)){
							update_mux_camp_cookie_stats(&(fte_additional_params->libstat_counters[0]),
									rt_response_params[*rt_requests_count].dsp_user_match_found,
									rt_response_params[*rt_requests_count].digitrust_id_present,
									rt_response_params[*rt_requests_count].campaign_id);
						}
						if ( (CHECK_CONTROL_BIT(rt_mux[i].enable_camp_syncup_stats, CAMP_PUB_EIDS_STATS_ENABLE))
								&& (CHECK_CONTROL_BIT(fte_additional_params->publisher_level_settings.enable_pub_syncup_stats, PUB_CAMP_EIDS_STATS_ENABLE))
								&& NULL != fte_additional_params->pub_camp_stats_map){
							update_pub_camp_eids_map(&(fte_additional_params->pub_camp_stats_map[pub_camp_stats_map_cnt]),
									rt_response_params[*rt_requests_count].dsp_user_match_found,
									rt_response_params[*rt_requests_count].digitrust_id_present,
									rt_response_params[*rt_requests_count].campaign_id);
									pub_camp_stats_map_cnt ++;
							fte_additional_params->pub_camp_stats_map[pub_camp_stats_map_cnt].camp_id = 0;
						}


					}

					logger_fill_cmpg_qps_logger(&(rt_response_params[*rt_requests_count]), &(fte_additional_params->qps_logging_params.qps_cmpg_logger_array), rt_mux[i].openbid_multisz_format_enabled);

					//increment total rtb requests count only if handle added successfully
					*rt_requests_count = *rt_requests_count + 1;
					INCREMENT_IMPRESSION_LEVEL_STAT(rtb_request);

				}
			}

end_loop: 

			rt_mux[i].max_multi_requests--;
		}
	}

	return RTB_SUCCESS;
}
