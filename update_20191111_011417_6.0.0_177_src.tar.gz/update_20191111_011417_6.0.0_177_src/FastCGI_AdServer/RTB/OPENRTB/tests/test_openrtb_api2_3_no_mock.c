#include <stddef.h>
#include <stdarg.h>
#include <setjmp.h>
#include <cmocka.h>
#include <stdio.h>
#include <string.h>

#include "bid_util.h"
#include "openrtb.h"

#define POST_DATA_SIZE_BAPP_OBJECT 500
#define POST_DATA_SIZE_BAPP_PRE 100
static char post_data_bapp[POST_DATA_SIZE_BAPP_OBJECT];
static char post_data_bapp_poison[POST_DATA_SIZE_BAPP_OBJECT];
typedef struct testcase_openrtb_request_append_bapp_object_ {
	int test_case_id;
	struct test_input_openrtb_request_append_bapp_object {
		bapp_info_t const bapp_info;
		char * const post_data_buf_ptr;
	} test_input;
	struct expected_output_openrtb_request_append_bapp_object {
		const char *post_data;
		const char *post_data_buf_ptr ;
	} const expected_output;
} testcase_openrtb_request_append_bapp_object_t;

static testcase_openrtb_request_append_bapp_object_t testcases_openrtb_request_append_bapp_object[] = {
	{
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
#define STR "[\"app1\",\"app2\",\"app3\",\"app4\"]"
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR),
			},
			.post_data_buf_ptr = ((char*)&post_data_bapp) + POST_DATA_SIZE_BAPP_PRE,
		},
		.expected_output = {
#define OSTR ",\"bapp\":"STR
			.post_data = OSTR,
			.post_data_buf_ptr = ((char *)&post_data_bapp) + POST_DATA_SIZE_BAPP_PRE + strlen(OSTR),
#undef OSTR
#undef STR

		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
#define STR "[\"app1\"]"
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR),
			},
			.post_data_buf_ptr = ((char*)&post_data_bapp) + POST_DATA_SIZE_BAPP_PRE,
		},
		.expected_output = {
#define OSTR ",\"bapp\":"STR
			.post_data = OSTR,
			.post_data_buf_ptr = ((char *)&post_data_bapp) + POST_DATA_SIZE_BAPP_PRE + strlen(OSTR),
#undef OSTR
#undef STR

		}
	},
	{ /* ignore characters after json_len characters */
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
#define EXTRASTR "someextrastring"
#define STR "[\"app1\",\"app2\",\"app3\"]"EXTRASTR
				.bapp_egress_json = STR,
				.bapp_egress_json_len = (strlen(STR) - strlen(EXTRASTR)),
#undef STR
			},
			.post_data_buf_ptr = ((char*)&post_data_bapp) + POST_DATA_SIZE_BAPP_PRE,
		},
		.expected_output = {
#define OSTR ",\"bapp\":[\"app1\",\"app2\",\"app3\"]"
			.post_data = OSTR,
			.post_data_buf_ptr = ((char *)&post_data_bapp) + POST_DATA_SIZE_BAPP_PRE + strlen(OSTR),
#undef OSTR
		}
	},
	{ /* json_len = 0 */
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
#define STR "somestring"
				.bapp_egress_json = STR,
				.bapp_egress_json_len = 0,
#undef STR
			},
			.post_data_buf_ptr = ((char*)&post_data_bapp) + POST_DATA_SIZE_BAPP_PRE,
		},
		.expected_output = {
#define OSTR ""
			.post_data = OSTR,
			.post_data_buf_ptr = ((char *)&post_data_bapp) + POST_DATA_SIZE_BAPP_PRE + strlen(OSTR),
#undef OSTR
		}
	},
};

#define POISON_BAPP '`'
void test_openrtb_request_append_bapp_object(void **state) {
	(void) state;
	int testcase_count = sizeof(testcases_openrtb_request_append_bapp_object) / sizeof(testcase_openrtb_request_append_bapp_object_t);
	int i = 0;
	char * post_temp_ptr = NULL;
	testcase_openrtb_request_append_bapp_object_t * const testcases = testcases_openrtb_request_append_bapp_object;
	for(i=0; i<testcase_count; i++) {
		printf("Executing Test case %d (%d) for openrtb_request_append_bapp_object.\n", i, testcases[i].test_case_id);
		memset(post_data_bapp, POISON_BAPP, sizeof(post_data_bapp));
		memset(post_data_bapp_poison, POISON_BAPP, sizeof(post_data_bapp_poison));
		post_temp_ptr = testcases[i].test_input.post_data_buf_ptr;
		openrtb_request_append_bapp_object(&post_temp_ptr,
										   &(testcases[i].test_input.bapp_info));

		assert_ptr_equal(testcases[i].expected_output.post_data_buf_ptr,
						 post_temp_ptr);

		assert_true(*post_temp_ptr == POISON_BAPP);
		*post_temp_ptr  = '\0'; /* needed for assert_string_equal */
		assert_string_equal(testcases[i].expected_output.post_data,
							testcases[i].test_input.post_data_buf_ptr);
		memset(testcases[i].test_input.post_data_buf_ptr, POISON_BAPP, strlen(testcases[i].expected_output.post_data) + 1);
		assert_memory_equal(post_data_bapp_poison, post_data_bapp, sizeof(post_data_bapp));
	}
}

int main(){
    const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_openrtb_request_append_bapp_object),
    };
	return cmocka_run_group_tests(tests, NULL, NULL);
}
