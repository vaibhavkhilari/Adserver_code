#ifndef __OPENRTB_API_MOCK_FUNC_H__
#define __OPENRTB_API_MOCK_FUNC_H__

#define O_DEVICE_IP "ip"
#define O_DEVICE_IPV6 "ipv6"
struct curl_slist* header_list_openrtb = NULL;
struct curl_slist* header_list_openrtb2_3 = NULL;
int g_rtb_ms_timeout;
char *g_drproxy_url = NULL;

void __wrap_json_append_object(){
}

void __wrap_add_publisherobj_injson(){
}
void __wrap_validate_json() {
}
void __wrap_json_append_escaped_string(){
}

void __wrap_add_site_pagedomain_in_json(){
}

void __wrap_json_append_string(char **buff, const char *name, const char *value, int add_separator){
	(void) buff;
	check_expected(name);
	check_expected(value);
	check_expected(add_separator);
}

void __wrap_json_append_int(char **buff, const char *name, const int value, int add_separator, int add_quote) {
	(void) buff;
	check_expected(name);
	check_expected(value);
	check_expected(add_separator);
	check_expected(add_quote);
}

void __wrap_json_append_double() {
}

void __wrap_json_append_value_string(char **buff, const char *name, int add_separator) {
	(void) buff;
	check_expected(name);
	check_expected(add_separator);
}

void __wrap_json_append_fixed_value_string() {
}

void __wrap_json_encode_double_truncated(){
}

void __wrap_json_append_value_int() {
}

void __wrap_json_append_double_truncated() {
}

void __wrap_copy_iab_cat_from_db_in_json(){
}
void __wrap_Get_mu() {
}

CURLcode __wrap_curl_easy_setopt(CURL *handle, CURLoption option, void *parameter){
    (void) handle;
    (void) option;
    (void) parameter;
    return CURLE_OK;
}

CURL *__wrap_curl_easy_init( ){
    return NULL;
}

struct curl_slist *__wrap_curl_slist_append(){
    struct curl_slist *slist=NULL;
    return slist;
}

int __wrap_nstrcpy(){
	return mock_type(int);
}

char* __wrap_deserialize_int() {
	return mock_type(char *);
}

char * __wrap_cache_get_badv_domain_json(){
	return mock_type(char *);
}

size_t __wrap_openrtb_process_header() {
	return mock_type(size_t);
}

int __wrap_default_process_response () {
	return mock_type(int);
}

int __wrap_get_winloss_info_str(){
	return mock_type(int);
}

void __wrap_strtoupper() {
}

int __wrap_get_frequency() {
	return mock_type(int);
}

const char* __wrap_get_header_value(){
	return mock_type(char *);
}

int __wrap_decode_url() {
	return mock_type(int);
}

void __wrap_elog() {
}

int __wrap_increment_stats_counters(libstat_counters_t *libstat_counters, int stats_id, long int campaign_id ) {
	check_expected(stats_id);
	check_expected(campaign_id);
	return 0 ;
}

int __wrap_is_ipv4_address(){
	return mock_type(int);
}

void __wrap_add_ip_in_json(char** post_data, int is_ipv4, char* ip, int add_comma){
	(void) post_data;
	check_expected(is_ipv4);
	check_expected(ip);
	(void) add_comma;
}

void __wrap_replace_native_img_icon_asset_type() {
}
void __wrap_create_geo_object_pass_asis(){

}
void __wrap_get_alpha3_from_alpha2(){
}
void __wrap_memcached_release_object_reference(){
}

void __wrap_append_supply_chain_object(char **post_data, rt_request_params_t* in_request_params, int *has_ext_params){}

int ut_create_pmp_object_2_3( char **post_data, publisher_site_ad_campaign_list_t *adcampaigns,
								const rt_request_url_params_mask_t * rt_request_url_params_mask1,
								fte_additional_params_t *fte_additional_parameters,
								const rt_request_params_t *in_request_params ) ;

void __wrap_gdpr_object_creation_decision() {
}
int __wrap_prepare_translated_eb_provider_id_list() {
	return 0;
}

#endif
