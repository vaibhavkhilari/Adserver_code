#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <typedefs.h>
#include <ad_server_types.h>
#include <rtb_util.h>
#include <rt_campaign_config.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "openrtb.h"
#include "error.h"
#include "db_error.h"
#include "db_connection.h"
#include "cache_libmemcached.h"
#include "openrtb_api_mock_functions.h"
#include "deal_fast_targeting.h"
#include "libstats_util.h"
#include "audience_slist_impl.h"
#include "pm_json.h"

int gbl_log_level = L_DEBUG;
int g_min_payload_for_compression;

char* g_local_primary_drproxy_url;
char* g_local_secondary_drproxy_url;

void audience_prof_print ( void *head ) {
	if( NULL == head ) {
	abort() ;
	}
}
int audience_prof_compr( const void *node1, const void *node2 ) {
	if( NULL == node1 || NULL == node2 ) {
		return -1;
	}

	return ((dp_profiles_t *)node1)->dpid - ((dp_profiles_t *)node2)->dpid;
}

void print_string ( void *head ) {
	if( NULL == head) {
		abort() ;
	}
}

int compare_slist_string( const void *node1, const void *node2 ) {
	if( NULL == node1 || NULL == node2 ) {
		return -1;
	}
	return (int) ( strcmp((char*)node1, (char*)node2) );
}


#define DATA_PROVIDER_ID 289

static void populate_dummy_user_segments(void  **audience_data_list)
{
	int j =0;
	int ret_val=0;
	char *provider_id_string =NULL;
	dp_profiles_t *profiles = NULL;
	int seg_count=100;
	int profile_count = 1; 
	char buf[100] ;

	//Create and populate SLIST with these segments as  there is no data from aerospike
	(*audience_data_list) = NULL;
	(*audience_data_list) = (SLIST *)malloc( sizeof(SLIST) );
	if (NULL == *audience_data_list) {
		fprintf(stderr, "malloc failed %s:%d\n", __FILE__, __LINE__);
		return ;
	}

	ret_val = slist_create(           /* SLIST with elements as individual data provider profiles */
			(*audience_data_list),
			profile_count,
			&audience_prof_free,
			&audience_prof_print,
			&audience_prof_compr,
			&audience_prof_search );
	if( ADS_ERROR_SUCCESS != ret_val ) {
		free(*audience_data_list );
		(*audience_data_list) = NULL;
		fprintf(stderr, "Static List creation failed for Audience profiles. %s:%d\n", __FILE__, __LINE__);
		return;
	}

	/* allocate memory for the variable. */
	profiles = NULL;
	profiles = (dp_profiles_t*)malloc(sizeof(dp_profiles_t));
	if( NULL == profiles ) {
		fprintf(stderr, "malloc failed %s:%d\n", __FILE__, __LINE__);
		ret_val = ADS_ERROR_NOMEMORY;
		goto free_and_ret;
	}

	/*Adding the data provider profile to the primary SLIST*/
	ret_val = slist_add((*audience_data_list), (void *)profiles );
	if( ADS_ERROR_SUCCESS != ret_val ) {
		free( profiles );
		profiles = NULL;

		fprintf(stderr, "Addition to static list of audiences failed. %s:%d\n", __FILE__, __LINE__);
		ret_val = ADS_ERROR_INTERNAL;
		goto free_and_ret;
	}

	/*Create SLIST to hold provider segment IDs as strings (ProvIDSlist)*/
	if( ADS_ERROR_SUCCESS != (ret_val = slist_create(
					&(profiles->audiences_string), seg_count, &free_generic_ptr,
					&print_string, (__compare_function)&compare_slist_string, &search_string)) ) {

		fprintf(stderr, "Static List creation failed for Audience profiles. %s:%d\n", __FILE__, __LINE__);
		ret_val = ADS_ERROR_INTERNAL;
		goto free_and_ret;
	}

	/* Add data provider ID. */
	profiles->dpid = DATA_PROVIDER_ID;

	for(; j<seg_count; j++ ) {
		snprintf( buf, sizeof(buf), "segment_%d_%d", profiles->dpid, j ) ;
		provider_id_string = strdup( buf ); 
		ret_val = slist_add(&(profiles->audiences_string),provider_id_string);
		if( ADS_ERROR_SUCCESS != ret_val ) {
			free( provider_id_string );
			provider_id_string = NULL;

			fprintf(stderr, "Addition to static list of audiences failed. %s:%d\n", __FILE__, __LINE__);
			ret_val = ADS_ERROR_INTERNAL;
			break ;
		}
	} 

free_and_ret:
	if( ADS_ERROR_SUCCESS != ret_val ) {
		slist_destroy( *audience_data_list );
		free( *audience_data_list );
		(*audience_data_list) = NULL;
	}


}

int ut_create_data_object_with_audience( char **post_data, uint32_t *dpids, uint32_t dpid_count, void *user_segments, int has_user_params ) ;

static void test_create_user_data( void **state )
{
	void *user_segments = NULL ; 
	char buf[10000];
	char* post_data = buf ;
	int bytes_written = 0 ;
	pm_json_object_t* json_obj = NULL;
	pm_json_error_t json_err = PM_JSON_ERROR_SUCCESS;
	int i = 0 ;

	uint32_t dpids[MAX_AUDIENCE_IDS_IN_BID_REQ] ;
	uint32_t dpid_count = MAX_AUDIENCE_IDS_IN_BID_REQ ;

	for( i = 0 ; i < MAX_AUDIENCE_IDS_IN_BID_REQ ; i++ ) {
		dpids[i] = DATA_PROVIDER_ID ;
	}
		
	populate_dummy_user_segments(&user_segments);

	bytes_written = ut_create_data_object_with_audience( &post_data, dpids, dpid_count, NULL, 0 ) ; 
	if( bytes_written != 0 ) abort() ;

	bytes_written = ut_create_data_object_with_audience( &post_data, dpids, 0, user_segments, 0 ) ;
	if( bytes_written != 0 ) abort() ;

	*post_data = '{' ;
	post_data++ ;
	*post_data = '\0' ;

	bytes_written = ut_create_data_object_with_audience( &post_data, dpids, dpid_count, user_segments, 0 ) ;
	if( bytes_written == 0 ) abort() ;

	*post_data = '}' ;
	post_data++ ;
	*post_data = '\0' ;

	printf( "Audience JSON: %s. Length: %d\n", buf, bytes_written ) ;	

	json_err = pm_json_parse(buf, &json_obj);
	if (json_err != PM_JSON_ERROR_SUCCESS)
	{
		abort();
	}
	
	pm_json_object_release(json_obj);
}


static void common_create_pmp_object( void **state, int version )
{
	char buf[65536];
	char* post_data = buf ;
	publisher_site_ad_campaign_list_t adcampaign ;
	rt_request_url_params_mask_t rt_request_url_params_mask1 ;
	fte_additional_params_t fte_additional_parameters ;
	ad_campaign_list_setings_t ad_camp_settings ;
	currency_xrate_map_t usd_xate_map ;
	rt_request_params_t in_request_params ;
	char * ptr_guaranteed = NULL ; 

	size_t i = 0 ;
	struct dsp_buyer *p_dsp_buyer = NULL ;

	strncpy( usd_xate_map.currency_code, "USD", sizeof("USD") ) ;
	usd_xate_map.currency_id = 1 ;
	usd_xate_map.precision_rate = 1 ;
	usd_xate_map.inverse_rate = 1 ;

	memset( buf, 0, sizeof(buf) ) ;
	memset( &adcampaign, 0, sizeof(adcampaign) ) ;
	memset( &rt_request_url_params_mask1, 0, sizeof(rt_request_url_params_mask1) ) ;
	memset( &fte_additional_parameters, 0, sizeof(fte_additional_parameters) ) ;
	memset( &ad_camp_settings, 0, sizeof(ad_camp_settings) ) ;
	memset( &in_request_params, 0, sizeof(in_request_params) ) ;

	adcampaign.ad_campaign_list_setings = &ad_camp_settings ;
	in_request_params.fte_additional_params = &fte_additional_parameters ;

	fte_additional_parameters.publisher_level_settings.max_deal_count_in_bidreq = 100 ;

	fte_additional_parameters.currency_xrate_map = &usd_xate_map ;
	fte_additional_parameters.currency_count = 1 ;  
	rt_request_url_params_mask1.buyer_id_passing_enable_flag = 1 ;

	ad_camp_settings.applicable_dsp_buyers_count = 1000 ;
	ad_camp_settings.applicable_dsp_buyers = (dsp_buyer_t**)malloc( sizeof(dsp_buyer_t*)*ad_camp_settings.applicable_dsp_buyers_count ) ;
	memset( ad_camp_settings.applicable_dsp_buyers, 0, sizeof(dsp_buyer_t*)*ad_camp_settings.applicable_dsp_buyers_count ) ;

	adcampaign.campaign_id = 120 ;

	for(  i = 0 ; i < ad_camp_settings.applicable_dsp_buyers_count ; i++ )
	{
		p_dsp_buyer = (struct dsp_buyer*)malloc( sizeof(struct dsp_buyer) ) ;
		memset( p_dsp_buyer, 0, sizeof(*p_dsp_buyer) ) ;

		p_dsp_buyer->parent_deal_params = (struct deal_params*)malloc( sizeof(struct deal_params) ) ;	
		memset( p_dsp_buyer->parent_deal_params, 0, sizeof(struct deal_params) ) ;

		p_dsp_buyer->pubmatic_buyer_id = 100+i ;
		p_dsp_buyer->dsp_buyer_id = 100+i ;
		p_dsp_buyer->dsp_id = 100+i ;
		p_dsp_buyer->deal_pub.deal_ecpm_usd = 1+0.1*i ;
		p_dsp_buyer->in_rtb_request = NOT_ADDED_IN_RTB_REQUEST ;

		p_dsp_buyer->parent_deal_params->deal_type = PMP_DEAL ;

		snprintf( p_dsp_buyer->parent_deal_params->pub_deal_id, sizeof(p_dsp_buyer->parent_deal_params->pub_deal_id),
				"UT_DEAL_%lu", i ) ;
		p_dsp_buyer->deal_pub.auction_id = 1 ;

		p_dsp_buyer->parent_deal_params->deal_channel_type_id = DEAL_CHANNEL_TYPE_PMP ; 

		p_dsp_buyer->parent_deal_params->p_stats = (deal_stats_t*)malloc( sizeof(deal_stats_t) ) ;
		memset( p_dsp_buyer->parent_deal_params->p_stats, 0, sizeof(deal_stats_t) ) ;

		ad_camp_settings.applicable_dsp_buyers[i] = p_dsp_buyer ;
	}

	ad_camp_settings.applicable_dsp_buyers[0]->parent_deal_params->deal_channel_type_id = DEAL_CHANNEL_TYPE_PMPG ; 

	expect_value(__wrap_increment_stats_counters, stats_id, RTB_MAX_DEAL_VIOLATION_COUNT_ID );
	expect_value(__wrap_increment_stats_counters, campaign_id, adcampaign.campaign_id);

	if( version == 21 )
	{
		ut_create_pmp_object( &post_data, &adcampaign, &rt_request_url_params_mask1, &fte_additional_parameters ) ;
	}
	else if ( version == 23 )
	{
		ut_create_pmp_object_2_3( &post_data, &adcampaign, &rt_request_url_params_mask1, &fte_additional_parameters, &in_request_params ) ;
	}
	else
	{
		abort() ;
	}

	for(  i = 0 ; i < ad_camp_settings.applicable_dsp_buyers_count ; i++ )
	{
		if( i < fte_additional_parameters.publisher_level_settings.max_deal_count_in_bidreq )
		{
			if( strstr( buf, ad_camp_settings.applicable_dsp_buyers[i]->parent_deal_params->pub_deal_id ) == NULL )
			{
				abort() ;
			}
		}
		else
		{
			if( strstr( buf, ad_camp_settings.applicable_dsp_buyers[i]->parent_deal_params->pub_deal_id ) != NULL )
			{
				abort() ;
			}
		}

		free( ad_camp_settings.applicable_dsp_buyers[i]->parent_deal_params->p_stats ) ;
		free( ad_camp_settings.applicable_dsp_buyers[i]->parent_deal_params ) ;
	}

	ptr_guaranteed = strstr( buf, "guaranteed") ;

	if( ptr_guaranteed == NULL )
	{
		abort() ;
	}

	//there should be only one guaranteed deal

	ptr_guaranteed = strstr( ptr_guaranteed + sizeof("guaranteed") , "guaranteed") ;

	if( ptr_guaranteed != NULL )
	{
		abort() ;
	}

	fprintf( stdout, "PMP JSON object in bid request: \"%s\"\n", buf ) ;

	free( ad_camp_settings.applicable_dsp_buyers ) ;
}

static void test_create_pmp_object_21( void **state )
{
	common_create_pmp_object( state, 21 ) ;
}

static void test_create_pmp_object_23( void **state )
{
	common_create_pmp_object( state, 23 ) ;
}


int main(){
	const struct CMUnitTest tests[] = { 
		cmocka_unit_test(test_create_user_data),
		cmocka_unit_test(test_create_pmp_object_21),
		cmocka_unit_test(test_create_pmp_object_23)
	};  
	return cmocka_run_group_tests(tests, NULL, NULL);
}

