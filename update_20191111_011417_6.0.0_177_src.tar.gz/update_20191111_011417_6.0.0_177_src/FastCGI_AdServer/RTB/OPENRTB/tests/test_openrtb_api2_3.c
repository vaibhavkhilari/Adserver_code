#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <typedefs.h>
#include <ad_server_types.h>
#include <rtb_util.h>
#include <rt_campaign_config.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "openrtb.h"
#include "error.h"
#include "db_error.h"
#include "db_connection.h"
#include "cache_libmemcached.h"
#include "openrtb_api_mock_functions.h"

/* Currently, no test cases cover code for proxies.  Just adding to resolve
 * library dependencies without importing too many additional dependencies.
 * When proxies are added this can be removed and many additional
 * dependencies will need to be added.
 */
char* g_local_primary_drproxy_url;
char* g_local_secondary_drproxy_url;

int gbl_log_level = L_DEBUG;
uint8_t g_min_payload_for_compression = 0;

static void test_add_ip_in_openrtb2_3device_ipv4(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int has_device_param=0;
	bool ip_masking_enabled = 0;
	int is_coppa_compliant=0;
	char *remote_ip="172.16.4.63";
	char *masked_ip="172.16.4.0";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	will_return(__wrap_is_ipv4_address,1);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 1);
	expect_string(__wrap_add_ip_in_json, ip, remote_ip);
	add_ip_in_openrtb2_3device(&post_data,&in_request_params,is_coppa_compliant, ip_masking_enabled,has_device_param);
	
}

static void test_add_ip_in_openrtb2_3device_ipv4_private(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int has_device_param=0;
	bool ip_masking_enabled = 1;
	int is_coppa_compliant=0;
	char *remote_ip="172.16.4.63";
	char *masked_ip="172.16.4.0";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	will_return(__wrap_is_ipv4_address,1);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 1);
	expect_string(__wrap_add_ip_in_json, ip, masked_ip);
	add_ip_in_openrtb2_3device(&post_data,&in_request_params,is_coppa_compliant, ip_masking_enabled,has_device_param);	
}


static void test_add_ip_in_openrtb2_3device_ipv4_coppa(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int has_device_param=0;
	bool ip_masking_enabled = 0;
	int is_coppa_compliant=1;
	char *remote_ip="172.16.4.63";
	char *masked_ip="172.16.4.0";
	char *truncated_ip="172.16.4";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	strcpy(in_request_params.rt_custom_params.truncated_ip, truncated_ip);
	will_return(__wrap_is_ipv4_address,1);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 1);
	expect_string(__wrap_add_ip_in_json, ip, truncated_ip);
	add_ip_in_openrtb2_3device(&post_data,&in_request_params,is_coppa_compliant, ip_masking_enabled,has_device_param);	
}
static void test_add_ip_in_openrtb2_3device_ipv6(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int has_device_param=0;
	bool ip_masking_enabled = 0;
	int is_coppa_compliant=0;
	char *remote_ip="2001:0db8:85a3:0000:7890:0000:0370:7334";
	char *masked_ip="2001:0db8:85a3::";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	will_return(__wrap_is_ipv4_address,0);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 0);
	expect_string(__wrap_add_ip_in_json, ip, remote_ip);
	add_ip_in_openrtb2_3device(&post_data,&in_request_params,is_coppa_compliant, ip_masking_enabled,has_device_param);	
}

static void test_add_ip_in_openrtb2_3device_ipv6_private(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int has_device_param=0;
	bool ip_masking_enabled = 1;
	int is_coppa_compliant=0;
	char *remote_ip="2001:0db8:85a3:0000:7890:0000:0370:7334";
	char *masked_ip="2001:0db8:85a3::";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	will_return(__wrap_is_ipv4_address,0);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 0);
	expect_string(__wrap_add_ip_in_json, ip, masked_ip);
	add_ip_in_openrtb2_3device(&post_data,&in_request_params,is_coppa_compliant, ip_masking_enabled,has_device_param);	
}

static void test_add_ip_in_openrtb2_3device_ipv6_coppa(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int has_device_param=0;
	bool ip_masking_enabled = 0;
	int is_coppa_compliant=1;
	char *remote_ip="2001:0db8:85a3:0000:7890:0000:0370:7334";
	char *masked_ip="2001:0db8:85a3::";
	char *truncated_ip="2001:0db8:85a3:0000:7890:0000";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	strcpy(in_request_params.rt_custom_params.truncated_ip, truncated_ip);
	will_return(__wrap_is_ipv4_address,0);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 0);
	expect_string(__wrap_add_ip_in_json, ip, truncated_ip);
	add_ip_in_openrtb2_3device(&post_data,&in_request_params,is_coppa_compliant, ip_masking_enabled,has_device_param);	
}

/*
 * Testcase create_source_object_v23 0 : Argument Invalid
 */
static void test_create_source_object_v23_ARG_INVALID(void **state){

	rt_request_params_t in_request_params;
	create_source_object_v23(NULL,&in_request_params,0);
}

/*
 * Testcase create_source_object_v23 1: when MLA flag is 0
 */
static void test_create_source_object_v23_MLA_FLAG_0_pchain(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_param_t in_server_req_params;
	publisher_site_ad_t site_ad;

	in_request_params.in_server_req_params=&in_server_req_params;
	in_request_params.in_server_req_params->site_ad = &site_ad;
	in_request_params.in_server_req_params->site_ad->multi_level_auction_enabled = 0;
	strcpy(in_request_params.in_server_req_params->payment_tagid_chain,"5555:1234");

	in_request_params.in_server_req_params->omidpn[0] = '\0';
	in_request_params.in_server_req_params->omidpv[0] = '\0';

	expect_string(__wrap_json_append_value_string, name, "\"source\":{");
	expect_value(__wrap_json_append_value_string, add_separator, 1);

	expect_string(__wrap_json_append_int, name, "fd");
	expect_value(__wrap_json_append_int, value, 0);
	expect_value(__wrap_json_append_int, add_separator, 0);
	expect_value(__wrap_json_append_int, add_quote, 0);
	/*Add pchain */
	expect_string(__wrap_json_append_string, name, "pchain");
	expect_string(__wrap_json_append_string, value, "5555:1234");
	expect_value(__wrap_json_append_string, add_separator, 1);

	expect_string(__wrap_json_append_value_string, name, "\"ext\":{");
	expect_value(__wrap_json_append_value_string, add_separator, 1);

	expect_string(__wrap_json_append_value_string, name, "}");
	expect_value(__wrap_json_append_value_string, add_separator, 0);

	create_source_object_v23(&post_data,&in_request_params,0);
}

/*
 * Testcase create_source_object_v23 2: when MLA flag is 1
 */

static void test_create_source_object_v23_MLA_FLAG_1_no_pchain(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_param_t in_server_req_params;
	publisher_site_ad_t site_ad;

	in_request_params.in_server_req_params=&in_server_req_params;
	in_request_params.in_server_req_params->site_ad = &site_ad;
	in_request_params.in_server_req_params->site_ad->multi_level_auction_enabled = 1;

	in_request_params.in_server_req_params->payment_tagid_chain[0] = '\0';
	in_request_params.in_server_req_params->omidpn[0] = '\0';
	in_request_params.in_server_req_params->omidpv[0] = '\0';

	in_request_params.in_server_req_params->payment_tagid_chain[0] = '\0';
	expect_string(__wrap_json_append_value_string, name, "\"source\":{");
	expect_value(__wrap_json_append_value_string, add_separator, 1);

	expect_string(__wrap_json_append_int, name, "fd");
	expect_value(__wrap_json_append_int, value, 1);
	expect_value(__wrap_json_append_int, add_separator, 0);
	expect_value(__wrap_json_append_int, add_quote, 0);

	expect_string(__wrap_json_append_value_string, name, "\"ext\":{");
	expect_value(__wrap_json_append_value_string, add_separator, 1);

	expect_string(__wrap_json_append_value_string, name, "}");
	expect_value(__wrap_json_append_value_string, add_separator, 0);

	create_source_object_v23(&post_data,&in_request_params,0);
}

/*
 * Testcase create_source_object_v23 3: when MLA flag is Invalid
 */

static void test_create_source_object_v23_INVALID_MLA_FLAG_pchain(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_param_t in_server_req_params;
	publisher_site_ad_t site_ad;

	in_request_params.in_server_req_params=&in_server_req_params;
	in_request_params.in_server_req_params->site_ad = &site_ad;
	in_request_params.in_server_req_params->site_ad->multi_level_auction_enabled = -1;
	strcpy(in_request_params.in_server_req_params->payment_tagid_chain,"5555:1234");
	
	in_request_params.in_server_req_params->omidpn[0] = '\0';
	in_request_params.in_server_req_params->omidpv[0] = '\0';

	expect_string(__wrap_json_append_value_string, name, "\"source\":{");
	expect_value(__wrap_json_append_value_string, add_separator, 1);

	/*Add pchain */
	expect_string(__wrap_json_append_string, name, "pchain");
	expect_string(__wrap_json_append_string, value, "5555:1234");
	expect_value(__wrap_json_append_string, add_separator, 0);

	/* here for EXt */
	expect_string(__wrap_json_append_value_string, name, "\"ext\":{");
	expect_value(__wrap_json_append_value_string, add_separator, 1);

	expect_string(__wrap_json_append_value_string, name, "}");
	expect_value(__wrap_json_append_value_string, add_separator, 0);

	create_source_object_v23(&post_data,&in_request_params,0);
}

int main(){
    const struct CMUnitTest tests[] = { 
        cmocka_unit_test(test_add_ip_in_openrtb2_3device_ipv4),
		cmocka_unit_test(test_add_ip_in_openrtb2_3device_ipv4_private),
		cmocka_unit_test(test_add_ip_in_openrtb2_3device_ipv4_coppa),
		cmocka_unit_test(test_add_ip_in_openrtb2_3device_ipv6),
		cmocka_unit_test(test_add_ip_in_openrtb2_3device_ipv6_private),
		cmocka_unit_test(test_add_ip_in_openrtb2_3device_ipv6_coppa),
		cmocka_unit_test(test_create_source_object_v23_ARG_INVALID),
		cmocka_unit_test(test_create_source_object_v23_MLA_FLAG_0_pchain),
		cmocka_unit_test(test_create_source_object_v23_MLA_FLAG_1_no_pchain),
		cmocka_unit_test(test_create_source_object_v23_INVALID_MLA_FLAG_pchain),

    };  
     return cmocka_run_group_tests(tests, NULL, NULL);
}
