/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "error.h"
#include "json.h"
#include "json_util.h"
#include "json_object_private.h"
#include "default_adapter.h"
#include "rtb_brand_control_util.h"
#include "openrtb.h" 
#include "log_fw.h"
#include "video.h"
#include "string_util.h"
#include "url_util.h"
#include "native_resp_handler.h"
#include "native_util.h"

json_object *get_json_child_from_parent(json_object *parent_json_object, const char *key, json_type child_json_type);
void remove_char(char *str, char c);

extern currency_hash_t g_currency_hash[];

void printbid_openrtb(long oper_id, long campaign_id, rt_bid_response_params_t *bid_response_params, ad_server_additional_params_t *additional_parameter, int bid_currency, int dnbr)
{
	if(!bid_response_params){
    		return;
  	}
	if( additional_parameter->adserver_config_params->rtb_debug_flag >= 1
	   && oper_id == SERV_ADS_VIDEO_OPER ) {
	     logVidMessage("VIDEO_INFO|OpenRTB-BidRESP: CId:%ld BidId:%s ReqId:%s BID:%f\n",
	                campaign_id,
        	        bid_response_params->transaction_id,
                	bid_response_params->request_id,
	                bid_response_params->ecpm);
	}

	if( additional_parameter->adserver_config_params->rtb_debug_flag == DEBUG_RTB || 
	    additional_parameter->adserver_config_params->rtb_debug_flag == DEBUG_OPENRTB ) {

    	llog_write(L_DEBUG,
                "\n\nOPENRTB RESPONSE: cid : %ld "
                "%s : %s "  // Transaction ID
                "%s : %s "  // Request ID
                "%s : %lf"  // eCPM
                "%s : %s "  // Landing Page URL
                "%s : %s "  // Landing Page TLD
                "%s : %s "  // Creative ID
                "%s : %d "  // Creative Type
                "%s : %d "  // DSP Buyer ID
                "%s : %s "  // Ad Markup
                "%s : %s "  // Piggyback cookie
                "%s : %s "  // Deal ID
                "%s : %d "  // Bid Currency
                "%s : %s "  // iUrl
                "%s : %s "  // Campaign ID
                "%s : %d "  // dnbr
                "%s : %d "  // Creative Attribute
                "%s : %s "  // Rich Media Tech Name
                "\n",
                campaign_id,
                ID, bid_response_params->transaction_id,
                REQUEST_ID, bid_response_params->request_id,
                BID, bid_response_params->ecpm,
                LANDING_PAGE_URL, bid_response_params->landing_page_url,
                LANDING_PAGE_TLD, bid_response_params->landing_page_tld,
                CREATIVEID, bid_response_params->creative_id,
                CREATIVE_TYPE, bid_response_params->creative_type,
                SEAT, bid_response_params->dsp_buyer_id,
                ADMARKUP, bid_response_params->u_url.admarkup,
                PIGGYBACK_COOKIE, bid_response_params->cookie,
                DEALID, bid_response_params->pub_deal_id,
                BID_CURRENCY, bid_currency,
                O_IURL, bid_response_params->iurl,
                CID, bid_response_params->dsp_campaign_id,
                DEAL_NO_BID_REASON, dnbr,
                ATTR_ARR, bid_response_params->rich_media_ad_creative_attribute_id,
                RICH_MEDIA_TECH_ID, bid_response_params->rich_media_tech_name
	);
  }
}

/*
 * Function to parse response level ext object from response
 */
static void parse_response_ext_object(rt_response_params_t *rt_response_params, json_object *json_obj) {
	json_object *ext_object = NULL;
	json_object *dnbr_object = NULL;

        ext_object = get_json_child_from_parent(json_obj, EXT, json_type_object);
        if ( ext_object != NULL ) {
		dnbr_object = get_json_child_from_parent( ext_object, DEAL_NO_BID_REASON, json_type_int);
		if ( dnbr_object != NULL) {
			rt_response_params->deal_no_bid_reason = dnbr_object->o.c_int;
			OPENRTB_DEBUG("Deal no bid reason:%d", rt_response_params->deal_no_bid_reason);
		}
        }	
}


/*
 * Function to parse bid level ext object from response
 */
static void parse_ext_object(rt_bid_response_params_t *bid_params, json_object *bid_obj, int is_native_request) {
	json_object *ext_object = NULL;
	json_object *dealid_object = NULL;
	/* OLD Native Protocol Implementation
	json_object *native_object = NULL;
	*/
	(void)is_native_request;
        json_object *creative_type = NULL;
	json_object *rich_media_tech_id = NULL;	

        ext_object = get_json_child_from_parent(bid_obj, EXT, json_type_object);
        if ( ext_object != NULL ) {
		dealid_object = get_json_child_from_parent( ext_object, DEALID, json_type_string);
		if ( dealid_object != NULL) {
			strncpy(bid_params->pub_deal_id, dealid_object->o.c_string, MAX_DEAL_ID_LEN);
			bid_params->pub_deal_id[MAX_DEAL_ID_LEN] = '\0';
			OPENRTB_DEBUG("Deal id:%s",bid_params->pub_deal_id);
		}

                creative_type = get_json_child_from_parent(ext_object,
                                CREATIVE_TYPE, json_type_int);
                if (creative_type) {
                        int t = creative_type->o.c_int;
                        if (MIN_CREATIVE_TYPE_VALUE <= t &&
                                        t <= MAX_CREATIVE_TYPE_VALUE) {
                                bid_params->creative_type = t;
                                OPENRTB_DEBUG("Creative type:%d",
                                                bid_params->creative_type);
                        }
                }
	
		rich_media_tech_id  = get_json_child_from_parent( ext_object, RICH_MEDIA_TECH_ID, json_type_string);
		if( rich_media_tech_id != NULL ) {
			nstrcpy(bid_params->rich_media_tech_name, rich_media_tech_id->o.c_string, MAX_RICH_MEDIA_TECH_ID_LEN);
			bid_params->rich_media_tech_name[MAX_RICH_MEDIA_TECH_ID_LEN] = '\0';
			OPENRTB_DEBUG("RM: RMT ID:%s", bid_params->rich_media_tech_name);
		}

		parse_common_response_bidExt_object(ext_object, bid_params);
	}
}


int validate_native_response(char *native_creative, fte_additional_params_t *fte_additional_params)
{
    int invalid_reason = NATIVE_OBJ_VALID_JSON;
    {
       native_object_t native_response;
       init_native_resp_object(&native_response);
       invalid_reason = native_response_parser(native_creative, &native_response);

#ifdef NATIVE_DEBUG
       print_parsed_native_object(&native_response);
#endif

       if( invalid_reason == NATIVE_OBJ_VALID_JSON ) {
         invalid_reason  = validate_request_response(&fte_additional_params->in_server_req_params->native_request, &native_response);
         if(NATIVE_OBJ_VALID_JSON == invalid_reason && native_response.stats.num_invalid_assets != 0) {
            invalid_reason = repair_json_response(native_creative, &native_response); 
         }
       } 

       free_native_response(&native_response);
    }

    if (invalid_reason != NATIVE_OBJ_VALID_JSON) {
      llog_write(L_DEBUG, "\nNATIVE_ERROR:: Invalid Native Response with ERROR_CODE:%d [pub_id:%ld, site_id:%ld, ad_id:%ld]!\n", 
			invalid_reason,
			fte_additional_params->in_server_req_params->publisher_id,
			fte_additional_params->in_server_req_params->site_id,
			fte_additional_params->in_server_req_params->ad_id);
    } else {
#ifdef NATIVE_DEBUG
         llog_write(L_DEBUG, "\nNATIVE:: Valid Native Response !\n");
#endif
    }   

	return (invalid_reason != NATIVE_OBJ_VALID_JSON);
}



/*
 * Get bid request object and fill the structure
 */
static void get_dsp_bids(json_object *bid_obj, rt_response_params_t *rt_response_params, long oper_id, int currency_id, fte_additional_params_t *fte_additional_params, const ad_server_additional_params_t * additional_params) {
        
	json_object *bid_id_obj = NULL;
        json_object *impid_obj = NULL;
        json_object *price_obj = NULL;
        json_object *adm_obj = NULL;
        json_object *crid_obj = NULL;
	json_object *adomain_arr = NULL;
	json_object *adomain_obj = NULL;

        json_object *iurl_obj = NULL;
        json_object *cid_obj = NULL;
        json_object *attr_arr = NULL;
        json_object *attr_obj = NULL;
        //json_object *adid_obj = NULL;
        //json_object *nurl_obj = NULL;

	int ret_val = 0;
	int attr_arr_len = 0;
        //int i = 0;

        rt_bid_response_params_t *bid_params = NULL;

	int adomain_arr_len = 0;
        char tmp_landing_page_tld[MAX_DOMAIN_NAME_LENGTH + 1];
	int imp_id = 0, len = 0;

	int is_native_request = (fte_additional_params->in_server_req_params->ad_type == AD_TYPE_NATIVE) ? 1 : 0;
	tmp_landing_page_tld[0] = tmp_landing_page_tld[MAX_DOMAIN_NAME_LENGTH] = '\0';
	bid_params = &rt_response_params->bid_response_params;
	bid_params->pub_deal_id[0] = '\0';

	bid_id_obj = get_json_child_from_parent(bid_obj, BID_DOT_ID, json_type_string);
        if ( bid_id_obj == NULL ) {
                OPENRTB_ERROR("Mandatory bid id param not found, campaign:%ld", rt_response_params->campaign_id);
        } else {
		nstrcpy(bid_params->str_bid_id,bid_id_obj->o.c_string,MAX_BID_ID_LEN);
        	bid_params->str_bid_id[MAX_BID_ID_LEN] = '\0';
	}

        impid_obj = get_json_child_from_parent(bid_obj, IMP_ID, json_type_string);
        if ( impid_obj == NULL ) {
                OPENRTB_ERROR("Mandatory impid param not found, campaign:%ld", rt_response_params->campaign_id);
        } else {
		imp_id = atoi(impid_obj->o.c_string);
		if ( imp_id != 1) {
			OPENRTB_ERROR("Invalid imp_id value '%d'. Expected value is \"1\", campaign:%ld",
					imp_id, rt_response_params->campaign_id);
		}
   		//assign to something
	}

        price_obj = get_json_child_from_parent(bid_obj, PRICE, json_type_double);
        if ( price_obj && price_obj->o.c_double ) {
		bid_params->ecpm = price_obj->o.c_double;
		bid_params->ecpm = CONVERT_NATIVE_CURRENCY_TO_USD(bid_params->ecpm, currency_id,fte_additional_params->currency_xrate_map,  fte_additional_params->currency_count);
        } else {
		price_obj = get_json_child_from_parent(bid_obj, PRICE, json_type_int);
		if (price_obj) {
			bid_params->ecpm = price_obj->o.c_int;
			bid_params->ecpm = CONVERT_NATIVE_CURRENCY_TO_USD(bid_params->ecpm, currency_id,fte_additional_params->currency_xrate_map,  fte_additional_params->currency_count);
		}
		else {
			OPENRTB_ERROR("Mandatory price param not found, campaign:%ld", rt_response_params->campaign_id);
		}
	}
	if ( bid_params->ecpm <= 0.0 ) {
		OPENRTB_ERROR("Invalid bid value %lf, campaign:%ld",bid_params->ecpm, rt_response_params->campaign_id);
	}

	adm_obj = get_json_child_from_parent(bid_obj, ADMARKUP, json_type_string);
        if ( adm_obj != NULL ) {
		if( oper_id == SERV_ADS_VIDEO_OPER ) {
			bid_params->type = VIDEO_CREATIVE_TAG_TYPE;
			int allowed_creative_buff_size = additional_params->pubsite_default_settings.video_creative_buff_size;
			nstrcpy( bid_params->u_url.video_creative_tag, adm_obj->o.c_string, allowed_creative_buff_size);
			bid_params->u_url.video_creative_tag[allowed_creative_buff_size] = '\0';
		/* OLD Native Protocol Implementation
		} else if (is_native_request) {
			bid_params->u_url.admarkup[0] = '\0';
		*/
		} else if (is_native_request) {
			bid_params->type = NATIVE_CREATIVE_TYPE;
			nstrcpy( bid_params->u_url.native_creative_json, adm_obj->o.c_string, MAX_NATIVE_CREATIVE_LEN);
      bid_params->u_url.native_creative_json[MAX_NATIVE_CREATIVE_LEN] = '\0';
			ret_val = validate_native_response(bid_params->u_url.native_creative_json, fte_additional_params);
			if (ret_val == 1) {
				bid_params->u_url.native_creative_json[0] = '\0';
			}
#ifdef NATIVE_DEBUG
      OPENRTB_DEBUG("\nNative creative: %s", bid_params->u_url.native_creative_json);
#endif
		} else {
			bid_params->type = XHTML_TYPE;
			nstrcpy( bid_params->u_url.admarkup, adm_obj->o.c_string, MAX_CREATIVE_TAG_SIZE);
                	bid_params->u_url.admarkup[MAX_CREATIVE_TAG_SIZE] = '\0';
		}
        }

        crid_obj = get_json_child_from_parent(bid_obj, CRID, json_type_string);
        if ( crid_obj != NULL ) {
                nstrcpy( bid_params->creative_id,crid_obj->o.c_string ,MAX_CREATIVE_ID_SIZE);
                bid_params->creative_id[MAX_CREATIVE_ID_SIZE] = '\0';
        }

        cid_obj = get_json_child_from_parent(bid_obj, CID, json_type_string);
        if ( cid_obj != NULL ) {
		nstrcpy( bid_params->dsp_campaign_id, cid_obj->o.c_string, MAX_DSP_CAMPAIGN_ID_LEN);
		bid_params->dsp_campaign_id[MAX_DSP_CAMPAIGN_ID_LEN] = '\0';
        }

	iurl_obj = get_json_child_from_parent(bid_obj, O_IURL, json_type_string);
        if ( iurl_obj != NULL ) {
		nstrcpy( bid_params->iurl, iurl_obj->o.c_string, MAX_IURL_SIZE);
		bid_params->iurl[MAX_IURL_SIZE] = '\0';
        }

	/*adid_obj = get_json_child_from_parent(bid_obj, CADID, json_type_string);
        if ( adid_obj != NULL ) {
                //llog_write(L_DEBUG,"\nadid:%s",adid_obj->o.c_string);
        }*/


        /*nurl_obj = get_json_child_from_parent(bid_obj, NURL, json_type_string);
        if ( nurl_obj != NULL ) {
                //llog_write(L_DEBUG,"\nnurl:%s",nurl_obj->o.c_string);
        }*/


        attr_arr = get_json_child_from_parent(bid_obj, ATTR_ARR, json_type_array);
        if ( attr_arr != NULL ) {
                attr_arr_len = json_object_array_length(attr_arr);
                if (attr_arr_len < 1 ) {
                        OPENRTB_DEBUG("Invalid attr array");
                } else {
			attr_obj = json_object_array_get_idx(attr_arr, 0);
			if ( attr_obj != NULL && attr_obj->o_type == json_type_int ) {
				bid_params->rich_media_ad_creative_attribute_id = attr_obj->o.c_int;
				OPENRTB_DEBUG("RM: creative attr:%d", bid_params->rich_media_ad_creative_attribute_id);
			}
                }
        }

        adomain_arr = get_json_child_from_parent(bid_obj, ADV_DOMAIN_ARR, json_type_array);
        if ( adomain_arr == NULL ) {
                OPENRTB_DEBUG("\nAdv domain array not found");
        } else {
                adomain_arr_len = json_object_array_length(adomain_arr);
                if (adomain_arr_len < 1 ) {
                        OPENRTB_DEBUG("\nInvalid adv domain array");
                } else {
                        adomain_obj = json_object_array_get_idx(adomain_arr, 0);
			if ( adomain_obj != NULL && adomain_obj->o_type == json_type_string ) {
				nstrcpy(tmp_landing_page_tld, adomain_obj->o.c_string, MAX_DOMAIN_NAME_LENGTH);
				len = strlen(tmp_landing_page_tld);
				lowercase_string( tmp_landing_page_tld, 0, len - 1);
				//get tld from escaped url
				get_domain_name_from_escaped_url(tmp_landing_page_tld, bid_params->landing_page_tld, MAX_DOMAIN_NAME_LENGTH);
	                        bid_params->landing_page_flag |= 2;
			} else {
				OPENRTB_ERROR("Invalid adomain string, campaign:%ld", rt_response_params->campaign_id);
			}
                }
        }

	parse_ext_object(bid_params, bid_obj, is_native_request);
	
        //check for verifying mandatory params. If either of these are invalid, we invalidate the request  
        if (
		bid_params->str_bid_id[0] == '\0'
			||
           	bid_params->ecpm <= 0.0
                        ||
                bid_params->u_url.admarkup[0] == '\0'
			||
		imp_id != 1
           ) {
                bid_params->ecpm = 0.0;
                return;
        }
	bid_params->response_complete = 1;
	return;
}

/*
 * Copy parameters from index campaign to current campaign
 */ 
void copy_rt_response_params_openrtb(rt_response_params_t *src, rt_response_params_t *dest){
	// initialization rt_response_params
	rt_bidding_initialize(dest);
	//initialize_bid_response(&dest->bid_response_params);
	dest->campaign_id = src->campaign_id;
	dest->campaign_index = src->campaign_index;
	dest->dp_id= src->dp_id;
	dest->dsp_user_match_found = src->dsp_user_match_found;
	dest->digitrust_id_present = src->digitrust_id_present;
	dest->skip_user_floor = src->skip_user_floor;
	dest->apply_normal_distribution = src->apply_normal_distribution;
	dest->bid_price_encryption_enabled = src->bid_price_encryption_enabled;
	dest->second_price_encryption_enabled = src->second_price_encryption_enabled;
 	dest->click_tracking_url_encoding_enabled = src->click_tracking_url_encoding_enabled;
	dest->pass_blank_click_tracking_url = src->pass_blank_click_tracking_url;
	dest->protocol = src->protocol;
	dest->enabled_ias_services = src->enabled_ias_services;
	dest->send_winloss_info = src->send_winloss_info;
	//reached here means req processed  = 1
	dest->bid_response_params.req_processed = 1;
	dest->currency_id = src->currency_id;
	dest->deal_no_bid_reason = src->deal_no_bid_reason;
	dest->rt_req_id_index = src->rt_req_id_index;
	dest->parent_index = src->parent_index;
	dest->req_ad_dimensions_from_tag = src->req_ad_dimensions_from_tag;
	dest->res_ad_dimension = src->res_ad_dimension;
	dest->log_full_user_id = src->log_full_user_id;
	dest->open_auction_type = src->open_auction_type;
	dest->rtc_settings = src->rtc_settings;
	nstrcpy(dest->bid_response_params.second_price_macro,
		src->bid_response_params.second_price_macro,
		MAX_SECOND_PRICE_MACRO_SIZE);

	nstrcpy(dest->bid_response_params.clicktrack_keyword, 
		src->bid_response_params.clicktrack_keyword,
		MAX_RTB_CLICKTRACK_KEYWORD_LEN);
	dest->bid_response_params.clicktrack_keyword[MAX_RTB_CLICKTRACK_KEYWORD_LEN] = '\0';

	nstrcpy(dest->bid_response_params.transaction_id,
                src->bid_response_params.transaction_id,
                MAX_TRANSACTION_ID_SIZE);
	dest->bid_response_params.transaction_id[MAX_TRANSACTION_ID_SIZE] = '\0';

	nstrcpy(dest->bid_response_params.request_id, 
		src->bid_response_params.request_id,
		MAX_UNIQUE_ID_LEN);
        dest->bid_response_params.request_id[MAX_UNIQUE_ID_LEN]='\0';

	nstrcpy(dest->bid_response_params.cookie,
                src->bid_response_params.cookie,
                MAX_COOKIE_SIZE);
        dest->bid_response_params.cookie[MAX_COOKIE_SIZE] = '\0';
}

/*
 * This function is to parse OPENRTB response object and fill required structures.
 * If DSP response is multiseat or multibid, then this function behaves same as in case of 
 * PubMatic multibid.
 */
void  parse_response_openrtb(void *ptr_rt_response_params_x,
                            int *response_alloc_count,
                            int index,
                            void *additional_parameters_x,
                            int *response_count, 
			    void * rt_request_params_x ) {

	rt_response_params_t **ptr_rt_response_params = (rt_response_params_t **)ptr_rt_response_params_x;
        ad_server_additional_params_t *additional_parameter = (ad_server_additional_params_t *)additional_parameters_x;
	rt_request_params_t *rt_request_params = (rt_request_params_t *)rt_request_params_x;
	long oper_id = rt_request_params->in_server_req_params->oper_id;
	fte_additional_params_t  *fte_additional_params = rt_request_params->fte_additional_params;
	
	json_object *json_obj = NULL;
	json_object *id_obj = NULL;
	json_object *seatbid_arr = NULL;
	json_object *seatbid_obj = NULL;
	json_object *bid_arr = NULL;
	json_object *bid_obj = NULL;
	json_object *bidid_obj = NULL;
	json_object *customdata_obj = NULL;
	json_object *seat_obj = NULL;
	json_object *currrency_obj = NULL;

	int bid_arr_len = 0;
	int seatbid_arr_len = 0;
	int bid_loop = 0;
	int seat_loop = 0;
	char *buffer = NULL;
	int bids_processed = 0;	//Number of OpenRTB bids processed

	/*Variables present in seatbid but not in bid*/
	//char tmp_seatid[MAX_DSP_BUYER_ID_LEN + 1];	
	int tmp_seat_id = 0;
	

	rt_response_params_t *rt_response_params = NULL;    
  	rt_response_params = *ptr_rt_response_params;
	rt_response_params[index].bid_response_params.pub_deal_id[0] = '\0';
	// intialize to a USD. It will be overwritten if we have a valid or invalid currency code
	rt_response_params[index].currency_id = USD_CURRENCY_ID;

	//tmp_seatid[0]='\0';
	if ( additional_parameter->adserver_config_params == NULL ) {
     		OPENRTB_ERROR("Null adserver config parameter passed");
		return;
  	}
	int rtb_debug_flag = additional_parameter->adserver_config_params->rtb_debug_flag; 

	//check for zero bid
        if (rt_response_params[index].bid_response_params.http_response_code == 204 ) {
		if ( rtb_debug_flag ==  DEBUG_RTB || rtb_debug_flag ==  DEBUG_OPENRTB ) {
                	llog_write(L_DEBUG,"\nOPENRTB: Zero bid found from header for campaign %d",(int)rt_response_params[index].campaign_id);
		}
                rt_response_params[index].bid_response_params.ecpm = 0.0;
                rt_response_params[index].bid_response_params.response_complete = 1;
		return;
        }

	/*if (rt_response_params[index].bid_response_params.http_response_code == -1 ) {
                OPENRTB_DEBUG("Timeout for campaign %d",rt_response_params[index].campaign_id);
                return;
        }*/

	buffer = rt_response_params[index].bid_response_params.response_buffer;
  	if (buffer == NULL) {
			OPENRTB_ERROR("API RESPONSE is NULL for Campaign %ld, HTTP code:%d",
				rt_response_params[index].campaign_id, rt_response_params[index].bid_response_params.http_response_code);
    	return;
  	}
	if (check_if_json(buffer) == 0) {
	  	if ( rtb_debug_flag ==  DEBUG_RTB || rtb_debug_flag ==  DEBUG_OPENRTB ) {
			OPENRTB_ERROR("Invalid JSON string obtained:'%s' from campaign %ld",buffer, rt_response_params[index].campaign_id);
		}
		return;
	}
  
  	if ( rtb_debug_flag ==  DEBUG_RTB || rtb_debug_flag ==  DEBUG_OPENRTB ){
			ad_server_req_param_t *in_server_req_params = rt_request_params->in_server_req_params;
			long int t1 =  rt_request_params->stamp_before_api_cal_api_call.tv_sec * 1000 + 
							(rt_request_params->stamp_before_api_cal_api_call.tv_usec/1000);
			long int t2 = rt_response_params[index].bid_response_params.stamp_after_api_call.tv_sec * 1000 + 
							(rt_response_params[index].bid_response_params.stamp_after_api_call.tv_usec/1000);
			llog_write(L_DEBUG,"\nOPENRTB API RESPONSE for Campaign %ld, P:%ld,S:%ld,A:%ld,O:%ld,RT:%ld, start:  %s :end \n",
			rt_response_params[index].campaign_id, in_server_req_params->publisher_id, in_server_req_params->site_id, 
			in_server_req_params->ad_id, in_server_req_params->oper_id, t2 - t1, buffer);
  	}

	if( rt_request_params->in_server_req_params->wakanda_enabled )
	{
		dsp_message_t *dsp_msg = (dsp_message_t*)malloc( sizeof(dsp_message_t) ) ;
		dsp_msg->campaignid = rt_response_params[index].campaign_id ;
		dsp_msg->message = strdup( buffer ) ;
		dsp_msg->message_len = strlen( buffer ) ;
		dsp_msg->next = fte_additional_params->dsp_resp ;
		fte_additional_params->dsp_resp = dsp_msg ;
	}

  	json_obj = json_tokener_parse(buffer);
  	if ((json_obj == NULL) || (is_error(json_obj))) {
    		OPENRTB_ERROR("json_tokener_parse failed for Campaign:%ld\n", rt_response_params[index].campaign_id);
    		return;    
  	}

  	id_obj = get_json_child_from_parent(json_obj, ID, json_type_string);
  	if ( id_obj == NULL ) {
                OPENRTB_ERROR("Mandatory param ID not found for campaign:%ld", rt_response_params[index].campaign_id);
		goto end;
	}
	nstrcpy( rt_response_params[index].bid_response_params.request_id, id_obj->o.c_string ,MAX_UNIQUE_ID_LEN);
	rt_response_params[index].bid_response_params.request_id[MAX_UNIQUE_ID_LEN]='\0';

	seatbid_arr = get_json_child_from_parent(json_obj, SEATBID_ARR, json_type_array);
	if ( seatbid_arr == NULL ) {
                OPENRTB_ERROR("Mandatory param seatbid array not found for campaign:%ld", rt_response_params[index].campaign_id);
		goto end;
        } 

  	seatbid_arr_len = json_object_array_length(seatbid_arr);
	if (seatbid_arr_len < 1 ) {
		OPENRTB_DEBUG("Invalid seatbid array, campaign:%ld", rt_response_params[index].campaign_id);
		goto end;
	}

	bidid_obj = get_json_child_from_parent(json_obj, BID_ID, json_type_string);
        if ( bidid_obj != NULL) {
                nstrcpy( rt_response_params[index].bid_response_params.transaction_id,bidid_obj->o.c_string ,MAX_TRANSACTION_ID_SIZE);
		rt_response_params[index].bid_response_params.transaction_id[MAX_TRANSACTION_ID_SIZE] = '\0';
        }

	currrency_obj = get_json_child_from_parent(json_obj, CURRENCY, json_type_string);
	if(currrency_obj == NULL){
	
		rt_response_params[index].currency_id = USD_CURRENCY_ID;
		
	}else {
		rt_response_params[index].currency_id =  get_currency_id_from_hash(fte_additional_params->currency_xrate_map, currrency_obj->o.c_string);
	}

	if ((1 != rt_request_params->in_server_req_params->gdpr_req_params.is_gdpr_req) ||
			(GDPR_CONSENT_GIVEN == rt_request_params->in_server_req_params->gdpr_req_params.pm_consent_status)) {
		customdata_obj = get_json_child_from_parent(json_obj, CUSTOM_DATA, json_type_string);
		if (NULL != customdata_obj) {
			nstrcpy(rt_response_params[index].bid_response_params.cookie,customdata_obj->o.c_string ,MAX_COOKIE_SIZE);
			rt_response_params[index].bid_response_params.cookie[MAX_COOKIE_SIZE] = '\0';
		}
	}

	parse_response_ext_object(&rt_response_params[index], json_obj);

	for (seat_loop = 0; seat_loop < seatbid_arr_len; seat_loop++) {

		if ( bids_processed == MAX_BIDS_LIMIT ) {
			OPENRTB_ERROR("Max bids limit of %d reached.. Ignoring remaining bids, campaign:%ld", 
					MAX_BIDS_LIMIT, rt_response_params[index].campaign_id);
			goto end;
		}
		//tmp_seatid[0]='\0';
		tmp_seat_id = 0;
		seatbid_obj = json_object_array_get_idx(seatbid_arr, seat_loop);
		if ( seatbid_obj == NULL ) {
                	OPENRTB_DEBUG("seatbid object not found , campaign:%ld", rt_response_params[index].campaign_id);
			continue;
        	}

    		bid_arr = get_json_child_from_parent(seatbid_obj, BID_ARR, json_type_array);
		if ( bid_arr == NULL ) {
			OPENRTB_ERROR("Mandatory param bid array not found, campaign:%ld", rt_response_params[index].campaign_id);
			goto end;
		}

		seat_obj = get_json_child_from_parent(seatbid_obj, CSEAT, json_type_string);
                if ( seat_obj != NULL) {
                        //nstrcpy(tmp_seatid,seat_obj->o.c_string,MAX_DSP_BUYER_ID_LEN);
			//tmp_seatid[MAX_DSP_BUYER_ID_LEN] = '\0';
			tmp_seat_id = atoi(seat_obj->o.c_string);
			/*if ( tmp_seat_id == 0 ) {
				OPENRTB_ERROR("Invalid seat id %s obtained..Numeric string is required",seat_obj->o.c_string);
			}*/
                }

		bid_arr_len = json_object_array_length(bid_arr);
		if (bid_arr_len < 1 ) {
                	OPENRTB_DEBUG("Invalid bid array, campaign:%ld", rt_response_params[index].campaign_id);
			goto end;
		}
		//Parse only upto MAX_BIDS_LIMIT total bids... ignore remaining bids
		if ( bids_processed + bid_arr_len > MAX_BIDS_LIMIT )	{
			OPENRTB_ERROR("Max bids limit of %d reached.. Ignoring remaining bids, campaign:%ld", 
					MAX_BIDS_LIMIT, rt_response_params[index].campaign_id);
			bid_arr_len = MAX_BIDS_LIMIT - bids_processed;
		}


		if( seat_loop == 0 ){
			bid_obj = json_object_array_get_idx(bid_arr, 0);
	                if ( bid_obj == NULL ) {
	                        OPENRTB_DEBUG("bid object not found, campaign:%ld", rt_response_params[index].campaign_id);
				goto end;
	                }
			
			rt_response_params[index].child_index = -1;
			get_dsp_bids(bid_obj, &rt_response_params[index],oper_id, rt_response_params[index].currency_id, fte_additional_params, additional_parameter);
			//nstrcpy(rt_response_params[index].bid_response_params.str_dsp_buyer_id,tmp_seatid,MAX_DSP_BUYER_ID_LEN);
			//rt_response_params[index].bid_response_params.str_dsp_buyer_id[MAX_DSP_BUYER_ID_LEN] = '\0';	
			rt_response_params[index].bid_response_params.dsp_buyer_id = tmp_seat_id;
			printbid_openrtb(oper_id, rt_response_params[index].campaign_id, &rt_response_params[index].bid_response_params, additional_parameter, rt_response_params[index].currency_id, rt_response_params[index].deal_no_bid_reason);
			bids_processed++;
  		}	


		if (*response_alloc_count < *response_count + bid_arr_len ) {
    			rt_response_params = realloc(*ptr_rt_response_params, ((*response_alloc_count) + bid_arr_len + RT_RESPONSE_INCREMENT_COUNT) * sizeof(rt_response_params_t));

    			if(rt_response_params){
      				*ptr_rt_response_params =  rt_response_params;
      				*response_alloc_count =  (*response_alloc_count) + bid_arr_len + RT_RESPONSE_INCREMENT_COUNT;
				OPENRTB_DEBUG("Memory reallocated. new count:%d",*response_alloc_count);
			} else {
                     		OPENRTB_DEBUG("Not enough  memory to accomodate bids");
                       		goto end;
			}
              	}

		//If dsp sends more than one bid we will treat it as a different response.
		//We will add other bids to the end of array
		for(bid_loop = 0; bid_loop < bid_arr_len; bid_loop++) {
			//if it is first bid, no need to copy parameters
          		if(seat_loop == 0 && bid_loop == 0) {
            			continue;
          		}
    			bid_obj = json_object_array_get_idx(bid_arr, bid_loop);
    			if( bid_obj )
    			{
				//copy params from index campaign
                                copy_rt_response_params_openrtb(&rt_response_params[index], &rt_response_params[*response_count]);
      				get_dsp_bids(bid_obj, &rt_response_params[*response_count], oper_id,  rt_response_params[index].currency_id, fte_additional_params, additional_parameter);

				//nstrcpy(rt_response_params[*response_count].bid_response_params.str_dsp_buyer_id,tmp_seatid,MAX_DSP_BUYER_ID_LEN);
				rt_response_params[*response_count].bid_response_params.bid_id = bids_processed;
				rt_response_params[*response_count].bid_response_params.dsp_buyer_id = tmp_seat_id;
				printbid_openrtb(oper_id, rt_response_params[*response_count].campaign_id, 
					&rt_response_params[*response_count].bid_response_params, additional_parameter, 
					rt_response_params[index].currency_id, rt_response_params[index].deal_no_bid_reason);
				rt_response_params[index].child_index = *response_count;
				index = *response_count;
				*response_count = *response_count + 1;
				bids_processed++;
    			}
  		}

  	}
end:

	//check for verifying mandatory params.
        if (
                        rt_response_params[index].bid_response_params.request_id[0] == '\0'
           ) {
                llog_write(L_DEBUG,"\nOPENRTB: Realtime response incomplete. Missing request id. campaign:%ld", 
			rt_response_params[index].campaign_id);
                rt_response_params[index].bid_response_params.ecpm = 0.0;
	}

  	//free json object
  	if ((json_obj != NULL) && (!is_error(json_obj))) {
    		json_object_put(json_obj);
		json_obj = NULL;
  	}

	return;
}
