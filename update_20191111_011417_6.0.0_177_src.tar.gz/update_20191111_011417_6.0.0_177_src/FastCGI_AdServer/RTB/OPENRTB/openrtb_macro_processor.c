/*
	 PubMatic Inc. ("PubMatic") CONFIDENTIAL
	 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/


#include "openrtb.h"
#include "rt_types.h"
#include "error.h"

#define MAX_MACROS 7
#define MAX_MACRO_LEN 25
#define MACRO_COMMON_STRING "${AUCTION_"
#define MACRO_START "${"
#define COMMON_STRING_LEN 10

enum macro_id {INVALID_MACRO = -1,MACRO_AD_ID,MACRO_BID_ID,MACRO_CURRENCY,MACRO_ID,MACRO_IMP_ID,MACRO_PRICE,MACRO_SEAT_ID}; 

//sorted map of macros
static const char macro_map[MAX_MACROS][MAX_MACRO_LEN]={"${AUCTION_AD_ID}","${AUCTION_BID_ID}","${AUCTION_CURRENCY}","${AUCTION_ID}","${AUCTION_IMP_ID}","${AUCTION_PRICE}","${AUCTION_SEAT_ID}"};

/*
 * Binary search macro_map and return index of key into it
 */
static int binary_search(char search[MAX_MACRO_LEN]) {

	int first = 0;
	int last = MAX_MACROS - 1;
	int middle = (first + last)/2;

	while( first <= last ) {
		if ( strcmp(macro_map[middle] + COMMON_STRING_LEN,search) < 0) {
			first = middle + 1;
		}
		else if ( strcmp(macro_map[middle] + COMMON_STRING_LEN,search) == 0 ) {
			return middle;
		}
		else {
			last = middle - 1;
		}
		middle = (first + last)/2;
	}
	return INVALID_MACRO;
}

/*
 * Function to get macro name from adscript
 * Returns lenght of macro name(key)
 */
static int get_macro(const char *haystack, char *needle) {
	int i = 0;
	for ( i = 0; i < MAX_MACRO_LEN; i++) {
		needle[i] = haystack[i];
		if ( haystack[i] == '}' ) {
			needle[i+1] = '\0';
			return (i+1);
		}
	}
	if (i == MAX_MACRO_LEN) {
		ERROR_LOG("\nOPENRTB:Inavlid Macro found");
		needle[0]='\0';
		return i;
	}
	//shouldnt reach here
	return INVALID_MACRO;
}

/*
 * Function to replace all openrtb macros found in adscript
 */
void apply_openrtb_macro_substitution(selected_campaign_attribute_t* selected_camp, 
		ad_server_additional_params_t *additional_params,
		fte_additional_params_t *fte_additional_params) {
	char** adscript = &selected_camp->creative_buff;
	char *adcode = NULL;
	char *pos;
	int macro_index = 0;
	int key_len = 0;
	char tmp_key[MAX_MACRO_LEN + 1];
	int adscript_index= 0, adcode_index= 0;
	int bytes_written = 0;
	int bytes_to_copy = 0;
	int rtb_debug_flag = additional_params->adserver_config_params->rtb_debug_flag;
	

	adcode = (char *)malloc(sizeof(char)*MAX_FIXED_ADSCRIPT_LEN);
	if (adcode == NULL) {
		ERROR_LOG("adcode memory allocation failed");
		return;
	}
	rt_bid_response_params_t *bid_response_params = &(selected_camp->rt_response_params.bid_response_params);

	if ( rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB) {
		llog_write(L_DEBUG,"\n\nOPENRTB campaign %ld won. Applying Macro substitution..",selected_camp->rt_response_params.campaign_id);
	}

	while(1) {
		//Find position of "${AUCTION_" in adscript
		pos=strstr((*adscript) + adscript_index, MACRO_COMMON_STRING);
		if (pos == NULL) { 
			break;                                       
		}

		//copy portion till position into adcode
		bytes_to_copy = (int)(pos-((*adscript) + adscript_index));      
		strncpy(adcode + adcode_index, *adscript + adscript_index, bytes_to_copy);

		//get full key string
		key_len = get_macro((*adscript) + adscript_index + bytes_to_copy, tmp_key);                                                    
		if (key_len > COMMON_STRING_LEN && key_len < MAX_MACRO_LEN) {
			//get position of key from sorted macro array
			macro_index = binary_search(tmp_key + COMMON_STRING_LEN);
		} else {
			macro_index = INVALID_MACRO;                                             
		}

		//increment pointers accordingly 
		adcode_index += bytes_to_copy;
		adscript_index += bytes_to_copy;

		//replace macro with it's value 
		switch(macro_index) {

			/*case MACRO_AD_ID:    //will be added later 
				bytes_written=sprintf(adcode+adcode_index,"%d",(int)out_served_params->ad_id);
				break;*/

			case MACRO_BID_ID:                           
				bytes_written=sprintf(adcode+adcode_index,"%s",bid_response_params->str_bid_id);        
				break;

			case MACRO_CURRENCY:                         
				bytes_written=sprintf(adcode+adcode_index,"%s",
						GET_CURRENCY_CODE_FROM_ID(selected_camp->rt_response_params.currency_id,
							fte_additional_params->currency_xrate_map,
							fte_additional_params->currency_count));
				break;               

			case MACRO_ID:
				bytes_written=sprintf(adcode+adcode_index,"%s",bid_response_params->request_id);
				break;

			case MACRO_IMP_ID:
				bytes_written=sprintf(adcode+adcode_index,"%s",DEFAULT_IMP_ID);
				break;

			case MACRO_PRICE:
				bytes_written=sprintf(adcode+adcode_index,"%lf",selected_camp->pbmt_ecpm);
				break;

			case MACRO_SEAT_ID:
				//bytes_written=sprintf(adcode+adcode_index,"%s",bid_response_params->str_dsp_buyer_id);
				if (bid_response_params->dsp_buyer_id != 0) {
					bytes_written=sprintf(adcode+adcode_index,"%d",bid_response_params->dsp_buyer_id);
				} else {
					bytes_written=0;
				}					
				break;

			default:
				OPENRTB_DEBUG("\nInvalid macro obtained");
				bytes_written=sprintf(adcode+adcode_index,"%s",MACRO_COMMON_STRING);
				key_len=COMMON_STRING_LEN;  

		}
		//increment adscript_index by macro length and adcode_index by value length
		adscript_index += key_len;
		adcode_index += bytes_written;
		bytes_written = 0;
	}

	//copy the rest of adscript into adcde 
	strcpy(adcode + adcode_index,(char *)(*adscript + adscript_index));
	/*free original adscript*/
	free((*adscript));
	/*set new adcode as adscript*/
	(*adscript) = (adcode);

	if ( rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB) {
		llog_write(L_DEBUG,"\n\nOPENRTB admarkup after macro substitution:'%s'",*adscript);
	}
	return;
}

/*
	 int main(int argc, char *argv[]) {
	 if (argv[1] == NULL ) {
	 printf("\nNo Input Obtained");
	 return;
	 }
	 char *str=strdup(argv[1]);
	 printf("\nORIGINAL_SCRIPT:%s",str);
	 apply_openrtb_macro_substitution(&str);
	 printf("\nNEW_SCRIPT:%s\n",str);
	 free(str);
	 }
	 */
