/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "error.h"
#include "fte_handle.h"
#include "get_user_audience_info.h"
#include "audience_targeting_util.h"
#include "get_user_audience_info.h"
#define MAXSTACK 100
#define EMPTYSTACK -1
#define TOKEN_FLAG -2


/* This file contains set of functions to implement stack operations to evaluate the postfix expression using stack. */

typedef struct STACK{
	
	char *token;
	int value;

}stack_t;

static inline int full(int top) {
        if (top == (MAXSTACK - 1))
                return 1;
        else
                return 0;
}

static inline int empty(int top) {
        if (top == EMPTYSTACK)
                return 1;
        else
                return 0;
}

static inline int push(stack_t *stack, int *top, char *token, int value){

	if (!full(*top)){
		stack[++(*top)].token = token;
		stack[(*top)].value = value; 
		return 0;

	}else{
		llog_write(L_DEBUG, "ERROR: stack overflow, %s,%d\n", __FILE__, __LINE__);
		return 1;
	}

}


static inline int pop(stack_t *stack, int *top, char **token, int *value){
	if (!empty(*top)) {
		(*token) = stack[(*top)].token;
		(*value) = stack[(*top)--].value;
		return 0;
	
	}else{
		llog_write(L_DEBUG, "ERROR: stack empty, %s:%d\n", __FILE__, __LINE__);
		token = NULL;
		(*value) = 0;
		return 1;
	}
}

/*
	Function will add each segment in segment_list to used_segments if segment is not present in used_segments list.
	Function may not add segment to used_segment list if there not enough space to add new segment.
*/


static inline int update_used_segments(char *used_segments, char *segment_list ) {

	const char *tmp_used_segments = used_segments;
	char *pos;
	char *token = NULL;
	char *saveptr = NULL;
	int len = 0;
	int used_segments_len = 0;
	char *tmp_segment_list = NULL;
	int found = 0;

	if (used_segments == NULL || segment_list == NULL){

		return ADS_ERROR_SUCCESS;
	}

	used_segments_len = strlen(used_segments);	
	tmp_segment_list = strdup (segment_list);
	token = strtok_r (tmp_segment_list,",", &saveptr);


	while (token != NULL ){
		tmp_used_segments = used_segments;
		len = strlen(token);
		found = 0;
		while ((pos = strstr(tmp_used_segments, token)) != NULL) {
			if (pos == tmp_used_segments) {
				if (*(pos + len) == ',' || *(pos + len) == '\0') { 
				/* if we found the segment in the beginning and its the only segment in the list */
					found = 1;
					break;
				}
			}else{

				/* Make sure the token(segment) had a comma before it (,a_b) and a comma after it or a NUL (a_b, or a_b\0) */
				if ( (*(pos-1) == ',') && (*(pos + len) == ',' || (*(pos + len) == '\0'))) {
					found = 1;
					break;
				}
			}

			tmp_used_segments = strchr(tmp_used_segments,',');
			if (NULL == tmp_used_segments) break;

			tmp_used_segments++;
		}
		if (found == 0){
			
			// To check the buffer overflow validate there is enough space to store token and , (comma) in used_segments
		
			if ( (used_segments_len + len + 1) < MAX_USER_SEGMENT_LIST_SIZE){
				/* add comma to list if there are any segments before adding new segment */ 
				if ((used_segments_len - 1) > 0){
					strncat (used_segments, ",", MAX_USER_SEGMENT_LIST_SIZE - used_segments_len);
					used_segments_len++;
				}
				
				strncat (used_segments, token, MAX_USER_SEGMENT_LIST_SIZE - used_segments_len);
				used_segments[MAX_USER_SEGMENT_LIST_SIZE] = '\0';

				used_segments_len = used_segments_len + len;
			}

		}
		token = strtok_r (NULL, ",", &saveptr);
	}

	free (tmp_segment_list);
	/* we did not find a trace of the segment in the list in our first call to strstr() so return '0' */
	return ADS_ERROR_SUCCESS;
}
/*
	Function will evaluate segment expression using audience segment information.
	Result of expression will be 1 or 0.
	Function will generate used_segments list i.e list of segments used when result of expression is 1
		
*/
int evaluate_audience_user_segments (const char *expression, void *segment_list, int *expression_result, char *used_segments) {

	/* Local Variables */
	char *token = NULL;
	char *token1 = NULL;
	char *token2 = NULL;
	int result = 0;
	int operand1 = 0;
	int operand2 = 0;
	int value1 = 0 , value2 = 0 ;
	char *saveptr = NULL;
	char *processing_string = NULL;
	int top = EMPTYSTACK;
	stack_t items [MAXSTACK];
	char used_token[MAX_USER_SEGMENT_LIST_SIZE+1] = {'\0'};
	char *tmp_used_token = NULL;

	(*expression_result) = 0;

	if(expression == NULL || segment_list == NULL) {
		llog_write(L_DEBUG,"ERROR: expression is NULL or segment list is NULL, %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	processing_string = strdup(expression);
	if (processing_string == NULL) {
		llog_write(L_DEBUG, "ERROR: Failed to strdup expression, %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_NOMEMORY; 
	}

#ifdef DEBUG
		llog_write(L_DEBUG, "INFO: AUDIENCE: evaluet user segment expression:%s\n", processing_string);
#endif

	token = strtok_r(processing_string, ",", &saveptr);

	while (token != NULL) {
		token1 = NULL;
		token2 = NULL;
		used_token[0] = '\0';
		tmp_used_token = NULL;

#ifdef DEBUG
		llog_write(L_DEBUG, "INFO: AUDIENCE: segment expression token:%s\n", token);
#endif 
		if ((*token) != '&' && (*token) != '|' && (*token) != '!') {
/*
#ifdef DEBUG
			llog_write(L_DEBUG, "INFO: AUDIENCE: push token:%s\n", token);	
#endif
*/			if (push(items, &top, token, TOKEN_FLAG) == 1)
				break;
		} else {
			if (pop(items, &top, &token1, &value1) == 1)
				break;
/*
#ifdef DEBUG
			llog_write(L_DEBUG, "INFO: AUDIENCE: poped token1:%s\n", token1);	
#endif
*/
			if (value1 == TOKEN_FLAG){
				if (token1 != NULL){
					validate_user_segment(segment_list, token1, &operand1);
				}else{
					llog_write(L_DEBUG, "ERROR: Wrong token %s:%d\n", __FILE__, __LINE__);
					break;
				}
			}else{
				operand1 = value1;
			}

			if (*token == '&' || *token == '|'){
				if (pop(items, &top, &token2, &value2) == 1)
					break;
	/*
#ifdef DEBUG
				llog_write(L_DEBUG, "INFO: AUDIENCE: poped token2:%s\n", token2);	
#endif
	*/

				if (value2 == TOKEN_FLAG){
					if (token2 != NULL){
						validate_user_segment(segment_list, token2, &operand2);
					}else{
						llog_write(L_DEBUG, "ERROR: Wrong token %s:%d\n", __FILE__, __LINE__);
						break;
					}
				}else{
					operand2 = value2;
				}
			}	

			if ((operand1 == 1 || operand1 == 0) && (operand2 == 1 || operand2 == 0)){
		
				if ((*token) == '&'){
					result = operand1 && operand2;
					
					/*
					* If result is 1 then operand1 and operand2 are evaluated so track their corresponding tokens else
					* track the segments for operand that lead to result as 0
					*/ 
					if (result == 1){
						
						if (token1 != NULL){
							strncpy(used_token, token1, MAX_USER_SEGMENT_LIST_SIZE);
							used_token[MAX_USER_SEGMENT_LIST_SIZE] = '\0'; 
						}

						if (token2 != NULL){
							update_used_segments(used_token, token2);
						}
                    }else{
                       if (operand1 == 0){
                            if (token1 != NULL){
                                strncpy(used_token, token1, MAX_SEGMENT_EXPR_SIZE);
                                used_token[MAX_SEGMENT_EXPR_SIZE] = '\0';
                            }
                        }else{
                            if (token2 != NULL){
                                strncpy(used_token, token2, MAX_SEGMENT_EXPR_SIZE);
                                used_token[MAX_SEGMENT_EXPR_SIZE] = '\0';
                            }
                        }
					}

#ifdef DEBUG
                    llog_write(L_DEBUG, "INFO: AUDIENCE: AND used token : %s \n", used_token);
#endif
				}else if ((*token) == '|'){

					result = operand1 || operand2;

					/*
					* If result is 1 then track the segments of operand1 or operand2 because of which result is 1 else
					* track the segments for operand1 and operand2 that lead to result as 0
					*/ 
					if (result == 1){
						if (operand1 == 1){
							if (token1 != NULL){
								strncpy(used_token, token1, MAX_USER_SEGMENT_LIST_SIZE);
								used_token[MAX_USER_SEGMENT_LIST_SIZE] = '\0';
							}
/*
#ifdef DEBUG
							llog_write(L_DEBUG, "INFO: AUDIENCE: Used token :%s \n", token1 == NULL ? "NULL" : token1);
#endif
*/
						}else{
							if (token2 != NULL){
								strncpy(used_token, token2, MAX_USER_SEGMENT_LIST_SIZE);
								used_token[MAX_USER_SEGMENT_LIST_SIZE] = '\0';
							}
/*
#ifdef DEBUG
							llog_write(L_DEBUG, "INFO: AUDIENCE: Used token :%s \n", token2 == NULL ? "NULL" : token2);
#endif
*/
						}
					}else{

                        if (token1 != NULL){
                            strncpy(used_token, token1, MAX_SEGMENT_EXPR_SIZE);
                            used_token[MAX_SEGMENT_EXPR_SIZE] = '\0';
                        }

                        if (token2 != NULL){
                            update_used_segments(used_token, token2);
                        }

#ifdef DEBUG
                        llog_write(L_DEBUG, "INFO: AUDIENCE: OR used token : %s \n", used_token);
#endif
	
					}					
				}else if ((*token) == '!'){

					result = ! operand1 ;
					/*
					* Track the segments if result is 1
					*/

					if (result == 1){
						if (token1 != NULL){
							strncpy(used_token, token1, MAX_SEGMENT_EXPR_SIZE);
							used_token[MAX_SEGMENT_EXPR_SIZE] = '\0';
						}

					}
#ifdef DEBUG					
					llog_write(L_DEBUG, "\n NOT result :%d, used_token:%s\n", result, used_token);
#endif
				}
			}else{
				llog_write(L_DEBUG, "ERROR : Invalid values for operand, %s:%d\n", __FILE__, __LINE__);
				break;
			}

			if ('\0' != used_token[0]){
				tmp_used_token = strdup(used_token);
			}

			if (token1 != NULL && value1 != TOKEN_FLAG)
				free(token1);
			if (token2 != NULL && value2 != TOKEN_FLAG)
				free(token2);
/*
#ifdef DEBUG
				llog_write(L_DEBUG, "INFO: AUDIENCE: Pusing used token : %s\n", tmp_used_token == NULL ? "NULL" : tmp_used_token); 
#endif
*/
				if (push(items, &top, tmp_used_token, result) == 1)
					break;

		}
		
		token = strtok_r(NULL, ",", &saveptr);
   	}

	if (top == 0) {
		pop(items, &top, &token1 , &value1);
	
		if (value1 != TOKEN_FLAG){
			if (value1 == 1){
				update_used_segments (used_segments, token1);
			}
			free (token1);
		}else{
			validate_user_segment(segment_list, token1, &value1);
			if (value1 == 1){
				update_used_segments (used_segments, token1);	
			}
		}

		(*expression_result) = value1;

#ifdef DEBUG		 
		 llog_write(L_DEBUG, "INFO: AUDIENCE: Final used token : %s, expression result:%d\n", used_segments, (*expression_result));
#endif
	} else {

		llog_write(L_DEBUG, "ERROR: Expression is wrong. Cannot Evaluate !!!\n");
		while ( pop(items, &top, &token1 , &value1) == 0){
			if (value1 != TOKEN_FLAG){
				free (token1);
			}
		}
	}

	free (processing_string);
	processing_string = NULL;

	return ADS_ERROR_SUCCESS;
}

/* Function to initilaise audience curl handle */

int init_audience_curl_handle(CURL **audience_curl_handle, int connection_timeout, int request_timeout ){

	CURLcode curl_retval = CURLE_OK;

	(*audience_curl_handle) = NULL;

	(*audience_curl_handle) = curl_easy_init();
	if ((*audience_curl_handle) == NULL){
		llog_write(L_DEBUG,"\nERROR curl_easy_init() failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	curl_retval = curl_easy_setopt((*audience_curl_handle), CURLOPT_CONNECTTIMEOUT_MS, connection_timeout);
	if (curl_retval != CURLE_OK){
		llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set audience connection timeout %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	curl_retval = curl_easy_setopt((*audience_curl_handle), CURLOPT_TIMEOUT_MS, request_timeout);
	if (curl_retval != CURLE_OK){
		llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set audience request timeout %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	curl_retval = curl_easy_setopt((*audience_curl_handle), CURLOPT_NOSIGNAL, 1);
	if (curl_retval != CURLE_OK){
		llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set no signal %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}
#if 0
	curl_retval = curl_easy_setopt((*audience_curl_handle), CURLOPT_VERBOSE, 1);
	if (curl_retval != CURLE_OK){
		llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

#endif

	return ADS_ERROR_SUCCESS;
}

/* function to free curl handle */

void free_audience_curl_handle(CURL **audience_curl_handle){
	if ( audience_curl_handle != NULL && (*audience_curl_handle) != NULL){
		curl_easy_cleanup((*audience_curl_handle));
		(*audience_curl_handle) = NULL;
	}
}

