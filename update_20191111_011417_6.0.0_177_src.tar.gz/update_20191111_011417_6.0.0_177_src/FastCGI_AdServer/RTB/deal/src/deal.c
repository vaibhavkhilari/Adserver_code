/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "debug.h"
#include "platform.h"
#include "error_code.h"
#include "log_fw.h"
#include "error.h"
#include "debug.h"
#include "db_error.h"
#include "fte_util.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include <string_util.h>
#include "rtb_brand_control_util.h"
#include "rt_types.h"
#include "deal.h"
#include "deal_util.h"
#include "audience_targeting_util.h"
#include "time_parting.h"
#include "day_parting.h"
#include "libstats_util.h"
#include "log_fw.h"
#include "deal_def.h"
#include "deal_fast_targeting.h"
#include "evaluate_custom_targeting.h"
#include "ad_server_click_track_utils.h"
#include "audience_profile_structure.h"
#include "slist.h"

#define ALLOC_DEAL_CRITERIA_COUNT			5
#define ALLOC_DEAL_PARAMS_COUNT				15
#define ALLOC_DEALS_COUNT					5
#define MAX_DEBUG_DEAL_BUFF 				1800

#define IS_SET( BITMAP, BITNUM ) ( BITMAP[BITNUM/8] && ( BITMAP[BITNUM/8]&(0x80>>(BITNUM%8)) ) )

#define DEAL_APPLICATION "DEAL_APP"

#define USER_COOKIE_PRESENT 1
#define USER_COOKIE_ABSENT  2

#define GRACE_TIME_FOR_REFERENCES_GONE 900 // 15 mins

#define AVERAGE_OF( SUM, COUNT ) ( ( COUNT > 0 ) ? ( SUM/COUNT ) : ( 0 ) )

#define likely(x)      __builtin_expect(!!(x), 1) 
#define unlikely(x)    __builtin_expect(!!(x), 0) 

#define MAX_MATRIX_COLUMNS 100000

static size_t deal_count = 0 ; //protected by deal_list_lock
static deal_params_t **deal_list = NULL ; //protected by deal_list_lock
static deal_evaluator_h deal_evaluator_hdl = NULL ; //protected by deal_list_lock

static pthread_rwlock_t deal_list_lock ;

static deal_params_t **new_deal_list = NULL ;
static size_t new_deal_count = 0 ;

enum
{
				pub_id_index = 0 ,
				site_id_index,
				country_ids_index,
				region_ids_index,
				city_ids_index,
				dma_ids_index,
				os_type_id_index,
				os_id_index,
				ad_id_index,
				make_model_id_index,
				carrier_id_index,
				browser_id_index,
				mobile_device_type_id_index,
				mobile_request_type_id_index,
				mobile_udid_type_validation_index,
				mobile_latlong_validation_index,
				fold_position_id_index,
				video_ad_pos_index,
				video_ad_type_index,
				video_skippable_index,
				video_placement_index,
				video_vpaid_index,
				matched_user_index,
				platform_id_index,
				source_index,
				time_parting_index,
				days_of_week_index,
				viewability_index,
				row_index_max //fast targeting parameter count
} ;


//TODO convert this to a pointer like above
static int row_ids_exclude[row_index_max] ; //protected by deal_list_lock

/*
 * Get all deals which are available for the given Publisher.
 * Returns ADS_ERROR_SUCCESS on success & ADS_ERROR_INTERNAL on failure.
 */
static int pmp_deal_id_compare(const void *key, const void *pelem)
{
				publisher_request_deal_t *deal = *(publisher_request_deal_t **)pelem;
				return strcmp(((char *)key), deal->id);
}

void compose_deals_params_post_data(char **post_data,
									publisher_site_ad_campaign_list_t *adcampaigns,
									const rt_request_url_params_mask_t * rt_request_url_params_mask1,
									fte_additional_params_t *fte_additional_parameters,
									int *flag)
{
	char *post_temp_ptr = NULL;
	int i = 0, counter = 0;
	dsp_buyer_t **applicable_dsp_buyers = NULL;

	if (post_data == NULL ||
		*post_data == NULL ||
		adcampaigns == NULL ||
		rt_request_url_params_mask1 == NULL ||
		!CAMPAIGN_HAS_DEALS(adcampaigns, rt_request_url_params_mask1))
	{
		return;
	}

	post_temp_ptr = *post_data;
	applicable_dsp_buyers = adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers;

	//Seprator.
	if (*flag == 1)
	{
		memcpy(post_temp_ptr, ",", 1);
		post_temp_ptr++;
	}
	//Start of Deal params.
	memcpy(post_temp_ptr, DEAL_PARAMS_STRING, (sizeof (DEAL_PARAMS_STRING) - 1));
	post_temp_ptr += (sizeof (DEAL_PARAMS_STRING) - 1);

	for (i = 0; i < adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers_count && counter < MAX_DEAL_OBJECTS; i++) 
	{

		/*Check deal_type, it can be either 1 (for ATOM/pub connect) or 0 (for PMP deal) 
		* if deal_type != 0 skip till ATOM integration is done
		*/

		if (applicable_dsp_buyers[i]->parent_deal_params->deal_type != PMP_DEAL){
			continue;
		}

		if (i > 0)
		{
			//Add separator
			memcpy(post_temp_ptr, ",", 1);
			post_temp_ptr += 1;
		}
		
		__sync_fetch_and_add(&( (deal_stats_t*)applicable_dsp_buyers[i]->parent_deal_params->p_stats)->sent_to_dsp, 1 ) ;

		//Start Deal object.
		memcpy(post_temp_ptr, DEAL_OBJECT_START_STRING, sizeof (DEAL_OBJECT_START_STRING) - 1);
		post_temp_ptr += sizeof (DEAL_OBJECT_START_STRING) - 1;
		//Deal Id.
		json_encode_string(&post_temp_ptr, DEAL_ID_STRING, applicable_dsp_buyers[i]->parent_deal_params->pub_deal_id, DO_NOT_ADD_SEPARATOR);
		if (rt_request_url_params_mask1->buyer_id_passing_enable_flag == 1 &&
				applicable_dsp_buyers[i]->dsp_buyer_id != DEFAULT_DSP_BUYER_ID)
		{
			//Buyer Id.
			json_encode_integer(&post_temp_ptr, DEAL_BUYER_ID_STRING, applicable_dsp_buyers[i]->dsp_buyer_id, ADD_SEPARATOR);
		}
		//Auction Id.
		json_encode_integer(&post_temp_ptr, DEAL_AUCTION_ID_STRING, applicable_dsp_buyers[i]->deal_pub.auction_id, ADD_SEPARATOR);
		//Floor eCPM.
		double deal_ecpm_dsp_native = CONVERT_USD_TO_NATIVE_CURRENCY(applicable_dsp_buyers[i]->deal_pub.deal_ecpm_usd,
				adcampaigns->dsp_currency_id,
				fte_additional_parameters->currency_xrate_map,
				fte_additional_parameters->currency_count);
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		fprintf(stderr,"\nDeal currency conversion while creating PubMatic RTB post data: Deal pub deal id: %s, DSP currency id: %d, Deal currency value in DSP currency: %f, Deal USD currency value: %f\n",
												applicable_dsp_buyers[i]->parent_deal_params->pub_deal_id, adcampaigns->dsp_currency_id,
												deal_ecpm_dsp_native, applicable_dsp_buyers[i]->deal_pub.deal_ecpm_usd ) ;
#endif
		json_encode_double(&post_temp_ptr, DEAL_FLOOR_STRING, deal_ecpm_dsp_native, ADD_SEPARATOR);
		//End Deal object.
		memcpy(post_temp_ptr, DEAL_OBJECT_END_STRING, sizeof (DEAL_OBJECT_END_STRING) - 1);
		post_temp_ptr += sizeof (DEAL_OBJECT_END_STRING) - 1;
		applicable_dsp_buyers[i]->in_rtb_request = ADDED_IN_RTB_REQUEST;
		counter++;
	}
	//End of Deal params.
	memcpy(post_temp_ptr, DEAL_PARAMS_STRING_END, (sizeof (DEAL_PARAMS_STRING_END) - 1));
	post_temp_ptr += (sizeof (DEAL_PARAMS_STRING_END) - 1);

	*post_data = post_temp_ptr;
	*flag = 1;

	// Add stats for alert in case when number of deal passed to campaign has reached to MAX_DEAL_OBJECTS
	if (counter >= MAX_DEAL_OBJECTS){ 
		increment_stats_counters(&(fte_additional_parameters->libstat_counters[0]), RTB_MAX_DEAL_VIOLATION_COUNT_ID, adcampaigns->campaign_id);
		//fprintf (stderr, "\nALERT: MAX_DEAL_OBJECTS limit hit for ad_id:%u, campaign_id:%u, dsp_id:%u\n",
		LOG_CRITICAL(MAX_DEAL_OBJ_LIMIT_HIT,MOD_DEFAULT,
				adcampaigns->ad_id, adcampaigns->campaign_id, adcampaigns->dp_id);	
	}
}

/*
 * Process DSP repsonce for passed Deal info.
 * As DSP shall be returning Deal Id given by Publisher (pub_deal_id) as part of bid response,
 * We need to look for its corrspoding deal_params_t & set adcampaign->dsp_interested_deal accordingly.
 * This will help us to override Deal Margin as adcampaign->second_price.
 * ASSUMTION: For given Deal atmost one buyer is supported for each DSP.
 *            If this is not the case, then along with pub_deal_id we need to also make buyer_id mandatory
 *            to keep track of won deal impression at buyer level.
 */
void process_dsp_deal_response(publisher_site_ad_campaign_list_t *adcampaign,
								rt_response_params_t *rt_response_params)
{
	dsp_buyer_t **applicable_dsp_buyers = NULL;
	deal_params_t *prev_parent_deal_params = NULL;
	int i = 0, retval = 0;
	int counter = 0;

	if (adcampaign == NULL ||
		adcampaign->ad_campaign_list_setings->applicable_dsp_buyers == NULL ||
		*(adcampaign)->ad_campaign_list_setings->applicable_dsp_buyers == NULL ||
		adcampaign->ad_campaign_list_setings->applicable_dsp_buyers_count == 0 ||
		adcampaign->ad_campaign_list_setings->dsp_interested_deal != NULL||
		rt_response_params == NULL ||
		rt_response_params->bid_response_params.pub_deal_id[0] == '\0'	
		)
	{
		//Failed to found deal_params_t for given pub_deal_id, So clear pub_deal_id from bid responce this
		//will prevent Rule Engine to apply any rules set against this pub_deal_id.
		rt_response_params->bid_response_params.pub_deal_id[0] = '\0';
		return;
	}

	applicable_dsp_buyers = adcampaign->ad_campaign_list_setings->applicable_dsp_buyers;

	LOG_INFO (DEAL_DBG_1, DEAL_MODULE,  adcampaign->campaign_id, adcampaign->ad_campaign_list_setings->applicable_dsp_buyers_count, 
				rt_response_params->bid_response_params.pub_deal_id, rt_response_params->bid_response_params.dsp_buyer_id ) ;

	for (i = 0; i < adcampaign->ad_campaign_list_setings->applicable_dsp_buyers_count && counter < MAX_DEAL_OBJECTS; i++)
	{
		if (prev_parent_deal_params != NULL &&
			prev_parent_deal_params == applicable_dsp_buyers[i]->parent_deal_params)
		{
			//Already compared, hence ignore.
			continue;
		}

		LOG_INFO (DEAL_DBG_2, DEAL_MODULE,  applicable_dsp_buyers[i]->parent_deal_params->pub_deal_id, applicable_dsp_buyers[i]->dsp_buyer_id,
					applicable_dsp_buyers[i]->deal_pub.deal_ecpm_usd ); 

		retval = strncmp(applicable_dsp_buyers[i]->parent_deal_params->pub_deal_id,
						rt_response_params->bid_response_params.pub_deal_id,
						MAX_DEAL_ID_LEN);
			
		if (retval == 0)
		{
			//applicable_dsp_buyers are ordered by publisher deal
			//found matching deal id, if dsp_interested_deal ==  NULL, then we found matching deal for first time 
			//found matching deal id, if dsp_interested_deal != NULL, then look for match deal with maximum ecpm in the list.
		    /*******************************************************************************************************
 			//commenting this part as want to compare deal id only and not buyer id
			if (rt_response_params->buyer_id_passing_enable_flag == 1 && dsp_buyer_id != DEFAULT_DSP_BUYER_ID){

					if (applicable_dsp_buyers[i]->dsp_buyer_id == dsp_buyer_id){
							//we found the exact match
							adcampaign->dsp_interested_deal = applicable_dsp_buyers[i];
							break;
					}
			}else 
		   ***********************************************************************************************************/	
			if (adcampaign->ad_campaign_list_setings->dsp_interested_deal == NULL || 
				applicable_dsp_buyers[i]->deal_pub.deal_ecpm_usd > adcampaign->ad_campaign_list_setings->dsp_interested_deal->deal_pub.deal_ecpm_usd){
				
				adcampaign->ad_campaign_list_setings->dsp_interested_deal = applicable_dsp_buyers[i];
				//tushar:ASD-1750:add aud segment price in to product ecpm
				if( applicable_dsp_buyers[i]->audience_targeting_applied == 1 ){
					adcampaign->ad_campaign_list_setings->product_ecpm += applicable_dsp_buyers[i]->segment_price;
				}
			}
		}else if (adcampaign->ad_campaign_list_setings->dsp_interested_deal != NULL){
			//stop comparing publisher deal as applicable deal objects are ordered by publisher deal id 
			break;
		}
		
		prev_parent_deal_params = applicable_dsp_buyers[i]->parent_deal_params;

		counter++;
	}
	if (adcampaign->ad_campaign_list_setings->dsp_interested_deal == NULL)
	{
		//Failed to found deal_params_t for given pub_deal_id, So clear pub_deal_id from bid responce this
		//will prevent Rule Engine to apply any rules set against this pub_deal_id.
		rt_response_params->bid_response_params.pub_deal_id[0] = '\0';
		LOG_INFO (DEAL_DBG_3, DEAL_MODULE,  adcampaign->campaign_id);
		return;
	}

	__sync_fetch_and_add(&( (deal_stats_t*)adcampaign->ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->p_stats)->dsp_bids, 1 ) ;
	LOG_INFO (DEAL_DBG_4, DEAL_MODULE,  adcampaign->ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->pub_deal_id, 
				adcampaign->ad_campaign_list_setings->dsp_interested_deal->dsp_buyer_id, adcampaign->ad_campaign_list_setings->dsp_interested_deal->deal_pub.deal_ecpm_usd); 
}

static void register_deal_object( size_t dealoffset, db_deal_row_t *p_db_deal_row )
{
				deal_params_t *p_deal_params = NULL ;

				if( dealoffset >= MAX_MATRIX_COLUMNS )
				{
								llog_write(L_DEBUG, "ERROR: Offset: %lu, Deal id %u. Cannot take deal since the deal count has exceeded limits\n", dealoffset, p_db_deal_row->id ) ;
								return ;
				}

				//printf( "Offset: %lu, Deal id %lu\n", dealoffset, dealid ) ;

				p_deal_params = (deal_params_t*)malloc( sizeof(deal_params_t) ) ;

				p_deal_params->id = p_db_deal_row->id ;
				p_deal_params->deal_meta_id = p_db_deal_row->deal_meta_id ;				
				p_deal_params->pubmatic_deal_id = p_db_deal_row->deal_id ;
				strcpy( p_deal_params->pub_deal_id, p_db_deal_row->pub_deal_id ) ; 
				p_deal_params->deal_second_price_margin = p_db_deal_row->deal_second_price_margin;
				p_deal_params->dsp_buyer_count = 0 ;
				p_deal_params->dsp_buyer_list = NULL ;
				p_deal_params->deal_type = p_db_deal_row->deal_type ;
				p_deal_params->deal_level_feature_flag = p_db_deal_row->feature_flag ;
				p_deal_params->deal_channel_type_id = p_db_deal_row->deal_channel_type_id ;
				p_deal_params->publisher_owned = p_db_deal_row->publisher_owned ;
				p_deal_params->nonft_filter_h = p_db_deal_row->nonft_filter_h ;
				p_deal_params->p_stats = (deal_stats_t*)malloc( sizeof(deal_stats_t) ) ;
				p_deal_params->is_audience_targeted = p_db_deal_row->is_audience_targeted;
				memset( p_deal_params->p_stats, 0, sizeof(deal_stats_t) ) ; 

				new_deal_list[dealoffset] = p_deal_params ;
				new_deal_count++ ;
}

static int get_row_id( const char *row_key, int value ) 
{
				int row_id = -1 ;
				char buf[ROW_KEY_MAX_SIZE] ; 
				
				snprintf( buf, sizeof(buf), "%s_%d", row_key, value) ; 
				row_id = deal_evaluator_get_row_id_for_key( deal_evaluator_hdl, buf ) ;

				DEAL_TRACE( "Matrix key: %s, Row id: %d", buf, row_id ) ;

				return row_id ;
}

static int get_row_id_str( const char *row_key, const char *value ) 
{
				int row_id = -1 ;
				char buf[ROW_KEY_MAX_SIZE] ; 
				
				snprintf( buf, sizeof(buf), "%s_%s", row_key, value) ; 
				row_id = deal_evaluator_get_row_id_for_key( deal_evaluator_hdl, buf ) ;

				DEAL_TRACE( "Matrix key: %s, Row id: %d", buf, row_id ) ;

				return row_id ;
}

static char *num_to_day_map[] = { "sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday" } ;

static const char *dayofweek( int year, int month, int day )  
{ 
				static int t[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };  
				year -= month < 3;  
				int weekday = ( year + year/4 - year/100 + year/400 + t[month-1] + day) % 7;  

				return num_to_day_map[weekday] ;
} 

static void extract_deal_specific_params( struct fte_params *fte_additional_parameters,
								struct publisher_site_ad *in_ad,
								struct rt_response_params *rt_response_param,
								bool is_ortb_msize_format_enabled,
								int *row_ids,
								deal_evaluator_nonft_impr_params_t *p_nonft_params )
{
				unsigned int i = 0 ;
				int mobile_udid_type = 0;
				int fold_position_id = 0;
				ad_server_req_param_t *req_params = fte_additional_parameters->in_server_req_params;
				char *cli_date = NULL;
				int impr_year=0, impr_month=0, impr_date=0, impr_hr=0, impr_min=0, impr_sec=0;
				int user_cookie_value = USER_COOKIE_ABSENT ;
				uint8_t timestamp_decoded = 0 ;

				row_ids[pub_id_index] = get_row_id( "pub_id", req_params->publisher_id ) ;

				row_ids[site_id_index] = get_row_id( "site_id", req_params->site_id ) ;
	
				row_ids[country_ids_index] = get_row_id( "country_ids", fte_additional_parameters->gd.country_id ) ;
				row_ids[region_ids_index] = get_row_id( "region_ids", fte_additional_parameters->gd.region_id ) ;
				row_ids[city_ids_index] = get_row_id( "city_ids", fte_additional_parameters->gd.city_id ) ;
				row_ids[dma_ids_index] = get_row_id( "dma_ids", fte_additional_parameters->gd.dma_id ) ;

				row_ids[os_type_id_index] = get_row_id( "os_type_id", req_params->os_type_id );
				row_ids[os_id_index] = get_row_id( "os_id", req_params->os_id );
				row_ids[ad_id_index] = get_row_id( "ad_id", req_params->ad_id );
				row_ids[make_model_id_index] = get_row_id( "make_model_id", req_params->make_model_id );
				row_ids[carrier_id_index] = get_row_id( "carrier_id", req_params->carrier_id );
				row_ids[browser_id_index] = get_row_id( "browser_id", req_params->browser_id );
				row_ids[mobile_device_type_id_index] = get_row_id( "mobile_device_type_id", req_params->device_type_id ) ;
				row_ids[mobile_request_type_id_index] = get_row_id( "mobile_request_type_id", req_params->mobile_request_type );//mobile request type id

				mobile_udid_type =  atoi(req_params->udid_type); //get a row using mobile_udid_type

				row_ids[mobile_udid_type_validation_index] = get_row_id( "mobile_udid_type_validation", mobile_udid_type ) ;


				if( req_params->mobile_device_location[0] != '\0'  ||
												( IS_VALID_LATITUDE(fte_additional_parameters->gd.latitude) && IS_VALID_LONGITUDE(fte_additional_parameters->gd.longitude ) ) )
				{
								row_ids[mobile_latlong_validation_index] = get_row_id( "mobile_latlong_validation", 1 ) ;
				}
				else
				{
								row_ids[mobile_latlong_validation_index] = get_row_id( "mobile_latlong_validation", 0 ) ;
				}

				if (req_params->s_fold_position_id){
								fold_position_id = req_params->s_fold_position_id;
				}else if (fte_additional_parameters->u_fold_position_id){
								fold_position_id = fte_additional_parameters->u_fold_position_id;
				}

				row_ids[fold_position_id_index] = get_row_id( "fold_position_id", fold_position_id ) ;

				row_ids[video_ad_pos_index] = get_row_id( "video_ad_pos", req_params->video_params.position ) ; //video ad position
				row_ids[video_ad_type_index] = get_row_id( "video_ad_type", req_params->video_params.type ) ; //video ad type
				row_ids[video_skippable_index] = get_row_id( "video_skippable", req_params->video_params.skip ) ; //video skippable

				if( req_params->video_params.placement < 1 ||
												req_params->video_params.placement > 5 )
				{
								row_ids[video_placement_index] = get_row_id( "video_placement", 1 ) ; ///same as instream placement
				}
				else
				{
								row_ids[video_placement_index] = get_row_id( "video_placement", req_params->video_params.placement ) ; //video placement instream/outstream
				}
				
				if( req_params->video_params.vid_api == API_VPAID_1_0 || req_params->video_params.vid_api == API_VPAID_2_0 )
				{
							row_ids[video_vpaid_index] = get_row_id( "video_vpaid", 1 ) ;
				}
				else
				{
							row_ids[video_vpaid_index] = get_row_id( "video_vpaid", 0 ) ;
				}

				user_cookie_value = (rt_response_param->dsp_user_match_found) ? (USER_COOKIE_PRESENT) : (USER_COOKIE_ABSENT) ;
				row_ids[matched_user_index] = get_row_id( "matched_user", user_cookie_value ) ;//get row for matched user rule	

				row_ids[platform_id_index] = get_row_id( "platform_id", req_params->dynamic_platform_id ) ; //platform  id

				row_ids[source_index] = get_row_id( "source", req_params->is_phoenix_request ) ;

				if( req_params->time_stamp != NULL && req_params->time_stamp[0] != '\0' ) 
				{
								decode_click_url(&cli_date, req_params->time_stamp);

								if( cli_date == NULL )
								{
													llog_write(L_DEBUG, "ERROR: Timestamp decoding failure in the impression. Decoded timestamp is NULL."
													" Deals that need time and day parting will NOT work for this impression. "
																				"Timestamp in the impression is \"%s\"\n", req_params->time_stamp ) ;
								}
								else if( cli_date[0] == '\0' )
								{
													llog_write(L_DEBUG, "ERROR: Timestamp decoding failure in the impression. "
													" Deals that need time and day parting will NOT work for this impression. "
																				"Timestamp in the impression is \"%s\"\n", req_params->time_stamp ) ;
													free( cli_date ) ;
								}
								else
								{
												sscanf(cli_date,"%d-%d-%d %d:%d:%d", &impr_year, &impr_month, &impr_date, &impr_hr, &impr_min, &impr_sec);
												free( cli_date ) ;							

												if( impr_month > 12 || impr_month < 1 || impr_date < 1 || impr_date > 31 || impr_year < 0 || impr_year > 3000 ) 
												{
																llog_write(L_DEBUG, "ERROR: Invalid timestamp in the impression. Deals that need time and day parting will NOT work for this impression. "
																								"Timestamp in the impression is \"%s\"\n", req_params->time_stamp ) ;
												}
												else
												{
																timestamp_decoded = 1 ;

												}
								}
				}

				if( timestamp_decoded )
				{
								row_ids[time_parting_index] = get_row_id( "time_parting", impr_hr ) ;
								row_ids[days_of_week_index] = get_row_id_str( "days_of_week", dayofweek(impr_year, impr_month, impr_date) ) ;
				}
				else
				{
								row_ids[time_parting_index] = -1 ;
								row_ids[days_of_week_index] = -1 ;
				}

				row_ids[viewability_index] = get_row_id( "viewability", fte_additional_parameters->viewability ) ;

				memcpy( p_nonft_params->playback, req_params->video_params.playback,
												sizeof(req_params->video_params.playback) ) ;

				p_nonft_params->ad_size_id = in_ad->ad_size_id ;
				if (is_ortb_msize_format_enabled 
						&& in_ad->multi_adsize_count > AD_DIMENSIONS_COUNT_MUX){ 
					p_nonft_params->multi_adsize_count = AD_DIMENSIONS_COUNT_MUX ;
				}else {
					p_nonft_params->multi_adsize_count = in_ad->multi_adsize_count ;
				}
				for( i = 0 ; i < p_nonft_params->multi_adsize_count ; i++ )
				{
					p_nonft_params->ad_sizes[i] = in_ad->ad_dimensions_from_tag[i].ad_size_id ;
				}

				p_nonft_params->video_skip_offset = req_params->video_params.skip_delay ;	

				p_nonft_params->video_noskip_adlen = req_params->video_params.noskip_ad_len ;

				p_nonft_params->video_player_size = req_params->video_params.player_size ;

				p_nonft_params->ad_type_id = req_params->ad_type ;

				p_nonft_params->blocked_richmedia_creative_attr_map = req_params->blocked_richmedia_creative_attr_map ;

				memcpy( p_nonft_params->rich_media_technologies,
												req_params->rich_media_technologies,
												sizeof(p_nonft_params->rich_media_technologies) ) ;

				memcpy( p_nonft_params->ad_expansion_direction,
												req_params->ad_expansion_direction,
												sizeof(p_nonft_params->ad_expansion_direction) ) ;
				
				p_nonft_params->user_segments = fte_additional_parameters->audience_params.user_segment_list_info ;
}

static void initializ_deal_pub( deal_pub_fields_t *p_deal_pub_fields )
{
				p_deal_pub_fields->deal_ecpm_usd = 0 ;;
				p_deal_pub_fields->priority = 0 ;
				p_deal_pub_fields->auction_id = 2 ;
				p_deal_pub_fields->pub_margin = 0 ;
				p_deal_pub_fields->pub_margin_type= 0 ;
				p_deal_pub_fields->currency_id = 0 ;
}

static int insert_applicable_deal(dsp_buyer_t **retlist,
						int use_count,
						dsp_buyer_t *p_dsp_buyer,
						int buyer_id_passing_enable_flag,
						fte_additional_params_t *fte_additional_parameters,
						deal_evaluator_h local_deal_evaluator_hdl,
						int pub_id
						)
{

				int index = 0;
				int ret_list_action = -1;
				/*  
				 * -1 => Apend to list. New deal
				 * 0 => Do nothing. Ignore this dsp-buyer
				 * 1=> Replace an existing dsp-buyer
				 */
				deal_pub_fields_t deal_pub_new_deal ;
				deal_pub_fields_t deal_pub_list_deal ;

				initializ_deal_pub( &deal_pub_new_deal ) ;

				uint8_t fetch_status = 0 ;
			
				fetch_status = deal_evaluator_pub_deal_fetch( local_deal_evaluator_hdl, pub_id,
												p_dsp_buyer->parent_deal_params->deal_meta_id, &deal_pub_new_deal ) ;

				if( fetch_status ) {
								llog_write(L_ERROR, "Deal currency conversion post evaluation on new deal: Deal pub deal id: %s"
																", ERROR: Could not fetch pub-deal level config\n", 
																p_dsp_buyer->parent_deal_params->pub_deal_id );
								LOG_FATAL( INVALID_DB_ENTRY, MOD_DEFAULT, "AdFlex.deal.currency_id");
								return use_count ;
				}

				 deal_pub_new_deal.deal_ecpm_usd = CONVERT_NATIVE_CURRENCY_TO_USD( deal_pub_new_deal.deal_ecpm_native,
																deal_pub_new_deal.currency_id,
																fte_additional_parameters->currency_xrate_map,
																fte_additional_parameters->currency_count ) ;

				/* Disqualify deal having inactive native currency */
				if(deal_pub_new_deal.deal_ecpm_usd == 0 && deal_pub_new_deal.deal_ecpm_native != 0) {
								llog_write(L_ERROR, "Deal currency conversion post evaluation on new deal: Deal pub deal id: %s, Native currency id: %d. ERROR: Invalid currency id\n", 
																p_dsp_buyer->parent_deal_params->pub_deal_id, deal_pub_new_deal.currency_id);
								LOG_FATAL( INVALID_DB_ENTRY, MOD_DEFAULT, "AdFlex.deal.currency_id");
								return use_count ;
				}

				for( index = use_count - 1 ; index >= 0 ; index-- )
				{
								if( strncmp(retlist[index]->parent_deal_params->pub_deal_id,
																				p_dsp_buyer->parent_deal_params->pub_deal_id,MAX_DEAL_ID_LEN) )
								{
												continue ;
								}

								fetch_status = deal_evaluator_pub_deal_fetch( local_deal_evaluator_hdl, pub_id,
																retlist[index]->parent_deal_params->deal_meta_id, 
																&deal_pub_list_deal ) ;
								if( fetch_status ) {
												llog_write(L_ERROR, "Deal currency conversion post evaluation on list deal: Deal pub deal id: %s"
																				", ERROR: Could not fetch pub-deal level config\n", 
																				retlist[index]->parent_deal_params->pub_deal_id ) ;
																				LOG_FATAL( INVALID_DB_ENTRY, MOD_DEFAULT, "AdFlex.deal.currency_id");
												continue ;
								}

								deal_pub_list_deal.deal_ecpm_usd = CONVERT_NATIVE_CURRENCY_TO_USD( deal_pub_list_deal.deal_ecpm_native,
																deal_pub_list_deal.currency_id,
																fte_additional_parameters->currency_xrate_map,
																fte_additional_parameters->currency_count ) ;

								if(deal_pub_list_deal.deal_ecpm_usd == 0 && deal_pub_list_deal.deal_ecpm_native != 0) {
												llog_write(L_ERROR, "Deal currency conversion post evaluation on list deal: Deal pub deal id: %s, Native currency id: %d. ERROR: Invalid currency id\n", 
																				retlist[index]->parent_deal_params->pub_deal_id, deal_pub_list_deal.currency_id);
												LOG_FATAL( INVALID_DB_ENTRY, MOD_DEFAULT, "AdFlex.deal.currency_id");
												continue ;
								}

								if (buyer_id_passing_enable_flag == 1 )
								{
												if (retlist[index]->dsp_buyer_id == p_dsp_buyer->dsp_buyer_id)
												{
																if (deal_pub_list_deal.deal_ecpm_usd < deal_pub_new_deal.deal_ecpm_usd )
																{
																				ret_list_action = 1;
																}else
																{
																				ret_list_action = 0;
																}
																break;
												}
								}else
								{

												if (deal_pub_list_deal.deal_ecpm_usd < deal_pub_new_deal.deal_ecpm_usd )
												{
																ret_list_action = 1;
												}else
												{
																ret_list_action = 0;
												}
												break;
								}
				}

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				fprintf( stderr, "Deal currency conversion post evaluation: Deal pub deal id: %s, Native currency id: %d, Native currency value: %f, USD currency value: %f\n",
												p_dsp_buyer->parent_deal_params->pub_deal_id, deal_pub_new_deal.currency_id,
												deal_pub_new_deal.deal_ecpm_native, deal_pub_new_deal.deal_ecpm_usd ) ;
#endif

				if (ret_list_action == 1)
				{
								memcpy( retlist[index], p_dsp_buyer, sizeof(*p_dsp_buyer) ) ;
								retlist[index]->in_rtb_request = NOT_ADDED_IN_RTB_REQUEST; 
								memcpy( &retlist[index]->deal_pub, &deal_pub_new_deal, sizeof(deal_pub_fields_t) ) ;
				}else if (ret_list_action == -1)
				{
								dsp_buyer_t *p_dsp_buyer_clone = (dsp_buyer_t*)malloc( sizeof(dsp_buyer_t) ) ;
								if( p_dsp_buyer_clone != NULL )
								{
												memcpy( p_dsp_buyer_clone, p_dsp_buyer, sizeof(*p_dsp_buyer) ) ;
												retlist[use_count] = p_dsp_buyer_clone;
												retlist[use_count]->in_rtb_request = NOT_ADDED_IN_RTB_REQUEST;
												memcpy( &retlist[use_count]->deal_pub, &deal_pub_new_deal, sizeof(deal_pub_fields_t) ) ;
												use_count = use_count + 1;
								}
				}

				return use_count ;
}


static int cmp_dsp_buyer(const void *p1, const void *p2)
{
				const dsp_buyer_t *element1 = *(dsp_buyer_t**)p1 ;
				const dsp_buyer_t *element2 = *(dsp_buyer_t**)p2 ;

				if( element1->deal_pub.priority < element2->deal_pub.priority )
				{
								return -1 ;
				}

				if( element1->deal_pub.priority > element2->deal_pub.priority )
				{
								return 1 ;
				}
				
				if( element1->deal_pub.deal_ecpm_usd < element2->deal_pub.deal_ecpm_usd )
				{
								return 1 ;
				}

				if( element1->deal_pub.deal_ecpm_usd > element2->deal_pub.deal_ecpm_usd )
				{
								return -1 ;
				}

				return 0 ;
}

static void create_deal_buyers(void)
{				
						size_t iDeal = 0, iDSPBuyer = 0 ;
						dsp_buyer_t *p_dsp_buyer_attr = NULL ;
						size_t dsp_buyer_count = 0 ;
						dsp_buyer_t **dsp_buyer_list = NULL ;

						for( iDeal = 0 ; iDeal < new_deal_count ; iDeal++ )
						{
										if( new_deal_list[iDeal] == NULL )
										{
														continue ;
										}

										const dsp_buyer_mapping_t *p_dsp_buyer = deal_evaluator_get_dsp_buyers( new_deal_list[iDeal]->nonft_filter_h, &dsp_buyer_count ) ;
										dsp_buyer_list = (dsp_buyer_t**)malloc( dsp_buyer_count*sizeof(dsp_buyer_t*) ) ;

										for( iDSPBuyer = 0 ; iDSPBuyer < dsp_buyer_count ; iDSPBuyer++ )
										{
														p_dsp_buyer_attr = (dsp_buyer_t*)malloc( sizeof(dsp_buyer_t) ) ;
														memset( p_dsp_buyer_attr, 0, sizeof(dsp_buyer_t) ) ;

														p_dsp_buyer_attr->in_rtb_request = NOT_ADDED_IN_RTB_REQUEST ;
														p_dsp_buyer_attr->pubmatic_buyer_id = p_dsp_buyer->buyer_id  ;
														p_dsp_buyer_attr->dsp_buyer_id = p_dsp_buyer->dsp_buyer_id ;
														p_dsp_buyer_attr->dsp_id = p_dsp_buyer->dsp_id ;
														p_dsp_buyer_attr->parent_deal_params = new_deal_list[iDeal] ;

														p_dsp_buyer = p_dsp_buyer->next ;
														dsp_buyer_list[iDSPBuyer] = p_dsp_buyer_attr ;
										}

										new_deal_list[iDeal]->dsp_buyer_count = (int)dsp_buyer_count ;
										new_deal_list[iDeal]->dsp_buyer_list = dsp_buyer_list ;
						}
}

static uint8_t eval_user_segments( const char *expression, void *user_segments )
{
				int segment_expr_evaluation_result = 0 ;	
				evaluate_audience_user_segments( expression, user_segments, 
												&segment_expr_evaluation_result, NULL ) ; 

				return (uint8_t)segment_expr_evaluation_result ;
}

static uint8_t eval_custom_targeting( deal_params_t *deal,
								struct fte_params *fte_additional_parameters )
{
				if( !IS_FEATURE_ENABLED( deal->deal_level_feature_flag, CUSTOM_TARGETING_ENABLED ) )
				{
								return 1 ;
				}

				return deal_evaluator_custom_targeting_check( deal->nonft_filter_h, fte_additional_parameters->in_server_req_params->dkeyval ) ;	
}

static uint8_t evaluate_publisher_requested_deal(deal_params_t *deal, 
								publisher_requested_pmp_t *pub_pmp_obj )
{
				uint8_t eval_success = 1 ;

				if ((1 == deal->publisher_owned) &&
												IS_FEATURE_ENABLED( deal->deal_level_feature_flag, EVALUATE_PUBLISHER_REQUESTED_DEALS))
				{
								if( NULL == pub_pmp_obj || pub_pmp_obj->ndeals <= 0 )
								{ 
												eval_success = 0; 
								}    
								else if( NULL == (bsearch(&deal->pub_deal_id,
																								pub_pmp_obj->deals,
																								pub_pmp_obj->ndeals,
																								sizeof(publisher_request_deal_t *),
																								pmp_deal_id_compare)) 
											 )
								{
												eval_success = 0; 
								}    
				}    

				return eval_success;
}

static void print_deal_stats( deal_params_t **print_deal_list, size_t print_deal_count, deal_evaluator_h print_deal_evaluator_hdl )
{
	FILE *fp = NULL ;
	size_t iDeal = 0 ;
	deal_stats_t *p_stats = NULL ;
	char filename[256] ;
	time_t now = time(NULL) ;
	struct tm detailedtime ;
	memset( &detailedtime, 0, sizeof(detailedtime) ) ;

	localtime_r( &now, &detailedtime) ;
	snprintf( filename, sizeof(filename), "/tmp/deal_stats_%04d%02d%02d%02d%02d%02d.dump",
			detailedtime.tm_year+1900, detailedtime.tm_mon+1,
			detailedtime.tm_mday, detailedtime.tm_hour,
			detailedtime.tm_min, detailedtime.tm_sec  ) ;

	fp = fopen( filename, "w+" ) ;

	if( fp == NULL )
	{
		llog_write(L_DEBUG, "ERROR: Failed to dump deal stats\n" ) ;
		return ;
	}

	fprintf( fp, "\n\nTable Keys:\nA=>%s\nB=>%s\nC=>%s\nD=>%s\nE=>%s\nF=>%s\nG=>%s"
			"\nH=>%s\nI=>%s\nJ=>%s\nK=>%s\nL=>%s\nM=>%s\nN=>%s\nO=>%s\nP=>%s\nQ=>%s\nR=>%s\nS=>%s\n",
			"Deal meta id", "Fast targeting hits", "DSP id misses",
			"Pub req misses", "Ad size misses", "Rich media misses", "Video playback misses",
			"Video skip offset misses", "Video noskip adlen misses", "Video player size misses",
			"Ad type id misses", "Section misses", 
			"Audience misses", "Custom targeting misses",
			"Deal match count", "Sent to DSP", "DSP bids",
			"Audience postfix evaluation time in nanosec", "Post evaluation time in nanosec") ;

	fprintf( fp, "\nNote: All zeroes for a deal implies it never cleared fast targeting\n\n" ) ;

	fprintf( fp, "%10s|%10s|%10s|%10s|%10s|%10s"
			"|%10s|%10s|%10s|%10s|%10s|%10s|%10s"
			"|%10s|%10s|%10s|%10s|%10s|%10s\n",
			"A", "B", "C", "D", "E", "F", "G",
			"H", "I", "J", "K", "L", "M",	"N",
			"O", "P", "Q", "R", "S" ) ;

	for( iDeal = 0 ; iDeal < print_deal_count ; iDeal++ )
	{
		if( print_deal_list[iDeal] == NULL )
		{
			continue ;
		}

		p_stats = (deal_stats_t*)print_deal_list[iDeal]->p_stats ;
		fprintf( fp, "%10d|%10u|%10u|%10u|%10u|%10u"
				"|%10u|%10u|%10u|%10u|%10u|%10u|%10u"
				"|%10u|%10u|%10u|%10u|%10lu|%10lu\n",
				print_deal_list[iDeal]->deal_meta_id,
				p_stats->ft_hits,
				p_stats->dsp_id_misses,
				p_stats->pub_req_misses,
				p_stats->ad_size_misses,
				p_stats->richmedia_misses,
				p_stats->videoplayback_misses,
				p_stats->videoskipoffset_misses,
				p_stats->videonoskipadlen_misses,
				p_stats->videoplaysersize_misses,
				p_stats->ad_type_id_misses,
				p_stats->section_misses,
				p_stats->audience_misses,
				p_stats->custom_targeting_misses,
				p_stats->deal_matched,
				p_stats->sent_to_dsp,
				p_stats->dsp_bids,
				AVERAGE_OF( p_stats->audience_sum_nanosec, p_stats->audience_count ),
				AVERAGE_OF( p_stats->post_evaluation_sum_nanosec, p_stats->post_evaluation_count ) ) ;
	}
	if (print_deal_evaluator_hdl != NULL)	
	{
					deal_evaluator_print_audience_stats(print_deal_evaluator_hdl, fp);
	}

	fclose( fp ) ;
}


static void reload_deal_evaluator(void)
{
				db_connection_t adf_dbconn ;
				int retval = get_fte_db_connection(&adf_dbconn) ;
				size_t iDeal = 0, iDSPBuyer = 0 ;
				time_t start_sec = 0 ;
				
				deal_params_t **old_deal_list = deal_list ;
				deal_evaluator_h old_deal_evaluator_hdl = deal_evaluator_hdl ;
				size_t old_deal_count = deal_count ;

				if( retval != ADS_ERROR_SUCCESS )
				{
								LOG_FATAL( DB_CALL_FAIL, MOD_DEFAULT, "Reloading deals failed since DB connection failed");
								return ;
				}

				start_sec = time(NULL) ;

				new_deal_list = (deal_params_t**)malloc( sizeof(deal_params_t*)*MAX_MATRIX_COLUMNS ) ;
				memset( new_deal_list, 0, sizeof(deal_params_t*)*MAX_MATRIX_COLUMNS ) ;

				deal_evaluator_h new_deal_evaluator_hdl = deal_evaluator_create( &adf_dbconn, register_deal_object, eval_user_segments);

				release_db_connection(&adf_dbconn);

				if( new_deal_evaluator_hdl == NULL )
				{
								LOG_FATAL( DEAL_LOAD_FAILURE, MOD_DEFAULT, "Reloading deals failed since DB connection failed");
								return ;
				}

				create_deal_buyers() ;

				pthread_rwlock_wrlock( &deal_list_lock ) ;

				memset( row_ids_exclude, 0xff, sizeof(row_ids_exclude) ) ;

				row_ids_exclude[pub_id_index]                      = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "pub_id") ;
				row_ids_exclude[site_id_index]                     = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "site_id" ) ;
				row_ids_exclude[country_ids_index]                 = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "country_ids" ) ;
				row_ids_exclude[region_ids_index]                  = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "region_ids") ;
				row_ids_exclude[city_ids_index]                    = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "city_ids" ) ;
				row_ids_exclude[dma_ids_index]                     = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "dma_ids" ) ;
				row_ids_exclude[os_type_id_index]                  = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "os_type_id" );
				row_ids_exclude[os_id_index]                       = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "os_id" );
				row_ids_exclude[ad_id_index]                       = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "ad_id" );
				row_ids_exclude[make_model_id_index]               = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "make_model_id" );
				row_ids_exclude[carrier_id_index]                  = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "carrier_id" );
				row_ids_exclude[browser_id_index]                  = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "browser_id" );
				row_ids_exclude[mobile_device_type_id_index]       = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "mobile_device_type_id" ) ;
				row_ids_exclude[mobile_request_type_id_index]      = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "mobile_request_type_id" ) ;
				row_ids_exclude[mobile_udid_type_validation_index] = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "mobile_udid_type_validation" ) ;
				row_ids_exclude[mobile_latlong_validation_index]   = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "mobile_latlong_validation" ) ;
				row_ids_exclude[fold_position_id_index]            = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "fold_position_id" ) ;
				row_ids_exclude[video_ad_pos_index]                = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "video_ad_pos" ) ; 
				row_ids_exclude[video_ad_type_index]               = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "video_ad_type" ) ;
				row_ids_exclude[video_skippable_index]             = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "video_skippable" ) ;
				row_ids_exclude[video_placement_index]             = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "video_placement" ) ;
				row_ids_exclude[video_vpaid_index]                 = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "video_vpaid" ) ;
				row_ids_exclude[matched_user_index]                = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "matched_user" ) ;
				row_ids_exclude[platform_id_index]                 = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "platform_id" ) ;
				row_ids_exclude[source_index]                      = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "source" ) ;
				row_ids_exclude[time_parting_index]                = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "time_parting" ) ;
				row_ids_exclude[days_of_week_index]                = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "days_of_week" ) ;
				row_ids_exclude[viewability_index]                 = deal_evaluator_get_exclusion_row_id_for_attribute( new_deal_evaluator_hdl, "viewability" ) ;
#ifdef DEBUG_FAST_TARGET

				FILE *fp = fopen( "/tmp/dealmatrix.dump", "w+" ) ;

				fprintf( fp, "%15s:%15s\n", "Deal id", "Column number" ) ;

				fprintf( fp, "\n-----------------------------------------------------------------------------------------------\n" ) ;

				for( iDeal = 0 ; iDeal < new_deal_count ; iDeal++ )
				{
								if( new_deal_list[iDeal] == NULL )
								{
												continue ;
								}

								fprintf( fp, "%15d:%15lu\n", new_deal_list[iDeal]->id, iDeal ) ;
				}

				llog_write(L_INFO, "\nDumping deal fast targeting matrix. Please wait...\n" ) ;
				deal_evaluator_dump( new_deal_evaluator_hdl, fp ) ;
				llog_write(L_INFO, "Dumping deal fast targeting matrix finished.\n" ) ;
				fclose( fp ) ;
				fp = fopen( "/tmp/audience_deals.json", "w+" ) ;
				deal_evaluator_print_audience_stats(new_deal_evaluator_hdl, fp);
				fclose(fp);
#endif				

				deal_evaluator_hdl = new_deal_evaluator_hdl ;
				deal_list = new_deal_list ;
				deal_count = new_deal_count ;

				pthread_rwlock_unlock( &deal_list_lock ) ;
				
				llog_write(L_DEBUG, "Deal evaluator reloaded in %ld seconds\n", time(NULL)-start_sec ) ;
				
				new_deal_evaluator_hdl = NULL ;
				new_deal_list = NULL ;
				new_deal_count = 0 ;

				if( old_deal_list == NULL )
				{
								print_deal_stats( deal_list, deal_count, NULL ) ;
								return ;
				}
				
				print_deal_stats( old_deal_list, old_deal_count, old_deal_evaluator_hdl ) ;

				/*wait for GRACE_TIME_FOR_REFERENCES_GONE seconds so that
				 * any references to deal objects from data path threads will be gone
				 */
				sleep( GRACE_TIME_FOR_REFERENCES_GONE ) ;

				for( iDeal = 0 ; iDeal < old_deal_count ; iDeal++ )
				{
								if( old_deal_list[iDeal] == NULL )
								{
												continue ;
								}

								deal_evaluator_nonft_filter_destroy( old_deal_list[iDeal]->nonft_filter_h ) ;

								for( iDSPBuyer = 0 ; iDSPBuyer < old_deal_list[iDeal]->dsp_buyer_count ; iDSPBuyer++ )
								{
												free( old_deal_list[iDeal]->dsp_buyer_list[iDSPBuyer ] ) ;
								}
				
								free( old_deal_list[iDeal]->p_stats ) ;
								free( old_deal_list[iDeal]->dsp_buyer_list ) ;
								free( old_deal_list[iDeal] ) ;
				}

				free( old_deal_list ) ;
				old_deal_list = NULL ;
				
				deal_evaluator_destroy( old_deal_evaluator_hdl ) ;
}

static void *reinitialize_thread( void *arg )
{
				const time_t refresh_interval_sec = 3600 ; //one hour

				if( arg != NULL ) //insignificant. just to avoid warnings
				{
								abort() ;
				}

				while(1)
				{
								sleep( refresh_interval_sec ) ;
								reload_deal_evaluator() ;
				}

				return NULL ;
}

void load_deal_evaluator(void)
{	
				pthread_t thread ;

				pthread_rwlockattr_t attr ;
				pthread_rwlockattr_init( &attr ) ;
				pthread_rwlockattr_setkind_np( &attr, PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP ) ;

				pthread_rwlock_init( &deal_list_lock , &attr ) ;
				pthread_rwlockattr_destroy( &attr ) ;

				reload_deal_evaluator() ;			
				
				llog_write(L_DEBUG, "Deal evaluator loaded\n" ) ;
				
				pthread_create( &thread, NULL, reinitialize_thread, NULL ) ;
}

uint8_t is_audience_deal_present( int pub_id, int site_id )
{
				deal_evaluator_h local_deal_evaluator_hdl = NULL ;

				pthread_rwlock_rdlock( &deal_list_lock ) ;
				local_deal_evaluator_hdl = deal_evaluator_hdl ; 
				pthread_rwlock_unlock( &deal_list_lock ) ;

				return deal_evaluator_audience_check( local_deal_evaluator_hdl, pub_id, site_id ) ;
}

#ifdef AEROSPIKE_SIMULATE
void populate_dummy_user_segments(void  **audience_data_list)
{
				const char *segments[]={"8106368", "WebormaDpid","Sample_1_10000","Sample_1_10001","Sample_1_10002", "Sample_1_10004", "Sample_1_10000", "Sample_1_10001", "abcd", "pqrs", "8106370"};
				int j =0;
				int ret_val=0;
				char *provider_id_string =NULL;
				dp_profiles_t *profiles = NULL;
				int seg_count=4;
				int profile_count = sizeof(segments)/sizeof(segments[0]); 
				//int profile_counter = 0, seg_count = 0;

				//Create and populate SLIST with these segments as  there is no data from aerospike
				(*audience_data_list) = NULL;
				(*audience_data_list) = (SLIST *)malloc( sizeof(SLIST) );
				if (NULL == *audience_data_list) {
								fprintf(stderr, "malloc failed %s:%d\n", __FILE__, __LINE__);
								return ;
				}

				ret_val = slist_create(           /* SLIST with elements as individual data provider profiles */
												(*audience_data_list),
												profile_count,
												&audience_prof_free,
												&audience_prof_print,
												&audience_prof_compr,
												&audience_prof_search );
				if( ADS_ERROR_SUCCESS != ret_val ) {
								free(*audience_data_list );
								(*audience_data_list) = NULL;
								fprintf(stderr, "Static List creation failed for Audience profiles. %s:%d\n", __FILE__, __LINE__);
								return;
				}

				/* allocate memory for the variable. */
				profiles = NULL;
				profiles = (dp_profiles_t*)malloc(sizeof(dp_profiles_t));
				if( NULL == profiles ) {
								fprintf(stderr, "malloc failed %s:%d\n", __FILE__, __LINE__);
								ret_val = ADS_ERROR_NOMEMORY;
								goto free_and_ret;
				}

				/*Adding the data provider profile to the primary SLIST*/
				ret_val = slist_add((*audience_data_list), (void *)profiles );
				if( ADS_ERROR_SUCCESS != ret_val ) {
								free( profiles );
								profiles = NULL;

								fprintf(stderr, "Addition to static list of audiences failed. %s:%d\n", __FILE__, __LINE__);
								ret_val = ADS_ERROR_INTERNAL;
								goto free_and_ret;
				}

				/*Create SLIST to hold provider segment IDs as strings (ProvIDSlist)*/
				if( ADS_ERROR_SUCCESS != (ret_val = slist_create(
																				&(profiles->audiences_string), seg_count, &free_generic_ptr,
																				&print_string, (__compare_function)&compare_slist_string, &search_string)) ) {

								fprintf(stderr, "Static List creation failed for Audience profiles. %s:%d\n", __FILE__, __LINE__);
								ret_val = ADS_ERROR_INTERNAL;
								goto free_and_ret;
				}

				/* Add data provider ID. */
				profiles->dpid = 289;

				for(; j<seg_count; j++ ) {
								provider_id_string = strdup(segments[j]); 
								ret_val = slist_add(&(profiles->audiences_string),provider_id_string);
								if( ADS_ERROR_SUCCESS != ret_val ) {
												free( provider_id_string );
												provider_id_string = NULL;

												fprintf(stderr, "Addition to static list of audiences failed. %s:%d\n", __FILE__, __LINE__);
												ret_val = ADS_ERROR_INTERNAL;
												goto free_and_ret;
								}
				} 
free_and_ret:

				if( ADS_ERROR_SUCCESS != ret_val ) {
								slist_destroy( *audience_data_list );
								free( *audience_data_list );
								(*audience_data_list) = NULL;
				}


}
#endif

void find_audience_matching_deals(int pub_id, char *impr_id,  void **user_segments, result_set_hdl rs_hdl)
{
				SLIST *list=NULL;
				dp_profiles_t** profiles=NULL;
				int i,k;
				char segment[128];
				struct timespec starttime, endtime ;
        uint64_t eval_time_ns =0;
        size_t num_user_segments=0;

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
        char buf[65536];
#endif

				clock_gettime(CLOCK_MONOTONIC, &starttime);
				if ((*user_segments) == NULL)
				{
								llog_write(L_DEBUG, "Audience data from Aerospike is not available "
																"for Impression id: %s, Pub id: %d \n",impr_id, pub_id  ) ;
								return;
				}

				list = (SLIST*)(*user_segments); 
				profiles= (dp_profiles_t**)(list->data);

				for(i=0; i<list->curr; i++)
				{
								dp_profiles_t* profile = profiles[i];
								SLIST* audience_strings= &(profile->audiences_string);
								for( k=0; k<audience_strings->curr; k++)
								{
												snprintf(segment, sizeof(segment),  "%d:%s", profile->dpid,  (char*)audience_strings->data[k] );
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
												llog_write(L_DEBUG, "Impression id: %s, Pub id: %d, Segment string(aerospike): %s\n",
																				impr_id, pub_id, segment ) ;
#endif						
												deal_evaluator_audience_eval_segment(deal_evaluator_hdl, segment, rs_hdl);
												num_user_segments++;
								}

				}
				clock_gettime(CLOCK_MONOTONIC, &endtime);
				eval_time_ns = DIFFTIME_NANOSEC( starttime, endtime ) ;

        // Call JSON Serilaize here to serialize result set 
        DEBUG_LOG("Impression id: %s, Pub id: %d, Eval Time(ns): %lu, Num User Segments: %lu, Result set: %s \n",
				impr_id, pub_id, eval_time_ns, num_user_segments, deal_evaluator_audience_result_set_serialize(rs_hdl, buf, sizeof(buf)) );
				

				// Record this time in stats handle
        deal_evaluator_record_audience_eval_time(deal_evaluator_hdl,
                eval_time_ns);
}

int  deal_evaluator_audience_result_set_init( result_set_hdl *rs_hdl)
{
				return audience_result_set_init(rs_hdl);
}

void deal_evaluator_audience_result_set_destroy( result_set_hdl rs_hdl)
{
		audience_result_set_destroy(rs_hdl);
}

static uint8_t audience_evaluate( deal_evaluator_h deal_eval_hdl,
								deal_evaluator_nonft_filter_h nonft_filter_h,  deal_evaluator_nonft_impr_params_t *p_nonft_params,
								int deal_meta_id,
								uint8_t is_coppa_compliant,
								result_set_hdl rs_hdl,
								int debug_deal_meta,
								char *impression_id,
								int campaign_id,
								char *pub_deal_id,
								double *p_segment_price,
								char **p_segment_exp_out,
								char *printbuf, size_t printbuf_len,
								deal_stats_t *p_stats )
{
				uint8_t audience_targeting_applied = 0 ;
				//Check if this deal matches with user data( is there in result set) 
				deal_evaluator_audience_get_segment_info(rs_hdl,
												deal_meta_id, p_segment_exp_out, p_segment_price);
				if (!(*p_segment_exp_out))
				{
								//Audience eval failed for non-postfix expression check if postfix-expr is configured for this deal and matches 
								deal_evaluator_postfix_evaluate(deal_eval_hdl, nonft_filter_h, p_nonft_params,is_coppa_compliant,&audience_targeting_applied,
																p_segment_price, p_segment_exp_out, printbuf, printbuf_len, p_stats);
								if (audience_targeting_applied ==0)
								{
												DEAL_DEBUG(deal_meta_id, debug_deal_meta, impression_id, campaign_id, DEAL_APPLICATION,
																				"Deal filtered out. Pub deal id: %s. Failed audience evaluation. Reason: %s",
																				pub_deal_id, printbuf ) ;
												return 0;
								}
				}
				return 1;
}


void get_applicable_deals( struct fte_params *fte_additional_parameters,
								struct publisher_site_ad_campaign_list *adcampaigns,
								struct publisher_site_ad *in_ad,
								int buyer_id_passing_enable_flag,
								bool is_ortb_msize_format_enabled,
								struct rt_response_params *rt_response_param,
								int debug_deal_meta,
								char *impression_id,
								int rtb_debug_enabled,
								result_set_hdl rs_hdl)
{								
				size_t resultByteCount = 0 ;
				size_t iDeal = 0, iDSPBuyer = 0 ;
				int use_count = 0 ;
				size_t dsp_buyer_list_size = 1024 ;
				uint8_t audience_targeting_applied = 0 ;
				double segment_price = 0 ;
				char *segment_exp = NULL ;
				char *sites_delimited_list = fte_additional_parameters->in_server_req_params->zone ;
				int row_ids[row_index_max] ;
				publisher_requested_pmp_t *pub_pmp_obj = fte_additional_parameters->in_server_req_params->pub_pmp_obj;
				deal_evaluator_nonft_impr_params_t nonft_params ;
				static __thread unsigned char *resultBitmap = NULL ;
				uint8_t dsp_buyer_found = 0 ;
				size_t local_deal_count = 0 ;
				deal_params_t **local_deal_list = NULL ;
				deal_params_t *p_deal = NULL ;
				deal_evaluator_h local_deal_evaluator_hdl = NULL ; 
				char printbuf[1024] ;
				struct timespec starttime_agg, endtime_agg ;
				struct timespec starttime, endtime ;
				deal_stats_t *p_stats = NULL ;
				uint64_t extraction_time = 0, ft_time = 0, sorting_time_nanosec = 0 ;
				size_t resultBitCount = 0 ; 
				int local_row_ids_exclude[row_index_max] ;
				printbuf[0] = '\0' ;

				if( fte_additional_parameters->in_server_req_params == NULL )
				{
								return ;
				}

				if( resultBitmap == NULL )
				{
								resultBitmap = (unsigned char*)malloc( MAX_MATRIX_COLUMNS/8 ) ; //thread specific. allocated only once
				}

				clock_gettime(CLOCK_MONOTONIC, &starttime_agg);

				memset( &nonft_params, 0, sizeof(nonft_params) ) ;
				memset( row_ids, 0xff, sizeof(row_ids) ) ;

				clock_gettime(CLOCK_MONOTONIC, &starttime );

				adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers = (dsp_buyer_t**)malloc( dsp_buyer_list_size*sizeof(dsp_buyer_t*) ) ;

				if( adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers == NULL )
				{
								llog_write(L_DEBUG, "ERROR. Out of memory while processing deals and creating dsp buyer array\n" ) ;
								return ;
				}

				memset( adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers, 0, dsp_buyer_list_size*sizeof(dsp_buyer_t*) ) ;
				clock_gettime(CLOCK_MONOTONIC, &endtime );

				extraction_time = DIFFTIME_NANOSEC( starttime, endtime ) ;

				pthread_rwlock_rdlock( &deal_list_lock ) ;
				local_deal_count = deal_count ;
				local_deal_list = deal_list ;
				local_deal_evaluator_hdl = deal_evaluator_hdl ; 
				memcpy( local_row_ids_exclude, row_ids_exclude, sizeof(local_row_ids_exclude) ) ;
				extract_deal_specific_params( fte_additional_parameters,
												in_ad, rt_response_param, 
												is_ortb_msize_format_enabled, 
												row_ids, &nonft_params ) ;
				pthread_rwlock_unlock( &deal_list_lock ) ;

				clock_gettime(CLOCK_MONOTONIC, &starttime );
				deal_evaluator_lookup_matching_deals( local_deal_evaluator_hdl, row_ids, local_row_ids_exclude,
												row_index_max, resultBitmap, &resultByteCount ) ;
				clock_gettime(CLOCK_MONOTONIC, &endtime );

				ft_time = DIFFTIME_NANOSEC( starttime, endtime ) ;

				resultBitCount = resultByteCount*8 ;	
				for( iDeal = 0 ; iDeal < resultBitCount && iDeal < local_deal_count ; iDeal++ )
				{
								if( unlikely( local_deal_list[iDeal] == NULL ) )
								{
												continue ;
								}
								if( likely( !IS_SET( resultBitmap, iDeal ) ) )
								{
												DEAL_DEBUG( local_deal_list[iDeal]->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																				"Deal filtered out. Pub deal id: %s"
																				". Reason: Did not clear fast targeting. Impression for deal's publisher: %s, Viewability: %u"
																				", Query string: %s",
																				local_deal_list[iDeal]->pub_deal_id,
																				( deal_evaluator_pub_deal_mapping_check( local_deal_evaluator_hdl,
																				fte_additional_parameters->in_server_req_params->publisher_id, local_deal_list[iDeal]->deal_meta_id ) == 1 )
																				? ( "yes" ) : ( "no" ),
																				fte_additional_parameters->viewability,
																				fte_additional_parameters->impression_string ) ;
												continue ;
								}

								p_deal = local_deal_list[iDeal] ;
								p_stats = (deal_stats_t*)p_deal->p_stats ;

								__sync_fetch_and_add( &p_stats->ft_hits, 1 ) ;

								dsp_buyer_found = 0 ;
								//Check if the current deal is audience targeted
								if (p_deal->is_audience_targeted ==1)
								{
												audience_targeting_applied = audience_evaluate(local_deal_evaluator_hdl, p_deal->nonft_filter_h,
																				&nonft_params,p_deal->deal_meta_id,fte_additional_parameters->in_server_req_params->is_coppa_compliant,rs_hdl, debug_deal_meta, impression_id, adcampaigns->campaign_id,p_deal->pub_deal_id,&segment_price,&segment_exp, printbuf, sizeof(printbuf), p_stats);                         if (audience_targeting_applied==0)
												{
																continue;
												} 

								}

								for( iDSPBuyer = 0 ; iDSPBuyer < p_deal->dsp_buyer_count ; iDSPBuyer++ )
								{
												if( adcampaigns->dp_id == (unsigned long)p_deal->dsp_buyer_list[iDSPBuyer]->dsp_id )
												{
																DEAL_DEBUG(p_deal->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																								"Deal DSP id matched. Pub deal id: %s. Reason: Campaign DSP id %d, DSP buyer list DSP id: %d",
																								p_deal->pub_deal_id, adcampaigns->dp_id, p_deal->dsp_buyer_list[iDSPBuyer]->dsp_id ) ;
																dsp_buyer_found = 1 ;
																break ; 
												}

												DEAL_DEBUG(p_deal->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																				"Deal DSP id mismatch. Pub deal id: %s. Reason: Campaign DSP id %d, DSP buyer list DSP id: %d",
																				p_deal->pub_deal_id, adcampaigns->dp_id, p_deal->dsp_buyer_list[iDSPBuyer]->dsp_id ) ;
								}

								if( dsp_buyer_found == 0 )
								{
												DEAL_DEBUG(p_deal->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																				"Deal filtered out. Pub deal id: %s. Reason: Campaign DSP id %d not found in DSP buyer list",
																				p_deal->pub_deal_id, adcampaigns->dp_id ) ;
												__sync_fetch_and_add( &p_stats->dsp_id_misses, 1 ) ;								
												continue ;								
								}

								if( evaluate_publisher_requested_deal( p_deal, pub_pmp_obj ) == 0 )
								{
												DEAL_DEBUG(p_deal->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																				"Deal filtered out. Pub deal id: %s. Reason: Not requested by publisher",
																				p_deal->pub_deal_id ) ;
												__sync_fetch_and_add( &p_stats->pub_req_misses, 1 ) ;								
												continue ;
								}																
								if( deal_evaluator_match_nonft_params( p_deal->nonft_filter_h,
																				&nonft_params,
																				sites_delimited_list,
																				printbuf, sizeof(printbuf),
																				p_stats ) == 0 )
								{
												DEAL_DEBUG(p_deal->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																				"Deal filtered out. Pub deal id: %s. Reason: Some non fast targeting parameter did not match due to reason %s",
																				p_deal->pub_deal_id, printbuf ) ;
												continue ;
								}

								if( eval_custom_targeting( p_deal, fte_additional_parameters ) == 0 )
								{
												DEAL_DEBUG(p_deal->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																				"Deal filtered out. Pub deal id: %s. Reason: Did not clear custom targeting. Impression key value: %s",
																				p_deal->pub_deal_id, fte_additional_parameters->in_server_req_params->dkeyval ) ;
												__sync_fetch_and_add( &p_stats->custom_targeting_misses, 1 ) ;								
												continue ;
								}

								DEAL_DEBUG(p_deal->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																"Deal matched. Pub deal id: %s, Campaign DSP id: %d, Finding Buyers\n",
																p_deal->pub_deal_id, adcampaigns->dp_id ) ;

								__sync_fetch_and_add( &p_stats->deal_matched, 1 ) ;								

								clock_gettime(CLOCK_MONOTONIC, &starttime); //start post evaluation
								for( iDSPBuyer = 0 ; iDSPBuyer < p_deal->dsp_buyer_count ; iDSPBuyer++ )
								{
												if( adcampaigns->dp_id != (unsigned long)p_deal->dsp_buyer_list[iDSPBuyer]->dsp_id )
												{
																DEAL_DEBUG(p_deal->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																								"Deal DSP buyer evaluation. DSP id: %d. Buyer id: %d. DSP id not applicable\n",
																								p_deal->dsp_buyer_list[iDSPBuyer]->dsp_id,
																								p_deal->dsp_buyer_list[iDSPBuyer]->dsp_buyer_id ) ;
																continue ; 
												}

												//DO NOT CHANGE THE ORDER OF THESE CALLS SINCE insert_applicable_deal() deep copies the dsp_buyer_t object
												use_count = insert_applicable_deal( adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers,
																				use_count, p_deal->dsp_buyer_list[iDSPBuyer], buyer_id_passing_enable_flag,
																				fte_additional_parameters, local_deal_evaluator_hdl,
																				fte_additional_parameters->in_server_req_params->publisher_id ) ;

												if( use_count <= 0 || adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[use_count-1] == NULL )
												{
																llog_write(L_DEBUG, "ERROR: Error in deal evaluation for pub deal id %s. Failure to create dsp-buyer list"
																								"Deal count: %lu, Application deal count for impression: %d. Some inconsistency in data strcture\n",
																								p_deal->pub_deal_id, deal_count, use_count ) ;
																break ;
												}

												adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[use_count-1]->audience_targeting_applied = audience_targeting_applied ;		
												adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[use_count-1]->segment_price = segment_price ;		
												adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[use_count-1]->segment_exp = segment_exp ;		

												DEAL_DEBUG(p_deal->deal_meta_id, debug_deal_meta, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																				"Deal DSP buyer evaluation. Pub deal id: %s. DSP Buyer id: %d. DSP buyer applicable\n",
																				adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[use_count-1]->parent_deal_params->pub_deal_id,
																				adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[use_count-1]->dsp_buyer_id ) ;

												if( use_count == (int)dsp_buyer_list_size )
												{
																dsp_buyer_t **p_new_applicable_dsp_buyers = (dsp_buyer_t**)malloc( dsp_buyer_list_size*2*sizeof(dsp_buyer_t*) ) ;

																if( p_new_applicable_dsp_buyers == NULL )
																{
																				llog_write(L_DEBUG, "ERROR: Out of memory while processing deals. Not processing any more deals for this impression %s\n",
																												impression_id ) ;
																				break ;
																}

																memset( p_new_applicable_dsp_buyers, 0, dsp_buyer_list_size*2*sizeof(dsp_buyer_t*) ) ;
																memcpy( p_new_applicable_dsp_buyers, adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers, dsp_buyer_list_size*sizeof(dsp_buyer_t*) ) ;
																free( adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers ) ;
																adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers = p_new_applicable_dsp_buyers ;
																dsp_buyer_list_size = dsp_buyer_list_size*2 ;																				 
												}
								}
								clock_gettime(CLOCK_MONOTONIC, &endtime); //end post evaluation

								__sync_fetch_and_add( &p_stats->post_evaluation_sum_nanosec, DIFFTIME_NANOSEC( starttime, endtime ) ) ;
								__sync_fetch_and_add( &p_stats->post_evaluation_count, 1 ) ;
				}
				
				adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers_count = use_count;

				if( adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers_count > 1 )
				{
								clock_gettime(CLOCK_MONOTONIC, &starttime );
								qsort( adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers,
																adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers_count,
																sizeof(dsp_buyer_t*), cmp_dsp_buyer);	
								clock_gettime(CLOCK_MONOTONIC, &endtime );

								sorting_time_nanosec = DIFFTIME_NANOSEC( starttime, endtime ) ;
				}
				
				adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers_count = use_count;

				clock_gettime(CLOCK_MONOTONIC, &endtime_agg);

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				for( iDSPBuyer = 0 ; iDSPBuyer < (size_t)adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers_count ; iDSPBuyer++ )
				{
								p_deal = adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[iDSPBuyer]->parent_deal_params ;
								DEAL_DEBUG(p_deal->deal_meta_id, p_deal->deal_meta_id, impression_id, adcampaigns->campaign_id, DEAL_APPLICATION,
																"Deal DSP buyer evaluation. Pub deal id: %s. DSP Buyer id: %d, Priority: %d, USD ECPM: %f, DSP buyer applicable post ECPM checks and merging\n",
																adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[iDSPBuyer]->parent_deal_params->pub_deal_id,
																adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[iDSPBuyer]->dsp_buyer_id,
																adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[iDSPBuyer]->deal_pub.priority,
																adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers[iDSPBuyer]->deal_pub.deal_ecpm_usd ) ;
				}
#endif

				if( rtb_debug_enabled ) 
				{
								llog_write(L_DEBUG, "Deal aggregate latencies for campaign id %d. Total evaluation: %lu nanosec, DSP buyer list allocation: %lu nanosec, Fast targeting: %lu nanosec, Sorting: %lu nanosec\n",
																adcampaigns->campaign_id,
																DIFFTIME_NANOSEC( starttime_agg, endtime_agg ),
																extraction_time, 
																ft_time,
																sorting_time_nanosec
													) ;
				}			 
}

#ifdef QA_AUTOMATION
void automation_reload_deal_global_data() {
	reload_deal_evaluator();
}
#endif
