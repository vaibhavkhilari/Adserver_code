/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "error.h"
#include "db_error.h"
#include "fte_util.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "rt_types.h"
#include "deal.h"
#include "deal_util.h"

/*
 *  * clear_bit - Clears a bit in memory
 *   * @nr: the bit to clear.
 *    * @addr: the address to start counting from
 *     */
void clear_bit(int nr, unsigned long long *addr)
{
        *addr = ((~(1ULL << nr)) & (*addr));
}

/*
 *  * set_bit - Set a bit in memory
 *   * @nr: the bit to set
 *    * @addr: the address to start counting from
 *     */
void set_bit(int nr, unsigned long long *addr)
{
        *addr = ((1ULL << nr) | *addr);
}


static void applicable_dsp_buyers_cleanup ( dsp_buyer_t **applicable_dsp_buyers, int applicable_dsp_buyers_count){

				int index = 0;  
				if (applicable_dsp_buyers == NULL || applicable_dsp_buyers_count == 0){ 
								return;
				}   

				for (index = 0 ; index < applicable_dsp_buyers_count; index++){
								if( applicable_dsp_buyers[index] == NULL ) {
												continue ;
								}

								free( applicable_dsp_buyers[index] );
				}   
}


void campaigns_applicable_dsp_buyers_cleanup(publisher_site_ad_campaign_list_t *adcampaigns,
								int campaigns_count)
{
				int i = 0;
				if (adcampaigns == NULL ||
												campaigns_count == 0)
				{
								//NOP.
								return;
				}

				for (i = 0; i < campaigns_count; i++)
				{
								if( NULL != adcampaigns[i].ad_campaign_list_setings->applicable_dsp_buyers ) {

												applicable_dsp_buyers_cleanup( adcampaigns[i].ad_campaign_list_setings->applicable_dsp_buyers,
																				adcampaigns[i].ad_campaign_list_setings->applicable_dsp_buyers_count ) ;
												
												free(adcampaigns[i].ad_campaign_list_setings->applicable_dsp_buyers);

												adcampaigns[i].ad_campaign_list_setings->applicable_dsp_buyers = NULL;
												adcampaigns[i].ad_campaign_list_setings->applicable_dsp_buyers_count = 0;
								}
				}
}



/*
 * Encode given string in JSON form.
 */
void json_encode_string(char **buff, char *name, char *value, int add_separator)
{
		if (buff == NULL ||
						name == NULL ||
						value == NULL)
		{
				return;
		}

		if (add_separator == 1)
		{
				memcpy(*buff, ",", strlen(","));
				*buff += strlen(",");
		}
		memcpy(*buff, "\"", strlen("\""));
		*buff += strlen("\"");
		memcpy(*buff, name, strlen(name));
		*buff += strlen(name);
		memcpy(*buff, "\":\"", strlen("\":\""));
		*buff += strlen("\":\"");
		memcpy(*buff, value, strlen(value));
		*buff += strlen(value);
		memcpy(*buff, "\"", strlen("\""));
		*buff += strlen("\"");
}

/*
 * Encode given integer in JSON form.
 */
void json_encode_integer(char **buff, char *name, int value, int add_separator)
{
		char int_str[80 + 1];

		if (buff == NULL ||
						name == NULL)
		{
				return;
		}

		if (add_separator == 1)
		{
				memcpy(*buff, ",", strlen(","));
				*buff += strlen(",");
		}
		memcpy(*buff, "\"", strlen("\""));
		*buff += strlen("\"");
		memcpy(*buff, name, strlen(name));
		*buff += strlen(name);
		memcpy(*buff, "\":", strlen("\":"));
		*buff += strlen("\":");
		sprintf(int_str, "%d", value);
		memcpy(*buff, int_str, strlen(int_str));
		*buff += strlen(int_str);
}

/*
 * Encode given float in JSON form.
 */
void json_encode_double(char **buff, char *name, double value, int add_separator)
{
		char float_str[80 + 1];

		if (buff == NULL ||
			name == NULL)
		{
				return;
		}

		if (add_separator == 1)
		{
				memcpy(*buff, ",", strlen(","));
				*buff += strlen(",");
		}
		memcpy(*buff, "\"", strlen("\""));
		*buff += strlen("\"");
		memcpy(*buff, name, strlen(name));
		*buff += strlen(name);
		memcpy(*buff, "\":", strlen("\":"));
		*buff += strlen("\":");
		sprintf(float_str, "%.6g", value);
		memcpy(*buff, float_str, strlen(float_str));
		*buff += strlen(float_str);
}

void json_encode_double_truncated(char **buff, char *name, double value, int add_separator)
{
		char float_str[80 + 1];

		if (buff == NULL ||
			name == NULL)
		{
				return;
		}

		if (add_separator == 1)
		{
				memcpy(*buff, ",", strlen(","));
				*buff += strlen(",");
		}
		memcpy(*buff, "\"", strlen("\""));
		*buff += strlen("\"");
		memcpy(*buff, name, strlen(name));
		*buff += strlen(name);
		memcpy(*buff, "\":", strlen("\":"));
		*buff += strlen("\":");
		sprintf(float_str, "%.2f", value);
		memcpy(*buff, float_str, strlen(float_str));
		*buff += strlen(float_str);
}


