/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DYNAMIC_MARGIN__
#define __DYNAMIC_MARGIN__

#define DUMMY_DATA_FOUND(MARGIN_MAP) \
	(	(MARGIN_MAP)->lower_price == -1 && \
		(MARGIN_MAP)->upper_price == -1 && \
		(MARGIN_MAP)->sp_margin == -1	   \
	)

#if defined DEBUG || defined DSPM_DEBUG
        #define DSPM_DEBUGLOG(format, ...) fprintf(stderr, "\nDSPM: " format " -> %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__)
#else
        #define DSPM_DEBUGLOG(format, ...)
#endif

typedef struct dynamic_dsp_sp_margin {
	double lower_price; 
	double upper_price;
	double sp_margin;
}dsp_sp_margin_map_t;

void update_dynamic_second_price_margin( long campaign_id, double bid_price, double *second_price_margin,
                        		cache_handle_t* cache_handle, db_connection_t* adflex_dbconn);

#endif

