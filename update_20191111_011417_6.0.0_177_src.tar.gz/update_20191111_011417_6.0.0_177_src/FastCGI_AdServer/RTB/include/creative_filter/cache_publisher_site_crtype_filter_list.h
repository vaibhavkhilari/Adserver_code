/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

/* 
 * File:   cache_publisher_site_crtype_filter_list.h
 * Author: Srinivas
 *
 * Created on 18 August, 2015, 10:15 AM
 */

#ifndef CACHE_PUBLISHER_SITE_CRTYPE_FILTER_LIST_H
#define	CACHE_PUBLISHER_SITE_CRTYPE_FILTER_LIST_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "error.h"
#include "debug.h"    

#include "cache_libmemcached.h"
#include "db_publisher_site_crtype_filter_list.h"
    
publisher_site_crtype_filter_list_t * cache_get_publisher_site_crtype_filter_list(
                                        cache_handle_t* cache,
                                        db_connection_t* dbconn,
                                        long pub_id,
                                        long site_id
                                    );

#ifdef	__cplusplus
}
#endif

#endif	/* CACHE_PUBLISHER_SITE_CRTYPE_FILTER_LIST_H */

