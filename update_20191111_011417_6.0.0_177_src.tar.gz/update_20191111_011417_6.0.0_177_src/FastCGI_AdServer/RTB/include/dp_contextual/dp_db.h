/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DP_DB_H__
#define __DP_DB_H__

#include "dp_properties.h"

#define DP_AUTHENTCATE_KEY_SIZE		256
#define DP_RES_TYPE_BUFF_SIZE		256
#define DP_NAME_SIZE				256

/*
 * Macros for index number for SQLBindCol for input parametrs.
 */
#define FIRST	0
#define DP_ID_IN_IDX					(FIRST + 1)
#define DP_DATACENTER_ID_IN_IDX			(DP_ID_IN_IDX + 1)

/*
 * Macros for index number for SQLBindCol for output parametrs.
 */
#define DP_ID_OUT_IDX					(FIRST + 1)
#define DP_NAME_OUT_IDX					(DP_ID_OUT_IDX + 1)
#define DP_IS_ENABLED_OUT_IDX			(DP_NAME_OUT_IDX + 1)
#define DP_REQUEST_TIMEOUT_OUT_IDX		(DP_IS_ENABLED_OUT_IDX + 1)
#define DP_CONNECTION_TIMEOUT_OUT_IDX	(DP_REQUEST_TIMEOUT_OUT_IDX + 1)
#define DP_BASE_URL_OUT_IDX				(DP_CONNECTION_TIMEOUT_OUT_IDX + 1)
#define DP_AUTHENTICATION_TYPE_OUT_IDX	(DP_BASE_URL_OUT_IDX + 1)
#define DP_AUTHENTICATION_KEY_OUT_IDX	(DP_AUTHENTICATION_TYPE_OUT_IDX + 1)
#define DP_RESPONSE_TYPE_OUT_IDX		(DP_AUTHENTICATION_KEY_OUT_IDX + 1)

/*
 * SQL query to read configuration from DB.
 */
#define DP_CONTEXTUAL_READ_CONF_QUERY	"select dp_id, dp_name, dp_is_enabled, dp_request_timeout, dp_connection_timeout, dp_base_url, dp_authentication_type, \
									 dp_authentication_key, dp_response_type from dp_contextual_generic_config where dp_id = ? and dp_datacenter_id = ?"

/*
 * Structure to store dp_contextual configuration read from DB.
 */
typedef struct dp_contextual_config{
	int isactive;
	int timeout;
	int conn_timeout;
	int calltype;
	char dp_base_url[MAX_URL_SIZE + 1];
	int dp_authentication_method;
	char dp_authentication_key[DP_AUTHENTCATE_KEY_SIZE + 1];
	//int dp_authentication_session_timeout;
	char responsetype[DP_RES_TYPE_BUFF_SIZE + 1]; //TODO id instead of char.
}dp_contextual_config_t;

int init_dp_contextual_config(dp_contextual_config_t *dp_contextual_config);
int dp_contextual_read_conf(
		db_connection_t *dbconn,
		dp_contextual_config_t *dp_contextual_config,
		int dp_id,
		int dc_id);

#endif /* __DP_DB_H__ */
