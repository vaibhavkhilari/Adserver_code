/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __TEST_JSON_H__
#define __TEST_JSON_H__

#define CNT	2
#define JSON_STR_COUNT	2000


char json[CNT][2048] = {
		{"{ \
				\"language\":\"en\",\
				\"scope\":\"page\",\
				\"brandprotection\":{\
						\"rating\":{\
						\"20995\":1},\
				\"safetylevel\":{\
						\"21001\":1},\
				\"nonstandardcontent\":{\
\
		}\
		},\
		\"contextual\":\
		{	\"type\":\"iab\",\
			\"category\":[\
				{	\"weight\":100,\
					\"id\":20603},\
				{	\"weight\":100,\
					\"id\":20966},\
				{	\"weight\":17,\
					\"id\":20625},\
				{	\"weight\":12,\
					\"id\":20602},\
				{	\"weight\":12,\
					\"id\":20788}\
			]\
		}\
	}"},
	{"{ \
				\"language\":\"en\",\
				\"scope\":\"page\",\
				\"brandprotection\":{\
						\"rating\":{\
						\"20995\":1},\
				\"safetylevel\":{\
						\"21001\":1},\
				\"nonstandardcontent\":{\
\
		}\
		},\
		\"contextual\":\
		{	\"type\":\"iab\",\
			\"category\":[\
				{	\"weight\":100,\
					\"id\":20603},\
				{	\"weight\":100,\
					\"id\":20966},\
				{	\"weight\":17,\
					\"id\":20625},\
				{	\"weight\":12,\
					\"id\":20602},\
				{	\"weight\":12,\
					\"id\":20788}\
			]\
		}\
	}"}
};

#endif /* __TEST_JSON_H__ */
