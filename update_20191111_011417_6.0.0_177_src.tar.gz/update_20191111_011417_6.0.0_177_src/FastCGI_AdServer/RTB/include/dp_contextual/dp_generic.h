/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DP_GENERIC_H
#define __DP_GENERIC_H


#include "ad_server_types.h"
#include "db_connection.h"

typedef int (*dpops_get_id)(void);
typedef const char*(*dpops_get_name)(void);
typedef int (*dpops_get_isenabled)(void *);
typedef int (*dpops_initialize)(db_connection_t *, void **, int *size);
typedef int (*dpops_release_config)(void *);
typedef int (*dpops_create_request)(void *,
					const ad_server_req_param_t *,
					CURL *,
					void *);
typedef int (*dpops_parse_response)(void *,
					const char *response,
					int response_size,
					void *dp_cont_bp_data);

typedef struct dp_ops{
	dpops_get_id get_id;
	dpops_get_name get_name;
	dpops_get_isenabled get_isenabled;
	dpops_initialize initialize;
	dpops_release_config release_config;
	dpops_create_request create_request;
	dpops_parse_response parse_response;
}dp_ops_t;

/*
 * OPS structure for DP
 */
typedef struct dp_generic{
	int dpid;
	dp_ops_t *dp_ops;
}dp_generic_t;

/*
 * Config container
 *
 * dp_spec_config and dp_spec_config_size 
 * is populated by calling DP specific functions
 */
typedef struct dp_config{
	void *dp_spec_config;
	int dp_spec_config_size;
	dp_generic_t *dp_generic; // This is global and so we just keep a reference
}dp_config_t;

#endif /* end __DP_GENERIC_H */
