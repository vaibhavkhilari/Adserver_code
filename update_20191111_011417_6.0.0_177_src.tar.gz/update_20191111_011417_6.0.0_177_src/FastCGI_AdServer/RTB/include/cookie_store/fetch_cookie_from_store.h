/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __FETCH_COOKIE_FROM_STORE__
#define __FETCH_COOKIE_FROM_STORE__ 

//#include "cookie_store_types.h"
//#include "serversidestore_types.h"
//#include "c_func_header.h"
#include "ctleaf_wrapper.h"
#include "server_side_cookie_store.h"
#include <curl/curl.h>

#define SPUG_SUCCESS	"SUCCESS"
#define SPUG_FAILURE	"FAILURE"
#define SIZE_OF_INT 4
#define MAX_URL_LEN 1024
#define MAX_COOKIE_STORE_OBJ_SIZE 4096 //max length of data from cookie store
#define MAX_SPUG_RETURN_OBJ_SIZE 7

#define MAX_FLOAT_BUFFER_LEN 16
#define MAX_INT_BUFFER_LEN 12
#define MAX_RPUG_FLOOR_OBJ_SIZE (MAX_FLOAT_BUFFER_LEN + MAX_INT_BUFFER_LEN)

#define PUBMATIC_COOKIESTORE_ID 0
#ifdef CS_DEBUG
#define DEBUG_PRINTF(format, ...) fprintf(stderr, "CS_LOG::"format, ##__VA_ARGS__)
#else
#define DEBUG_PRINTF(format, ...)
#endif

/* memory structure for cookie store curl call */
typedef struct rpug_memory_struct {
	char	memory[MAX_COOKIE_STORE_OBJ_SIZE + 1];
	size_t	size;
	unsigned int	max_length;
} rpug_memory_struct_t;

/*memory structure for SPUG curl call */
typedef struct spug_memory_struct {
	char	memory[MAX_SPUG_RETURN_OBJ_SIZE + 1];
	size_t	size;
	unsigned int	max_length;
} spug_memory_struct_t;

/* memory struct for rpug curl call to get user-floor */
typedef struct floor_rpug_memory_struct {
	char		memory[MAX_RPUG_FLOOR_OBJ_SIZE + 1];
	size_t		size;
	unsigned int	max_length;
} floor_rpug_memory_struct_t;

/* function to fetch piggyback cookie from cookie store*/
size_t rpug_memory_callback(void *ptr,
			size_t size,
			size_t nmemb,
			void *data);

size_t spug_memory_callback(void *ptr,
			size_t size,
			size_t nmemb,
			void *data);

size_t rpug_floor_memory_callback(void *ptr,
			size_t size,
			size_t nmemb,
			void *data);

int fetch_user_floor_cs(char *pubmatic_uid,
			const long site_id,
			cs_user_floor_data_t *user_floor_data);

int fetch_server_side_cookies( char **pubmaticUID,
		char* partnerUID,
		char* req_pubmaticUID,
		cookie_store_data_t *cookie_store_data,
		void **user_segment_list_info,
		const long freq_siteid,
		int *flag_read_fcap_from_cs,
		int user_id_preference,
		unsigned int *aero_call_counter,
		void *audience_stats,
		puid_stats_t *puid_stats,
		int active_tag_new_approach);

int fetch_cookiestore_data(CURL *curl,
			rpug_memory_struct_t *rpug_chunk,
			const char *partnerUID,
			int partnerID,
			int site_id);

/*int populate_cookie_store_data(cookie_store_data_t *cookie_store_data,
			char *csdata,
			int len);*/

int extract_individual_data(char *csdata,
			int len,
			char **piggyback,
			int *plen,
			char **campfreq,
			int *clen,
			char **netfreq,
			int *nlen,
			char **userfloor,
			int *flen);

int validate_binary_data(char *data,
			int len,
			int *plen,
			int *clen,
			int *nlen,
			int *flen);

int allocate_and_copy(char *buf,
			int len,
			char **data);

int update_spug_freq_data(CURL *curl,
			char cookie_store_url[]);

int construct_freq_update_url(char *partner_uid,
                        int req_type,
                        int camp_id,
                        int site_id,
                        int net_id,
                        time_t cexpiry,
                        time_t nexpiry,
			int secure,
			int client_call,
                        char cookie_store_url[]);

int fetch_user_floor_value(CURL *curl,
						floor_rpug_memory_struct_t *chunk,
                        const char *pubmatic_uid,
                        int site_id);

int parse_userfloor_data(char *floor_string,
			float *cs_ufv,
			int *cs_dsf);

int is_pubmatic_optout(char *pubmatic_uid);

#endif /*__FETCH_COOKIE_FROM_STORE__*/
