#ifndef __RT_BIDDING_H__
#define __RT_BIDDING_H__

#include "rt_types.h"

#define IPV4_LEVEL 3
#define IPV6_TRUNCATE_END 29
#define PAYMENT_TAGID_SEPRATOR "-"


int truncate_ip_address(char* truncated_ip, const char* ip);

int append_pubmatic_pay_tagid(
		cache_handle_t *cache, db_connection_t *dbconn,
		const publisher_level_settings_t *publisher_level_settings,
		long pub_id,
		char *payment_tagid_chain);

void init_rtb_custom_params(rt_request_params_t* in_request_params,
		const ad_server_additional_params_t* additional_parameter);
void truncate_xff(const char* xff, char* truncated_xff);

#endif
