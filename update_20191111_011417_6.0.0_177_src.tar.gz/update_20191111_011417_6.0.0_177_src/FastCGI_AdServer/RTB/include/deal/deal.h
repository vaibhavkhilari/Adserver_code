/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DEAL_H__
#define __DEAL_H__

#include <linux/types.h>
#include "deal_def.h"

#include "fte_types.h"
#include "floor_rules_types.h"
#include "ad_server_types.h"

#define PMP_DEAL 0
#define PUBCONNECT_DEAL 1
#define NOT_ADDED_IN_RTB_REQUEST 111
#define ADDED_IN_RTB_REQUEST 222

typedef struct deal_pub_fields
{
	double deal_ecpm_usd ;
	double deal_ecpm_native ;
	int priority ;
	//1 - First price, 2 - Second Price. 3 Fixed price
	int auction_id;
	double pub_margin;
	int pub_margin_type; //0=No Margin, 1=Fixed Margin(MAP0), 2=Dynamic Margin(MAP2/MAP0) 
	int currency_id ;
} deal_pub_fields_t ;

typedef struct dsp_buyer
{
	//long site_id;
	int pubmatic_buyer_id;
	int dsp_buyer_id;
	int dsp_id;
	struct deal_params *parent_deal_params;
	int in_rtb_request; //for use only on the data path 
	int audience_targeting_applied; //for use only on the data path 
	double segment_price ; //for use only on the data path 
	char *segment_exp ;//for use only on the data path 
	deal_pub_fields_t deal_pub ;
} dsp_buyer_t;


typedef struct deal_params
{
	//This is deal.id in deal table and is need for deal_overrriding feature
	int id;					
	int pub_id ; // deal.pub_id
	//This is deal.deal_meta_id in deal table. This is id is created and dont change there after.
	//So this is used in key for deal white list and rule engine where it is campared against rule_meta_id
	//since both this value is populated from managment and will be same for deal
	int deal_meta_id;				
	//This is deal.deal_id in deal table. This id changes when deal is modified.It is this value that is added in server side log.
	int pubmatic_deal_id;
	// This is deal.pub_deal_id in deal table. Deal ID as entered by Publisher and it used in RTB request and response
	char pub_deal_id[MAX_DEAL_ID_LEN + 1];
	double deal_second_price_margin;
	int deal_type;
	int deal_level_feature_flag;
	int deal_channel_type_id;
	bool publisher_owned; //1 = Deal is publisher baought, 0 = Deal is pubmatic bought
	void *nonft_filter_h ;
  size_t dsp_buyer_count ;
	dsp_buyer_t **dsp_buyer_list ;
	void *p_stats ;
	uint8_t is_audience_targeted;
} deal_params_t;

struct rt_request_params;
struct rt_dsp_buyer_map;
struct rt_request_url_params_mask;
struct publisher_site_ad_campaign_list;
struct publisher_site;
struct ad_server_additional_params;
struct rt_response_params;
struct fte_params;
struct publisher_site_ad;

typedef struct result_set *result_set_hdl;

void compose_deals_params_post_data(char **post_data,
	        struct publisher_site_ad_campaign_list *adcampaigns,
        	const struct rt_request_url_params_mask *rt_request_url_params_mask1,
	        struct fte_params *fte_additional_parameters, int *flag);

void load_deal_evaluator(void) ;

void processAudienceDealsPreCampaign(struct fte_params *fte_additional_parameters);

void get_applicable_deals( struct fte_params *fte_additional_parameters,
								struct publisher_site_ad_campaign_list *adcampaigns,
								struct publisher_site_ad *in_ad,
								int buyer_id_passing_enable_flag,
								bool is_ortb_msize_format_enabled,
								struct rt_response_params *rt_response_param,
								int debug_deal_meta,
								char *impression_id,
								int rtb_debug_enabled,
								result_set_hdl rs_hdl
								) ;

uint8_t is_audience_deal_present( int pub_id, int site_id ) ;

#endif //__DEAL_H_

