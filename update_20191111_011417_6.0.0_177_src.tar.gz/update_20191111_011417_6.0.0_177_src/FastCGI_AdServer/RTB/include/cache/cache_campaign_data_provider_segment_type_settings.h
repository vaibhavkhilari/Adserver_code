/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __CACHE_CAMPAIGN_LEVEL_DATA_PROVIDER_SETTINGS_H__

#include "cache_types.h"
#include "db_connection.h"
#include "campaign_data_provider_data.h"
#include "campaign_data_provider_settings.h"

//Data-Provider data passing settings in Memcache.
typedef struct memcache_dp_data_passing_settings
{
        int segment_type_id;
		int segment_id;
} memcached_dp_data_passing_settings_t;

//Campaign data passing settngs in Memcache.
typedef struct memcache_cmpg_dp_data_passing_settings
{
       int dp_settings_count;
       memcached_dp_data_passing_settings_t dp_settings[0];
} memcache_cmpg_dp_data_passing_settings_t;

/*
 * Cache call for getting Campaign Data-Provider Segment Type settings.
 * It will fill given memcache_cmpg_dp_data_passing_settings_t object.
 */
int cache_get_cmpg_data_provider_segment_type_settings(
				long campaign_id,
				int data_provider_id,
                memcache_cmpg_dp_data_passing_settings_t **cmpg_dp_settings,
				cache_handle_t *cache,
                db_connection_t *dbconn);

#endif //__CACHE_CAMPAIGN_LEVEL_DATA_PROVIDER_SETTINGS_H__
