/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __URL_BLOCKLIST_H__
#define __URL_BLOCKLIST_H__
#include <stdio.h>
#include <stdlib.h>
#include "ad_server_types.h"
#include "rt_types.h"
#include "db_connection.h"
#include "cache_types.h"
//struct db_connection_t;
//struct cache_handle_t;
/*typedef struct url_blocklist {
	char* json_blocklist;
	int len_category_blocklist;
	int len_brand_blocklist;
	int len_url_blocklist;
	int len_vertical_blocklist;
}url_blocklist_t;*/

typedef struct memcached_blocklist
{
	char json_url_blocked_list[MAX_BLOCKLIST_SIZE + 1];
	int json_url_blockedlist_len;
	int json_blocked_creative_attributes_len;
	int json_blocked_advt_categories_len;
	int json_blocked_iab_advt_categories_len;
	char json_allowed_creative_attributes_list[MAX_ALLOWED_CREATIVE_ATTRIBUTES_LIST_LEN + 1];
	int json_allowed_creative_attributes_list_len;
	int json_total_len;
} memcached_blocklist_t;

int cache_get_json_blocklist(long pub_id, long site_id, cache_handle_t* cache_handle, db_connection_t* conn, rt_request_params_t *rt_request_params);
#endif
/*exclude {
brands : [<List of Brand ids>],
creative_categories : [<List of Creative Categories>],
ad_verticals : [List of Ad Verticals],
urls : [<List of urls>],
}
*/

