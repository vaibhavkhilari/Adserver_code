/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __BLOOM_FILTER_H__
#define __BLOOM_FILTER_H__
#include<limits.h>
#include<stdlib.h>

//i18
#include <idna.h>
#include <tld.h>
#include <stringprep.h>
#define LIBIDN_REQUIRED_VERSION "0.4.1"
#define IS_ASCII 1
#define IS_NON_ASCII 0
//unicode to punycode conversion error codes
#define ASC_CONVERT_SUCCESS 0
#define NO_ASC_CONVERSION -1
#define ASC_CONVERT_ERROR -2
#define ASC_INVALID_VERSION -3
#define MAX_ALLOWED_BLOOMS 3
#define SETBIT(a, n) (a[n/CHAR_BIT] |= (1<<(n%CHAR_BIT)))
#define GETBIT(a, n) (a[n/CHAR_BIT] & (1<<(n%CHAR_BIT)))

#define WWW_STR "www."
#define WWW_STR_LEN 4
#define MAX_ELEMENT_COUNT 200000 //maximum allowed urls to be inserted in blocklist/bloom filter
#define MAX_ELEMENT_COUNT_WHITELIST 150000 //maximum allowed urls to be inserted in whitelist/bloom filter

#define MAX_ALLOWED_URL_PER_BLOOM 200000
#define MAX_URL_LIMIT (MAX_ALLOWED_URL_PER_BLOOM * MAX_ALLOWED_BLOOMS) //that needs to read from DB

#define BIT_CHUNK 4194303 //(2^22)-1
#define BIT_COUNT 22 //# bits to be considered as a number for getting single bit position in bit array
#define BIT_LIMIT 64 //# bits in a single number out of 3 numbers returned by tiger/192
#define SKIPED_BITS 7 //# bits to be skipped while choosing bits for forming a number i.e. bit position in bit array
#define BITS_SET_PER_URL 21 //# bit positions to represent single url
#define BIT_ARRAY_SIZE_BYTES(size) ((size+CHAR_BIT-1)/CHAR_BIT)*sizeof(char) //calculate bit array size in bytes
#define BIT_ARRAY_SIZE_BITS(nelements) ((nelements + (nelements * 0.25) + 1) * BITS_SET_PER_URL) //# bits in bit array
#define BIT_ARRAY_SIZE (int)BIT_ARRAY_SIZE_BITS(MAX_ELEMENT_COUNT) //i.e. 656253, required for bit array of 200000 elements

#ifdef DEBUG_BLOCKLIST
#define BLOCKLIST_DEBUG(format, ...) fprintf(stderr, format, ##__VA_ARGS__)
#else
#define BLOCKLIST_DEBUG(format, ...)
#endif /* DEBUG_BLOCKLIST */

#ifdef DEBUG_WHITELIST
#define WHITELISTLIST_DEBUG(format, ...) fprintf(stderr, format, ##__VA_ARGS__)
#else
#define WHITELIST_DEBUG(format, ...)
#endif /* DEBUG_WHITELIST */

#ifdef DEBUG_BLOCKLIST_C
#define BLOCKLIST_DEBUG_C(format, ...) fprintf(stderr, format, ##__VA_ARGS__)
#else
#define BLOCKLIST_DEBUG_C(format, ...)
#endif /* DEBUG_BLOCKLIST_C */

#ifdef DEBUG_WHITELIST_C
#define WHITELIST_DEBUG_C(format, ...) fprintf(stderr, format, ##__VA_ARGS__)
#else
#define WHITELIST_DEBUG_C(format, ...)
#endif /* DEBUG_WHITELIST_C */

#ifdef DEBUG_MULTIBLOOM
#define MULTIBLOOM_DEBUG(format, ...) fprintf(stderr, format, ##__VA_ARGS__)
#else
#define MULTIBLOOM_DEBUG(format, ...)
#endif /* DEBUG_MULTIBLOOM */

#define INVALID_FILTER_IN_CACHE(BLOCKLIST) ({ \
		( ((unsigned char*)&((BLOCKLIST)[1])) == NULL			|| \
			(BLOCKLIST)->bit_array_size <= 0        || \
			(BLOCKLIST)->nelements <= 0 \
		); \
		})

#define TOTAL_BLOOM_OBJECT_SIZE(nelements) \
	  (sizeof(BLOOM)+ BIT_ARRAY_SIZE_BYTES(BIT_ARRAY_SIZE_BITS(nelements))+1)

//SQL QUERIES TO GET MULTI BLOOM

#define MAX_CRC64_CREATIVE_BLOOM_KEY_SZ 25

#define GET_GLOBAL_SS_BLOCKLIST_BLOOM "SELECT bloom_filter, blocklist_domain_count, bloom_version FROM global_supply_side_blocklist_filter WHERE id = ? AND id = ? LIMIT 1"

#define GET_PUB_SITE_DOMAIN_WHITELIST_BLOOM \
	  "SELECT bloom_filter, whitelist_domain_count, bloom_version FROM publisher_site_white_list_filter WHERE pub_id = ? AND site_id = ? LIMIT 1"

#define GET_PUB_SITE_DOMAIN_BLOCKLIST_BLOOM \
	  "SELECT bloom_filter, blocked_domain_count, bloom_version FROM publisher_site_landing_page_filter WHERE pub_id = ? AND site_id = ? LIMIT 1"

#define GET_PUB_SITE_CREATIVE_WHITELIST_BLOOM \
	    "SELECT whitelisted_bloom_filter, whitelisted_creative_count, bloom_version FROM publisher_site_creative_id_filter WHERE pub_id = ? AND site_id = ? LIMIT 1"

#define GET_PUB_SITE_CREATIVE_BLOCKLIST_BLOOM \
	    "SELECT blacklisted_bloom_filter, blacklisted_creative_count, bloom_version FROM publisher_site_creative_id_filter WHERE pub_id = ? AND site_id = ? LIMIT 1"

#define GET_PUB_SITE_CRC64_CREATIVE_WHITELIST_BLOOM \
	    "SELECT crc64_whitelisted_bloom_filter, crc64_whitelisted_creative_count, bloom_version FROM publisher_site_creative_id_filter WHERE pub_id = ? AND site_id = ? LIMIT 1"

#define GET_PUB_SITE_CRC64_CREATIVE_BLOCKLIST_BLOOM \
	    "SELECT crc64_blacklisted_bloom_filter, crc64_blacklisted_creative_count, bloom_version FROM publisher_site_creative_id_filter WHERE pub_id = ? AND site_id = ? LIMIT 1"

#define GET_PUB_SITE_DEAL_WHITELIST_BLOOM \
	  "SELECT dw_bloom, dw_domain_count, bloom_version FROM publisher_site_deal_whitelist_bloom_new WHERE pub_id = ? AND site_id = ? LIMIT 1"

#define GET_DSP_CAMPAIGN_WHITELIST_BLOOM \
	    "SELECT bloom_filter, whitelisted_domain_count, bloom_version FROM dsp_campaign_whitelist_filter WHERE dp_id = ? AND campaign_id = ? LIMIT 1"

#define GET_DSP_CAMPAIGN_BLOCKLIST_BLOOM \
	    "SELECT bloom_filter, blocked_domain_count, bloom_version FROM dsp_campaign_blocklist_filter WHERE dp_id = ? AND campaign_id = ? LIMIT 1"

#define GET_DSP_CAMPAIGN_APPURL_BLOCKLIST_BLOOM \
	"SELECT bloom_filter, blocked_appurl_count, bloom_version FROM dsp_campaign_appurl_blocklist_filter WHERE dp_id = ? AND campaign_id = ? LIMIT 1"

#define GET_DSP_CAMPAIGN_APPURL_WHITELIST_BLOOM \
	"SELECT bloom_filter, whitelisted_appurl_count, bloom_version FROM dsp_campaign_appurl_whitelist_filter WHERE dp_id = ? AND campaign_id = ? LIMIT 1"

#define GET_PUB_SITE_FLR_RL_ADV_ID_BLOOM \
	"SELECT bloom, domain_count, bloom_version FROM publisher_site_floor_rule_bloom_filter WHERE pub_id = ? AND site_id = ? AND active_entity = 3 LIMIT 1"

#define GET_PUB_SITE_FLR_RL_ADV_DOM_BLOOM \
	"SELECT bloom, domain_count, bloom_version FROM publisher_site_floor_rule_bloom_filter WHERE pub_id = ? AND site_id = ? AND active_entity = 4 LIMIT 1"

#define GET_PUB_SITE_FLR_RL_ADV_CAT_BLOOM \
	"SELECT bloom, domain_count, bloom_version FROM publisher_site_floor_rule_bloom_filter WHERE pub_id = ? AND site_id = ? AND active_entity = 14 LIMIT 1"

#define GET_DAA_DEVICE_OPTOUT_BLOOM \
	  "SELECT bloom_filter, deviceid_count, bloom_version FROM daa_device_optout_filter WHERE hashing_used = ? AND device_type = ? LIMIT 1"

#define GET_GLOBAL_CREATIVE_ID_BLOCKLIST_BLOOM \
	"SELECT bloom_filter, element_count, bloom_version, update_time FROM AdFlex.global_bloom_filter WHERE bloom_type_id = 0 AND update_time > '%s' AND bloom_version = 2 LIMIT 1"

#define GET_DSP_PUB_CAMPAIGN_BLOCKLIST_BLOOM \
    "SELECT bloom_filter, blocked_domain_count, bloom_version FROM publisher_campaign_block_list_filter WHERE dp_id = ? AND campaign_id = ? AND pub_id = %ld"

#define GET_ADS_TXT_DOMAIN_LIST_BLOOM \
    "SELECT bloom_filter, domain_count, bloom_version, update_time FROM KomliAdServer.ads_txt_domain_list_filter WHERE pub_id = %ld AND type = %ld LIMIT 1"

#define GET_GLOBAL_ADS_TXT_DOMAIN_LIST_BLOOM \
    "SELECT bloom_filter, domain_count, bloom_version, update_time FROM KomliAdServer.ads_txt_domain_list_filter WHERE pub_id = 0 AND type = 0 AND update_time > '%s' LIMIT 1"

#define GET_APP_ADS_TXT_BLOOM \
    "SELECT bloom_filter, app_count, bloom_version, update_time FROM KomliAdServer.app_ads_txt_bloom_filter WHERE pub_id = %ld AND type = %ld LIMIT 1"

#define GET_GLOBAL_APP_ADS_TXT_BLOOM \
    "SELECT bloom_filter, app_count, bloom_version, update_time FROM KomliAdServer.app_ads_txt_bloom_filter WHERE pub_id = 0 AND type = 0 AND update_time > '%s' LIMIT 1"

#define GET_GLOBAL_UNIQUE_CREATIVE_ID_BLOOM \
    "SELECT bloom_filter, element_count, bloom_version, update_time FROM AdFlex.global_bloom_filter WHERE bloom_type_id = 2 AND update_time > '%s' AND bloom_version = 2 LIMIT 1"

#define GET_PUB_GEO_DOMAIN_BLOCKLIST_BLOOM \
    "SELECT bloom_filter, domain_count, bloom_version, update_time FROM AdFlex.pub_geo_domain_blocklist_filter WHERE pub_id = %ld LIMIT 1"

#define GET_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_BLOOM \
	"SELECT bloom_filter, element_count, bloom_version, update_time FROM AdFlex.global_bloom_filter WHERE bloom_type_id = 1 AND update_time > '%s' AND bloom_version = 2 LIMIT 1"

#define GET_GSS_DOMAIN_BLOCKLIST_BLOOM \
	"SELECT bloom_filter, element_count, bloom_version, update_time FROM AdFlex.global_bloom_filter WHERE bloom_type_id = 4 AND update_time > '%s' AND bloom_version = 2 LIMIT 1"

#define GET_GSS_APP_BLOCKLIST_BLOOM \
	"SELECT bloom_filter, element_count, bloom_version, update_time FROM AdFlex.global_bloom_filter WHERE bloom_type_id = 5 AND update_time > '%s' AND bloom_version = 2 LIMIT 1"

#define GET_CLASSIFIED_CREATIVES_SMALL_BLOOM \
	"SELECT bloom_filter, element_count, bloom_version, update_time FROM AdFlex.global_bloom_filter WHERE bloom_type_id = 3 AND update_time > '%s' AND bloom_version = 2 LIMIT 1"

#define GET_CLASSIFIED_CREATIVES_GIANT_BLOOM \
	"SELECT bloom_filter, element_count, bloom_version, update_time FROM AdFlex.global_bloom_filter WHERE bloom_type_id = 6 AND update_time > '%s' AND bloom_version = 2 LIMIT 1"

typedef unsigned long long int word64;
typedef unsigned long word32;
typedef unsigned char byte;

typedef unsigned int (*hashfunc_t)(byte*, word64, word64*);
typedef struct {
	size_t bit_array_size;		//number of bits in bit array i.e. (URL_COUNT_IN_BLOCKLIST * BITS_SET_PER_URL)
	int nelements;	//total no. of blocked domains
} BLOOM;

typedef struct {
	BLOOM* bloom_filter_0[MAX_ALLOWED_BLOOMS];
	BLOOM* bloom_filter_s[MAX_ALLOWED_BLOOMS];
	int bloom_count_0;
	int bloom_count_s;
} MULTI_BLOOM;

enum BLOOM_FILTER_TYPE {
		DSP_APP_BLOCKLIST_BLOOM_FILTER = 0,
		DSP_TLD_BLOCKLIST_BLOOM_FILTER = 1
};

BLOOM *bloom_create(int nelements, size_t *memcache_obj_size);
int bloom_destroy(BLOOM **bloom);
int bloom_add(BLOOM *bloom, const char *s);
int bloom_check(const BLOOM *bloom, const char *s);

//Hash Function tiger/192
void tiger(byte*, word64, word64*);

int substring_bloom_search(
		char* domain_to_be_searched,
		const BLOOM* bloom
		);
int create_and_test_bloom ( void ) ;
int char_counter(
		const char* str,
		char c
		);

int substring_deal_bloom_search(
		int deal_meta_id,
		char* domain_to_be_searched,
		const BLOOM* bloom
		);

int substring_multi_bloom_search(
		char* domain_to_be_searched,
		const MULTI_BLOOM* multi_bloom
		);

int substring_multi_concat_bloom_search(
		int deal_meta_id,
		const char* domain_to_be_searched,
		const MULTI_BLOOM* multi_bloom
		);
int check_in_blocklist_bloom(
		const char *processing_data,
		const MULTI_BLOOM *multi_bloom
		);

int convert_unicode_domain_to_punycode(
		const char *in_domain,
		char **out_domain);

int get_actual_url_start_pos(char*in_str);

int evaluate_url_filter(
		char* domain_to_be_searched,
		const BLOOM** bloom,
		const int bloom_count,
		const int depth_of_search,
		char delim
		);
#endif /* __BLOOM_H__ */
