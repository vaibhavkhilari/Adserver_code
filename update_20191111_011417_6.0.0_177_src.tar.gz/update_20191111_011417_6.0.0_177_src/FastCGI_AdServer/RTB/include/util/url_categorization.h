/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __URL_CAT__
#define __URL_CAT__

#define DUMMY_IAS_SETTINGS_FOUND(SETTINGS) 		\
        (       (SETTINGS)->campaign_id == -1 && 	\
                (SETTINGS)->enabled_ias_services == -1	\
	)

#if defined DEBUG || defined URLCAT_DEBUG
        #define UCAT_DEBUGLOG(format, ...) fprintf(stderr, "\nUCAT: " format " -> %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__)
#else
        #define UCAT_DEBUGLOG(format, ...)
#endif

#define MAX_CURL_INTEGRAL_DATA_SIZE 	1024
#define INTEGRAL_PLATFORM_NAME		"adsafe_url" 
#define MAX_CONNECTION_URL_LENGTH   	2047
#define URLCAT_CURL_NAME 		"URL CATEGORIZATION CURL"
#define IAB_KEYWORD			"\"iab\":["
#define BSC_KEYWORD			"\"bsc\":{"

#define JSON_BSC "bsc"
#define JSON_SAM "sam"
#define JSON_IAB "iab"

#define PAGE_CAT_MAP		1
#define BSC_MAP			2
#define SAM_FLT_MAP             4
#define BSC_FLT_MAP             8
 
#define MAX_IAS_VALUE 2000

#define NUMBER_OF_BSC_KEYS 6 

typedef struct integral_curl_data {
        char data[MAX_CURL_INTEGRAL_DATA_SIZE + 1];
        size_t size;
}integral_curl_data_t;

int set_integral_options ( const ad_server_req_param_t *in_server_req_params, 
				CURL *curl, 
				integral_curl_data_t *integral_chunk, 
				integral_data_t *integral_data,
				int level);

int parse_integral_data(const integral_curl_data_t *integral_chunk,
				 integral_data_t *integral_data);
int init_integral_curl_handle(CURL **curl_handle, const char* connection_name,
	const int connection_timeout,
	const int request_timeout,
	const int no_signal);

int get_enabled_ias_services_for_campaign(
		integral_data_t * integral_data,
		unsigned int campaign_id
		);
void remove_query_params(char *dest, const char* src, size_t max_size);
#endif

