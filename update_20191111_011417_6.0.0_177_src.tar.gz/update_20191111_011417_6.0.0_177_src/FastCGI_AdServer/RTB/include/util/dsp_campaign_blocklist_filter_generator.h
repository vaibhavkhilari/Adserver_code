#ifndef __DSP_CAMP_BLOCK_FILTER_GEN_H__
#define __DSP_CAMP_BLOCK_FILTER_GEN_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_rt_campaign_config.h"
#include "db_bloom_filter_generator.h"
#include "error.h"
#include "bloom_filter.h"


#define INITIAL_URL_BLOCK_LIST_SIZE 20

#define GET_DSP_CAMPAIGN_BLOCKLIST \
"select distinct campaign_id,domain_name from dsp_campaign_block_list where dp_id = ? and campaign_id in (0,?) and platform_id in (1, 2)"

#define SET_DSP_CAMPAIGN_BLOCKLIST \
"replace into dsp_campaign_blocklist_filter(dp_id,campaign_id,bloom_filter,blocked_domain_count) values(?,?,?,?)"

#define SET_CREATIVE_BLOOM \
"replace into creative_bloom ( creative_count,bloom,active_count,id )  values(?,?,?,?) "

void lowercase_string( char* str, int left, int right);

typedef struct {
	char domain_name[BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH + 1];
} dsp_blocklist_domain;

int get_dcbl_bloom_filter(db_connection_t *dbconn, long dp_id, long campaign_id, BLOOM** dsp_campaign_blocklist, size_t *ret_size);
int set_creative_bloom(db_connection_t *dbconn, BLOOM* creative_bloom, int active_count ,int id , size_t *ret_size, int dsplevel, const char *dbquery);
int set_dcbl_bloom_filter(db_connection_t *dbconn, long dp_id, long campaign_id, BLOOM* dsp_campaign_blocklist, size_t *ret_size);

#endif
