/*
	 PubMatic Inc. ("PubMatic") CONFIDENTIAL
	 Unpublished Copyright (c) 2006-2019 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current
PubMatic employees, managers or contractors who have executed
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source
code, which includes
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION,
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE,
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION
DOES NOT CONVEY OR IMPLY ANY RIGHTS
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY
DESCRIBE, IN WHOLE OR IN PART.
*/

#ifndef RTB_BID_UTIL_H
#define RTB_BID_UTIL_H

#define BLOCK_APP_IDS	"bapp"
#define MAX_BLOCK_APP_IDS 40
#define MAX_APP_ID_LEN	256
#define MAX_BLOCKED_APP_IDS_OUTPUT_JSON_LEN	10500
typedef struct bapp_info_ {
	/* For filtering */
	int app_id_count;
	char app_ids[MAX_BLOCK_APP_IDS][MAX_APP_ID_LEN + 1];

	/* For egress */
	char bapp_egress_json[MAX_BLOCKED_APP_IDS_OUTPUT_JSON_LEN + 1]; /* BidRequest.bapp : string array */
	int bapp_egress_json_len;
} bapp_info_t;

int parse_bapp_param(const char * const url_param,
					 bapp_info_t * const bapp_info);

int form_bapp_json_str(bapp_info_t * const bapp_info);

void init_bapp_info(bapp_info_t * const bapp_info);

#ifdef DEBUG
void print_bapp_info(const bapp_info_t * const bapp_info);
#endif /* DEBUG */

int validate_iab_category(const char * const iab_cat_str);

#endif /* RTB_BID_UTIL_H */
