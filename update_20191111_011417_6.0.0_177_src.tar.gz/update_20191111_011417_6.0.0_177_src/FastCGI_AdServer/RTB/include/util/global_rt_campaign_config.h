#ifndef __GLOBAL_RT_CAMPAIGN_CONFIG_H__
#define __GLOBAL_RT_CAMPAIGN_CONFIG_H__


#include "db_connection.h"
#include "db_rt_campaign_config.h"

#ifdef __cplusplus
extern "C" {
#endif


/* update_global_rt_campaign_config
 * --------------------------------
 * Wrapper around C++ method RtCampaignConfigTable::Get.
 */
int update_global_rt_campaign_config(
        const db_connection_t * const dbconn
);

/* get_global_rt_campaign_config
 * -----------------------------
 * Wrapper around C++ method RtCampaignConfigTable::Update.
 */
int get_global_rt_campaign_config(
        const rt_request_url_params_mask_t ** rt_request_url_params_mask,
        int * ret_list_len
);


#ifdef __cplusplus
}  // __cplusplus
#endif

#endif
