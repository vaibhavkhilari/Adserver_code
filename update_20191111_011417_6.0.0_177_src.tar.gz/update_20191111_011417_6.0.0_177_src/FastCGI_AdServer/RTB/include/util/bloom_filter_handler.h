/*
   PubMatic Inc. ("PubMatic") CONFIDENTIAL
   Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/

#ifndef __BLOOM_FILTER_HANDLER_H__
#define __BLOOM_FILTER_HANDLER_H__

#include <fcntl.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "property.h"
#include "config.h"
#include "error.h"
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_bloom_filter_generator.h"
#include "dsp_campaign_blocklist_filter_generator.h"
#include "bloom_filter.h"
#include "floor_rules_types.h"
#include "rt_types.h"


#define MAX_CREATIVE_BLOOM_LIMIT 3
#define IS_PUBLISHER_IAB_ENABLED \
  "select count(*) from acl_resource_feature where feature_id=116 and resource_type_id =1 and resource_id = ?"

db_env_t g_dbenv;
char *g_odbc_kad_dsn_name;
char *g_odbc_adf_dsn_name;
char *g_odbc_bc_dsn_name;
char *g_odbc_local_adf_dsn_name;
char *g_odbc_rawdata_dsn_name;
char *g_odbc_master_dsn_name;
char *g_odbc_daa_optout_dsn_name;
char *g_odbc_dsn_user_name;
char *g_odbc_dsn_user_password;
char *g_conf_bloom_dir;
int g_cur_arg_index; //Should be assigned some value before using it.
unsigned int g_max_bloom_thread_count;

/* Bloom generation thread parameter */
typedef struct bloom_thread_param {
	int ret_val;
	int argc;
	char **argv;
	unsigned long batch_size;
	unsigned long thread_id;
} bloom_thread_param_t;

/* Thread handler function */
void* bloom_generation_handler(void* thread_data);

#define MAX_GLOBAL_BLOOM_SIZE 3//TODO: move to common location
int check_publisher_iab_status(db_connection_t *dbconn,long pub_id,int* iab_enabled);
int set_bloom_configuration();
void free_bloom_configuration();
void get_log_file_name(char *log_file);
void init_query_metadata(get_query_meta_t *query_meta, const int oper_id);
int get_thread_configuration(const int oper_id, int argc, unsigned long *batch_size, int *thread_count);
void* generate_gss_blocklist_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_blocklist_landing_page_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_creative_id_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_publisher_site_floor_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_whitelist_landing_page_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_daa_deviceid_optout_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_dsp_blocklist_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_publisher_site_deal_whitelist_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_unique_creative_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_classfied_creative_bloom(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_dsp_whitelist_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_dsp_appurl_blocklist_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_dsp_appurl_whitelist_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_url_black_white_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_global_creative_id_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_publisher_campaign_level_blocklist(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);
void* generate_ads_txt_domain_list_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id);

#endif
