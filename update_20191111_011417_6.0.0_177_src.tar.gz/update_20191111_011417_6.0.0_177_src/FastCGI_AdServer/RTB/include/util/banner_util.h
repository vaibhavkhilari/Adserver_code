/*
	 PubMatic Inc. ("PubMatic") CONFIDENTIAL
	 Unpublished Copyright (c) 2006-2019 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current
PubMatic employees, managers or contractors who have executed
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source
code, which includes
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION,
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE,
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION
DOES NOT CONVEY OR IMPLY ANY RIGHTS
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY
DESCRIBE, IN WHOLE OR IN PART.
*/

#ifndef RTB_BANNER_UTIL_H
#define RTB_BANNER_UTIL_H

#include <stdint.h>

#define BLOCKED_BANNER_AD_TYPES	"btype"
#define BTYPE_VALUE_MAX 4
#define BTYPE_INPUT_PARAM_MAX_LEN 99
#define MAX_BTYPE_JSON_LEN	20
typedef struct btype_info_ {
	/* For filtering */
	uint64_t btype_values_map; /* 64-bit bitmap for received values in range 1-64 inclusive */

	/* For egress */
	char btype_egress_json[MAX_BTYPE_JSON_LEN + 1]; /* BidRequest.imp[i].banner.btype : interger array */
	int btype_egress_json_len;
} btype_info_t;

int parse_btype_param(const char * const url_param,
					  btype_info_t * const btype_info);

int form_btype_json_str(btype_info_t * const btype_info);

void init_btype_info(btype_info_t * const btype_info);

#ifdef DEBUG
void print_btype_info(const btype_info_t * const btype_info);
#endif /* DEBUG */

#endif /* RTB_BANNER_UTIL_H */
