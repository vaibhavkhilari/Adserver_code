/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __OPENRTB_COMMON_UTL__
#define __OPENRTB_COMMON_UTL__
#define RES_CONTENT_ENCODING_HEADER "content-encoding"
#define RES_DSP_STATUS_HEADER "X-dspstatus"

size_t openrtb_process_header( void* header_data,	size_t size, size_t nmemb, void* bid_response_params_ptr);
void json_append_escaped_string(char **buff, const char *name, const char *value, int add_separator, int max_len);
void json_append_value_string(char **buff, const char *name, int add_separator);
void json_append_fixed_value_string(char **buff, const char *name, int len, int add_separator);
void json_append_value_int(char **buff, const int value, int add_separator, int add_quote);
void json_append_string(char **buff, const char *name, const char *value, int add_separator);
void json_append_int(char **buff, const char *name, const int value, int add_separator, int add_quote);
void json_append_double(char **buff, const char *name, const double value, int add_separator, int add_quote);

uint8_t* try_compression( const char* post_data, int* p_post_data_len, unsigned int campaign_id, uint8_t debug  ) ;
int video_append_protocols(char **buff, const char *field_name, const char *value, int add_comma);

CURLcode set_response_compress_flags( CURL *easy_handle ) ;
void gdpr_object_creation_decision(ad_server_req_param_t* req_params,
		fte_additional_params_t *fte_additional_params,
		int dont_pass_iab_consent_obj,
		int *add_gdpr_ext,
		int *add_iab_gdpr_consent,
		int *add_eb_provider_list,
		char **eb_provider_list);

void openrtb_request_append_common_ext_object(char **post_data,
		rt_request_params_t *in_request_params,
		const ad_server_additional_params_t *additional_parameter,
		const publisher_site_ad_campaign_list_t *adcampaign,
		int *has_ext_params,
		const rt_request_url_params_mask_t* rt_request_url_params_mask1);

void openrtb_banner_append_common_btype_object(char ** const post_data_buf_ptr,
											   const btype_info_t * const btype_info);

void append_supply_chain_object(char **post_data,
		rt_request_params_t* in_request_params,
		int *has_ext_params);

void parse_common_response_bidExt_object(json_object *ext_object, rt_bid_response_params_t *bid_params);

void get_non_throttle_ad_size(publisher_site_ad_campaign_list_t *adcampaigns,
		const ad_server_req_param_t* const req_params,
		int *tmp_ad_width, int *tmp_ad_height);

typedef enum ipls {
        IPLS_IP2LOCATION = 1,
        IPLS_NEUSTAR,
        IPLS_MAXMIND,
        IPLS_DIGITAL_ELEMENT
}ipls_t;
#endif

