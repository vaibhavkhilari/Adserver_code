/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef DB_DYNAMIC_CAMP_SP_MARGIN_H__
#define DB_DYNAMIC_CAMP_SP_MARGIN_H__

#include "bloom_filter.h"

int db_get_campaign_dynamic_sp_margin(
		db_connection_t *dbconn,
		dsp_sp_margin_map_t **margin_map,
		long campaign_id,
		size_t *no_of_records);

int db_get_cmpg_sp_info(
		db_connection_t* dbconn,
		cmpg_sp_info_t** sp_info,
		int campaign_id);

int db_get_bid_boost_settings(
		db_connection_t *dbconn,
		bid_boost_settings_t *settings,
		long pub_id,
		int camp_id);

int db_get_integral_settings(db_connection_t *dbconn,
		integral_settings_t **settings,
		long pub_id,
		size_t *no_of_records);
#endif //DB_DYNAMIC_CAMP_SP_MARGIN_H__
