/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#ifndef DB_GET_BKT_BLOOM_FILTERS_H
#define DB_GET_BKT_BLOOM_FILTERS_H

#include "bkt_bloom_filter.h"

#define MAX_PER_BLOOM_DB_SIZE 600000 /* ~600 KB */
#define MAX_BLOOM_COUNT_FOR_CACHE 3 /* Maxmimum 3 blooms should be used, when we store it in memcache/INPC */
#define MAX_BLOOM_COUNT_FOR_GLOBAL 20 /* Maxmimum 20 blooms should be used, must be stored in global memory */
#define MAX_GIANT_BLOOM_COUNT_FOR_GLOBAL 100 /* only for Giant bloom (used in special case - strict mode), stored in global memory */

int db_get_bkt_bloom_filters(db_connection_t *dbconn,
		const char *db_query,
		BKT_BLOOM** out_bloom_filter,
		int *bloom_count,
		size_t *ret_size,
		char *update_time,
		int max_bloom_count);

int db_get_global_bkt_bloom_filter(db_connection_t *dbconn,
		const char *db_query,
		char *update_time,
		BKT_BLOOM_ARRAY **out_bloom_array,
		int max_bloom_count);

#endif /* DB_RT_NW_INFO_H */
