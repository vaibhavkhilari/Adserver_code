/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DB_BLOOMFILTER_GENERATOR_H__
#define __DB_BLOOMFILTER_GENERATOR_H__
#include "bloom_filter.h"
#include "bkt_bloom_filter.h"

#define BLOOM_CONFIG_FILE_NAME "/SCRIPTS/BLOOM_FILTER_GENERATION/conf/config.ini"
#define KAD_DSN_NAME "db.kad.dsn.name"
#define ADF_DSN_NAME "db.adf.dsn.name"
#define BC_DSN_NAME "db.bc.dsn.name"
#define CEASER_DSN_NAME "db.ceaser.dsn.name"
#define LOCAL_ADF_DSN_NAME "db.local.adf.dsn.name"
#define RAWDATA_DSN_NAME "db.rawdata.dsn.name"
#define MASTER_DSN_NAME "db.master.dsn.name"
#define DAA_OPTOUT_DSN_NAME "db.daaoptout.dsn.name"
#define ADS_TXT_DSN_NAME "db.ads.txt.dsn.name"
#define CRTV_INGESTOR_DSN_NAME "db.creativeingestor.dsn.name"
#define DSN_USERNAME "db.dsn.user.name"
#define DSN_PASSWORD "db.dsn.user.password"
#define MAX_BLOOM_THREAD_COUNT "max.thread.count"
#define BLOOM_DIR "/SCRIPTS/BLOOM_FILTER_GENERATION/"

/* Bloom filter types */
typedef enum {
	BLOOM_BLOCKLIST_LANDING_PAGE_FILTER = 1,
	BLOOM_CREATIVE_ID_FILTER = 2,
	BLOOM_ADVERTISER_DOMAIN_FILTER = 3,
	BLOOM_WHITELIST_LANDING_PAGE_FILTER = 4,
	BLOOM_DSP_BLOCKLIST_FILTER = 5,
	BLOOM_PUBLISHER_SITE_FLOOR_FILTER = 6,
	BLOOM_PUBLISHER_SITE_DEAL_WHITELIST_FILTER = 7,
	GSS_BLOCKLIST_FILTER = 8,
	BLOOM_UNIQ_CREATV = 9,
	BLOOM_DSP_WHITELIST_FILTER = 10,
	BLOOM_DSP_APPURL_BLOCKLIST_FILTER = 11,
	BLOOM_DSP_APPURL_WHITELIST_FILTER = 12,
	BLOOM_URL_BLACK_WHITE_FILTER = 13,
	BLOOM_DAA_DEVICEID_OPTOUT_FILTER = 14,
	BLOOM_GLOBAL_CREATIVE_ID_FILTER = 15,
	BLOOM_PUBLISHER_CAMPAIGN_DOMAIN_FILTER = 16,
	BLOOM_ADS_TXT_DOMAIN_LIST_FILTER = 17,
	BLOOM_PUB_GEO_DOMAIN_BLOCKLIST_FILTER = 18,
	BLOOM_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER = 19,
	BLOOM_BLOCKLIST_LANDING_PAGE_FILTER_NEW = 20,
	BLOOM_APP_ADS_TXT_FILTER = 21,
	PUBLISHER_SITE_DOMAIN_APP_WHITELIST = 22,
	BLOOM_CLASSIFIED_CREATIVES_SMALL = 23,
	BLOOM_CLASSIFIED_CREATIVES_GIANT = 24,

	/* Total bloom filter count, Add new bloom type above this line */
	TOTAL_BLOOM_COUNT
} bloom_filter_types_t;

#define MAX_FLOOR_BLOOM_ACTIVE_ENTITY_SIZE 3
//
#define MAX_BIND_COL 2

typedef enum select_type {
	SELECT_INT=1,
	SELECT_CHAR,
	SELECT_CHAR_DOMAIN,
	SELECT_UNSIGNED_BIG
}select_type_t;

typedef struct {
	unsigned int nSelect;
	select_type_t type[MAX_BIND_COL];
	unsigned int max_elt_size;
}get_query_meta_t;

#define GET_DB_GLOBAL_SUPPLY_SIDE_BLOCKLIST \
	"SELECT domain FROM global_supply_side_blocklist WHERE deleted = 0 AND platform_id IN (1,2) LIMIT 480000"

#define SET_DB_GLOBAL_SUPPLY_SIDE_BLOCKLIST \
	"REPLACE INTO global_supply_side_blocklist_filter(id, bloom_filter, blocklist_domain_count, bloom_version) VALUES (0,?,%d,1)"

#define GET_DB_GLOBAL_PUBLISHER_SITE_BLOCKLIST \
	"SELECT url FROM global_block_list where is_deleted = 0"

#define GET_DB_PUBLISHER_SITE_BLOCKLIST \
	"SELECT domain_name FROM publisher_site_block_list WHERE pub_id = %ld AND site_id = %ld"

#define GET_DB_PUBLISHER_SITE_BLOCKLIST_NEW \
	"SELECT domain_name FROM Ceaser.blocked_domain WHERE pub_id = %ld AND site_id = %ld"

#define SET_DB_PUBLISHER_SITE_BLOCKLIST \
	"REPLACE INTO publisher_site_landing_page_filter(pub_id,site_id,bloom_filter,blocked_domain_count,bloom_version) VALUES (%ld,%ld,?,%d,1)"

#define GET_DB_PUBLISHER_SITE_WHITELIST \
	"SELECT domain_name FROM publisher_site_white_list WHERE pub_id = %ld AND site_id = %ld AND deleted = 0"

#define SET_DB_PUBLISHER_SITE_WHITELIST \
	"REPLACE INTO publisher_site_white_list_filter(pub_id,site_id,bloom_filter,whitelist_domain_count,bloom_version) VALUES (%ld,%ld,?,%d,1)"

#define GET_CREATIVE_WHITE_LIST \
	"SELECT CONCAT(dsp_id, '_', creative_id) FROM rtb_dsp_creative_publisher_status_mapping WHERE publisher_id = %ld AND site_id = %ld AND status = 3"

#define SET_CREATIVE_WHITE_LIST \
	"REPLACE INTO publisher_site_creative_id_filter(pub_id,site_id,whitelisted_bloom_filter,whitelisted_creative_count,bloom_version) VALUES (%ld,%ld,?,%d,1)"

#define GET_CREATIVE_BLOCK_LIST \
	"SELECT CONCAT(dsp_id, '_', creative_id) FROM rtb_dsp_creative_publisher_status_mapping WHERE publisher_id = %ld AND site_id = %ld AND status = 4 ORDER BY blocking_reason_id DESC, create_timestamp DESC LIMIT 480000"

#define SET_CREATIVE_BLOCK_LIST \
	"REPLACE INTO publisher_site_creative_id_filter(pub_id,site_id,blacklisted_bloom_filter,blacklisted_creative_count,bloom_version) VALUES (%ld,%ld,?,%d,1)"

#define GET_CRC64_CREATIVE_WHITE_LIST \
	"SELECT (ucrid) FROM rtb_dsp_creative_publisher_status_mapping WHERE publisher_id = %ld AND site_id = %ld AND status = 3 AND ucrid IS NOT NULL"

#define SET_CRC64_CREATIVE_WHITE_LIST \
	"INSERT INTO publisher_site_creative_id_filter(pub_id, site_id, crc64_whitelisted_bloom_filter, crc64_whitelisted_creative_count, bloom_version) VALUES (%ld, %ld, ? ,%d, 1) ON DUPLICATE KEY UPDATE crc64_whitelisted_bloom_filter = VALUES(crc64_whitelisted_bloom_filter), crc64_whitelisted_creative_count = VALUES(crc64_whitelisted_creative_count)"

#define GET_CRC64_CREATIVE_BLOCK_LIST \
	"SELECT (ucrid) FROM rtb_dsp_creative_publisher_status_mapping WHERE publisher_id = %ld AND site_id = %ld AND status = 4 AND ucrid IS NOT NULL ORDER BY blocking_reason_id DESC, create_timestamp DESC LIMIT 480000"

#define SET_CRC64_CREATIVE_BLOCK_LIST \
	"INSERT INTO publisher_site_creative_id_filter(pub_id, site_id, crc64_blacklisted_bloom_filter, crc64_blacklisted_creative_count, bloom_version) VALUES (%ld, %ld, ? ,%d, 1) ON DUPLICATE KEY UPDATE crc64_blacklisted_bloom_filter = VALUES(crc64_blacklisted_bloom_filter), crc64_blacklisted_creative_count = VALUES(crc64_blacklisted_creative_count)"

#define GET_DB_DSP_CAMPAIGN_WHITELIST \
	"SELECT DISTINCT domain_name FROM dsp_campaign_white_list WHERE dp_id = %ld AND campaign_id = %ld AND platform_id IN (1, 2)"

#define SET_DB_DSP_CAMPAIGN_WHITELIST \
	"REPLACE INTO dsp_campaign_whitelist_filter(dp_id,campaign_id,bloom_filter,whitelisted_domain_count,bloom_version) VALUES (%ld,%ld,?,%d,1)"

#define GET_DB_DSP_CAMPAIGN_BLOCKLIST \
	"SELECT DISTINCT domain_name FROM dsp_campaign_block_list WHERE dp_id = %ld AND campaign_id = %ld AND platform_id IN (1, 2) AND pub_id = 0 AND site_id = 0 ORDER BY update_time DESC LIMIT 480000"

#define SET_DB_DSP_CAMPAIGN_BLOCKLIST \
	"REPLACE INTO dsp_campaign_blocklist_filter(dp_id,campaign_id,bloom_filter,blocked_domain_count,bloom_version) VALUES (%ld,%ld,?,%d,1)"

#define GET_DB_DSP_PUB_CAMPG_BLOCKLIST \
	"SELECT DISTINCT concat(site_id, '_', domain_name) FROM dsp_campaign_block_list WHERE dp_id = %ld AND campaign_id = %ld AND pub_id = %ld ORDER BY update_time DESC LIMIT 160000"

#define SET_DB_DSP_PUB_CAMPG_BLOCKLIST \
	"REPLACE INTO  publisher_campaign_block_list_filter(dp_id,campaign_id,pub_id,bloom_filter,blocked_domain_count,bloom_version) VALUES (%ld,%ld,%ld,?,%d,1)"

#define GET_DB_DSP_CAMPAIGN_APPURL_WHITELIST \
	"SELECT DISTINCT domain_name FROM dsp_campaign_white_list WHERE dp_id = %ld AND campaign_id = %ld AND platform_id IN (4, 5)"

#define SET_DB_DSP_CAMPAIGN_APPURL_WHITELIST \
	"REPLACE INTO dsp_campaign_appurl_whitelist_filter(dp_id,campaign_id,bloom_filter,whitelisted_appurl_count,bloom_version) VALUES (%ld,%ld,?,%d,1)"

#define GET_DB_DSP_CAMPAIGN_APPURL_BLOCKLIST \
	"SELECT DISTINCT domain_name FROM dsp_campaign_block_list WHERE dp_id = %ld AND campaign_id = %ld AND platform_id IN (4, 5) AND pub_id = 0 AND site_id = 0 ORDER BY update_time DESC LIMIT 480000"

#define SET_DB_DSP_CAMPAIGN_APPURL_BLOCKLIST \
	"REPLACE INTO dsp_campaign_appurl_blocklist_filter(dp_id,campaign_id,bloom_filter,blocked_appurl_count,bloom_version) VALUES (%ld,%ld,?,%d,1)"

#define GET_DB_PUBLISHER_SITE_DEAL_WHITELIST_FILTER_IAB_ENABLED \
	"SELECT DISTINCT deal_meta_id, domain from ((SELECT  u.deal_meta_id, AD.domain FROM advertiser_domain as AD inner join (select distinct deal_meta_id,  domain_id from advertiser_domain_category_mapping as ADCM inner join (  select distinct deal_meta_id, entity_id from deal_advertiser_attributes as DAA where  DAA.pub_id = %ld and DAA.site_id = %ld and DAA.whitelist_flag = 1 and DAA.active_entity = 3  and DAA.entity_id != 0  )t on t.entity_id = ADCM.advertiser_id)u on AD.id = u.domain_id) UNION (SELECT t.deal_meta_id, AD.domain FROM advertiser_domain as AD inner join (select distinct deal_meta_id, entity_id from deal_advertiser_attributes as DAA where  DAA.pub_id = %ld and DAA.site_id = %ld and DAA.whitelist_flag = 1 and DAA.active_entity = 4 and DAA.entity_id != 0)t  on t.entity_id = AD.id) UNION  (SELECT  u.deal_meta_id, AD.domain FROM advertiser_domain as AD inner join (select distinct deal_meta_id,  domain_id from advertiser_domain_category_mapping as ADCM inner join (  select distinct deal_meta_id, entity_id from deal_advertiser_attributes as DAA where  DAA.pub_id = %ld and DAA.site_id = %ld and DAA.whitelist_flag = 1 and DAA.active_entity = 14 and DAA.is_iab_category = 1 and DAA.entity_id != 0  )t on t.entity_id = ADCM.int_primary_iab_category_id OR t.entity_id = ADCM.int_sub1_iab_category_id OR t.entity_id = ADCM.int_sub2_iab_category_id OR t.entity_id = ADCM.int_sub2_primary_iab_category_id OR t.entity_id = ADCM.int_sub3_iab_category_id OR t.entity_id = ADCM.int_sub3_primary_iab_category_id)u on AD.id = u.domain_id)) DEAL_DOMAIN"

#define GET_DB_PUBLISHER_SITE_DEAL_WHITELIST_FILTER_IAB_DISABLED \
	"SELECT DISTINCT deal_meta_id, domain from ((SELECT  u.deal_meta_id, AD.domain FROM advertiser_domain as AD inner join (select distinct deal_meta_id,  domain_id from advertiser_domain_category_mapping as ADCM inner join (  select distinct deal_meta_id, entity_id from deal_advertiser_attributes as DAA where  DAA.pub_id = %ld and DAA.site_id = %ld and DAA.whitelist_flag = 1 and DAA.active_entity = 3  and DAA.entity_id != 0  )t on t.entity_id = ADCM.advertiser_id)u on AD.id = u.domain_id) UNION (SELECT t.deal_meta_id, AD.domain FROM advertiser_domain as AD inner join (select distinct deal_meta_id, entity_id from deal_advertiser_attributes as DAA where  DAA.pub_id = %ld and DAA.site_id = %ld and DAA.whitelist_flag = 1 and DAA.active_entity = 4 and DAA.entity_id != 0)t  on t.entity_id = AD.id) UNION  (SELECT  u.deal_meta_id, AD.domain FROM advertiser_domain as AD inner join (select distinct deal_meta_id,  domain_id from advertiser_domain_category_mapping as ADCM inner join (  select distinct deal_meta_id, entity_id from deal_advertiser_attributes as DAA where  DAA.pub_id = %ld and DAA.site_id = %ld and DAA.whitelist_flag = 1 and DAA.active_entity = 14 and DAA.is_iab_category = 0  and DAA.entity_id != 0  )t on t.entity_id = ADCM.category_id)u on AD.id = u.domain_id)) DEAL_DOMAIN"

#define SET_DB_PUBLISHER_SITE_DEAL_WHITELIST_FILTER \
	"REPLACE INTO publisher_site_deal_whitelist_bloom_new(pub_id, site_id, dw_bloom, dw_domain_count,iab_flag,bloom_version) VALUES (%ld,%ld,?,%d,%d,1)"

#define GET_DB_PUBLISHER_SITE_FOR_ADVERTISER_FLOOR_FILTER \
	"SELECT DISTINCT t.rule_meta_id, AD.domain domain_count FROM advertiser_domain as AD inner join (select distinct RE.rule_meta_id, RE.entity_id from (select distinct rule_meta_id from publisher_site_floor_rules  where  pub_id = %ld and site_id = %ld and status = 1 and start_time < now() and now() <= end_time and find_in_set('3', active_entities))  PSFR, rule_entity RE where RE.rule_meta_id = PSFR.rule_meta_id and RE.entity_type = 'ADVT')t  on t.entity_id = AD.advertiser_id;"

#define GET_DB_PUBLISHER_SITE_FOR_DOMAIN_FLOOR_FILTER \
	"SELECT DISTINCT t.rule_meta_id, AD.domain domain_count FROM advertiser_domain as AD inner join (select distinct RE.rule_meta_id, RE.entity_id from (select distinct rule_meta_id from publisher_site_floor_rules where pub_id = %ld and site_id = %ld and status = 1 and start_time < now() and now() <= end_time and find_in_set('4', active_entities)) PSFR, rule_entity RE where PSFR.rule_meta_id = RE.rule_meta_id and RE.entity_type = 'DOMN')t  on t.entity_id = AD.id;"

#define GET_DB_PUBLISHER_SITE_FOR_CATEGORY_FLOOR_FILTER_IAB_ENABLED \
	"SELECT DISTINCT u.rule_meta_id, AD.domain FROM advertiser_domain as AD, (select distinct t.rule_meta_id,advertiser_id, domain_id, entity_id from advertiser_domain_category_mapping as ADCM , (select distinct RE.rule_meta_id, RE.entity_id from ( select distinct rule_meta_id from publisher_site_floor_rules where pub_id = %ld and site_id = %ld and status = 1 and start_time < now() and now() <= end_time and find_in_set('14', active_entities))PSFR, rule_entity RE where PSFR.rule_meta_id = RE.rule_meta_id and RE.entity_type = 'ICAT') t where t.entity_id = ADCM.int_primary_iab_category_id OR t.entity_id = ADCM.int_sub1_iab_category_id OR t.entity_id = ADCM.int_sub2_iab_category_id OR t.entity_id = ADCM.int_sub2_primary_iab_category_id OR t.entity_id = ADCM.int_sub3_iab_category_id OR t.entity_id = ADCM.int_sub3_primary_iab_category_id) u where u.advertiser_id = AD.advertiser_id and AD.id = u.domain_id;"

#define GET_DB_PUBLISHER_SITE_FOR_CATEGORY_FLOOR_FILTER_IAB_DISABLED \
	"SELECT DISTINCT u.rule_meta_id, AD.domain FROM advertiser_domain as AD, (select distinct t.rule_meta_id,advertiser_id, domain_id, entity_id from advertiser_domain_category_mapping as ADCM , (select distinct RE.rule_meta_id, RE.entity_id from ( select distinct rule_meta_id from publisher_site_floor_rules where pub_id = %ld and site_id = %ld and status = 1 and start_time < now() and now() <= end_time and find_in_set('14', active_entities))PSFR, rule_entity RE where PSFR.rule_meta_id = RE.rule_meta_id and RE.entity_type = 'CATG') t where t.entity_id = ADCM.category_id) u where u.advertiser_id = AD.advertiser_id and AD.id = u.domain_id;"

#define SET_DB_PUBLISHER_SITE_FLOOR_FILTER \
	"REPLACE INTO publisher_site_floor_rule_bloom_filter(pub_id, site_id, active_entity, bloom, domain_count, iab_flag, bloom_version) VALUES (%ld,%ld,%ld,?,%d,%d,1)"

#define GET_DAA_DEVICE_OPTOUT_LIST \
	"SELECT device_id FROM daa_device_optout WHERE hashing_used = %ld AND opt_out=1"

#define SET_DAA_DEVICE_OPTOUT_LIST \
	"REPLACE INTO daa_device_optout_filter(hashing_used,device_type,deviceid_count,bloom_filter,bloom_version) VALUES (%ld,0,%d,?,1)"

#define GET_GLOBAL_CREATIVE_ID_BLOCKLIST \
	"SELECT DISTINCT (ucrid) FROM BrandShield.creative_attribute_classification where creative_attribute_id in (SELECT DISTINCT id FROM KomliAdServer.creative_attributes WHERE blocking_type = 1) AND ucrid IS NOT NULL ORDER BY create_timestamp DESC LIMIT 3200000"

#define SET_GLOBAL_CREATIVE_ID_BLOCKLIST \
	"INSERT INTO global_bloom_filter(bloom_type_id, bloom_type_name, bloom_filter, element_count, bloom_version) VALUES (0, 'MALWARE_CREATIVE_ID_BLOOM', ?, %d, 2) ON DUPLICATE KEY UPDATE bloom_filter = VALUES(bloom_filter), element_count = VALUES(element_count)"

#define GET_GLOBAL_ADS_TXT_PRESENT_DOMAIN_LIST \
	"SELECT tmp.tld_name FROM ((SELECT tld_name FROM ads_txt_crawler.ads_txt_compititors_crawled_data WHERE is_deleted = 0 AND platform IN (1,2)) UNION (SELECT tld_name FROM ads_txt_crawler.ads_txt_crawled_data WHERE is_deleted = 0 AND platform IN (1,2))) AS tmp LIMIT 3200000"

#define GET_PUB_ADS_TXT_RESELLER_DOMAIN_LIST \
	"SELECT tld_name FROM ads_txt_crawler.ads_txt_crawled_data WHERE seller_id = %ld AND seller_type = 'reseller' AND is_deleted = 0 AND platform IN (1,2) LIMIT 480000"

#define GET_PUB_ADS_TXT_DIRECT_DOMAIN_LIST \
	"SELECT tld_name FROM ads_txt_crawler.ads_txt_crawled_data WHERE seller_id = %ld AND seller_type = 'direct' AND is_deleted = 0 AND platform IN (1,2) LIMIT 480000"

#define SET_ADS_TXT_DOMAIN_LIST_FILTER \
	"INSERT INTO KomliAdServer.ads_txt_domain_list_filter (pub_id, type, domain_count, bloom_filter, bloom_version) VALUES(%ld,%ld,%d,?,2) ON DUPLICATE KEY UPDATE domain_count = VALUES(domain_count), bloom_filter = VALUES(bloom_filter)"

#define GET_PUB_GEO_DOMAIN_BLOCKLIST_FILTER \
	"SELECT DISTINCT geo_id, domain_name FROM pub_geo_domain_blocklist WHERE pub_id = %ld ORDER BY update_time DESC LIMIT 480000"

#define SET_PUB_GEO_DOMAIN_BLOCKLIST_FILTER \
	"INSERT INTO pub_geo_domain_blocklist_filter(pub_id, domain_count, bloom_filter, bloom_version) VALUES(%ld,%d,?,2) ON DUPLICATE KEY UPDATE domain_count = VALUES(domain_count), bloom_filter = VALUES(bloom_filter)"

#define GET_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER \
	"SELECT DISTINCT CONCAT(creative_attribute_id,'_',ucrid) FROM BrandShield.creative_attribute_classification WHERE creative_attribute_id IN (SELECT DISTINCT id FROM KomliAdServer.creative_attributes WHERE blocking_type = 2) AND ucrid IS NOT NULL ORDER BY create_timestamp DESC LIMIT 3200000"

#define SET_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER \
	"INSERT INTO AdFlex.global_bloom_filter(bloom_type_id,bloom_type_name, bloom_filter, element_count, bloom_version) VALUES (1,'PUB_PREFERRED_GLOBAL_CREATIVE_BLOOM', ?, %d, 2) ON DUPLICATE KEY UPDATE bloom_filter = VALUES(bloom_filter), element_count = VALUES(element_count)"

#define SET_UNIQUE_CREATIVE_ID_BLOOM \
	"INSERT INTO global_bloom_filter(bloom_type_id, bloom_type_name, bloom_filter, element_count, bloom_version) values (2, 'UNIQUE_CREATIVE_ID_BLOOM', ?, %d, 2) ON DUPLICATE KEY UPDATE bloom_filter = VALUES(bloom_filter), element_count= VALUES(element_count)"

#define SET_CLASSIFIED_CREATIVES_SMALL_BLOOM \
	"INSERT INTO global_bloom_filter(bloom_type_id, bloom_type_name, bloom_filter, element_count, bloom_version) values (3, 'CLASSIFIED_CREATIVE_SMALL_BLOOM', ?, %d, 2) ON DUPLICATE KEY UPDATE bloom_filter = VALUES(bloom_filter), element_count= VALUES(element_count)"

#define SET_CLASSIFIED_CREATIVES_GIANT_BLOOM \
	"INSERT INTO global_bloom_filter(bloom_type_id, bloom_type_name, bloom_filter, element_count, bloom_version) values (6, 'CLASSIFIED_CREATIVE_GIANT_BLOOM', ?, %d, 2) ON DUPLICATE KEY UPDATE bloom_filter = VALUES(bloom_filter), element_count= VALUES(element_count)"

#define GET_UNIQUE_CREATIVE_ID \
	"SELECT ucrid FROM CreativeIngestor.campaign_creative_info WHERE ucrid IS NOT NULL AND ucrid != 0 ORDER BY creation_time DESC LIMIT 3200000"

#define GET_CLASSIFIED_CREATIVES_SMALL \
	"SELECT DISTINCT(ucrid) FROM BrandShield.creative_attribute_classification WHERE creative_attribute_id != -1 ORDER BY update_timestamp DESC LIMIT 1600000"

#define GET_CLASSIFIED_CREATIVES_GIANT \
	"SELECT DISTINCT(ucrid) FROM BrandShield.creative_attribute_classification WHERE creative_attribute_id != -1 ORDER BY update_timestamp DESC LIMIT 16000000"

#define GET_GSS_DOMAIN_BLOCKLIST \
	"SELECT domain FROM KomliAdServer.global_supply_side_blocklist WHERE deleted = 0 AND platform_id IN (1,2) LIMIT 3200000"

#define GET_GSS_APP_BLOCKLIST \
	"SELECT domain FROM KomliAdServer.global_supply_side_blocklist WHERE deleted = 0 AND platform_id IN (4,5) LIMIT 3200000"

#define SET_GSS_DOMAIN_BLOCKLIST \
	"INSERT INTO AdFlex.global_bloom_filter(bloom_type_id, bloom_type_name, bloom_filter, element_count, bloom_version) VALUES (4,'GSS_DOMAIN_BLOCKLIST_BLOOM', ?, %d, 2) ON DUPLICATE KEY UPDATE bloom_filter = VALUES(bloom_filter), element_count = VALUES(element_count)"

#define SET_GSS_APP_BLOCKLIST \
	"INSERT INTO AdFlex.global_bloom_filter(bloom_type_id, bloom_type_name, bloom_filter, element_count, bloom_version) VALUES (5,'GSS_APP_BLOCKLIST_BLOOM', ?, %d, 2) ON DUPLICATE KEY UPDATE bloom_filter = VALUES(bloom_filter), element_count = VALUES(element_count)"

#define GET_GLOBAL_APP_ADS_TXT_PRESENT_LIST \
	"SELECT distinct app_bundle_id from  \
		(SELECT s.app_bundle_id \
		FROM	store_urls s INNER JOIN \
			ads_txt_crawled_data a \
			ON a.tld_name = s.developer_url AND a.platform = s.platform \
		WHERE s.developer_url IS NOT NULL \
			AND a.platform IN ( 4, 5 ) \
			AND a.is_deleted = 0 \
			AND s.is_excluded_for_crawling = 0 \
		UNION \
		SELECT s.app_bundle_id \
		FROM	store_urls s INNER JOIN \
			ads_txt_compititors_crawled_data ac \
			ON ac.tld_name = s.developer_url AND ac.platform = s.platform \
		WHERE s.developer_url IS NOT NULL \
			AND ac.platform IN ( 4, 5 ) \
			AND ac.is_deleted = 0 \
			AND s.is_excluded_for_crawling = 0) L \
	LIMIT 3200000"

#define GET_PUB_APP_ADS_TXT_RESELLER_LIST \
	"SELECT DISTINCT s.app_bundle_id \
	FROM	store_urls s INNER JOIN \
		ads_txt_crawled_data a \
		ON a.tld_name = s.developer_url AND a.platform = s.platform \
	WHERE s.developer_url IS NOT NULL \
		AND a.platform IN ( 4, 5 ) \
		AND a.seller_type = 'reseller' \
		AND a.seller_id = %ld \
		AND a.is_deleted = 0 \
		AND s.is_excluded_for_crawling = 0 \
	LIMIT 480000"

#define GET_PUB_APP_ADS_TXT_DIRECT_LIST \
	"SELECT DISTINCT s.app_bundle_id \
	FROM	store_urls s INNER JOIN \
		ads_txt_crawled_data a \
		ON a.tld_name = s.developer_url AND a.platform = s.platform \
	WHERE s.developer_url IS NOT NULL \
		AND a.platform IN ( 4, 5 ) \
		AND a.seller_type = 'direct' \
		AND a.seller_id = %ld \
		AND a.is_deleted = 0 \
		AND s.is_excluded_for_crawling = 0 \
	LIMIT 480000"

#define SET_APP_ADS_TXT_BLOOM_FILTER \
	"INSERT INTO KomliAdServer.app_ads_txt_bloom_filter (pub_id, type, app_count, bloom_filter, bloom_version) VALUES(%ld,%ld,%d,?,2) ON DUPLICATE KEY UPDATE app_count = VALUES(app_count), bloom_filter = VALUES(bloom_filter)"

typedef enum ads_txt_blm_type_t{
	GLOBAL_ADS_TXT_PRESENT_DOMAIN_LIST = 0,
	PUB_ADS_TXT_RESELLER_DOMAIN_LIST,
	PUB_ADS_TXT_DIRECT_DOMAIN_LIST
}ads_txt_blm_type;

int get_lpf_bloom_filter(db_connection_t *dbconn,
		long pub_id,
		long site_id,
		BLOOM** publisher_site_landing_page_domain_name,
		size_t *ret_size);

int set_lpf_bloom_filter(db_connection_t *dbconn,
		long pub_id,
		long site_id,
		BLOOM* publisher_site_landing_page_domain_name,
		size_t *ret_size);
		
int get_adf_bloom_filter(db_connection_t *dbconn,
		long pub_id,
		long site_id,
		int is_pub_iab_enabled, 
		BLOOM** publisher_site_advertiser_domain_name,
		size_t *ret_size);

int set_adf_bloom_filter(db_connection_t *dbconn,
		long pub_id,
		long site_id,
                int is_pub_iab_enabled, 
		BLOOM* publisher_site_advertiser_domain_name,
		size_t *ret_size);

int get_psff_bloom(db_connection_t *dbconn,
                long pub_id,
                long site_id,
		int active_entity,
		int is_pub_iab_enabled,
		BLOOM** publisher_site_floor_rule,
		size_t *ret_size);
		
int set_psff_for_bloom(db_connection_t *dbconn,
		long pub_id,
		long site_id,
		int active_entity,
                int is_pub_iab_enabled,
		BLOOM* publisher_site_floor_rule,
		size_t *ret_size);

int get_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		get_query_meta_t* query_meta,
		BLOOM** bloom_filter_list_t,
		size_t *ret_size,
		int *element_count);

int set_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		BLOOM** bloom_filter_list,
		const long pub_id,
		const long site_id,
		const int bloom_type,
		size_t *ret_size,
		const int element_count);

int get_bkt_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		get_query_meta_t* query_meta,
		BKT_BLOOM** bkt_bloom_filter_list_t,
		size_t *ret_size,
		int *element_count);

int set_bkt_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		BKT_BLOOM** bkt_bloom_filter_list,
		size_t *ret_size,
		const int element_count);

#endif
