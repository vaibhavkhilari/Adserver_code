/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __CAMPAIGN_DATA_PROVIDER_SETTINGS_H__

#define __CAMPAIGN_DATA_PROVIDER_SETTINGS_H__

#include "dp_data_passing_constants.h"

/* Campaign Data-Provider settings regaring what all segment IDs for given segment type need to be send */
typedef struct campaign_data_provider_segment_type_settings
{
	/*Campaign ID. */
	long campaign_id;
	/* Id of the Data Provider. */
	int data_provider_id;
	/* Segment type ID. Ex. Contextual, Brand Safety etc. */
	int segment_type_id;
	/* Count of entries in the above array. If this count is "zero" then we should pass all available segment ids to DSPs */
	int segment_ids_count;
	/* This array will stores Segment Ids that need to be passed to DSPs for given Segment type. */
	int segment_ids[0];
} campaign_data_provider_segment_type_settings_t;

/* Data-Provider level settings. */
typedef struct campaign_data_provider_settings
{
	/*Segment Type Settings for given Data-Provider. */
	campaign_data_provider_segment_type_settings_t *cmpg_dp_seg_stype_settinngs[MAX_DATA_PROVIDER_SEGMENT_TYPE];
	/* Count of Segment Type settings. */
	int cmpg_dp_seg_stype_settinngs_count;
} campaign_data_provider_settings_t;

/* Campaign level settings. */
typedef struct campaign_level_dp_settings
{
	/* Data-Provider level settings. */
	campaign_data_provider_settings_t *dp_settings[MAX_DATA_PROVIDERS];
	/* Count of Data-Provider level settings. */
	int dp_settings_count;
} campaign_level_dp_settings_t;

#endif //__CAMPAIGN_DATA_PROVIDER_SETTINGS_H__
