/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DP_DATA_PASSING_UTIL_H__

#define __DP_DATA_PASSING_UTIL_H__

#include "campaign_data_provider_settings.h"
#include "campaign_data_provider_data.h"
#include "dp_data_passing_generic.h"
#include "rt_types.h"


void dump_cmpg_dp_seg_type_settings(campaign_data_provider_segment_type_settings_t *seg_type_setting);
void cleanup_all_campg_level_dp_settings(campaign_data_provider_data_ops_params_t cmpg_data_provider_data_params[MAX_REALTIME_CAMPAIGNS],
										int cmpg_dp_data_params_idx,
										rt_request_params_t* rt_request_params);
void init_data_provider_data(data_provider_data_t *dp_data);
struct memcache_cmpg_dp_data_passing_settings;
int get_seg_type_settings_from_cached_dp_setting(long campaign_id,
				                                 int data_provider_id,
	                                             campaign_data_provider_settings_t *dp_settings,
												 struct memcache_cmpg_dp_data_passing_settings *cmpg_dp_settings);

#endif //__DP_DATA_PASSING_UTIL_H___
