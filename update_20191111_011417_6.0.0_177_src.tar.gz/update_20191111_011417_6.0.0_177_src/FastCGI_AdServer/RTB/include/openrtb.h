/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __OPENRTB__
#define __OPENRTB__

#include <rt_types.h>
#include <rtb_util.h>
#include "ad_server_constants.h"
#include "openrtb_common_util.h"

//OPENRTB response params

#define ID "id"
#define SEATBID_ARR "seatbid"
#define BID_ARR "bid"
#define BID_DOT_ID "id"
#define IMP_ID "impid"
#define PRICE "price"
#define CADID "adid"
#define NURL "nurl"
#define ADMARKUP "adm"
#define ADV_DOMAIN_ARR "adomain"
#define O_IURL "iurl"
#define CID "cid"
#define CRID "crid"
#define ATTR_ARR "attr"
#define CSEAT "seat"
#define BID_ID "bidid"
#define CUR "cur"
#define EXT "ext"
#define DEALID "dealid"
#define BID_WIDTH "w"
#define BID_HEIGHT "h"
#define NATIVE "native"
#define DEAL_NO_BID_REASON "dnbr"

#define CUSTOM_DATA "customdata"
#define BID_EXT_OBJ "ext"

#define COMPRESSION_GZIP "gzip"

//for click tracking
#define OPENRTB_CLICKTRACK_KEYWORD "${AUCTION_CLICKTRACK_URL}"
#define OPENRTB_SECOND_PRICE_MACRO "${AUCTION_PRICE}"

//runtime config reload debug flags
#define DEBUG_RTB 1
#define DEBUG_OPENRTB 2
#define DEBUG_OPENRTB_MOBILE 3

#if defined DEBUG || defined OPENRTBDEBUG
        #define OPENRTB_DEBUG(format, ...) llog_write(L_DEBUG, "\nOPENRTB: " format " -> %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__);
#else
        #define OPENRTB_DEBUG(format, ...)
#endif

#define OPENRTB_ERROR(format, ...) llog_write(L_DEBUG, "\nERROR OPENRTB: " format " :%s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__);

#define DEFAULT_IMP_ID "1"

#define NEED_TO_PASS_GRANULAR_SITE_ID(rt_request_url_params_mask1,additional_parameter) ({ \
		( ( rt_request_url_params_mask1->feature_flag_bitmap & (1 << CS_BIT_POS_RTB_PASS_GRANULAR_SITE_ID) ) && \
			( additional_parameter->pubsite_default_settings.feature_flag_bitmap & (1 << PS_BIT_POS_RTB_PASS_GRANULAR_SITE_ID) ) && \
			( additional_parameter->granular_site_id[0] != '\0' ) ); \
		})

#define NEED_TO_CHANGE_NATIVE_IMAGE_TYPE(rt_request_url_params_mask1,additional_parameter) ({ \
		( ( rt_request_url_params_mask1->feature_flag_bitmap & (1 << CS_BIT_POS_RTB_CHANGE_NATIVE_IMAGE_TYPE) ) && \
			( additional_parameter->pubsite_default_settings.feature_flag_bitmap & (1 << PS_BIT_CHANGE_NATIVE_IMAGE_TYPE) )); \
		})

		typedef struct buffer_tracker
		{
			uint8_t *buffer_list[MAX_REALTIME_REQUESTS] ;
			size_t numBuffers ;
		} buffer_tracker_t ;

//Function signatures

		uint8_t registerBuffer( buffer_tracker_t *p_buffer_tracker, uint8_t *buf ) ;

		void clearBuffers( buffer_tracker_t *p_buffer_tracker ) ;

void  parse_response_openrtb(void *ptr_rt_response_params,
                            int *response_alloc_count,
                            int index,
                            void *additional_parameter,
                            int *response_count,
			    void *rt_request_params_x);

void  parse_response_openrtb2_3(void *ptr_rt_response_params,
                            int *response_alloc_count,
                            int index,
                            void *additional_parameter,
                            int *response_count,
			    void *rt_request_params_x);

//creates realtime request--> called per realtime campaign
int openrtb_bidding_create_request(void *in_request_params_x,
				   int request_count,
				   void *out_response_params_x,
				   long campaign_id,
				   void *site_x,
				   cache_handle_t *cache_handle,
				   db_connection_t *dbconn,
				   const void * rt_request_url_params_mask1_x,
				   void *additional_parameter_x,
				   void *cmpg_dp_params_x,
				   char *request_url_with_mandatory_params,
				   char* post_data,
				   char* campaign_cookie,
				   void *adcampaign_x,
				   void *header_list_x,
				   int *size_header_list,
				   void* adcampaign_list_x,
				   const int nelements,
				   const int current_index,
				   void *p_buffer_tracker_x
				   );

int openrtb_bidding_create_request_generic(void *in_request_params_x,
				      int request_count,
				      void *out_response_params_x,
				      long campaign_id,
				      void *site_x,
				      cache_handle_t *cache_handle,
				      db_connection_t *dbconn,
				      const void * rt_request_url_params_mask1_x,
				      void *additional_parameter_x,
				      void *cmpg_dp_params_x,
				      char *request_url_with_mandatory_params,
				      char* post_data,
				      char* campaign_cookie,
				      void *adcampaign_x,
				      void *header_list_x,
				      int *size_header_list,
				      void* adcampaign_list_x,
				      int nelements,
				      int current_index,
				      void *p_buffer_tracker_x
				      );

int openrtb_bidding_create_request2_5(void *in_request_params_x,
				      int request_count,
				      void *out_response_params_x,
				      long campaign_id,
				      void *site_x,
				      cache_handle_t *cache_handle,
				      db_connection_t *dbconn,
				      const void * rt_request_url_params_mask1_x,
				      void *additional_parameter_x,
				      void *cmpg_dp_params_x,
				      char *request_url_with_mandatory_params,
				      char* post_data,
				      char* campaign_cookie,
				      void *adcampaign_x,
				      void *header_list_x,
				      int *size_header_list,
				      void* adcampaign_list_x,
				      int nelements,
				      int current_index,
				      void *p_buffer_tracker_x
				      );


size_t openrtb_process_header(
                        void* header_data,
                        size_t size,
                        size_t nmemb, 
                        void* bid_response_params_ptr
                	);

void apply_openrtb_macro_substitution(selected_campaign_attribute_t* selected_camp,
                                      ad_server_additional_params_t *additional_params,
                                      fte_additional_params_t *fte_additional_params);

extern void lowercase_string(char* str, int left, int right);

char* deserialize_int(unsigned char* buf, int* n);

void add_ip_in_openrtb_device(
	char** post_data,
	rt_request_params_t *in_request_params,
	bool ip_masking_enabled,
	int has_device_params);

void add_ip_in_openrtb2_3device(
        char **post_data,
        rt_request_params_t*  in_request_params,
		int is_coppa_compliant,
		bool ip_masking_enabled,
        int has_device_params);

void add_ip_in_json(char** post_data, int is_ipv4, char* ip, int add_comma);

void add_site_pagedomain_in_json(char** post_data, const publisher_site_ad_campaign_list_t *adcampaign,
		    const publisher_site_default_settings_t *pubsite_default_settings, const char* anonymized_pageurl,
				    const ad_server_req_param_t *in_server_req_params);
void create_source_object_v23(char** post_data,
		rt_request_params_t* in_request_params,
		int protocol);
void replace_native_img_icon_asset_type(char *native_obj);
extern void add_publisherobj_injson(char **post_data,
		const int send_origin_pubid_enabled,
		const ad_server_req_param_t* req_params,
		const rt_request_params_t*  in_request_params,	
		const rt_request_url_params_mask_t* rt_request_url_params_mask,
		int is_prefix_comma);

/* OpenRTB 2.X Add Consumer Identifier in "user.ext" */
int create_2_x_consumer_identifier_ext(
        char **post_data,
        const ad_server_req_param_t* req_params,
        const publisher_site_ad_campaign_list_t *adcampaign,
        int *has_ext_params);

/* OpenRTB 3.0 Add Consumer Identifier in "user.eids" array */
int create_3_x_consumer_identifier_object(
        char **post_data,
        const ad_server_req_param_t* req_params,
        const publisher_site_ad_campaign_list_t *adcampaign,
        int *has_user_params);

int create_geo_object_pass_asis(char **post_data,
								int *is_pa_geo,
                                int ortb_version,       //ORTB Version - few fields will be droped for lower versions
                                const geo_obj_info_t *geo,    //Request geo fields
                                const geo_data_t *gd,         //IP inferred geo fields
								int is_coppa_compliant,
                                bool lat_lon_masking_enabled,
                                int has_parent_params);

void openrtb_request_append_bapp_object(char ** const post_data_buf_ptr,
										const bapp_info_t * const bapp_info);
#endif

