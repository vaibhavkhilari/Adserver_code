/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>

#include "cache_conf_intf.h"
#include "dp_properties.h"
#include "db_connection.h"
#include "error.h"
#include "dp_data_passing_generic.h"
#include "proximic_data_passing.h"

int g_datacenter_id = 2;

db_env_t g_dbenv;
char *g_odbc_dsn_name = "KomliAdServer";
char *g_odbc_dsn_adflex_name = "AdFlex_kartik";
char *g_odbc_dsn_user_name = "kdbuser";
char *g_odbc_dsn_user_password = "KdBuSeR12!";
char *g_cache_servers = "/home/http/memcached.socket";

int dp_debug(dp_response_params_t *dp_resp_params, int max_dp_count)
{
	int i =0;

	if( dp_resp_params == NULL )
	{
		llog_write(L_DEBUG, "ERROR!!! Invalid arguments %s:%d\n",__FILE__, __LINE__);
		return -1;
	}

	for( i = 0 ; i < max_dp_count; i++ )
	{
	//	llog_write(L_DEBUG, "Inside main : The response for base url %s is %s\n", dp_resp_params[i].url_to_be_analysed, dp_resp_params[i].response);

	}

	return ADS_ERROR_SUCCESS;
}

int get_fte_cache_timeout() {
    return ((rand() % 100));
}

int main(void)
{
	int retval = 0;
	//char *url = "http://www.jsonlint.com";
	char *url = "http://www.espnstar.com/football";

	dp_config_t dp_config[MAX_DP_COUNT];
	dp_request_params_t dp_req_params;
	dp_response_params_t dp_resp_params[MAX_DP_COUNT];
	db_connection_t db_conn;
	db_connection_t db_conn_ad_flex;
	ad_server_req_param_t in_req_params;
	cache_handle_t cache_handle;
	dp_data_passing_params_t params;
	data_provider_data_t *dp_data;
	int i = 0, j = 0;
	campaign_data_provider_settings_t *dp_settings = NULL;

	/*
	 * Set ad request parameters.
	 */
	in_req_params.inIframe = 0;
	in_req_params.page_url = url;

	curl_global_init(CURL_GLOBAL_ALL);	
	
	retval = init_db_env(&g_dbenv);
	if (retval != 0) {
		llog_write(L_DEBUG, "DB ENV initilization failed\n");
		return ADS_ERROR_INTERNAL;
	}

	retval = get_db_connection(&db_conn, &g_dbenv, g_odbc_dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (retval != 0) {

		/* If opening the connection with the database failed, then return */
		llog_write(L_DEBUG, "Connection to DB failed, dsn_name:%s %s:%d\n", g_odbc_dsn_name, __FILE__,__LINE__);
		return 0;
	}

	retval = get_db_connection(&db_conn_ad_flex, &g_dbenv, g_odbc_dsn_adflex_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (retval != 0) {

		/* If opening the connection with the database failed, then return */
		llog_write(L_DEBUG, "Connection to DB failed, dsn_name:%s %s:%d\n", g_odbc_dsn_adflex_name, __FILE__,__LINE__);
		return 0;
	}

	/* Initilize the memcache */
	retval = init_cache(&cache_handle, g_cache_servers);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "\nERROR: Fail to initilize the cache : '%s', %s:%d\n", g_cache_servers, __FILE__, __LINE__);
		return 0;
	}

///////////////////////////////////////////////////////////////////////
	params.dp_settings = (campaign_data_provider_settings_t *) malloc (sizeof(campaign_data_provider_settings_t));
	dp_settings = params.dp_settings;
	params.campaign_id = 1442;
	params.cache = &cache_handle;
	params.dbconn = &db_conn_ad_flex;
	params.dp_data = &dp_data;

    for (i = 0, j = 0; i < MAX_DATA_PROVIDER_SEGMENT_TYPE; i++)
    {
        dp_settings->cmpg_dp_seg_stype_settinngs[j] = NULL;
        llog_write(L_DEBUG, "%s(): Ret = %d\n", __FUNCTION__, retval);
        if (dp_settings->cmpg_dp_seg_stype_settinngs[j] != NULL)
        {
            j++;
        }
    }
    dp_settings->cmpg_dp_seg_stype_settinngs_count = j;

///////////////////////////////////////////////////////////////////////

	retval = dp_process_request_init(dp_config, &dp_req_params, MAX_DP_COUNT);
	if( retval != ADS_ERROR_SUCCESS )
	{
		llog_write(L_DEBUG, "ERROR dp_process_request_init failed %s:%d\n" ,__FILE__ ,__LINE__);
		return -1;
	}

	retval = dp_process_response_init(dp_resp_params, MAX_DP_COUNT);
	if( retval != ADS_ERROR_SUCCESS )
	{
		llog_write(L_DEBUG, "ERROR dp_process_response_init failed %s:%d\n" ,__FILE__ ,__LINE__);
		return -1;
	}
	
	retval = dp_init_env(dp_config, &dp_req_params, &db_conn, MAX_DP_COUNT);
	if( retval != ADS_ERROR_SUCCESS )
	{
		llog_write(L_DEBUG, "ERROR dp_init_env failed %s:%d\n", __FILE__, __LINE__);
		return -1;
	}

	retval = dp_get_data(dp_config, &dp_req_params, dp_resp_params, &in_req_params, MAX_DP_COUNT, NULL, NULL);
	if( retval != ADS_ERROR_SUCCESS )
	{
		llog_write(L_DEBUG, "ERROR dp_get_data failed %s:%d\n",__FILE__, __LINE__);
		return -1;
	}

	retval = dp_debug(dp_resp_params, MAX_DP_COUNT);
	if(retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "ERROR dp_get_data failed %s:%d\n",__FILE__, __LINE__);
		return -1;
	}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#if 1
	retval = dp_generic_data_creator(&params, dp_resp_params);
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	retval = dp_process_response_release(dp_resp_params, MAX_DP_COUNT);
	if( retval != ADS_ERROR_SUCCESS )
    {
        llog_write(L_DEBUG, "ERROR dp_process_response_init failed %s:%d\n",__FILE__, __LINE__);
        return -1;
    }


	retval = dp_rel_env(dp_config, &dp_req_params, MAX_DP_COUNT);
	if( retval != ADS_ERROR_SUCCESS )
	{
		llog_write(L_DEBUG, "ERROR dp_init_env failed %s:%d\n", __FILE__, __LINE__);
		return -1;
	}

	release_db_connection(&db_conn);
	release_db_connection(&db_conn_ad_flex);
	
	curl_global_cleanup();

	llog_write(L_DEBUG, "Hello world\n");
	return 0;
}
