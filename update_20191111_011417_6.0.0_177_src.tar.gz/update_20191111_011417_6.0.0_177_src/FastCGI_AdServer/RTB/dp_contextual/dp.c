/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <unistd.h>
#include <curl/curl.h>
#include <curl/multi.h>

#include "dp_properties.h"
#include "dp_error.h"
#include "proximic.h"
#include "time_util.h"
#include "error.h"
#include "curlstat_util.h"

//extern int g_rtb_enable_persistent_connections;
int g_dp_ms_timeout;
extern int g_curlstat_enabled_flag;
extern int g_allow_config_reload_flag;
/*
 * Global array initialising 
 * function pointers for each DP
 */
static dp_generic_t g_dp_generic[MAX_DP_COUNT] = {  
	{PROXIMIC_ID, &g_proximic_ops}}; 

// Read description in dp_properties.h

/* niki : this multi handle not used anymore
int dp_init_curlm_handle(dp_curl_multi_handle_t *dp_curlm_handle, int pool_size)
{
	CURLMcode rc;

	if( dp_curlm_handle == NULL || pool_size < 0 ) {
		llog_write(L_DEBUG, "ERROR dp_curl_multi_handle is NULL  %s:%d\n", __FILE__,__LINE__);
		return DP_ERROR_INVALID_ARGS; 
	}

	dp_curlm_handle->curlm_handle = curl_multi_init();
	if(dp_curlm_handle->curlm_handle == NULL) {
		llog_write(L_DEBUG,"ERROR curl_multi_init failed : %s:%d\n",__FILE__,__LINE__);
		return DP_ERROR_INTERNAL;
	}

	//Set pool_size : number of max easy connection to be added DEFAULT 10
	rc = curl_multi_setopt(dp_curlm_handle->curlm_handle, CURLMOPT_MAXCONNECTS, pool_size);
	if(rc != CURLM_OK) {
		llog_write(L_DEBUG,"ERROR curl_multi_setopt failed : %s  %s:%d\n", curl_multi_strerror(rc),__FILE__,__LINE__);
		return DP_ERROR_INTERNAL;
	}

	llog_write(L_DEBUG,"START_STATUS:DP multi connections are enabled and connection pool size is = %d %s:%d\n",pool_size,__FILE__,__LINE__);
	return DP_ERROR_SUCCESS;
}*/

// niki :: commented cos multi clean up not required
/*int dp_clean_curlm_handle(dp_curl_multi_handle_t *dp_curlm_handle)
{
	CURLMcode rc;
	if( dp_curlm_handle == NULL || dp_curlm_handle->curlm_handle == NULL ) {
		return DP_ERROR_SUCCESS;
	}

	rc = curl_multi_cleanup(dp_curlm_handle->curlm_handle);
	if(rc != CURLM_OK) {
		llog_write(L_DEBUG,"ERROR curl_multi_cleanup failed : %s  %s:%d\n", curl_multi_strerror(rc),__FILE__,__LINE__);
		return DP_ERROR_INTERNAL;
	}
	dp_curlm_handle->curlm_handle = NULL;
	return DP_ERROR_SUCCESS;
}*/

int dp_init_curl_cache_handles( dp_curl_easy_handle_t *dp_easy_cache_handle, int max_dp_count, int *failed_count)  
{
	int i = 0;
	int retval = DP_ERROR_SUCCESS;

	if( dp_easy_cache_handle == NULL || max_dp_count < 1 || failed_count == NULL ) {
		llog_write(L_DEBUG, "ERROR dp_easy_cache_handle/failed_count is NULL %s:%d\n", __FILE__, __LINE__);
		return DP_ERROR_SUCCESS;
	}

	*failed_count = 0;

	for( i = 0; i < max_dp_count ; i++)
	{
		if( dp_easy_cache_handle[i].curle_handle == NULL ) {

			dp_easy_cache_handle[i].curle_handle = curl_easy_init();
			if(dp_easy_cache_handle[i].curle_handle == NULL) {
				(*failed_count)++; //TODO Not using currently, Only for reference
				llog_write(L_DEBUG,"ERROR curl_easy_init() num of handles failed : %d %s:%d\n", 
						*failed_count, __FILE__,__LINE__);
				retval = DP_ERROR_INTERNAL;
			}
		}
	}

	return retval;
}

int dp_clean_curl_cache_handles( dp_curl_easy_handle_t *dp_easy_cache_handle, int max_dp_count)
{
	int retval = DP_ERROR_SUCCESS;
	int i = 0;

	if( dp_easy_cache_handle == NULL ) {
		return retval;
	}

	for( i = 0; i < max_dp_count; i++)
	{
		if(dp_easy_cache_handle[i].curle_handle != NULL) {
			curl_easy_cleanup(dp_easy_cache_handle[i].curle_handle);
			dp_easy_cache_handle[i].curle_handle = NULL;
		}
	}
	return retval;
}


int dp_process_request_init(dp_config_t *dp_config, dp_request_params_t *dp_req_params, int max_dp_count)
{
	int i = 0;

	if( dp_req_params == NULL || dp_config == NULL ) {
		llog_write(L_DEBUG, "ERROR dp_process_init failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	// Set ops pointers and id in config 
	for( i = 0 ; i < max_dp_count ; i++ )
	{
		dp_config[i].dp_spec_config = NULL;
		dp_config[i].dp_spec_config_size = 0;
		dp_config[i].dp_generic = &(g_dp_generic[i]);
	}	

	//Set dp_config in request params
	//Set curlm_handle and curle_handle to NULL;
	for( i = 0; i < max_dp_count; i++ )
	{
		dp_req_params->dp_config[i] = &(dp_config[i]);		
		dp_req_params->dp_curle_handle[i].curle_handle = NULL;
	}

	dp_req_params->dp_curl_easy_pool_initialized = 0;
	dp_req_params->db_conn = NULL;

	return ADS_ERROR_SUCCESS;
}

/*
 * Function to clean dp_cont_bp_data_t object.
 */
void dp_cont_bp_data_release(dp_cont_bp_data_t *dp_cont_bp_data) {
	/*
	 * Check validity of function paramaters.
	 */
	if (dp_cont_bp_data == NULL) {
		llog_write(L_DEBUG, "ERROR : Arguments NULL %s:%s:%d\n", __FILE__, __FUNCTION__, __LINE__ );
	}

	if (dp_cont_bp_data->dp_contextual_data != NULL) {
		free(dp_cont_bp_data->dp_contextual_data);
		dp_cont_bp_data->dp_contextual_data = NULL;
	}
}

/*
 * Function to init dp_cont_bp_data_t object.
 */
int dp_cont_bp_data_init(dp_cont_bp_data_t *dp_cont_bp_data) {
	/*
	 * Check validity of function paramaters.
	 */
	if (dp_cont_bp_data == NULL) {
		llog_write(L_DEBUG, "ERROR : Arguments NULL %s:%s:%d\n", __FILE__, __FUNCTION__, __LINE__ );
		return DP_ERROR_INVALID_ARGS;
	}

	/*
	 * Now init the values.
	 */
	dp_cont_bp_data->dpid = 0;
	dp_cont_bp_data->page_scope[0] = '\0';
	dp_cont_bp_data->page_type[0] = '\0';
	dp_cont_bp_data->cont_segment_count = 0;
	dp_cont_bp_data->dp_contextual_data = NULL;

	/*
	 * Init brandsafety contents flag;
	 */
	dp_cont_bp_data->dp_bp_safety_data.rating.set_flag = 0;
	dp_cont_bp_data->dp_bp_safety_data.safetylevel.set_flag = 0;
	dp_cont_bp_data->dp_bp_safety_data.nonstandardcontent.set_flag = 0;

	return DP_ERROR_SUCCESS;
}

/*
 * Function to add segment id and weight in strucure.
 */
int dp_cont_id_wt_add(dp_cont_bp_data_t *dp_cont_bp_data, int wt, int id) {
	/*
	 * Local variables.
	 */
	size_t alloc_size;
	dp_id_wt_data_t *temp_dp_contextual_data = NULL;
	/*
	 * Check validity of function paramaters.
	 */
	if (dp_cont_bp_data == NULL) {
		llog_write(L_DEBUG, "ERROR : Arguments NULL %s:%s:%d\n", __FILE__, __FUNCTION__, __LINE__ );
		return DP_ERROR_INVALID_ARGS;
	}

	/*
	 * Check if need for realloc.
	 */
	if (((dp_cont_bp_data->cont_segment_count % DP_SEGCOUNT_ALLOC_SIZE) == 0) || (dp_cont_bp_data->dp_contextual_data == NULL)) {
		alloc_size = (dp_cont_bp_data->cont_segment_count + DP_SEGCOUNT_ALLOC_SIZE) * (sizeof(dp_id_wt_data_t));

		temp_dp_contextual_data = (dp_id_wt_data_t *) realloc(dp_cont_bp_data->dp_contextual_data, alloc_size);
		if (temp_dp_contextual_data == NULL) {
			llog_write(L_DEBUG, "ERROR : while realloc of size : '%d', %s:%s:%d\n", (int )alloc_size, __FILE__, __FUNCTION__, __LINE__ );
			dp_cont_bp_data_init(dp_cont_bp_data);
			return DP_ERROR_NOMEMORY;
		}

		dp_cont_bp_data->dp_contextual_data = temp_dp_contextual_data;
	} else {
		temp_dp_contextual_data = dp_cont_bp_data->dp_contextual_data;
	}

	/*
	 * Now add values and inrement segment count.
	 */
	temp_dp_contextual_data[dp_cont_bp_data->cont_segment_count].wt = wt;
	temp_dp_contextual_data[dp_cont_bp_data->cont_segment_count].id = id;
	dp_cont_bp_data->cont_segment_count = dp_cont_bp_data->cont_segment_count + 1;

	return DP_ERROR_SUCCESS;
}

/*
 * Function to print contextual and brand safety data.
 */
void dp_cont_bp_data_print(dp_cont_bp_data_t *dp_cont_bp_data) {
	/*
	 * Local variables.
	 */
	int i;
	dp_id_wt_data_t *dp_contextual_data = NULL;

	/*
	 * Check validity of function paramaters.
	 */
	if (dp_cont_bp_data == NULL) {
		llog_write(L_DEBUG, "ERROR : Arguments NULL %s:%d\n", __FILE__, __LINE__ );
		return;
	}

	llog_write(L_DEBUG, "\n-----------------------------------------------------------------------------\n");
	llog_write(L_DEBUG, "DPID : '%d'\n", dp_cont_bp_data->dpid);	
	llog_write(L_DEBUG, "DP SCOPE : '%s'\n", dp_cont_bp_data->page_scope);	
	llog_write(L_DEBUG, "DP TYPE : '%s'\n", dp_cont_bp_data->page_type);	
	llog_write(L_DEBUG, "DP SEGMENT COUNT : '%d'\n", dp_cont_bp_data->cont_segment_count);	
	llog_write(L_DEBUG, "SEGMENT : \n");

	dp_contextual_data = dp_cont_bp_data->dp_contextual_data;
	if (dp_contextual_data != NULL) {
		for(i=0 ; i<dp_cont_bp_data->cont_segment_count; i++) {
			llog_write(L_DEBUG, "ID : '%d', WT : '%d'\n", dp_contextual_data[i].id, dp_contextual_data[i].wt);	
		}
	}
	
	llog_write(L_DEBUG, "BRAND PROTECTION DATA : \n");
	if (dp_cont_bp_data->dp_bp_safety_data.rating.set_flag == 1) {
		llog_write(L_DEBUG, "rating : id : '%d', wt : '%d'\n",
				dp_cont_bp_data->dp_bp_safety_data.rating.dp_id_wt_data.id, dp_cont_bp_data->dp_bp_safety_data.rating.dp_id_wt_data.wt);
	}
	if (dp_cont_bp_data->dp_bp_safety_data.safetylevel.set_flag == 1) {
		llog_write(L_DEBUG, "safetylevel : id : '%d', wt : '%d'\n",
				dp_cont_bp_data->dp_bp_safety_data.safetylevel.dp_id_wt_data.id, dp_cont_bp_data->dp_bp_safety_data.safetylevel.dp_id_wt_data.wt);
	}
	if (dp_cont_bp_data->dp_bp_safety_data.nonstandardcontent.set_flag == 1) {
		llog_write(L_DEBUG, "nonstandardcontent : id : '%d', wt : '%d'\n",
				dp_cont_bp_data->dp_bp_safety_data.nonstandardcontent.dp_id_wt_data.id, dp_cont_bp_data->dp_bp_safety_data.nonstandardcontent.dp_id_wt_data.wt);
	}
	llog_write(L_DEBUG, "\n-----------------------------------------------------------------------------\n");
}

int dp_dpid_campaign_format_json(dp_response_params_t *dp_resp_params) {
	/*
	 * Local variables.
	 */
	int i, offset = 0, retval, comma_flag = 0;
	dp_cont_bp_data_t *dp_cont_bp_data = NULL;
	dp_id_wt_data_t *dp_contextual_data = NULL;

	dp_cont_bp_data = &dp_resp_params->dp_cont_bp_data;
	dp_contextual_data = dp_cont_bp_data->dp_contextual_data;
	
	retval = snprintf(dp_resp_params->campaign_format_json + offset,
						MAX_DP_RESPONSE_SIZE - offset,
						"{\"provider\":%d,\"scope\":\"%s\",\"type\":\"%s\"",
						dp_cont_bp_data->dpid, dp_cont_bp_data->page_scope, dp_cont_bp_data->page_type);
	offset = offset + retval;
	
	/*
	 * Now add contextual data.
	 */
	if(dp_contextual_data != NULL) {
		retval = snprintf(dp_resp_params->campaign_format_json + offset,
						MAX_DP_RESPONSE_SIZE - offset,
						",\"category\":[");
		offset = offset + retval;

		for(i=0 ; i<dp_cont_bp_data->cont_segment_count; i++) {
			if(i != 0) {
				retval = snprintf(dp_resp_params->campaign_format_json + offset,
									MAX_DP_RESPONSE_SIZE - offset,
									",");
				offset = offset + retval;
			}

			retval = snprintf(dp_resp_params->campaign_format_json + offset,
								MAX_DP_RESPONSE_SIZE - offset,
								"{\"id\":%d,\"wt\":%d}",
								dp_contextual_data[i].id, dp_contextual_data[i].wt);
			offset = offset + retval;
		}
		
		/*
		 * End contextual data JSON array.
		 */
		retval = snprintf(dp_resp_params->campaign_format_json + offset,
							MAX_DP_RESPONSE_SIZE - offset,
							"]");
		offset = offset + retval;
	}

	/*
	 * Now add brandsafety data.
	 */
	if((dp_cont_bp_data->dp_bp_safety_data.rating.set_flag == 1) ||
			(dp_cont_bp_data->dp_bp_safety_data.safetylevel.set_flag == 1) ||
				(dp_cont_bp_data->dp_bp_safety_data.nonstandardcontent.set_flag == 1)) {
		retval = snprintf(dp_resp_params->campaign_format_json + offset,
							MAX_DP_RESPONSE_SIZE - offset,
							",\"brandsafety\":[");
		offset = offset + retval;

		/*
		 * Add rating object.
		 */
		if (dp_cont_bp_data->dp_bp_safety_data.rating.set_flag == 1) {
			if (comma_flag == 1) {
				retval = snprintf(dp_resp_params->campaign_format_json + offset,
									MAX_DP_RESPONSE_SIZE - offset,
									",");
				offset = offset + retval;
			}
			retval = snprintf(dp_resp_params->campaign_format_json + offset,
								MAX_DP_RESPONSE_SIZE - offset,
								"{\"id\":%d}", dp_cont_bp_data->dp_bp_safety_data.rating.dp_id_wt_data.id);
			offset = offset + retval;
			comma_flag = 1;
		}

		/*
		 * Add safetylevel object.
		 */
		if (dp_cont_bp_data->dp_bp_safety_data.safetylevel.set_flag == 1) {
			if (comma_flag == 1) {
				retval = snprintf(dp_resp_params->campaign_format_json + offset,
									MAX_DP_RESPONSE_SIZE - offset,
									",");
				offset = offset + retval;
			}
			retval = snprintf(dp_resp_params->campaign_format_json + offset,
								MAX_DP_RESPONSE_SIZE - offset,
								"{\"id\":%d}", dp_cont_bp_data->dp_bp_safety_data.safetylevel.dp_id_wt_data.id);
			offset = offset + retval;
			comma_flag = 1;
		}

		/*
		 * Add nonstandardcontent object.
		 */
		if (dp_cont_bp_data->dp_bp_safety_data.nonstandardcontent.set_flag == 1) {
			if (comma_flag == 1) {
				retval = snprintf(dp_resp_params->campaign_format_json + offset,
									MAX_DP_RESPONSE_SIZE - offset,
									",");
				offset = offset + retval;
			}
			retval = snprintf(dp_resp_params->campaign_format_json + offset,
								MAX_DP_RESPONSE_SIZE - offset,
								"{\"id\":%d}", dp_cont_bp_data->dp_bp_safety_data.nonstandardcontent.dp_id_wt_data.id);
			offset = offset + retval;
			comma_flag = 1;
		}

		/*
		 * End brand safety data JSON array.
		 */
		retval = snprintf(dp_resp_params->campaign_format_json + offset,
							MAX_DP_RESPONSE_SIZE - offset,
							"]");
		offset = offset + retval;
	}

	/*
	 * End DPID JSON object.
	 */
	retval = snprintf(dp_resp_params->campaign_format_json + offset,
						MAX_DP_RESPONSE_SIZE - offset,
						"}");
	offset = offset + retval;

	/*
	 * Update Campaign JSON string length.
	 */
	dp_resp_params->campaign_format_json_len = offset;


	return ADS_ERROR_SUCCESS;
}
int dp_make_campaign_format_json(dp_response_params_t *dp_resp_params,
	int max_resp_count) {
	/*
	 * Local variables.
	 */
	int i = 0;

	if( dp_resp_params == NULL || max_resp_count < 0 ) {
		llog_write(L_DEBUG, "ERROR dp_process_response_init : Arguments NULL %s:%d\n", __FILE__, __LINE__ );
		return DP_ERROR_INVALID_ARGS;
	}

	for( i = 0 ; i < max_resp_count; i++ ) {
		if ((dp_resp_params[i].response_size > 0) && (dp_resp_params[i].response_success_flag ==1)) {
			dp_dpid_campaign_format_json(&dp_resp_params[i]);
		}
	}

	return ADS_ERROR_SUCCESS;
}

int dp_process_response_init( dp_response_params_t *dp_resp_params, int max_resp_count)
{
	int i = 0;

	if( dp_resp_params == NULL || max_resp_count < 0 ) {
		llog_write(L_DEBUG, "ERROR dp_process_response_init : Arguments NULL %s:%d\n", __FILE__, __LINE__ );
		return DP_ERROR_INVALID_ARGS;
	}

	for( i = 0 ; i < max_resp_count; i++ )
	{
		dp_resp_params[i].dpid = 0;
		dp_resp_params[i].url_to_be_analysed[0]='\0';
		dp_resp_params[i].response_type = 0;
		dp_resp_params[i].response[0] = '\0';
		dp_resp_params[i].campaign_format_json[0] = '\0';
		dp_resp_params[i].campaign_format_json_len = 0;
		dp_resp_params[i].response_size = 0;
		dp_resp_params[i].response_success_flag = 0;
		dp_resp_params[i].create_flag = 0;
		dp_resp_params[i].timeout_never_occured_flag = 0;
		dp_cont_bp_data_init(&dp_resp_params[i].dp_cont_bp_data);
	}

	return ADS_ERROR_SUCCESS;
}

int dp_process_response_release( dp_response_params_t *dp_resp_params, int max_resp_count)
{	
	int i = 0;

	if( dp_resp_params == NULL || max_resp_count < 0 ) {
		llog_write(L_DEBUG, "\nERROR : Arguments NULL %s:%s:%d\n", __FILE__, __FUNCTION__, __LINE__ );
		return DP_ERROR_INVALID_ARGS;
	}

	for( i = 0 ; i < max_resp_count; i++ )
	{
		dp_cont_bp_data_release(&dp_resp_params[i].dp_cont_bp_data);
	}

	return DP_ERROR_SUCCESS;
}

int dp_init_env(dp_config_t *dp_config, 
		dp_request_params_t *dp_req_params, 
		db_connection_t *db_conn,
		int max_dp_count)
{
	int i = 0;
	int failed_easy_handle = 0;
	int retval = ADS_ERROR_SUCCESS;

	if( dp_config == NULL 
			|| dp_req_params == NULL 
			|| db_conn == NULL ) {
		llog_write(L_DEBUG, "ERROR Paraniod check.Function expects arguments to be pre allocated %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	// Call DP specific intialize function to return DP allocated config
	for( i = 0 ; i < max_dp_count; i++ )
	{
		retval = (dp_config[i].dp_generic)->dp_ops->initialize(db_conn, &(dp_config[i].dp_spec_config), &(dp_config[i].dp_spec_config_size));
		if( retval != DP_ERROR_SUCCESS ) {
			llog_write(L_DEBUG, "ERROR  init failed for DPId : %d,DP Name : %s %s:%d\n",
					dp_config[i].dp_generic->dp_ops->get_id(), 
					dp_config[i].dp_generic->dp_ops->get_name(), __FILE__, __LINE__);
			return ADS_ERROR_INTERNAL;
		}
	}

/*	if(!(dp_req_params->dp_curl_multi_pool_initialized)) {
#ifdef DEBUG
		llog_write(L_DEBUG, "Creating DP CURL multihandle\n");
#endif
		retval = dp_init_curlm_handle(&(dp_req_params->dp_curlm_handle), MAX_DP_COUNT);
		if(retval != DP_ERROR_SUCCESS) {
			llog_write(L_DEBUG, "ERROR dp_init_curlm_handle failed %s:%d\n", __FILE__, __LINE__);
			//TODO dp cleanup
			return ADS_ERROR_INTERNAL;
		}
		dp_req_params->dp_curl_multi_pool_initialized = 1;

	}
*/
	failed_easy_handle = 0;
	if(!(dp_req_params->dp_curl_easy_pool_initialized)) {
#ifdef DEBUG
		llog_write(L_DEBUG, "Creating DP CURL easy handles\n");
#endif
		retval = dp_init_curl_cache_handles(dp_req_params->dp_curle_handle, MAX_DP_COUNT, &failed_easy_handle);
		if(retval != DP_ERROR_SUCCESS) {
			llog_write(L_DEBUG, "ERROR dp_init_easy_handle failed %s:%d\n", __FILE__, __LINE__);
			//TODO dp cleanup 
			return ADS_ERROR_INTERNAL;
		}
		dp_req_params->dp_curl_easy_pool_initialized = 1;
	}

	dp_req_params->db_conn = db_conn;

	fprintf( stdout, "Env is setup,  config is loaded , curl handles initialized\n");
	return ADS_ERROR_SUCCESS;
}

int dp_rel_env(dp_config_t *dp_config, dp_request_params_t *dp_req_params, int max_dp_count)
{
	int i = 0;
	int retval = ADS_ERROR_SUCCESS;

	if( dp_config == NULL 
			|| dp_req_params == NULL ) {

		fprintf( stdout, "DEBUG dp_rel_env:arguments passed are NULL  %s:%d\n", __FILE__, __LINE__);
		return retval;
	}

	// Call DP specific intialize function to return DP allocated config
	for( i = 0 ; i < max_dp_count; i++ ) {
		if( dp_config[i].dp_spec_config != NULL && dp_config[i].dp_spec_config_size ) {

			retval = dp_config[i].dp_generic->dp_ops->release_config(dp_config[i].dp_spec_config);
			if( retval != DP_ERROR_SUCCESS ) {
				llog_write(L_DEBUG, "ERROR  releasing failed for DPId : %d,DP Name : %s %s:%d\n",
						dp_config[i].dp_generic->dp_ops->get_id(), 
						dp_config[i].dp_generic->dp_ops->get_name(), __FILE__, __LINE__);
				continue;
			}

			dp_config[i].dp_spec_config = NULL;
			dp_config[i].dp_spec_config_size = 0;
		}
	}			

	// TODO Ugly hack to remove memory leak
	// Fix later
/*	if( dp_req_params->dp_curl_multi_pool_initialized == 1 ) {
		retval = dp_clean_curlm_handle(&(dp_req_params->dp_curlm_handle));
		if( retval != DP_ERROR_SUCCESS ) {
			llog_write(L_DEBUG, "ERROR dp_clean_curlm_handle failed %s:%d\n" , __FILE__, __LINE__);
			retval = ADS_ERROR_INTERNAL;
		}
		dp_req_params->dp_curl_multi_pool_initialized = 0;
	}*/

	if( dp_req_params->dp_curl_easy_pool_initialized == 1 )	{
		retval = dp_clean_curl_cache_handles(dp_req_params->dp_curle_handle, MAX_DP_COUNT);
		if( retval != DP_ERROR_SUCCESS ) {
			llog_write(L_DEBUG, "ERROR dp_clean_curle_handle failed %s:%d\n", __FILE__, __LINE__);
			retval = ADS_ERROR_INTERNAL;
		}
		dp_req_params->dp_curl_easy_pool_initialized = 0;
	}

	dp_req_params->db_conn = NULL;

	return retval;
}

int dp_response_callback(void *in_ptr , size_t size, size_t nmemb, void *stream)
{
	char *buf = NULL;
	dp_response_params_t *dp_resp_params = NULL;
	int total_size = 0, response_size = 0, response_buffer_left = 0;
	int i = 0;


	buf = (char *)in_ptr;
	dp_resp_params = (dp_response_params_t *)stream;

	//Callback was called means 
	//response arrived before timout
	//hence set the flag to true(1) 
	dp_resp_params->timeout_never_occured_flag = 1; 

	total_size = size * nmemb;

	for(i = 0; i < total_size ; i++) {
		if(buf[i] == '\r') {
			buf[i] = '\n';
		}
	}


	//Find out left over buffer size in response buf
	response_buffer_left =  MAX_DP_RESPONSE_SIZE - (dp_resp_params->response_size) - 1; // Keeping 1 byte for '\0'

	//Copy only min(total_size,MAX_DP_RESPONSE_SIZE), if more skip the rest
	response_size =  ((total_size > response_buffer_left)?response_buffer_left:total_size);

	memcpy(&(dp_resp_params->response[dp_resp_params->response_size]), buf, response_size);

	//Set the rest of the fields in response
	dp_resp_params->response_size += response_size;
	dp_resp_params->response[dp_resp_params->response_size] = '\0';// Handling boundary case

	dp_resp_params->response_success_flag = 1;
	return total_size;
}

int dp_create_request(dp_request_params_t *dp_req_params,
		const ad_server_req_param_t *in_req_params,
		dp_response_params_t *dp_resp_params,
		int max_dp_count)
{
	int i = 0;
	int retval = ADS_ERROR_SUCCESS;
	CURL *curl_handle = NULL;
	dp_config_t *dp_config = NULL;

	if( (dp_req_params == NULL) 
			|| (dp_resp_params) == NULL) {

		llog_write(L_DEBUG, "ERROR dp_create_request: Arguments NULL%s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	for( i = 0; i < max_dp_count; i++ )
	{
		dp_config = dp_req_params->dp_config[i];
		curl_handle = dp_req_params->dp_curle_handle[i].curle_handle;

		//Always Set required fields in response
		dp_resp_params[i].dpid = dp_config->dp_generic->dp_ops->get_id();
		//TODO comment url since not used right now
		snprintf(dp_resp_params[i].url_to_be_analysed, MAX_URL_SIZE, "%s", in_req_params->page_url);
		dp_resp_params[i].url_to_be_analysed[MAX_URL_SIZE+1] = '\0';
		dp_resp_params[i].response_success_flag = 0;
		dp_resp_params[i].timeout_never_occured_flag = 0;
		dp_resp_params[i].create_flag = 0;

		retval = dp_config->dp_generic->dp_ops->create_request(dp_config[i].dp_spec_config, in_req_params, curl_handle, &(dp_resp_params[i]));
		if(retval == DP_ERROR_SUCCESS) {
			dp_resp_params[i].create_flag = 1;
		} else if( retval != DP_ERROR_SUCCESS ) {
			if (retval == DP_ERROR_NOT_SUPPORTED) {
				llog_write(L_DEBUG,"\nDp error not supported error %s : %d",__FILE__,__LINE__);
				retval = ADS_ERROR_INTERNAL;
				continue;
			}
			llog_write(L_DEBUG, "ERROR dp_ops->create_request failed for %s %s:%d\n",
					dp_config->dp_generic->dp_ops->get_name(), __FILE__, __LINE__);
			retval = ADS_ERROR_INTERNAL;
			break;
		}
	}
	return retval;
} 

int dp_add_request( dp_response_params_t *dp_resp_params,
		dp_config_t *dp_config, 
		CURLM *multi_curl_handle,
		dp_curl_easy_handle_t *dp_curl_easy_handle, 
		int max_dp_count, int *failed_count)
{
	int i = 0;
	int retval = ADS_ERROR_SUCCESS;
	int isenabled = 0;
	CURLMcode rc = CURLM_OK;

	*failed_count = 0;

	if( dp_config == NULL 
			|| multi_curl_handle == NULL 
			|| dp_curl_easy_handle == NULL ) {
		llog_write(L_DEBUG, "ERROR %s:%d\n", __FILE__, __LINE__ );
		return ADS_ERROR_INVALID_ARGS;	
	}

	for( i = 0 ; i < max_dp_count ; i++)
	{
		//Get isenabled flag for each DP
		//TODO find efficient way to reduce function calls
		//TODO make references short
		isenabled = dp_config[i].dp_generic->dp_ops->get_isenabled(dp_config[i].dp_spec_config);
		if(( isenabled == DP_ENABLED ) && (dp_resp_params[i].create_flag == 1)) {

#ifdef DEBUG
			llog_write(L_DEBUG, "Inside add request: DP is enabled\n");
#endif

			rc = curl_multi_add_handle(multi_curl_handle, 
					dp_curl_easy_handle[i].curle_handle);
			if( rc != CURLM_OK ) {
				(*failed_count)++;//TODO not used currently, for future reference
				llog_write(L_DEBUG,"ERROR stacking num of handle failed:%d %s:%s:%d\n", 
						*failed_count, curl_multi_strerror(retval),__FILE__,__LINE__);
				continue;
			}
		}

		//Skip for all disabled DPs
	}

	return retval;
}

int dp_remove_request(dp_response_params_t *dp_resp_params, dp_config_t *dp_config, CURLM *multi_curl_handle, 
		dp_curl_easy_handle_t *dp_curl_easy_handle, int num_of_added_handles)
{
	int i = 0;
	int isenabled = 0;

	if( dp_config == NULL 
			|| multi_curl_handle==NULL
			|| dp_curl_easy_handle == NULL ) {

		llog_write(L_DEBUG, "ERROR Arguments not initialised %s:%d\n", __FILE__,__LINE__ );
		return ADS_ERROR_INTERNAL;
	}


	for ( i = 0 ; i < num_of_added_handles; i++ )
	{
		// For each DP remove easy handle if isenabled
		isenabled = dp_config[i].dp_generic->dp_ops->get_isenabled(dp_config[i].dp_spec_config);
		
	if( isenabled == DP_ENABLED && dp_curl_easy_handle[i].curle_handle != NULL  && dp_resp_params[i].create_flag == 1) {  // Check which DP is active
			curl_multi_remove_handle(multi_curl_handle,
					dp_curl_easy_handle[i].curle_handle);
		

			/* Curl RTB-S2S Performance Metrics Logging  */
			if (g_allow_config_reload_flag == 1 && g_curlstat_enabled_flag == 1 ) {
			    
			    log_curlstat(dp_curl_easy_handle[i].curle_handle, __FILE__, __LINE__);
			}
			/* Curl RTB-S2S Performance Metrics Logging End */


	}			
	}	
	return ADS_ERROR_SUCCESS;
}

// niki :: multi perform not required
/*
int dp_request_do_perform(dp_curl_multi_handle_t *dp_curlm_handle)
{
	CURLMcode rc = CURLM_OK;
	int still_running = 0;
	struct timeval timeout;
	int retval = DP_ERROR_SUCCESS;	

	fd_set fdread;
	fd_set fdwrite;
	fd_set fdexcep;
	int status = 0;
	int maxfd = 0;

	if( dp_curlm_handle == NULL || dp_curlm_handle->curlm_handle == NULL  ) {

		llog_write(L_DEBUG, "ERROR dp_request_do_perform curlm handle not initialised %s:%d", __FILE__,__LINE__);
		return DP_ERROR_INVALID_ARGS;
	}

	while((rc = curl_multi_perform(dp_curlm_handle->curlm_handle, &still_running)) == CURLM_CALL_MULTI_PERFORM );

#ifdef DEBUG
	llog_write(L_DEBUG, "Inside Do perform curl_multi_perform done\n");
#endif

	if (rc != CURLM_OK) {
		return DP_ERROR_INTERNAL;
	}

	while(still_running) {

		FD_ZERO(&fdread);
		FD_ZERO(&fdwrite);
		FD_ZERO(&fdexcep);

		timeout.tv_sec =  g_dp_ms_timeout/1000;
		timeout.tv_usec = (g_dp_ms_timeout%1000)*1000;

		rc = curl_multi_fdset(dp_curlm_handle->curlm_handle, &fdread, &fdwrite, &fdexcep, &maxfd);
#ifdef DEBUG
		llog_write(L_DEBUG, "Inside Do perform curl_multi_fdset done maxfd %d\n", maxfd);
#endif

		if(rc != CURLM_OK) {
			return DP_ERROR_INTERNAL;
		}

		if(maxfd == -1) {
			break;
		}else {
			if(timeout.tv_sec == 0 && timeout.tv_usec == 0) {
				still_running = 0;
				retval = DP_ERROR_INTERNAL;
			}else {
				status = select(maxfd+1, &fdread, &fdwrite, &fdexcep, &timeout);
			}
		}

		switch(status) {
			case -1:	
				llog_write(L_DEBUG,"ERROR:DP select returned error %s:%d\n",__FILE__,__LINE__);
				still_running = 0;
				retval = DP_ERROR_INTERNAL;
				break;
			case 0:
				still_running = 0;
				break;
			default:
				while((rc = curl_multi_perform(dp_curlm_handle->curlm_handle, &still_running)) ==
						CURLM_CALL_MULTI_PERFORM );
				if (rc != CURLM_OK) {
					return DP_ERROR_INTERNAL;
				}
		}
	}
	return retval;
}*/

/*
 * Interface to be called from RTB workflow
 */
int dp_get_data(dp_config_t *dp_config,
		dp_request_params_t *dp_req_params,
		dp_response_params_t *dp_resp_params,
		CURLM *multi_curl_handle, 
		int max_dp_count,
		void *contextual_data,
		int *contextual_size)
{
	(void) contextual_data;
	(void) contextual_size;
	int retval = ADS_ERROR_SUCCESS;

	if( dp_config == NULL 
			|| dp_req_params == NULL
			|| dp_resp_params == NULL
			|| multi_curl_handle == NULL) {
		//TODO enable this when output format gets decided || contextual_data == NULL ) {
		llog_write(L_DEBUG, "ERROR!!! dp_get_data failed in valid arguments %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

/*	//Check if request handles are initialized 
	if(( dp_req_params->dp_curl_multi_pool_initialized == 0)
			|| ( dp_req_params->dp_curl_easy_pool_initialized == 0)) {
		llog_write(L_DEBUG, "ERROR!!! dp_get_data returning handles not initialized check config %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	retval = dp_create_request(dp_req_params, in_req_params, dp_resp_params, max_dp_count);
	if( retval != DP_ERROR_SUCCESS ) {
		llog_write(L_DEBUG, "ERROR dp_create_request failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	failed_count = 0;
	retval = dp_add_request(dp_resp_params, dp_config, &(dp_req_params->dp_curlm_handle), dp_req_params->dp_curle_handle, MAX_DP_COUNT, &failed_count);
	if( retval != DP_ERROR_SUCCESS ) {
		llog_write(L_DEBUG, "ERROR dp_add_request failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

#ifdef TIME_DIFF*/
	/*
	 * Get start time before doing multiple curl calls.
	 */
/*	gettimeofday(&tv1, NULL);
#endif
	retval = dp_request_do_perform(&(dp_req_params->dp_curlm_handle));	
	if( retval != DP_ERROR_SUCCESS ) {
		llog_write(L_DEBUG, "ERROR dp_request_do_perform failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}
#ifdef TIME_DIFF
	
	 * Get end time after doing multiple curl calls.
	 
	gettimeofday(&tv2, NULL);

	*
	 * Now get time in milliseconds.
	 */
//	diff_milli = TIME_DIFF_MILLI(tv1, tv2);
	//llog_write(L_DEBUG, "Time taken for CURL multiple calls : '%lu'\n", diff_milli);

//#endif

	retval = dp_remove_request(dp_resp_params, dp_config, multi_curl_handle, dp_req_params->dp_curle_handle, max_dp_count);
	if( retval != DP_ERROR_SUCCESS ) {
		llog_write(L_DEBUG, "ERROR dp_remove_request failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}
	void *response = NULL;
	int response_size = 0;

	retval = dp_add_to_rtb(dp_req_params, dp_resp_params, max_dp_count, &response, &response_size);
	if( retval != DP_ERROR_SUCCESS ) {
		llog_write(L_DEBUG, "ERROR dp_add_to_rtb failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}
	retval = dp_make_campaign_format_json(dp_resp_params, max_dp_count);
	if( retval != DP_ERROR_SUCCESS ) {
		llog_write(L_DEBUG, "ERROR dp_make_campaign_format_json failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}
	return retval;
}

int dp_contextual_enable_curl_conn( int rtb_enabled_flag,
		int* all_curl_handles_initialized,
		fte_additional_params_t* fte_additional_parameters,
		db_connection_t *dbconn,
		int reload_config_flag) {
	int retval;
#ifdef DEBUG
	llog_write(L_DEBUG, "Inside function : '%s', all_curl_handles_initialized : '%d'\n", __FUNCTION__, *all_curl_handles_initialized);
#endif
	switch(rtb_enabled_flag) {
		case 0:
			if(*all_curl_handles_initialized == 1) {
#ifdef DEBUG
				llog_write(L_DEBUG, "Calling dp_rel_env\n");
#endif
				dp_rel_env(	fte_additional_parameters->dp_config,
						fte_additional_parameters->dp_request_params,
						MAX_DP_COUNT);
				*all_curl_handles_initialized = 0;
			}
			break;

		case 1:
			if((*all_curl_handles_initialized != 1) || (reload_config_flag == 1)) {
#ifdef DEBUG
				llog_write(L_DEBUG, "Calling dp_process_request_init, dp_init_env\n");
#endif
				dp_rel_env(	fte_additional_parameters->dp_config,
						fte_additional_parameters->dp_request_params,
						MAX_DP_COUNT);

				retval = dp_init_env(fte_additional_parameters->dp_config,
						fte_additional_parameters->dp_request_params,
						dbconn,
						MAX_DP_COUNT);
				if( retval != ADS_ERROR_SUCCESS )
				{
					llog_write(L_DEBUG, "ERROR dp_init_env failed %s:%d\n", __FILE__, __LINE__);
					return ADS_ERROR_INTERNAL;
				}
				*all_curl_handles_initialized = 1;
			}
			break;

		default:
			llog_write(L_DEBUG,"ERROR rtb value is neither 1 nor 2 %s:%d\n",__FILE__,__LINE__);
			//assert(0);
	}
	return ADS_ERROR_SUCCESS;
}

int dp_add_to_rtb( dp_request_params_t *dp_req_params,
		dp_response_params_t *dp_resp_params,
		int max_dp_count,
		void **rtb_dp_buf,
		int *rtb_dp_buff_size )
{
	(void) rtb_dp_buff_size;
	int i = 0;
	int isenabled = 0;
	int retval = ADS_ERROR_SUCCESS;
	dp_config_t *dp_config = NULL;

	if( dp_req_params == NULL 
			|| dp_resp_params == NULL
			|| rtb_dp_buf == NULL ) {

		llog_write(L_DEBUG,"ERROR!!! dp_add_to_rtb failed Invalid arguments%s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}


	for( i = 0; i < max_dp_count; i++ ) 
	{
		dp_config = dp_req_params->dp_config[i];
		
		isenabled = dp_config[i].dp_generic->dp_ops->get_isenabled(dp_config[i].dp_spec_config);
		if( isenabled == DP_ENABLED && dp_resp_params[i].response_success_flag == 1) {
		
#ifdef MULTI_CURL_CALL
			if(dp_resp_params[i].timeout_never_occured_flag == 0) {
				llog_write(L_DEBUG, "Timeout occured for DP id : %d name : %s for url : %s %s:%d\n",
						dp_config->dp_generic->dp_ops->get_id(),
						dp_config->dp_generic->dp_ops->get_name(),
						dp_resp_params[i].url_to_be_analysed,
						__FILE__,__LINE__);						
			}

			if(dp_resp_params[i].response_size == 0) {
				llog_write(L_DEBUG, "No/NULL Response returned for DP id : %d name : %s for url : %s %s:%d\n",
						dp_config->dp_generic->dp_ops->get_id(),
						dp_config->dp_generic->dp_ops->get_name(),
						dp_resp_params[i].url_to_be_analysed,
						__FILE__,__LINE__);						
			}
#endif 
			retval = dp_config[i].dp_generic->dp_ops->parse_response(dp_config[i].dp_spec_config,
					dp_resp_params[i].response,
					dp_resp_params[i].response_size,
					&dp_resp_params[i].dp_cont_bp_data);
			
			if(retval != DP_ERROR_SUCCESS) {
				llog_write(L_DEBUG, "ERROR in parsing response for DP id : %d name : %s %s:%d\n",
						dp_config->dp_generic->dp_ops->get_id(),
						dp_config->dp_generic->dp_ops->get_name(),
						__FILE__,__LINE__);
				continue;
			}	
		}
	}		

	return retval;
}

int int_compare(const void *int1, const void *int2) {
	int *num1 = (int *) int1;
	int *num2 = (int *) int2;

	if(*num1 < *num2) {
		return -1;
	} else if (*num1 == *num2) {
		return 0;
	} else {
		return 1;
	}
}

/*
 * Function creates contextual JSON data for DP, based on campaign-id settings.
 */
int dp_generic_bp_creator(dp_data_passing_params_t *params,
	dp_response_params_t *dp_resp_params) {
	/*
	 * Local variables.
	 */
	int i;
	campaign_data_provider_settings_t *dp_settings = NULL;
	campaign_data_provider_segment_type_settings_t *cmpg_dp_seg_stype_settinngs = NULL;
	data_provider_data_t *dp_data = NULL;
	int *setting_segment_ids = NULL;
	int write_flag = 0;
	dp_bp_safety_data_t *dp_bp_safety_data;
	dp_contextual_string_data_t dp_bp_string_data;
	dp_contextual_string_data_t dp_bp_logger;
	int *num;
	char temp_str[DP_TEMP_STR_LEN + 1];

#ifdef DEBUG
	llog_write(L_DEBUG, "Inside function : '%s'\n", __FUNCTION__);
#endif

	dp_data = *(params->dp_data);
	dp_settings = params->dp_settings;
	dp_bp_safety_data = &(dp_resp_params->dp_cont_bp_data.dp_bp_safety_data);

    init_dp_contextual_string_data(&dp_bp_string_data);
    init_dp_contextual_string_data(&dp_bp_logger);

	/*
	 * Get brandsafety setting for this campaign-id.
	 */
	for(i=0; i<dp_settings->cmpg_dp_seg_stype_settinngs_count; i++) {
		if(dp_settings->cmpg_dp_seg_stype_settinngs[i]->segment_type_id == DATA_PROVIDER_BRAND_SAFETY_SEGMENT) {
			cmpg_dp_seg_stype_settinngs = dp_settings->cmpg_dp_seg_stype_settinngs[i];
			break;
		}
	}
	/*
	 * Check if settings found.
	 */
	if (cmpg_dp_seg_stype_settinngs == NULL) {
		llog_write(L_DEBUG, "No brand safety settings found\n");
		return ADS_ERROR_SUCCESS;
	}
	if((cmpg_dp_seg_stype_settinngs->segment_ids_count == 0) || (cmpg_dp_seg_stype_settinngs->segment_ids == NULL)) {
		llog_write(L_DEBUG, "Invalid segment_ids_count or segment_ids = NULL, : '%s:%s:%d'\n",
							__FILE__, __FUNCTION__, __LINE__);
		return ADS_ERROR_SUCCESS;
	}
	setting_segment_ids = cmpg_dp_seg_stype_settinngs->segment_ids;

	/*
	 * Write rating data.
	 */
	if(dp_bp_safety_data->rating.set_flag == 1) {
		num = NULL;
		if(setting_segment_ids[0] != 0) {
			num = (int *) bsearch(&dp_bp_safety_data->rating.dp_id_wt_data.id,
									setting_segment_ids,
									cmpg_dp_seg_stype_settinngs->segment_ids_count,
									sizeof(int),
									int_compare);
		}
		if ((num != NULL) || (setting_segment_ids[0] == 0)) {
			//llog_write(L_DEBUG, "found ID : '%d'\n", dp_bp_safety_data->rating.dp_id_wt_data.id);
			write_dp_contextual_string_data(&dp_bp_string_data, "\"brandsafety\":[");
			write_flag = 1;

			snprintf(temp_str, sizeof(temp_str), "{\"id\":%d}", dp_bp_safety_data->rating.dp_id_wt_data.id);
			write_dp_contextual_string_data(&dp_bp_string_data, temp_str);

			snprintf(temp_str, sizeof(temp_str), "{\"%d\":[%d", dp_resp_params->dpid, dp_bp_safety_data->rating.dp_id_wt_data.id);
			write_dp_contextual_string_data(&dp_bp_logger, temp_str);
		}
	}

	if(dp_bp_safety_data->safetylevel.set_flag == 1) {
		num = NULL;
		if(setting_segment_ids[0] != 0) {
			num = (int *) bsearch(&dp_bp_safety_data->safetylevel.dp_id_wt_data.id,
									setting_segment_ids,
									cmpg_dp_seg_stype_settinngs->segment_ids_count,
									sizeof(int),
									int_compare);
		}
		if ((num != NULL) || (setting_segment_ids[0] == 0)) {
			if(write_flag == 1) {
				write_dp_contextual_string_data(&dp_bp_string_data, ",");
				write_dp_contextual_string_data(&dp_bp_logger, ",");
			} else {
				write_dp_contextual_string_data(&dp_bp_string_data, "\"brandsafety\":[");

				snprintf(temp_str, sizeof(temp_str), "{\"%d\":[", dp_resp_params->dpid);
				write_dp_contextual_string_data(&dp_bp_logger, temp_str);

				write_flag = 1;
			}

			snprintf(temp_str, sizeof(temp_str), "{\"id\":%d}", dp_bp_safety_data->safetylevel.dp_id_wt_data.id);
			write_dp_contextual_string_data(&dp_bp_string_data, temp_str);

			snprintf(temp_str, sizeof(temp_str), "%d", dp_bp_safety_data->safetylevel.dp_id_wt_data.id);
			write_dp_contextual_string_data(&dp_bp_logger, temp_str);
		}
	}

	if(dp_bp_safety_data->nonstandardcontent.set_flag == 1) {
		num = NULL;
		if(setting_segment_ids[0] != 0) {
			num = (int *) bsearch(&dp_bp_safety_data->nonstandardcontent.dp_id_wt_data.id,
									setting_segment_ids,
									cmpg_dp_seg_stype_settinngs->segment_ids_count,
									sizeof(int),
									int_compare);
		}
		if ((num != NULL) || (setting_segment_ids[0] == 0)) {
			if(write_flag == 1) {
				write_dp_contextual_string_data(&dp_bp_string_data, ",");
				write_dp_contextual_string_data(&dp_bp_logger, ",");
			} else {
				write_dp_contextual_string_data(&dp_bp_string_data, "\"brandsafety\":[");

				snprintf(temp_str, sizeof(temp_str), "{\"%d\":[", dp_resp_params->dpid);
				write_dp_contextual_string_data(&dp_bp_logger, temp_str);

				write_flag = 1;
			}

			snprintf(temp_str, sizeof(temp_str), "{\"id\":%d}", dp_bp_safety_data->nonstandardcontent.dp_id_wt_data.id);
			write_dp_contextual_string_data(&dp_bp_string_data, temp_str);

			snprintf(temp_str, sizeof(temp_str), "%d", dp_bp_safety_data->nonstandardcontent.dp_id_wt_data.id);
			write_dp_contextual_string_data(&dp_bp_logger, temp_str);
		}
	}

	if(write_flag == 1) {
		write_dp_contextual_string_data(&dp_bp_string_data, "]");
		write_dp_contextual_string_data(&dp_bp_logger, "]}");
	}

	if (get_dp_contextual_string_curr_size(&dp_bp_string_data)) {
		dp_data->json_brand_safety_data = strdup(get_dp_contextual_string_data(&dp_bp_string_data));
		dp_data->json_brand_safety_data_len = get_dp_contextual_string_curr_size(&dp_bp_string_data);
	}

	if (get_dp_contextual_string_curr_size(&dp_bp_logger)) {
		snprintf(params->json_logger_data_provider_brand_safety_segment_ids,
				MAX_JSON_DATA_PROVIDER_SEGMENT_IDS, "%s",
				get_dp_contextual_string_data(&dp_bp_logger));
		params->json_logger_data_provider_brand_safety_segment_ids[MAX_JSON_DATA_PROVIDER_SEGMENT_IDS] = '\0';
		params->json_logger_data_provider_brand_safety_segment_ids_len = get_dp_contextual_string_curr_size(&dp_bp_logger);
	}

#ifdef DEBUG
	if (get_dp_contextual_string_curr_size(&dp_bp_string_data)) {
		llog_write(L_DEBUG, "Brand Safety data for DPID : '%d' : '%s'\n", dp_resp_params->dpid, get_dp_contextual_string_data(&dp_bp_string_data));
	}
	if (get_dp_contextual_string_curr_size(&dp_bp_logger)) {
		llog_write(L_DEBUG, "Brand Safety logger data for DPID : '%d' : '%s'\n", dp_resp_params->dpid, get_dp_contextual_string_data(&dp_bp_logger));
	}
#endif
	
	release_dp_contextual_string_data(&dp_bp_string_data);
	release_dp_contextual_string_data(&dp_bp_logger);

	return ADS_ERROR_SUCCESS;
}
	
/*
 * Function creates contextual JSON data for DP, based on campaign-id settings.
 */
int dp_generic_cont_creator(dp_data_passing_params_t *params,
	dp_response_params_t *dp_resp_params) {
	/*
	 * Local variables.
	 */
	int i,j;
	int comma_flag = 0;
	dp_id_wt_data_t *dp_contextual_data = NULL;
	campaign_data_provider_settings_t *dp_settings = NULL;
	campaign_data_provider_segment_type_settings_t *cmpg_dp_seg_stype_settinngs = NULL;
	data_provider_data_t *dp_data = NULL;
	int *setting_segment_ids = NULL;
	int *num = NULL;
	dp_contextual_string_data_t dp_contextual_string_data;
	dp_contextual_string_data_t dp_contextual_logger;
	char temp_str[DP_TEMP_STR_LEN + 1];

#ifdef DEBUG
	llog_write(L_DEBUG, "Inside function : '%s'\n", __FUNCTION__);
#endif

	/*
     * Init local data structure.
     */
    init_dp_contextual_string_data(&dp_contextual_string_data);
    init_dp_contextual_string_data(&dp_contextual_logger);

	/*
	 * Get addresses of setting ,data and contextual dats DS.
	 */
	dp_data = *(params->dp_data);
	dp_settings = params->dp_settings;
	dp_contextual_data = dp_resp_params->dp_cont_bp_data.dp_contextual_data;
	if (dp_contextual_data == NULL) {
		llog_write(L_DEBUG, "No contextual data for dpid : '%d'\n", dp_resp_params->dpid);
		return ADS_ERROR_INVALID_ARGS;
	}

	/*
	 * Get contextual setting for this campaign-id.
	 */
	for(i=0; i<dp_settings->cmpg_dp_seg_stype_settinngs_count; i++) {
		if(dp_settings->cmpg_dp_seg_stype_settinngs[i]->segment_type_id == DATA_PROVIDER_CONTEXTUAL_SEGMENT) {
			cmpg_dp_seg_stype_settinngs = dp_settings->cmpg_dp_seg_stype_settinngs[i];
			break;
		}
	}
	/*
	 * Check if settings found.
	 */
	if (cmpg_dp_seg_stype_settinngs == NULL) {
		llog_write(L_DEBUG, "No contextual settings found\n");
		return ADS_ERROR_INVALID_ARGS;
	}

	if((cmpg_dp_seg_stype_settinngs->segment_ids_count == 0) || (cmpg_dp_seg_stype_settinngs->segment_ids == NULL)) {
		llog_write(L_DEBUG, "Invalid segment_ids_count or segment_ids = NULL, : '%s:%s:%d'\n",
			__FILE__, __FUNCTION__, __LINE__);
		return ADS_ERROR_SUCCESS;
	}

    setting_segment_ids = cmpg_dp_seg_stype_settinngs->segment_ids;
	
#ifdef DEBUG
	llog_write(L_DEBUG, "Constructiing contextual data for dpid : '%d'\n", dp_resp_params->dpid);
#endif

	/*
	 * Go through setting of each campaign-id and construct data for each DP.
	 */
	if ((cmpg_dp_seg_stype_settinngs->segment_type_id == DATA_PROVIDER_CONTEXTUAL_SEGMENT) && 
					(cmpg_dp_seg_stype_settinngs->data_provider_id == dp_resp_params->dpid)) {
		/*
		 * Get array of setting.
		 */
		setting_segment_ids = cmpg_dp_seg_stype_settinngs->segment_ids;

		for(j=0; j<dp_resp_params->dp_cont_bp_data.cont_segment_count ; j++) {
			/*
			 * If thers is any setting for campaign id. check id returned by DP is in the list,
			 * then only add it to JSON.
			 */
			if (setting_segment_ids[0] != 0) {
				/*
			 	 * Now check this id is present in settings.
			 	 */
				num = (int *) bsearch(&dp_contextual_data[j].id,
										setting_segment_ids,
										cmpg_dp_seg_stype_settinngs->segment_ids_count,
										sizeof(int),
										int_compare);
				if (num == NULL) {
					/*
					 * Entry not found in settings. Continue.
					 */
					continue;
				}
			}
			if (comma_flag == 0) {
				comma_flag = 1;
				write_dp_contextual_string_data(&dp_contextual_string_data, "\"category\":[");

				/*
				 * Write looger JSON also.
				 */
				snprintf(temp_str, sizeof(temp_str), "{\"%d\":[", dp_resp_params->dpid);
				write_dp_contextual_string_data(&dp_contextual_logger, temp_str);
			} else { 
				write_dp_contextual_string_data(&dp_contextual_string_data, ",");
				write_dp_contextual_string_data(&dp_contextual_logger, ",");
			}

			/*
			 * Add id and weight in contextual JSON.
			 */
			snprintf(temp_str, sizeof(temp_str), "{\"id\":%d, \"wt\":%d}", dp_contextual_data[j].id, dp_contextual_data[j].wt);
			write_dp_contextual_string_data(&dp_contextual_string_data, temp_str);

			snprintf(temp_str, sizeof(temp_str), "%d", dp_contextual_data[j].id);
			write_dp_contextual_string_data(&dp_contextual_logger, temp_str);
#ifdef DEBUG
			llog_write(L_DEBUG, "ADDING IDs : '%s'\n", temp_str);
#endif
		}
	}

	/*
	 * End JSON data string by adding ']'.
	 */
	if (comma_flag == 1) {
		write_dp_contextual_string_data(&dp_contextual_string_data, "]");
		write_dp_contextual_string_data(&dp_contextual_logger, "]}");
	}

	if (get_dp_contextual_string_curr_size(&dp_contextual_string_data)) {
		dp_data->json_contextual_data = strdup(get_dp_contextual_string_data(&dp_contextual_string_data));
		dp_data->json_contextual_data_len = get_dp_contextual_string_curr_size(&dp_contextual_string_data);
	}
	if (get_dp_contextual_string_curr_size(&dp_contextual_logger)) {
		snprintf(params->json_logger_data_provider_contextual_segment_ids,
				MAX_JSON_DATA_PROVIDER_SEGMENT_IDS, "%s",
				get_dp_contextual_string_data(&dp_contextual_logger));
		params->json_logger_data_provider_contextual_segment_ids[MAX_JSON_DATA_PROVIDER_SEGMENT_IDS] = '\0';
		params->json_logger_data_provider_contextual_segment_ids_len = get_dp_contextual_string_curr_size(&dp_contextual_logger);
	}
#ifdef DEBUG
	if (get_dp_contextual_string_curr_size(&dp_contextual_string_data)) {
		llog_write(L_DEBUG, "Contextual data for DPID : '%d' : '%s'\n", dp_resp_params->dpid, get_dp_contextual_string_data(&dp_contextual_string_data));
	}
	if (get_dp_contextual_string_curr_size(&dp_contextual_logger)) {
		llog_write(L_DEBUG, "Contextual logger data for DPID : '%d' : '%s'\n", dp_resp_params->dpid, get_dp_contextual_string_data(&dp_contextual_logger));
	}
#endif
	
	/*
	 * Release memory allocated for storing JSON data.
	 */
	release_dp_contextual_string_data(&dp_contextual_string_data);
	release_dp_contextual_string_data(&dp_contextual_logger);

	return ADS_ERROR_SUCCESS;
}

/*
 * Function creates JSON data for DP, based on campaign-id settings.
 */
int dp_generic_data_creator(dp_data_passing_params_t *params,
	dp_response_params_t *dp_resp_params) {
	/*
	 * Local variables.
	 */
	int i, dpid, retval, ret_check = 0;
	campaign_data_provider_settings_t *dp_settings = NULL;
	campaign_data_provider_segment_type_settings_t *cmpg_dp_seg_stype_settinngs = NULL;
	data_provider_data_t *dp_data = NULL;

#ifdef DEBUG
	llog_write(L_DEBUG, "Inside function : '%s'\n", __FUNCTION__);
#endif

	/*
	 * Check function parameters.
	 */
	if((params == NULL) || (dp_resp_params == NULL)) {
		llog_write(L_DEBUG,"ERROR!!! Invalid parameters : %s:%s:%d\n", __FILE__, __FUNCTION__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	dp_settings = params->dp_settings;
	if ((dp_settings->cmpg_dp_seg_stype_settinngs_count <= 0) || (dp_settings->cmpg_dp_seg_stype_settinngs == NULL)) {
		llog_write(L_DEBUG,"ERROR!!! Invalid arguments : %s:%s:%d\n", __FILE__, __FUNCTION__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	/*
	 * Allocate and init memory for story data.
	 */
	dp_data = (data_provider_data_t *) malloc(sizeof(data_provider_data_t));	
	if(dp_data == NULL) {
		llog_write(L_DEBUG,"ERROR!!! malloc failed for size : '%d', %s:%s:%d\n", (int )sizeof(data_provider_data_t),
							__FILE__, __FUNCTION__, __LINE__);
		return ADS_ERROR_NOMEMORY;
	}
	init_data_provider_data(dp_data);
	*(params->dp_data) = dp_data;

#ifdef DEBUG
	
#endif
	/*
	 * Get DPID.
	 */
	cmpg_dp_seg_stype_settinngs = dp_settings->cmpg_dp_seg_stype_settinngs[0];
	dpid = cmpg_dp_seg_stype_settinngs->data_provider_id;

	for(i=0 ; i<MAX_DP_COUNT ; i++) {
		/*
		 * Find dpid data from response.
		 * Check response size and response recvd flag for DP.
		 */
		if(dp_resp_params[i].dpid == dpid) {
			if((dp_resp_params[i].response_size > 0) && (dp_resp_params[i].response_success_flag ==1)) {
				dp_data->campaign_id = cmpg_dp_seg_stype_settinngs->campaign_id;
				dp_data->data_provider_id = dpid;
				snprintf(dp_data->scope, PAGE_SCOPE_MAX_LEN + 1, "%s", dp_resp_params[i].dp_cont_bp_data.page_scope);
				dp_data->scope[PAGE_SCOPE_MAX_LEN] = '\0';
				snprintf(dp_data->type, PAGE_TYPE_MAX_LEN + 1, "%s", dp_resp_params[i].dp_cont_bp_data.page_type);
				dp_data->type[PAGE_TYPE_MAX_LEN] = '\0';
				dp_data->json_logger_data = strdup(dp_resp_params[i].campaign_format_json);
				dp_data->json_logger_data_len = dp_resp_params[i].campaign_format_json_len;

				/*
				 * Construct contextual data.
				 */
				retval = dp_generic_cont_creator(params, dp_resp_params);
				if (retval == ADS_ERROR_SUCCESS) {
					ret_check = ret_check | 1;
				}
				/*
				 * Construct brand safety data.
				 */
				retval = dp_generic_bp_creator(params, dp_resp_params);
				if (retval == ADS_ERROR_SUCCESS) {
					ret_check = ret_check | 1;
				}

				/*
				 * If none of the contextual or brandsafety data was found return failure.
				 */
				if (ret_check == 0) {
					return ADS_ERROR_INTERNAL;
				} else {
					return ADS_ERROR_SUCCESS;
				}
			} else {
				/*
				 * There was no response from DP.
				 */
#ifdef DEBUG
				llog_write(L_DEBUG, "No response for DPID : '%d'\n", dpid);
#endif
				return ADS_ERROR_DATA_NOT_FOUND;
			}
		}
	}

	/*
	 * Reached here means there was some problem find DPID data.
	 */
#ifdef DEBUG
	llog_write(L_DEBUG, "Some error while finding response for DPID : '%d'\n", dpid);
#endif

	return ADS_ERROR_INTERNAL;
}

int dp_get_dpid_response(int dpid,
	data_provider_logger_data_params_t *data_provider_logger_data_params) {
	/*
	 * Local variables.
	 */
	dp_response_params_t *dp_resp_params = NULL;
	int i;
	if((data_provider_logger_data_params == NULL) || (data_provider_logger_data_params->dp_resp_params == NULL)) {
		llog_write(L_DEBUG,"ERROR!!! Invalid arguments : %s:%s:%d\n", __FILE__, __FUNCTION__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	dp_resp_params = (dp_response_params_t *) data_provider_logger_data_params->dp_resp_params;
	
	for(i=0 ; i<MAX_DP_COUNT ; i++) {
		if (dp_resp_params[i].dpid == dpid) {
			if ((dp_resp_params[i].campaign_format_json_len > 0) && (dp_resp_params[i].response_success_flag ==1)) {
				if (dp_resp_params[i].campaign_format_json_len > MAX_JSON_DATA_PROVIDER_DATA) {
					llog_write(L_DEBUG, "No sufficient memory for storing DP response for DPID : '%d'\n", dpid);
					return ADS_ERROR_NOMEMORY;
				} else {
					data_provider_logger_data_params->json_data_provider_data_len = dp_resp_params[i].campaign_format_json_len;
					memcpy(data_provider_logger_data_params->json_data_provider_data,
							dp_resp_params[i].campaign_format_json,
							dp_resp_params[i].campaign_format_json_len);

					return ADS_ERROR_SUCCESS;
				}
			} else {
#ifdef DEBUG
				llog_write(L_DEBUG, "No response data found from DP for DPID : '%d'\n", dpid);
#endif
				return ADS_ERROR_INTERNAL;
			}
		}
	}

	return ADS_ERROR_SUCCESS;
}
