/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>

#include "proximic.h"
#include "test_json.h"
#include "dp_error.h"
#include "dp_contextual_util.h"
#include "dp_error.h"
#include "json.h"
#include "json_object_private.h"

int g_datacenter_id = 2;

int main () {
	/*
	 * Local variables.
	 */
	int i, j;
	int retval = DP_ERROR_SUCCESS;
	json_object *px_json_object = NULL;
	dp_cont_bp_data_t dp_cont_bp_data;
	proximic_parse_info_t proximic_parse_info;
	proximic_config_t px_config;
	struct timeval tv1, tv2;
	unsigned long int time_diff;

	/*
	 * Init local data structure.
	 */
	dp_cont_bp_data_init(&dp_cont_bp_data);
	init_proximic_parse_info(&proximic_parse_info);
	init_proximic_config(&px_config);
	strcpy(px_config.responsetype, PROXIMIC_RES_FORMAT);

	gettimeofday(&tv1, NULL);
	for (j=0 ; j<JSON_STR_COUNT; j++) {
		//llog_write(L_DEBUG, "Count : '%d'\n", j);
		for (i=0 ; i<CNT ; i++) {
			/*
			 * Convert the JSON response from proximic to JSON object.
			 */
			px_json_object = json_tokener_parse(json[i]);
			if ((px_json_object == NULL) || (is_error(px_json_object))) {
				llog_write(L_DEBUG, "json_tokener_parse failed for proximic response : '%s', '%s:%s:%d'\n",
								json[i], __FILE__, __FUNCTION__, __LINE__);

				retval = DP_ERROR_INTERNAL;
				goto done;
			}

			/*
			 * Check object type before proceeding. JSON object should be of type 'json_type_object'.
			 * Types like json_type_int, json_type_array, json_type_string are invalid.
			 */
			if (json_object_is_type(px_json_object, json_type_object) == 0) {
				llog_write(L_DEBUG, "Invalid JSON object type for proximic response : '%s', '%s:%s:%d'\n",
								json[i], __FILE__, __FUNCTION__, __LINE__);

				retval = DP_ERROR_INTERNAL;
				goto done;
			}

			retval = proximic_check_response_prerequisites(&px_config, px_json_object, &proximic_parse_info);
			if(retval != DP_ERROR_SUCCESS) {
				llog_write(L_DEBUG, "Error while response prerequisites check: '%s', '%s:%s:%d'\n",
								json[i], __FILE__, __FUNCTION__, __LINE__);
				retval = DP_ERROR_INTERNAL;
				goto done;
			}

			retval = proximic_parse_contextual_response(px_json_object, &dp_cont_bp_data, &proximic_parse_info);
			if(retval != DP_ERROR_SUCCESS) {
				llog_write(L_DEBUG, "Error while parsing proximic response : '%s', '%s:%s:%d'\n",
								json[i], __FILE__, __FUNCTION__, __LINE__);
				retval = DP_ERROR_INTERNAL;
				goto done;
			}

			retval = proximic_parse_bp_response(px_json_object, &dp_cont_bp_data, &proximic_parse_info);
			if(retval != DP_ERROR_SUCCESS) {
				llog_write(L_DEBUG, "Error while parsing proximic response : '%s', '%s:%s:%d'\n",
								json[i], __FILE__, __FUNCTION__, __LINE__);
				retval = DP_ERROR_INTERNAL;
				goto done;
			}
		}
	}
	gettimeofday(&tv2, NULL);
	time_diff = (((tv2.tv_sec * 1000000) + tv2.tv_usec) - ((tv1.tv_sec * 1000000) + tv1.tv_usec)) / 1000;
	llog_write(L_DEBUG, "time in milli sec for %d JSON strings: '%lu'\n", (CNT * JSON_STR_COUNT), time_diff);

	printf("\n");

done:
	return 0;
}
