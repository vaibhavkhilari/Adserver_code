/*
   PubMatic Inc. ("PubMatic") CONFIDENTIAL
   Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"           
#include "db_constants.h"       
#include "db_rt_campaign_config.h"
#include "error.h"
#include "dynamic_dsp_sp_margin.h"
#include "assert.h"
#include "common_util.h"
#include "log_fw.h"
#include "url_categorization.h"

#define GET_DYNAMIC_SP_MARGIN "select lower_price, upper_price, sp_margin from dynamic_campaign_sp_margin where campaign_id = ? order by lower_price ASC;"
#define INITIAL_MARGIN_MAP_SIZE 5

//#define GET_CMPG_SP_INFO "select var_A, var_B, var_D, r, s, t, mode, impr_percentage, algo_v2_percent, cp_boost_factor, cp_boost_var_D from campaign_second_price_info where campaign_id = ? and on_off = 1"
#define GET_CMPG_SP_INFO "select var_A, var_B, var_D, r, s, t, impr_percentage, algo_v2_percent, cp_boost_factor, cp_boost_var_D from campaign_second_price_info where campaign_id = ? and on_off = 1"
//#define GET_CMPG_SP_INFO "select var_A, var_B, var_D, r, s, t, algo_v2_percent, cp_boost_factor, cp_boost_var_D from campaign_second_price_info where campaign_id = ? and on_off = 1"

#define GET_IAS_SETTINGS "select campaign_id , pub_id , enabled_send_pcat_service , enabled_send_bsc_score_service , enabled_bsc_filtering , bsc_score_field , enabled_sam_filtering , sam_score_field  from  publisher_ias_preferences  where pub_id in( ? ,0 )  order by campaign_id , pub_id  ASC"

#define GET_BID_BOOST_SETTINGS "select bid_boost_factor , disable_pubmatic_cut from  publisher_camp_bid_boost_settings where pub_id in ( ? ,'0' )  and campaign_id = ? and is_deleted =0 order by  pub_id  DESC limit 1"


#define INITIAL_SETTINGS_SIZE 20

#define ENABLED 1 
#define DISABLED 0
#define UNKNOWN -1

int db_get_campaign_dynamic_sp_margin( 	db_connection_t *dbconn,
		dsp_sp_margin_map_t **margin_map,
		long campaign_id,
		size_t *no_of_records) {

	int retval = DB_ERROR_SUCCESS;
	dsp_sp_margin_map_t *ret_map = NULL, *tmp_map = NULL;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	SQLINTEGER s_campaign_id = 0;
	SQLLEN cb_s_campaign_id = 0;

	SQLDOUBLE s_lower_price;
	SQLLEN cb_s_lower_price = 0;

	SQLDOUBLE s_upper_price;
	SQLLEN cb_s_upper_price = 0;

	SQLDOUBLE s_sp_margin = 0;
	SQLLEN cb_s_sp_margin = 0;

	int use_count = 0, alloc_count = 0;

	(*no_of_records) = 0;

#ifdef DSPM_DEBUG
	assert((*margin_map) == NULL);
#endif
	(*margin_map) = NULL;


	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	strncpy((char *) sql_statement, GET_DYNAMIC_SP_MARGIN, MAX_SQL_QUERY_STR_LEN );
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';


	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}

	/* Bind parameters : campaign_id */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_campaign_id, 0, &cb_s_campaign_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}
	s_campaign_id = campaign_id;

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);

	if (sql_retval == SQL_SUCCESS) {

		/* Bind Column : upper_price */
		sql_retval = SQLBindCol(statement_handle, 1, SQL_C_DOUBLE, &s_lower_price, 0, &cb_s_lower_price);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : lower_price */
		sql_retval = SQLBindCol(statement_handle, 2, SQL_C_DOUBLE, &s_upper_price, 0, &cb_s_upper_price);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : sp_margin */
		sql_retval = SQLBindCol(statement_handle, 3, SQL_C_DOUBLE, &s_sp_margin, 0, &cb_s_sp_margin);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		//Fetch records from db and populate margin map
		alloc_count = INITIAL_MARGIN_MAP_SIZE;
		ret_map = (dsp_sp_margin_map_t *)malloc( sizeof(dsp_sp_margin_map_t)*alloc_count);

		if ( ret_map == NULL ) {
			llog_write(L_DEBUG, "ERROR: Out of Memory %s:%d\n", __FILE__, __LINE__);
			retval = DB_ERROR_NO_MEMORY;
			goto done;
		}

		while (sql_retval != SQL_NO_DATA)
		{
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {

				if (use_count == alloc_count) {
					alloc_count *= 2;
					tmp_map =(dsp_sp_margin_map_t *) realloc(ret_map, sizeof(dsp_sp_margin_map_t) * alloc_count);
					if (tmp_map == NULL) {
						if (ret_map != NULL) {
							free(ret_map);
							ret_map = NULL;
						}
						retval = DB_ERROR_NO_MEMORY;
						use_count = 0;
						goto done;
					}
					ret_map = tmp_map;
				}
				ret_map[use_count].upper_price = s_upper_price;
				ret_map[use_count].lower_price = s_lower_price;
				ret_map[use_count].sp_margin = s_sp_margin;
				use_count += 1;

#ifdef DSPM_DEBUG
				llog_write(L_DEBUG,"\nDSPM: IN DB CALL->LP:%f,UP:%f,SPM:%f",s_lower_price,s_upper_price,s_sp_margin);
#endif
			}
		}
	} else {
		llog_write(L_DEBUG, "Error executing select statement, %s:%d\n",__FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}

done:
	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	(*margin_map) = ret_map;
	(*no_of_records) = use_count;
	return retval;
}

int db_get_cmpg_sp_info(
		db_connection_t* dbconn,
		cmpg_sp_info_t** sp_info,
		int campaign_id
		)
{

	int retval = DB_ERROR_SUCCESS;
	cmpg_sp_info_t* ret_map = NULL;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	SQLINTEGER s_campaign_id = 0;
	SQLLEN cb_s_campaign_id = 0;

	SQLINTEGER s_impr_percentage = 0;
	SQLLEN cb_s_impr_percentage = 0;

	SQLINTEGER s_algo_v2_percent = 0;
	SQLLEN cb_s_algo_v2_percent = 0;

	SQLDOUBLE s_var_A;
	SQLLEN cb_s_var_A = 0;

	SQLDOUBLE s_var_B;
	SQLLEN cb_s_var_B = 0;

	SQLDOUBLE s_var_D;
	SQLLEN cb_s_var_D = 0;

	SQLDOUBLE s_var_r;
	SQLLEN cb_s_var_r = 0;

	SQLDOUBLE s_var_s;
	SQLLEN cb_s_var_s = 0;

	SQLDOUBLE s_var_t;
	SQLLEN cb_s_var_t = 0;

	SQLDOUBLE s_cp_boost_factor;
	SQLLEN cb_cp_boost_factor = 0;

	SQLDOUBLE s_cp_boost_var_D;
	SQLLEN cb_cp_boost_var_D = 0;

	int record_found = 0;

	(*sp_info) = NULL;


	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	strncpy((char *) sql_statement, GET_CMPG_SP_INFO, MAX_SQL_QUERY_STR_LEN );
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';


	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		LOG_CRITICAL(SQL_PREPARE_FAILED, MOD_DEFAULT);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}

	/* Bind parameters : campaign_id */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_campaign_id, 0, &cb_s_campaign_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("\nError binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}
	s_campaign_id = campaign_id;

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);

	if (sql_retval == SQL_SUCCESS) {
		/* Bind Column : var_A */
		sql_retval = SQLBindCol(statement_handle, 1, SQL_C_DOUBLE, &s_var_A, 0, &cb_s_var_A);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : var_B */
		sql_retval = SQLBindCol(statement_handle, 2, SQL_C_DOUBLE, &s_var_B, 0, &cb_s_var_B);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : var_D */
		sql_retval = SQLBindCol(statement_handle, 3, SQL_C_DOUBLE, &s_var_D, 0, &cb_s_var_D);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}
		/* Bind Column : var_r */
		sql_retval = SQLBindCol(statement_handle, 4, SQL_C_DOUBLE, &s_var_r, 0, &cb_s_var_r);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}
		/* Bind Column : var_s */
		sql_retval = SQLBindCol(statement_handle, 5, SQL_C_DOUBLE, &s_var_s, 0, &cb_s_var_s);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}
		/* Bind Column : var_t */
		sql_retval = SQLBindCol(statement_handle, 6, SQL_C_DOUBLE, &s_var_t, 0, &cb_s_var_t);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : impr_percentage */
		sql_retval = SQLBindCol(statement_handle, 7, SQL_C_LONG, &s_impr_percentage, 0, &cb_s_impr_percentage);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : algo_v2_percent */
		sql_retval = SQLBindCol(statement_handle, 8, SQL_C_LONG, &s_algo_v2_percent, 0, &cb_s_algo_v2_percent);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : cp_boost_factor */
		sql_retval = SQLBindCol(statement_handle, 9, SQL_C_DOUBLE, &s_cp_boost_factor, 0, &cb_cp_boost_factor);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}
		/* Bind Column : boost_var_D */
		sql_retval = SQLBindCol(statement_handle, 10, SQL_C_DOUBLE, &s_cp_boost_var_D, 0, &cb_cp_boost_var_D);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		ret_map = (cmpg_sp_info_t*) malloc(sizeof(cmpg_sp_info_t));

		if (ret_map == NULL) {
			LOG_FATAL(MEMORY_ALLOC_FAILED, MOD_DEFAULT, __FILE__,__LINE__);
			retval = DB_ERROR_NO_MEMORY;
			goto done;
		}
		/*
		 * This is not a while loop since campaign_id is primary key and hence would execute only once
		 */

		while (sql_retval != SQL_NO_DATA)
		{
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {
				ret_map->var_A = s_var_A;
				ret_map->var_B = s_var_B;
				/*
				 * If var_D = 0.0 or -ve, log(1 + var_D) would be -ve
				 * Don't want a bad value in DB to result in application
				 * crashes (^_-)
				 */
				ret_map->var_D = (s_var_D > 0.0)?s_var_D:0.08;
				ret_map->r = s_var_r;
				ret_map->s = s_var_s;
				ret_map->t = s_var_t;
				//ret_map->mode = s_mode;
				ret_map->impr_percentage = s_impr_percentage;
				// In case of incorrect db entry, Just ignore this algorithm
				ret_map->algo_v2_percent = (s_algo_v2_percent >= 0 && s_algo_v2_percent <=100)?s_algo_v2_percent:0;
				ret_map->cp_boost_factor = (s_cp_boost_factor >= 0.0)?s_cp_boost_factor :1.0;
				ret_map->cp_boost_var_D = (s_cp_boost_var_D > 0.0)?s_cp_boost_var_D:0.025;
				record_found = 1;
			}
		}
	} else {
		llog_write(L_DEBUG, "\nError executing select statement, %s:%d\n",__FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}

done:
	// Free The SQL Statement Handle
	if (statement_handle != NULL) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	if (record_found == 0) {
		/*
		 * free(NULL) is valid
		 * but still :(
		 */
		if (ret_map != NULL) {
			free(ret_map);
		}
		ret_map = NULL;
	}
	(*sp_info) = ret_map;
	return retval;
}


int db_get_bid_boost_settings( db_connection_t *dbconn , bid_boost_settings_t *settings,long pub_id , int camp_id) {


	int retval = DB_ERROR_SUCCESS;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	
	SQLINTEGER s_campaign_id = 0;
	SQLLEN cb_s_campaign_id = 0;

	SQLINTEGER s_pub_id = 0;
	SQLLEN cb_s_pub_id = 0;

	SQLINTEGER s_disable_pubmatic_cut = 0;
	SQLLEN cb_s_disable_pubmatic_cut = 0;

	SQLDOUBLE s_bid_boost_factor = -1.0;
	SQLLEN cb_s_bid_boost_factor = 0;


	/* this will serve the purpose of dummy*/
	settings->bid_boost_factor = -1.0;
	settings->campaign_id = camp_id;


	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	nstrcpy((char *) sql_statement, GET_BID_BOOST_SETTINGS, MAX_SQL_QUERY_STR_LEN );
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';


	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}

	/* Bind parameters : pub_id */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}

	/*Bind parameter : camp_id */
	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
	SQL_INTEGER, 0, 0, &s_campaign_id , 0, &cb_s_campaign_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
  db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
	retval = DB_ERROR_INTERNAL;
	goto done;
	}



	s_pub_id = pub_id;
	s_campaign_id = camp_id;

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);
	
	if (sql_retval == SQL_SUCCESS) {

		/* Bind Column : campaign id */
		sql_retval = SQLBindCol(statement_handle , 1 , SQL_C_DOUBLE , &s_bid_boost_factor, 0 , &cb_s_bid_boost_factor );
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		sql_retval = SQLBindCol(statement_handle , 2 , SQL_C_LONG , &s_disable_pubmatic_cut , 0 , &cb_s_disable_pubmatic_cut );
                if (sql_retval != SQL_SUCCESS) {
                        db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                        retval = DB_ERROR_INTERNAL;
                        goto done;
                }
	



		
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {
				
				settings->bid_boost_factor = s_bid_boost_factor;
				settings->campaign_id = camp_id;
				settings->disable_pubmatic_cut = s_disable_pubmatic_cut;

#ifdef DEBUG
			llog_write(L_DEBUG,"\nFROM DB :BID factor id:%f,campId:%d,disable_pubmatic_cut:%d\n", settings->bid_boost_factor,settings->campaign_id,settings->disable_pubmatic_cut);
#endif
		
		}
	}
	else {
		llog_write(L_DEBUG, "Error executing select statement, %s:%d\n",__FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}
done:
	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	return retval;
}



int db_get_integral_settings( db_connection_t *dbconn,integral_settings_t **settings,long pub_id,size_t *no_of_records) {
	int retval = DB_ERROR_SUCCESS;
	integral_settings_t *ret_settings = NULL, *tmp_settings = NULL;
	db_integral_settings_t temp_db ;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	
	SQLINTEGER s_campaign_id = 0;
	SQLLEN cb_s_campaign_id = 0;

	SQLINTEGER s_pub_id = 0;
	SQLLEN cb_s_pub_id = 0;

	SQLINTEGER s_publisher_result_id = 0;
	SQLLEN cb_s_publisher_result_id = 0;

	SQLINTEGER s_enabled_send_pcat_service = 0;
	SQLLEN cb_s_enabled_send_pcat_service = 0;

	SQLINTEGER s_enabled_send_bsc_score_service = 0;
	SQLLEN cb_s_enabled_send_bsc_score_service = 0;

	SQLINTEGER s_enabled_bsc_filtering  = 0;
	SQLLEN cb_s_enabled_bsc_filtering  = 0;

	SQLINTEGER s_bsc_score_field = 0;
	SQLLEN cb_s_bsc_score_field = 0;

	SQLINTEGER s_enabled_sam_filtering = 0;
	SQLLEN cb_s_enabled_sam_filtering = 0;

	SQLINTEGER s_sam_score_field = 0;
	SQLLEN cb_s_sam_score_field = 0;

	int use_count = 0, alloc_count = 0;

	(*no_of_records) = 0;

#ifdef URLCAT_DEBUG
	assert((*settings) == NULL);
#endif
	(*settings) = NULL;


	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	nstrcpy((char *) sql_statement, GET_IAS_SETTINGS, MAX_SQL_QUERY_STR_LEN );
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';


	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}

	/* Bind parameters : pub_id */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}
	s_pub_id = pub_id;
	SQLLEN key_count;

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);
	
	/* get the row count and check if it is -1
	 */

	SQLRowCount(statement_handle, &key_count);
	if ( (int)key_count < 0 ) {
		key_count = INITIAL_SETTINGS_SIZE;
	}
	if (sql_retval == SQL_SUCCESS) {

		/* Bind Column : campaign id */
		sql_retval = SQLBindCol(statement_handle, 1, SQL_C_ULONG, &s_campaign_id, 0, &cb_s_campaign_id);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : publisher_id */
		sql_retval = SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_publisher_result_id , 0, &cb_s_publisher_result_id );
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}


		/* Bind Column : enable pcat service */
		sql_retval = SQLBindCol( statement_handle, 3 ,  SQL_C_ULONG , &s_enabled_send_pcat_service, 0 , &cb_s_enabled_send_pcat_service );
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : enabled_send_bsc_score_service */
		sql_retval = SQLBindCol(statement_handle, 4 , SQL_C_ULONG, &s_enabled_send_bsc_score_service, 0, &cb_s_enabled_send_bsc_score_service );
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : bsc_score_field */
		sql_retval = SQLBindCol(statement_handle, 5 , SQL_C_ULONG, &s_enabled_bsc_filtering , 0, &cb_s_enabled_bsc_filtering );
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;
		}



		/* Bind Column : bsc_score_field */
		sql_retval = SQLBindCol(statement_handle, 6 , SQL_C_ULONG, &s_bsc_score_field , 0, &cb_s_bsc_score_field );
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;        
		} 


		/* Bind Column : enabled_sam_filtering */
		sql_retval = SQLBindCol(statement_handle, 7 , SQL_C_ULONG, &s_enabled_sam_filtering , 0, &cb_s_enabled_sam_filtering );
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;     
		}

		/* Bind Column : sam_score_field */
		sql_retval = SQLBindCol(statement_handle, 8 , SQL_C_ULONG, &s_sam_score_field , 0, &cb_s_sam_score_field );
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = DB_ERROR_INTERNAL;
			goto done;     
		}



		//Fetch records from db and populate ias settigns
		alloc_count = key_count;
		ret_settings = (integral_settings_t *)malloc( sizeof(integral_settings_t)*alloc_count);

		if ( ret_settings == NULL ) {
			llog_write(L_DEBUG, "ERROR: Out of Memory %s:%d\n", __FILE__, __LINE__);
			retval = DB_ERROR_NO_MEMORY;
			goto done;
		}

		while (sql_retval != SQL_NO_DATA)
		{
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {

				if (use_count == alloc_count) {
					alloc_count *= 2;
					tmp_settings = (integral_settings_t *)realloc(ret_settings, sizeof(integral_settings_t) * alloc_count);
					if (tmp_settings == NULL) {
						if (ret_settings != NULL) {
							free(ret_settings);
							ret_settings = NULL;
						}
						retval = DB_ERROR_NO_MEMORY;
						use_count = 0;
						goto done;
					}
					ret_settings = tmp_settings;
				}

				/*
				 * case pub_id = 0 
				 * store data in integral array 
				 * and also in temp setting 
				 */

				if ( s_publisher_result_id == 0  || s_campaign_id != temp_db.campaign_id) {
					/*
					 * storing data in integral array
					 */
					ret_settings[use_count].enabled_ias_services = 0;
					ret_settings[use_count].score_field = 0 ;
					ret_settings[use_count].campaign_id = s_campaign_id ;
					//ret_settings[use_count].pub_id = s_publisher_result_id ;
					if ( s_enabled_send_pcat_service == ENABLED ) {
						ret_settings[use_count].enabled_ias_services +=  PAGE_CAT_MAP ;
					} 
					if ( s_enabled_send_bsc_score_service == ENABLED  ) {
						ret_settings[use_count].enabled_ias_services += BSC_MAP ;
					}
					if ( s_enabled_bsc_filtering == ENABLED ) {
						ret_settings[use_count].enabled_ias_services += BSC_FLT_MAP ;
						ret_settings[use_count].score_field = s_bsc_score_field ;
						ret_settings[use_count].score_field <<= 8 ;
					}
					if ( s_enabled_sam_filtering == ENABLED ) {	
						ret_settings[use_count].enabled_ias_services += SAM_FLT_MAP ;
						ret_settings[use_count].score_field |= s_sam_score_field ;
					} 

					/* store it in temp since pub_id == 0 */
					if (  s_publisher_result_id == 0  ) {
						temp_db.campaign_id = s_campaign_id;
						temp_db.pub_id = s_publisher_result_id ;
						temp_db.enabled_send_pcat_service  = s_enabled_send_pcat_service ;
						temp_db.enabled_send_bsc_score_service = s_enabled_send_bsc_score_service;
						temp_db.enabled_bsc_filtering = s_enabled_bsc_filtering ;
						temp_db.bsc_score_field =  s_bsc_score_field;
						temp_db.enabled_sam_filtering =  s_enabled_sam_filtering;
						temp_db.sam_score_field =  s_sam_score_field;
					}
					use_count ++ ;
					continue ;
				} else  

					/*
					 * case where specific setting is found after global setting
					 */

					if ( s_campaign_id == temp_db.campaign_id ) {
						// fill camp pub_id directly and init enabled ias services and score field
						ret_settings[use_count -1 ].enabled_ias_services = 0 ;
						ret_settings[use_count -1 ].score_field = 0 ;
						ret_settings[use_count -1 ].campaign_id = s_campaign_id ;
						//ret_settings[use_count].pub_id = s_publisher_result_id ;
						if ( s_enabled_send_pcat_service == ENABLED || 
								( s_enabled_send_pcat_service == UNKNOWN && temp_db.enabled_send_pcat_service == ENABLED ))	{
							ret_settings[use_count - 1 ].enabled_ias_services += PAGE_CAT_MAP ; 
						} 
						if ( s_enabled_send_bsc_score_service == ENABLED ||
								( s_enabled_send_bsc_score_service == UNKNOWN && temp_db.enabled_send_bsc_score_service == ENABLED )) {
							ret_settings[use_count - 1].enabled_ias_services += BSC_MAP ;
						}

						if ( s_enabled_bsc_filtering == ENABLED ) {
								ret_settings[use_count - 1 ].score_field = s_bsc_score_field ;
								ret_settings[use_count -1 ].score_field <<= 8 ;
								ret_settings[use_count - 1].enabled_ias_services += BSC_FLT_MAP ;
						} else if 
								(	s_enabled_bsc_filtering == UNKNOWN && temp_db.enabled_bsc_filtering == ENABLED ) {
							ret_settings[use_count -1 ].score_field = temp_db.bsc_score_field ;
							ret_settings[use_count -1 ].score_field <<= 8 ;
							ret_settings[use_count - 1].enabled_ias_services += BSC_FLT_MAP ;
						}
						if ( s_enabled_sam_filtering == ENABLED ) {
								ret_settings[use_count -1 ].score_field |= s_sam_score_field ;
								ret_settings[use_count - 1].enabled_ias_services += SAM_FLT_MAP ;
						}
						else if	( s_enabled_sam_filtering == UNKNOWN && temp_db.enabled_sam_filtering == ENABLED ) {
							ret_settings[use_count -1].score_field |= temp_db.sam_score_field ;
							ret_settings[use_count - 1].enabled_ias_services += SAM_FLT_MAP ;
						}
					} /*else  {
						
						 *case where only specfic setting is found
						 
						ret_settings[use_count].enabled_ias_services = 0;
						ret_settings[use_count].score_field = 0 ;
						ret_settings[use_count].campaign_id = s_campaign_id ;
						//ret_settings[use_count].pub_id = s_publisher_result_id ;
						if ( s_enabled_send_pcat_service == ENABLED ) {
							ret_settings[use_count].enabled_ias_services += PAGE_CAT_MAP ;
						}
						if ( s_enabled_send_bsc_score_service == ENABLED  ) {
							ret_settings[use_count].enabled_ias_services += BSC_MAP ;
						}
						if ( s_enabled_bsc_filtering == ENABLED ) {
							ret_settings[use_count].score_field = s_bsc_score_field ;
							ret_settings[use_count].score_field <<= 8 ;
							ret_settings[use_count].enabled_ias_services += BSC_FLT_MAP ;
						}
						if ( s_enabled_sam_filtering == ENABLED ) {
							ret_settings[use_count].score_field |= s_sam_score_field ;
							ret_settings[use_count].enabled_ias_services += SAM_FLT_MAP ;
						}

						use_count++ ;

					}*/
			}
#ifdef DEBUG
			llog_write(L_DEBUG,"\nUCAT: IN DB CALL->Cid:%d,BITMAP:%d,SCORE_FIELD:%d", s_campaign_id, s_enabled_send_bsc_score_service ,s_bsc_score_field);
#endif
		}
	}
	else {
		llog_write(L_DEBUG, "Error executing select statement, %s:%d\n",__FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		retval = DB_ERROR_INTERNAL;
		goto done;
	}
#ifdef DEBUG
	int z =0;
	for ( z = 0; z < use_count ; z++ ) {
		llog_write(L_DEBUG,"\nUUCAT: IN DB CALL->Cid:%d,pcat:%d,SCORE_FIELD:%ld", ret_settings[z].campaign_id, ret_settings[z].enabled_ias_services, ret_settings[z].score_field );
	}
#endif 
done:
	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	(*settings) = ret_settings;
	(*no_of_records) = use_count;
	return retval;
}
