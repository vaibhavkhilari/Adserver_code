/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_rt_campaign_config.h"
#include "db_get_bloom_filters.h"
#include "error.h"
#include "bloom_filter.h"
#include "log_fw.h"
/* 
	here, ORDER BY site_id DESC LIMIT 1 ensures that if bloom filter of specified site exists then it will be fetched 
	o.w. bloom filter of site id 0 i.e. ALL will be fetched 
*/


int db_get_bloom_filters(db_connection_t *dbconn,
				const char *db_query,
				BLOOM** out_bloom_filter,
				int *bloom_count,
				size_t *ret_size,
				const long pub_id,
				const long site_id){
	/* Local variables */
	int retval = ADS_ERROR_SUCCESS;
	size_t memcache_obj_size = 0;
	BLOOM* bloom = NULL;	
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLINTEGER s_pub_id=0;
	SQLLEN cb_s_pub_id=0;
	SQLINTEGER s_site_id=0;
	SQLLEN cb_s_site_id=0;

	SQLCHAR s_bloom_list[BIT_ARRAY_SIZE+1] ;
	SQLLEN cb_s_bloom_list = SQL_NTS;
	SQLINTEGER s_element_count=0;
	SQLLEN cb_s_element_count=0;
	SQLINTEGER s_bloom_version=0;
	SQLLEN cb_s_bloom_version=0;

	int destroy_bloom=0;
	int i=0;
	ret_size[0] = 0;
	out_bloom_filter[0] = NULL;
	int bloom_index=0;
	BLOOM* tbloom=NULL;

	*bloom_count = 0;

	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	strncpy((char *) sql_statement, db_query, MAX_SQL_QUERY_STR_LEN );
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = ADS_ERROR_INTERNAL;
		goto done;
	}

	/* Bind parameters : pub_id */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = ADS_ERROR_INTERNAL;
		goto done;
	}
	s_pub_id = pub_id;	

	/* Bind parameters : site_id */
	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_s_site_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = ADS_ERROR_INTERNAL;
		goto done;
	}
	s_site_id = site_id;	

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);
	if (sql_retval == SQL_SUCCESS) {

		sql_retval = SQLBindCol(statement_handle, 1, SQL_C_BINARY, s_bloom_list, BIT_ARRAY_SIZE, &cb_s_bloom_list);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = ADS_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : blocked/whitelisted domain count */
		sql_retval = SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_element_count, 0, &cb_s_element_count);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = ADS_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : bloom version for backward compatibility : 0:old-single, 1:serialized-multi */
		sql_retval = SQLBindCol(statement_handle, 3, SQL_C_ULONG, &s_bloom_version, 0, &cb_s_bloom_version);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = ADS_ERROR_INTERNAL;
			goto done;
		}
		
		/* Fetch Result */
		sql_retval = SQLFetch(statement_handle);
		if (sql_retval == SQL_NO_DATA) {
			LOG_INFO(LPF_DB_INFO,MOD_DEFAULT,pub_id,site_id,__FILE__,__LINE__);
			retval = ADS_ERROR_SUCCESS;
			goto done;
		}
	}
	else {
		//LOG_FATAL()
		llog_write(L_DEBUG, "Error executing select statement, %s:%d\n",__FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		retval = ADS_ERROR_INTERNAL;
		goto done;
	}

	if(cb_s_bloom_list==SQL_NULL_DATA || cb_s_bloom_list==0 || s_element_count <= 0){
		retval = ADS_ERROR_SUCCESS;
		goto done;
	}

	if(s_bloom_version > 0) {
		tbloom=(BLOOM*)s_bloom_list;
		
		while(MAX_ALLOWED_BLOOMS>bloom_index && cb_s_bloom_list>0) {
			if(!(bloom = bloom_create((int)tbloom->nelements, &memcache_obj_size))){
				retval = ADS_ERROR_NOMEMORY;
				destroy_bloom=1;
				goto done;
			}
			memcpy(bloom,(unsigned char *)tbloom, memcache_obj_size);
			ret_size[bloom_index] = memcache_obj_size;
			out_bloom_filter[bloom_index] = bloom;
			bloom_index++;
			tbloom = (BLOOM*)(((char*)tbloom)+memcache_obj_size);
			cb_s_bloom_list-=memcache_obj_size;
		}
	}
	else {
		if(!(bloom = bloom_create((int)s_element_count, &memcache_obj_size))) {
			llog_write(L_DEBUG, "\nERROR: Could not create bloom filter for pub:%ld,site:%ld %s:%d\n", pub_id, site_id, __FILE__, __LINE__);
			retval = ADS_ERROR_NOMEMORY;
			goto done;
		}
		cb_s_bloom_list = (cb_s_bloom_list < BIT_ARRAY_SIZE) ? cb_s_bloom_list : BIT_ARRAY_SIZE;
		unsigned char* bit_array = (unsigned char*)&((bloom)[1]);
		memcpy(bit_array, (unsigned char *)s_bloom_list,	cb_s_bloom_list);
		ret_size[bloom_index] = memcache_obj_size;
		out_bloom_filter[bloom_index] = bloom;
		bloom_index++;
	}

	*bloom_count=bloom_index;

done:
	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	if(destroy_bloom){
		for(i=0; i<bloom_index;i++)
			bloom_destroy(&out_bloom_filter[i]);
		*bloom_count=0;
		llog_write(L_DEBUG, "\nERROR: Could not create bloom filter for pub:%ld,site:%ld %s:%d\n", pub_id, site_id, __FILE__, __LINE__);
	}
	return retval;
}
