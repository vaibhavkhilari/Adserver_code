/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_rt_campaign_config.h"
#include "db_get_bkt_bloom_filters.h"
#include "error.h"
#include "bloom_filter.h"
#include "bkt_bloom_filter.h"
#include "log_fw.h"

/* Fetches bkt_bloom filter from DB for given arguments. */
int db_get_bkt_bloom_filters(db_connection_t *dbconn,
		const char *db_query,
		BKT_BLOOM** out_bloom_filter,
		int *bloom_count,
		size_t *ret_size,
		char *update_time,
		int max_bloom_count) {
	int retval = ADS_ERROR_SUCCESS;
	int i = 0;
	int bloom_index = 0;
	size_t memcache_obj_size = 0;
	BKT_BLOOM* tbloom = NULL;
	BKT_BLOOM* bloom = NULL;

	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLCHAR *s_bloom_list = NULL;
	SQLLEN cb_s_bloom_list = SQL_NTS;
	SQLINTEGER s_element_count=0;
	SQLLEN cb_s_element_count=0;
	SQLINTEGER s_bloom_version=0;
	SQLLEN cb_s_bloom_version=0;
	SQLCHAR s_update_time[MAX_TIMESTAMP_SIZE_YYYYMMDD + 1];
	SQLLEN cb_s_update_time = 0;

	/* Initialize out params */
	*bloom_count = 0;
	ret_size[0] = 0;
	out_bloom_filter[0] = NULL;

	do {
		/* Check passed max bloom count is valid */
		if (1 > max_bloom_count || MAX_GIANT_BLOOM_COUNT_FOR_GLOBAL < max_bloom_count) {
			ERROR_LOG("Max bloom count passed to function is not supported, %d", max_bloom_count);
			retval = ADS_ERROR_INVALID_ARGS;
			break;
		}

		/* Allocate memory for bloom list fetched from DB */
		long mem_needed = MAX_PER_BLOOM_DB_SIZE * max_bloom_count;
		s_bloom_list = (SQLCHAR *) malloc(sizeof(SQLCHAR) * mem_needed);
		if (NULL == s_bloom_list) {
			ERROR_LOG("Not enough memory.");
			retval = ADS_ERROR_NOMEMORY;
			break;
		}

		/* Allocate the statement handle */
		SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

		/* Create SQL char string which contains the query */
		strncpy((char *) sql_statement, db_query, MAX_SQL_QUERY_STR_LEN );
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		/* Create a prepared statement */
		sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
		if (SQL_SUCCESS != sql_retval) {
			ERROR_LOG("SQLPrepare failed.");
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
			retval = ADS_ERROR_INTERNAL;
			break;
		}

		sql_retval = SQLExecute(statement_handle);
		if (SQL_SUCCESS == sql_retval) {

			/* Bind Column : bkt_bloom in binary format */
			sql_retval = SQLBindCol(statement_handle, 1, SQL_C_BINARY, s_bloom_list, mem_needed, &cb_s_bloom_list);
			if (SQL_SUCCESS != sql_retval) {
				db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
				retval = ADS_ERROR_INTERNAL;
				break;
			}

			/* Bind Column : blocked/whitelisted domain count */
			sql_retval = SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_element_count, 0, &cb_s_element_count);
			if (SQL_SUCCESS != sql_retval) {
				db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
				retval = ADS_ERROR_INTERNAL;
				break;
			}

			/* Bind Column : bloom version for backward compatibility : 0:old-single, 1:serialized-multi 2: bkt_bloom */
			sql_retval = SQLBindCol(statement_handle, 3, SQL_C_ULONG, &s_bloom_version, 0, &cb_s_bloom_version);
			if (SQL_SUCCESS != sql_retval) {
				db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
				retval = ADS_ERROR_INTERNAL;
				break;
			}

			/* Bind Column : update_time */
			sql_retval = SQLBindCol(statement_handle, 4, SQL_C_CHAR, &s_update_time, MAX_TIMESTAMP_SIZE_YYYYMMDD, &cb_s_update_time);
			if (SQL_SUCCESS != sql_retval) {
				db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
				retval = ADS_ERROR_INTERNAL;
				break;
			}

			/* Fetch Result */
			sql_retval = SQLFetch(statement_handle);
			/* If no data available then return SUCCESS */
			if ((SQL_NO_DATA == sql_retval) || (SQL_NULL_DATA == cb_s_bloom_list) ||
					(0 == cb_s_bloom_list) || (s_element_count <= 0)) {
				LOG_INFO(LPF_DB_INFO, MOD_DEFAULT, __FILE__, __LINE__);
				retval = ADS_ERROR_SUCCESS;
				break;
			}

			/* Bloom version 2 is for bkt_bloom */
			if (2 == s_bloom_version) {
				tbloom=(BKT_BLOOM*)s_bloom_list;
				/* Build bkt_bloom */
				while (MAX_ALLOWED_BKT_BLOOMS > bloom_index && cb_s_bloom_list > 0) {
					if (!(bloom = bkt_bloom_create((int)tbloom->nelements, &memcache_obj_size))) {
						retval = ADS_ERROR_NOMEMORY;
						/* Bloom creation failed, do cleanup */
						for (i=0; i<bloom_index; i++) {
							bkt_bloom_destroy(&out_bloom_filter[i]);
						}
						bloom_index = 0;
						ERROR_LOG("Failed to create bkt_bloom filter.");
						break;
					}
					/* copy bloom to allocated bkt_bloom memory space */
					memcpy(bloom,(unsigned char *)tbloom, memcache_obj_size);
					ret_size[bloom_index] = memcache_obj_size;
					out_bloom_filter[bloom_index] = bloom;
					bloom_index++;
					tbloom = (BKT_BLOOM*)(((char*)tbloom)+memcache_obj_size);
					cb_s_bloom_list-=memcache_obj_size;
				}
			}

			if (bloom_index > 0 && cb_s_update_time > 0) {
				*bloom_count = bloom_index;
				strncpy(update_time, (const char *)s_update_time, MAX_TIMESTAMP_SIZE_YYYYMMDD);
			}

		} else {
			ERROR_LOG("SQLExecute failed.");
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval, __LINE__, __FILE__);
			retval = ADS_ERROR_INTERNAL;
			break;
		}

	} while (0);

	if (0 != statement_handle) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}

	if (s_bloom_list) {
		free(s_bloom_list);
		s_bloom_list = NULL;
	}

	return retval;
}

/* This function fetches the global bloom from DB, if there is any modification in bloom since last fetch.
 * If there is no modification, this function will return SUCCESS and out_bloom_array will remain NULL */
int db_get_global_bkt_bloom_filter(db_connection_t *dbconn,
		const char *db_query,
		char *update_time,
		BKT_BLOOM_ARRAY **out_bloom_array,
		int max_bloom_count) {
	int ret_val = ADS_ERROR_SUCCESS;
	size_t ret_list_size[MAX_ALLOWED_BKT_BLOOMS];
	BKT_BLOOM_ARRAY *tmp_global_bloom = NULL;
	char sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	(*out_bloom_array) = NULL;

	do {
		/* Allocate memory for bkt bloom array */
		tmp_global_bloom = bkt_bloom_array_create();
		if (NULL == tmp_global_bloom) {
			ERROR_LOG("Malloc failed.");
			ret_val = ADS_ERROR_NOMEMORY;
			break;
		}

		/* Prepare query with required update timestamp */
		snprintf(sql_statement, MAX_SQL_QUERY_STR_LEN, db_query, update_time);
		INFO_LOG("GLOBAL_BLOOM::Executing Query: %s", sql_statement);

		/* Fetch global bloom from db */
		ret_val = db_get_bkt_bloom_filters(dbconn,
				sql_statement,
				tmp_global_bloom->bkt_bloom,
				&(tmp_global_bloom->bkt_bloom_count),
				ret_list_size,
				update_time,
				max_bloom_count);

		if (ADS_ERROR_SUCCESS != ret_val) {
			bkt_bloom_array_destroy(&tmp_global_bloom);
			ERROR_LOG("db_get_bkt_bloom_filters failed. error_code: %d", ret_val);
			break;
		}

		/* There is modification in bloom since last fetch */
		if ((NULL != tmp_global_bloom->bkt_bloom[0]) && (0 < tmp_global_bloom->bkt_bloom_count)) {
			(*out_bloom_array) = tmp_global_bloom;
		} else { /* There is no modification in bloom since last fetch */
			bkt_bloom_array_destroy(&tmp_global_bloom);
		}
	} while (0);

	return ret_val;
}
