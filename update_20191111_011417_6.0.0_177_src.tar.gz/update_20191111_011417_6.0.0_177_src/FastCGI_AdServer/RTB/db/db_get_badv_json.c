/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_url_blocklist.h"
#include "db_error.h"
#include "db_constants.h"
#include "stdlib.h"
#include <sys/time.h>
#include <errno.h>
#include "log_fw.h"


#define GET_BADV_DOMAIN_JSON "select badv_domain_json from publisher_campaign_badv_domain where pub_id=? and site_id in ('0',?) and campaign_id in ( '0', ? ) order by site_id desc , campaign_id desc limit 1"

// Caller should free the string
char *db_get_badv_domain_json( db_connection_t *dbconn, int pub_id, int site_id,int campaign_id){
	char *badv_domain_json=NULL;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN];
	SQLCHAR s_badv_domain_json[MAX_SINGLE_BLOCKLIST_SIZE+1];
	SQLLEN cb_badv_domain_json=SQL_NTS;
	SQLINTEGER s_pub_id,s_site_id, s_campaign_id;
	SQLLEN cb_pub_id, cb_site_id, cb_campaign_id;
	cb_pub_id =cb_site_id =cb_campaign_id=0;

	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);
	strcpy((char *) sql_statement,  GET_BADV_DOMAIN_JSON);

	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if(sql_retval!=SQL_SUCCESS)
	{
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		goto done;
	}
  
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			      SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_pub_id);
	s_pub_id=pub_id;

	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
			      SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_site_id);
	s_site_id=site_id;

	sql_retval = SQLBindParameter(statement_handle, 3, SQL_PARAM_INPUT, SQL_C_ULONG,
			      SQL_INTEGER, 0, 0, &s_campaign_id, 0, &cb_campaign_id);
	s_campaign_id=campaign_id;

	
	sql_retval = SQLExecute(statement_handle);
	if (sql_retval == SQL_SUCCESS)
	{
		SQLBindCol(statement_handle, 1, SQL_C_CHAR, s_badv_domain_json,
				MAX_SINGLE_BLOCKLIST_SIZE, &cb_badv_domain_json);

		sql_retval = SQLFetch(statement_handle);
		if (sql_retval != SQL_NO_DATA && cb_badv_domain_json!= SQL_NULL_DATA && cb_badv_domain_json < MAX_SINGLE_BLOCKLIST_SIZE){
			badv_domain_json=strdup((char *)s_badv_domain_json);
		}
	} else {
		llog_write(L_DEBUG, "Error executing select statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		LOG_FATAL( DB_CALL_FAIL, MOD_DEFAULT,__FILE__,__LINE__);
		goto done;
	}

	done:
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	return badv_domain_json;
}

