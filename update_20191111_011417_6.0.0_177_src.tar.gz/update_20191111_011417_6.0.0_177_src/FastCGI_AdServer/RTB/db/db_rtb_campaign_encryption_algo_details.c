/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include "db_rtb_campaign_encryption_algo_details.h"

#define INITIAL_RTB_CAMPAIGN_ENCYPTION_ALGO_DETAILS_SIZE 5

#define GET_RTB_CAMPAIGN_ENCRYPTION_ALGO_DETAILS \
    "select ALGO_KEYS.campaign_id, ALGO.algorithm_name, \
     ALGO_KEYS.encryption_key, ALGO_KEYS.integrity_key  \
     from realtime_encryption_algorithms as ALGO \
     NATURAL JOIN \
     realtime_campaign_encryption_algorithm_keys as ALGO_KEYS \
     where ALGO_KEYS.algorithm_purpose = ? \
     ORDER BY \
     ALGO_KEYS.campaign_id"

int db_get_rtb_campaign_encryption_algo_details(int algorithm_purpose,
        db_connection_t *dbconn,
        rt_campaign_encryption_algo_details_t **rt_campaign_encryption_algo_details,
        int *rt_campaign_count) {

#ifdef DEBUG
    llog_write(L_DEBUG, "\n%s:%d", __FUNCTION__, __LINE__);
#endif

    /* Local variables */
    rt_campaign_encryption_algo_details_t* retvalue = NULL;
    rt_campaign_encryption_algo_details_t* tmp_retvalue = NULL;

    SQLHANDLE statement_handle = 0;
    SQLRETURN sql_retval = SQL_SUCCESS;
    SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

    SQLINTEGER s_campaign_id = 0;
	SQLLEN cb_s_campaign_id = 0;

    SQLCHAR s_algorithm_name[MAX_ENCRYPTION_ALGO_NAME_LENGTH + 1];
    SQLLEN cb_s_algorithm_name = SQL_NTS;

    SQLCHAR s_encryption_key[MAX_ENCRYPTION_KEY_LENGTH + 1];
    SQLLEN cb_s_encryption_key  = SQL_NTS;

    SQLCHAR s_integrity_key[MAX_INTEGRITY_KEY_LENGTH + 1];
    SQLLEN cb_s_integrity_key  = SQL_NTS;

    SQLINTEGER s_algorithm_purpose = 0;
	SQLLEN cb_s_algorithm_purpose = 0;

    int use_count = 0;
    int alloc_count = INITIAL_RTB_CAMPAIGN_ENCYPTION_ALGO_DETAILS_SIZE;

    /* Allocate the statement handle */
    SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

    /* Create SQL char string which contains the query */
    strncpy((char *) sql_statement, GET_RTB_CAMPAIGN_ENCRYPTION_ALGO_DETAILS, MAX_SQL_QUERY_STR_LEN );
    sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';


    /* Create a prepared statement */
    sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
    if (sql_retval != SQL_SUCCESS) {
        llog_write(L_DEBUG, "Error preparing statement:\n");
        db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );

        // Free The SQL Statement Handle
        if (statement_handle != 0) {
            SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
        }
        return ADS_ERROR_INTERNAL;
    }

    /* Bind parameters */
    sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_TINYINT,
            SQL_INTEGER, 0, 0, &s_algorithm_purpose, 0, &cb_s_algorithm_purpose);
    if (sql_retval != SQL_SUCCESS) {
        printf("Error binding:\n");
        db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );

        // Free The SQL Statement Handle

        if (statement_handle != 0) {
            SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
        }
        return ADS_ERROR_INTERNAL;
    }
    s_algorithm_purpose = algorithm_purpose;

    // Execute The SQL Statement
    sql_retval = SQLExecute(statement_handle);

    if (sql_retval == SQL_SUCCESS) {

        sql_retval = SQLBindCol(statement_handle, 1, SQL_C_ULONG, &s_campaign_id, 0, &cb_s_campaign_id);
        if (sql_retval != SQL_SUCCESS) {
            db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
            SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
            return ADS_ERROR_INTERNAL;
        }

        sql_retval = SQLBindCol(statement_handle, 2, SQL_C_CHAR, s_algorithm_name, MAX_ENCRYPTION_ALGO_NAME_LENGTH, &cb_s_algorithm_name);
        if (sql_retval != SQL_SUCCESS) {
            db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
            SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
            return ADS_ERROR_INTERNAL;
        }

        sql_retval = SQLBindCol(statement_handle, 3, SQL_C_CHAR, s_encryption_key, MAX_ENCRYPTION_KEY_LENGTH + 1, &cb_s_encryption_key);
        if (sql_retval != SQL_SUCCESS) {
            db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
            SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
            return ADS_ERROR_INTERNAL;
        }

        sql_retval = SQLBindCol(statement_handle, 4, SQL_C_CHAR, s_integrity_key, MAX_INTEGRITY_KEY_LENGTH + 1, &cb_s_integrity_key);
        if (sql_retval != SQL_SUCCESS) {
            db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
            SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
            return ADS_ERROR_INTERNAL;
        }


        // While There Are Records In The Result Data Set
        // Produced, Retrieve And Display Them
        retvalue = (rt_campaign_encryption_algo_details_t *) malloc ((sizeof(rt_campaign_encryption_algo_details_t) * INITIAL_RTB_CAMPAIGN_ENCYPTION_ALGO_DETAILS_SIZE ));

        if (retvalue == NULL) {
            if (statement_handle != 0) {
                SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
            }
            return ADS_ERROR_NOMEMORY;
        }
        while (1) {
            sql_retval = SQLFetch(statement_handle);
            if (sql_retval == SQL_NO_DATA) {
                break;
            }
            else {
                if (use_count == alloc_count) {
                    alloc_count*=2;// Use exponential allocation to avoid high reallocation and copying of data
                    tmp_retvalue = realloc(retvalue,
                            sizeof(rt_campaign_encryption_algo_details_t) * alloc_count);
                    if (tmp_retvalue == NULL) {
                        if (retvalue != NULL) {
                            free(retvalue);
                            retvalue = NULL;
                        }
                        // Free The SQL Statement Handle
                        if (statement_handle != 0) {
                            SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                        }
                        return ADS_ERROR_NOMEMORY;
                    }
                    retvalue = tmp_retvalue;
                }

                if (cb_s_algorithm_name != SQL_NULL_DATA && cb_s_algorithm_name != 0) {
                    memcpy(retvalue[use_count].algorithm_name, (char *)s_algorithm_name, cb_s_algorithm_name);
                    retvalue[use_count].algorithm_name[cb_s_algorithm_name] = '\0';
                }
                else {
                    continue;
                }

                if (cb_s_encryption_key != SQL_NULL_DATA && cb_s_encryption_key != 0) {
                    memcpy(retvalue[use_count].encryption_key, (char *)s_encryption_key, cb_s_encryption_key);
                    retvalue[use_count].encryption_key[cb_s_encryption_key] = '\0';
                }
                else {
                    continue;
                }

                if (cb_s_integrity_key != SQL_NULL_DATA && cb_s_integrity_key != 0) {
                    memcpy(retvalue[use_count].integrity_key, (char *)s_integrity_key, cb_s_integrity_key);
                    retvalue[use_count].integrity_key[cb_s_integrity_key] = '\0';
                }
                else {
                    continue;
                }

                retvalue[use_count].campaign_id = s_campaign_id;
                use_count ++;
            }
        }
    } else {
        llog_write(L_DEBUG, "Error executing select statement:\n");
        db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                sql_retval, __LINE__, __FILE__ );
        if (retvalue != NULL) {
            free(retvalue);
            retvalue = NULL;
        }
        // Free The SQL Statement Handle
        if (statement_handle != 0) {
            SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
        }
        return ADS_ERROR_INTERNAL;
    }

    if(use_count == 0){
        if (retvalue!= NULL) {
            free(retvalue);
            retvalue=NULL;
        }
    }
    // Free The SQL Statement Handle
    if (statement_handle != 0) {
        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
    }

    (*rt_campaign_count) = use_count;
    (*rt_campaign_encryption_algo_details) = retvalue;
    return ADS_ERROR_SUCCESS;
}

