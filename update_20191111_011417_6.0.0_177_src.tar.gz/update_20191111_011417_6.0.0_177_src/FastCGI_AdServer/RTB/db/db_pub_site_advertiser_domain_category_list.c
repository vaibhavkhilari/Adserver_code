/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include "db_pub_site_advertiser_domain_category_list.h"

int db_get_pub_site_domain_advertiser_blocklist(db_connection_t *dbconn,
		long **pub_site_domain_advertiser_blocklist,
		int *nelements,
		long pub_id,
		long site_id){

	/*Local Variables*/
	int use_count = 0;
	int alloc_count = 0;
	int ret_val = ADS_ERROR_SUCCESS;
	long *tmp_adv_blocklist = NULL;

	SQLHANDLE statement_handle = 0;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLUINTEGER s_advertiser_id = 0;
	SQLLEN cb_s_advertiser_id = 0;

	/*Allocate the statement handle*/
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	snprintf((char *)sql_statement, MAX_SQL_QUERY_STR_LEN, GET_PUB_SITE_DOM_ADV_BLOCKLIST, pub_id, site_id);
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (SQL_SUCCESS != sql_retval) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );

		// Free The SQL Statement Handle
		if (0 != statement_handle) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);

	if (SQL_SUCCESS == sql_retval) {
		SQLBindCol(statement_handle, 1, SQL_C_ULONG, &s_advertiser_id, 0, &cb_s_advertiser_id);

		SQLLEN key_count;
		SQLRETURN sql_ret = SQL_SUCCESS;
		sql_ret = SQLRowCount(statement_handle, &key_count); // Get the count of rows returned by select query execution.
		if((SQL_SUCCESS == sql_ret || SQL_SUCCESS_WITH_INFO == sql_ret)){
			alloc_count = key_count;
			if(alloc_count > 0){
				tmp_adv_blocklist = (long *) malloc ((sizeof(long) * (alloc_count)));
				if(NULL != tmp_adv_blocklist){
					do{
						sql_retval = SQLFetch(statement_handle);
						if(SQL_NO_DATA == sql_retval) break;
						tmp_adv_blocklist[use_count++] = s_advertiser_id;
					}while(1);
				}
				else{
					ret_val = ADS_ERROR_NOMEMORY;
				}
			}
		}
		else{
			llog_write(L_DEBUG, "\nERROR: SQLRowCount failed. %s:%d\n", __FILE__, __LINE__);
			ret_val = ADS_ERROR_INTERNAL;
		}
	} else {
		llog_write(L_DEBUG, "ERROR: SQLExecute failed.\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		ret_val = ADS_ERROR_INTERNAL;
	}

	if(use_count != alloc_count){
		llog_write(L_DEBUG, "\nERROR: Mismatch in SQLRowCount and actual copied rowcount. %s:%d\n", __FILE__, __LINE__);
		if (tmp_adv_blocklist != NULL) {
			free(tmp_adv_blocklist);
			tmp_adv_blocklist = NULL;
		}
		use_count = 0;
		ret_val = ADS_ERROR_INTERNAL;
	}

	// Free The SQL Statement Handle
	if (0 != statement_handle) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}

	(*nelements) = use_count;
	(*pub_site_domain_advertiser_blocklist) = tmp_adv_blocklist;
	return ret_val;
}

int db_get_pub_site_domain_category_blocklist(db_connection_t *dbconn,
		int **pub_site_domain_category_blocklist,
		int *nelements,
		long pub_id,
		long site_id){

	/*Local Variables*/
	int use_count = 0;
	int alloc_count = 0;
	int ret_val = ADS_ERROR_SUCCESS;
	int *tmp_cat_blocklist = NULL;

	SQLHANDLE statement_handle = 0;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLUINTEGER s_category_id = 0;
	SQLLEN cb_s_category_id = 0;

	/*Allocate the statement handle*/
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	snprintf((char *)sql_statement, MAX_SQL_QUERY_STR_LEN, GET_PUB_SITE_DOM_CAT_BLOCKLIST, pub_id, site_id);
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (SQL_SUCCESS != sql_retval) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );

		// Free The SQL Statement Handle
		if (0 != statement_handle) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);

	if (SQL_SUCCESS == sql_retval) {
		SQLBindCol(statement_handle, 1, SQL_C_ULONG, &s_category_id, 0, &cb_s_category_id);

		SQLLEN key_count;
		SQLRETURN sql_ret = SQL_SUCCESS;
		sql_ret = SQLRowCount(statement_handle, &key_count); // Get the count of rows returned by select query execution.
		if((SQL_SUCCESS == sql_ret || SQL_SUCCESS_WITH_INFO == sql_ret)){
			alloc_count = key_count;
			if(alloc_count > 0){
				tmp_cat_blocklist = (int *) malloc ((sizeof(int) * (alloc_count)));
				if(NULL != tmp_cat_blocklist){
					do{
						sql_retval = SQLFetch(statement_handle);
						if (SQL_NO_DATA == sql_retval) break;
						tmp_cat_blocklist[use_count++] = (int)s_category_id;

					}while(1);
				}
				else{
					ret_val = ADS_ERROR_NOMEMORY;
				}
			}
		}
		else{
			llog_write(L_DEBUG, "\nERROR: SQLRowCount failed. %s:%d\n", __FILE__, __LINE__);
			ret_val = ADS_ERROR_INTERNAL;
		}
	} else {
		llog_write(L_DEBUG, "ERROR: SQLExecute failed.\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		ret_val = ADS_ERROR_INTERNAL;
	}

	if(use_count != alloc_count){
		llog_write(L_DEBUG, "\nERROR: Mismatch in SQLRowCount and actual copied rowcount. %s:%d\n", __FILE__, __LINE__);
		if (tmp_cat_blocklist != NULL) {
			free(tmp_cat_blocklist);
			tmp_cat_blocklist = NULL;
		}
		use_count = 0;
		ret_val = ADS_ERROR_INTERNAL;
	}

	// Free The SQL Statement Handle
	if (0 != statement_handle) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}

	(*nelements) = use_count;
	(*pub_site_domain_category_blocklist) = tmp_cat_blocklist;
	return ret_val;
}
