/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "dp_data_passing_generic.h"
#include "rt_types.h"
#include "db_error.h"
#include "db_constants.h"
#include "cache_campaign_data_provider_segment_type_settings.h"
#include "campaign_data_provider_data.h"
#include "campaign_data_provider_settings.h"
#include "dp_data_passing_util.h"
#include "db_campaign_data_provider_segment_type_settings.h"

#define GET_CAMPAIGN_LEVEL_DATA_PROVIDER_SETTINGS       "                     \
select            cdpstm.data_type_id, cdpsm.provider_segment_id              \
from              campaign_data_provider_data_type_mapping cdpstm             \
left outer join   (campaign_data_provider_segments_mapping cdpsm)             \
 on               (cdpstm.campaign_id = cdpsm.campaign_id                     \
  and             cdpstm.data_provider_id = cdpsm.data_provider_id            \
  and             cdpstm.data_type_id = cdpsm.data_type_id)                   \
where             cdpstm.campaign_id = ?                                      \
 and              cdpstm.data_provider_id = ?                                 \
order by          cdpstm.campaign_id, cdpstm.data_provider_id,                \
                  cdpstm.data_type_id, cdpsm.provider_segment_id              \
"

#define SEGMENT_IDS_ALLOC_SIZE					5

//Allocate memory for Segment type settings.
//Return 0 on Success & 1 on Failure.
static int alloc_seg_type_settings(
                             memcache_cmpg_dp_data_passing_settings_t **cmpg_dp_settings,
							 int *alloc_count,
							 int *use_count)
{
	memcache_cmpg_dp_data_passing_settings_t *tmp_cmp_dp_settings = NULL;

	if (*alloc_count > *use_count)
	{
		tmp_cmp_dp_settings = malloc(
						sizeof (memcache_cmpg_dp_data_passing_settings_t) +
						((*alloc_count) * sizeof (memcached_dp_data_passing_settings_t)));
		if (tmp_cmp_dp_settings == NULL)
	    {
		    llog_write(L_DEBUG, "\n(%s:%d) Not able to allocate memory for segment ids.\n", __FUNCTION__, __LINE__);
            return 1;
		}
	}
	else
	{
		*alloc_count += SEGMENT_IDS_ALLOC_SIZE;
		tmp_cmp_dp_settings = realloc(
							*cmpg_dp_settings,
							sizeof (memcache_cmpg_dp_data_passing_settings_t) +
							((*alloc_count) * sizeof (memcached_dp_data_passing_settings_t)));
		if (tmp_cmp_dp_settings == NULL)
		{
			llog_write(L_DEBUG, "\n(%s:%d) Not able to allocate memory for segment ids.\n", __FUNCTION__, __LINE__);
            return 1;
		}
	}

	*cmpg_dp_settings = tmp_cmp_dp_settings;
	return 0;
}

/*
 * If Data-Provider settings are not found in the Cache for given Campaing,
 * following function would be called to get the same from DB.
 */
int get_campaign_data_provider_settings(
									long campaign_id,
									int data_provider_id,
									db_connection_t *dbconn,
									memcache_cmpg_dp_data_passing_settings_t **cmpg_dp_settings)
{
    SQLHANDLE statement_handle = 0;
    SQLRETURN sql_retval = SQL_SUCCESS;
    SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN];
    SQLINTEGER s_campaign_id = 0;
	SQLLEN cb_s_campaign_id = 0;
    SQLINTEGER s_data_provider_id = 0;
	SQLLEN cb_s_data_provider_id = 0;
    SQLINTEGER s_data_provider_segment_type = 0;
	SQLLEN cb_s_data_provider_segment_type = 0;
    SQLINTEGER s_data_provider_segment_id = 0;
	SQLLEN cb_s_data_provider_segment_id = 0;
    int use_count = 0;
    int is_settings_empty;
	int seg_ids_alloc_count;
	int ret = DB_ERROR_SUCCESS;

    if (dbconn == NULL ||
        cmpg_dp_settings == NULL ||
        *cmpg_dp_settings != NULL)
    {
		llog_write(L_DEBUG, "(%s:%d): One of the input params is NULL.\n", __FUNCTION__, __LINE__);
        return DB_ERROR_INVALID_ARGS;
    }

    /* Initialized input params. */
    *cmpg_dp_settings = NULL;

    SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);
    strcpy((char *) sql_statement, GET_CAMPAIGN_LEVEL_DATA_PROVIDER_SETTINGS);
    sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
    if(sql_retval != SQL_SUCCESS)
    {
        printf("Error preparing statement:\n");
        db_conn_print_error((SQLSMALLINT) SQL_HANDLE_STMT, statement_handle, sql_retval,__LINE__,__FILE__ );
        // Free The SQL Statement Handle
        if (statement_handle != 0)
        {
            SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
        }
        return DB_ERROR_INTERNAL;
    }

	//Bind Campaign Id.
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_campaign_id, 0, &cb_s_campaign_id);
	if(sql_retval != SQL_SUCCESS)
	{
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
					sql_retval, __LINE__, __FILE__);
		// Free The SQL Statement Handle
		if (statement_handle != 0)
		{
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}
	s_campaign_id = campaign_id;
	//Bind Data-Provider Id.
	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_data_provider_id, 0, &cb_s_data_provider_id);
	if(sql_retval != SQL_SUCCESS)
	{
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
					sql_retval, __LINE__, __FILE__);
		// Free The SQL Statement Handle
		if (statement_handle != 0)
		{
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}
	s_data_provider_id = data_provider_id;

	//Set to 0 when at least one record is found.
    is_settings_empty = 1;

	seg_ids_alloc_count = SEGMENT_IDS_ALLOC_SIZE;
	use_count = 0;

    sql_retval = SQLExecute(statement_handle);
    if (sql_retval == SQL_SUCCESS)
	{
		SQLBindCol(statement_handle, 1, SQL_C_ULONG, &s_data_provider_segment_type, 0, &cb_s_data_provider_segment_type);
        SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_data_provider_segment_id, 0, &cb_s_data_provider_segment_id);

        if (alloc_seg_type_settings(
					cmpg_dp_settings,
					&seg_ids_alloc_count,
					&use_count) != 0)
        {
            llog_write(L_DEBUG, "\n(%s:%d) Not able to allocate memory for Campaign settings.\n",
							__FUNCTION__, __LINE__);
            ret = DB_ERROR_NO_MEMORY;
			goto cleanup;
        }

        use_count = 0;
        while (sql_retval != SQL_NO_DATA)
		{
            sql_retval = SQLFetch(statement_handle);
            if (sql_retval != SQL_NO_DATA)
            {
                if (is_settings_empty == 1)
		{
                    //To be doubly sure.
                    use_count = 0;
		}
		if (s_data_provider_segment_type == DATA_PROVIDER_UNKNOWN_SEGMENT)
		{
			//Ignore unknow segments.
			continue;
		}

		//Need to allocate more memory?
		if (use_count == seg_ids_alloc_count)
		{
			if (alloc_seg_type_settings(
				cmpg_dp_settings,
				&seg_ids_alloc_count,
				&use_count) != 0)
			{
				llog_write(L_DEBUG, "\n(%s:%d) Not able to allocate memory for segment ids.\n", __FUNCTION__, __LINE__);
				ret = DB_ERROR_NO_MEMORY;
				goto cleanup;
			}
		}

				
                //Fill Segment type level settings.
                (*cmpg_dp_settings)->dp_settings[use_count].segment_type_id = s_data_provider_segment_type;
                //Fill Segment Id.
                (*cmpg_dp_settings)->dp_settings[use_count].segment_id = s_data_provider_segment_id;

                is_settings_empty = 0;

                if (s_data_provider_segment_id  == 0 ||
                    cb_s_data_provider_segment_id == SQL_NULL_DATA)
                {
                     /*
					  * As Segment type is not known, Set segment_id  to *zero* for given Segment type.
					  * This means, We need to send all segments of given Segment type to DSPs.
					  */
                     (*cmpg_dp_settings)->dp_settings[use_count].segment_id = 0;
                }

                use_count++;
			}
		}

        //Set entries counter of last Campaign.
        (*cmpg_dp_settings)->dp_settings_count = use_count;
	}
	else
	{
        llog_write(L_DEBUG, "Error executing select statement:\n");
        ret = DB_ERROR_INTERNAL;
		goto cleanup;
    }

    if (is_settings_empty == 1)
    {
		llog_write(L_DEBUG, "(%s:%d): Does not found settings in DB.\n", __FUNCTION__, __LINE__);
		ret = DB_ERROR_SUCCESS;
		goto cleanup;
    }

	// Free The SQL Statement Handle
	if (statement_handle != 0)
	{
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
    return  DB_ERROR_SUCCESS;

cleanup:
	if ((*cmpg_dp_settings) != NULL)
	{
		free((*cmpg_dp_settings));
		(*cmpg_dp_settings) = NULL;
	}
	// Free The SQL Statement Handle
	if (statement_handle != 0)
	{
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	return ret;
}

