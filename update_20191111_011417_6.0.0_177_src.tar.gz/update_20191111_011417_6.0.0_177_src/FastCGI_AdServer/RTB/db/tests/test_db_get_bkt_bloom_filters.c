#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include "error.h"
#include "db_connection.h"
#include "rt_types.h"
#include "db_get_bkt_bloom_filters.h"
int gbl_log_level = L_DEBUG;
BKT_BLOOM *__wrap_bkt_bloom_create(int nelements, size_t *memcache_obj_size) {
	*memcache_obj_size = 1;
	return mock_type(BKT_BLOOM *);
}

int __wrap_bkt_bloom_destroy(BKT_BLOOM **bkt_bloom) {
	return 0;
}

BKT_BLOOM_ARRAY *__wrap_bkt_bloom_array_create() {
	return NULL;
}

void __wrap_db_conn_print_error(SQLSMALLINT htype, SQLHANDLE hndl, SQLRETURN frc, int line, char *file) {
}

int __wrap_bkt_bloom_array_destroy(BKT_BLOOM_ARRAY **bkt_bloom_array) {
	return 0;
}

SQLRETURN __wrap_SQLBindCol(
		SQLHSTMT       StatementHandle,
		SQLUSMALLINT   ColumnNumber,
		SQLSMALLINT    TargetType,
		SQLPOINTER     TargetValuePtr,
		SQLLEN         BufferLength,
		SQLLEN *       StrLen_or_Ind) {
	check_expected(ColumnNumber);
	check_expected(TargetType);
	check_expected(BufferLength);
	memcpy(TargetValuePtr, mock_type(SQLPOINTER),4);
	*StrLen_or_Ind = mock_type(int);
	//memcpy(StrLen_or_Ind, mock_type(SQLLEN *),4);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLExecute(SQLHSTMT StatementHandle) {
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFetch(SQLHSTMT StatementHandle) {
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLBindParameter(
		SQLHSTMT        StatementHandle,
		SQLUSMALLINT    ParameterNumber,
		SQLSMALLINT     InputOutputType,
		SQLSMALLINT     ValueType,
		SQLSMALLINT     ParameterType,
		SQLULEN         ColumnSize,
		SQLSMALLINT     DecimalDigits,
		SQLPOINTER      ParameterValuePtr,
		SQLLEN          BufferLength,
		SQLLEN *        StrLen_or_IndPtr) {
	check_expected(ParameterNumber);
	check_expected(InputOutputType);
	check_expected(ValueType);
	check_expected(ParameterType);
	check_expected(ColumnSize);
	check_expected(DecimalDigits);
	check_expected(BufferLength);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFreeHandle(SQLSMALLINT HandleType, SQLHANDLE Handle) {
	return 0;
}

SQLRETURN __wrap_SQLAllocHandle(SQLSMALLINT HandleType,SQLHANDLE InputHandle,SQLHANDLE *OutputHandlePtr) {
	check_expected(HandleType);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLPrepare(SQLHSTMT StatementHandle, SQLCHAR *StatementText, SQLINTEGER TextLength) {
	check_expected(StatementText);
	check_expected(TextLength);
	return mock_type(SQLRETURN);
}

typedef struct test_db_get_bkt_bloom_filters_inputs_t{
	int ret_sql_prepare;
	int ret_sql_exec;
	int ret_sql_bind[4];
	int ret_sql_fetch;
	int blm_create_ret;
	int blm_ele_cnt;
	int blm_version;
	int blm_clount;
	char blm_update_date[MAX_TIMESTAMP_SIZE_YYYYMMDD + 1];
	int ret_val;
}test_db_get_bkt_bloom_filters_inputs;

void test_db_get_bkt_bloom_filters(test_db_get_bkt_bloom_filters_inputs *input) {
	int rv;
	db_connection_t dbconn;
	int tmp_int = 1;
	char *db_query = "db query";
	BKT_BLOOM dummy_bloom = {1,1,"first_ele"};
	BKT_BLOOM *null_bloom = NULL;
	BKT_BLOOM *out_bloom_filter[MAX_ALLOWED_BKT_BLOOMS];
	size_t ret_size[MAX_ALLOWED_BKT_BLOOMS];
	int bloom_count;
	char update_time[MAX_TIMESTAMP_SIZE_YYYYMMDD + 1];

	do {
		if (1 > input->blm_clount || MAX_GIANT_BLOOM_COUNT_FOR_GLOBAL < input->blm_clount) {
			break;
		}

		expect_value(__wrap_SQLAllocHandle, HandleType, SQL_HANDLE_STMT);
		will_return(__wrap_SQLAllocHandle, SQL_SUCCESS);

		expect_string(__wrap_SQLPrepare, StatementText, db_query);
		expect_value(__wrap_SQLPrepare, TextLength, SQL_NTS);
		will_return(__wrap_SQLPrepare, input->ret_sql_prepare);
		if (SQL_SUCCESS != input->ret_sql_prepare) {
			break;
		}

		will_return(__wrap_SQLExecute, input->ret_sql_exec);
		if (SQL_SUCCESS != input->ret_sql_exec) {
			break;
		}

		expect_value(__wrap_SQLBindCol, ColumnNumber, 1);
		expect_value(__wrap_SQLBindCol, TargetType, SQL_C_BINARY);
		expect_value(__wrap_SQLBindCol, BufferLength, MAX_PER_BLOOM_DB_SIZE * input->blm_clount);
		will_return(__wrap_SQLBindCol, &dummy_bloom);
		will_return(__wrap_SQLBindCol, tmp_int);
		will_return(__wrap_SQLBindCol, input->ret_sql_bind[0]);
		if (SQL_SUCCESS != input->ret_sql_bind[0]) {
			break;
		}

		expect_value(__wrap_SQLBindCol, ColumnNumber, 2);
		expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
		expect_value(__wrap_SQLBindCol, BufferLength, 0);
		will_return(__wrap_SQLBindCol, &input->blm_ele_cnt);
		will_return(__wrap_SQLBindCol, tmp_int);
		will_return(__wrap_SQLBindCol, input->ret_sql_bind[1]);
		if (SQL_SUCCESS != input->ret_sql_bind[1]) {
			break;
		}

		expect_value(__wrap_SQLBindCol, ColumnNumber, 3);
		expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
		expect_value(__wrap_SQLBindCol, BufferLength, 0);
		will_return(__wrap_SQLBindCol, &input->blm_version);
		will_return(__wrap_SQLBindCol, tmp_int);
		will_return(__wrap_SQLBindCol, input->ret_sql_bind[2]);
		if (SQL_SUCCESS != input->ret_sql_bind[2]) {
			break;
		}

		expect_value(__wrap_SQLBindCol, ColumnNumber, 4);
		expect_value(__wrap_SQLBindCol, TargetType, SQL_C_CHAR);
		expect_value(__wrap_SQLBindCol, BufferLength, MAX_TIMESTAMP_SIZE_YYYYMMDD);
		will_return(__wrap_SQLBindCol, &input->blm_update_date);
		will_return(__wrap_SQLBindCol, tmp_int);
		will_return(__wrap_SQLBindCol, input->ret_sql_bind[3]);
		if (SQL_SUCCESS != input->ret_sql_bind[3]) {
			break;
		}

		will_return(__wrap_SQLFetch, input->ret_sql_fetch);
		if ((SQL_NO_DATA != input->ret_sql_fetch) && (2 == input->blm_version)) {
			if (0 == input->blm_create_ret) {
				will_return(__wrap_bkt_bloom_create, &dummy_bloom);
			} else {
				will_return(__wrap_bkt_bloom_create, null_bloom);
			}
		}
	} while(0);

	rv = db_get_bkt_bloom_filters(&dbconn, db_query, out_bloom_filter, &bloom_count, ret_size, update_time, input->blm_clount);
	assert_int_equal(input->ret_val, rv);
	if ((ADS_ERROR_SUCCESS == input->ret_val) && (2 == input->blm_version)) {
		assert_string_equal(input->blm_update_date, update_time);
		assert_int_equal(bloom_count, 1);
		assert_int_equal(ret_size[0], 1);
		assert_int_equal(out_bloom_filter[0], &dummy_bloom);
	}
}

static void test_db_get_bkt_bloom_filters__all_testcases(void **state) {
	int i;
	test_db_get_bkt_bloom_filters_inputs inputs[]={
		//Positive testcases
		//SQLPrepare_ret,SQLExec_ret,{SQLBind_ret},SQLFetch_ret,blm_create_ret,blm_ele_cnt,blm_ver,update_date,ret_val
		{0,0,{0,0,0,0},0,0,1,2,3,"date",0},
		{0,0,{0,0,0,0},0,0,1,0,3,"date",0}, // bloom version != 2
		{0,0,{0,0,0,0},0,0,1,2,20,"date",0},
		{0,0,{0,0,0,0},0,0,1,0,20,"date",0}, // bloom version != 2
		{0,0,{0,0,0,0},0,0,1,2,50,"date",0},
		{0,0,{0,0,0,0},0,0,1,0,100,"date",0}, // bloom version != 2

		// Negative testcases
		{0,0,{0,0,0,0},0,1,1,2,20,"date",ADS_ERROR_NOMEMORY},
		{0,0,{0,0,0,0},0,1,1,2,101,"date",ADS_ERROR_INVALID_ARGS},
		{0,0,{0,0,0,0},0,1,1,2,0,"date",ADS_ERROR_INVALID_ARGS},
		{0,0,{0,0,0,0},0,1,1,2,-1,"date",ADS_ERROR_INVALID_ARGS},
		{0,0,{0,0,0,0},SQL_NO_DATA,1,1,0,20,"date",0},
		{0,0,{0,0,0,-1},SQL_NO_DATA,1,1,0,20,"date",4}, // 4th SQL bind fails,
		{0,0,{0,0,-1,-1},SQL_NO_DATA,1,1,0,20,"date",4}, // 3rd SQL bind fails,
		{0,0,{0,-1,-1,-1},SQL_NO_DATA,1,1,0,20,"date",4}, // 2nd SQL bind fails,
		{0,0,{-1,-1,-1,-1},SQL_NO_DATA,1,1,0,20,"date",4}, // 1st SQL bind fails
		{0,-1,{-1,-1,-1,-1},SQL_NO_DATA,1,1,0,20,"date",4}, //SQL exec fails
		{-1,-1,{-1,-1,-1,-1},SQL_NO_DATA,1,1,0,20,"date",4}, //SQL prepare fails
	};

	for (i=0;i<(sizeof(inputs)/sizeof(test_db_get_bkt_bloom_filters_inputs));i++) {
		test_db_get_bkt_bloom_filters(&inputs[i]);
	}
}

int main()
{
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_db_get_bkt_bloom_filters__all_testcases),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
