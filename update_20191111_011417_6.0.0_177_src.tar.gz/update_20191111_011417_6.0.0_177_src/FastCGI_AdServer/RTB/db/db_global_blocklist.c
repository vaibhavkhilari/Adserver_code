/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "error.h"
#include "bloom_filter.h"

#define GET_GLOBAL_BLOCKLIST "select bloom_filter, blocklist_domain_count from global_supply_side_blocklist_filter"

int db_get_global_blocklist(db_connection_t *dbconn, 
															BLOOM** global_blocklist_domain, 
															size_t *global_bl_domain_length){

	unsigned char *bit_array = NULL;
	int retval = ADS_ERROR_SUCCESS;
  size_t memcache_obj_size = 0;
  BLOOM* bloom = NULL;   
  SQLHANDLE statement_handle = 0;
  SQLRETURN sql_retval = SQL_SUCCESS;
  SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLCHAR *s_bit_array = NULL;
  SQLLEN cb_s_bit_array = SQL_NTS;
  SQLINTEGER s_blocklist_domain_cnt=0;
  SQLLEN cb_s_blocklist_domain_cnt=0;

	(*global_blocklist_domain) = NULL;
	(*global_bl_domain_length) = 0;

	/* Allocate the statement handle */
  SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	strncpy((char *) sql_statement, GET_GLOBAL_BLOCKLIST, MAX_SQL_QUERY_STR_LEN );
  sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

	/* Create a prepared statement */
  sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
  if (sql_retval != SQL_SUCCESS) {
    llog_write(L_DEBUG, "Error preparing statement:\n");
    db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
    retval = ADS_ERROR_INTERNAL;
    goto done;
  }

	// Execute The SQL Statement
  sql_retval = SQLExecute(statement_handle);

	if (sql_retval == SQL_SUCCESS) {
		s_bit_array = (SQLCHAR *)calloc(BIT_ARRAY_SIZE+1, sizeof(char));
    if(s_bit_array == NULL) {
      llog_write(L_DEBUG, "\nError: Failed to allocate memory for bloom filter, %s:%d\n", __FILE__, __LINE__);
      return ADS_ERROR_NOMEMORY;
    }
		
		/* Bind Column : bloom_filter */
    sql_retval = SQLBindCol(statement_handle, 1, SQL_C_BINARY, s_bit_array, BIT_ARRAY_SIZE, &cb_s_bit_array);
    if (sql_retval != SQL_SUCCESS) {
      db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
      retval = ADS_ERROR_INTERNAL;
      goto done;
    }

		/* Bind Column : blocklist_domain_count */
    sql_retval = SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_blocklist_domain_cnt, 0, &cb_s_blocklist_domain_cnt);
    if (sql_retval != SQL_SUCCESS) {
      db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
      retval = ADS_ERROR_INTERNAL;
      goto done;
    }

		/* Fetch Result */
    sql_retval = SQLFetch(statement_handle);
    if (sql_retval == SQL_NO_DATA) {
      llog_write(L_DEBUG, "\nGSSBL: No bloom filter found for Blobal Block List, %s:%d\n",__FILE__,__LINE__);
      //LOG_INFO(LPF_DB_INFO,1,pub_id,site_id,__FILE__,__LINE__);
      retval = ADS_ERROR_SUCCESS;
      goto done;
    }
	} else {
    llog_write(L_DEBUG, "Error executing select statement, %s:%d\n",__FILE__,__LINE__);
    db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
        sql_retval,__LINE__,__FILE__ );
    retval = ADS_ERROR_INTERNAL;
    goto done;
  }

	if(s_blocklist_domain_cnt > MAX_ELEMENT_COUNT_WHITELIST) {
    llog_write(L_DEBUG, "ERROR: Could not create bloom filter because whitelist size > %d, %s:%d\n",MAX_ELEMENT_COUNT_WHITELIST,__FILE__,__LINE__);
    retval = ADS_ERROR_NOMEMORY;
    goto done;
  }

	if(!(bloom = bloom_create((int)s_blocklist_domain_cnt, &memcache_obj_size))) {
    llog_write(L_DEBUG, "\nERROR: Could not create bloom filter for Global BlockList, %s:%d\n", __FILE__, __LINE__);
    retval = ADS_ERROR_NOMEMORY;
    goto done;
  }

#ifdef GSSBL
	llog_write(L_DEBUG,"\nGSSBL: Global blocklist_domain_count:%d, db_bit_array_size_bytes:%ld\n",
        s_blocklist_domain_cnt, cb_s_bit_array);
#endif

	if(cb_s_bit_array != SQL_NULL_DATA && cb_s_bit_array != 0) {
		bit_array = (unsigned char*)&((bloom)[1]);
    cb_s_bit_array = (cb_s_bit_array < BIT_ARRAY_SIZE)? cb_s_bit_array : BIT_ARRAY_SIZE;
    memcpy(bit_array, (unsigned char *)s_bit_array, cb_s_bit_array);
  }

#ifdef GSSBL
	llog_write(L_DEBUG,"\nGSSBL: Global Bloak list domain_count:%d, sizeof(BLOOM):%zu, bit_array_size(in bits):%ld, "
      "bit_array_size(in bytes):%ld, memcache_obj_size:%d, %s:%d\n",
      bloom->nelements, sizeof(BLOOM), bloom->bit_array_size,
      BIT_ARRAY_SIZE_BYTES(bloom->bit_array_size),
      memcache_obj_size, __FILE__, __LINE__);
#endif

	(*global_blocklist_domain) = bloom;
  (*global_bl_domain_length) = memcache_obj_size;

done:
  // Free The SQL Statement Handle
  if (statement_handle != 0) {
    SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
  }
  if (s_bit_array != NULL) {
    free(s_bit_array);
  }
  return retval;
}

