/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "rt_types.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_publisher_site_dsp_floor.h"

#define GET_PUBLISHER_SITE_DSP_FLOOR "select  demand_partner_id, floor_ecpm from publisher_site_dsp_floor where pub_id=? and site_id in (?,0) and dsp_floor_active_flag = 1 order by site_id desc"

#define DSP_FLOOR_ALLOC_SIZE 20

int get_publisher_site_dsp_floor_settings( long publisher_id,
        long site_id,
        db_connection_t *dbconn,
        publisher_site_dsp_floor_settings_t **publisher_site_dsp_floor_settings,
        unsigned int *nelements){


        SQLHANDLE statement_handle = 0;
        SQLRETURN sql_retval = SQL_SUCCESS;
        SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN];
        SQLINTEGER s_site_id = 0;
        SQLINTEGER s_publisher_id = 0;
        SQLINTEGER s_dsp_id = 0;
        SQLDOUBLE s_floor_ecpm = 0.0;
        SQLLEN cb_site_id = 0;
	SQLLEN cb_floor_ecpm = 0;
	SQLLEN cb_publisher_id = 0;
	SQLLEN cb_dsp_id=0;
	publisher_site_dsp_floor_settings_t *retlist = NULL, *tmp_retlist = NULL;
	int use_count=0, alloc_count = 0;

        (*publisher_site_dsp_floor_settings) = NULL;
        (*nelements) = 0;

        SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);
        strcpy((char *) sql_statement, GET_PUBLISHER_SITE_DSP_FLOOR);
        sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
        if(sql_retval!=SQL_SUCCESS)
        {
                printf("Error preparing statement:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return DB_ERROR_INTERNAL;
        }

        sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_publisher_id, 0, &cb_publisher_id);
        if(sql_retval!=SQL_SUCCESS)
        {
                printf("Error binding:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return DB_ERROR_INTERNAL;
        }


        sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_site_id);
        if(sql_retval!=SQL_SUCCESS)
        {
                printf("Error binding:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return DB_ERROR_INTERNAL;
        }

        s_publisher_id = publisher_id;
        s_site_id = site_id;

        sql_retval = SQLExecute(statement_handle);

        if (sql_retval == SQL_SUCCESS)
        {

                SQLBindCol(statement_handle, 1, SQL_C_ULONG, &s_dsp_id,
                        0, &cb_dsp_id);
                SQLBindCol(statement_handle, 2, SQL_C_DOUBLE, &s_floor_ecpm,
                        0, &cb_floor_ecpm);

                retlist = (publisher_site_dsp_floor_settings_t *) malloc(sizeof(publisher_site_dsp_floor_settings_t) * DSP_FLOOR_ALLOC_SIZE);
                if (retlist == NULL){
                        if (statement_handle != 0) {
                                SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                        }
                        return DB_ERROR_NO_MEMORY;
                }
                alloc_count = DSP_FLOOR_ALLOC_SIZE;

                while (sql_retval != SQL_NO_DATA)
                {
                        sql_retval = SQLFetch(statement_handle);
                        if (sql_retval != SQL_NO_DATA) {

                                if (use_count == alloc_count) {
                                        alloc_count += DSP_FLOOR_ALLOC_SIZE;
                                        tmp_retlist = realloc(retlist, sizeof(publisher_site_dsp_floor_settings_t) * alloc_count);
                                        if (tmp_retlist == NULL) {
                                                if (retlist != NULL) {
                                                        free(retlist);
                                                        retlist = NULL;
                                                }
                                                // Free The SQL Statement Handle
                                                if (statement_handle != 0) {
                                                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                                                }
                                                return DB_ERROR_NO_MEMORY;
                                        }
                                        retlist = tmp_retlist;
                                }

				retlist[use_count].dsp_id = s_dsp_id;
                                retlist[use_count].floor_ecpm = s_floor_ecpm;
                                use_count+= 1;
                        }
                 }
        } else {
                 llog_write(L_DEBUG, "Error executing select statement:\n");
                 db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                               sql_retval,__LINE__,__FILE__ );
                 if (retlist != NULL) {
                        free(retlist);
                        retlist = NULL;
                  }
                  // Free The SQL Statement Handle
                  if (statement_handle != 0) {
                         SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                  }
                  return DB_ERROR_INTERNAL;
         }
		

        if (statement_handle != 0) {
                SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
        }

        if(use_count == 0) {
                if(retlist != NULL) {
                        free(retlist);
                        retlist = NULL;
                }
        }

        (*publisher_site_dsp_floor_settings) = retlist;
        (*nelements) = use_count;

       return DB_ERROR_SUCCESS;

}
