<?php
/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current
PubMatic employees, managers or contractors who have executed
 Confidentiality and Non-disclosure agreements explicitly covering such access.

 The copyright notice above does not evidence any actual or intended publication or disclosure of this source
code, which includes
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION,
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE,
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION
DOES NOT CONVEY OR IMPLY ANY RIGHTS
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY
DESCRIBE, IN WHOLE OR IN PART.
 */


/* Usage
 * =====
 * php bloom_filter_generator.php [-p <execution_period>] [configs...]
 * execution_period := int (Period in which the script will be re-run (in minutes)), default = 60 minutes
 * configs := SET_CONFIG |
 *            WHITELIST_BLOOM_FILTER |
 *            DSP_BLOCKLIST_FILTER |
 *            GSS_BLOCKLIST_FILTER |
 *            DSP_WHITELIST_FILTER |
 *            DSP_APPURL_BLOCKLIST_FILTER |
 *            DSP_APPURL_WHITELIST_FILTER |
 *            GLOBAL_LANDING_PAGE_FILTER
 */

//set default timezone
date_default_timezone_set("America/Los_Angeles");

$CONFIG_FILE="/SCRIPTS/BLOOM_FILTER_GENERATION/conf/config.ini";
$config_list="SET_CONFIG,WHITELIST_BLOOM_FILTER,DSP_BLOCKLIST_FILTER,GSS_BLOCKLIST_FILTER,DSP_WHITELIST_FILTER,DSP_APPURL_BLOCKLIST_FILTER,DSP_APPURL_WHITELIST_FILTER,GLOBAL_LANDING_PAGE_FILTER,DAA_DEVICE_OPTOUT_BLOOM_FILTER,PUBLISHER_CAMPAIGN_BLOCKLIST_FILTER";

function get_cmd_line_options() {
	global $EXECUTION_PERIOD;  // in minutes
	global $config_param, $argv;

	$config_param[]="SET_CONFIG";

	$EXECUTION_PERIOD = getopt('p:');
	if (isset($EXECUTION_PERIOD['p'])) {
		$EXECUTION_PERIOD = $EXECUTION_PERIOD['p'];
	} else {
		$EXECUTION_PERIOD = 60;  // 60 minutes.
	}
	foreach (array_slice($argv, 1) as $configs) {
		if ('A' <= $configs[0] && $configs[0] <= 'Z') {
			$config_param[]=$configs;
		}
	}
}

get_cmd_line_options();
if (count($config_param) == 1) {
	$config_param=explode(",",$config_list);
}

$has_db_connection=0;

$config=parse_ini_file("$CONFIG_FILE",1);

//read config.ini. config for select query will run on AdServer;
$SOURCE_LOCAL_HOST=$config['SET_CONFIG']['db.local.host.name'];
$SOURCE_BRAND_HOST=$config['SET_CONFIG']['db.brand.host.name'];
$SOURCE_KAD_DB=$config['SET_CONFIG']['db.kad.dsn.name'];
$SOURCE_ADF_DB=$config['SET_CONFIG']['db.adf.dsn.name'];
$SOURCE_OPTOUT_DB=$config['SET_CONFIG']['db.daaoptout.dsn.name'];
$SOURCE_USERNAME=$config['SET_CONFIG']['db.dsn.user.name'];
$SOURCE_PASSWORD=$config['SET_CONFIG']['db.dsn.user.password'];
$SOURCE_HOST_MAINDB=$config['SET_CONFIG']['db.master.host.name'];
$SOURCE_ADS_TXT_CRAWLER_DB=$config['SET_CONFIG']['db.ads.txt.dsn.name'];
$SOURCE_ADS_TXT_CRAWLER_HOST=$config['SET_CONFIG']['db.adstxt.crawler.host.name'];
$SOURCE_CEASER_DB=$config['SET_CONFIG']['db.ceaser.dsn.name'];
$SOURCE_CEASER_DB_HOST=$config['SET_CONFIG']['db.ceaser.host.name'];
$SOURCE_RAWDATA_DB=$config['SET_CONFIG']['db.rawdata.dsn.name'];
$SOURCE_RAWDATA_DB_HOST=$config['SET_CONFIG']['db.rawdata.host.name'];
$SOURCE_CRTV_INGESTOR_DB=$config['SET_CONFIG']['db.creativeingestor.dsn.name'];
$SOURCE_CRTV_INGESTOR_DB_HOST=$config['SET_CONFIG']['db.creativeingestor.host.name'];

$uniq_name = implode(":",$argv).":";
$uniq_name = substr($uniq_name, strpos($uniq_name, ':')+1, strlen($uniq_name));
$uniq_name = "BFG:".$uniq_name;
$BLOOM_BASE_DIR=$config['SET_CONFIG']['bloom.base.dir'];
$LAST_INSTANCE_CHECK_FILE=$BLOOM_BASE_DIR."/.".$uniq_name."pid";
$STATUS_FILE=$BLOOM_BASE_DIR."/.".$uniq_name."status";
$FILTER_GENERATOR_BIN=$BLOOM_BASE_DIR."/".$config['SET_CONFIG']['filter.generator.bin'];
$REPORT_FILE=$BLOOM_BASE_DIR."/".$uniq_name."REPORT.txt";
$INFO_LOG_FILE="$BLOOM_BASE_DIR/$uniq_name.INFO.tmp.txt";
$TMP_EMAIL_FILE=$BLOOM_BASE_DIR."/".$uniq_name."EMAIL.tmp.txt";
//default time interval = cron execution time, this will be overwrittne from status file
$INTERVAL_SECONDS = time() - $EXECUTION_PERIOD * 60;

function write_info_file($msg) {
	global $INFO_LOG_FILE;

	$file = fopen($INFO_LOG_FILE, "a");
	fwrite($file, $msg);
	fclose($file);
}

function email_info_file() {
	global $BLOOM_BASE_DIR, $INFO_LOG_FILE, $uniq_name;

	$subject = "BLOOM_GENERATOR_INFO:".$uniq_name;
	// $subject = "BLOOM_".$config_param[1]."_GENERATOR";

	# Send the report via mail
	exec("php $BLOOM_BASE_DIR/send_mail/sendmail.php $INFO_LOG_FILE $subject",$out,$ret);
	if($ret!=0)
	{
		echo "\nERROR: Failed send mail cmd\n";
	}

	exec("rm -f -- $INFO_LOG_FILE", $out, $ret);
}

function is_pid_current_program($pid)
{
	global $argv;

	exec("ps $pid",$out,$ret);
	if (count($out) >= 2)
	{
		exec("xargs -0 < /proc/$pid/cmdline | sed 's/ //g' | grep '".implode("",$argv)."'", $my_out, $ret);
		// print_r($my_out);
		if (count($my_out) == 1)
		{
			$msg = "PID is current program";
			echo $msg;
			write_info_file($msg);
			return true;
		}
		$msg = "PID file exists and process running, however, process is not this program.\n";
		echo $msg;
		write_info_file($msg);
		return false;
	}
	$msg = "PID file exists, however process is not running";
	echo $msg;
	write_info_file($msg);
	return false;
}

function read_status_file()
{
	global $STATUS_FILE;

	$file = fopen($STATUS_FILE, 'r');
	if (!$file) {
		return null;
	}

	$s = explode(',', fgets($file));
	fclose($file);

	$status['last_success_start_time'] =$s[0];
	$status['cur_start_time'] =$s[1];
	$status['cur_pid'] =$s[2];
	return $status;
}

function write_status_file_start()
{
	global $STATUS_FILE;

	$status_in = read_status_file();
	if (!$status_in) {
		$status_in['last_success_start_time'] = 0;
	}

	$file = fopen($STATUS_FILE, 'w');
	if (!$file) {
		return null;
	}

	$status = $status_in['last_success_start_time'] . ',' . time() . ',' . getmypid();
	fwrite($file, $status);
	fclose($file);
}

function write_status_file($is_success)
{
	global $STATUS_FILE, $SOURCE_USERNAME, $SOURCE_PASSWORD, $SOURCE_LOCAL_HOST;

	$status_in = read_status_file();
	if (!$status_in) {
		return null;
	}

	$file = fopen($STATUS_FILE, 'w');
	if (!$file) {
		return null;
	}

	if ($is_success) {
		//in case of replication lag, consider seconds behind master in next run of cron
		//$cmd_get_replication_lag="ps -ef | wc -l";
		$cmd_get_replication_lag="mysql -u$SOURCE_USERNAME -p$SOURCE_PASSWORD -h$SOURCE_LOCAL_HOST -e 'SHOW SLAVE STATUS\G' | grep Seconds_Behind_Master | cut -d':' -f2";

		//in case of error, sec_behind_master=0
		$sec_behind_master=intval(exec($cmd_get_replication_lag));

		//to avoid any misses, consider 1.5 times lag than current value of sec_behind_master
		if ($sec_behind_master > 0)
			$sec_behind_master = ceil($sec_behind_master * 1.5);

		$status = $status_in['cur_start_time']-$sec_behind_master . ',0,0';
		$msg = "\nwrite_status_file_success: $status = ".$status_in['cur_start_time']."(cur_start_time)-$sec_behind_master(seconds_behind_master)\n";
	}
	else {
		$status = $status_in['last_success_start_time'] . ',0,0';
		$msg = "\nwrite_status_file_failure: $status = ".$status_in['last_success_start_time']."(last_success_start_time)\n";
	}

	echo $msg;
	write_info_file($msg);

	fwrite($file, $status);
	fclose($file);
}

function format_timestamp($ts) {
	if ($ts == 0) {
		return 0;
	}
	return date("Y-m-d H:i:s", $ts);
}

function handle_first_period($status) {
	global $TMP_EMAIL_FILE, $BLOOM_BASE_DIR;

	$msg = "ERROR: Previous instance of bloom_filter_generator.php still running in first execution period: " . format_timestamp($status['last_success_start_time']) . ',' . format_timestamp($status['cur_start_time']) . ',' . format_timestamp($status['cur_pid']);
	echo $msg;

	send_report($TMP_EMAIL_FILE, $BLOOM_BASE_DIR, $msg);
	return null;
}

function handle_second_period($status) {
	global $REPORT_FILE, $BLOOM_BASE_DIR;

	$msg = "ERROR: Previous instance of bloom_filter_generator.php still running in second execution period: " . format_timestamp($status['last_success_start_time']) . ',' . format_timestamp($status['cur_start_time']) . ',' . format_timestamp($status['cur_pid']);
	echo $msg;
	send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
	return null;
}

/*
 * Returns: Bloom execution time in hours
 */
function handle_third_period($status) {
	if (is_pid_current_program($status['cur_pid'])) {
		$cmd = 'kill -9 ' . $status['cur_pid'];
		exec($cmd,$output,$retval);
	}

	if ($status['last_success_start_time'] <= 0) {
		return null;
	}
	$bloom_execution_time = $status['last_success_start_time'];
	return $bloom_execution_time;
}

/*
 * handle_running_instance
 * -----------------------
 * Returns: if null, then exit
 *   else use return value as Bloom execution time in hours.
 * Caveat: This function must be called before write_status_file_start so
 * that this function can refer to start time of the long running process
 * as * $status['cur_start_time']
 */
function handle_running_instance() {
	global $EXECUTION_PERIOD;

	$status = read_status_file();
	if (!$status) {
		return null;
	}

	$run_time = time() - $status['cur_start_time'];
	$msg = "\nIn handle_running_instance $run_time\n";
	echo $msg;
	write_info_file($msg);
	if ($run_time < $EXECUTION_PERIOD * 60) {
		$msg = "\nWarning: Please check if execution period in cron matches that specifed in the command line arguments: $EXECUTION_PERIOD\n";
		echo $msg;
		write_info_file($msg);
		return null;
	} elseif ($run_time < 2 * $EXECUTION_PERIOD * 60) {
		$msg = "\n## First execution period\n";
		echo $msg;
		write_info_file($msg);
		return handle_first_period($status);
	} elseif ($run_time < 3 * $EXECUTION_PERIOD * 60) {
		$msg = "\n## Second execution period\n";
		echo $msg;
		write_info_file($msg);
		return handle_second_period($status);
		// } elseif ($run_time < 4 * $EXECUTION_PERIOD * 60) {
	} else {
		$msg = "\n## Third execution period\n";
		echo $msg;
		write_info_file($msg);
		return handle_third_period($status);
	}
	return null;
}

function get_last_success_start_time($bloom_execution_time, $default) {
	if ($bloom_execution_time) {
		return $bloom_execution_time;
	} else {
		return $default;
	}
}

function db_reconnect($SOURCE_HOST, $SOURCE_USERNAME, $SOURCE_PASSWORD, $SOURCE_DB) {
	global $REPORT_FILE, $BLOOM_BASE_DIR, $LAST_INSTANCE_CHECK_FILE;

	$source_con=mysqli_connect($SOURCE_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD);
	if(!$source_con) {
		$msg = "\nERROR::$config_param[0]: $SOURCE_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);

	} else {
		$result_del=mysqli_select_db($source_con,$SOURCE_DB);
		if (!$result_del) {
			$msg = "\nERROR::DB.$SOURCE_DB Selection Failed...\n".mysqli_error($source_con)."\n";
			echo $msg;
			cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
		}
	}
	return $source_con;
}

function send_report($file,$bloom_base_dir,$message)
{
	global $config_param;

	$contents = $message;
	file_put_contents($file,$contents);

	// KGAP: Is the subject okay?
	$subject = "BLOOM_".$config_param[1]."_GENERATOR";

	# Send the report via mail
	exec("php $bloom_base_dir/send_mail/sendmail.php $file $subject",$out,$ret);
	if($ret!=0)
	{
		echo "\nERROR: Failed send mail cmd\n";
	}

	exit;
}

function cleanup_and_report($file,$bloom_base_dir,$pid_file,$message)
{
	email_info_file();
	write_status_file(0);
	if(file_exists($pid_file))
	{
		unlink($pid_file);
	}
	send_report($file,$bloom_base_dir,$message);
}

$msg = "\n** SCRIPT START **@".date("Y-m-d-H:i:s")."\nAttempting to acquire PID file lock on $LAST_INSTANCE_CHECK_FILE\n";
echo $msg;
write_info_file($msg);

$status_in = read_status_file();
if (!$status_in)
	$bloom_execution_time = 0;
else
	$bloom_execution_time = $status_in['last_success_start_time'];

//check for last instance of the process
if(file_exists($LAST_INSTANCE_CHECK_FILE)) {
	exec("cat $LAST_INSTANCE_CHECK_FILE",$pid,$ret);
	if($ret!=0) {
		$msg = "\nERROR: Failed cat cmd\n";
		echo $msg;
		send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
	}
	$msg = "\npid in $LAST_INSTANCE_CHECK_FILE:$pid[0]\n";
	echo $msg;
	write_info_file($msg);
	if (is_pid_current_program($pid[0]))
	{
		$bloom_execution_time = handle_running_instance();
		if (!$bloom_execution_time) {
			$msg = "\nERROR: Last Instance of bloom filter generator script is still running..., PID:$pid[0]\n$LAST_INSTANCE_CHECK_FILE\n$bloom_execution_time\nExiting...\n";
			echo $msg;
			send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
		} else {
			$msg = "\nINFO::Force terminated last instance of bloom filter generator script.  Starting new instance with Bloom execution time $bloom_execution_time\n";
			echo $msg;
			write_info_file($msg);
			$pid_fd = fopen($LAST_INSTANCE_CHECK_FILE, 'w');
			if(!$pid_fd)
			{
				$msg = "\nERROR: Failed to open $LAST_INSTANCE_CHECK_FILE\n";
				echo $msg;
				send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
			}
			fwrite($pid_fd, getmypid());
			fclose($pid_fd);
			write_status_file_start();
		}
	}
	else
	{
		$msg = "\nINFO::pid file Exist, No last instance running, mypid:".getmypid()."\n";
		echo $msg;
		write_info_file($msg);
		$pid_fd = fopen($LAST_INSTANCE_CHECK_FILE, 'w');
		if(!$pid_fd)
		{
			$msg = "\nERROR: Failed to open $LAST_INSTANCE_CHECK_FILE\n";
			echo $msg;
			send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
		}
		fwrite($pid_fd, getmypid());
		fclose($pid_fd);
		write_status_file_start();
	}
}
else
{
	$msg = "\nINFO::pid file '$LAST_INSTANCE_CHECK_FILE' does Not Exist, No last instance running, mypid:".getmypid()."\n";
	echo $msg;
	write_info_file($msg);
	$pid_fd = fopen($LAST_INSTANCE_CHECK_FILE, 'w');
	if(!$pid_fd)
	{
		$msg = "\nERROR: Failed to open $LAST_INSTANCE_CHECK_FILE\n";
		echo $msg;
		send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
	}
	fwrite($pid_fd, getmypid());
	fclose($pid_fd);
	write_status_file_start();
}

//connect to local db
$source_con_local=mysqli_connect($SOURCE_LOCAL_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con_local)
{
	$msg = "\nERROR::$config_param[0]: $SOURCE_LOCAL_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	echo $msg;
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
}
$msg = "\nConnected to Local MySQL DB: $config_param[0]: $SOURCE_LOCAL_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD\n";
echo $msg;
write_info_file($msg);

//connect to BrandShield db
$source_con_brand=mysqli_connect($SOURCE_BRAND_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con_brand)
{
	$msg = "\nERROR::$config_param[0]: $SOURCE_BRAND_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	echo $msg;
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
}
$msg = "\nConnected to BrandShield MySQL DB: $config_param[0]: $SOURCE_BRAND_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD\n";
echo $msg;
write_info_file($msg);

//connect to ADS.TXT crawler db
$source_con_ads_txt=mysqli_connect($SOURCE_ADS_TXT_CRAWLER_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con_ads_txt)
{
	$msg = "\nERROR::$config_param[0]: $SOURCE_ADS_TXT_CRAWLER_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	echo $msg;
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
}
$msg = "\nConnected to ADS.TXT crawler MySQL DB: $config_param[0]: $SOURCE_ADS_TXT_CRAWLER_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD\n";
echo $msg;
write_info_file($msg);

//connect to ceaser db
$source_con_ceaser=mysqli_connect($SOURCE_CEASER_DB_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con_ceaser)
{
	$msg = "\nERROR::$config_param[0]: $SOURCE_CEASER_DB_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	echo $msg;
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
}
$msg = "\nConnected to Ceaser MySQL DB: $config_param[0]: $SOURCE_CEASER_DB_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD\n";
echo $msg;
write_info_file($msg);

//connect to RawData db
$source_con_rawdata=mysqli_connect($SOURCE_RAWDATA_DB_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con_rawdata)
{
	$msg = "\nERROR::$config_param[0]: $SOURCE_RAWDATA_DB_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	echo $msg;
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
}
$msg = "\nConnected to RawData MySQL DB: $config_param[0]: $SOURCE_RAWDATA_DB_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD\n";
echo $msg;
write_info_file($msg);

//connect to CreativeIngestor db
$source_con_crtv_ingestor=mysqli_connect($SOURCE_CRTV_INGESTOR_DB_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con_crtv_ingestor)
{
	$msg = "\nERROR::$config_param[0]: $SOURCE_CRTV_INGESTOR_DB_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	echo $msg;
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
}
$msg = "\nConnected to CreativeIngestor MySQL DB: $config_param[0]: $SOURCE_CRTV_INGESTOR_DB_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD\n";
echo $msg;
write_info_file($msg);


//connect to MasterMain db
$source_con_maindb=mysqli_connect($SOURCE_HOST_MAINDB,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con_maindb)
{
	$msg = "\nERROR::$config_param[0]: $SOURCE_HOST_MAINDB:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	echo $msg;
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
}
$msg = "\nConnected to MasterMain MySQL DB: $config_param[0]: $SOURCE_HOST_MAINDB:$SOURCE_USERNAME:$SOURCE_PASSWORD\n";
echo $msg;
write_info_file($msg);

$has_db_connection = 1;
$found_updates = 0;

//operId : arg1 to be passed to bloom _filter_generator binary
$operId = array(
	"LANDING_PAGE_FILTER"	=> 1,
	"GLOBAL_LANDING_PAGE_FILTER" => 1,
	"CREATIVE_ID_FILTER" => 2,
	"WHITELIST_BLOOM_FILTER" => 4,
	"DSP_BLOCKLIST_FILTER" => 5,
	"GSS_BLOCKLIST_FILTER" => 8,
	"UNIQ_CREATIVE_BLOOM_FILTER" => 9,
	"DSP_WHITELIST_FILTER" => 10,
	"DSP_APPURL_BLOCKLIST_FILTER" => 11,
	"DSP_APPURL_WHITELIST_FILTER" => 12,
	"DAA_DEVICE_OPTOUT_BLOOM_FILTER" => 14,
	"GLOBAL_CREATIVE_ID_BLOOM_FILTER" => 15,
	"PUBLISHER_CAMPAIGN_BLOCKLIST_FILTER" => 16,
	"GLOBAL_ADS_TXT_DOMAIN_LIST_FILTER" => 17,
	"PUB_LEVEL_ADS_TXT_DOMAIN_LIST_FILTER" => 17,
	"PUB_GEO_DOMAIN_BLOCKLIST_BLOOM_FILTER" => 18,
	"PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER" => 19,
	"NEW_LANDING_PAGE_FILTER" => 20,
	"GLOBAL_APP_ADS_TXT_FILTER" => 21,
	"PUB_LEVEL_APP_ADS_TXT_FILTER" => 21,
	"PUBLISHER_SITE_TLD_WHITELIST" => 22,
	"CLASSIFIED_CREATIVES_SMALL_BLOOM" => 23,
	"CLASSIFIED_CREATIVES_GIANT_BLOOM" => 24,
);

//Main Loop over all input filters
for($j=1;$j<count($config_param);$j++)
{
	$msg = "\n---".$config_param[$j]." start--".date("Y-m-d-H:i:s")."---\n";
	echo $msg;
	write_info_file($msg);
	$cmd=$FILTER_GENERATOR_BIN." ".$operId[$config_param[$j]];
	$raw_cmd=$cmd;

	if($has_db_connection !=1){
		$msg = "\nERROR::$config_param[$j]: No DB Connection\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
	}
	//read config.ini
	$SELECT_QUERY=$config[$config_param[$j]]['select.updated.or.partial.removed.id'];
	$SELECT_REMOVED_QUERY=$config[$config_param[$j]]['select.complete.removed.id'];
	$DELETE_QUERY=$config[$config_param[$j]]['delete.complete.removed.id'];
	$SELECT_QUERY=str_replace("INTERVAL_SECONDS",
		format_timestamp(get_last_success_start_time($bloom_execution_time, $INTERVAL_SECONDS)),
		$SELECT_QUERY);

	$SOURCE_HOST = $SOURCE_LOCAL_HOST;
	$source_con = $source_con_local;
	$SOURCE_DB = $SOURCE_KAD_DB; //use KomliAdServer

	//choose database
	switch($config_param[$j])
	{
	case "LANDING_PAGE_FILTER":
	case "DAA_DEVICE_OPTOUT_BLOOM_FILTER":
		$SOURCE_HOST = $SOURCE_BRAND_HOST;
		$source_con = $source_con_brand;
		break;
	case "WHITELIST_BLOOM_FILTER":
	case "GSS_BLOCKLIST_FILTER":
	case "GLOBAL_LANDING_PAGE_FILTER":
	case "PUBLISHER_SITE_TLD_WHITELIST":
		break;
	case "CREATIVE_ID_FILTER":
		$SOURCE_HOST = $SOURCE_BRAND_HOST;
		$source_con = $source_con_brand;
		$SOURCE_DB = $SOURCE_ADF_DB; //use AdFlex
		break;
	case "DSP_BLOCKLIST_FILTER":
	case "DSP_WHITELIST_FILTER":
	case "DSP_APPURL_WHITELIST_FILTER":
	case "DSP_APPURL_BLOCKLIST_FILTER":
	case "PUB_GEO_DOMAIN_BLOCKLIST_BLOOM_FILTER":
		$SOURCE_DB = $SOURCE_ADF_DB; //use AdFlex
		break;
	case "GLOBAL_CREATIVE_ID_BLOOM_FILTER":
	case "PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER":
	case "CLASSIFIED_CREATIVES_SMALL_BLOOM":
	case "CLASSIFIED_CREATIVES_GIANT_BLOOM":
		$SOURCE_HOST = $SOURCE_BRAND_HOST;
		$source_con = $source_con_brand;
		$SOURCE_DB = $SOURCE_ADF_DB; //use AdFlex
		break;
	case "PUBLISHER_CAMPAIGN_BLOCKLIST_FILTER":
		$SOURCE_DB = $SOURCE_ADF_DB; //use AdFlex
		break;
	case "GLOBAL_ADS_TXT_DOMAIN_LIST_FILTER":
	case "PUB_LEVEL_ADS_TXT_DOMAIN_LIST_FILTER":
	case "GLOBAL_APP_ADS_TXT_FILTER":
	case "PUB_LEVEL_APP_ADS_TXT_FILTER":
		$SOURCE_HOST = $SOURCE_ADS_TXT_CRAWLER_HOST;
		$source_con = $source_con_ads_txt;
		$SOURCE_DB = $SOURCE_ADS_TXT_CRAWLER_DB;
		break;
	case "NEW_LANDING_PAGE_FILTER":
		$SOURCE_HOST = $SOURCE_CEASER_DB_HOST;
		$source_con = $source_con_ceaser;
		$SOURCE_DB = $SOURCE_CEASER_DB;
		break;
	case "UNIQ_CREATIVE_BLOOM_FILTER":
		$SOURCE_HOST = $SOURCE_CRTV_INGESTOR_DB_HOST;
		$source_con = $source_con_crtv_ingestor;
		$SOURCE_DB = $SOURCE_CRTV_INGESTOR_DB;
		break;
	default: //exit
		$msg = "\nERROR:: Invalid Filter : $config_param[$j]\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
	}

	$result=mysqli_select_db($source_con,$SOURCE_DB);
	if(!$result)
	{
		$msg = "\n2".date("Y-m-d-H:i:s")."\n\nresult_del:$result\n";
		echo $msg;
		write_info_file($msg);
		$source_con = db_reconnect($SOURCE_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD,$SOURCE_DB);
	}
	$msg = "\nSuccessfully selected DB: $SOURCE_DB\n";
	echo $msg;
	write_info_file($msg);

	$result=mysqli_query($source_con,$SELECT_QUERY);
	if(!$result)
	{
		$msg = "\nERROR::$config_param[$j]: Query Execution Failed: $SELECT_QUERY\n".mysqli_error($source_con)."\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
	}
	$msg = "\n$config_param[$j]:: Select Query Fired @".date("Y-m-d-H:i:s")." : $SELECT_QUERY\n";
	echo $msg;
	write_info_file($msg);

	while($row = mysqli_fetch_assoc($result))
	{
		$msg = "\n$config_param[$j]:: ".implode(" ",$row)."\n";
		echo $msg;
		write_info_file($msg);
		$cmd=$cmd." ".implode(" ",$row);
	}
	mysqli_free_result($result);

	// DELETE completely removed entries from bloom filter table
	$result=mysqli_query($source_con,$SELECT_REMOVED_QUERY);
	if(!$result)
	{
		$msg = "\nERROR::$config_param[$j]: Query Execution Failed: $SELECT_REMOVED_QUERY\n".mysqli_error($source_con)."\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
	}

	$msg = "\n$config_param[$j]:: Select Removed Query Fired @".date("Y-m-d-H:i:s")." : $SELECT_REMOVED_QUERY \n";
	echo $msg;
	write_info_file($msg);
	$msg = "\n1 : ".date("Y-m-d-H:i:s")."\n";
	echo $msg;
	write_info_file($msg);
	$result_del=mysqli_select_db($source_con_maindb,$SOURCE_KAD_DB);
	if(!$result_del)
	{
		$msg = "\n2 : ".date("Y-m-d-H:i:s")."\n\nresult_del:$result_del\n";
		echo $msg;
		write_info_file($msg);
		$source_con_maindb = db_reconnect($SOURCE_HOST_MAINDB,$SOURCE_USERNAME,$SOURCE_PASSWORD,$SOURCE_KAD_DB);
	}
	$msg = "\nSuccessfully selected DB: $SOURCE_KAD_DB\n";
	echo $msg;
	write_info_file($msg);

	while($row = mysqli_fetch_array($result))
	{
		$QUERY = str_replace("COLUMN_1",$row[0],$DELETE_QUERY);
		if(isset($row[1]))
			$QUERY = str_replace("COLUMN_2",$row[1],$QUERY);
		if(isset($row[2]))
			$QUERY = str_replace("COLUMN_3",$row[2],$QUERY);

		$result_del=mysqli_query($source_con_maindb,$QUERY);
		if(!$result_del)
		{
			$msg = "\nERROR::$config_param[$j]: MasterMainDB.Query Execution Failed: $QUERY\n".mysqli_error($source_con)."\n";
			echo $msg;
			cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
		}
		$msg = "\nDelete Query Fired: $QUERY\n";
		echo $msg;
		write_info_file($msg);
	}
	mysqli_free_result($result);

	if($cmd == $raw_cmd) {
		$msg = "\n*** NO MODIFICATIONS IN $config_param[$j] ***\n\n---".$config_param[$j]." end--".date("Y-m-d-H:i:s")."---\n";
		echo $msg;
		write_info_file($msg);
		continue;
	}

	$found_updates = 1;
	$msg = "\n$config_param[$j]:: Generation Command:\n$cmd\n";
	echo $msg;
	write_info_file($msg);

	$retval = 0;
	//Execute Application
	exec($cmd,$output,$retval);
	if($retval!=0)
	{
		$msg = "\nERROR::$config_param[$j]: Execution of $cmd Failed, retval:$retval\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
	}

	$msg = "\n---".$config_param[$j]." end--".date("Y-m-d-H:i:s")."---\n";
	echo $msg;
	write_info_file($msg);
}

$msg = "\n** SCRIPT END **@".date("Y-m-d-H:i:s")."\n";
echo $msg;
write_info_file($msg);

email_info_file();
write_status_file(1);
if($source_con_local)
{
	mysqli_close($source_con_local);
}
if($source_con_brand)
{
	mysqli_close($source_con_brand);
}
if($source_con_ads_txt)
{
	mysqli_close($source_con_ads_txt);
}
if($source_con_ceaser)
{
	mysqli_close($source_con_ceaser);
}
if($source_con_rawdata)
{
	mysqli_close($source_con_rawdata);
}
if($source_con_maindb)
{
	mysqli_close($source_con_maindb);
}
if($source_con_crtv_ingestor)
{
	mysqli_close($source_con_crtv_ingestor);
}
if(file_exists($LAST_INSTANCE_CHECK_FILE))
{
	unlink($LAST_INSTANCE_CHECK_FILE);
}
?>
