<?php
/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


/* Usage
 * =====
 * php publisher_site_floor_rule.php [-p <execution_period>]
 * execution_period := int (Period in which the script will be re-run (in minutes))
 */

//set default timezone
date_default_timezone_set("America/Los_Angeles");

$CONFIG_FILE="/SCRIPTS/BLOOM_FILTER_GENERATION/conf/config.ini";


$config_list="SET_CONFIG,PUBLISHER_SITE_DEAL_WHITELIST_FILTER,PUBLISHER_SITE_FLOOR_FILTER_ADVERTISER,PUBLISHER_SITE_FLOOR_FILTER_DOMAIN,PUBLISHER_SITE_FLOOR_FILTER_CATEGORY";

function get_cmd_line_options() {
        global $EXECUTION_PERIOD;  // in minutes
        global $config_param, $argv;

        $config_param[]="SET_CONFIG";

        $EXECUTION_PERIOD = getopt('p:');
        if (isset($EXECUTION_PERIOD['p'])) {
                $EXECUTION_PERIOD = $EXECUTION_PERIOD['p'];
        } else {
                $EXECUTION_PERIOD = 60;  // 60 minutes.
        }
        foreach (array_slice($argv, 1) as $configs) {
                if ('A' <= $configs[0] && $configs[0] <= 'Z') {
                        $config_param[]=$configs;
                }
        }
}

get_cmd_line_options();
if (count($config_param) == 1) {
        $config_param=split(",",$config_list);
}

$config=parse_ini_file("$CONFIG_FILE",1);

$has_db_connection=0;

$psff=6;

$active_entity=0;

//Exec script on server other than main DB, execute bin on main DB
//$master_db_user='mukulkedare';
//$master_db_host='10.0.12.63';
//$ssh_cmd='/usr/bin/ssh';

//read config.ini. It will be used to perform select query on ADSERVER
$SOURCE_HOST=$config[$config_param[0]]['db.local.host.name'];
$SOURCE_KAD_DB=$config[$config_param[0]]['db.kad.dsn.name'];
$SOURCE_ADF_DB=$config[$config_param[0]]['db.adf.dsn.name'];
$SOURCE_USERNAME=$config[$config_param[0]]['db.dsn.user.name'];
$SOURCE_PASSWORD=$config[$config_param[0]]['db.dsn.user.password'];

//read config.ini. It will be used to perform select query on MAINDB
$SOURCE_HOST_MAINDB=$config[$config_param[0]]['db.master.host.name'];

$uniq_name = implode(":",$argv).":";
$uniq_name = substr($uniq_name, strpos($uniq_name, ':')+1, strlen($uniq_name));
$BLOOM_BASE_DIR=$config[$config_param[0]]['bloom.base.dir'];
$uniq_name = "PSFR:".$uniq_name;
$FILTER_GENERATOR_BIN=$BLOOM_BASE_DIR."/".$config[$config_param[0]]['filter.generator.bin'];
$LAST_INSTANCE_CHECK_FILE=$BLOOM_BASE_DIR."/.PSFR_".$config[$config_param[0]]['last.instance.check.file'];
$STATUS_FILE=$BLOOM_BASE_DIR."/.$uniq_name"."status";
$REPORT_FILE=$BLOOM_BASE_DIR."/PSFR_".$config[$config_param[0]]['report.file'];
$REPORT_FILE=$BLOOM_BASE_DIR."/PSFR_$uniq_name.REPORT.txt";
$INFO_LOG_FILE=$BLOOM_BASE_DIR."/PSFR_$uniq_name.INFO.txt";
$TMP_EMAIL_FILE=$BLOOM_BASE_DIR."/PSFR_$uniq_name.EMAIL.txt";
//default time interval = cron execution time, this will be overwrittne from status file
$INTERVAL_SECONDS = time() - $EXECUTION_PERIOD * 60;
//$new_cmd = "chmod 777 $LAST_INSTANCE_CHECK_FILE";
//exec($new_cmd,$output,$retval);

function write_info_file($msg) {
	global $INFO_LOG_FILE;

	$file = fopen($INFO_LOG_FILE, "a");
	fwrite($file, $msg);
	fclose($file);
}

function email_info_file() {
	global $BLOOM_BASE_DIR, $INFO_LOG_FILE, $uniq_name;

	$subject = "BLOOM_GENERATOR_INFO:".$uniq_name;
	//$subject = "BLOOM_".$config_param[1]."_GENERATOR";

	# Send the report via mail
	exec("php $BLOOM_BASE_DIR/send_mail/sendmail.php $INFO_LOG_FILE $subject",$out,$ret);
	if($ret!=0) 
	{
		$msg = "\nERROR: Failed send mail cmd\n";
		echo $msg;
		write_info_file($msg);
	}

	exec("rm -f -- $INFO_LOG_FILE", $out, $ret);
}

function is_pid_current_program($pid)
{
	global $argv;

	exec("ps $pid",$out,$ret);
	if (count($out) >= 2)
	{
		exec("xargs -0 < /proc/$pid/cmdline | sed 's/ //g' | grep '".implode("",$argv)."'", $my_out, $ret);
		// print_r($my_out);
		if (count($my_out) == 1)
		{
			$msg = "PID is current program";
			echo $msg;
			write_info_file($msg);
			return true;
		}
		$msg = "PID file exists and process running, however, process is not this program.\n";
		echo $msg;
		write_info_file($msg);
		return false;
	}
	$msg = "PID file exists, however process is not running";
	echo $msg;
	write_info_file($msg);
	return false;
}

function read_status_file()
{
	global $STATUS_FILE;

	$file = fopen($STATUS_FILE, 'r');
	if (!$file) {
		return null;
	}

	$s = split(',', fgets($file));
	fclose($file);

	$status['last_success_start_time'] =$s[0];
	$status['cur_start_time'] =$s[1];
	$status['cur_pid'] =$s[2];
	return $status;
}

function write_status_file_start()
{
	global $STATUS_FILE;

	$status_in = read_status_file();
	if (!$status_in) {
		$status_in['last_success_start_time'] = 0;
	}

	$file = fopen($STATUS_FILE, 'w');
	if (!$file) {
		return null;
	}

	$status = $status_in['last_success_start_time'] . ',' . time() . ',' . getmypid();
	fwrite($file, $status);
	fclose($file);
}

function write_status_file($is_success)
{
	global $STATUS_FILE, $SOURCE_USERNAME, $SOURCE_PASSWORD, $SOURCE_LOCAL_HOST;

	$status_in = read_status_file();
	if (!$status_in) {
		return null;
	}

	$file = fopen($STATUS_FILE, 'w');
	if (!$file) {
		return null;
	}
	
	if ($is_success) {
		//in case of replication lag, consider seconds behind master in next run of cron
		//$cmd_get_replication_lag="ps -ef | wc -l";
		$cmd_get_replication_lag="mysql -u$SOURCE_USERNAME -p$SOURCE_PASSWORD -h$SOURCE_HOST -e 'SHOW SLAVE STATUS\G' | grep Seconds_Behind_Master | cut -d':' -f2";

		//in case of error, sec_behind_master=0
		$sec_behind_master=intval(exec($cmd_get_replication_lag));

		//to avoid any misses, consider 1.5 times lag than current value of sec_behind_master
		if ($sec_behind_master > 0)
			$sec_behind_master = ceil($sec_behind_master * 1.5);

		$status = $status_in['cur_start_time']-$sec_behind_master . ',0,0';
		$msg = "\nwrite_status_file_success: $status = ".$status_in['cur_start_time']."(cur_start_time)-$sec_behind_master(seconds_behind_master)\n";
	}
	else {
		$status = $status_in['last_success_start_time'] . ',0,0';
		$msg = "\nwrite_status_file_failure: $status = ".$status_in['last_success_start_time']."(last_success_start_time)\n";
	}

	echo $msg;

	fwrite($file, $status);
	fclose($file);
}


function format_timestamp($ts) {
	if ($ts == 0) {
		return 0;
	}
	return date("Y-m-d H:i:s", $ts);
}

function handle_first_period($status) {
	global $TMP_EMAIL_FILE, $BLOOM_BASE_DIR;

	$msg = "Previous instance of publisher_site_floor_rule.php still running " . format_timestamp($status['last_success_start_time']) . ',' . format_timestamp($status['cur_start_time']) . ',' . format_timestamp($status['cur_pid']);
	echo $msg;
	write_info_file($msg);

	send_report($TMP_EMAIL_FILE, $BLOOM_BASE_DIR, $msg);
	return null;
}

function handle_second_period($status) {
	global $REPORT_FILE, $BLOOM_BASE_DIR;

	$msg = "ERROR: Previous instance of publisher_site_floor_rule.php still running in second execution period: " . format_timestamp($status['last_success_start_time']) . ',' . format_timestamp($status['cur_start_time']) . ',' . format_timestamp($status['cur_pid']);
	echo $msg;
	send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
	return null;
}

/*
 * Returns: Bloom execution time in hours
 */
function handle_third_period($status) {
	if (is_pid_current_program($status['cur_pid'])) {
		$cmd = 'kill -9 ' . $status['cur_pid'];
		exec($cmd,$output,$retval);
	}

	if ($status['last_success_start_time'] <= 0) {
		return null;
	}
	$bloom_execution_time = $status['last_success_start_time'];
	return $bloom_execution_time;
}

/*
 * Returns: if null, then exit
 *   else use return value as Bloom execution time in hours.
 * Caveat: This function must be called before write_status_file_start so
 * that this function can refer to start time of the long running process
 * as * $status['cur_start_time']
 */
function handle_running_instance() {
	global $EXECUTION_PERIOD;

	$status = read_status_file();
	if (!$status) {
		return null;
	}

	$run_time = time() - $status['cur_start_time'];
	$msg = "\nIn handle_running_instance $run_time\n";
	echo $msg;
	write_info_file($msg);
	if ($run_time < $EXECUTION_PERIOD * 60) {
		$msg = "\nWarning: Please check if execution period in cron matches that specifed in the command line arguments: $EXECUTION_PERIOD\n";
		echo $msg;
		write_info_file($msg);
		return null;
	} elseif ($run_time < 2 * $EXECUTION_PERIOD * 60) {
		$msg = "\n## First execution period\n";
		echo $msg;
		write_info_file($msg);
		return handle_first_period($status);
	} elseif ($run_time < 3 * $EXECUTION_PERIOD * 60) {
		$msg = "\n## Second execution period\n";
		echo $msg;
		write_info_file($msg);
		return handle_second_period($status);
	// } elseif ($run_time < 4 * $EXECUTION_PERIOD * 60) {
	} else {
		$msg = "\n## Third execution period\n";
		echo $msg;
		write_info_file($msg);
		return handle_third_period($status);
	}
	return null;
}

function get_last_success_start_time($bloom_execution_time, $default) {
	if ($bloom_execution_time) {
		return $bloom_execution_time;
	} else {
		return $default;
	}
}

function db_reconnect($SOURCE_HOST_MAINDB, $SOURCE_USERNAME, $SOURCE_PASSWORD, $SOURCE_DB) {
	$source_con=mysql_connect($SOURCE_HOST_MAINDB,$SOURCE_USERNAME,$SOURCE_PASSWORD);
	if(!$source_con) {
		$msg = "\nERROR::$config_param[0]: $SOURCE_HOST_MAINDB:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);

	} else {
		$result_del=mysql_select_db($SOURCE_DB,$source_con);
		if(!$result_del)
		{
			$msg = "\nERROR::$filter_type: MasterMainDB.$SOURCE_DB Selection Failed...\n".mysql_error()."\n";
			echo $msg;
			cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
		}
	}
	return $source_con;
}

function send_report($file,$bloom_base_dir,$message)
{
	global $config_param;

	$contents = $message;
	file_put_contents($file,$contents);

	// KGAP: Is the subject okay?
	$subject = "BLOOM_".$config_param[1]."_GENERATOR";

	# Send the report via mail
	exec("php $bloom_base_dir/send_mail/sendmail.php $file $subject",$out,$ret);
	if($ret!=0) 
	{
		$msg = "\nERROR: Failed send mail cmd\n";
		echo $msg;
		write_info_file($msg);
	}

	exit;
}

function cleanup_and_report($file,$bloom_base_dir,$pid_file,$message)
{
	email_info_file();
	write_status_file(0);
	if(file_exists($pid_file))
	{
		unlink($pid_file);
	}
	send_report($file,$bloom_base_dir,$message);
}

function remove_deleted_filter(
	$filter_type,
	$con,
	$db_host,
	$db_username,
	$db_password,
	$db_name,
	$select_removed_query,
	$delete_query
) {

	$result=mysql_select_db($db_name,$con);
	if(!$result)
	{
		$msg = "\n2".date("Y-m-d-H:i:s")."\n\nresult_del:$result\n";
		echo $msg;
		write_info_file($msg);
		$con = db_reconnect($db_host,$db_username,$db_password,$db_name);
	}

	$result=mysql_query($select_removed_query,$con);
	if(!$result) 
	{
		$msg = "\nERROR::$filter_type Query Execution Failed: $select_removed_query\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
	}

	while($row = mysql_fetch_array($result))
	{
		//delete publisher site from bloom filter table
		$query=$delete_query;
		$query=str_replace("PUBLISHER_ID",$row[0],$query);
		$query=str_replace("SITE_ID",$row[1],$query);
		$result_del=mysql_query($query,$con);
		if(!$result_del)
		{
			$msg = "\nERROR::$filter_type: Query Execution Failed: $query\n".mysql_error()."\n";
			echo $msg;
			cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
		}

		$msg = "\nDeleted $filter_type:: pub_id:".$row['pub_id']." site_id:".$row['site_id']."\n";
		echo $msg;
		write_info_file($msg);
	}
	mysql_free_result($result);
}

$msg = "\n** SCRIPT START **@".date("Y-m-d-H:i:s")."\nAttempting to acquire PID file lock on $LAST_INSTANCE_CHECK_FILE\n";
echo $msg;
write_info_file($msg);

$status_in = read_status_file();
if (!$status_in)
	$bloom_execution_time = 0;
	else
	$bloom_execution_time = $status_in['last_success_start_time'];

//check for last instance of the process
if(file_exists($LAST_INSTANCE_CHECK_FILE)) {
	exec("cat $LAST_INSTANCE_CHECK_FILE",$pid,$ret);
	if($ret!=0) {
		$msg = "\nERROR: Failed cat cmd\n";
		echo $msg;
		send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
	}
	$msg = "\npid in $LAST_INSTANCE_CHECK_FILE:$pid[0]\n";
	echo $msg;
	write_info_file($msg);
	if (is_pid_current_program($pid[0]))
	{
		$bloom_execution_time = handle_running_instance();
		if (!$bloom_execution_time) {
			$msg = "\nERROR: Last Instance of bloom filter generator script is still running..., PID:$pid[0]\nExiting...\n";
			echo $msg;
			send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
		} else {
			$msg = "\nINFO::Force terminated last instance of bloom filter generator script.  Starting new instance with Bloom execution time $bloom_execution_time\n";
			echo $msg;
			write_info_file($msg);
			$pid_fd = fopen($LAST_INSTANCE_CHECK_FILE, 'w');
			if(!$pid_fd)
			{
				$msg = "\nERROR: Failed to open $LAST_INSTANCE_CHECK_FILE\n";
				send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
			}
			fwrite($pid_fd, getmypid());
			fclose($pid_fd);
			write_status_file_start();
		}
	}
	else 
	{
		$msg = "\nINFO::pid file Exist, No last instance running, mypid:".getmypid()."\n";
		echo $msg;
		write_info_file($msg);
		$pid_fd = fopen($LAST_INSTANCE_CHECK_FILE, 'w');
		if(!$pid_fd)
		{
			$msg = "\nERROR: Failed to open $LAST_INSTANCE_CHECK_FILE\n";
			send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
		}
		fwrite($pid_fd, getmypid());
		fclose($pid_fd);
		write_status_file_start();
	}
}
else
{
	$msg = "\nINFO::pid file does Not Exist, No last instance running, mypid:".getmypid()."\n";
	echo $msg;
	write_info_file($msg);
	$pid_fd = fopen($LAST_INSTANCE_CHECK_FILE, 'w');
	if(!$pid_fd)
	{
		$msg = "\nERROR: Failed to open $LAST_INSTANCE_CHECK_FILE\n";
		send_report($REPORT_FILE,$BLOOM_BASE_DIR,$msg);
	}
	fwrite($pid_fd, getmypid());
	fclose($pid_fd);
	write_status_file_start();
}

//connect to db
$source_con=mysql_connect($SOURCE_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con)
{
	$msg = "\nERROR::$config_param[0]: $SOURCE_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	// $msg = "\nERROR::$config_param[$j]: $SOURCE_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	echo $msg;
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
}
$msg = "\nConnected to database: $config_param[0]: $SOURCE_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD\n";
echo $msg;
write_info_file($msg);

$source_con_maindb=mysql_connect($SOURCE_HOST_MAINDB,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con_maindb)
{
        $msg = "\nERROR::$config_param[0]: $SOURCE_HOST_MAINDB:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
        // $msg = "\nERROR::$config_param[$j]: $SOURCE_HOST_MAINDB:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	echo $msg;
        cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
}
$msg = "\nConnected to MainDB: $config_param[0]: $SOURCE_HOST_MAINDB:$SOURCE_USERNAME:$SOURCE_PASSWORD\n";
echo $msg;
write_info_file($msg);

$has_db_connection = 1;
$found_updates = 0;

for($j=1;$j<count($config_param);$j++)
{
	$msg = "\n---".$config_param[$j]." start--".date("Y-m-d-H:i:s")."---\n";
	echo $msg;
	write_info_file($msg);
	$cmd=$FILTER_GENERATOR_BIN." ".$psff;
	$SELECT_QUERY=$config[$config_param[$j]]['select.all.site'];
	$SELECT_PUBLISER_SITE_DOMAIN_COUNT=$config[$config_param[$j]]['select.domain.count.publisher.site'];
	$SELECT_PUBLISER_SITE_BLOOM_DOMAIN_COUNT=$config[$config_param[$j]]['select.domain.count.bloom.site'];
	$SELECT_MODIFIED_PUBLISER_SITE=$config[$config_param[$j]]['select.modified.publisher.site'];
	$SELECT_REMOVED_QUERY=$config[$config_param[$j]]['select.complete.removed.pub.site'];
	$DELETE_QUERY=$config[$config_param[$j]]['delete.complete.removed.pub.site'];
	switch($config_param[$j]){
	case "PUBLISHER_SITE_FLOOR_FILTER_ADVERTISER":
		$active_entity=3;
		$psff = 6;
		$cmd=$FILTER_GENERATOR_BIN." ".$psff." ".$active_entity;
		break;
	case "PUBLISHER_SITE_FLOOR_FILTER_DOMAIN":
		$active_entity=4;
		$psff = 6;
		$cmd=$FILTER_GENERATOR_BIN." ".$psff." ".$active_entity;
		break;
	case "PUBLISHER_SITE_FLOOR_FILTER_CATEGORY":
		$active_entity=14;
		$psff = 6;
		$cmd=$FILTER_GENERATOR_BIN." ".$psff." ".$active_entity;
		break;
	case "PUBLISHER_SITE_DEAL_WHITELIST_FILTER":
		$psff = 7;
		$cmd=$FILTER_GENERATOR_BIN." ".$psff;
		break;
	}
	$raw_cmd = $cmd;

	if($has_db_connection !=1){
		$msg = "\nERROR::$config_param[$j]: No DB Connection\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
	}

	$result=mysql_select_db($SOURCE_ADF_DB,$source_con);
	if(!$result)
	{
		$msg = "\n2".date("Y-m-d-H:i:s")."\n\nresult_del:$result\n";
		echo $msg;
		write_info_file($msg);
		$source_con = db_reconnect($SOURCE_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD,$SOURCE_ADF_DB);
	}
	$msg = "\nSuccessfully selected DB: $SOURCE_ADF_DB\n";
	echo $msg;
	write_info_file($msg);

	$msg = 'INTERVAL_SECONDS:' . get_last_success_start_time($bloom_execution_time, $INTERVAL_SECONDS);
	echo $msg;
	write_info_file($msg);
	$SELECT_QUERY=str_replace("INTERVAL_SECONDS",
		format_timestamp(get_last_success_start_time($bloom_execution_time, $INTERVAL_SECONDS)),
		$SELECT_QUERY);

	$msg = "\n$config_param[$j]:: Executing Query: $SELECT_QUERY\n";
	echo $msg;
	write_info_file($msg);

	$result=mysql_query($SELECT_QUERY,$source_con);
	if(!$result)
	{
		$msg = "\nERROR::$config_param[$j]: Query Execution Failed: $SELECT_QUERY\n".mysql_error()."\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
	}
	$msg = "\n$config_param[$j]:: Select Query Fired @".date("Y-m-d-H:i:s")." : $SELECT_QUERY\n";
	echo $msg;
	write_info_file($msg);

	//sorted pub_id, site_id in ascending order, prev_pub_id check used to skip duplicates(in 0 & individual)
	while($row = mysql_fetch_array($result)){

		$pubsite_domain_count = $SELECT_PUBLISER_SITE_DOMAIN_COUNT;
		$iab_check_required = 0;
		$iab_status_changed = 0;
		$pub_iab_status = 0;

		if((strcmp($config_param[$j],"PUBLISHER_SITE_FLOOR_FILTER_CATEGORY") ==0) || 
			(strcmp($config_param[$j],"PUBLISHER_SITE_DEAL_WHITELIST_FILTER") ==0)){

				if(isset($row['feature_id']) && ($row['feature_id']==116)) {
					$msg = "\nPublisher is IAB enabled ".$row['pub_id']. "\n";
					echo $msg;
					//write_info_file($msg);
					$pub_iab_status = 1;
					$pubsite_domain_count = $config[$config_param[$j]]['select.domain.count.publisher.site.iab'];
				}
				$iab_check_required = 1;
			}


		$pubsite_domain_count=str_replace("PUBLISHER_ID",$row['pub_id'],$pubsite_domain_count);
		$pubsite_domain_count=str_replace("SITE_ID",$row['site_id'],$pubsite_domain_count);

		$pubsite_domain_count_bloom= $SELECT_PUBLISER_SITE_BLOOM_DOMAIN_COUNT;
		$pubsite_domain_count_bloom=str_replace("PUBLISHER_ID",$row['pub_id'],$pubsite_domain_count_bloom);
		$pubsite_domain_count_bloom=str_replace("SITE_ID",$row['site_id'],$pubsite_domain_count_bloom);

		$modified_pubsite=$SELECT_MODIFIED_PUBLISER_SITE;
		$modified_pubsite=str_replace("PUBLISHER_ID",$row['pub_id'],$modified_pubsite);
		$modified_pubsite=str_replace("SITE_ID",$row['site_id'],$modified_pubsite);
		$modified_pubsite=str_replace("INTERVAL_SECONDS",
			format_timestamp(get_last_success_start_time($bloom_execution_time, $INTERVAL_SECONDS)),
			$modified_pubsite);

		$result_domain_count=mysql_query($pubsite_domain_count,$source_con);
		$result_domain_count_bloom=mysql_query($pubsite_domain_count_bloom, $source_con);
		$result_modified_site= mysql_query($modified_pubsite, $source_con);

		$row_domain_count = mysql_fetch_array($result_domain_count);
		$row_domain_count_bloom = mysql_fetch_array($result_domain_count_bloom);
		$row_modified_site = mysql_fetch_array($result_modified_site);

		if($iab_check_required){
			$msg = "\nIAB status check required:".$iab_check_required." ... Pub:".$row['pub_id']." Site:".$row['site_id']."\n";
			echo $msg;
			//write_info_file($msg);
			if($pub_iab_status != $row_domain_count_bloom['iab_flag']){
				$iab_status_changed=1;
				$msg = "\nIAB status changed for Pub:".$row['pub_id']. " Site:".$row['site_id']."\n";
				echo $msg;
				write_info_file($msg);
			}
		}

		if($row_domain_count['domain_count'] != 0 && (!($row_domain_count_bloom) || $row_modified_site || $iab_status_changed || $row_domain_count['domain_count'] != $row_domain_count_bloom['domain_count'])){

			$flag = 0;
			$msg = "\n$config_param[$j]:: pub_id:".$row['pub_id']." site_id:".$row['site_id']."\n";
			echo $msg;
			write_info_file($msg);
			$cmd=$cmd." ".$row['pub_id']." ".$row['site_id'];
		}
		mysql_free_result($result_domain_count);
		mysql_free_result($result_domain_count_bloom);

	}
	mysql_free_result($result);

	//Delete pub-sites from bloom filters table which are absent in blocklist table
	remove_deleted_filter($config_param[$j],
		$source_con_maindb,
		$SOURCE_HOST_MAINDB,
		$SOURCE_USERNAME,
		$SOURCE_PASSWORD,
		$SOURCE_ADF_DB,
		$SELECT_REMOVED_QUERY,
		$DELETE_QUERY
	);
	if($cmd == $raw_cmd) {
		$msg = "\n*** NO MODIFICATIONS IN $config_param[$j] ***\n\n---".$config_param[$j]." end--".date("Y-m-d-H:i:s")."---\n";
		echo $msg;
		write_info_file($msg);
		continue;
	}

	$found_updates = 1;	
	$msg = "\n$config_param[$j]:: Generation Command:\n$cmd\n";
	echo $msg;
	write_info_file($msg);

	//Execute bin on main DB
	//$cmd = "$ssh_cmd $master_db_user@$master_db_host $cmd";
	//$cmd = "$ssh_cmd $master_db_user@$master_db_host date";

	//Execute Application
	exec($cmd,$output,$retval);
	if($retval!=0) 
	{
		$msg = "\nERROR::$config_param[$j]: Execution of $cmd Failed, retval:$retval\n";
		echo $msg;
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE,$msg);
	}

	$msg = "\n---".$config_param[$j]." end--".date("Y-m-d-H:i:s")."---\n";
	echo $msg;
	write_info_file($msg);
}

$msg = "\n** SCRIPT END **@".date("Y-m-d-H:i:s")."\n";
echo $msg;
write_info_file($msg);

email_info_file();
write_status_file(1);
if($source_con)
{
	mysql_close($source_con);
}
if($source_con_maindb)
{
	mysql_close($source_con_maindb);
}

if(file_exists($LAST_INSTANCE_CHECK_FILE))
{
	unlink($LAST_INSTANCE_CHECK_FILE);
}
?>
