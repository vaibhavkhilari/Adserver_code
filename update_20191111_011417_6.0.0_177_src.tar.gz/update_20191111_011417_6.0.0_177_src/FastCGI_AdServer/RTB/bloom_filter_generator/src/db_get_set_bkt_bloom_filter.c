/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_rt_campaign_config.h"
#include "db_bloom_filter_generator.h"
#include "error.h"
#include "bloom_filter.h"
#include "bkt_bloom_filter.h"

/* Compare function for qsort */
static int compare_string(const void *left,const void *right) {
	return(strcmp((char*)left,(char*)right));
}

/* Build bkt_bloom filter by reading the elements from DB */
int get_bkt_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		get_query_meta_t* query_meta,
		BKT_BLOOM** bkt_bloom_filter_list,
		size_t *ret_size,
		int *element_count) {

	char *retvalue=NULL;
	int max_element_size = query_meta->max_elt_size;
	int ret_val = ADS_ERROR_SUCCESS;
	int use_count = 0, is_domain = 0;
	int index = 0;
	SQLLEN alloc_count = 0;
	int i = 0;

	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLINTEGER s_id=0;
	SQLLEN cb_s_id=0;
	SQLCHAR s_element[max_element_size + 1];
	SQLLEN cb_s_element_len = SQL_NTS;
	SQLUBIGINT s_unsigned_big_id = 0;
	SQLLEN cb_s_unsigned_big_id = 0;

	(*ret_size) = 0;
	bkt_bloom_filter_list[0] = NULL;

	INFO_LOG("GET_QUERY:%s", sql_statement);

	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	do {
		/* Create a prepared statement */
		sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
		if (SQL_SUCCESS != sql_retval) {
			ERROR_LOG("SQLPrepare failed.");
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
			ret_val = ADS_ERROR_INTERNAL;
			break;
		}

		/* Execute The SQL Statement */
		sql_retval = SQLExecute(statement_handle);

		if (SQL_SUCCESS == sql_retval) {
			/* Bind result column to given type in query meta */
			for (i=0; i<(int)query_meta->nSelect && i<MAX_BIND_COL; i++) {
				switch (query_meta->type[i]) {
					case SELECT_INT:
						SQLBindCol(statement_handle, i+1, SQL_C_ULONG, &s_id, 0, &cb_s_id);
						break;
					case SELECT_CHAR_DOMAIN:
						is_domain = 1;
					case SELECT_CHAR:
						SQLBindCol(statement_handle, i+1, SQL_C_CHAR, &s_element, (max_element_size+1), &cb_s_element_len);
						break;
					case SELECT_UNSIGNED_BIG:
						SQLBindCol(statement_handle, i+1, SQL_C_UBIGINT, &s_unsigned_big_id, 0, &cb_s_unsigned_big_id);
						break;
					default:
						ERROR_LOG("Invalid query meta type[%d].", (int)query_meta->type[i]);
						/* Free The SQL Statement Handle */
						if (0 != statement_handle) {
							SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
						}
						return ADS_ERROR_INVALID_ARGS;
				}
			}

			/* Get the count of total elements to be added in bloom */
			SQLRowCount(statement_handle, &alloc_count);
			if (alloc_count > MAX_TOTAL_BKT_BLOOM_ELEMENTS_LIMIT) {
				INFO_LOG("[WARNING]: DB entries[%d] exceeds bkt_bloom Limit[%d]",
					(int)alloc_count, MAX_TOTAL_BKT_BLOOM_ELEMENTS_LIMIT);
				alloc_count = MAX_TOTAL_BKT_BLOOM_ELEMENTS_LIMIT;
			}

			/* Allocate memory to hold the elements */
			size_t malloc_size = (max_element_size+1) * alloc_count;
			retvalue = (char *) malloc(malloc_size);
			if (NULL == retvalue) {
				ERROR_LOG("Malloc failed.");
				ret_val= ADS_ERROR_NOMEMORY;
				break;
			}

			while (SQL_NO_DATA != sql_retval) {
				sql_retval = SQLFetch(statement_handle);
				if (SQL_NO_DATA != sql_retval) {
					if ((SQL_NULL_DATA != cb_s_element_len) && (0 != cb_s_element_len)) {
						cb_s_element_len = (cb_s_element_len < max_element_size) ?
									cb_s_element_len : max_element_size;
						char *actual_str_ptr = (char*)s_element;
						char *domain_punycode = NULL;

						/* If element is domain, remove 'www.' from start and convert it to punycode */
						if (is_domain) {
							if (0 == (strncmp((char*)s_element, WWW_STR, WWW_STR_LEN))) {
								actual_str_ptr = (char*)s_element + WWW_STR_LEN;
							}
							/* As domains are case in-sensitive, make it lowercase while adding to bloom */
							strtolower(actual_str_ptr, strlen(actual_str_ptr));

							int rc = NO_ASC_CONVERSION;
							rc = convert_unicode_domain_to_punycode(actual_str_ptr, &domain_punycode);
							if ((ASC_CONVERT_SUCCESS == rc) && (NULL != domain_punycode)) {
								actual_str_ptr=domain_punycode;
							}
						}

						/* pointing index to next element in list */
						index = (max_element_size+1)*use_count;
						if (query_meta->nSelect > 1) {
							snprintf(&retvalue[index], max_element_size, "%d_%s", s_id, actual_str_ptr);
						} else if (SELECT_UNSIGNED_BIG == query_meta->type[0]) {
							snprintf(&retvalue[index], max_element_size, "%llu", (unsigned long long)s_unsigned_big_id);
						} else {
							snprintf(&retvalue[index], max_element_size, "%s", actual_str_ptr);
						}
						retvalue[index + max_element_size] = 0;

						/* Free memory allocated by punycode conversion */
						if (NULL != domain_punycode) {
							free(domain_punycode);
							domain_punycode=NULL;
						}

						use_count++;
					}
				}
			}
		} else {
			ERROR_LOG("SQLExecute failed.");
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval, __LINE__, __FILE__);
			ret_val = ADS_ERROR_INTERNAL;
			break;
		}

		*element_count = use_count;
		/*
		 * Perform quick sort on elements, as bkt_bloom creation needs elements in sorted order
		 * If there is only one bkt_bloom getting built, we don't need to sort elements
		 */
		if (MAX_ALLOWED_ELEMENT_PER_BKT_BLOOM < use_count) {
			qsort(retvalue, use_count, max_element_size+1, compare_string);
		}
		/* Build bkt_bloom */
		ret_val = build_bkt_bloom(retvalue,
				use_count,
				bkt_bloom_filter_list,
				ret_size,
				max_element_size);
	} while (0);

	if (NULL != retvalue) {
		free(retvalue);
		retvalue = NULL;
	}

	if (0 != statement_handle) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}

	return ret_val;
}

/* Stores generated bkt_bloom filter to DB */
int set_bkt_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		BKT_BLOOM** bkt_bloom_filter_list,
		size_t *ret_size,
		const int element_count) {
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR *s_bit_array=NULL;
	SQLLEN cb_s_bit_array = 0;

	int ret_val = ADS_ERROR_SUCCESS;
	int cur_bloom = 0;

	if ((NULL == bkt_bloom_filter_list) || (NULL == *bkt_bloom_filter_list)) {
		INFO_LOG("No i/p BKT_BLOOM.");
		return ret_val;
	}

	/*
	 * Serialize bkt_bloom filter into buffer.
	 * Max size of buffer can be 16MB, as we use medium_blob in MySQL for storing bkt_bloom
	 */
	while (MAX_ALLOWED_BKT_BLOOMS > cur_bloom
			&& bkt_bloom_filter_list[cur_bloom] != NULL
			&& bkt_bloom_filter_list[cur_bloom]->nelements>0) {
		cb_s_bit_array+= ret_size[cur_bloom];
		cur_bloom++;
	}

	s_bit_array=(SQLCHAR*)malloc(sizeof(char)*cb_s_bit_array);
	if (NULL == s_bit_array) {
		ERROR_LOG("Malloc failed.");
		return ADS_ERROR_NOMEMORY;
	}

	cur_bloom=0;
	size_t cur_pos=0;
	while (MAX_ALLOWED_BKT_BLOOMS > cur_bloom
			&& bkt_bloom_filter_list[cur_bloom]!= NULL
			&& bkt_bloom_filter_list[cur_bloom]->nelements>0) {
		memcpy(s_bit_array+cur_pos, bkt_bloom_filter_list[cur_bloom], ret_size[cur_bloom]);
		cur_pos+=ret_size[cur_bloom];
		cur_bloom++;
	}

	INFO_LOG("SET_QUERY:%s", sql_statement);

	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	do {
		sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
		if (SQL_SUCCESS != sql_retval) {
			ERROR_LOG("SQLPrepare failed.");
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
			ret_val= ADS_ERROR_INTERNAL;
			break;
		}

		sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_BINARY,
				SQL_LONGVARBINARY, cb_s_bit_array, 0, (unsigned char*)s_bit_array, 0, &cb_s_bit_array);
		if (SQL_SUCCESS != sql_retval) {
			ERROR_LOG("SQLBindParameter failed.");
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
			ret_val= ADS_ERROR_INTERNAL;
			break;
		}

		sql_retval = SQLExecute(statement_handle);
		if (SQL_SUCCESS == sql_retval) {
			INFO_LOG("bkt_bloom Inserted:: elt_count:%d bloom_count:%d stored_bit_array_size_bytes:%d",
				element_count, cur_bloom, (int)cb_s_bit_array);
		} else {
			ERROR_LOG("bkt_bloom Insert failed:: elt_count:%d bloom_count:%d stored_bit_array_size_bytes:%d",
				element_count, cur_bloom, (int)cb_s_bit_array);
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval, __LINE__, __FILE__);
			ret_val= ADS_ERROR_INTERNAL;
		}
	} while (0);

	if (0 != statement_handle) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}

	if (NULL != s_bit_array) {
		free(s_bit_array);
	}

	return ret_val;
}
