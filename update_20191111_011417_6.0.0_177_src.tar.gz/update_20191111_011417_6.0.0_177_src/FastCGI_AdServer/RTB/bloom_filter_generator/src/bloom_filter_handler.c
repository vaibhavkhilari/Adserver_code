/*
   PubMatic Inc. ("PubMatic") CONFIDENTIAL
   Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "bloom_filter_handler.h"
#include "db_publisher_site_whitelisting.h"

const char* filter[] = {
	"SET_CONFIG",													 //0
	"BLOOM_BLOCKLIST_LANDING_PAGE_FILTER", //1
	"BLOOM_CREATIVE_ID_FILTER",						 //2
	"BLOOM_ADVERTISER_DOMAIN_FILTER",			 //3
	"BLOOM_WHITELIST_LANDING_PAGE_FILTER", //4
	"BLOOM_DSP_BLOCKLIST_FILTER",
	"BLOOM_PUBLISHER_SITE_FLOOR_FILTER",
	"BLOOM_PUBLISHER_SITE_DEAL_WHITELIST_FILTER",
	"GSS_BLOCKLIST_FILTER",
	"BLOOM_UNIQ_CREATV",
	"BLOOM_DSP_WHITELIST_FILTER",
	"BLOOM_DSP_APPURL_BLOCKLIST_FILTER",
	"BLOOM_DSP_APPURL_WHITELIST_FILTER",
	"BLOOM_URL_BLACK_WHITE_FILTER",
	"BLOOM_DAA_DEVICEID_OPTOUT_FILTER", //14
	"BLOOM_GLOBAL_CREATIVE_ID_FILTER", //15
	"BLOOM_PUBLISHER_CAMPAIGN_DOMAIN_FILTER", //16
	"BLOOM_ADS_TXT_DOMAIN_LIST_FILTER", //17
	"BLOOM_PUB_GEO_DOMAIN_BLOCKLIST_FILTER", //18
	"BLOOM_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER", //19
	"BLOOM_BLOCKLIST_LANDING_PAGE_FILTER_NEW", //20
	"BLOOM_APP_ADS_TXT_FILTER", //21
	"PUBLISHER_SITE_DOMAIN_APP_WHITELIST", //22
	"BLOOM_CLASSIFIED_CREATIVES_SMALL", //23
	"BLOOM_CLASSIFIED_CREATIVES_GIANT" //24
};

db_env_t g_dbenv;
char *g_odbc_kad_dsn_name;
char *g_odbc_adf_dsn_name;
char *g_odbc_bc_dsn_name;
char *g_odbc_ceaser_dsn_name;
char *g_odbc_local_adf_dsn_name;
char *g_odbc_rawdata_dsn_name;
char *g_odbc_master_dsn_name;
char *g_odbc_daa_optout_dsn_name;
char *g_odbc_ads_txt_dsn_name;
char *g_odbc_crtv_ingestor_dsn_name;
char *g_odbc_dsn_user_name;
char *g_odbc_dsn_user_password;
char *g_conf_bloom_dir;
int g_cur_arg_index; //Should be assigned some value before using it.
unsigned int g_max_bloom_thread_count;
pthread_mutex_t bloom_db_conn_mutex;

int get_pub_site_bloom_list(db_connection_t *dbconn,
				long pub_id,
				long site_id,
				int bloom_type,
				BLOOM** publisher_site_bloom_list,
				size_t *ret_size,
				int *url_count);
int set_pub_site_bloom_list(db_connection_t *dbconn,
				long pub_id,
				long site_id,
				BLOOM** publisher_site_bloom_list,
				size_t *ret_size,
				int url_count,
				int bloom_type);

int check_publisher_iab_status(db_connection_t *dbconn,long pub_id,int* iab_enabled)
{
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLINTEGER s_pub_id=0;
	SQLLEN cb_s_pub_id=0;
	SQLINTEGER s_pub_iab_flag=0;
	SQLLEN cb_s_pub_iab_flag=SQL_NTS;

	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	strncpy((char *) sql_statement, IS_PUBLISHER_IAB_ENABLED, MAX_SQL_QUERY_STR_LEN );
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		fprintf(stderr, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );

		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}

	/* Bind parameters */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);

	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );

		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}

	s_pub_id = pub_id;

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);

	if (sql_retval == SQL_SUCCESS) {

		SQLBindCol(statement_handle, 1, SQL_C_ULONG, &s_pub_iab_flag, 0, &cb_s_pub_iab_flag);

		while (sql_retval != SQL_NO_DATA) {
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {
				if(cb_s_pub_iab_flag != SQL_NULL_DATA && cb_s_pub_iab_flag != 0) {
					*iab_enabled=(s_pub_iab_flag)?1:0;
				}
			}
		}
	}
	else{
		fprintf(stderr, "Error executing select statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );

		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}

	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}

	return ADS_ERROR_SUCCESS;
}

int set_bloom_configuration() {
	/* local variables */
	int retval = 0;
	property_list_t *config_properties = NULL;
	char *temp_buffer = NULL;

	/* Read the configuration from the configuration file */
	retval = get_config_properties(BLOOM_CONFIG_FILE_NAME, &config_properties);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "Could not get the configuration properties\n");
		return retval;
	}

	/* Get the kad dsn name */
	retval = get_property_value(config_properties, KAD_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", KAD_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_kad_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* Get the adf dsn name */
	retval = get_property_value(config_properties, ADF_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", ADF_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_adf_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* Get the adf dsn name */
	retval = get_property_value(config_properties, BC_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", BC_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_bc_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* Get the adf dsn name */
	retval = get_property_value(config_properties, LOCAL_ADF_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", LOCAL_ADF_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_local_adf_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* Get the rawdata dsn name */
	retval = get_property_value(config_properties, RAWDATA_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", RAWDATA_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_rawdata_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* Get the master dsn name */
	retval = get_property_value(config_properties, MASTER_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", MASTER_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_master_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* Get the DAA Optout dsn name */
	retval = get_property_value(config_properties, DAA_OPTOUT_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", DAA_OPTOUT_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_daa_optout_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* Get ADS.TXT crawler db dsn name */
	retval = get_property_value(config_properties, ADS_TXT_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", ADS_TXT_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_ads_txt_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* Get the Creative Ingestor dsn name */
	retval = get_property_value(config_properties, CRTV_INGESTOR_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", CRTV_INGESTOR_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_crtv_ingestor_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* Get the ceaser dsn name */
	retval = get_property_value(config_properties, CEASER_DSN_NAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "%s DSN name not specified in configuration properties\n", CEASER_DSN_NAME);
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_ceaser_dsn_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* get dsn user name */
	retval = get_property_value(config_properties, DSN_USERNAME, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "DSN user name not specified in configuration properties\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_dsn_user_name = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* get dsn password */
	retval = get_property_value(config_properties, DSN_PASSWORD, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "DSN user password not specified in configuration properties\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_odbc_dsn_user_password = strndup(temp_buffer+1,strlen(temp_buffer)-2);

	/* get max thread count */
	retval = get_property_value(config_properties, MAX_BLOOM_THREAD_COUNT, &temp_buffer);
	if (retval != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "Bloom max thread count not specified in configuration properties\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_max_bloom_thread_count = atoi(temp_buffer);

	return ADS_ERROR_SUCCESS;
}

void free_bloom_configuration() {
	if(g_odbc_kad_dsn_name) {
		free(g_odbc_kad_dsn_name);
		g_odbc_kad_dsn_name = NULL;
	}
	if(g_odbc_adf_dsn_name) {
		free(g_odbc_adf_dsn_name);
		g_odbc_adf_dsn_name = NULL;
	}
	if(g_odbc_ceaser_dsn_name) {
		free(g_odbc_ceaser_dsn_name);
		g_odbc_ceaser_dsn_name = NULL;
	}
	if(g_odbc_bc_dsn_name) {
		free(g_odbc_bc_dsn_name);
		g_odbc_bc_dsn_name = NULL;
	}
	if(g_odbc_local_adf_dsn_name) {
		free(g_odbc_local_adf_dsn_name);
		g_odbc_local_adf_dsn_name = NULL;
	}
	if(g_odbc_rawdata_dsn_name) {
		free(g_odbc_rawdata_dsn_name);
		g_odbc_rawdata_dsn_name = NULL;
	}
	if(g_odbc_master_dsn_name) {
		free(g_odbc_master_dsn_name);
		g_odbc_master_dsn_name = NULL;
	}
	if(g_odbc_daa_optout_dsn_name) {
		free(g_odbc_daa_optout_dsn_name);
		g_odbc_daa_optout_dsn_name = NULL;
	}
	if(g_odbc_ads_txt_dsn_name) {
		free(g_odbc_ads_txt_dsn_name);
		g_odbc_ads_txt_dsn_name = NULL;
	}
	if(g_odbc_crtv_ingestor_dsn_name) {
		free(g_odbc_crtv_ingestor_dsn_name);
		g_odbc_crtv_ingestor_dsn_name = NULL;
	}
	if(g_odbc_dsn_user_name) {
		free(g_odbc_dsn_user_name);
		g_odbc_dsn_user_name = NULL;
	}
	if(g_odbc_dsn_user_password) {
		free(g_odbc_dsn_user_password);
		g_odbc_dsn_user_password = NULL;
	}
}

void get_log_file_name(char *log_file) {
	struct stat st;
	time_t now;
	struct tm *tm_now;
	struct timeval tv;
	char* strptr = NULL;
	int year = 0, month = 0, day = 0, nob = 0;
	int START_YEAR = 1900, START_MONTH = 1;

	now = time ( NULL );
	tm_now = localtime ( &now );
	year = tm_now->tm_year+START_YEAR;
	month = tm_now->tm_mon+START_MONTH;
	day = tm_now->tm_mday;
	strptr = log_file;

	nob = sprintf(strptr, "%s", g_conf_bloom_dir);
	strptr += nob;

	//check for valid path
	if (*(strptr-1) != '/')
		nob = sprintf (strptr, "/logs/");
	else
		nob = sprintf (strptr, "logs/");
	strptr += nob;

	//create logs dir if not exists
	if (stat(log_file, &st) != 0) {
		fprintf(stderr, "Log Directory Doesn't Exist, Creating '%s'\n", log_file);
		mkdir(log_file, (S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH));
	}

	nob = sprintf (strptr, "%d-", year);
	strptr += nob;

	if (tm_now->tm_mon+START_MONTH < 10)
		nob = sprintf (strptr, "0%d-", month);
	else
		nob = sprintf (strptr, "%d-", month);
	strptr += nob;

	if (tm_now->tm_mday < 10)
		nob = sprintf (strptr, "0%d", day);
	else
		nob = sprintf (strptr, "%d", day);
	strptr += nob;

	gettimeofday(&tv,NULL);
	sprintf (strptr, "-%ld.log",tv.tv_sec);
}

void init_query_metadata(get_query_meta_t *query_meta, const int oper_id) {
	//default select settings
	query_meta->nSelect = 1;
	query_meta->type[0] = SELECT_CHAR_DOMAIN;
	query_meta->max_elt_size = BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH;

	//operation specific overwiting
	switch(oper_id) {
		case BLOOM_PUBLISHER_SITE_DEAL_WHITELIST_FILTER:
				query_meta->nSelect = 2;
				query_meta->type[0] = SELECT_INT;
				query_meta->type[1] = SELECT_CHAR_DOMAIN;
				//additional space for concatination of deal_id & domain
				query_meta->max_elt_size = (2 *	BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH);
				break;
		case BLOOM_PUBLISHER_SITE_FLOOR_FILTER:
				query_meta->nSelect = 2;
				query_meta->type[0] = SELECT_INT;
				query_meta->type[1] = SELECT_CHAR_DOMAIN;
				//additional space for concatination of rule_meta_id & domain
				query_meta->max_elt_size = (BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH + 20);
				break;
		case GSS_BLOCKLIST_FILTER:
				query_meta->max_elt_size = MAX_BLACKWHITE_LIST_APPURL_LENGTH;
				break;
		/* All read UCrID to generate a bloom */
		case BLOOM_CLASSIFIED_CREATIVES_SMALL:
		case BLOOM_CLASSIFIED_CREATIVES_GIANT:
		case BLOOM_UNIQ_CREATV:
		case BLOOM_GLOBAL_CREATIVE_ID_FILTER:
				query_meta->type[0] = SELECT_CHAR;
				query_meta->max_elt_size = MAX_UCRID_STR_LENGTH;
				break;
		case BLOOM_CREATIVE_ID_FILTER:
		case BLOOM_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER:
				query_meta->type[0] = SELECT_CHAR;
				query_meta->max_elt_size = MAX_DSP_CREATIVE_LEN;
				break;
		case BLOOM_DAA_DEVICEID_OPTOUT_FILTER:
				query_meta->type[0] = SELECT_CHAR;
				query_meta->max_elt_size = MAX_DAA_OPTOUT_DEVICEID_LEN;
				break;
		case BLOOM_DSP_APPURL_BLOCKLIST_FILTER:
		case BLOOM_DSP_APPURL_WHITELIST_FILTER:
				query_meta->max_elt_size = MAX_BLACKWHITE_LIST_APPURL_LENGTH;
				break;
		case BLOOM_PUBLISHER_CAMPAIGN_DOMAIN_FILTER:
		//TODO :: confirm if type expected is SELECT_CHAR or SELECT_CHAR_DOMAIN
				query_meta->max_elt_size = MAX_BLACKWHITE_LIST_APPURL_LENGTH + LONG_INT_DATA_LEN; // to support 'site_domain' in the a string
				break;
		case BLOOM_ADS_TXT_DOMAIN_LIST_FILTER:
				query_meta->max_elt_size = MAX_BLACKWHITE_LIST_APPURL_LENGTH;
				break;
		case BLOOM_APP_ADS_TXT_FILTER:
				query_meta->type[0] = SELECT_CHAR;
				query_meta->max_elt_size = MAX_BLACKWHITE_LIST_APPURL_LENGTH;
				break;
		case BLOOM_PUB_GEO_DOMAIN_BLOCKLIST_FILTER:
				query_meta->nSelect = 2;
				query_meta->type[0] = SELECT_INT;
				query_meta->type[1] = SELECT_CHAR_DOMAIN;
				query_meta->max_elt_size = MAX_BLACKWHITE_LIST_APPURL_LENGTH + MAX_GEO_COUNTRY_CODE_LEN;
				break;
	}
}

int get_thread_configuration(const int oper_id,
			int argc,
			unsigned long *batch_size,
			int *thread_count) {
	//default thread configurations;
	int count = g_max_bloom_thread_count; //Max thread count
	int possible_threads;
	int no_args_required = 0;
	int size = 2; // batch size in input.. e.g for LANDING_PAGE it's 2, (pub_id:site_id array)
	g_cur_arg_index = 2; // Start index of input in argv string

	//operation specific thread count calculation
	switch(oper_id) {
		case GSS_BLOCKLIST_FILTER:
		case BLOOM_GLOBAL_CREATIVE_ID_FILTER:
		case BLOOM_UNIQ_CREATV:
		case BLOOM_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER:
		case BLOOM_CLASSIFIED_CREATIVES_SMALL:
		case BLOOM_CLASSIFIED_CREATIVES_GIANT:
			count = 1;
			no_args_required = 1;
			break;
		case BLOOM_URL_BLACK_WHITE_FILTER:
		case BLOOM_CREATIVE_ID_FILTER:
			size = 3;
			break;
		case BLOOM_DAA_DEVICEID_OPTOUT_FILTER:
		case BLOOM_PUB_GEO_DOMAIN_BLOCKLIST_FILTER:
			size = 1;
			break;
		case BLOOM_PUBLISHER_SITE_FLOOR_FILTER:
			g_cur_arg_index= 3;
			break;
		case BLOOM_PUBLISHER_CAMPAIGN_DOMAIN_FILTER:
			size = 3;
			break;
	}

	if(no_args_required){ // No args required for few operids e.g GSS_BLOCKLIST_FILTER, BLOOM_UNIQ_CREATV
		(*thread_count) = count;
	}
	else{
		possible_threads = (argc - g_cur_arg_index) / size;
		if(possible_threads < 1){
			fprintf(stderr, "ERROR: Didn't get enough args to process %s:%d\n",__FILE__,__LINE__);
			return ADS_ERROR_INTERNAL;
		}
		if((argc - g_cur_arg_index) % size){
			fprintf(stderr, "ERROR: Args provided can not be equally distributed among all threads %s:%d\n",__FILE__,__LINE__);
			return ADS_ERROR_INTERNAL;
		}
		(*thread_count) = count > possible_threads ? possible_threads : count;
	}
	(*batch_size) = size;
	return ADS_ERROR_SUCCESS;
}

void* generate_blocklist_landing_page_filter_new(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t kad_dbconn;
	db_connection_t ceaser_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv, g_odbc_kad_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%s\n",
				thread_params->thread_id, g_odbc_kad_dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&ceaser_dbconn, &g_dbenv, g_odbc_ceaser_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_ceaser_dsn_name, __FILE__,__LINE__);
		release_db_connection(&kad_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {
		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld site:%ld [Thread id:%lu]***\n",
				filter[oper_id], atol(argv[i]), atol(argv[i+1]), thread_params->thread_id);

		//if pub id = 0(global list for all publishers)
		if(atol(argv[i]) == 0)
			snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_GLOBAL_PUBLISHER_SITE_BLOCKLIST);
		else
			snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_PUBLISHER_SITE_BLOCKLIST_NEW,
					atol(argv[i]), atol(argv[i+1]));

		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters((atol(argv[i]) == 0) ? &kad_dbconn : &ceaser_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		//if pub id = 0(global list for all publishers)
		if(atol(argv[i]) == 0)
			snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_PUBLISHER_SITE_BLOCKLIST,
					(long int)0, (long int)0, element_count);
		else
			snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_PUBLISHER_SITE_BLOCKLIST,
					atol(argv[i]), atol(argv[i+1]), element_count);

		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&kad_dbconn,
				sql_statement,
				bloom_list,
				atol(argv[i]),
				atol(argv[i+1]),
				oper_id,
				ret_list_size,
				element_count);

		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&kad_dbconn);
	release_db_connection(&ceaser_dbconn);
	return NULL;
}

void* generate_blocklist_landing_page_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t kad_dbconn;
	db_connection_t bc_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv, g_odbc_kad_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%s\n",
				thread_params->thread_id, g_odbc_kad_dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&bc_dbconn, &g_dbenv, g_odbc_bc_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_bc_dsn_name, __FILE__,__LINE__);
		release_db_connection(&kad_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {
		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld site:%ld [Thread id:%lu]***\n",
				filter[oper_id], atol(argv[i]), atol(argv[i+1]), thread_params->thread_id);

		//if pub id = 0(global list for all publishers)
		if(atol(argv[i]) == 0)
			snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_GLOBAL_PUBLISHER_SITE_BLOCKLIST);
		else
			snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_PUBLISHER_SITE_BLOCKLIST,
					atol(argv[i]), atol(argv[i+1]));

		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters((atol(argv[i]) == 0) ? &kad_dbconn : &bc_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		//if pub id = 0(global list for all publishers)
		if(atol(argv[i]) == 0)
			snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_PUBLISHER_SITE_BLOCKLIST,
					(long int)0, (long int)0, element_count);
		else
			snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_PUBLISHER_SITE_BLOCKLIST,
					atol(argv[i]), atol(argv[i+1]), element_count);

		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&kad_dbconn,
				sql_statement,
				bloom_list,
				atol(argv[i]),
				atol(argv[i+1]),
				oper_id,
				ret_list_size,
				element_count);

		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&kad_dbconn);
	release_db_connection(&bc_dbconn);
	return NULL;
}

void* generate_creative_id_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t adf_dbconn;
	db_connection_t bc_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i;
	long int site_id=0, pub_id=0, bloom_filter_type=0;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_adf_dsn_name, __FILE__,__LINE__);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&bc_dbconn, &g_dbenv, g_odbc_bc_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_bc_dsn_name, __FILE__,__LINE__);
		release_db_connection(&adf_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {
		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		// init variables
		/// reset query meta to char
		query_meta->type[0] = SELECT_CHAR;
		pub_id = atol(argv[i]);
		site_id = atol(argv[i+1]);
		bloom_filter_type = atoi(argv[i+2]);
		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld site:%ld pref:%ld [Thread id:%lu]***\n",
				filter[oper_id], pub_id, site_id, bloom_filter_type, thread_params->thread_id);

		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, bloom_filter_type ? GET_CRC64_CREATIVE_WHITE_LIST : GET_CRC64_CREATIVE_BLOCK_LIST, pub_id, site_id);

		thread_params->ret_val = get_bloom_filters(&bc_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, pub_id, site_id, oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}


		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, bloom_filter_type ? SET_CRC64_CREATIVE_WHITE_LIST : SET_CRC64_CREATIVE_BLOCK_LIST, pub_id,site_id, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				pub_id,
				site_id,
				oper_id,
				ret_list_size,
				element_count);

		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, pub_id, site_id, oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
	}
	release_db_connection(&adf_dbconn);
	release_db_connection(&bc_dbconn);
	return NULL;
}

void* generate_publisher_site_floor_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t kad_dbconn;
	db_connection_t local_adf_dbconn;
	db_connection_t adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	int is_iab_enabled = 0;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv, g_odbc_kad_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%s\n",
				thread_params->thread_id, g_odbc_kad_dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_adf_dsn_name, __FILE__,__LINE__);
		release_db_connection(&kad_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&local_adf_dbconn, &g_dbenv, g_odbc_local_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_local_adf_dsn_name, __FILE__,__LINE__);
		release_db_connection(&kad_dbconn);
		release_db_connection(&adf_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {
		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld site:%ld active_entity:%ld [Thread id=%lu]***\n",
				filter[oper_id], atol(argv[i]), atol(argv[i+1]), atol(argv[2]), thread_params->thread_id);

		thread_params->ret_val=check_publisher_iab_status(&kad_dbconn,atol(argv[i]),&is_iab_enabled);
		fprintf(stderr, "\n[Thread id=%lu]INFO: check_publisher_iab_status [%d] for pub:%ld,retval:%d\n",
				thread_params->thread_id, is_iab_enabled,atol(argv[i]),thread_params->ret_val);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: check_publisher_iab_status failed for pub:%ld,retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), thread_params->ret_val, __FILE__,__LINE__);
			break;
		}

		const char* ptr_query = NULL;
		//switch active entity
		switch(atol(argv[2]))
		{
			case ADVERTISER_ID :
				ptr_query = GET_DB_PUBLISHER_SITE_FOR_ADVERTISER_FLOOR_FILTER;
				break;
			case DOMAIN_ID :
				ptr_query = GET_DB_PUBLISHER_SITE_FOR_DOMAIN_FLOOR_FILTER;
				break;
			case ADVERTISER_CATEGORIES :
				if(is_iab_enabled){
					ptr_query = GET_DB_PUBLISHER_SITE_FOR_CATEGORY_FLOOR_FILTER_IAB_ENABLED;
				}
				else{
					ptr_query = GET_DB_PUBLISHER_SITE_FOR_CATEGORY_FLOOR_FILTER_IAB_DISABLED;
				}
				break;
			default:
				fprintf(stderr, "\n[Thread id=%lu]:ERROR: Invalid active entity:%ld\n",thread_params->thread_id, atol(argv[2]));
				release_db_connection(&kad_dbconn);
				release_db_connection(&adf_dbconn);
				release_db_connection(&local_adf_dbconn);
				return NULL;
		}

		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN,
				ptr_query, atol(argv[i]), atol(argv[i+1]));
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters(&local_adf_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for pub:%ld, site:%ld, active_entity:%ld op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), atol(argv[2]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_PUBLISHER_SITE_FLOOR_FILTER,
				atol(argv[i]), atol(argv[i+1]), atol(argv[2]), element_count, is_iab_enabled);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				atol(argv[i]),
				atol(argv[i+1]),
				oper_id,
				ret_list_size,
				element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}
	release_db_connection(&kad_dbconn);
	release_db_connection(&adf_dbconn);
	release_db_connection(&local_adf_dbconn);
	return NULL;
}

void* generate_whitelist_landing_page_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t kad_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv, g_odbc_kad_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%s\n",
				thread_params->thread_id, g_odbc_kad_dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {
		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld site:%ld [Thread id=%lu]***\n",
				filter[oper_id], atol(argv[i]), atol(argv[i+1]), thread_params->thread_id);
		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_PUBLISHER_SITE_WHITELIST,
				atol(argv[i]), atol(argv[i+1]));
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters(&kad_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_PUBLISHER_SITE_WHITELIST,
				atol(argv[i]), atol(argv[i+1]), element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&kad_dbconn,
				sql_statement,
				bloom_list,
				atol(argv[i]),
				atol(argv[i+1]),
				oper_id,
				ret_list_size,
				element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}
	release_db_connection(&kad_dbconn);
	return NULL;
}

void* generate_daa_deviceid_optout_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t kad_dbconn;
	db_connection_t daa_optout_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv, g_odbc_kad_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%s\n",
				thread_params->thread_id, g_odbc_kad_dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&daa_optout_dbconn, &g_dbenv, g_odbc_daa_optout_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DAA Optout DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_daa_optout_dsn_name, __FILE__,__LINE__);
		release_db_connection(&kad_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {
		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: hashing_used:%ld [Thread id=%lu]***\n",
				filter[oper_id], atol(argv[i]), thread_params->thread_id);
		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DAA_DEVICE_OPTOUT_LIST,
				atol(argv[i]));
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters(&daa_optout_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for hashing_used:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DAA_DEVICE_OPTOUT_LIST,
				atol(argv[i]), element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&kad_dbconn,
				sql_statement,
				bloom_list,
				0,
				0,
				oper_id,
				ret_list_size,
				element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for hashing_used:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}
	release_db_connection(&kad_dbconn);
	release_db_connection(&daa_optout_dbconn);
	return NULL;
}

void* generate_dsp_blocklist_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_adf_dsn_name, __FILE__,__LINE__);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {
		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: dp:%ld cam:%ld [Thread id=%lu]***\n",
				filter[oper_id], atol(argv[i]), atol(argv[i+1]), thread_params->thread_id);
		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_DSP_CAMPAIGN_BLOCKLIST,
				atol(argv[i]), atol(argv[i+1]));
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters(&adf_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for dp:%ld, cam:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_DSP_CAMPAIGN_BLOCKLIST,
				atol(argv[i]), atol(argv[i+1]), element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				atol(argv[i]),
				atol(argv[i+1]),
				oper_id,
				ret_list_size,
				element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for db:%ld, cam:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&adf_dbconn);
	return NULL;
}

void* generate_publisher_site_deal_whitelist_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t kad_dbconn;
	db_connection_t adf_dbconn;
	db_connection_t local_adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	int is_iab_enabled = 0;

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv, g_odbc_kad_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%s\n",
				thread_params->thread_id, g_odbc_kad_dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_adf_dsn_name, __FILE__,__LINE__);
		release_db_connection(&kad_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&local_adf_dbconn, &g_dbenv, g_odbc_local_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_local_adf_dsn_name, __FILE__,__LINE__);
		release_db_connection(&kad_dbconn);
		release_db_connection(&adf_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {

		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld site:%ld [Thread id=%lu]***\n",
				filter[oper_id], atol(argv[i]), atol(argv[i+1]), thread_params->thread_id);

		thread_params->ret_val=check_publisher_iab_status(&kad_dbconn,atol(argv[i]),&is_iab_enabled);
		fprintf(stderr, "\n[Thread id=%lu]:INFO: check_publisher_iab_status [%d] for pub:%ld,retval:%d\n",
				thread_params->thread_id, is_iab_enabled, atol(argv[i]), thread_params->ret_val);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: check_publisher_iab_status failed for pub:%ld,retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), thread_params->ret_val, __FILE__,__LINE__);
			break;
		}

		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN,
				(is_iab_enabled) ? GET_DB_PUBLISHER_SITE_DEAL_WHITELIST_FILTER_IAB_ENABLED : GET_DB_PUBLISHER_SITE_DEAL_WHITELIST_FILTER_IAB_DISABLED,
				atol(argv[i]), atol(argv[i+1]),
				atol(argv[i]), atol(argv[i+1]),
				atol(argv[i]), atol(argv[i+1]));
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters(&local_adf_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_PUBLISHER_SITE_DEAL_WHITELIST_FILTER,
				atol(argv[i]), atol(argv[i+1]), element_count, is_iab_enabled);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				atol(argv[i]),
				atol(argv[i+1]),
				oper_id,
				ret_list_size,
				element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&kad_dbconn);
	release_db_connection(&adf_dbconn);
	release_db_connection(&local_adf_dbconn);
	return NULL;
}

void* generate_gss_domain_app_blocklist_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id){
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS] = {0};
	db_connection_t kad_dbconn;
	db_connection_t adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BKT_BLOOMS] = {0};
	int element_count=0, j;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);

	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv, g_odbc_kad_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
				thread_params->thread_id, g_odbc_adf_dsn_name);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
			g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
				thread_params->thread_id, g_odbc_adf_dsn_name);
		release_db_connection(&kad_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);

	INFO_LOG("GSS_BLOCKLIST_FILTER [Thread id=%lu]", thread_params->thread_id);

	do {
		/* Creation of GSS Domain Blocklist bkt_bloom filter */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_GSS_DOMAIN_BLOCKLIST);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bkt_bloom_filters(&kad_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:get_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}

		/* INSERT QUERY : Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_GSS_DOMAIN_BLOCKLIST, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bkt_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				ret_list_size,
				element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:set_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;

		}
		/* bloom cleanup */
		for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && bloom_list[j]!= NULL; j++) {
			bkt_bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}

		/* Creation of GSS App Blocklist bkt_bloom filter */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_GSS_APP_BLOCKLIST);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';
		element_count = 0;
		query_meta->type[0] = SELECT_CHAR;

		thread_params->ret_val = get_bkt_bloom_filters(&kad_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:get_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}

		/* INSERT QUERY : Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_GSS_APP_BLOCKLIST, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bkt_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				ret_list_size,
				element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:set_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;

		}
		/* bloom cleanup */
		for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && bloom_list[j]!= NULL; j++) {
			bkt_bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}

	} while (0);

	release_db_connection(&kad_dbconn);
	release_db_connection(&adf_dbconn);
	return NULL;
}

void* generate_unique_creative_filter(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id){
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS] = {0};
	db_connection_t ci_dbconn;
	db_connection_t adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BKT_BLOOMS] = {0};
	int element_count=0, j;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&ci_dbconn, &g_dbenv, g_odbc_crtv_ingestor_dsn_name,
			g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
				thread_params->thread_id, g_odbc_crtv_ingestor_dsn_name);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
			g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
				thread_params->thread_id, g_odbc_adf_dsn_name);
		release_db_connection(&ci_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);

	INFO_LOG("BLOOM_UNIQ_CREATV [Thread id=%lu]", thread_params->thread_id);

	do {
		/* Creation of Unique creativeId bkt_bloom filter */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_UNIQUE_CREATIVE_ID);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bkt_bloom_filters(&ci_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:get_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}

		/* INSERT QUERY : Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_UNIQUE_CREATIVE_ID_BLOOM, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bkt_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				ret_list_size,
				element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:set_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;

		}
		/* bloom cleanup */
		for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && bloom_list[j]!= NULL; j++) {
			bkt_bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	} while (0);

	release_db_connection(&ci_dbconn);
	release_db_connection(&adf_dbconn);
	return NULL;
}

void* generate_classfied_creative_bloom(bloom_thread_param_t *thread_params,
		get_query_meta_t *query_meta,
		int oper_id){
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS] = {0};
	db_connection_t bc_dbconn;
	db_connection_t adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BKT_BLOOMS] = {0};
	int element_count=0, j;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);

	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
			g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
				thread_params->thread_id, g_odbc_adf_dsn_name);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&bc_dbconn, &g_dbenv, g_odbc_bc_dsn_name,
			g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
				thread_params->thread_id, g_odbc_bc_dsn_name);
		release_db_connection(&adf_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);

	INFO_LOG("BLOOM_CLASSIFIED_CREATIVE [Thread id=%lu]", thread_params->thread_id);

	do {
		/* Creation of Classified Creative bkt_bloom filter */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, (BLOOM_CLASSIFIED_CREATIVES_GIANT == oper_id) ? \
				GET_CLASSIFIED_CREATIVES_GIANT : GET_CLASSIFIED_CREATIVES_SMALL);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bkt_bloom_filters(&bc_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:get_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}

		/* INSERT QUERY : Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, (BLOOM_CLASSIFIED_CREATIVES_GIANT == oper_id) ? \
				SET_CLASSIFIED_CREATIVES_GIANT_BLOOM : SET_CLASSIFIED_CREATIVES_SMALL_BLOOM,
				element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bkt_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				ret_list_size,
				element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:set_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;

		}
		/* bloom cleanup */
		for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && bloom_list[j]!= NULL; j++) {
			bkt_bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	} while (0);

	release_db_connection(&bc_dbconn);
	release_db_connection(&adf_dbconn);
	return NULL;
}


void* generate_dsp_whitelist_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_adf_dsn_name, __FILE__,__LINE__);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {

		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: dp:%ld cam:%ld [Thread id=%lu]***\n",
				filter[oper_id], atol(argv[i]), atol(argv[i+1]), thread_params->thread_id);
		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_DSP_CAMPAIGN_WHITELIST,
				atol(argv[i]), atol(argv[i+1]));
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters(&adf_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for dp:%ld, cam:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_DSP_CAMPAIGN_WHITELIST,
				atol(argv[i]), atol(argv[i+1]), element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				atol(argv[i]),
				atol(argv[i+1]),
				oper_id,
				ret_list_size,
				element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for db:%ld, cam:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&adf_dbconn);
	return NULL;
}

void* generate_dsp_appurl_blocklist_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_adf_dsn_name, __FILE__,__LINE__);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {

		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: dp:%ld cam:%ld [Thread id=%lu]***\n",
				filter[oper_id], atol(argv[i]), atol(argv[i+1]), thread_params->thread_id);
		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_DSP_CAMPAIGN_APPURL_BLOCKLIST,
				atol(argv[i]), atol(argv[i+1]));
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters(&adf_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for dp:%ld, cam:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_DSP_CAMPAIGN_APPURL_BLOCKLIST,
				atol(argv[i]), atol(argv[i+1]), element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				atol(argv[i]),
				atol(argv[i+1]),
				oper_id,
				ret_list_size,
				element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for db:%ld, cam:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&adf_dbconn);
	return NULL;
}

void* generate_dsp_appurl_whitelist_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_adf_dsn_name, __FILE__,__LINE__);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {

		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: dp:%ld cam:%ld [Thread id=%lu]***\n",
				filter[oper_id], atol(argv[i]), atol(argv[i+1]), thread_params->thread_id);
		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_DSP_CAMPAIGN_APPURL_WHITELIST,
				atol(argv[i]), atol(argv[i+1]));
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters(&adf_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for dp:%ld, cam:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_DSP_CAMPAIGN_APPURL_WHITELIST,
				atol(argv[i]), atol(argv[i+1]), element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				atol(argv[i]),
				atol(argv[i+1]),
				oper_id,
				ret_list_size,
				element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for db:%ld, cam:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&adf_dbconn);
	return NULL;
}

void* generate_url_black_white_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	(void) query_meta;
	(void) oper_id;
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t kad_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, i, k;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv, g_odbc_kad_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%s\n",
				thread_params->thread_id, g_odbc_kad_dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	fprintf(stderr, "\n*** URL black/while list bloom generation [Thread id=%lu]", thread_params->thread_id);
	for( ; ; ) {

		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		fprintf(stderr, "\n*** %s list bloom generation Request:: pub:%ld site:%ld bloom_type:%ld [Thread id=%lu]***\n",
				atol(argv[i+2])==0?"Black":"White", atol(argv[i]), atol(argv[i+1]), atol(argv[i+2]), thread_params->thread_id);

		thread_params->ret_val = get_pub_site_bloom_list(&kad_dbconn,
				atol(argv[i]),
				atol(argv[i+1]),
				atol(argv[i+2]),
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_wl_bloom_filter failed for pub:%ld, site:%ld, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		thread_params->ret_val = set_pub_site_bloom_list(&kad_dbconn,
				atol(argv[i]),
				atol(argv[i+1]),
				bloom_list,
				ret_list_size,
				element_count,
				atol(argv[i+2]));
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_wl_bloom_filter failed for pub:%ld, site:%ld, retval:%d, %s:%d\n",
					thread_params->thread_id, atol(argv[i]), atol(argv[i+1]), thread_params->ret_val, __FILE__,__LINE__);
			break;
		}

		for(k=0; k<MAX_ALLOWED_BLOOMS && bloom_list[k]!= NULL; k++)
			bloom_destroy(&bloom_list[k]);
		ret_list_size[k] = 0;
	}

	release_db_connection(&kad_dbconn);
	return NULL;
}

/*
 * This function creates global bloom
 * with key as ucrid.
 * For now it will create two blooms
 * in future we will remove one.
 */

void* generate_global_creative_id_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	db_connection_t adf_dbconn;;
	db_connection_t bc_dbconn;
	int element_count=0, j;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	BKT_BLOOM *bkt_bloom_list[MAX_ALLOWED_BKT_BLOOMS] = {0};
	size_t bkt_ret_list_size[MAX_ALLOWED_BKT_BLOOMS] = {0};

	pthread_mutex_lock(&bloom_db_conn_mutex);

	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv,g_odbc_adf_dsn_name,
			                                g_odbc_dsn_user_name,g_odbc_dsn_user_password);

	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id,g_odbc_adf_dsn_name,__FILE__,__LINE__);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&bc_dbconn, &g_dbenv, g_odbc_bc_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_bc_dsn_name, __FILE__,__LINE__);
		release_db_connection(&adf_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	fprintf(stderr, "\n*** %s_GENERATION_REQUEST [Thread id:%lu]***\n", filter[oper_id], thread_params->thread_id);

	do {
		/* Creation of Global creativeId blocklist bkt_bloom filter */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_GLOBAL_CREATIVE_ID_BLOCKLIST);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bkt_bloom_filters(&bc_dbconn,
				sql_statement,
				query_meta,
				bkt_bloom_list,
				bkt_ret_list_size,
				&element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:get_bkt_bloom_filters failed for op:%d,retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}

		/* INSERT QUERY : Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_GLOBAL_CREATIVE_ID_BLOCKLIST, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bkt_bloom_filters(&adf_dbconn,
				sql_statement,
				bkt_bloom_list,
				bkt_ret_list_size,
				element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:set_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}
		/* bloom cleanup */
		for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && bkt_bloom_list[j]!= NULL; j++) {
			bkt_bloom_destroy(&bkt_bloom_list[j]);
			bkt_ret_list_size[j] = 0;
		}
	} while (0);

	release_db_connection(&adf_dbconn);
	release_db_connection(&bc_dbconn);
	return NULL;
}

/*
 * This function creates global bloom
 * with key as id_ucrid.
 */

void* generate_pub_preferred_global_creative_blocklist_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	db_connection_t adf_dbconn;;
	db_connection_t bc_dbconn;
	int element_count=0, j;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	BKT_BLOOM *bkt_bloom_list[MAX_ALLOWED_BKT_BLOOMS] = {0};
	size_t bkt_ret_list_size[MAX_ALLOWED_BKT_BLOOMS] = {0};

	pthread_mutex_lock(&bloom_db_conn_mutex);

	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv,g_odbc_adf_dsn_name,
			                                g_odbc_dsn_user_name,g_odbc_dsn_user_password);

	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id,g_odbc_adf_dsn_name,__FILE__,__LINE__);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&bc_dbconn, &g_dbenv, g_odbc_bc_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_bc_dsn_name, __FILE__,__LINE__);
		release_db_connection(&adf_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	fprintf(stderr, "\n*** %s_GENERATION_REQUEST [Thread id:%lu]***\n", filter[oper_id], thread_params->thread_id);

	do {
		/* Creation of Global id_ucrid blocklist bkt_bloom filter */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bkt_bloom_filters(&bc_dbconn,
				sql_statement,
				query_meta,
				bkt_bloom_list,
				bkt_ret_list_size,
				&element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:get_bkt_bloom_filters failed for op:%d,retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}

		/* INSERT QUERY : Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bkt_bloom_filters(&adf_dbconn,
				sql_statement,
				bkt_bloom_list,
				bkt_ret_list_size,
				element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:set_bkt_bloom_filters failed for op:%d, retval:%d",
					thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}
		/* bloom cleanup */
		for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && bkt_bloom_list[j]!= NULL; j++) {
			bkt_bloom_destroy(&bkt_bloom_list[j]);
			bkt_ret_list_size[j] = 0;
		}
	} while (0);

	release_db_connection(&adf_dbconn);
	release_db_connection(&bc_dbconn);
	return NULL;
}

void* generate_publisher_campaign_level_blocklist(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};
	db_connection_t adf_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	int element_count=0, j;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	long argv2_dsp = 0, argv3_cmpg = 0, argv4_pub = 0;

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_adf_dsn_name, __FILE__,__LINE__);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {
		int i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		argv2_dsp = atol(argv[i]);
		argv3_cmpg = atol(argv[i+1]);
		argv4_pub = atol(argv[i+2]);

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: dp:%ld cam:%ld pub:%ld [Thread id=%lu]***\n", filter[oper_id], argv2_dsp, argv3_cmpg, argv4_pub, thread_params->thread_id);
		/* Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_DB_DSP_PUB_CAMPG_BLOCKLIST, argv2_dsp, argv3_cmpg, argv4_pub); 

		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bloom_filters(&adf_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: get_bloom_filters failed for dp:%ld, cam:%ld, pub:%ld, op:%d, retval:%d, %s:%d\n", thread_params->thread_id, argv2_dsp, argv3_cmpg, argv4_pub, oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		fprintf(stderr, "\n*** %s_SET_REQUEST:: i:%d, dp:%ld cam:%ld pub:%ld [Thread id=%lu]***\n", filter[oper_id], i, argv2_dsp, argv3_cmpg, argv4_pub, thread_params->thread_id);
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_DB_DSP_PUB_CAMPG_BLOCKLIST, argv2_dsp, argv3_cmpg, argv4_pub, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				argv2_dsp,
				argv3_cmpg,
				oper_id,
				ret_list_size,
				element_count);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:ERROR: set_bloom_filters failed for db:%ld, cam:%ld, pub_id:%ld, op:%d, retval:%d, %s:%d\n", thread_params->thread_id, argv2_dsp, argv3_cmpg, argv4_pub, oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}
		//bloom cleanup
		for(j=0; j<MAX_ALLOWED_BLOOMS && bloom_list[j]!= NULL; j++) {
			bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&adf_dbconn);
	return NULL;
}

void* generate_ads_txt_domain_list_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS]={0};
	db_connection_t kad_dbconn;;
	db_connection_t ads_txt_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BKT_BLOOMS]={0};
	int element_count=0, j;
	long int pub_id=0, blm_type=0;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);

	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv,g_odbc_kad_dsn_name,
			                                g_odbc_dsn_user_name,g_odbc_dsn_user_password);

	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
			thread_params->thread_id, g_odbc_kad_dsn_name);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&ads_txt_dbconn, &g_dbenv, g_odbc_ads_txt_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
			thread_params->thread_id, g_odbc_ads_txt_dsn_name);
		release_db_connection(&kad_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);

	for ( ; ; ) {
		int i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;
		pub_id = atol(argv[i]);
		blm_type = atol(argv[i+1]);

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld blm_type:%ld [Thread id=%lu]***\n",
				filter[oper_id], pub_id, blm_type, thread_params->thread_id);

		switch (blm_type) {
			case GLOBAL_ADS_TXT_PRESENT_DOMAIN_LIST:
				snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_GLOBAL_ADS_TXT_PRESENT_DOMAIN_LIST);
				pub_id = 0; /* For global domain list bloom, we use pub_id=0 and type=0 */
				break;
			case PUB_ADS_TXT_RESELLER_DOMAIN_LIST:
				snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_PUB_ADS_TXT_RESELLER_DOMAIN_LIST, pub_id);
				break;
			case PUB_ADS_TXT_DIRECT_DOMAIN_LIST:
				snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_PUB_ADS_TXT_DIRECT_DOMAIN_LIST, pub_id);
				break;
			default:
				ERROR_LOG("[Thread id=%lu]:Invalid ads_txt_blm_type:%ld",thread_params->thread_id, blm_type);
				thread_params->ret_val = ADS_ERROR_INTERNAL;
				return NULL;

		}
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bkt_bloom_filters(&ads_txt_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:get_bkt_bloom_filters failed for op:%d, retval:%d",
				thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}

		/* INSERT QUERY : Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_ADS_TXT_DOMAIN_LIST_FILTER, pub_id, blm_type, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bkt_bloom_filters(&kad_dbconn,
				sql_statement,
				bloom_list,
				ret_list_size,
				element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:set_bkt_bloom_filters failed for op:%d, retval:%d",
				thread_params->thread_id, oper_id, thread_params->ret_val);
			break;

		}
		/* bloom cleanup */
		for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && bloom_list[j]!= NULL; j++) {
			bkt_bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&kad_dbconn);
	release_db_connection(&ads_txt_dbconn);
	return NULL;
}

void* generate_app_ads_txt_bloom_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id) {
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS]={0};
	db_connection_t kad_dbconn;;
	db_connection_t ads_txt_dbconn;
	size_t ret_list_size[MAX_ALLOWED_BKT_BLOOMS]={0};
	int element_count=0, j;
	long int pub_id=0, blm_type=0;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);

	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv,g_odbc_kad_dsn_name,
			                                g_odbc_dsn_user_name,g_odbc_dsn_user_password);

	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
			thread_params->thread_id, g_odbc_kad_dsn_name);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&ads_txt_dbconn, &g_dbenv, g_odbc_ads_txt_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
			thread_params->thread_id, g_odbc_ads_txt_dsn_name);
		release_db_connection(&kad_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);

	for ( ; ; ) {
		int i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;
		pub_id = atol(argv[i]);
		blm_type = atol(argv[i+1]);

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld blm_type:%ld [Thread id=%lu]***\n",
				filter[oper_id], pub_id, blm_type, thread_params->thread_id);

		switch (blm_type) {
			case GLOBAL_ADS_TXT_PRESENT_DOMAIN_LIST:
				snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_GLOBAL_APP_ADS_TXT_PRESENT_LIST);
				pub_id = 0; /* For global domain list bloom, we use pub_id=0 and type=0 */
				break;
			case PUB_ADS_TXT_RESELLER_DOMAIN_LIST:
				snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_PUB_APP_ADS_TXT_RESELLER_LIST, pub_id);
				break;
			case PUB_ADS_TXT_DIRECT_DOMAIN_LIST:
				snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_PUB_APP_ADS_TXT_DIRECT_LIST, pub_id);
				break;
			default:
				ERROR_LOG("[Thread id=%lu]:Invalid ads_txt_blm_type:%ld",thread_params->thread_id, blm_type);
				thread_params->ret_val = ADS_ERROR_INTERNAL;
				return NULL;

		}
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bkt_bloom_filters(&ads_txt_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:get_bkt_bloom_filters failed for op:%d, retval:%d",
				thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}

		/* INSERT QUERY : Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_APP_ADS_TXT_BLOOM_FILTER, pub_id, blm_type, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bkt_bloom_filters(&kad_dbconn,
				sql_statement,
				bloom_list,
				ret_list_size,
				element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:set_bkt_bloom_filters failed for op:%d, retval:%d",
				thread_params->thread_id, oper_id, thread_params->ret_val);
			break;

		}
		/* bloom cleanup */
		for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && bloom_list[j]!= NULL; j++) {
			bkt_bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&kad_dbconn);
	release_db_connection(&ads_txt_dbconn);
	return NULL;
}


void* generate_pub_geo_domain_list_filter(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS] = {0};
	db_connection_t adf_dbconn;;
	size_t ret_list_size[MAX_ALLOWED_BKT_BLOOMS] = {0};
	int element_count = 0, j;
	long int pub_id = 0;
	int argc = thread_params->argc;
	char **argv = thread_params->argv;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	pthread_mutex_lock(&bloom_db_conn_mutex);

	thread_params->ret_val = get_db_connection(&adf_dbconn, &g_dbenv, g_odbc_adf_dsn_name,
			                                g_odbc_dsn_user_name,g_odbc_dsn_user_password);

	if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
		ERROR_LOG("[Thread id=%lu]:Connection to DB failed, dsn_name:%s",
			thread_params->thread_id, g_odbc_kad_dsn_name);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);

	for ( ; ; ) {
		int i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;
		pub_id = atol(argv[i]);

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld [Thread id=%lu]***\n",
				filter[oper_id], pub_id, thread_params->thread_id);

		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_PUB_GEO_DOMAIN_BLOCKLIST_FILTER, pub_id);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = get_bkt_bloom_filters(&adf_dbconn,
				sql_statement,
				query_meta,
				bloom_list,
				ret_list_size,
				&element_count);
		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:get_bkt_bloom_filters failed for op:%d, retval:%d",
				thread_params->thread_id, oper_id, thread_params->ret_val);
			break;
		}

		/* INSERT QUERY : Create SQL char string which contains the query */
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, SET_PUB_GEO_DOMAIN_BLOCKLIST_FILTER, pub_id, element_count);
		sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

		thread_params->ret_val = set_bkt_bloom_filters(&adf_dbconn,
				sql_statement,
				bloom_list,
				ret_list_size,
				element_count);

		if (ADS_ERROR_SUCCESS != thread_params->ret_val) {
			ERROR_LOG("[Thread id=%lu]:set_bkt_bloom_filters failed for op:%d, retval:%d",
				thread_params->thread_id, oper_id, thread_params->ret_val);
			break;

		}
		/* bloom cleanup */
		for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && bloom_list[j]!= NULL; j++) {
			bkt_bloom_destroy(&bloom_list[j]);
			ret_list_size[j] = 0;
		}
	}

	release_db_connection(&adf_dbconn);
	return NULL;
}

void* generate_publisher_site_domain_app_whitelist(bloom_thread_param_t *thread_params,
				get_query_meta_t *query_meta,
				int oper_id){
	(void) query_meta;
	db_connection_t kad_dbconn;
	db_connection_t local_adf_dbconn;
	int i, argc = thread_params->argc;
	char **argv = thread_params->argv;

	pthread_mutex_lock(&bloom_db_conn_mutex);
	thread_params->ret_val = get_db_connection(&kad_dbconn, &g_dbenv, g_odbc_kad_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%s\n",
				thread_params->thread_id, g_odbc_kad_dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	thread_params->ret_val = get_db_connection(&local_adf_dbconn, &g_dbenv, g_odbc_local_adf_dsn_name,
						g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (thread_params->ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Connection to DB failed, dsn_name:%s %s:%d\n",
				thread_params->thread_id, g_odbc_local_adf_dsn_name, __FILE__,__LINE__);
		release_db_connection(&kad_dbconn);
		pthread_mutex_unlock(&bloom_db_conn_mutex);
		return NULL;
	}

	pthread_mutex_unlock(&bloom_db_conn_mutex);
	for( ; ; ) {
		i = __sync_fetch_and_add(&g_cur_arg_index, thread_params->batch_size);
		if(i >= argc)
			break;

		long pub_id = atol(argv[i]);
		long site_id = atol(argv[i+1]);
		publisher_site_whitelisting_data_t *tmp_pub_site_whitelist = NULL;
		int nelements = 0;

		fprintf(stderr, "\n*** %s_GENERATION_REQUEST:: pub:%ld site:%ld [Thread id:%lu]***\n",
				filter[oper_id], pub_id, site_id, thread_params->thread_id);

		thread_params->ret_val = db_get_publisher_site_whitelisting_data(&local_adf_dbconn,
				&tmp_pub_site_whitelist,
				&nelements,
				pub_id,
				site_id);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:get_pub_site_whitelist failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, pub_id, site_id, oper_id, thread_params->ret_val, __FILE__, __LINE__);
			break;
		}

		thread_params->ret_val = db_set_publisher_site_whitelist(&kad_dbconn,
				tmp_pub_site_whitelist,
				nelements,
				pub_id,
				site_id);
		if(thread_params->ret_val != ADS_ERROR_SUCCESS) {
			fprintf(stderr, "\n[Thread id=%lu]:get_pub_site_whitelist failed for pub:%ld, site:%ld, op:%d, retval:%d, %s:%d\n",
					thread_params->thread_id, pub_id, site_id, oper_id, thread_params->ret_val, __FILE__,__LINE__);
			break;
		}

		/* cleanup */
		if (tmp_pub_site_whitelist) {
			free(tmp_pub_site_whitelist);
			tmp_pub_site_whitelist = NULL;
		}
	}

	release_db_connection(&kad_dbconn);
	release_db_connection(&local_adf_dbconn);
	return NULL;
}

void* bloom_generation_handler(void* thread_data)
{
	bloom_thread_param_t *thread_params = NULL;
	int oper_id=0;
	char **argv;
	get_query_meta_t query_meta = {0,{0,0},0};

	/* Check the thread params */
	if (thread_data == NULL) {
		fprintf(stderr, "ERROR: Thread data passed is NULL: %s:%d\n",__FILE__,__LINE__);
		/* Cannot do much */
		return NULL;
	}

	/* Initilize the thread_params */
	thread_params = thread_data;
	argv = thread_params->argv;

	oper_id = atoi(argv[1]);
	thread_params->ret_val = ADS_ERROR_SUCCESS;
	if (oper_id<=0) {
		fprintf(stderr, "[Thread id=%lu]:ERROR:Invalid OperId:%d %s:%d\n",
				thread_params->thread_id, oper_id, __FILE__,__LINE__);
		thread_params->ret_val = ADS_ERROR_INVALID_ARGS;
		return NULL;
	}

	//initalize DB Query Meta Data
	init_query_metadata(&query_meta, oper_id);

	switch(oper_id)
	{
		case GSS_BLOCKLIST_FILTER:
			generate_gss_domain_app_blocklist_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_BLOCKLIST_LANDING_PAGE_FILTER:
			generate_blocklist_landing_page_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_CREATIVE_ID_FILTER:
			generate_creative_id_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_PUBLISHER_SITE_FLOOR_FILTER:
			generate_publisher_site_floor_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_WHITELIST_LANDING_PAGE_FILTER:
			generate_whitelist_landing_page_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_DAA_DEVICEID_OPTOUT_FILTER:
			generate_daa_deviceid_optout_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_DSP_BLOCKLIST_FILTER:
			generate_dsp_blocklist_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_PUBLISHER_SITE_DEAL_WHITELIST_FILTER:
			generate_publisher_site_deal_whitelist_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_UNIQ_CREATV:
			generate_unique_creative_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_DSP_WHITELIST_FILTER:
			generate_dsp_whitelist_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_DSP_APPURL_BLOCKLIST_FILTER:
			generate_dsp_appurl_blocklist_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_DSP_APPURL_WHITELIST_FILTER:
			generate_dsp_appurl_whitelist_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_URL_BLACK_WHITE_FILTER:
			generate_url_black_white_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_GLOBAL_CREATIVE_ID_FILTER:
			generate_global_creative_id_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_PUBLISHER_CAMPAIGN_DOMAIN_FILTER:
			generate_publisher_campaign_level_blocklist(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_ADS_TXT_DOMAIN_LIST_FILTER:
			generate_ads_txt_domain_list_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_PUB_GEO_DOMAIN_BLOCKLIST_FILTER:
			generate_pub_geo_domain_list_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER:
			generate_pub_preferred_global_creative_blocklist_filter(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_BLOCKLIST_LANDING_PAGE_FILTER_NEW:
			generate_blocklist_landing_page_filter_new(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_APP_ADS_TXT_FILTER:
			generate_app_ads_txt_bloom_filter(thread_params, &query_meta, oper_id);
			break;
		case PUBLISHER_SITE_DOMAIN_APP_WHITELIST:
			generate_publisher_site_domain_app_whitelist(thread_params, &query_meta, oper_id);
			break;
		case BLOOM_CLASSIFIED_CREATIVES_SMALL:
		case BLOOM_CLASSIFIED_CREATIVES_GIANT:
			generate_classfied_creative_bloom(thread_params, &query_meta, oper_id);
			break;
		default:
			fprintf(stderr, "Command Usage:"
					"\n [1] Landing Page Filter:: %s 1 <pub_id> <site_id> ..."
					"\n [2] Creative Id Filter:: %s 2 <pub_id> <site_id> <1:whitelist/0:blocklist>..."
					"\n [4] Whitelist Domain Filter:: %s 4 <pub_id> <site_id> ..."
					"\n [5] DSP BlockList Filter:: %s 5  <dsp_id> <cmpgn_id> ..."
					"\n [6] Publisher site Floor Filter:: %s 6  <active_entity:3,4,14> <pub_id> <site_id> ..."
					"\n [7] Deal whitelist Filter:: %s 7 <pub_id> <site_id> ..."
					"\n [8] Global Supply side BlockList:: %s 8"
					"\n [9] Unique Creative filter:: %s 9"
					"\n [10] DSP Whitelist filter:: %s 10 <dsp_id> <cmpgn_id> ..."
					"\n [11] DSP APP Url Blocklist filter:: %s 11 <dsp_id> <cmpgn_id> ..."
					"\n [12] DSP APP Url Whitelist filter:: %s 12 <dsp_id> <cmpgn_id> ..."
					"\n [13] URL BlockList/WhiteList:: %s 13 <pub_id> <site_id> <1:whitelist/0:blocklist> ..."
					"\n [14] DAA DeviceId Optout filter:: %s 14 <hashing_type:1,2,3>"
					"\n [15] Global Creative Id Filter:: %s 15"
					"\n [16] Publisher campaign level domain black list:: %s 16"
					"\n [17] ADS.txt domain list filter:: %s 17 <pub_id> <0:global domain list 1:reseller 2:direct>"
					"\n [18] Pub Geo domain list filter:: %s 18 <pub_id>"
					"\n [19] Pub Preferred Creative Filter:: %s 19"
					"\n [20] New Landing Page Filter:: %s 20 <pub_id> <site_id> ..."
					"\n [21] App-ads.txt Filter:: %s 21 <pub_id/0> <0:global domain list 1:reseller 2:direct>"
					"\n [22] Publisher Site domain app whitelist:: %s 22 <pub_id> <site_id> ..."
					"\n [23] Classifed Creative filter[Small]:: %s 23"
					"\n [24] Classifed Creative filter[Giant]:: %s 24\n",
					argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0]);
			thread_params->ret_val = ADS_ERROR_INVALID_ARGS;
	}
	return NULL;
}
