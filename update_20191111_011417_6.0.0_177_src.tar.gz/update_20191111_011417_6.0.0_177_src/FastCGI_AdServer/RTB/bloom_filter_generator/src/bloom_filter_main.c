/*
   PubMatic Inc. ("PubMatic") CONFIDENTIAL
   Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/


#include <stdio.h>
#include <string.h>
#include "bloom_filter_handler.h"

db_env_t g_dbenv;
char *g_odbc_kad_dsn_name = NULL;
char *g_odbc_adf_dsn_name = NULL;
char *g_odbc_bc_dsn_name = NULL;
char *g_odbc_local_adf_dsn_name = NULL;
char *g_odbc_ceaser_dsn_name = NULL;
char *g_odbc_rawdata_dsn_name = NULL;
char *g_odbc_master_dsn_name = NULL;
char *g_odbc_daa_optout_dsn_name = NULL;
char *g_odbc_dsn_user_name = NULL;
char *g_odbc_dsn_user_password = NULL;
char *g_conf_bloom_dir = BLOOM_DIR;
int g_cur_arg_index; //Should be assigned some value before using it.
unsigned int g_max_bloom_thread_count;

pthread_mutex_t bloom_db_conn_mutex;

int gbl_log_level = L_INFO;

int main(int argc, char *argv[]) {
	int ret_val = ADS_ERROR_SUCCESS;
	char log_file[4096];
	int log_fd=-1, i=0;
	int max_thread_count;
	unsigned long batch_size;
	pthread_t *id = NULL;
	bloom_thread_param_t *thread_params = NULL;

	if(argc<2 || atoi(argv[1]) < 1 || atoi(argv[1]) >= TOTAL_BLOOM_COUNT) {
		fprintf(stderr, "Command Usage:"
		  "\n [1] Landing Page Filter:: %s 1 <pub_id> <site_id> ..."
		  "\n [2] Creative Id Filter:: %s 2 <pub_id> <site_id> <1:whitelist/0:blocklist>..."
		  "\n [4] Whitelist Domain Filter:: %s 4 <pub_id> <site_id> ..."
		  "\n [5] DSP BlockList Filter:: %s 5  <dsp_id> <cmpgn_id> ..."
		  "\n [6] Publisher site Floor Filter:: %s 6  <active_entity:3,4,14> <pub_id> <site_id> ..."
		  "\n [7] Deal whitelist Filter:: %s 7 <pub_id> <site_id> ..."
		  "\n [8] Global Supply side BlockList:: %s 8"
		  "\n [9] Unique Creative filter:: %s 9"
		  "\n [10] DSP Whitelist filter:: %s 10 <dsp_id> <cmpgn_id> ..."
		  "\n [11] DSP APP Url Blocklist filter:: %s 11 <dsp_id> <cmpgn_id> ..."
		  "\n [12] DSP APP Url Whitelist filter:: %s 12 <dsp_id> <cmpgn_id> ..."
		  "\n [13] URL BlockList/WhiteList:: %s 13 <pub_id> <site_id> <1:whitelist/0:blocklist> ..."
		  "\n [14] DAA DeviceId Optout filter:: %s 14 <hashing_type:1,2,3>"
		  "\n [15] Global Creative Id Filter :: %s 15 "
		  "\n [16] Publisher Campaign Domain Filter :: %s 16 <dsp> <campg> <pub_id>"
		  "\n [17] ADS.txt domain list filter:: %s 17 <pub_id> <0:global domain list 1:reseller 2:direct>"
		  "\n [18] Pub Geo domain list filter:: %s 18 <pub_id>"
		  "\n [19] Pub Preferred Creative Filter:: %s 19"
		  "\n [20] New Landing Page Filter:: %s 20 <pub_id> <site_id> ..."
		  "\n [21] App-ads.txt Filter:: %s 21 <pub_id/0> <0:global domain list 1:reseller 2:direct>"
		  "\n [22] Publisher Site domain app whitelist:: %s 22 <pub_id> <site_id> ..."
		  "\n [23] Classifed Creative filter[Small]:: %s 23"
		  "\n [24] Classifed Creative filter[Giant]:: %s 24\n",
		argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0],argv[0]);
		return ADS_ERROR_INVALID_ARGS;
	}

	/* generate log file name as todays date*/
	get_log_file_name(log_file);

	/* open log file */
	log_fd = open(log_file, (O_CREAT|O_WRONLY|O_APPEND), (S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH));

	if(log_fd < 0) {
		fprintf (stderr, "ERROR: Failed to open log file- %s\n", log_file);
		return ADS_ERROR_INTERNAL;
	}

	fprintf (stderr, "\nWriting Logs to '%s'\n", log_file);

	/* redirect stderr to log file below this line */
	dup2(log_fd, 2);

	ret_val = set_bloom_configuration();
	if (ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "ERROR: set_bloom_configuration failed, %s:%d\n",__FILE__,__LINE__);
		return ret_val;
	}
	ret_val = init_db_env(&g_dbenv);
	if (ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "ERROR: DB Env initilization failed, %s:%d\n",__FILE__,__LINE__);
		free_bloom_configuration();
		return ret_val;
	}

	/* Thread configuration */
	ret_val = get_thread_configuration(atoi(argv[1]), argc, &batch_size, &max_thread_count);
	if (ret_val != ADS_ERROR_SUCCESS) {
		fprintf(stderr, "ERROR: get_thread_configuration failed, %s:%d\n",__FILE__,__LINE__);
		free_bloom_configuration();
		return ret_val;
	}

	fprintf(stderr, "creating [%d] threads, %s:%d\n",max_thread_count,__FILE__,__LINE__);

	/* Based on the thread count allocate the array for thread ids */
	id = (pthread_t *) malloc(sizeof (pthread_t) * max_thread_count);
	if (id == NULL) {
		/* not enough memory */
		free_bloom_configuration();
		return ADS_ERROR_NOMEMORY;
	}

	/* Based on the thread count allocate the array of thread_params */
	thread_params = (bloom_thread_param_t*)  malloc(sizeof (bloom_thread_param_t) * max_thread_count);
	if (thread_params == NULL) {
		/* not enough memory */
		free(id);
		free_bloom_configuration();
		return ADS_ERROR_NOMEMORY;
	}

	pthread_mutex_init(&bloom_db_conn_mutex, NULL);

	/* Create threads */
	for (i = 0; i < max_thread_count; i++) {
		thread_params[i].thread_id = i;
		thread_params[i].argc = argc;
		thread_params[i].argv = argv;
		thread_params[i].batch_size = batch_size;
		pthread_create(&id[i], NULL, bloom_generation_handler, (void*)&thread_params[i]);
	}

	/* Wait for all threads to finish */
	for (i = 0; i < max_thread_count; i++) {
		pthread_join(id[i], NULL);
	}

	/* Log status of all threads */
	for (i = 0; i < max_thread_count; i++) {
		if(thread_params[i].ret_val == ADS_ERROR_SUCCESS)
			fprintf(stderr, "Thread[id=%lu] returned SUCCESS, %s:%d\n",thread_params[i].thread_id,__FILE__,__LINE__);
		else{
			fprintf(stderr, "Thread[id=%lu] returned ERROR:%d, %s:%d\n",thread_params[i].thread_id,thread_params[i].ret_val,__FILE__,__LINE__);
			ret_val = thread_params[i].ret_val;
		}
	}

	pthread_mutex_destroy(&bloom_db_conn_mutex);
	free(thread_params);
	free(id);
	free_bloom_configuration();

	if(ret_val == ADS_ERROR_SUCCESS)
		fprintf(stderr, "Main thread exiting..returning SUCCESS\n");
	else
		fprintf(stderr, "Main thread exiting..returning ERROR\n");
	return ret_val;
}
