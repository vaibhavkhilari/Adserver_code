/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_rt_campaign_config.h"
#include "db_bloom_filter_generator.h"
#include "error.h"
#include "bloom_filter.h"
#define MAX_BLOOM_DOMAIN_COUNT 150000

#define INITIAL_URL_BLOCK_LIST_SIZE 20
#define INITIAL_GLOBAL_URL_BLOCK_LIST_SIZE 50000

#define GET_PUBLISHER_SITE_BLOCKLIST \
"select distinct site_id,domain_name from publisher_site_block_list where pub_id = ? and site_id in (0,?)"

#define SET_PUBLISHER_SITE_BLOCKLIST \
"replace into publisher_site_landing_page_filter(pub_id,site_id,bloom_filter,blocked_domain_count) values(?,?,?,?)"

#define GET_GLOBAL_PUBLISHER_SITE_BLOCKLIST \
	"select distinct id, url from global_block_list where is_deleted = 0 limit ?"

#define UPDATE_ACTIVE_BLOOM_STATUS \
	"update publisher_site_landing_page_filter set active_bloom = 0 WHERE pub_id = 0 and site_id = ?"

#define PUB_SITE_URL_WHITE_LIST_TABLE_NAME "publisher_site_url_white_list"
#define PUB_SITE_URL_BLOCK_LIST_TABLE_NAME "publisher_site_url_block_list"
#define GET_PUBLISHER_SITE_URL_LIST \
"select distinct url from %s AS publisher_site_url_list where pub_id = ? and site_id in (0,?)"

#define SET_PUBLISHER_SITE_BLOOM_LIST \
"replace into publisher_site_bloom_list(pub_id,site_id, serialised_url_bloom_list,url_count, bloom_type) values(?,?,?,?,?)"


void lowercase_string( char* str, int left, int right);

typedef struct {
	char domain_name[BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH + 1];
} pub_blocklist_domain;

typedef struct {
	char domain_name[MAX_DOMAIN_NAME_LENGTH + 1];
} pub_site_url_list_t;

int build_blooms( pub_site_url_list_t *url_list,
		int ele_count,
		BLOOM** publisher_site_bloom_list,
		size_t *ret_size
		);

//this function generated bloom after query from Database
int get_pub_site_bloom_list(db_connection_t *dbconn,
				long pub_id,
				long site_id,
				int bloom_type,
				BLOOM** publisher_site_bloom_list,
				size_t *ret_size,
				int *url_count) {
	pub_site_url_list_t *url_list=NULL, *tmp_url_list=NULL;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLINTEGER s_pub_id=0;
	SQLLEN cb_s_pub_id=0;
	SQLINTEGER s_site_id=0;
	SQLLEN cb_s_site_id=0;
	SQLCHAR s_url[MAX_DOMAIN_NAME_LENGTH + 1];
	SQLLEN cb_s_url = SQL_NTS; 

	int actual_use_count = 0;
	int use_count = 0;
	int alloc_count = INITIAL_URL_BLOCK_LIST_SIZE;
	ret_size[0] = 0;
	publisher_site_bloom_list[0] = NULL;

	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	if(bloom_type ==0)
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN,
				GET_PUBLISHER_SITE_URL_LIST, PUB_SITE_URL_BLOCK_LIST_TABLE_NAME);
	else if (bloom_type == 1)
		snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN,
				GET_PUBLISHER_SITE_URL_LIST, PUB_SITE_URL_WHITE_LIST_TABLE_NAME);
	else {
		fprintf(stderr,"Invalid Bloom type:Pub:%ld, site:%ld %s:%d\n",pub_id, site_id,
				__FILE__,__LINE__);
		return -1;
	}

	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';
	int ret_val=ADS_ERROR_SUCCESS;

	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}

	/* Bind parameters */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}
	s_pub_id = pub_id;	

	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_s_site_id);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val=ADS_ERROR_INTERNAL;
		goto done;
	}
	s_site_id = site_id;	

	sql_retval = SQLExecute(statement_handle);
	if (sql_retval == SQL_SUCCESS) {
		SQLBindCol(statement_handle, 1, SQL_C_CHAR, &s_url, MAX_DOMAIN_NAME_LENGTH + 1, &cb_s_url);
		
		SQLRowCount(statement_handle,(SQLLEN*)&alloc_count);
		//limiting it to process only limited rows
		alloc_count= (alloc_count<=0)?(INITIAL_URL_BLOCK_LIST_SIZE):alloc_count;
		*url_count=alloc_count;
		if(alloc_count>MAX_URL_LIMIT){
			fprintf(stderr,"ERROR::DB entries Exceeds input Limit:ActualCount:%d, inputLimit:%d\n",alloc_count,MAX_URL_LIMIT);
			alloc_count=MAX_URL_LIMIT;
		}

		url_list = (pub_site_url_list_t *) malloc ((sizeof(pub_site_url_list_t) * alloc_count ));	
		if (url_list == NULL) {
			ret_val= ADS_ERROR_NOMEMORY;
			goto done;
		}
		while (sql_retval != SQL_NO_DATA) {
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {
				if(actual_use_count == alloc_count ){
					if(actual_use_count<MAX_URL_LIMIT) {
						alloc_count*=2;
						if(alloc_count >MAX_URL_LIMIT)
							alloc_count=MAX_URL_LIMIT;
						tmp_url_list = realloc(url_list,
								sizeof(pub_site_url_list_t) * alloc_count);
						if (tmp_url_list == NULL) {
							ret_val= ADS_ERROR_NOMEMORY;
							goto done;
						}
						url_list = tmp_url_list;
					}else	{
						use_count++;
						continue;
					}
				}
				if(cb_s_url != SQL_NULL_DATA && cb_s_url != 0) {
					cb_s_url = (cb_s_url < MAX_DOMAIN_NAME_LENGTH)? cb_s_url : MAX_DOMAIN_NAME_LENGTH;
					char *actual_str_ptr = (char*)s_url;
					if(strncmp((char*)s_url, WWW_STR, WWW_STR_LEN)==0)
						actual_str_ptr = (char*)s_url + WWW_STR_LEN;
					int rc=NO_ASC_CONVERSION;
					char *domain_punycode=NULL;
					rc=convert_unicode_domain_to_punycode(actual_str_ptr, &domain_punycode);
					if((rc == ASC_CONVERT_SUCCESS) && (domain_punycode != NULL)){
						actual_str_ptr=domain_punycode;
					}
					strncpy(url_list[actual_use_count].domain_name,actual_str_ptr, MAX_DOMAIN_NAME_LENGTH);
					url_list[actual_use_count].domain_name[MAX_DOMAIN_NAME_LENGTH]=0;
					if(NULL!= domain_punycode){
						free(domain_punycode);
						domain_punycode=NULL;
					}
					actual_use_count++;
					use_count++;
				}
			}
		}
	} else {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}

	build_blooms( url_list,
			actual_use_count,
			publisher_site_bloom_list,
			ret_size
			);

done:
	if (url_list != NULL) {
		free(url_list);
		url_list = NULL;
	}
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	return ret_val;
}

int build_blooms( pub_site_url_list_t *url_list,
			int ele_count,
			BLOOM** publisher_site_bloom_list,
			size_t *ret_size
		){
	int i=0, j=0;
	BLOOM* bloom = NULL;
	size_t memcache_obj_size = 0;
	int false_positive=0;
	int cur_ele=0;

	for( i=0; i<MAX_ALLOWED_BLOOMS && cur_ele<ele_count ;i++){
		if((bloom = bloom_create(
						(((ele_count-cur_ele)>MAX_ALLOWED_URL_PER_BLOOM) ? MAX_ALLOWED_URL_PER_BLOOM:(ele_count-cur_ele)),
						&memcache_obj_size))){
			for( j=0; j<MAX_ALLOWED_URL_PER_BLOOM && cur_ele<ele_count; j++, cur_ele++){
				if(bloom_check(bloom, url_list[cur_ele].domain_name)){
					false_positive++;
					BLOCKLIST_DEBUG("BloomList: bloom_check,match for %s %s:%d\n",url_list[cur_ele].domain_name, __FILE__, __LINE__);
			}
			bloom_add(bloom, url_list[cur_ele].domain_name);
			BLOCKLIST_DEBUG("LPF_Bloom:URL added:%s %s:%d\n", url_list[cur_ele].domain_name, __FILE__, __LINE__);
			}
			publisher_site_bloom_list[i]=bloom;
			ret_size[i]=memcache_obj_size;
		}else
			break;
	}
	if(i<MAX_ALLOWED_BLOOMS && cur_ele<ele_count){
		fprintf(stderr,"Error, Bloom creation failed:%d,%s\n",__LINE__,__FILE__);
		while(i>=0){
		  if(publisher_site_bloom_list[i]) free(publisher_site_bloom_list[i]);
		  publisher_site_bloom_list[i]=NULL;
		  ret_size[i]=0;
		  i--;
		}
	}else{
		if(i<MAX_ALLOWED_BLOOMS){
			publisher_site_bloom_list[i]=NULL;
		}else if( cur_ele<ele_count){
			fprintf(stderr,"URL count exceeds Bloom limit:%s:%d\n",__FILE__,__LINE__);
		}
	}
	return 0;
}

//this function set the bloom structure in Database
//first bloom stores the information ablout total no of blloms,appended in last
int set_pub_site_bloom_list(db_connection_t *dbconn,
				long pub_id,
				long site_id,
				BLOOM** publisher_site_bloom_list,
				size_t *ret_size,
				int url_count,
				int bloom_type){
	/* Local variables */
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLINTEGER s_pub_id=0;
	SQLLEN cb_s_pub_id=0;
	SQLINTEGER s_site_id=0;
	SQLLEN cb_s_site_id=0;
	SQLCHAR *s_bit_array=NULL;
	SQLLEN cb_s_bit_array = 0; //BIT_ARRAY_SIZE_BYTES(publisher_site_bloom_list->bit_array_size);
	SQLINTEGER s_bloom_type=0;
	SQLLEN cb_s_bloom_type=0;
	SQLINTEGER s_url_count=0;
	SQLLEN cb_s_url_count=0;



	int ret_val=ADS_ERROR_SUCCESS;

	if(publisher_site_bloom_list == NULL || *publisher_site_bloom_list== NULL) {
		fprintf(stderr,"INFO : No i/p BLOOM for pub_id:%ld site_id:%ld, %s:%d\n",pub_id,site_id,__FILE__,__LINE__);
		goto done;
	}

	int cur_bloom=0;
	//get the serialized bloom data in in one buffer.medium_bloom supports upto 16MB
	while( MAX_ALLOWED_BLOOMS>cur_bloom 
			&& publisher_site_bloom_list[cur_bloom] != NULL 
			&& publisher_site_bloom_list[cur_bloom]->nelements>0){
		cb_s_bit_array+= ret_size[cur_bloom];
		cur_bloom++;
	}
	s_bit_array=(SQLCHAR*)malloc(sizeof(char)*cb_s_bit_array);
	if(NULL== s_bit_array){
		ret_val=ADS_ERROR_NOMEMORY;
		goto done;
	}
	cur_bloom=0;
	size_t cur_pos=0;
	while( MAX_ALLOWED_BLOOMS>cur_bloom
			 && publisher_site_bloom_list[cur_bloom]!= NULL
			 && publisher_site_bloom_list[cur_bloom]->nelements>0){
		memcpy(s_bit_array+cur_pos, publisher_site_bloom_list[cur_bloom],	ret_size[cur_bloom]);
		cur_pos+=ret_size[cur_bloom];
		cur_bloom++;
		//copy data in buffer
	}

	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);
	strncpy((char *) sql_statement, SET_PUBLISHER_SITE_BLOOM_LIST, MAX_SQL_QUERY_STR_LEN );
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}

	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}
	s_pub_id = pub_id;	

	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_s_site_id);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}
	s_site_id = site_id;


	sql_retval = SQLBindParameter(statement_handle, 3, SQL_PARAM_INPUT, SQL_C_BINARY,
			SQL_LONGVARBINARY, cb_s_bit_array, 0, 
			(unsigned char*)s_bit_array, 0, &cb_s_bit_array);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}//data already copied

	sql_retval = SQLBindParameter(statement_handle, 4, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_url_count, 0, &cb_s_url_count);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}
	s_url_count=url_count;

	sql_retval = SQLBindParameter(statement_handle, 5, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_bloom_type, 0, &cb_s_bloom_type);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}
	s_bloom_type = bloom_type;


	sql_retval = SQLExecute(statement_handle);
	if (sql_retval == SQL_SUCCESS) {
		fprintf(stderr, "Bloom_LIST:: Data Inserted Successfully- pub:%ld, site:%ld, stored_bit_array_len_in_bytes:%zd, %s:%d\n",
				pub_id, site_id, cb_s_bit_array, __FILE__, __LINE__);
	} else {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}

done:
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	if(NULL != s_bit_array)
		free(s_bit_array);

	return ret_val;
}
