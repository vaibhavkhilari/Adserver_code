/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "cache_campaign_data_provider_segment_type_settings.h"
#include "dp_data_passing_generic.h"
#include "dp_data_passing_util.h"

#define SEGMENT_IDS_ALLOC_SIZE					5

void dump_cmpg_dp_seg_type_settings(campaign_data_provider_segment_type_settings_t *seg_type_setting)
{
	int k;

	llog_write(L_DEBUG, "\n=============%s()==============", __FUNCTION__);
	llog_write(L_DEBUG, "\ncampaign_id : %ld", seg_type_setting->campaign_id);
	llog_write(L_DEBUG, "\ndata_provider_id : %d", seg_type_setting->data_provider_id);        
	llog_write(L_DEBUG, "\nsegment_type_id = %d", seg_type_setting->segment_type_id);
	for (k = 0; k < seg_type_setting->segment_ids_count; k++)
	{
		llog_write(L_DEBUG, "\n  segment_ids[%d] = %d", k, seg_type_setting->segment_ids[k]);
	}
	llog_write(L_DEBUG, "\n=============%s() END==============\n", __FUNCTION__);
}

void init_data_provider_data(data_provider_data_t *dp_data) {
	if(dp_data == NULL) {
		return;
	}

	dp_data->campaign_id = 0;
	dp_data->data_provider_id = 0;
	dp_data->scope[0] = '\0';
	dp_data->type[0] = '\0';
	dp_data->json_contextual_data = NULL;
	dp_data->json_contextual_data_len = 0;
	dp_data->json_brand_safety_data = NULL;
	dp_data->json_brand_safety_data_len = 0;
	dp_data->json_logger_data = NULL;
	dp_data->json_logger_data_len = 0;

	return;
}

void cleanup_all_campg_level_dp_settings(campaign_data_provider_data_ops_params_t cmpg_data_provider_data_params[MAX_REALTIME_CAMPAIGNS],
										int cmpg_dp_data_params_idx,
										rt_request_params_t *rt_request_params)
{
	int i;

#ifdef DEBUG
	/*llog_write(L_DEBUG, "\n%s()://Cleanup Contextual & Brand Safety data provided by Data-Provider(s).\n",
					__FUNCTION__);*/
#endif //DEBUG
	for (i = 0; i < cmpg_dp_data_params_idx; i++)
	{
		cleanup_campaign_data_provider_data(
				cmpg_data_provider_data_params[i].campaign_id,
				&cmpg_data_provider_data_params[i],
				rt_request_params);
	}
}

//Allocate memory for Segment type settings.
//Return 0 on Success & 1 on Failure.
//TODO(Darshan): use retrun type macros ADS_ERROR_*
static int alloc_seg_type_settings(
                             campaign_data_provider_segment_type_settings_t **seg_type_settings,
							 int *alloc_count,
							 int *use_count)
{
	campaign_data_provider_segment_type_settings_t *tmp_seg_type_settings = NULL;

	if (*alloc_count > *use_count)
	{
		tmp_seg_type_settings = malloc(
						sizeof (campaign_data_provider_segment_type_settings_t) +
						((*alloc_count) * sizeof (int)));
		if (tmp_seg_type_settings == NULL)
		{
			llog_write(L_DEBUG, "\n(%s:%d) Not able to allocate memory for segment ids.\n", __FUNCTION__, __LINE__);
			return 1;
		}
	}
	else
	{
		*alloc_count += SEGMENT_IDS_ALLOC_SIZE;
		tmp_seg_type_settings = realloc(
							*seg_type_settings,
							sizeof (campaign_data_provider_segment_type_settings_t) +
							((*alloc_count) * sizeof (int)));
		if (tmp_seg_type_settings == NULL)
		{
			llog_write(L_DEBUG, "\n(%s:%d) Not able to allocate memory for segment ids.\n", __FUNCTION__, __LINE__);
			return 1;
		}
	}

	*seg_type_settings = tmp_seg_type_settings;
	return 0;
}

/*
 * Retrive Segment type settings from cached Data-Provider settings.
 * Returns: On success 0 & on failure 1.
 */
int get_seg_type_settings_from_cached_dp_setting(long campaign_id,
				                                 int data_provider_id,
	                                             campaign_data_provider_settings_t *dp_settings,
												 memcache_cmpg_dp_data_passing_settings_t *cmpg_dp_settings)
{
	int i;
	int alloc_count;
	int use_count;
	int prev_seg_type_id;
	int seg_id_idx;
	int ret = 0;

	if (dp_settings == NULL ||
		cmpg_dp_settings == NULL)
	{
		llog_write(L_DEBUG, "%s(): One of the input params is NULL.\n",
						__FUNCTION__);
		return 1;
	}

	prev_seg_type_id = -1;
	seg_id_idx = -1;
	for (i = 0; i < cmpg_dp_settings->dp_settings_count; i++)
	{
		if (i == 0 ||
			(	prev_seg_type_id > 0 &&
				prev_seg_type_id != cmpg_dp_settings->dp_settings[i].segment_type_id))
		{
			if (i > 0)
			{
				dp_settings->cmpg_dp_seg_stype_settinngs[seg_id_idx]->segment_ids_count = use_count;
				prev_seg_type_id = dp_settings->cmpg_dp_seg_stype_settinngs[seg_id_idx]->segment_type_id;
			}
			prev_seg_type_id = cmpg_dp_settings->dp_settings[i].segment_type_id;

			++seg_id_idx;
			if (seg_id_idx >= MAX_DATA_PROVIDER_SEGMENT_TYPE)
			{
				seg_id_idx = (MAX_DATA_PROVIDER_SEGMENT_TYPE - 1);
				break;
			}
			alloc_count = SEGMENT_IDS_ALLOC_SIZE;
			use_count = 0;
			if (alloc_seg_type_settings(
					&dp_settings->cmpg_dp_seg_stype_settinngs[seg_id_idx],
					&alloc_count,
					&use_count) != 0)
			{
				ret = -1;
				goto cleanup;
			}
		}
		else if (use_count == alloc_count)
		{
			if (alloc_seg_type_settings(
					&dp_settings->cmpg_dp_seg_stype_settinngs[seg_id_idx],
					&alloc_count,
					&use_count) != 0)
			{
				ret = -1;
				goto cleanup;
			}
		}

		//Fill the settings.
		/* Campaign Id. */
		dp_settings->cmpg_dp_seg_stype_settinngs[seg_id_idx]->campaign_id = campaign_id;
		/* Id of the Data Provider. */
		dp_settings->cmpg_dp_seg_stype_settinngs[seg_id_idx]->data_provider_id = data_provider_id;
		/* Segment type ID. Ex. Contextual, Brand Safety etc. */
		dp_settings->cmpg_dp_seg_stype_settinngs[seg_id_idx]->segment_type_id = cmpg_dp_settings->dp_settings[i].segment_type_id;
		dp_settings->cmpg_dp_seg_stype_settinngs[seg_id_idx]->segment_ids[use_count] = cmpg_dp_settings->dp_settings[i].segment_id;

		use_count++;
	}

	if(seg_id_idx>=0){
	  dp_settings->cmpg_dp_seg_stype_settinngs[seg_id_idx]->segment_ids_count = use_count;
	  dp_settings->cmpg_dp_seg_stype_settinngs_count = (seg_id_idx + 1);
	}
	return 0;

cleanup:
	for (i = 0; i <= seg_id_idx; i++)
	{
		if (dp_settings->cmpg_dp_seg_stype_settinngs[i] != NULL)
		{
			free(dp_settings->cmpg_dp_seg_stype_settinngs[i]);
			dp_settings->cmpg_dp_seg_stype_settinngs[i] = NULL;
		}
	}
	dp_settings->cmpg_dp_seg_stype_settinngs_count = 0;

	return ret;
}

