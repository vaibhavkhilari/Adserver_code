/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "error.h"
#include "fte_util.h"
#include "db_error.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "campaign_data_provider_data.h"
#include "campaign_data_provider_settings.h"
#include "dp_data_passing_generic.h"
#include "rt_types.h"
#include "proximic_data_passing.h"
#include "dp_properties.h"

typedef struct dp_data_passing_conf
{
	int data_provider_idx;
	dp_data_passing_ops_t *ops;
} dp_data_passing_conf_t;

static dp_data_passing_conf_t dp_confs[MAX_DATA_PROVIDERS] = {
		[0] = {
			.data_provider_idx = 0,
			.ops = &g_proximic_data_passing_ops
		}
};

//For given Campaignget Contextual & Brand Safety data from Data-Provider(s).
//Returns: On success 0 & on failure 1.
int get_campaign_data_provider_contextual_and_brandsafety_data(
                             long campaign_id,
                             campaign_data_provider_data_ops_params_t *params,
                             struct rt_request_params *rt_request_params,
                             cache_handle_t *cache_handle,
                             db_connection_t *dbconn)
{
	int i = 0, j = 0;
	int ret_val = 0;
	/* Campaign level settings. */
	campaign_level_dp_settings_t *cmpg_dp_settinngs;
	/* Data provided by Data-Provider(s) for given Campaign. */
	campaign_data_provider_data_t *cmpg_dp_data;
	/* Data that needs to be logged regarding data provided by Data-Provider(s). */
	campaign_data_provider_logger_data_t *cmpg_dp_logger_data;
	/* Data-Provider respoce params. */
	dp_response_params_t *dp_resp_params;
	dp_data_passing_params_t dp_params;
	char json_data_provider_segment_ids[MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + MAX_JSON_DATA_PROVIDER_SEGMENT_IDS + 5];

	//Sanity checks.
	if (params == NULL ||
		rt_request_params == NULL ||
		rt_request_params->fte_additional_params == NULL ||
		rt_request_params->fte_additional_params->dp_resp_params == NULL ||
		cache_handle == NULL ||
		dbconn == NULL)
	{
		return 1;
	}

	params->campaign_id = campaign_id;
	cmpg_dp_settinngs = &params->cmpg_dp_settinngs;
	cmpg_dp_data = &params->cmpg_dp_data;
	cmpg_dp_logger_data = &params->cmpg_dp_logger_data;
	dp_resp_params = (dp_response_params_t *) rt_request_params->fte_additional_params->dp_resp_params;
	strcpy(cmpg_dp_logger_data->json_data_provider_contextual_segment_ids, "[");
	cmpg_dp_logger_data->json_data_provider_contextual_segment_ids_len = 1;
	strcpy(cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids, "[");
	cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids_len = 1;
	for (i = 0, j = 0; i < MAX_DATA_PROVIDERS; i++)
	{
		cmpg_dp_settinngs->dp_settings[j] = (campaign_data_provider_settings_t *) malloc( sizeof (campaign_data_provider_settings_t));
		if (cmpg_dp_settinngs->dp_settings[j] == NULL)
		{
			llog_write(L_DEBUG, "%s(): Not able to allocate memory for Data-Provider settings.\n", __FUNCTION__);
			continue;
		}

		//Initialize Data-Provider params.
		dp_params.campaign_id = campaign_id;
		dp_params.dp_settings = cmpg_dp_settinngs->dp_settings[j];
		dp_params.dp_data = &cmpg_dp_data->dp_data[j];
		dp_params.json_logger_data_provider_contextual_segment_ids[0] = '\0';
		dp_params.json_logger_data_provider_contextual_segment_ids_len = 0;
		dp_params.json_logger_data_provider_brand_safety_segment_ids[0] = '\0';
		dp_params.json_logger_data_provider_brand_safety_segment_ids_len = 0;
		dp_params.dp_resp_params = dp_resp_params;
		dp_params.cache = cache_handle;
		dp_params.dbconn = dbconn;

		ret_val = dp_confs[i].ops->initialize(&dp_params);
		if (ret_val != 0)
		{
			//Initialization failed.
			free(cmpg_dp_settinngs->dp_settings[j]);
			cmpg_dp_settinngs->dp_settings[j] = NULL;
			continue;
		}
		ret_val = dp_confs[i].ops->get_post_data(&dp_params);
		if (ret_val != 0)
		{
			//Failed to get POST data.
			free(cmpg_dp_settinngs->dp_settings[j]);
			cmpg_dp_settinngs->dp_settings[j] = NULL;
			continue;
		}
#ifdef DEBUG
		/*if (cmpg_dp_data->dp_data[j] != NULL)
		{
			llog_write(L_DEBUG, "%s(): j = %d\n%s\n%s\n",
						__FUNCTION__,
						j,
						cmpg_dp_data->dp_data[j]->json_contextual_data,
						cmpg_dp_data->dp_data[j]->json_brand_safety_data);
		}*/
#endif //DEBUG
		//Copy Array Contextual Segment Ids in JSON form provided  Data-Provider that needs to be logged.
		if (dp_params.json_logger_data_provider_contextual_segment_ids_len > 0)
		{
			if (cmpg_dp_logger_data->json_data_provider_contextual_segment_ids_len > 1)
			{
				snprintf(json_data_provider_segment_ids,
						MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + MAX_JSON_DATA_PROVIDER_SEGMENT_IDS + 3,
						"%s,%s",
						cmpg_dp_logger_data->json_data_provider_contextual_segment_ids,
						dp_params.json_logger_data_provider_contextual_segment_ids);
			}
			else
			{
				snprintf(json_data_provider_segment_ids,
						MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + MAX_JSON_DATA_PROVIDER_SEGMENT_IDS + 2,
						"%s%s",
						cmpg_dp_logger_data->json_data_provider_contextual_segment_ids,
						dp_params.json_logger_data_provider_contextual_segment_ids);
			}
			json_data_provider_segment_ids[MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + MAX_JSON_DATA_PROVIDER_SEGMENT_IDS] = '\0';
			strcpy(cmpg_dp_logger_data->json_data_provider_contextual_segment_ids, json_data_provider_segment_ids);
			cmpg_dp_logger_data->json_data_provider_contextual_segment_ids_len = strlen(cmpg_dp_logger_data->json_data_provider_contextual_segment_ids);
		}

		//Copy Array Brand Safety Segment Ids in JSON form provided  Data-Provider that needs to be logged.
		if (dp_params.json_logger_data_provider_brand_safety_segment_ids_len > 0)
		{
			if (cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids_len > 1)
			{
				snprintf(json_data_provider_segment_ids,
						MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + MAX_JSON_DATA_PROVIDER_SEGMENT_IDS + 3,
						"%s,%s",
						cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids,
						dp_params.json_logger_data_provider_brand_safety_segment_ids);
			}
			else
			{
				snprintf(json_data_provider_segment_ids,
						MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + MAX_JSON_DATA_PROVIDER_SEGMENT_IDS + 2,
						"%s%s",
						cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids,
						dp_params.json_logger_data_provider_brand_safety_segment_ids);
			}
			json_data_provider_segment_ids[MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + MAX_JSON_DATA_PROVIDER_SEGMENT_IDS] = '\0';
			strcpy(cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids, json_data_provider_segment_ids);
			cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids_len = strlen(cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids);
		}

		j++;
	}
	cmpg_dp_settinngs->dp_settings_count = j;
	cmpg_dp_data->dp_data_count = j;
	snprintf(json_data_provider_segment_ids,
			MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + 2,
			"%s]",
			cmpg_dp_logger_data->json_data_provider_contextual_segment_ids);
	json_data_provider_segment_ids[MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS] = '\0';
	strcpy(cmpg_dp_logger_data->json_data_provider_contextual_segment_ids, json_data_provider_segment_ids);
	cmpg_dp_logger_data->json_data_provider_contextual_segment_ids_len = strlen(cmpg_dp_logger_data->json_data_provider_contextual_segment_ids);
	snprintf(json_data_provider_segment_ids,
			MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + 2,
			"%s]",
			cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids);
	json_data_provider_segment_ids[MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS] = '\0';
	strcpy(cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids, json_data_provider_segment_ids);
	cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids_len = strlen(cmpg_dp_logger_data->json_data_provider_brand_safety_segment_ids);

	return 0;
}

//Get Data from Data-Provider(s) thats need to be logged.
//Returns: On success 0 & on failure 1.
int get_data_provider_logger_data(char json_data_provider_logger_data[MAX_JSON_DATA_PROVIDER_DATA + 1],
								struct rt_request_params *rt_request_params)
{
	int i = 0;
	int ret_val = 0;
	int json_data_provider_data_len;
	data_provider_logger_data_params_t params;
	char json_data_provider_data[MAX_JSON_DATA_PROVIDER_DATA + MAX_JSON_DATA_PROVIDER_DATA + 5];

	//Sanity checks.
	if (json_data_provider_logger_data == NULL ||
		rt_request_params == NULL ||
		rt_request_params->fte_additional_params == NULL ||
		rt_request_params->fte_additional_params->dp_resp_params == NULL)
	{
		return 1;
	}

	strcpy(json_data_provider_logger_data, "[");
	json_data_provider_data_len = 1;
	for (i = 0; i < MAX_DATA_PROVIDERS; i++)
	{
		//Initialize Data-Provider params.
		params.json_data_provider_data[0] = '\0';
		params.json_data_provider_data_len = 0;
		params.dp_resp_params = rt_request_params->fte_additional_params->dp_resp_params;

		ret_val = dp_confs[i].ops->get_logger_data(&params);
#ifdef DEBUG
		/*llog_write(L_DEBUG, "%s(): initialize ret = %d data= %s %d\n",
						__FUNCTION__, ret_val, params.json_data_provider_data, params.json_data_provider_data_len);*/
#endif //DEBUG
		if (ret_val != 0)
		{
			//Initialization failed.
			/*llog_write(L_DEBUG, "%s(): get_logger_data failed. ret = %d.\n",
						__FUNCTION__, ret_val);*/
			continue;
		}

		params.json_data_provider_data[params.json_data_provider_data_len] = '\0';
		//Copy data provided by Data-Provider that needs to be logged.
		if (params.json_data_provider_data_len > 0 &&
			(json_data_provider_data_len + params.json_data_provider_data_len) < MAX_JSON_DATA_PROVIDER_DATA)
		{
			if (json_data_provider_data_len > 1)
			{
				snprintf(json_data_provider_data,
						MAX_JSON_DATA_PROVIDER_DATA + MAX_JSON_DATA_PROVIDER_DATA + 3,
						"%s,%s",
						json_data_provider_logger_data,
						params.json_data_provider_data);
			}
			else
			{
				snprintf(json_data_provider_data,
						MAX_JSON_DATA_PROVIDER_DATA + MAX_JSON_DATA_PROVIDER_DATA + 2,
						"%s%s",
						json_data_provider_logger_data,
						params.json_data_provider_data);
			}
			json_data_provider_data[MAX_JSON_DATA_PROVIDER_DATA + MAX_JSON_DATA_PROVIDER_DATA] = '\0';
			json_data_provider_data_len = strlen(json_data_provider_data);
			strcpy(json_data_provider_logger_data, json_data_provider_data);
		}
	}
	snprintf(json_data_provider_data,
			MAX_JSON_DATA_PROVIDER_DATA + 2,
			"%s]",
			json_data_provider_logger_data);
	json_data_provider_data[MAX_JSON_DATA_PROVIDER_DATA + 1] = '\0';
	strcpy(json_data_provider_logger_data, json_data_provider_data);

	return 0;
}

void cleanup_campaign_data_provider_data(
								long campaign_id,
								campaign_data_provider_data_ops_params_t *params,
								struct rt_request_params *rt_request_params)
{
	int i = 0;
	/* Campaign level settings. */
	campaign_level_dp_settings_t *cmpg_dp_settinngs;
	/* Data provided by Data-Provider(s) for given Campaign. */
	campaign_data_provider_data_t *cmpg_dp_data;
	dp_data_passing_params_t dp_params;

	//Sanity checks
	if (rt_request_params == NULL ||
		params == NULL ||
		rt_request_params->fte_additional_params == NULL)
	{
		return;
	}

	cmpg_dp_settinngs = &params->cmpg_dp_settinngs;
	cmpg_dp_data = &params->cmpg_dp_data;
	for (i = 0; i < cmpg_dp_settinngs->dp_settings_count; i++)
	{
		if (cmpg_dp_settinngs->dp_settings[i] == NULL)
		{
			continue;
		}

		//Initialize Data-Provider params.
		dp_params.campaign_id = campaign_id;
		dp_params.dp_settings = cmpg_dp_settinngs->dp_settings[i];
		dp_params.dp_data = &cmpg_dp_data->dp_data[i];

		dp_confs[i].ops->cleanup(&dp_params);
		free(cmpg_dp_settinngs->dp_settings[i]);
		cmpg_dp_settinngs->dp_settings[i] = NULL;
	}
	cmpg_dp_settinngs->dp_settings_count = 0;
	cmpg_dp_data->dp_data_count = 0;
}

