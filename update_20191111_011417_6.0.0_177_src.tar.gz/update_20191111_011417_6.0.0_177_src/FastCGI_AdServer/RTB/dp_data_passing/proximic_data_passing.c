/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include "error.h"
#include "proximic_data_passing.h"
#include "dp_properties.h"

int initialize_proximic_data_passing(dp_data_passing_params_t *params);
int get_proximic_post_data(dp_data_passing_params_t *params);
int get_proximic_logger_data(data_provider_logger_data_params_t *params);
int proximic_data_passing_cleanup(dp_data_passing_params_t *params);

dp_data_passing_ops_t g_proximic_data_passing_ops = {
	.initialize = initialize_proximic_data_passing,
	.get_post_data = get_proximic_post_data,
	.get_logger_data = get_proximic_logger_data,
	.cleanup = proximic_data_passing_cleanup
};

/*
 * Initialization related to Proximic Data-Provider.
 * Returns, On Success 0 & on Failure 1.
 */
int initialize_proximic_data_passing(dp_data_passing_params_t *params)
{
	int i = 0;
	campaign_data_provider_settings_t *dp_settings = NULL;

	//Sanity Checks.
	if (params == NULL ||
		params->dp_settings == NULL ||
		params->dp_data == NULL ||
		*(params->dp_data) != NULL ||
		params->cache == NULL ||
		params->dbconn == NULL)
	{
#ifdef DEBUG
		llog_write(L_DEBUG, "%s(): Invalid input argument.\n", __FUNCTION__);
#endif
		return 1;
	}

	dp_settings = params->dp_settings;
	for (i = 0; i < MAX_DATA_PROVIDER_SEGMENT_TYPE; i++)
	{
		dp_settings->cmpg_dp_seg_stype_settinngs[i] = NULL;
	}
	dp_settings->cmpg_dp_seg_stype_settinngs_count = 0;

	*(params->dp_data) = NULL;

	return 0;
}

/*
 * Get POST data from Proximic Data-Provider.
 * Returns, On Success 0 & on Failure 1.
 */
int get_proximic_post_data(dp_data_passing_params_t *params)
{
	int i = 0;// j = 0;
	campaign_data_provider_settings_t *dp_settings = NULL;
	dp_response_params_t *dp_resp_params = NULL;
	memcache_cmpg_dp_data_passing_settings_t *cmpg_dp_settings = NULL;
	int ret_val = 0;

	//Sanity Checks.
	if (params == NULL ||
		params->dp_settings == NULL ||
		params->dp_data == NULL ||
		*(params->dp_data) != NULL ||
		params->dp_resp_params == NULL ||
		params->cache == NULL ||
		params->dbconn == NULL)
	{
#ifdef DEBUG
		llog_write(L_DEBUG, "%s(): Invalid input argument.\n", __FUNCTION__);
#endif
		return 1;
	}

	dp_settings = params->dp_settings;
	dp_resp_params = (dp_response_params_t *) params->dp_resp_params;

	cmpg_dp_settings = NULL;
	ret_val = cache_get_cmpg_data_provider_segment_type_settings(
					params->campaign_id,
					DATA_PROVIDER_PROXIMIC_ID,
					&cmpg_dp_settings,
					params->cache,
					params->dbconn);
	if (ret_val != ADS_ERROR_SUCCESS)
	{
		llog_write(L_DEBUG, "%s(): Failed to get Segment type : %d settings from Cache/DB.\n",
						__FUNCTION__,
						i);
		proximic_data_passing_cleanup(params);
		return 1;
	}
	if (cmpg_dp_settings != NULL)
	{
#ifdef DEBUG
		/*llog_write(L_DEBUG, "%s()DP : %d\n",
						__FUNCTION__,
						DATA_PROVIDER_PROXIMIC_ID);
		for (i = 0; i < cmpg_dp_settings->dp_settings_count; i++)
		{
			llog_write(L_DEBUG, "segment_type_id %d segment_id %d\n",
							cmpg_dp_settings->dp_settings[i].segment_type_id,
							cmpg_dp_settings->dp_settings[i].segment_id);
		}
		llog_write(L_DEBUG, "%s() END\n", __FUNCTION__);*/
#endif //DEBUG
		//Get All segment type settings for given Campaign.
		ret_val = get_seg_type_settings_from_cached_dp_setting(
						params->campaign_id,
						DATA_PROVIDER_PROXIMIC_ID,
						dp_settings,
						cmpg_dp_settings);
		if (ret_val != 0)
		{
			llog_write(L_DEBUG, "%s(): Failed to get all segment type settings from memcached settings.",
							__FUNCTION__);
			free(cmpg_dp_settings);
			cmpg_dp_settings = NULL;
			proximic_data_passing_cleanup(params);
			return 1;
		}
		free(cmpg_dp_settings);
		cmpg_dp_settings = NULL;
#ifdef DEBUG
		/*for (i = 0; i < dp_settings->cmpg_dp_seg_stype_settinngs_count; i++)
		{
			dump_cmpg_dp_seg_type_settings(dp_settings->cmpg_dp_seg_stype_settinngs[i]);
		}*/
#endif //DEBUG

		//Get POST data from Proximic.
		ret_val = dp_generic_data_creator(
									params,
									dp_resp_params);
#ifdef DEBUG
		/*llog_write(L_DEBUG, "%s(): dp data creator Ret = %d\n",
						__FUNCTION__,
						ret_val);*/
#endif //DEBUG
		if (ret_val != ADS_ERROR_SUCCESS)
		{
			//Failed to get data from Proximic.
			proximic_data_passing_cleanup(params);
			return 1;
		}

		return 0;
	}

	return 1;
}

//Returns, On success 0 & On failure 1.
int get_proximic_logger_data(data_provider_logger_data_params_t *params)
{
	int ret;

	if (params == NULL)
	{
		return 1;
	}

	ret = dp_get_dpid_response(DATA_PROVIDER_PROXIMIC_ID, params);
	if (ret != ADS_ERROR_SUCCESS)
	{
#ifdef DEBUG
		llog_write(L_DEBUG, "%s(): Not able to get Data-Provider logger data.\n",
						__FUNCTION__);
#endif
		return 1;
	}

	return 0;
}

//Returns, On success 0 & On failure 1.
int proximic_data_passing_cleanup(dp_data_passing_params_t *params)
{
	int i;
	campaign_data_provider_settings_t *dp_settings = NULL;
	/* Data provided by various Data-Provider. */
	data_provider_data_t *dp_data;

	//Sanity Checks.
	if (params == NULL ||
		params->dp_settings == NULL ||
		params->dp_data == NULL)
	{
#ifdef DEBUG
		llog_write(L_DEBUG, "%s(): Invalid input argument.\n", __FUNCTION__);
#endif
		return 1;
	}

	dp_settings = params->dp_settings;
	for (i = 0; i < dp_settings->cmpg_dp_seg_stype_settinngs_count; i++)
	{
		if (dp_settings->cmpg_dp_seg_stype_settinngs[i] != NULL)
		{
			/*llog_write(L_DEBUG, "%s(): Freeing cmpg_dp_seg_stype_settinngs[%d]\n",
							__FUNCTION__,
							i);*/
			free(dp_settings->cmpg_dp_seg_stype_settinngs[i]);
			dp_settings->cmpg_dp_seg_stype_settinngs[i] = NULL;
		}
	}
	dp_settings->cmpg_dp_seg_stype_settinngs_count = 0;

	//Cleanup regarding Data received from Prximic.
	dp_data = *(params->dp_data);
	if (dp_data != NULL)
	{
		/* Contextual data provided by Data-Provider in JSON form. */
		if (dp_data->json_contextual_data != NULL)
		{
			free(dp_data->json_contextual_data);
		}
		dp_data->json_contextual_data = NULL;
		dp_data->json_contextual_data_len = 0;
		/* Brand Safety data provided by Data-Provider in JSON form. */
		if (dp_data->json_brand_safety_data != NULL)
		{
			free(dp_data->json_brand_safety_data);
		}
		dp_data->json_brand_safety_data = NULL;
		dp_data->json_brand_safety_data_len = 0;
		/* Data which is in JSON form thats need to be logged. */
		if (dp_data->json_logger_data != NULL)
		{
			free(dp_data->json_logger_data);
		}
		dp_data->json_logger_data = NULL;
		dp_data->json_logger_data_len = 0;

		free(dp_data);
		*(params->dp_data) = NULL;
	}

	return 0;
}

