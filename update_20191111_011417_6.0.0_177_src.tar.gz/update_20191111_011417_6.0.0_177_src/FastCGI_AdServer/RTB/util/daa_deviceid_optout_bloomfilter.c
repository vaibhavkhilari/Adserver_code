/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include <rt_types.h>
#include "bloom_filter.h"
#include "daa_deviceid_optout_bloomfilter.h"
#include "cache_get_bloom_filters.h"
#include "rtb_brand_control_util.h"
#include "default_adapter.h"

int check_daa_deviceid_optout_bloom_filter(char** deviceid,
															int deviceid_count,
															int hashing_used,
															cache_handle_t* cache_handle, 
															db_connection_t* dbconn) {
	int retval = 0, i, j;
	MULTI_BLOOM daa_optout_bloom;
	memset(&daa_optout_bloom, 0, sizeof(MULTI_BLOOM));
	char processing_string[MAX_DAA_OPTOUT_DEVICEID_LEN + 1];
	
	processing_string[0]='\0';
	//Get bloom for daa deviceid optout 
	retval = cache_get_bloom_filters(cache_handle,
			dbconn,
			DAA_DEVICEID_OPTOUT_KEY,
			GET_DAA_DEVICE_OPTOUT_BLOOM,
			&daa_optout_bloom,
			hashing_used,
			(long)0,
			-1);
	if(retval != ADS_ERROR_SUCCESS) {
		destroy_multi_bloom(&daa_optout_bloom);
		return retval;
	}

	for(i=0;i<deviceid_count;i++){
		snprintf(processing_string, MAX_DAA_OPTOUT_DEVICEID_LEN,"%s", deviceid[i]);
		processing_string[MAX_DAA_OPTOUT_DEVICEID_LEN] = '\0';
		lowercase_string(processing_string, 0, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

		if (daa_optout_bloom.bloom_filter_0[0]) {
			for(j=0; j<daa_optout_bloom.bloom_count_0 ; j++){
				if(bloom_check(daa_optout_bloom.bloom_filter_0[j], processing_string)) {
					llog_write(L_DEBUG,"\nDAA OPTOUT: found DeviceId[%s] in opted-out device list in bloom:%d\n", deviceid[i], j);
					destroy_multi_bloom(&daa_optout_bloom);
					return ADS_ERROR_SUCCESS;
				}
			}
		}
	}
	destroy_multi_bloom(&daa_optout_bloom);
	return -1;
}

void check_daa_deviceid_optout(ad_server_req_param_t *params, cache_handle_t* cache_handle, db_connection_t* dbconn, int *optout_flag) {
	int retval = 0;
	char hashed_deviceID[MAX_DAA_OPTOUT_DEVICEID_LEN];
	char *deviceIDs[2];
	deviceIDs[0] = params->device_id;
	switch(params->udid_hash){
		case UDID_HASH_FUNCTION_SHA1:
			retval = check_daa_deviceid_optout_bloom_filter(deviceIDs, 1, UDID_HASH_FUNCTION_SHA1, cache_handle, dbconn);
			if(retval == ADS_ERROR_SUCCESS) {
				*optout_flag = PUBMATIC_OPT_OUT_TRUE;
			}
			break;

		case UDID_HASH_FUNCTION_MD5:
			retval = check_daa_deviceid_optout_bloom_filter(deviceIDs, 1, UDID_HASH_FUNCTION_MD5, cache_handle, dbconn);
			if(retval == ADS_ERROR_SUCCESS) {
				*optout_flag = PUBMATIC_OPT_OUT_TRUE;
			}
			break;

		case UDID_HASH_FUNCTION_RAW:
			/* Check first with sha1 hashed device id */
			get_sha1_hash(hashed_deviceID, MAX_DAA_OPTOUT_DEVICEID_LEN, params->device_id);
			deviceIDs[0] = hashed_deviceID;
			retval = check_daa_deviceid_optout_bloom_filter(deviceIDs, 1, UDID_HASH_FUNCTION_SHA1, cache_handle, dbconn);
			if(retval == ADS_ERROR_SUCCESS) {
				*optout_flag = PUBMATIC_OPT_OUT_TRUE;
				break;
			}
			/* Check with md5 hashed device id */
			get_md5_hash(hashed_deviceID, MAX_DAA_OPTOUT_DEVICEID_LEN, params->device_id);
			deviceIDs[0] = hashed_deviceID;
			retval = check_daa_deviceid_optout_bloom_filter(deviceIDs, 1, UDID_HASH_FUNCTION_MD5, cache_handle, dbconn);
			if(retval == ADS_ERROR_SUCCESS) {
				*optout_flag = PUBMATIC_OPT_OUT_TRUE;
			}
			break;

		default:
			/* Check with sha1 hashed device id and received deviceid */
			get_sha1_hash(hashed_deviceID, MAX_DAA_OPTOUT_DEVICEID_LEN, params->device_id);
			deviceIDs[1] = hashed_deviceID;
			retval = check_daa_deviceid_optout_bloom_filter(deviceIDs, 2, UDID_HASH_FUNCTION_SHA1, cache_handle, dbconn);
			if(retval == ADS_ERROR_SUCCESS) {
				*optout_flag = PUBMATIC_OPT_OUT_TRUE;
				break;
			}
			/* Check with md5 hashed device id and received deviceid */
			get_md5_hash(hashed_deviceID, MAX_DAA_OPTOUT_DEVICEID_LEN, params->device_id);
			deviceIDs[1] = hashed_deviceID;
			retval = check_daa_deviceid_optout_bloom_filter(deviceIDs, 2, UDID_HASH_FUNCTION_MD5, cache_handle, dbconn);
			if(retval == ADS_ERROR_SUCCESS) {
				*optout_flag = PUBMATIC_OPT_OUT_TRUE;
			}
			break;
	}
}
