/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <apply_campaign_blocking_parameters.h>
#include <error.h>
#include <stdio.h>
#include <config.h>
#include <ad_server_types.h>
#include <campaign_site_blocking_params.h>
#include <stdlib.h>
#include <libstats_util.h>

/*****************************************************************************************
Date : 08-04-2010
Author : Ameya Agnihotri
Feature : RTB Campaign Blocking 

apply_campaign_blocking_parameters does the following

1. Query cache/db - Get the list of campaignid, blocking% in campaign_site_blocking_params_t list
2. Query cache and get campaign, randomization context list
3. iterate over the blocking params list and copy the context for that campaign
4. In case of new entry in DB, there wont be any context. Hence create new context in blocking params list
5. Iterate over adcampaigns list, get the context for that perticular campaign, generate the random number,
and based on it filter the campaign if applicable.
6. If there is new entry whose context was not obtained from DB/cache, we need to create new context list.
7. Populate new context list with campaign id, context and set it to memcache.
8. If all the contexts were found, then, populate the old context list with newly changed contexts from 
blocking params list. Set it memcache.
9. Free, the allocated memory.

*****************************************************************************************/
int apply_campaign_blocking_parameters(int threadid, publisher_site_ad_campaign_list_t *adcampaigns,int nelements, 
                                        long site_id,
                                        cache_handle_t *cache_handle,
                                        db_connection_t *dbconn,
				        				ad_server_additional_params_t *additional_parameters,
										fte_additional_params_t *fte_additional_parameters){

	int i=0,j=0;
	int retval = 0;
	int nretelements = 0;
	int nretcontextelements = 0;
	long random_num=0; 
	long mod_10000 = 0;
	int context_notfound_counter=0;

	
	campaign_site_blocking_params_t *campaign_site_blocking_params=NULL;//campaign, blocking % list
	campaign_site_blocking_context_t *campaign_site_blocking_context=NULL;//context 
	campaign_site_blocking_context_t *modified_campaign_site_blocking_context=NULL; //modified context

	// Sanity check
	if(adcampaigns == NULL || cache_handle == NULL || dbconn == NULL || site_id <=0){
		return ADS_ERROR_INVALID_ARGS;
	}

	//Get campaign , blocking % from cache/db for a given site id
	retval =  cache_get_campaign_site_blocking_params(threadid, &campaign_site_blocking_params,
							 site_id, cache_handle, dbconn,  &nretelements);

	//handle fail conditions
	if(retval != ADS_ERROR_SUCCESS || nretelements == 0)
	{
		if(campaign_site_blocking_params != NULL){
			free(campaign_site_blocking_params);
		}
		return ADS_ERROR_INTERNAL;
	}

	//handling of dummy conditions
	if(nretelements == 1 && campaign_site_blocking_params[0].campaign_id == 0){
		if(campaign_site_blocking_params != NULL){
			free(campaign_site_blocking_params);
		}

		return ADS_ERROR_SUCCESS;	
	}

	//Get context from memcache 
	retval = cache_get_campaign_site_context(threadid,  &campaign_site_blocking_context, 
        											site_id, cache_handle, &nretcontextelements);

	//Copy the context to site blocking params list. Mark found contexts
	if(campaign_site_blocking_context!=NULL && nretcontextelements > 0){
		for(i=0;i<nretelements;i++){
			for(j=0;j<nretcontextelements;j++){
				if(campaign_site_blocking_context[j].campaign_id == campaign_site_blocking_params[i].campaign_id){
					memcpy(&(campaign_site_blocking_params[i].rcampaign_blocking_context), &(campaign_site_blocking_context[j].rcampaign_blocking_context), sizeof(struct drand48_data));
					campaign_site_blocking_params[i].found_flag = 1;		
				}
			}
		}
	}

	//For newly added entry in DB, there will be not context. So initialize an assign new context
	//context_notfound_counter is a flag, based on which we determine if we need to ,
	//reallocate memory to accomodate new contexts
	for(i=0;i<nretelements;i++){
		llog_write(L_DEBUG, "\n Camp-site-blocking: CampId: %ld", campaign_site_blocking_params[i].campaign_id);
		if(campaign_site_blocking_params[i].found_flag == 0){
			srand48_r(threadid, &(campaign_site_blocking_params[i].rcampaign_blocking_context));
			context_notfound_counter++;	
		}
	}

	// Iterate over campaign list, generate new random number, based on it, filter/dont filter campaign
	for(i=0; i<nelements;i++){
		for(j=0; j<nretelements;j++){
			if(adcampaigns[i].ad_campaign_list_setings->filtered_flag == 1){
				continue;
			}
			if((int )adcampaigns[i].campaign_id == campaign_site_blocking_params[j].campaign_id){
				lrand48_r(&(campaign_site_blocking_params[j].rcampaign_blocking_context), &random_num);
				mod_10000 = random_num%RANDOM_NUMBER_UPPER_BOUND;		
				
				if(mod_10000 < (int )campaign_site_blocking_params[j].blocking_percentage*100){
					
					#ifdef DEBUG
					llog_write(L_DEBUG, "\n Campaign Blocked: CampId: %d SiteId: %ld", adcampaigns[i].campaign_id, site_id);
					#endif

					adcampaigns[i].ad_campaign_list_setings->filtered_flag = 1;
					
					if(additional_parameters->adserver_config_params->stats_collection_enable == 1){
                               			 increment_stats_counters(&(fte_additional_parameters->libstat_counters[0]), FILTERED_CAMPAIGN_ID, adcampaigns[i].campaign_id);
					}
				}
			}
		}
	}

	//We need to allocate more memory in order to accomodate new campaign contexts
	if(context_notfound_counter > 0 ){
		//allocate memory
		modified_campaign_site_blocking_context = (campaign_site_blocking_context_t *)malloc(sizeof(campaign_site_blocking_context_t)*(nretelements));
		if(modified_campaign_site_blocking_context != NULL){
			//copy the data
			for(i=0; i<nretelements; i++){
				modified_campaign_site_blocking_context[i].campaign_id = campaign_site_blocking_params[i].campaign_id;
				memcpy(&(modified_campaign_site_blocking_context[i].rcampaign_blocking_context), &(campaign_site_blocking_params[i].rcampaign_blocking_context), sizeof(struct drand48_data));
			}

			if(campaign_site_blocking_context!=NULL){
				free(campaign_site_blocking_context);
				campaign_site_blocking_context=NULL;
			}
			//set new context to memcache
			set_context_campaign_site_blocking_params(threadid, &modified_campaign_site_blocking_context,
                                               		nretelements, site_id, cache_handle);
			if(modified_campaign_site_blocking_context != NULL){
				free(modified_campaign_site_blocking_context);
				modified_campaign_site_blocking_context=NULL;
			}
		}
		else{
			llog_write(L_DEBUG, "\n Malloc failed :Function %s", __FUNCTION__);
        }
    }
	else{
		//copy updated contexts back to campaign_site_blocking_context, and set it to memcache.
		//as there are no new elements, no malloc needed.
		for(i=0; i<nretelements; i++){
                campaign_site_blocking_context[i].campaign_id = campaign_site_blocking_params[i].campaign_id;
                memcpy(&(campaign_site_blocking_context[i].rcampaign_blocking_context), &(campaign_site_blocking_params[i].rcampaign_blocking_context), sizeof(struct drand48_data));
            }
	
        	set_context_campaign_site_blocking_params(threadid, &campaign_site_blocking_context,
                                                    nretcontextelements, site_id, cache_handle);

			if(campaign_site_blocking_context != NULL){
				free(campaign_site_blocking_context);
				campaign_site_blocking_context = NULL;
			}
	}

	//free unused memory
	if(campaign_site_blocking_params != NULL){
			free(campaign_site_blocking_params);
			campaign_site_blocking_params=NULL;
	}

	return ADS_ERROR_SUCCESS;
}


