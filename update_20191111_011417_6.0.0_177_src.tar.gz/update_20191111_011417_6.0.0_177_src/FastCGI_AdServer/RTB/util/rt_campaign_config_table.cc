#include "rt_campaign_config_table.h"

bool RtCampaignConfigTable::isTableModified(const db_connection_t * const dbconn)
{
        uint32_t last_updated = 0U;

        int rv = get_rt_campaign_config_modification_time(&last_updated, dbconn);
        if (rv != DB_ERROR_SUCCESS) {
                fprintf(stderr, "ERROR: reading modification time of DB tables  %s:%d\n", __FILE__, __LINE__);
                return false;
        }

        if (last_updated > modification_timestamp_) {
                modification_timestamp_ = last_updated;
                return true;
        }
        return false;
}

int RtCampaignConfigTable::Update(const db_connection_t * const dbconn)
{
        int rv = 0;
	int is_first_pass = 0;

        int8_t inuse = idx_inuse_.load();

	if (inuse != 0 && inuse !=1){
		inuse = 0;
		is_first_pass = 1;
	}
	int8_t not_inuse = (inuse == 0) ? 1 : 0;

	rt_request_url_params_mask_t * tmp = NULL;
	rv = get_rt_campaign_config(&tmp, dbconn, &list_size_[not_inuse]);
	if (rv != DB_ERROR_SUCCESS) {
		return rv;
	}
	if (is_first_pass != 1){
		free(table_[not_inuse]);
	}
	table_[not_inuse] = tmp;
	idx_inuse_.store(not_inuse);
	return DB_ERROR_SUCCESS;
}

int RtCampaignConfigTable::Get(
        const rt_request_url_params_mask_t ** rt_request_url_params_mask,
        int * ret_list_len
) {
        int8_t inuse = idx_inuse_.load();
        if (inuse != 0 && inuse != 1) {
                fprintf(stderr, "Global Campaign Config Table not filled.  Perhaps query failed.  %s:%d\n", __FILE__, __LINE__);
                return ADS_ERROR_INVALID_ARGS;
        }
        *rt_request_url_params_mask = table_[inuse];
        *ret_list_len = list_size_[inuse];
        return ADS_ERROR_SUCCESS;
}

void RtCampaignConfigTable::PrintTable(void) {
        fprintf(stderr, "RtCampaignConfigTable: idx_inuse = %d\n",
                        idx_inuse_.load());
        print_rt_request_url_params_mask(table_[0], list_size_[0]);
        print_rt_request_url_params_mask(table_[1], list_size_[1]);
}
