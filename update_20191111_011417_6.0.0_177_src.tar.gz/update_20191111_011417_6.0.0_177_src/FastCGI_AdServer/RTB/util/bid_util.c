/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2019 PubMatic, All Rights Reserved.

 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current
PubMatic employees, managers or contractors who have executed
 Confidentiality and Non-disclosure agreements explicitly covering such access.

 The copyright notice above does not evidence any actual or intended publication or disclosure of this source
code, which includes
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION,
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE,
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION
DOES NOT CONVEY OR IMPLY ANY RIGHTS
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY
DESCRIBE, IN WHOLE OR IN PART.
 */

#include <ctype.h>
#include <stdlib.h>
#include "bid_util.h"
#include "rtb_json_util.h"
#include "error.h"
#include "string_util.h"

/* Parse bapp parameter in Ad Request
   Note: url_param and bapp_info should point to valid memory areas.
*/
int parse_bapp_param(const char * const url_param,
					 bapp_info_t * const bapp_info)
{
	int rc = ADS_ERROR_SUCCESS;
	int app_id_count = 0;
	char decoded_url_bapp[MAX_BLOCKED_APP_IDS_OUTPUT_JSON_LEN + 1];
	decode_url(url_param, decoded_url_bapp, MAX_BLOCKED_APP_IDS_OUTPUT_JSON_LEN);
	if(ADS_ERROR_SUCCESS == parse_comma_seperated_strings_to_string_array(decoded_url_bapp,
																		  MAX_BLOCK_APP_IDS,
																		  MAX_APP_ID_LEN,
																		  bapp_info->app_ids,
																		  &app_id_count)) {
		bapp_info->app_id_count = app_id_count;
	}
	else {
		DEBUG_LOG("parse_comma_seperated_strings_to_string_array() failed for bapp");
		rc = ADS_ERROR_INTERNAL;
	}
	return rc;
}

/* Generate BidRequest.bapp JSON string array from already parsed bapp parameter received in Ad Request */
int form_bapp_json_str(bapp_info_t * const bapp_info)
{
	int bapp_egress_json_len = 0;
	int rc = ADS_ERROR_SUCCESS;
	if (ADS_ERROR_SUCCESS == form_json_string_array_from_string_array(MAX_APP_ID_LEN,
																	  bapp_info->app_ids,
																	  bapp_info->app_id_count,
																	  bapp_info->bapp_egress_json,
																	  MAX_BLOCKED_APP_IDS_OUTPUT_JSON_LEN + 1,
																	  &bapp_egress_json_len)) {
		bapp_info->bapp_egress_json_len = bapp_egress_json_len;
	}
	else {
		DEBUG_LOG("form_json_string_array_from_string_array() failed for bapp");
		rc = ADS_ERROR_INTERNAL;
	}
	return rc;
}

void init_bapp_info(bapp_info_t * const bapp_info)
{
	int i;
	bapp_info->app_id_count = 0;
	bapp_info->bapp_egress_json_len = 0;
	bapp_info->bapp_egress_json[0] = '\0';
	for(i=0; i<MAX_BLOCK_APP_IDS; i++) {
		bapp_info->app_ids[i][0] = '\0';
	}
}

#ifdef DEBUG
void print_bapp_info(const bapp_info_t * const bapp_info)
{
	int i = 0;
	DEBUG_LOG("bapp_info->app_id_count = %d\n",
			  bapp_info->app_id_count);

	for(i=0; i<bapp_info->app_id_count; i++) {
		DEBUG_LOG("bapp_info->app_ids[%d] = %s\n",
				  i,
				  bapp_info->app_ids[i]);
	}

	DEBUG_LOG("bapp_info->bapp_egress_json_len = %d\n",
			  bapp_info->bapp_egress_json_len);

	if(bapp_info->bapp_egress_json_len > 0) {
		DEBUG_LOG("bapp_info->bapp_egress_json = %s\n",
				  bapp_info->bapp_egress_json);
	}
}
#endif /* DEBUG */

#define MAX_IAB_CATEG_PRIMARY 26
#define MAX_IAB_CATEGORY_SECONDARY01 7
#define MAX_IAB_CATEGORY_SECONDARY02 23
#define MAX_IAB_CATEGORY_SECONDARY03 12
#define MAX_IAB_CATEGORY_SECONDARY04 11
#define MAX_IAB_CATEGORY_SECONDARY05 15
#define MAX_IAB_CATEGORY_SECONDARY06 9
#define MAX_IAB_CATEGORY_SECONDARY07 45
#define MAX_IAB_CATEGORY_SECONDARY08 18
#define MAX_IAB_CATEGORY_SECONDARY09 31
#define MAX_IAB_CATEGORY_SECONDARY10 9
#define MAX_IAB_CATEGORY_SECONDARY11 5
#define MAX_IAB_CATEGORY_SECONDARY12 3
#define MAX_IAB_CATEGORY_SECONDARY13 12
#define MAX_IAB_CATEGORY_SECONDARY14 8
#define MAX_IAB_CATEGORY_SECONDARY15 10
#define MAX_IAB_CATEGORY_SECONDARY16 7
#define MAX_IAB_CATEGORY_SECONDARY17 44
#define MAX_IAB_CATEGORY_SECONDARY18 6
#define MAX_IAB_CATEGORY_SECONDARY19 36
#define MAX_IAB_CATEGORY_SECONDARY20 27
#define MAX_IAB_CATEGORY_SECONDARY21 3
#define MAX_IAB_CATEGORY_SECONDARY22 4
#define MAX_IAB_CATEGORY_SECONDARY23 10
#define MAX_IAB_CATEGORY_SECONDARY24 0
#define MAX_IAB_CATEGORY_SECONDARY25 7
#define MAX_IAB_CATEGORY_SECONDARY26 4

static const int iab_cat_max_primary = MAX_IAB_CATEG_PRIMARY;
static const int iab_cat_max_secondary[MAX_IAB_CATEG_PRIMARY] =
	{
		MAX_IAB_CATEGORY_SECONDARY01,
		MAX_IAB_CATEGORY_SECONDARY02,
		MAX_IAB_CATEGORY_SECONDARY03,
		MAX_IAB_CATEGORY_SECONDARY04,
		MAX_IAB_CATEGORY_SECONDARY05,
		MAX_IAB_CATEGORY_SECONDARY06,
		MAX_IAB_CATEGORY_SECONDARY07,
		MAX_IAB_CATEGORY_SECONDARY08,
		MAX_IAB_CATEGORY_SECONDARY09,
		MAX_IAB_CATEGORY_SECONDARY10,
		MAX_IAB_CATEGORY_SECONDARY11,
		MAX_IAB_CATEGORY_SECONDARY12,
		MAX_IAB_CATEGORY_SECONDARY13,
		MAX_IAB_CATEGORY_SECONDARY14,
		MAX_IAB_CATEGORY_SECONDARY15,
		MAX_IAB_CATEGORY_SECONDARY16,
		MAX_IAB_CATEGORY_SECONDARY17,
		MAX_IAB_CATEGORY_SECONDARY18,
		MAX_IAB_CATEGORY_SECONDARY19,
		MAX_IAB_CATEGORY_SECONDARY20,
		MAX_IAB_CATEGORY_SECONDARY21,
		MAX_IAB_CATEGORY_SECONDARY22,
		MAX_IAB_CATEGORY_SECONDARY23,
		MAX_IAB_CATEGORY_SECONDARY24,
		MAX_IAB_CATEGORY_SECONDARY25,
		MAX_IAB_CATEGORY_SECONDARY26,
	};

int validate_iab_category(const char * const iab_cat_str)
{
	if(iab_cat_str == NULL) return 0;
	const unsigned char *p = (const unsigned char *)iab_cat_str; /* typecasting is required for isdigit() */
	const char *pri = NULL, *sec = NULL;
	int idx = 0;
	char primary[3] = "", secondary[3] = "";
	int primary_cat = 0, secondary_cat = 0 ;

	if(!(*p++ == 'I')) return 0; /* I */
	if(!(*p++ == 'A')) return 0; /* IA */
	if(!(*p++ == 'B')) return 0; /* IAB */

	/* primary category */
	pri = (const char *)p;
	if( !(isdigit(*p++)) ) return 0; /* IAB1 */
	if('\0' == *p) goto valid; /* valid if IAB1\0 , no secondary category */
	else if(*p != '-') { /* IAB1? */
		if( !(isdigit(*p++)) ) return 0; /* IAB11 */
		if('\0' == *p) goto valid; /* valid if IAB11\0 */
		else if(!(*p == '-')) return 0; /* IAB11- */
	}
	p++; /* current char is '-', so increment */

	/* secondary category */
	sec = (const char *)p;
	if( !(isdigit(*p++)) ) return 0; /* IAB1-1, IAB11-1 */
	if('\0' == *p) goto valid; /* valid if IAB1-1\0, IAB11-1\0 */
	else if( !(isdigit(*p++)) ) return 0; /* IAB1-11, IAB11-11 */
	if('\0' == *p) goto valid; /* valid if IAB1-11\0, IAB11-11\0 */
	return 0;

 valid:
	/* pattern is valid (IAB[0-9]{1,2} | IAB[0-9]{1,2}-[0-9]{1,2}), now check the actual limits as per spec */
	idx = 0;
	while(*pri != '\0' && *pri != '-') {
		primary[idx++] = *pri++;
	}
	primary[idx] = '\0';
	primary_cat = atoi(primary);
	//printf("pri=%d\n",primary_cat);
	if(!(primary_cat >= 1 && primary_cat <= iab_cat_max_primary)) {
		return 0; /* primary category not within range as per Spec */
	}


	if(NULL != sec) {
		idx = 0;
		while(*sec != '\0') {
			secondary[idx++] = *sec++;
		}
		secondary[idx] = '\0';
		secondary_cat = atoi(secondary);
		//printf("sec=%d\n",secondary_cat);
		if(!(secondary_cat >= 1 && secondary_cat <= iab_cat_max_secondary[primary_cat-1])) {
			return 0; /* secondary category not within range as per Spec */
		}
	}
	return 1;
}
