#include "rtb_util.h"
#include "native_resp_handler.h"

json_object *get_json_child_from_parent(json_object *parent_json_object, const char *key, json_type child_json_type);

void get_native_resp_params(json_object *native_obj, rt_bid_response_params_t *bid_response_params) {
        json_object *title_object = NULL;
        json_object *text_object = NULL;
        json_object *icon_img_object = NULL;
        json_object *main_img_object = NULL;
        json_object *click_object = NULL;
        json_object *imp_tracker_object = NULL;
        json_object *click_tracker_object = NULL;
        json_object *ctatext_object = NULL;
        json_object *rating_object = NULL;

        int loop_cnt = 0;
        int url_found = 0;
        json_object *imp_tracker_str = NULL;
        json_object *clk_tracker_str = NULL;
        char *imp_tracker_ptr = NULL;
        char *clk_tracker_ptr = NULL;
        int imp_tracker_len = 0;
        int clk_tracker_len = 0;
        int imp_tracker_arr_len = 0;
        int clk_tracker_arr_len = 0;

#ifdef NATIVE_DEBUG
        llog_write(L_DEBUG, "\nParsing The Native object in Bid response..\n");
#endif

        title_object = get_json_child_from_parent(native_obj, NATIVE_RESP_TITLE, json_type_string);
        if ( title_object != NULL ) {
                nstrcpy(bid_response_params->native_resp_params.title, title_object->o.c_string, MAX_NTV_TITLE_LEN);
                bid_response_params->native_resp_params.title[MAX_NTV_TITLE_LEN] = '\0';
        }

        text_object = get_json_child_from_parent(native_obj, NATIVE_RESP_TEXT, json_type_string);
        if ( text_object != NULL ) {
                nstrcpy(bid_response_params->native_resp_params.text, text_object->o.c_string, MAX_NTV_TEXT_LEN);
                bid_response_params->native_resp_params.text[MAX_NTV_TEXT_LEN] = '\0';
        }

        icon_img_object = get_json_child_from_parent(native_obj, NATIVE_RESP_ICON_IMG, json_type_string);
        if ( icon_img_object != NULL ) {
                nstrcpy(bid_response_params->native_resp_params.iconImg, icon_img_object->o.c_string, MAX_NTV_ICON_IMAGE_LEN);
                bid_response_params->native_resp_params.iconImg[MAX_NTV_ICON_IMAGE_LEN] = '\0';
        }

        main_img_object = get_json_child_from_parent(native_obj, NATIVE_RESP_MAIN_IMG, json_type_string);
        if ( main_img_object != NULL ) {
                nstrcpy(bid_response_params->native_resp_params.mainImg, main_img_object->o.c_string, MAX_NTV_MAIN_IMAGE_LEN);
                bid_response_params->native_resp_params.mainImg[MAX_NTV_MAIN_IMAGE_LEN] = '\0';
        }

        click_object = get_json_child_from_parent(native_obj, NATIVE_RESP_CLICK, json_type_string);
        if ( click_object != NULL ) {
                nstrcpy(bid_response_params->native_resp_params.clickUrl, click_object->o.c_string, MAX_NTV_CLICK_LEN);
                bid_response_params->native_resp_params.clickUrl[MAX_NTV_CLICK_LEN] = '\0';
        }

        imp_tracker_object = get_json_child_from_parent(native_obj, NATIVE_RESP_IMP_TRACKER, json_type_array);
        if ( imp_tracker_object != NULL ) {

                imp_tracker_arr_len = json_object_array_length(imp_tracker_object);
                if (imp_tracker_arr_len >= 1) {
                        imp_tracker_ptr = bid_response_params->native_resp_params.impTracker;
                        imp_tracker_len += snprintf(imp_tracker_ptr, MAX_NTV_IMP_TRACK_LEN - imp_tracker_len, "[\"");
                        imp_tracker_ptr = bid_response_params->native_resp_params.impTracker + imp_tracker_len;

                        for(loop_cnt = 0; loop_cnt < imp_tracker_arr_len; loop_cnt++) {
                                imp_tracker_str = json_object_array_get_idx(imp_tracker_object, loop_cnt);
                                if ( imp_tracker_str ) {
                                        imp_tracker_len += snprintf(imp_tracker_ptr, MAX_NTV_IMP_TRACK_LEN - imp_tracker_len, "%s\",\"", imp_tracker_str->o.c_string);
                                        imp_tracker_ptr = bid_response_params->native_resp_params.impTracker + imp_tracker_len;
                                        url_found = 1;
                                }
                        }
                        if (url_found) {
                                imp_tracker_ptr -= 3;
                                imp_tracker_len -= 3;
                                imp_tracker_len += snprintf(imp_tracker_ptr, MAX_NTV_IMP_TRACK_LEN - imp_tracker_len, "\"]");
                                imp_tracker_ptr = bid_response_params->native_resp_params.impTracker + imp_tracker_len;
                                bid_response_params->native_resp_params.impTracker[MAX_NTV_IMP_TRACK_LEN] = '\0';
                        } else {
                                bid_response_params->native_resp_params.impTracker[0] = '\0';
                        }
                }
        }

        loop_cnt = 0;
        url_found = 0;

        click_tracker_object = get_json_child_from_parent(native_obj, NATIVE_RESP_CLICK_TRACKER, json_type_array);
        if ( click_tracker_object != NULL ) {

                clk_tracker_arr_len = json_object_array_length(click_tracker_object);
                if (clk_tracker_arr_len >= 1) {

                        clk_tracker_ptr = bid_response_params->native_resp_params.clickTracker;
                        clk_tracker_len += snprintf(clk_tracker_ptr, MAX_NTV_CLICK_TRACK_LEN - clk_tracker_len, "[\"");
                        clk_tracker_ptr = bid_response_params->native_resp_params.clickTracker + clk_tracker_len;

                        for(loop_cnt = 0; loop_cnt < clk_tracker_arr_len; loop_cnt++) {
                                clk_tracker_str = json_object_array_get_idx(click_tracker_object, loop_cnt);
                                if ( clk_tracker_str ) {
                                        clk_tracker_len += snprintf(clk_tracker_ptr, MAX_NTV_CLICK_TRACK_LEN - clk_tracker_len, "%s\",\"", clk_tracker_str->o.c_string);
                                        clk_tracker_ptr = bid_response_params->native_resp_params.clickTracker + clk_tracker_len;
                                        url_found = 1;
                                }
                        }
                        if (url_found) {
                                clk_tracker_ptr -= 3;
                                clk_tracker_len -= 3;
                                clk_tracker_len += snprintf(clk_tracker_ptr, MAX_NTV_CLICK_TRACK_LEN - clk_tracker_len, "\"]");
                                clk_tracker_ptr = bid_response_params->native_resp_params.clickTracker + clk_tracker_len;
                                bid_response_params->native_resp_params.clickTracker[MAX_NTV_CLICK_TRACK_LEN] = '\0';
                        } else {
                                bid_response_params->native_resp_params.clickTracker[0] = '\0';
                        }
                }
        }

        ctatext_object = get_json_child_from_parent(native_obj, NATIVE_RESP_CTATEXT, json_type_string);
        if ( ctatext_object != NULL ) {
                nstrcpy(bid_response_params->native_resp_params.ctatext, ctatext_object->o.c_string, MAX_NTV_CTATEXT_LEN);
                bid_response_params->native_resp_params.ctatext[MAX_NTV_CTATEXT_LEN] = '\0';
        }

        rating_object = get_json_child_from_parent(native_obj, NATIVE_RESP_RATING, json_type_double);
        if ( rating_object && rating_object->o.c_double ) {
                bid_response_params->native_resp_params.rating = rating_object->o.c_double;
        }
}


void form_native_creative_json(rt_bid_response_params_t* bid_response) {
        char *creative_ptr = NULL;
        int creative_len = 0;
        native_response_params_t *native_resp = NULL;
        int creative_present = 0;

        native_resp = &(bid_response->native_resp_params);

	if ( native_resp->clickUrl[0] != '\0'
	     &&
	     (
		native_resp->iconImg[0] != '\0' ||
		native_resp->mainImg[0] != '\0' ||
		native_resp->text[0] != '\0' ||
		native_resp->title[0] != '\0'
	     )
	) {
#ifdef NATIVE_DEBUG
                llog_write(L_DEBUG,"\nMB_NATIVE Mandatory response parameter present, creating JSON creative %s:%d\n",__FILE__,__LINE__);
#endif
	        creative_ptr = bid_response->u_url.native_creative_json;
	
	        creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len, "{");
	        creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	
	        if (native_resp->title[0] != '\0') {
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len,
	                                        "\"%s\":\"%s\",", NATIVE_RESP_TITLE, native_resp->title);
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                creative_present = 1;
	        }
	
	        if (native_resp->text[0] != '\0') {
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len,
	                                        "\"%s\":\"%s\",", NATIVE_RESP_TEXT, native_resp->text);
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                creative_present = 1;
	        }
	
	        if (native_resp->iconImg[0] != '\0') {
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len,
	                                        "\"%s\":\"%s\",", NATIVE_RESP_ICON_IMG, native_resp->iconImg);
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                creative_present = 1;
	        }
	
	        if (native_resp->mainImg[0] != '\0') {
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len,
	                                        "\"%s\":\"%s\",", NATIVE_RESP_MAIN_IMG, native_resp->mainImg);
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                creative_present = 1;
	        }
	
	        if (native_resp->ctatext[0] != '\0') {
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len,
	                                        "\"%s\":\"%s\",", NATIVE_RESP_CTATEXT, native_resp->ctatext);
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                creative_present = 1;
	        }
	
	        if (native_resp->rating >= 0.0) {
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len,
	                                        "\"%s\":%.1f,", NATIVE_RESP_RATING, native_resp->rating);
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                creative_present = 1;
	        }
	
	        if (native_resp->clickUrl[0] != '\0') {
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len,
	                                        "\"%s\":\"%s\",", NATIVE_RESP_CLICK, native_resp->clickUrl);
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                creative_present = 1;
	        }
	
	        if (native_resp->impTracker[0] != '\0') {
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len,
	                                        "\"%s\":%s,", NATIVE_RESP_IMP_TRACKER, native_resp->impTracker);
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                creative_present = 1;
	        }
	
	        if (native_resp->clickTracker[0] != '\0') {
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len,
	                                        "\"%s\":%s,", NATIVE_RESP_CLICK_TRACKER, native_resp->clickTracker);
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                creative_present = 1;
	        }
	
	        if (creative_present) {
	                creative_ptr--;
	                creative_len--;
	                creative_len += snprintf(creative_ptr, MAX_NATIVE_CREATIVE_LEN - creative_len, "}");
	                creative_ptr = bid_response->u_url.native_creative_json + creative_len;
	                /* TODO: Make changes to Adflex optimizer */
	                bid_response->type = NATIVE_CREATIVE_TYPE;
#ifdef NATIVE_DEBUG
                        llog_write(L_DEBUG,"\nMB_NATIVE Native creative: %s %s:%d\n", bid_response->u_url.native_creative_json, __FILE__,__LINE__);
#endif
	        } else {
#ifdef NATIVE_DEBUG
                        llog_write(L_DEBUG,"\nMB_NATIVE Creative is blank %s:%d\n",__FILE__,__LINE__);
#endif
	                bid_response->u_url.native_creative_json[0] = '\0';
	        }
		creative_ptr = NULL;
	} else {
#ifdef NATIVE_DEBUG
                llog_write(L_DEBUG,"\nMB_NATIVE Mandatory response parameter missing, setting creative to NULL %s:%d\n",__FILE__,__LINE__);
#endif
		bid_response->u_url.native_creative_json[0] = '\0';
	}
}

