#include <stddef.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "bid_util.h"
#include "error.h"

#include "testlib.h"

int gbl_log_level = L_DEBUG;

static void test_init_bapp_info__all_testcases(void **state)
{
	(void) state;
	bapp_info_t bapp_info;
	int i;

	init_bapp_info(&bapp_info);
	assert_int_equal(0, bapp_info.app_id_count);
	assert_int_equal(0, bapp_info.bapp_egress_json_len);
	assert_string_equal("", bapp_info.bapp_egress_json);
	for(i=0; i<MAX_BLOCK_APP_IDS; i++) {
		assert_string_equal("", bapp_info.app_ids[i]);
	}
}


typedef struct testcase_parse_bapp_param_
{
	int test_case_id;
	struct test_input_parse_bapp_param_ {
		const char *  url_param;
		bapp_info_t * bapp_info;
	} test_input;

	struct expected_output_parse_bapp_param {
		bapp_info_t  bapp_info;
	} expected_output;

} testcase_parse_bapp_param_t;


static bapp_info_t global_bapp_info;



testcase_parse_bapp_param_t testcases_parse_bapp_param[] = {
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "application1,application2,application3",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 3,
				.app_ids = {
					"application1",
					"application2",
					"application3",
				}
			},
		},
	},
	{ /* one space, on either side and both side of applications and just one space in application id(also last appid) */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = " application1,application2 , application3 ,application4, ",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 5,
				.app_ids = {
					" application1",
					"application2 ",
					" application3 ",
					"application4",
					" ",
				}
			},
		},
	},
	{ /* few spaces, on either side and both side of applications and just few in application id(also last appid) */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "  application1,application2  ,  application3  ,application4,  ",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 5,
				.app_ids = {
					"  application1",
					"application2  ",
					"  application3  ",
					"application4",
					"  ",
				}
			},
		},
	},
	{ /* Url encoded and control characters -> \t, , %0a(\n i.e 2 chars as \\n), quote(\") character */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "application+%41%42suffix,application2,application3,application4%0a\t\"suffix",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 4,
				.app_ids = {
					"application ABsuffix",
					"application2",
					"application3",
					"application4\n\t\"suffix",
				}
			},
		},
	},
	{ /* Impromperly terminated url encoded string, case 1*/
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "application1,application2,application3%",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 3,
				.app_ids = {
					"application1",
					"application2",
					"application3",
				}
			},
		},
	},
	{ /* Impromperly terminated url encoded string, case 2*/
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "application1,application2,application3%3",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 3,
				.app_ids = {
					"application1",
					"application2",
					"application3",
				}
			},
		},
	},
	{ /* %2c = , */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "application1,,application2,,,,application3%3",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 3,
				.app_ids = {
					"application1",
					"application2",
					"application3",
				}
			},
		},
	},
	{ /* %2c = , */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = ",,,%2C,,,application1%2Capplication2%2c,application3,,,,%2C,,",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 3,
				.app_ids = {
					"application1",
					"application2",
					"application3",
				}
			},
		},
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 0,
				.app_ids = {
				}
			},
		},
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = ",",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 0,
				.app_ids = {
				}
			},
		},
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = ",,,,,,",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 0,
				.app_ids = {
				}
			},
		},
	},
	{ /* repeated application names */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "app1,app2,app%31,app2",
			.bapp_info = &global_bapp_info,
		},
		.expected_output = {
			.bapp_info = {
				.app_id_count = 4,
				.app_ids = {
					"app1",
					"app2",
					"app1",
					"app2",
				}
			},
		},
	},
};


#define POISON_CHAR '`'
bapp_info_t bapp_info_poison;
static void test_parse_bapp_param__all_testcases(void **state)
{
	(void) state;
	const int testcase_count = sizeof(testcases_parse_bapp_param)/sizeof(testcase_parse_bapp_param_t);
	testcase_parse_bapp_param_t * const testcases = testcases_parse_bapp_param;
	int i = 0, rc = 0;
	for(i = 0; i < testcase_count; i++) {
		memset(&bapp_info_poison, POISON_CHAR, sizeof(bapp_info_t));
		memset(testcases[i].test_input.bapp_info, POISON_CHAR, sizeof(bapp_info_t));
		printf("Executing Test case id %d (%d) for parse_bapp_param.\n", i, testcases[i].test_case_id);
		rc = parse_bapp_param(testcases[i].test_input.url_param,
							   testcases[i].test_input.bapp_info);
		assert_int_equal(ADS_ERROR_SUCCESS, rc);
		assert_int_equal(testcases[i].expected_output.bapp_info.app_id_count,
						 testcases[i].test_input.bapp_info->app_id_count);
		int j = 0;
		for(j=0; j<testcases[i].expected_output.bapp_info.app_id_count; j++) {
			assert_string_equal(testcases[i].expected_output.bapp_info.app_ids[j],
								testcases[i].test_input.bapp_info->app_ids[j]);
		}
		for(j=0; j<testcases[i].expected_output.bapp_info.app_id_count; j++) {
			memset(testcases[i].test_input.bapp_info->app_ids[j],
				   POISON_CHAR,
				   MAX_APP_ID_LEN + 1); /* strncpy some times pads remaining bytes with all \0s */
		}
		testcases[i].test_input.bapp_info->app_id_count = bapp_info_poison.app_id_count;

		assert_memory_equal(&bapp_info_poison,
							testcases[i].test_input.bapp_info,
							sizeof(bapp_info_t));
	}
}

static char * generate_bapp_test_case_url_param(const int n, const int app_len)
{
	if((n < 1) || (n > 99) || (app_len < 5)) {
		return NULL;
	}
	char * const url_param = malloc(n*(app_len + 1)); /* app, or app\0 */
	if(url_param == NULL) {
		return NULL;
	}
	char * const app_string = malloc(app_len + 1);
	if(app_string == NULL) {
		free(url_param);
		return NULL;
	}
	int i = 0;
	url_param[0] = '\0';
	for(i=0; i<n; i++) {
		if(i > 0) {
			strcat(url_param,",");
		}
		memset(app_string, 'Z', app_len);
		sprintf(app_string, "app%02d", i+1);
		app_string[strlen("appNN")] = 'Y';
		app_string[app_len] = '\0';
		strcat(url_param,app_string);
	}

	free(app_string);
	return url_param;
}

#define TEST_MAX_BLOCK_APP_IDS 40
#define TEST_MAX_APP_ID_LEN 256
#define TEST_MAX_BLOCKED_APP_IDS_OUTPUT_JSON_LEN 10500
static void generate_bapp_test_case_bapp_app_ids(const int n, const int app_len, bapp_info_t * const bapp_info)
{
	char app_string[500];
	if((n < 1) || (n > TEST_MAX_BLOCK_APP_IDS) || (app_len < 5) || app_len > TEST_MAX_APP_ID_LEN) {
		return;
	}
	int i = 0;
	for(i=0; i<n; i++) {
		memset(app_string, 'Z', app_len);
		sprintf(app_string, "app%02d", i+1);
		app_string[strlen("appNN")] = 'Y';
		app_string[app_len] = '\0';
		strcpy(bapp_info->app_ids[i], app_string);
	}
	bapp_info->app_id_count = i;
}

typedef struct testcase_parse_bapp_param2_
{
	int test_case_id;
	struct test_input_parse_bapp_param2_ {
		int app_count;
		int app_len;
	} test_input;

	struct expected_output_parse_bapp_param2_ {
		int app_count;
		int app_len;
	} expected_output;

} testcase_parse_bapp_param2_t;

testcase_parse_bapp_param2_t testcases_parse_bapp_param2[] = {
	{
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = TEST_MAX_BLOCK_APP_IDS - 1,
			.app_len = 5,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS - 1,
			.app_len = 5,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = 5,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = 5,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = TEST_MAX_BLOCK_APP_IDS + 1,
			.app_len = 5,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = 5,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = TEST_MAX_BLOCK_APP_IDS + 10,
			.app_len = 5,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = 5,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = 99,
			.app_len = 5,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = 5,
		}
	},
	{ /* truncation of strings */
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = 5,
			.app_len = TEST_MAX_APP_ID_LEN,
		},
		.expected_output = {
			.app_count = 5,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
	{ /* truncation of strings */
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = 5,
			.app_len = TEST_MAX_APP_ID_LEN - 1,
		},
		.expected_output = {
			.app_count = 5,
			.app_len = TEST_MAX_APP_ID_LEN - 1,
		}
	},
	{ /* truncation of strings */
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = 5,
			.app_len = TEST_MAX_APP_ID_LEN + 1,
		},
		.expected_output = {
			.app_count = 5,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
	{ /* truncation of strings */
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = 5,
			.app_len = TEST_MAX_APP_ID_LEN * 2,
		},
		.expected_output = {
			.app_count = 5,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
	{ /* Max appid and applen */
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = TEST_MAX_APP_ID_LEN,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
	{ /* Max appid and applen + 1 */
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = TEST_MAX_APP_ID_LEN + 1,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
	{ /* Max appid and applen - 1 */
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = TEST_MAX_APP_ID_LEN - 1,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = TEST_MAX_APP_ID_LEN - 1,
		}
	},
	{ /* Max appid + 1 and applen*/
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = TEST_MAX_BLOCK_APP_IDS + 1,
			.app_len = TEST_MAX_APP_ID_LEN,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
	{ /* Max appid - 1 and applen  */
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = TEST_MAX_BLOCK_APP_IDS - 1,
			.app_len = TEST_MAX_APP_ID_LEN,
		},
		.expected_output = {
			.app_count = TEST_MAX_BLOCK_APP_IDS - 1,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
	{ /* 10,500 = 21 * 500 , last byte gets truncated by decode_url */
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = 21,
			.app_len = 499 /* 1 byte for comma or \0 */
		},
		.expected_output = {
			.app_count = 21,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
	{ /* 10,000 = 10 * 1000 , 499 chars left*/
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = 11,
			.app_len = 999 /* 1 byte for comma or \0 */
		},
		.expected_output = {
			.app_count = 11,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
	{ /* special test case 10,296 = 264 * 39 , last appids_len = (10,500 - 10,296) = 203 , last app_id will be truncated to 203 bytes, limitationt added due to decode_url*/
		.test_case_id = __LINE__,
		.test_input = {
			.app_count = 40,
			.app_len = 263 /* 1 byte for comma or \0 */
		},
		.expected_output = {
			.app_count = 40,
			.app_len = TEST_MAX_APP_ID_LEN,
		}
	},
};

static void test_parse_bapp_param2__all_testcases(void **state)
{
	(void) state;
	const int testcase_count = sizeof(testcases_parse_bapp_param2)/sizeof(testcase_parse_bapp_param2_t);
	testcase_parse_bapp_param2_t * const testcases = testcases_parse_bapp_param2;
	int i = 0, rc = 0;
	testcase_parse_bapp_param_t testcase1;
	for(i=0; i< (testcase_count - 1); i++) {
		memset(&bapp_info_poison, POISON_CHAR, sizeof(bapp_info_t));
		memset(&global_bapp_info, POISON_CHAR, sizeof(bapp_info_t));
		printf("Executing extra Test case id %d (%d) for parse_bapp_param.\n", i, testcases[i].test_case_id);
		testcase1.test_input.url_param = generate_bapp_test_case_url_param(testcases[i].test_input.app_count,
																			  testcases[i].test_input.app_len);
		testcase1.test_input.bapp_info = &global_bapp_info;
		generate_bapp_test_case_bapp_app_ids(testcases[i].expected_output.app_count,
											 testcases[i].expected_output.app_len,
											 &(testcase1.expected_output.bapp_info));
		assert_true(NULL != testcase1.test_input.url_param);
		rc = parse_bapp_param(testcase1.test_input.url_param,
							   testcase1.test_input.bapp_info);
		free((void*)testcase1.test_input.url_param); /* remove const using (void *) typecast */
		assert_int_equal(ADS_ERROR_SUCCESS, rc);
		assert_int_equal(testcase1.expected_output.bapp_info.app_id_count,
						 testcase1.test_input.bapp_info->app_id_count);
		int j = 0;
		for(j=0; j<testcase1.expected_output.bapp_info.app_id_count; j++) {
			assert_string_equal(testcase1.expected_output.bapp_info.app_ids[j],
								testcase1.test_input.bapp_info->app_ids[j]);
		}
		for(j=0; j<testcase1.expected_output.bapp_info.app_id_count; j++) {
			memset(testcase1.test_input.bapp_info->app_ids[j],
				   POISON_CHAR,
				   MAX_APP_ID_LEN + 1); /* strncpy some times pads remaining bytes with all \0s */
		}
		testcase1.test_input.bapp_info->app_id_count = bapp_info_poison.app_id_count;

		assert_memory_equal(&bapp_info_poison,
							testcase1.test_input.bapp_info,
							sizeof(bapp_info_t));
	}
	memset(&bapp_info_poison, POISON_CHAR, sizeof(bapp_info_t));
	memset(&global_bapp_info, POISON_CHAR, sizeof(bapp_info_t));
	printf("Executing special extra Test case id %d (%d) for parse_bapp_param.\n", i, testcases[i].test_case_id);
	testcase1.test_input.url_param = generate_bapp_test_case_url_param(testcases[i].test_input.app_count,
																	   testcases[i].test_input.app_len);
	testcase1.test_input.bapp_info = &global_bapp_info;
	generate_bapp_test_case_bapp_app_ids(testcases[i].expected_output.app_count,
										 testcases[i].expected_output.app_len,
										 &(testcase1.expected_output.bapp_info));

	testcase1.expected_output.bapp_info.app_ids[39][203] = '\0'; /* Special handling here, last app gets truncated due to decode_url_param truncation */
	assert_true(NULL != testcase1.test_input.url_param);
	rc = parse_bapp_param(testcase1.test_input.url_param,
						  testcase1.test_input.bapp_info);
	free((void*)testcase1.test_input.url_param); /* remove const using (void *) typecast */
	assert_int_equal(ADS_ERROR_SUCCESS, rc);
	assert_int_equal(testcase1.expected_output.bapp_info.app_id_count,
					 testcase1.test_input.bapp_info->app_id_count);
	int j = 0;
	for(j=0; j<testcase1.expected_output.bapp_info.app_id_count; j++) {
		assert_string_equal(testcase1.expected_output.bapp_info.app_ids[j],
							testcase1.test_input.bapp_info->app_ids[j]);
	}
	for(j=0; j<testcase1.expected_output.bapp_info.app_id_count; j++) {
		memset(testcase1.test_input.bapp_info->app_ids[j],
			   POISON_CHAR,
			   MAX_APP_ID_LEN + 1); /* strncpy some times pads remaining bytes with all \0s */
	}
	testcase1.test_input.bapp_info->app_id_count = bapp_info_poison.app_id_count;

	assert_memory_equal(&bapp_info_poison,
						testcase1.test_input.bapp_info,
						sizeof(bapp_info_t));
}

typedef struct testcase_form_bapp_json_str_
{
	int test_case_id;
	struct test_input2_ {
		bapp_info_t bapp_info;
	} test_input;

	struct expected_output2_ {
		const bapp_info_t bapp_info;
	} const expected_output;
} testcase_form_bapp_json_str_t;

static testcase_form_bapp_json_str_t testcases_form_bapp_json_str[] = {
	{
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
				.app_id_count = 1,
				.app_ids = {
					"application1",
				}

			}
		},
		.expected_output = {
			.bapp_info = {
#define STR "[\"application1\"]"
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
				.app_id_count = 3,
				.app_ids = {
					"application1",
					"application2",
					"application3",
				}

			}
		},
		.expected_output = {
			.bapp_info = {
#define STR "[\"application1\",\"application2\",\"application3\"]"
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{ /* one space on either and both sides */
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
				.app_id_count = 3,
				.app_ids = {
					" application1",
					"application2 ",
					" application3 ",
				}

			}
		},
		.expected_output = {
			.bapp_info = {
#define STR "[\" application1\",\"application2 \",\" application3 \"]"
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{ /* few spaces on either and both sides */
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
				.app_id_count = 3,
				.app_ids = {
					"  application1",
					"application2  ",
					"  application3  ",
				}

			}
		},
		.expected_output = {
			.bapp_info = {
#define STR "[\"  application1\",\"application2  \",\"  application3  \"]"
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{ /* json_escape needing characters */
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
				.app_id_count = 1,
				.app_ids = {
					"application1prefix\n\x19suffix",
				}

			}
		},
		.expected_output = {
			.bapp_info = {
#define STR "[\"application1prefix\\n\\u0019suffix\"]"
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{ /* json_escape needing characters */
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
				.app_id_count = 5,
				.app_ids = {
					"application1prefix\n\x19suffix",
					"application2prefix\n\x19",
					"\n\x19 application3",
					"\n\x19",
					"application4\n\t\x19\x20",

				}

			}
		},
		.expected_output = {
			.bapp_info = {
#define STR "[\"application1prefix\\n\\u0019suffix\",\"application2prefix\\n\\u0019\",\"\\n\\u0019 application3\",\"\\n\\u0019\",\"application4\\n\\t\\u0019\x20\"]"
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{ /* app_id_count = 0 */
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
				.app_id_count = 0,
				.app_ids = {
				}

			}
		},
		.expected_output = {
			.bapp_info = {
#define STR ""
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{ /* app_id_count = -12 */
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
				.app_id_count = -12,
				.app_ids = {
				}

			}
		},
		.expected_output = {
			.bapp_info = {
#define STR ""
				.bapp_egress_json = STR,
				.bapp_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{ /* max app_ids and app_len */
		.test_case_id = __LINE__,
		.test_input = {
			.bapp_info = {
				/* will be filled in test_form_bapp_json_str__all_testcases() */
			}
		},
		.expected_output = {
			.bapp_info = {
				/* will be filled in test_form_bapp_json_str__all_testcases() */
			}
		}
	},
};


static void test_form_bapp_json_str__all_testcases(void **state)
{
	(void) state;
	const int testcase_count = sizeof(testcases_form_bapp_json_str) / sizeof(testcase_form_bapp_json_str_t);
	testcase_form_bapp_json_str_t * const testcases = testcases_form_bapp_json_str;

	/*max app_ids and app_len test case*/

	int i=0, rc = 0;
	for(i=0; i < testcase_count; i++) {
		memset(&bapp_info_poison, POISON_CHAR, sizeof(bapp_info_t));
		int backup_app_id_count;
		char backup_app_ids[MAX_BLOCK_APP_IDS][MAX_APP_ID_LEN + 1];
		backup_app_id_count = testcases[i].test_input.bapp_info.app_id_count;
		memcpy(backup_app_ids, testcases[i].test_input.bapp_info.app_ids, sizeof(backup_app_ids));
		memset(&(testcases[i].test_input.bapp_info), POISON_CHAR, sizeof(bapp_info_t));
		testcases[i].test_input.bapp_info.app_id_count = backup_app_id_count;
		memcpy(testcases[i].test_input.bapp_info.app_ids, backup_app_ids, sizeof(backup_app_ids));

		printf("Executing Test case id %d (%d) for form_bapp_json_str.\n", i, testcases[i].test_case_id);
		rc = form_bapp_json_str(&(testcases[i].test_input.bapp_info));
		assert_int_equal(ADS_ERROR_SUCCESS, rc);

		assert_int_equal(testcases[i].expected_output.bapp_info.bapp_egress_json_len,
						 testcases[i].test_input.bapp_info.bapp_egress_json_len);

		assert_int_equal(backup_app_id_count, testcases[i].test_input.bapp_info.app_id_count);
		assert_memory_equal(backup_app_ids, testcases[i].test_input.bapp_info.app_ids, sizeof(backup_app_ids));
		testcases[i].test_input.bapp_info.app_id_count = bapp_info_poison.app_id_count;
		memset(testcases[i].test_input.bapp_info.app_ids, POISON_CHAR, sizeof(backup_app_ids));

		if(testcases[i].expected_output.bapp_info.bapp_egress_json_len > 0) {
			assert_string_equal(testcases[i].expected_output.bapp_info.bapp_egress_json,
								testcases[i].test_input.bapp_info.bapp_egress_json);
			memset(testcases[i].test_input.bapp_info.bapp_egress_json,
				   POISON_CHAR,
				   testcases[i].expected_output.bapp_info.bapp_egress_json_len + 1);
			testcases[i].test_input.bapp_info.bapp_egress_json_len = bapp_info_poison.bapp_egress_json_len;
			assert_memory_equal(&bapp_info_poison,
								&(testcases[i].test_input.bapp_info),
								sizeof(bapp_info_t));
		}
	}
}

typedef struct testcase_form_bapp_json_str2_
{
	int test_case_id;
	struct test_input_form_bapp_json_str2_ {
		const int app_id_count;
		const int app_len;
		const char * const signature;
	} test_input;

	struct expected_output2_form_bapp_json_str2_ {
		const int app_len;
		const char * const signature;
		int bapp_egress_json_len;
		char bapp_egress_json[TEST_MAX_BLOCKED_APP_IDS_OUTPUT_JSON_LEN + 1];
	} expected_output;
} testcase_form_bapp_json_str2_t;

static testcase_form_bapp_json_str2_t testcases_form_bapp_json_str2[] = {
	{
		.test_case_id = __LINE__,
		.test_input = {
			.app_id_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = TEST_MAX_APP_ID_LEN,
			.signature = "XYZ",
		},
		.expected_output = {
			.app_len = TEST_MAX_APP_ID_LEN,
			.signature = "XYZ",
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.app_id_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = TEST_MAX_APP_ID_LEN/2,
			.signature = "\n",
		},
		.expected_output = {
			.app_len = TEST_MAX_APP_ID_LEN,
			.signature = "\\n",
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.app_id_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = 258/6,
			.signature = "\x19",
		},
		.expected_output = {
			.app_len = 258,
			.signature = "\\u0019",
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.app_id_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = 258/2,
			.signature = "\t",
		},
		.expected_output = {
			.app_len =  258,
			.signature = "\\t",
		}
	},
};

static void generate_bapp_test_case_bapp_app_ids2(bapp_info_t * const bapp_info,
												  const int app_id_count,
												  const int app_len,
												  const char * const signature)
{
	int i = 0;
	for(i=0; i<app_id_count; i++) {
		generate_string(bapp_info->app_ids[i], app_len + 1, signature);
	}
	bapp_info->app_id_count = app_id_count;
}

static void generate_bapp_bapp_egress_json2(char * const bapp_egress_json,
									  const int app_id_count,
									  const int app_id_json_len,
									  const char * const json_signature)
{
	char app_id_json[app_id_json_len + 1];
	int i = 0;
	sprintf(bapp_egress_json,"[");
	for(i=0; i<app_id_count; i++) {
				generate_string(app_id_json, app_id_json_len + 1, json_signature);
				if(i > 0) {
					strcat(bapp_egress_json,",");
				}
				strcat(bapp_egress_json,"\"");
				strcat(bapp_egress_json, app_id_json);
				strcat(bapp_egress_json,"\"");
	}
	strcat(bapp_egress_json,"]");
}

static void test_form_bapp_json_str2__all_testcases(void **state)
{
	(void) state;
	const int testcase_count = sizeof(testcases_form_bapp_json_str2) / sizeof(testcase_form_bapp_json_str2_t);
	testcase_form_bapp_json_str2_t * const testcases = testcases_form_bapp_json_str2;

	/*max app_ids and app_len test case*/

	int i=0, rc = 0;
	for(i=0; i < testcase_count; i++) {
		printf("Executing extra Test case id %d (%d) for form_bapp_json_str.\n", i, testcases[i].test_case_id);
		/* Generate test input */
		generate_bapp_test_case_bapp_app_ids2(&global_bapp_info,
											  testcases[i].test_input.app_id_count,
											  testcases[i].test_input.app_len,
											  testcases[i].test_input.signature);
		/* Generated expected output */
		testcases[i].expected_output.bapp_egress_json_len = (testcases[i].expected_output.app_len + 3) * testcases[i].test_input.app_id_count + 1;
		generate_bapp_bapp_egress_json2(testcases[i].expected_output.bapp_egress_json,
								   testcases[i].test_input.app_id_count,
								   testcases[i].expected_output.app_len,
								   testcases[i].expected_output.signature);

		memset(&bapp_info_poison, POISON_CHAR, sizeof(bapp_info_t));
		int backup_app_id_count;
		char backup_app_ids[MAX_BLOCK_APP_IDS][MAX_APP_ID_LEN + 1];
		backup_app_id_count = global_bapp_info.app_id_count;
		memcpy(backup_app_ids, global_bapp_info.app_ids, sizeof(backup_app_ids));
		memset(&global_bapp_info, POISON_CHAR, sizeof(bapp_info_t));
		global_bapp_info.app_id_count= backup_app_id_count;
		memcpy(global_bapp_info.app_ids, backup_app_ids, sizeof(backup_app_ids));

		rc = form_bapp_json_str(&global_bapp_info);


		assert_int_equal(ADS_ERROR_SUCCESS, rc);

		assert_int_equal(testcases[i].expected_output.bapp_egress_json_len,
						 global_bapp_info.bapp_egress_json_len);

		assert_int_equal(backup_app_id_count, global_bapp_info.app_id_count);
		assert_memory_equal(backup_app_ids, global_bapp_info.app_ids, sizeof(backup_app_ids));
		global_bapp_info.app_id_count = bapp_info_poison.app_id_count;
		memset(global_bapp_info.app_ids, POISON_CHAR, sizeof(backup_app_ids));

		if(testcases[i].expected_output.bapp_egress_json_len > 0 ) {
			assert_string_equal(testcases[i].expected_output.bapp_egress_json,
								global_bapp_info.bapp_egress_json);
			memset(global_bapp_info.bapp_egress_json,
				   POISON_CHAR,
				   testcases[i].expected_output.bapp_egress_json_len + 1);
			global_bapp_info.bapp_egress_json_len = bapp_info_poison.bapp_egress_json_len;
			assert_memory_equal(&bapp_info_poison,
								&global_bapp_info,
								sizeof(bapp_info_t));
		}
	}
	printf("Executing special extra(full size egress json) Test case id %d (%d) for form_bapp_json_str.\n", i++, __LINE__);
	testcase_form_bapp_json_str2_t testcase1 = {
		/* use all 10500 bytes for bapp_egress_json */
		.test_case_id = __LINE__,
		.test_input = {
			.app_id_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = 258/2,
			.signature = "\t",
		},
		.expected_output = {
			.app_len =  258,
			.signature = "\\t",
		}
	};
	/*Generate test input */
	generate_bapp_test_case_bapp_app_ids2(&global_bapp_info,
										  testcase1.test_input.app_id_count,
										  testcase1.test_input.app_len,
										  testcase1.test_input.signature);
	/* Generated expected output */
	testcase1.expected_output.bapp_egress_json_len = TEST_MAX_BLOCKED_APP_IDS_OUTPUT_JSON_LEN;
	generate_bapp_bapp_egress_json2(testcase1.expected_output.bapp_egress_json,
							   testcase1.test_input.app_id_count,
							   testcase1.expected_output.app_len,
							   testcase1.expected_output.signature);

	/* special handling here so that exactly max bytes are needed */
	char suffix1[60];
	generate_string(suffix1, 60, "SIGN"); /*ends with SIGNSIG*/
	strcat(global_bapp_info.app_ids[TEST_MAX_BLOCK_APP_IDS - 1], suffix1);

	/* fix expected ouptput here */
	testcase1.expected_output.bapp_egress_json[strlen(testcase1.expected_output.bapp_egress_json)-2] = '\0';
	strcat(testcase1.expected_output.bapp_egress_json, suffix1);
	strcat(testcase1.expected_output.bapp_egress_json, "\"]");
	assert_int_equal(TEST_MAX_BLOCKED_APP_IDS_OUTPUT_JSON_LEN, strlen(testcase1.expected_output.bapp_egress_json));

	memset(&bapp_info_poison, POISON_CHAR, sizeof(bapp_info_t));
	int backup_app_id_count;
	char backup_app_ids[MAX_BLOCK_APP_IDS][MAX_APP_ID_LEN + 1];
	backup_app_id_count = global_bapp_info.app_id_count;
	memcpy(backup_app_ids, global_bapp_info.app_ids, sizeof(backup_app_ids));
	memset(&global_bapp_info, POISON_CHAR, sizeof(bapp_info_t));
	global_bapp_info.app_id_count= backup_app_id_count;
	memcpy(global_bapp_info.app_ids, backup_app_ids, sizeof(backup_app_ids));

	rc = form_bapp_json_str(&global_bapp_info);

	assert_int_equal(ADS_ERROR_SUCCESS, rc);

	assert_int_equal(testcase1.expected_output.bapp_egress_json_len,
					 global_bapp_info.bapp_egress_json_len);

	assert_int_equal(backup_app_id_count, global_bapp_info.app_id_count);
	assert_memory_equal(backup_app_ids, global_bapp_info.app_ids, sizeof(backup_app_ids));
	global_bapp_info.app_id_count = bapp_info_poison.app_id_count;
	memset(global_bapp_info.app_ids, POISON_CHAR, sizeof(backup_app_ids));

	if(testcase1.expected_output.bapp_egress_json_len > 0 ) {
		assert_string_equal(testcase1.expected_output.bapp_egress_json,
							global_bapp_info.bapp_egress_json);
		memset(global_bapp_info.bapp_egress_json,
			   POISON_CHAR,
			   testcase1.expected_output.bapp_egress_json_len + 1);
			global_bapp_info.bapp_egress_json_len = bapp_info_poison.bapp_egress_json_len;
			assert_memory_equal(&bapp_info_poison,
								&global_bapp_info,
								sizeof(bapp_info_t));
	}

	/*Buffer over flow test case below */
	printf("Executing special(full size plus 1 extra charcter) extra Test case id %d (%d) for form_bapp_json_str.\n", i++, __LINE__);
	testcase_form_bapp_json_str2_t testcase2 = {
		/* use all 10500 bytes for bapp_egress_json */
		.test_case_id = __LINE__,
		.test_input = {
			.app_id_count = TEST_MAX_BLOCK_APP_IDS,
			.app_len = 258/2,
			.signature = "\t",
		},
		.expected_output = {
			.app_len =  258,
			.signature = "\\t",
		}
	};
	/*Generate test input */
	generate_bapp_test_case_bapp_app_ids2(&global_bapp_info,
										  testcase2.test_input.app_id_count,
										  testcase2.test_input.app_len,
										  testcase2.test_input.signature);

	/* special handling here to cause to need exactly one more than max bytes */
	char suffix2[60 + 1];
	generate_string(suffix2, 60 + 1, "SIGN"); /*ends with SIGNSIGN*/
	strcat(global_bapp_info.app_ids[TEST_MAX_BLOCK_APP_IDS - 1], suffix2);

	memset(&bapp_info_poison, POISON_CHAR, sizeof(bapp_info_t));
	backup_app_id_count = global_bapp_info.app_id_count;
	memcpy(backup_app_ids, global_bapp_info.app_ids, sizeof(backup_app_ids));
	memset(&global_bapp_info, POISON_CHAR, sizeof(bapp_info_t));
	global_bapp_info.app_id_count= backup_app_id_count;
	memcpy(global_bapp_info.app_ids, backup_app_ids, sizeof(backup_app_ids));

	rc = form_bapp_json_str(&global_bapp_info);
	assert_int_not_equal(ADS_ERROR_SUCCESS, rc);

	assert_int_equal(backup_app_id_count, global_bapp_info.app_id_count);
	assert_memory_equal(backup_app_ids, global_bapp_info.app_ids, sizeof(backup_app_ids));
	global_bapp_info.app_id_count = bapp_info_poison.app_id_count;
	memset(global_bapp_info.app_ids, POISON_CHAR, sizeof(backup_app_ids));
	memset(global_bapp_info.bapp_egress_json, POISON_CHAR, sizeof(global_bapp_info.bapp_egress_json)); /* bapp_egress_json may be modified in non success */
	/* global_bapp_info.bapp_egress_json should be untouched */
	assert_memory_equal(&bapp_info_poison,
						&global_bapp_info,
						sizeof(bapp_info_t));

}


typedef struct testcase_validate_iab_cat_ {
	int test_case_id;
	struct test_input_validate_iab_cat_ {
		char *str;
	} test_input;
	struct expected_output_validate_iab_cat_ {
		int rc;
	} expected_output;
} testcase_validate_iab_cat;

testcase_validate_iab_cat testcases_validate_iab_cat[]= {
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB1",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB11",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB1-1",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB11-1",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB9-3",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB13-10",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = NULL,
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "i",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "I",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "Ia",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IA",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAb",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IABx",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB1x",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB11_",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB11-",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB11-x",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB11-1x",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB11-11x",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB1-",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB1-x",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB1-1x",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB1-11x",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB111",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB1-111",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB11-111",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "iab1"
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB2",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB02",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB0",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB00",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB26",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB27",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB2-1",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB3-02",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB04-1",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB04-02",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB2-0",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB3-00",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB04-0",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB04-00",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB6-9",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB6-10",
		},
		.expected_output = {
			.rc = 0,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB4-11",
		},
		.expected_output = {
			.rc = 1,
		}

	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB4-12",
		},
		.expected_output = {
			.rc = 0,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB21-3",
		},
		.expected_output = {
			.rc = 1,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB21-4",
		},
		.expected_output = {
			.rc = 0,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB23-10",
		},
		.expected_output = {
			.rc = 1,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB23-11",
		},
		.expected_output = {
			.rc = 0,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB24",
		},
		.expected_output = {
			.rc = 1,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB24-0",
		},
		.expected_output = {
			.rc = 0,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB24-1",
		},
		.expected_output = {
			.rc = 0,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB24-00",
		},
		.expected_output = {
			.rc = 0,
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.str = "IAB24-01",
		},
		.expected_output = {
			.rc = 0,
		}
	},
};

void test_validate_iab_cat__all_testcases(void ** state)
{
	(void)state;
	unsigned int i=0;
	testcase_validate_iab_cat *testcases = testcases_validate_iab_cat;
	for(i=0; i<sizeof(testcases_validate_iab_cat)/sizeof(testcase_validate_iab_cat); i++) {
		printf("Executing test case %d (%d) for validate_iab_category.\n", i, testcases[i].test_case_id);
		assert_int_equal(testcases[i].expected_output.rc,
						 validate_iab_category(testcases[i].test_input.str));
	}
}

#define MAX_IAB_CATEG_PRIMARY 26
#define MAX_IAB_CATEGORY_SECONDARY01 7
#define MAX_IAB_CATEGORY_SECONDARY02 23
#define MAX_IAB_CATEGORY_SECONDARY03 12
#define MAX_IAB_CATEGORY_SECONDARY04 11
#define MAX_IAB_CATEGORY_SECONDARY05 15
#define MAX_IAB_CATEGORY_SECONDARY06 9
#define MAX_IAB_CATEGORY_SECONDARY07 45
#define MAX_IAB_CATEGORY_SECONDARY08 18
#define MAX_IAB_CATEGORY_SECONDARY09 31
#define MAX_IAB_CATEGORY_SECONDARY10 9
#define MAX_IAB_CATEGORY_SECONDARY11 5
#define MAX_IAB_CATEGORY_SECONDARY12 3
#define MAX_IAB_CATEGORY_SECONDARY13 12
#define MAX_IAB_CATEGORY_SECONDARY14 8
#define MAX_IAB_CATEGORY_SECONDARY15 10
#define MAX_IAB_CATEGORY_SECONDARY16 7
#define MAX_IAB_CATEGORY_SECONDARY17 44
#define MAX_IAB_CATEGORY_SECONDARY18 6
#define MAX_IAB_CATEGORY_SECONDARY19 36
#define MAX_IAB_CATEGORY_SECONDARY20 27
#define MAX_IAB_CATEGORY_SECONDARY21 3
#define MAX_IAB_CATEGORY_SECONDARY22 4
#define MAX_IAB_CATEGORY_SECONDARY23 10
#define MAX_IAB_CATEGORY_SECONDARY24 0
#define MAX_IAB_CATEGORY_SECONDARY25 7
#define MAX_IAB_CATEGORY_SECONDARY26 4

static const int iab_cat_max_primary = MAX_IAB_CATEG_PRIMARY;
static const int iab_cat_max_secondary[MAX_IAB_CATEG_PRIMARY] =
	{
		MAX_IAB_CATEGORY_SECONDARY01,
		MAX_IAB_CATEGORY_SECONDARY02,
		MAX_IAB_CATEGORY_SECONDARY03,
		MAX_IAB_CATEGORY_SECONDARY04,
		MAX_IAB_CATEGORY_SECONDARY05,
		MAX_IAB_CATEGORY_SECONDARY06,
		MAX_IAB_CATEGORY_SECONDARY07,
		MAX_IAB_CATEGORY_SECONDARY08,
		MAX_IAB_CATEGORY_SECONDARY09,
		MAX_IAB_CATEGORY_SECONDARY10,
		MAX_IAB_CATEGORY_SECONDARY11,
		MAX_IAB_CATEGORY_SECONDARY12,
		MAX_IAB_CATEGORY_SECONDARY13,
		MAX_IAB_CATEGORY_SECONDARY14,
		MAX_IAB_CATEGORY_SECONDARY15,
		MAX_IAB_CATEGORY_SECONDARY16,
		MAX_IAB_CATEGORY_SECONDARY17,
		MAX_IAB_CATEGORY_SECONDARY18,
		MAX_IAB_CATEGORY_SECONDARY19,
		MAX_IAB_CATEGORY_SECONDARY20,
		MAX_IAB_CATEGORY_SECONDARY21,
		MAX_IAB_CATEGORY_SECONDARY22,
		MAX_IAB_CATEGORY_SECONDARY23,
		MAX_IAB_CATEGORY_SECONDARY24,
		MAX_IAB_CATEGORY_SECONDARY25,
		MAX_IAB_CATEGORY_SECONDARY26,
	};

void test_validate_iab_cat_min_max_limit___all_testcases(void ** state)
{
	(void)state;
	char iab_cat_string[9]= "";
	unsigned int pri=0, sec_max=0;
	int i =0;
	for(i=0; i<iab_cat_max_primary; i++) {
		printf("Executing test case %d for validate_iab_category \"IAB%d\" secondary category max value.\n", i, i+1);
		pri = i+1;
		sec_max = iab_cat_max_secondary[i];
		if(sec_max != 0) {
			sprintf(iab_cat_string,"IAB%u-%u", pri,sec_max);
			assert_int_equal(1,
							 validate_iab_category(iab_cat_string));
		}
		sprintf(iab_cat_string,"IAB%u-%u", pri,sec_max+1);
		assert_int_equal(0,
						 validate_iab_category(iab_cat_string));
	}
	for(i=0; i<iab_cat_max_primary; i++) {
		printf("Executing test case %d for validate_iab_category \"IAB%d\" secondary category min value.\n", i, i+1);
		pri = i + 1;
		sprintf(iab_cat_string,"IAB%u-%u", pri, 0);
		assert_int_equal(0,
						 validate_iab_category(iab_cat_string));
		if(iab_cat_max_secondary[i] > 0 ) {
			sprintf(iab_cat_string,"IAB%u-%u", pri, 1);
			assert_int_equal(1,
							 validate_iab_category(iab_cat_string));
		}
	}
	printf("Executing test case for validate_iab_category \"IAB%d\" primary category max value.\n", iab_cat_max_primary + 1);
	sprintf(iab_cat_string,"IAB%u",iab_cat_max_primary + 1);
	assert_int_equal(0,
					 validate_iab_category(iab_cat_string));
	printf("Executing test case for validate_iab_category \"IAB%d\" primary category min value.\n", iab_cat_max_primary + 1);
	sprintf(iab_cat_string,"IAB%u",0);
	assert_int_equal(0,
					 validate_iab_category(iab_cat_string));

	for(i=0; i<iab_cat_max_primary; i++) {
		printf("Executing test case %d for validate_iab_category \"IAB%d\" with no secondary category.\n", i, i+1);
		pri = i + 1;
		sprintf(iab_cat_string,"IAB%u", pri);
		assert_int_equal(1,
						 validate_iab_category(iab_cat_string));
	}
}

void test_validate_iab_cat_min_max_limit_zero_pad__all_testcases(void ** state)
{
	(void)state;
	char iab_cat_string[9]= "";
	unsigned int pri=0, sec_max=0;
	int i =0;
	for(i=0; i<iab_cat_max_primary; i++) {
		printf("Executing test case %d for validate_iab_category \"IAB%02d\" secondary category max value.\n", i, i+1);
		pri = i+1;
		sec_max = iab_cat_max_secondary[i];
		if(sec_max != 0) {
			sprintf(iab_cat_string,"IAB%02u-%02u", pri,sec_max);
			assert_int_equal(1,
							 validate_iab_category(iab_cat_string));
		}
		sprintf(iab_cat_string,"IAB%02u-%02u", pri,sec_max+1);
		assert_int_equal(0,
						 validate_iab_category(iab_cat_string));
	}
	for(i=0; i<iab_cat_max_primary; i++) {
		printf("Executing test case %d for validate_iab_category \"IAB%02d\" secondary category min value.\n", i, i+1);
		pri = i + 1;
		sprintf(iab_cat_string,"IAB%02u-%02u", pri, 0);
		assert_int_equal(0,
						 validate_iab_category(iab_cat_string));
		if(iab_cat_max_secondary[i] > 0 ) {
			sprintf(iab_cat_string,"IAB%02u-%02u", pri, 1);
			assert_int_equal(1,
							 validate_iab_category(iab_cat_string));
		}
	}
	printf("Executing test case for validate_iab_category \"IAB%02d\" primary category max value.\n", iab_cat_max_primary + 1);
	sprintf(iab_cat_string,"IAB%02u",iab_cat_max_primary + 1);
	assert_int_equal(0,
					 validate_iab_category(iab_cat_string));
	printf("Executing test case for validate_iab_category \"IAB%02d\" primary category min value.\n", iab_cat_max_primary + 1);
	sprintf(iab_cat_string,"IAB%02u",0);
	assert_int_equal(0,
					 validate_iab_category(iab_cat_string));

	for(i=0; i<iab_cat_max_primary; i++) {
		printf("Executing test case %d for validate_iab_category \"IAB%02d\" with no secondary category.\n", i, i+1);
		pri = i + 1;
		sprintf(iab_cat_string,"IAB%02u", pri);
		assert_int_equal(1,
						 validate_iab_category(iab_cat_string));
	}
}

void test_validate_iab_cat_all_openrtb_values__all_testcases(void ** state)
{
	(void)state;
	char iab_cat_string[9]= "";
	unsigned int pri = 0;
	int i = 0, j = 0;
	for(i=0; i<iab_cat_max_primary; i++) {
		pri = i+1;
		sprintf(iab_cat_string,"IAB%u", pri);
		printf("Testing IAB%u(%s)\n", i+1 ,iab_cat_string);
		assert_int_equal(1,
						 validate_iab_category(iab_cat_string));
		for(j=1; j<=iab_cat_max_secondary[i]; j++) {

			sprintf(iab_cat_string,"IAB%u-%u", pri,j);
			printf("Testing IAB%u-%u(%s)\n", i+1, j ,iab_cat_string);
			assert_int_equal(1,
							 validate_iab_category(iab_cat_string));
		}
	}
}

void test_validate_iab_cat_all_openrtb_values_zero_pad__all_testcases(void ** state)
{
	(void)state;
	char iab_cat_string[9]= "";
	unsigned int pri = 0;
	int i = 0, j = 0;
	for(i=0; i<iab_cat_max_primary; i++) {
		pri = i+1;
		sprintf(iab_cat_string,"IAB%02u", pri);
		printf("Testing IAB%02u(%s)\n", i+1 ,iab_cat_string);
		assert_int_equal(1,
						 validate_iab_category(iab_cat_string));
		for(j=1; j<=iab_cat_max_secondary[i]; j++) {

			sprintf(iab_cat_string,"IAB%02u-%02u", pri,j);
			printf("Testing IAB%02u-%02u(%s)\n", i+1, j ,iab_cat_string);
			assert_int_equal(1,
							 validate_iab_category(iab_cat_string));
		}
	}
}

int main()
{
	const struct CMUnitTest bid_util_tests[] = {
		/* bapp */
		cmocka_unit_test(test_init_bapp_info__all_testcases),
		cmocka_unit_test(test_parse_bapp_param__all_testcases),
		cmocka_unit_test(test_parse_bapp_param2__all_testcases),
		cmocka_unit_test(test_form_bapp_json_str__all_testcases),
		cmocka_unit_test(test_form_bapp_json_str2__all_testcases),
		/* validate_iab_cat */
        cmocka_unit_test (test_validate_iab_cat__all_testcases),
		cmocka_unit_test (test_validate_iab_cat_min_max_limit___all_testcases),
		cmocka_unit_test (test_validate_iab_cat_min_max_limit_zero_pad__all_testcases),
		cmocka_unit_test (test_validate_iab_cat_all_openrtb_values__all_testcases),
		cmocka_unit_test (test_validate_iab_cat_all_openrtb_values_zero_pad__all_testcases),
	};

	return cmocka_run_group_tests(bid_util_tests, NULL, NULL);
}
