#include <stdio.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include "truncate_string_if_nonutf8.h"

typedef struct test_object {
  char *str;
  char *expected_str;
}test_object_t;

char hex_char_arr[][5] = {

  //Test case 1:string has non UTF8 char at start
  {0xA2,0x61,0x62,0x63,0x86},

  //Test case 2:string has non UTF8 char in string at index more than 0
  {0x61,0x62,0xA2,0x63,0x86},

  //Test case 3:string has all valid UTF8 char in string
  {0x61,0x62,0x63,0x64,0x65}
};

char expected_hex_char_arr[][5] = {
  {0x00},
  {0x61,0x62,0x00},
  {0x61,0x62,0x63,0x64,0x65}
};

test_object_t test_object_arr[] = {
  //Test case 1:string has non UTF8 char at start
  {
	.str = hex_char_arr[0],
	.expected_str = expected_hex_char_arr[0]
  },
  //Test case 2:string has non UTF8 char in string at index more than 0
  {
	.str = hex_char_arr[1],
	.expected_str = expected_hex_char_arr[1]
  },
  //Test case 3:string has all valid UTF8 char in string
  {
	.str = hex_char_arr[2],
	.expected_str = expected_hex_char_arr[2]
  }

};

static void test_truncate_string_if_nonutf8(void **state) {
 // fprintf(stdout,"IN your UTC\n");
  int index = 0;
  for (index = 0; index < (int) (sizeof(test_object_arr)/sizeof(test_object_t)); index++) {
	truncate_string_if_nonutf8(test_object_arr[index].str);
	assert_string_equal(test_object_arr[index].str,test_object_arr[index].expected_str);
  }
  (void) state;
}

int main() {
  const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_truncate_string_if_nonutf8)
  };

  return cmocka_run_group_tests(tests, NULL, NULL);
}
