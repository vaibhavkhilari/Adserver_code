#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include <rt_types.h>
#include <error.h>
#include <string.h>
#include "rtb_util.h"
#include "win_loss_notification.h"
#include "string_util.h"

int gbl_log_level = L_DEBUG;
extern int pm_rff_to_ortb_rff_map[MAX_REASON_FOR_FILTERING];
extern campaign_winloss_info_t * get_campaign_winloss_info(const win_loss_table_t * wlt, int camp_id);
extern void init_wl_Queue(win_loss_queue_t* queue);
extern int isfull_wlq(win_loss_queue_t* queue);
extern int isempty_wlq(win_loss_queue_t* queue);
extern void add_to_wlq(win_loss_queue_t* queue,
					   const char *request_id,
					   double winning_bid,
					   int client_auction_enabled,
					   const char *bid_id,
					   int reason,
					   const char *bid_currency_code);
extern campaign_winloss_info_t* dequeue_wlq(win_loss_queue_t* queue);
extern campaign_winloss_info_t* get_obj_with_same_request_inqueue(const char *request_id, win_loss_queue_t* queue);
extern int add_campaign_winloss_info(win_loss_table_t * wlt,
									 int camp_id,
									 const char *request_id,
									 int reason_for_filtering, 
									 const char* bid_id,
									 double winning_bid,
									 int client_auction_enabled,
									 const char* bid_currency_code);
extern campaign_winloss_info_t * get_campaign_winloss_info(const win_loss_table_t * wlt,
														   int camp_id);
extern double get_winning_bid( 
							  const fte_additional_params_t *fte_additional_parameters,
							  const int selected_campaign,
							  const selected_campaign_attribute_t* selected_camp,
							  const double bidding_ecpm
							   );
void __wrap_elog( int level, int error_code, uint64_t module_code, ... ){
}

void test_init_wl_Queue(void **state){
	(void) state; /* unused */
	win_loss_queue_t wlq;
	init_wl_Queue(&wlq);
	
	//verify
	
	assert_int_equal(wlq.capacity, WIN_LOSS_QUEUE_SIZE);
	assert_int_equal(wlq.front, 0);
	assert_int_equal(wlq.size, 0);
	assert_int_equal(wlq.rear, wlq.capacity-1);
	assert_int_equal(wlq.capacity, WIN_LOSS_QUEUE_SIZE);
}
void test_isfull_wlq(void **state){
  win_loss_queue_t wlq;
  int i = 0;
  init_wl_Queue(&wlq);
  
  for( i = 0; i< WIN_LOSS_QUEUE_SIZE;i++){
	add_to_wlq(&wlq,  "request_id_1", 100.0, 1,
			   "bid_id_1", 1, "USD");
  }
  assert_int_equal(isfull_wlq(&wlq),1);
  //remove one and check
  dequeue_wlq(&wlq);
  assert_int_equal(isfull_wlq(&wlq),0);

  //deque all and check
  for( i = 0; i< WIN_LOSS_QUEUE_SIZE;i++){
	dequeue_wlq(&wlq);
  }
  
  assert_int_equal(isfull_wlq(&wlq),0);
  assert_int_equal(isempty_wlq(&wlq),1);

  //add again 1  and check
  add_to_wlq(&wlq,  "request_id_1", 100.0, 1,
			 "bid_id_1", 1, "USD");
  assert_int_equal(isfull_wlq(&wlq),0);
  assert_int_equal(isempty_wlq(&wlq),0);
}

void test_isempty_wlq(void **state){
  win_loss_queue_t wlq;
  init_wl_Queue(&wlq);

  assert_int_equal(isempty_wlq(&wlq),1);

  add_to_wlq(&wlq,  "request_id_1",	 100.0, 1,
			 "bid_id_1", 1, "USD");
  assert_int_equal(isempty_wlq(&wlq),0);

  dequeue_wlq(&wlq);
  assert_int_equal(isempty_wlq(&wlq),1);

  add_to_wlq(&wlq,  "request_id_2",	 100.0, 1,
			 "bid_id_1", 1, "USD");
  add_to_wlq(&wlq,  "request_id_2",	 100.0, 1,
			 "bid_id_2", 1, "USD");

  dequeue_wlq(&wlq);
  assert_int_equal(isempty_wlq(&wlq),0);

  }

typedef struct add_to_wlq_test_table{
  char * request_id;
  double winning_bid;
  int client_auction_enabled;
  char *bid_id;
  int reason;
  char *bid_currency_code;
}add_to_wlq_test_table_t;

static add_to_wlq_test_table_t add_to_wlq_arr[] ={
  {"request_id_1",100,1,"bid_id_1",1,"USD"},
  {"request_id_2",100.1,1,"bid_id_2",1,"USD1"},
  {"request_id_3",100.2,1,"bid_id_3",1,"USD2"},
  {"request_id_4",100.3,1,"bid_id_4",1,"USD3"},
  {"request_id_5",100.4,1,"bid_id_5",1,"USD4"},
  {"request_id_6",100.5,1,"bid_id_6",1,"USD5"},
  {"request_id_7",100.6,1,"bid_id_7",1,"USD6"},
  {"request_id_8",100.7,1,"bid_id_8",1,"USD7"},
  {"request_id_9",100.8,1,"bid_id_5",1,"USD8"},
  {"request_id_10",100.3,1,"bid_id_4",1,"USD9"},
  {"request_id_11",100.4,1,"bid_id_5",1,"ABC1"},
  {"request_id_12",100.3,1,"bid_id_4",1,"ABC2"},
  {"request_id_13",100.4,1,"bid_id_5",1,"USD3"},
};

void test_add_to_wlq(void **state){
  int i = 0;
  campaign_winloss_info_t* campaign_info_ptr = NULL;
  win_loss_queue_t wlq;
  int j = 0;
  init_wl_Queue(&wlq);
  for( j = 0; j<3;j++){
	for(i = 0; i< WIN_LOSS_QUEUE_SIZE;i++){
	  add_to_wlq(&wlq,
				 add_to_wlq_arr[i].request_id,
				 add_to_wlq_arr[i].winning_bid,
				 add_to_wlq_arr[i].client_auction_enabled,
				 add_to_wlq_arr[i].bid_id,
				 add_to_wlq_arr[i].reason,
				 add_to_wlq_arr[i].bid_currency_code);
	}
	//now queue should be full
	assert_int_equal(isfull_wlq(&wlq),1);

	//adding more should not crash
	add_to_wlq(&wlq,
			   add_to_wlq_arr[i].request_id,
			   add_to_wlq_arr[i].winning_bid,
			   add_to_wlq_arr[i].client_auction_enabled,
			   add_to_wlq_arr[i].bid_id,
			   add_to_wlq_arr[i].reason,
			   add_to_wlq_arr[i].bid_currency_code);
	i++;
	add_to_wlq(&wlq,
			   add_to_wlq_arr[i].request_id,
			   add_to_wlq_arr[i].winning_bid,
			   add_to_wlq_arr[i].client_auction_enabled,
			   add_to_wlq_arr[i].bid_id,
			   add_to_wlq_arr[i].reason,
			   add_to_wlq_arr[i].bid_currency_code);

	//now verify the data
	for(i = 0; i< WIN_LOSS_QUEUE_SIZE;i++){
	  campaign_info_ptr = dequeue_wlq(&wlq);
	  assert_non_null(campaign_info_ptr);
	
	  assert_string_equal(campaign_info_ptr->request_id, add_to_wlq_arr[i].request_id);
	  //  assert_float_equal(campaign_info_ptr->winning_bid, add_to_wlq_arr[i].winning_bid,2);
	  assert_int_equal(campaign_info_ptr->client_auction_enabled, add_to_wlq_arr[i].client_auction_enabled);
	  assert_string_equal(campaign_info_ptr->bid_id[0], add_to_wlq_arr[i].bid_id);
	  assert_int_equal(campaign_info_ptr->reasons[0], add_to_wlq_arr[i].reason);
	  assert_string_equal(campaign_info_ptr->bid_currency_code, add_to_wlq_arr[i].bid_currency_code);
	}
	campaign_info_ptr = dequeue_wlq(&wlq);
	assert_null(campaign_info_ptr);
  }
}
void test_dequeue_wlq(void**state){
  win_loss_queue_t wlq;
  init_wl_Queue(&wlq);
  campaign_winloss_info_t* campaign_info_ptr = dequeue_wlq(&wlq);
  assert_null(campaign_info_ptr);

  add_to_wlq(&wlq,  "request_id_2",	 100.0, 1,
			 "bid_id_1", 1, "USD");
  campaign_info_ptr = dequeue_wlq(&wlq);
  assert_non_null(campaign_info_ptr);
}
void test_get_obj_with_same_request_inqueue(void **state){
  int i = 0;
  campaign_winloss_info_t* campaign_info_ptr = NULL;
  win_loss_queue_t wlq;
  init_wl_Queue(&wlq);
  
  for(i = 0; i< WIN_LOSS_QUEUE_SIZE;i++){
	add_to_wlq(&wlq,
			   add_to_wlq_arr[i].request_id,
			   add_to_wlq_arr[i].winning_bid,
			   add_to_wlq_arr[i].client_auction_enabled,
			   add_to_wlq_arr[i].bid_id,
			   add_to_wlq_arr[i].reason,
			   add_to_wlq_arr[i].bid_currency_code);
	campaign_info_ptr = get_obj_with_same_request_inqueue(add_to_wlq_arr[i].request_id,&wlq);
	assert_non_null(campaign_info_ptr);
  }
  dequeue_wlq(&wlq);
  dequeue_wlq(&wlq);

  for(i = 2;i <WIN_LOSS_QUEUE_SIZE;i++){
	campaign_info_ptr = get_obj_with_same_request_inqueue(add_to_wlq_arr[i].request_id,&wlq);
	assert_non_null(campaign_info_ptr);
  }

  dequeue_wlq(&wlq);

  dequeue_wlq(&wlq);
  for(i = 4;i <WIN_LOSS_QUEUE_SIZE;i++){
	campaign_info_ptr = get_obj_with_same_request_inqueue(add_to_wlq_arr[i].request_id,&wlq);
	assert_non_null(campaign_info_ptr);
  }

  for(i = 0; i< 4;i++){
	add_to_wlq(&wlq,
			   add_to_wlq_arr[i].request_id,
			   add_to_wlq_arr[i].winning_bid,
			   add_to_wlq_arr[i].client_auction_enabled,
			   add_to_wlq_arr[i].bid_id,
			   add_to_wlq_arr[i].reason,
			   add_to_wlq_arr[i].bid_currency_code);
	campaign_info_ptr = get_obj_with_same_request_inqueue(add_to_wlq_arr[i].request_id,&wlq);
	assert_non_null(campaign_info_ptr);
  }

  dequeue_wlq(&wlq);
  dequeue_wlq(&wlq);
  dequeue_wlq(&wlq);
  dequeue_wlq(&wlq);
  
  for(i = 2; i < 4;i++){
	campaign_info_ptr = get_obj_with_same_request_inqueue(add_to_wlq_arr[i].request_id,&wlq);
	assert_non_null(campaign_info_ptr);
  }
}
void test_init_winloss_table(void **stat){
  win_loss_table_t *wlt = NULL;
  init_winloss_table(&wlt);
  assert_non_null(wlt);
  assert_non_null(wlt->wlt_data_arr);
  assert_int_equal(wlt->capacity, INITIAL_WIN_LOSS_TABLE_LEN);
  assert_int_equal(wlt->use_count, 0);
  free_winloss_table(&wlt);
  assert_null(wlt);
}
void test_get_campaign_winloss_info(void **stat){
  win_loss_table_t *wlt = NULL;
  init_winloss_table(&wlt);

  //add some campaign and related data
}
typedef struct add_campaign_winloss_info_test{
  int camp_id;
  char *request_id;
  int reason_for_filtering;
  char* bid_id;
  double winning_bid;
  int client_auction_enabled;
  char* bid_currency_code;
}add_campaign_winloss_info_test_t;
add_campaign_winloss_info_test_t add_campaign_info_arr[]={
  {//0
	.camp_id = 100,
	.request_id = "request_1",
	.reason_for_filtering = 10,
	.bid_id = "bid_id1",
	.winning_bid = 100.1,
	.client_auction_enabled = 1,
	.bid_currency_code = "USD",
  },
  {//1
	.camp_id = 100,
	.request_id = "request_2",
	.reason_for_filtering = 11,
	.bid_id = "bid_id2",
	.winning_bid = 100.1,
	.client_auction_enabled = 1,
	.bid_currency_code = "USD",
  },
  {//2
	.camp_id = 100,
	.request_id = "request_3",
	.reason_for_filtering = 10,
	.bid_id = "bid_id3",
	.winning_bid = 100.1,
	.client_auction_enabled = 1,
	.bid_currency_code = "USD",
  },
  {//3
	.camp_id = 100,
	.request_id = "request_4",
	.reason_for_filtering = 10,
	.bid_id = "bid_id4",
	.winning_bid = 100.1,
	.client_auction_enabled = 1,
	.bid_currency_code = "USD",
  },
  {//4
	.camp_id = 101,
	.request_id = "request_10",
	.reason_for_filtering = 10,
	.bid_id = "bid_id10",
	.winning_bid = 100.1,
	.client_auction_enabled = 1,
	.bid_currency_code = "USD",
  },
  {//5
	.camp_id = 101,
	.request_id = "request_11",
	.reason_for_filtering = 10,
	.bid_id = "bid_id11",
	.winning_bid = 100.1,
	.client_auction_enabled = 1,
	.bid_currency_code = "USD",
  },
  {//6
	.camp_id = 101,
	.request_id = "request_12",
	.reason_for_filtering = 10,
	.bid_id = "bid_id12",
	.winning_bid = 100.1,
	.client_auction_enabled = 1,
	.bid_currency_code = "USD",
	},
  {//7
	.camp_id = 102,
	.request_id = "request_20",
	.reason_for_filtering = 10,
	.bid_id = "bid_id20",
	.winning_bid = 100.1,
	.client_auction_enabled = 1,
	.bid_currency_code = "USD",
	},
    {//8
	.camp_id = 102,
	.request_id = "request_21",
	.reason_for_filtering = 10,
	.bid_id = "bid_id21",
	.winning_bid = 100.1,
	.client_auction_enabled = 1,
	.bid_currency_code = "USD",
	},
  
};

void test_add_campaign_info(void ** stat){
  win_loss_table_t *wlt = NULL;
  init_winloss_table(&wlt);
  int i = 0;
  for(i = 0;i < 7 ;i++){
	  add_campaign_winloss_info(wlt,
							add_campaign_info_arr[i].camp_id,
							add_campaign_info_arr[i].request_id,
							add_campaign_info_arr[i].reason_for_filtering,
							add_campaign_info_arr[i].bid_id,
							add_campaign_info_arr[i].winning_bid,
							add_campaign_info_arr[i].client_auction_enabled,
							add_campaign_info_arr[i].bid_currency_code);
  }
  //dequeue request as per expectation
  campaign_winloss_info_t * campaign_info_ptr =  get_campaign_winloss_info(wlt , 101);
  assert_non_null(campaign_info_ptr);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[4].request_id);
  campaign_info_ptr = get_campaign_winloss_info(wlt , 101);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[5].request_id);
  campaign_info_ptr = get_campaign_winloss_info(wlt , 100);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[0].request_id);
  campaign_info_ptr = get_campaign_winloss_info(wlt , 100);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[1].request_id);

  for(i = 7;i < 9 ;i++){
	add_campaign_winloss_info(wlt,
							add_campaign_info_arr[i].camp_id,
							add_campaign_info_arr[i].request_id,
							add_campaign_info_arr[i].reason_for_filtering,
							add_campaign_info_arr[i].bid_id,
							add_campaign_info_arr[i].winning_bid,
							add_campaign_info_arr[i].client_auction_enabled,
							add_campaign_info_arr[i].bid_currency_code);
  }
  campaign_info_ptr = get_campaign_winloss_info(wlt , 102);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[7].request_id);

  campaign_info_ptr = get_campaign_winloss_info(wlt , 100);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[2].request_id);
  campaign_info_ptr = get_campaign_winloss_info(wlt , 101);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[6].request_id);
  campaign_info_ptr = get_campaign_winloss_info(wlt , 102);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[8].request_id);
  for(i = 0;i < 2 ;i++){
	add_campaign_winloss_info(wlt,
					  add_campaign_info_arr[0].camp_id,
					  add_campaign_info_arr[0].request_id,
					  add_campaign_info_arr[0].reason_for_filtering,
					  add_campaign_info_arr[0].bid_id,
					  add_campaign_info_arr[0].winning_bid,
					  add_campaign_info_arr[0].client_auction_enabled,
					  add_campaign_info_arr[0].bid_currency_code);
  }
  campaign_info_ptr = get_campaign_winloss_info(wlt , 100);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[3].request_id);

  campaign_info_ptr = get_campaign_winloss_info(wlt , 100);
  assert_string_equal(campaign_info_ptr->request_id, add_campaign_info_arr[0].request_id);
  
}
currency_xrate_map_t test_currency_xrate_map[] = {
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	}
};
static adserver_config_params_t adserver_config_params_local;
typedef struct filter_reason_mapping {
	ad_campaign_list_setings_t  ad_campaign_list_setings;
	int mapped_reason_for_filter;
}filter_reason_mapping_t;
static filter_reason_mapping_t filter_reason_mapping_table[] ={
  {//0
    .ad_campaign_list_setings.reason_for_filtering = UNFILTERED,
    .mapped_reason_for_filter = WLN_UNFILTERED
  },
	{//1
		.ad_campaign_list_setings.reason_for_filtering = LANDING_PAGE_FILTER,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_ADV_EXCLUSION
	},
	{//2
	  .ad_campaign_list_setings.reason_for_filtering = 23, //unmapped filetr

	},
	{//3
		.ad_campaign_list_setings.reason_for_filtering = FILTER_TIMED_OUT,
		.mapped_reason_for_filter = WLN_IMPRESSION_OPPORTUNITY_EXPIRED
	},
	{//4
		.ad_campaign_list_setings.reason_for_filtering = FILTER_ZERO_BID,
		.mapped_reason_for_filter = WLN_ZERO_BID
	},
	{//5
		.ad_campaign_list_setings.reason_for_filtering = FILTER_REQUEST_ID_MISMATCH,
		.mapped_reason_for_filter = WLN_INVALID_BID_RESPONSE
	},
	{//6
		.ad_campaign_list_setings.reason_for_filtering = FILTER_ABNORMAL_ECPM,
		.mapped_reason_for_filter = WLN_INVALID_BID_RESPONSE
	},
	{//7
		.ad_campaign_list_setings.reason_for_filtering = FILTER_LOW_BID,
		.mapped_reason_for_filter = WLN_BID_BELOW_AUCTION_FLOOR
	},
	{//8
		.ad_campaign_list_setings.reason_for_filtering = FILTER_INCOMPLETE_RESPONSE,
		.mapped_reason_for_filter = WLN_INVALID_BID_RESPONSE
	},
	{//9
		.ad_campaign_list_setings.reason_for_filtering = PMP_FLOOR_FILTER,
		.mapped_reason_for_filter = WLN_BID_BELOW_DEAL_FLOOR
	},
	{//10
		.ad_campaign_list_setings.reason_for_filtering = FILTER_CREATIVE_ID_NOT_AVAILABLE,
		.mapped_reason_for_filter = WLN_MINIMUM_CREATIVE_APPROVAL_DATA
	},
	{//11
		.ad_campaign_list_setings.reason_for_filtering = FILTER_CREATIVE_ID_BLOCKED,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_DISAPPROVED_EXCH
	},
	{//12
		.ad_campaign_list_setings.reason_for_filtering = FILTER_BID_PRICE_DECRYPTION_FAILURE,
		.mapped_reason_for_filter = WLN_INVALID_BID_RESPONSE
	},
	{//13
		.ad_campaign_list_setings.reason_for_filtering = UNCATEGORIZED_ADVERTISER_FILTER,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_CATEGORY_EXCLUSION
	},
	{//14
		.ad_campaign_list_setings.reason_for_filtering = REPEAT_IMPRESSION_ON_PAGE,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_GENERAL
	},
	{//15
		.ad_campaign_list_setings.reason_for_filtering = FILTER_TYPE_UNSECURE_RESPONSE,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_NOT_SECURE
	},
	{//16
		.ad_campaign_list_setings.reason_for_filtering = BIDDING_ECPM_FILTER,
		.mapped_reason_for_filter = WLN_BID_BELOW_AUCTION_FLOOR
	},
	{//17
		.ad_campaign_list_setings.reason_for_filtering = BID_LESS_THAN_MIN_PUB_ECPM_FILTER,
		.mapped_reason_for_filter = WLN_BID_BELOW_AUCTION_FLOOR
	},
	{//18
		.ad_campaign_list_setings.reason_for_filtering = FILTER_BIDS_WITHOUT_LANDING_PAGE_URL,
		.mapped_reason_for_filter = WLN_MINIMUM_CREATIVE_APPROVAL_DATA
	},
	{//19
		.ad_campaign_list_setings.reason_for_filtering = DEAL_WHITE_LIST_FILTER,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_NOT_ALLOWED_INPMP_DEAL
	},
	{//20
		.ad_campaign_list_setings.reason_for_filtering = FILTER_INVALID_CURRENCY_CODE,
		.mapped_reason_for_filter = WLN_INVALID_BID_RESPONSE
	},
	{//21
		.ad_campaign_list_setings.reason_for_filtering = FILTER_MAX_CREATIVE_SIZE,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_SIZE_EXCEED
	},
	{//22
		.ad_campaign_list_setings.reason_for_filtering = FILTER_ADVT_DOMAIN_CATEGORY_ID,
		.mapped_reason_for_filter = WLN_MALFORMED_RESPONSE
	},
	{//23
		.ad_campaign_list_setings.reason_for_filtering = FILTER_RM_CREATIVE_ATTR_BLOCKED,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_CATEGORY_ATTR_EXCLUSION
	},
	{//24
		.ad_campaign_list_setings.reason_for_filtering = FILTER_RM_CRTYPE_BLOCKED,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_ADTYPE_EXCLUSION
	},
	{//25
		.ad_campaign_list_setings.reason_for_filtering = FILTER_RM_BLOCKLIST_STRICT_CHECK,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_GENERAL
	},
	{//26
		.ad_campaign_list_setings.reason_for_filtering = GLOBAL_FILTER_CREATIVE_ID_BLOCKED,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_CATEGORY_EXCLUSION
	},
	{//27
		.ad_campaign_list_setings.reason_for_filtering = POST_BLOCK_OPEN_EXCHANGE,
		.mapped_reason_for_filter = WLN_INVALID_DEAL_ID
	},
	{//28
		.ad_campaign_list_setings.reason_for_filtering = FILTER_VIDEO_ATTR_MIMETYPE,
		.mapped_reason_for_filter = WLN_INVALID_BID_RESPONSE
	},
	{//29
		.ad_campaign_list_setings.reason_for_filtering = GLOBAL_PUB_PREFERRED_FILTER_CREATIVE_ID_BLOCKED,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_GENERAL
	},
	{//30
		.ad_campaign_list_setings.reason_for_filtering = GLOBAL_BUYER_BLOCKLIST_FILTER,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_GENERAL
	},
	{//31
		.ad_campaign_list_setings.reason_for_filtering = CHANNEL_PARTNER_BUYER_BLOCKLIST_FILTER,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_GENERAL
	},
	{//32
		.ad_campaign_list_setings.reason_for_filtering = PUB_LEVEL_BUYER_BLOCKLIST_FILTER,
		.mapped_reason_for_filter = WLN_CREATIVE_FILTERED_GENERAL
	}
};
typedef struct update_rtb_winloss_information_table{
	fte_additional_params_t fte_additional_parameters;
	ad_server_additional_params_t additional_params; 
	publisher_site_ad_campaign_list_t adcampaigns[2];
	rt_request_params_t rt_request_params;
	int rt_response_count;
	rt_response_params_t rt_response_params[2];
	selected_campaign_attribute_t selected_camp;
	win_loss_table_t *wlt;
	int selected_campaign;
	double bidding_ecpm;
	//expected
	int expected_win_loss_data[2] ; //1 yes 0 no
	campaign_winloss_info_t exp_cmp_winloss_info[2] ;
	int expected_auction_type[2];
	
}update_rtb_winloss_information_table_t;
static update_rtb_winloss_information_table_t update_rtb_winloss_information_arr[] = {
	{//0
		.fte_additional_parameters.currency_count = 40,
		.fte_additional_parameters.currency_xrate_map = test_currency_xrate_map,
		.additional_params.adserver_config_params = &adserver_config_params_local,
		.adcampaigns[0].ad_campaign_list_setings = &(filter_reason_mapping_table[0].ad_campaign_list_setings),
		.adcampaigns[1].ad_campaign_list_setings = &(filter_reason_mapping_table[1].ad_campaign_list_setings),
		.rt_request_params.request_url_params.request_id[0] = "0-0",
		.rt_request_params.request_url_params.request_id[0] = "0-1",
		.rt_response_count = 2,
		.rt_response_params[0].send_winloss_info = 0,
		.rt_response_params[1].send_winloss_info = 1,
		.rt_response_params[1].open_auction_type = AUCTION_TYPE_SECOND_PRICE,
		.rt_response_params[0].campaign_index = 0,
		.rt_response_params[1].campaign_index = 1,
		.rt_response_params[0].campaign_id = 100,
		.rt_response_params[1].campaign_id = 101,
		.rt_response_params[0].currency_id = 1,
		.rt_response_params[1].currency_id = 1,
		.rt_response_params[0].rt_req_id_index = 0,
		.rt_response_params[1].rt_req_id_index = 0,
		.rt_response_params[0].bid_response_params.transaction_id = "0",
		.rt_response_params[1].bid_response_params.transaction_id = "1",
		.selected_camp.campaign_price = 100,
		.selected_campaign  = 0,
		.bidding_ecpm = 50,

		//expected
		.expected_win_loss_data[0] = 0,
		.expected_win_loss_data[1] = 1,
		.exp_cmp_winloss_info[1].request_id = "0-1",
		.exp_cmp_winloss_info[1].reasons[0] = 10,
		.exp_cmp_winloss_info[1].winning_bid = 100,
		.exp_cmp_winloss_info[1].client_auction_enabled = 1,
	},
	{//1
		.fte_additional_parameters.currency_count = 40,
		.fte_additional_parameters.currency_xrate_map = test_currency_xrate_map,
		.additional_params.adserver_config_params = &adserver_config_params_local,
		.adcampaigns[0].ad_campaign_list_setings = &(filter_reason_mapping_table[0].ad_campaign_list_setings),
		.adcampaigns[1].ad_campaign_list_setings = &(filter_reason_mapping_table[1].ad_campaign_list_setings),
		.rt_request_params.request_url_params.request_id[0] = "0-0",
		.rt_request_params.request_url_params.request_id[0] = "0-1",
		.rt_response_count = 2,
		.rt_response_params[0].send_winloss_info = 0,
		.rt_response_params[1].send_winloss_info = 1,
		.rt_response_params[1].open_auction_type = AUCTION_TYPE_FIRST_PRICE,
		.rt_response_params[0].campaign_index = 0,
		.rt_response_params[1].campaign_index = 1,
		.rt_response_params[0].campaign_id = 100,
		.rt_response_params[1].campaign_id = 101,
		.rt_response_params[0].currency_id = 1,
		.rt_response_params[1].currency_id = 1,
		.rt_response_params[0].rt_req_id_index = 0,
		.rt_response_params[1].rt_req_id_index = 0,
		.rt_response_params[0].bid_response_params.transaction_id = "0",
		.rt_response_params[1].bid_response_params.transaction_id = "1",
		.selected_camp.campaign_price = 100,
		.selected_campaign  = -1,
		.bidding_ecpm = 50,

		//expected
		.expected_win_loss_data[0] = 0,
		.expected_win_loss_data[1] = 1,
		.exp_cmp_winloss_info[1].request_id = "0-1",
		.exp_cmp_winloss_info[1].reasons[0] = 10,
		.exp_cmp_winloss_info[1].winning_bid = 0,
		.exp_cmp_winloss_info[1].client_auction_enabled = 0,
	},
	{//2
		.fte_additional_parameters.currency_count = 40,
		.fte_additional_parameters.currency_xrate_map = test_currency_xrate_map,
		.additional_params.adserver_config_params = &adserver_config_params_local,
		.adcampaigns[0].ad_campaign_list_setings = &(filter_reason_mapping_table[0].ad_campaign_list_setings),
		.adcampaigns[1].ad_campaign_list_setings = &(filter_reason_mapping_table[1].ad_campaign_list_setings),
		.rt_request_params.request_url_params.request_id[0] = "0-0",
		.rt_request_params.request_url_params.request_id[1] = "0-1",
		.rt_response_count = 2,
		.rt_response_params[0].send_winloss_info = 0,
		.rt_response_params[1].send_winloss_info = 1,
		.rt_response_params[1].open_auction_type = AUCTION_TYPE_SECOND_PRICE,
		.rt_response_params[0].campaign_index = 0,
		.rt_response_params[1].campaign_index = 1,
		.rt_response_params[0].campaign_id = 100,
		.rt_response_params[1].campaign_id = 101,
		.rt_response_params[0].currency_id = 1,
		.rt_response_params[1].currency_id = 1,
		.rt_response_params[0].rt_req_id_index = 0,
		.rt_response_params[1].rt_req_id_index = 0,
		.rt_response_params[0].bid_response_params.transaction_id = "0",
		.rt_response_params[1].bid_response_params.transaction_id = "1",
		.selected_camp.campaign_price = 100,
		.selected_campaign  = 1,
		.bidding_ecpm = 50,

		//expected
		.expected_win_loss_data[0] = 0,
		.expected_win_loss_data[1] = 1,
		.exp_cmp_winloss_info[1].request_id = "0-1",
		.exp_cmp_winloss_info[1].reasons[0] = 10,
		.exp_cmp_winloss_info[1].winning_bid = 100,
		.exp_cmp_winloss_info[1].client_auction_enabled = 1,
	},
	{//3
		.fte_additional_parameters.currency_count = 40,
		.fte_additional_parameters.currency_xrate_map = test_currency_xrate_map,
		.additional_params.adserver_config_params = &adserver_config_params_local,
		.adcampaigns[0].ad_campaign_list_setings = &(filter_reason_mapping_table[0].ad_campaign_list_setings),
		.adcampaigns[1].ad_campaign_list_setings = &(filter_reason_mapping_table[4].ad_campaign_list_setings),
		.rt_request_params.request_url_params.request_id[0] = "0-0",
		.rt_request_params.request_url_params.request_id[0] = "0-1",
		.rt_response_count = 2,
		.rt_response_params[0].send_winloss_info = 0,
		.rt_response_params[1].send_winloss_info = 1,
		.rt_response_params[1].open_auction_type = AUCTION_TYPE_FIRST_PRICE,
		.rt_response_params[0].campaign_index = 0,
		.rt_response_params[1].campaign_index = 1,
		.rt_response_params[0].campaign_id = 100,
		.rt_response_params[1].campaign_id = 101,
		.rt_response_params[0].currency_id = 1,
		.rt_response_params[1].currency_id = 1,
		.rt_response_params[0].rt_req_id_index = 0,
		.rt_response_params[1].rt_req_id_index = 0,
		.rt_response_params[0].bid_response_params.transaction_id = "0",
		.rt_response_params[1].bid_response_params.transaction_id = "1",
		.selected_camp.campaign_price = 100,
		.selected_campaign  = -1,
		.bidding_ecpm = 50,

		//expected
		.expected_win_loss_data[0] = 0,
		.expected_win_loss_data[1] = 0,
		.exp_cmp_winloss_info[1].request_id = "0-1",
		.exp_cmp_winloss_info[1].reasons[0] = 10,
		.exp_cmp_winloss_info[1].winning_bid = 0,
		.exp_cmp_winloss_info[1].client_auction_enabled = 0,
	},

};
void test_update_rtb_winloss_information(void **stat){
	init_pm_rff_to_ortb_rff_map();
	campaign_winloss_info_t * cmp_winloss_info = NULL;
	int i = 0;
	int j = 0;
	for(i = 0;i < sizeof(update_rtb_winloss_information_arr)/sizeof(update_rtb_winloss_information_table_t);i++){
		init_winloss_table(& update_rtb_winloss_information_arr[i].wlt) ;
		update_rtb_winloss_information(
			& update_rtb_winloss_information_arr[i].fte_additional_parameters,
			& update_rtb_winloss_information_arr[i].additional_params, 
			update_rtb_winloss_information_arr[i].adcampaigns,
			& update_rtb_winloss_information_arr[i].rt_request_params,
			update_rtb_winloss_information_arr[i].rt_response_count,
			update_rtb_winloss_information_arr[i].rt_response_params,
			& update_rtb_winloss_information_arr[i].selected_camp,
			update_rtb_winloss_information_arr[i].wlt,
			update_rtb_winloss_information_arr[i].selected_campaign,
			update_rtb_winloss_information_arr[i].bidding_ecpm
			);
		for( j = 0; j < 2;j++){ 
			cmp_winloss_info = get_campaign_winloss_info(update_rtb_winloss_information_arr[i].wlt,
														 update_rtb_winloss_information_arr[i].rt_response_params[j].campaign_id);
			if(update_rtb_winloss_information_arr[i].expected_win_loss_data[j] == 1){
				assert_non_null(cmp_winloss_info);
				//assert_float_equal(cmp_winloss_info->winning_bid, update_rtb_winloss_information_arr[i].exp_cmp_winloss_info[j].winning_bid,4);
				assert_int_equal(update_rtb_winloss_information_arr[i].exp_cmp_winloss_info[j].client_auction_enabled, cmp_winloss_info->client_auction_enabled);
				
			}else{
			  assert_null(cmp_winloss_info);
			}
		}
		
		free_winloss_table(& update_rtb_winloss_information_arr[i].wlt);
	}
	//run test to verify filter mapping
	update_rtb_winloss_information_table_t *update_wln_ptr = update_rtb_winloss_information_arr + 0;
	init_winloss_table(& update_wln_ptr->wlt) ;
	for( i = 0;i<sizeof(filter_reason_mapping_table)/sizeof(filter_reason_mapping_t);i++){
	  update_wln_ptr->adcampaigns[1].ad_campaign_list_setings = &(filter_reason_mapping_table[i].ad_campaign_list_setings);
	  update_rtb_winloss_information(
					 & update_wln_ptr->fte_additional_parameters,
					 & update_wln_ptr->additional_params, 
					 update_wln_ptr->adcampaigns,
					 & update_wln_ptr->rt_request_params,
					 update_wln_ptr->rt_response_count,
					 update_wln_ptr->rt_response_params,
					 & update_wln_ptr->selected_camp,
					 update_wln_ptr->wlt,
					 update_wln_ptr->selected_campaign,
					 update_wln_ptr->bidding_ecpm
					 );
	  cmp_winloss_info = get_campaign_winloss_info(update_wln_ptr->wlt,
						       update_wln_ptr->rt_response_params[1].campaign_id);
	  if ( filter_reason_mapping_table[i].mapped_reason_for_filter == WLN_ZERO_BID){
	    assert_null(cmp_winloss_info);
	    //pm_rff_to_ortb_rff_map[UNFILTERED] = WLN_UNFILTERED
	  }else if (pm_rff_to_ortb_rff_map[filter_reason_mapping_table[i].ad_campaign_list_setings.reason_for_filtering] == WLN_UNFILTERED){
	    assert_non_null(cmp_winloss_info);
	    int reason = (update_wln_ptr->adcampaigns[1].campaign_price > update_wln_ptr->selected_camp.campaign_price )?
	      WLN_BID_BELOW_AUCTION_FLOOR:WLN_LOST_TO_HIGHER_BID;
	    assert_int_equal(cmp_winloss_info->reasons[0], reason);
	  
	  }else {
	    assert_non_null(cmp_winloss_info);
	    assert_int_equal(cmp_winloss_info->reasons[0], filter_reason_mapping_table[i].mapped_reason_for_filter);
	  }
	}
}
int main()
{
	const struct CMUnitTest tests[] = {
	  cmocka_unit_test(test_init_wl_Queue),
	  cmocka_unit_test(test_isempty_wlq),
	  cmocka_unit_test(test_isfull_wlq),
	  cmocka_unit_test(test_add_to_wlq),
	  cmocka_unit_test(test_dequeue_wlq),
	  cmocka_unit_test(test_get_obj_with_same_request_inqueue),
	  cmocka_unit_test(test_init_winloss_table),
	  cmocka_unit_test(test_get_campaign_winloss_info),
	  cmocka_unit_test(test_add_campaign_info),
	  cmocka_unit_test(test_update_rtb_winloss_information)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
