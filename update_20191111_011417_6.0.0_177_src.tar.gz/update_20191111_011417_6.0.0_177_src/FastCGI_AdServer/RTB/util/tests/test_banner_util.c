#include <stddef.h>
#include <setjmp.h>
#include <stdarg.h>
#include <cmocka.h>
#include <stdio.h>
#include <string.h>

#include "banner_util.h"
#include "error.h"

static void test_init_btype_info__all_testcases(void **state)
{
	(void) state;
	btype_info_t btype_info;
	const uint64_t expected_btype_values_map = 0;
	init_btype_info(&btype_info);
	assert_memory_equal(&expected_btype_values_map,
						&(btype_info.btype_values_map),
						sizeof(expected_btype_values_map));
	assert_int_equal(0, btype_info.btype_egress_json_len);
	assert_string_equal("", btype_info.btype_egress_json);
}

typedef struct testcase_parse_btype_param_
{
	int test_case_id;
	struct test_input1_ {
		const char * const url_param;
		btype_info_t * const btype_info;
	} const test_input;

	struct expected_output1_ {
		btype_info_t  btype_info;
	} const expected_output;

} testcase_parse_btype_param_t;

static btype_info_t global_btype_info;
static testcase_parse_btype_param_t testcases_parse_btype_param[] = {
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "1,2,3,4",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0xf,
			}
		},
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "4,3,2,1",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0xf,
			}
		},
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "3",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0x4,
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "3,1",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0x5,
			}
		}
	},
	{ /* should ignore out of range values */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "0,1,5,2",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0x3,
			}
		}
	},
	{ /* should ignore negative values */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "-1,2,3,4",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0xe,
			}
		}
	},
	{ /* strings not starting with number, 2c => 2 */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "1a,2b,3c,4d",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0xf,
			}
		}
	},
	{ /* should ignore non numeric values e.g abc, abc2 */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "a1,bb,3,4",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0xc,
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0x0,
			}
		}
	},
	{ /* Repeated values */
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = "1,1,4,3,3,4,1,3", /* 1,3,4 */
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0xd,
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = ",,1,,2,,3,,4,,",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0xf,
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = ",",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0x0,
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.url_param = ",,,,",
			.btype_info = &global_btype_info,
		},
		.expected_output = {
			.btype_info = {
				.btype_values_map = 0x0,
			}
		}
	},
};

#define POISON1 0x5555555555555555
#define POISON_CHAR '`'
btype_info_t btype_info_poison;
static void test_parse_btype_param__all_testcases(void **state)
{
	(void) state;
	const int testcase_count = sizeof(testcases_parse_btype_param)/sizeof(testcase_parse_btype_param_t);
	testcase_parse_btype_param_t * const testcases = testcases_parse_btype_param;
	int i = 0, rc = 0;
	for(i = 0; i < testcase_count; i++) {
		memset(&btype_info_poison, POISON_CHAR, sizeof(btype_info_t));
		memset(testcases[i].test_input.btype_info, POISON_CHAR, sizeof(btype_info_t));
		testcases[i].test_input.btype_info->btype_values_map = POISON1;
		printf("Executing Test case id %d (%d) for parse_btype_param.\n", i, testcases[i].test_case_id);
		rc = parse_btype_param(testcases[i].test_input.url_param,
							   testcases[i].test_input.btype_info);
		assert_int_equal(ADS_ERROR_SUCCESS, rc);
		assert_memory_equal(&(testcases[i].expected_output.btype_info.btype_values_map),
							&(testcases[i].test_input.btype_info->btype_values_map),
							sizeof(testcases[i].expected_output.btype_info.btype_values_map));
		memset(&(testcases[i].test_input.btype_info->btype_values_map),
			   POISON_CHAR,
			   sizeof(testcases[i].test_input.btype_info->btype_values_map));
		assert_memory_equal(&btype_info_poison,
							testcases[i].test_input.btype_info,
							sizeof(btype_info_t));
	}
}


typedef struct testcase_form_btype_json_str_
{
	int test_case_id;
	struct test_input2_ {
		btype_info_t btype_info;
	} test_input;

	struct expected_output2_ {
		const btype_info_t btype_info;
	} const expected_output;
} testcase_form_btype_json_str_t;

testcase_form_btype_json_str_t testcases_form_btype_json_str[] = {
	{
		.test_case_id = __LINE__,
		.test_input = {
			.btype_info = {
				.btype_values_map = 0xf,
			}
		},
		.expected_output = {
			.btype_info = {
#define STR "[1,2,3,4]"
				.btype_egress_json = STR,
				.btype_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.btype_info = {
				.btype_values_map = 0x0,
			}
		},
		.expected_output = {
			.btype_info = {
#define STR ""
				.btype_egress_json = STR,
				.btype_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.btype_info = {
				.btype_values_map = 0x9,
			}
		},
		.expected_output = {
			.btype_info = {
#define STR "[1,4]"
				.btype_egress_json = STR,
				.btype_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.btype_info = {
				.btype_values_map = 0x2,
			}
		},
		.expected_output = {
			.btype_info = {
#define STR "[2]"
				.btype_egress_json = STR,
				.btype_egress_json_len = strlen(STR)
#undef STR
			}
		}
	},
	{
		.test_case_id = __LINE__,
		.test_input = {
			.btype_info = {
				.btype_values_map = 0xe,
			}
		},
		.expected_output = {
			.btype_info = {
#define STR "[2,3,4]"
				.btype_egress_json = STR,
				.btype_egress_json_len = strlen(STR)
#undef STR
			}
		}
	}
};


static void test_form_btype_json_str__all_testcases(void **state)
{
	(void) state;
	const int testcase_count = sizeof(testcases_form_btype_json_str) / sizeof(testcase_form_btype_json_str_t);
	testcase_form_btype_json_str_t * const testcases = testcases_form_btype_json_str;

	int i=0, rc = 0;
	for(i=0; i < testcase_count; i++) {
		memset(&btype_info_poison, POISON_CHAR, sizeof(btype_info_t));
		uint64_t backup_values_map = testcases[i].test_input.btype_info.btype_values_map;
		memset(&(testcases[i].test_input.btype_info), POISON_CHAR, sizeof(btype_info_t));
		testcases[i].test_input.btype_info.btype_values_map = backup_values_map;
		printf("Executing Test case id %d (%d) for form_btype_json_str.\n", i, testcases[i].test_case_id);
		rc = form_btype_json_str(&(testcases[i].test_input.btype_info));
		assert_int_equal(ADS_ERROR_SUCCESS, rc);

		assert_int_equal(testcases[i].expected_output.btype_info.btype_egress_json_len,
						 testcases[i].test_input.btype_info.btype_egress_json_len);

		if(testcases[i].expected_output.btype_info.btype_egress_json_len > 0) {
			assert_string_equal(testcases[i].expected_output.btype_info.btype_egress_json,
								testcases[i].test_input.btype_info.btype_egress_json);
			memset(testcases[i].test_input.btype_info.btype_egress_json,
				   POISON_CHAR,
				   testcases[i].expected_output.btype_info.btype_egress_json_len + 1);
			assert_memory_equal(&backup_values_map,
								&(testcases[i].test_input.btype_info.btype_values_map),
								sizeof(backup_values_map));
			testcases[i].test_input.btype_info.btype_values_map = btype_info_poison.btype_values_map;
			testcases[i].test_input.btype_info.btype_egress_json_len = btype_info_poison.btype_egress_json_len;
			assert_memory_equal(&btype_info_poison,
								&(testcases[i].test_input.btype_info),
								sizeof(btype_info_t));
		}
	}
}


int main()
{
	const struct CMUnitTest banner_util_tests[] = {
		cmocka_unit_test(test_init_btype_info__all_testcases),
		cmocka_unit_test(test_parse_btype_param__all_testcases),
		cmocka_unit_test(test_form_btype_json_str__all_testcases),
	};

	return cmocka_run_group_tests(banner_util_tests, NULL, NULL);
}
