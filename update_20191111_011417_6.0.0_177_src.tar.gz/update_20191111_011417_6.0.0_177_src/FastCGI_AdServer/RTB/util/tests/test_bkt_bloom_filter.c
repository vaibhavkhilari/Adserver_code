#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include <rt_types.h>
#include "bloom_filter.h"
#include "bkt_bloom_filter.h"
int gbl_log_level = L_DEBUG;
int bs_upper_bound(const char *element, const BKT_BLOOM *bkt_bloom_list[], int size);

int __wrap_char_counter(const char *str, char c) {
	check_expected(str);
	check_expected(c);
	return mock_type(int);
}

int __wrap_elog() {
	return 0;
}

int __wrap_convert_unicode_domain_to_punycode(const char *in_domain, char **out_domain) {
	check_expected(in_domain);
	char *tmp_str = mock_type(char*);
	(*out_domain) = (char*)malloc(strlen(tmp_str));
	strcpy((*out_domain), tmp_str);
	return mock_type(int);
}

void __wrap_tiger(word64 *str, word64 length, word64 res[3]) {
	res[0] = 0x0123456789ABCDEFLL;
	res[1] = 0xFEDCBA9876543210LL;
	res[2] = 0xF096A5B4C3B2E187LL;
}

typedef struct test_bs_upper_bound_inputs_t {
	char f_ele[MAX_BKT_BLOOM_ELEMENT_LEN+1][MAX_ALLOWED_BKT_BLOOMS];
	int blm_count;
	char ele_to_search[MAX_BKT_BLOOM_ELEMENT_LEN+1];
	int index_ret;
}test_bs_upper_bound_inputs;

void test_bs_upper_bound(test_bs_upper_bound_inputs *input) {
	int i, blm_index;
	BKT_BLOOM bkt_bloom_list[MAX_ALLOWED_BKT_BLOOMS];
	BKT_BLOOM *bloom_list_ptr[MAX_ALLOWED_BKT_BLOOMS];
	for (i=0; i<input->blm_count; i++) {
		strcpy(bkt_bloom_list[i].first_element, input->f_ele[i]);
		bloom_list_ptr[i] = &bkt_bloom_list[i];
	}
	blm_index = bs_upper_bound(input->ele_to_search, (const BKT_BLOOM **)bloom_list_ptr, input->blm_count);
	assert_int_equal(blm_index, input->index_ret);
}

static void test_bs_upper_bound__all_testcases(void **state) {
	int i;
	test_bs_upper_bound_inputs inputs[] = {
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "adfg", 3},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "dadds", 5},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "zzzzz", 6},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "11000", 1},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "000", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd","eeee","ffff","ggg","hh"}, 10, "z", 10},
		{{}, 0, "z", 0},
	};

	for (i=0; i<(sizeof(inputs)/sizeof(test_bs_upper_bound_inputs)); i++) {
		test_bs_upper_bound(&inputs[i]);
	}
}

static void test_bkt_bloom_create__bkt_bloom_destroy__all_testcases(void **state) {
	int nelem[] = {100, 200, 300, 4000, 7000, 160000};
	int i;
	size_t mem_size = 0;
	for (i=0; i<sizeof(nelem)/sizeof(int); i++) {
		const size_t size = BIT_ARRAY_SIZE_BITS(nelem[i]);
		const size_t total_size = sizeof(BKT_BLOOM) + BIT_ARRAY_SIZE_BYTES(size) + 1;
		BKT_BLOOM *bkt_bloom = bkt_bloom_create(nelem[i], &mem_size);

		assert_int_equal(total_size, mem_size);
		assert_int_equal(bkt_bloom->bit_array_size, size);
		assert_int_equal(bkt_bloom->nelements, nelem[i]);
		assert_int_equal(bkt_bloom->first_element[0], '\0');
		bkt_bloom_destroy(&bkt_bloom);
		assert_int_equal(NULL, bkt_bloom);
	}
	BKT_BLOOM *bkt_bloom = bkt_bloom_create(0, &mem_size);
	assert_int_equal(NULL, bkt_bloom);
	assert_int_equal(0, mem_size);
	bkt_bloom_destroy(&bkt_bloom);
	assert_int_equal(NULL, bkt_bloom);
}

typedef struct test_bkt_bloom_check_inputs_t {
	char f_ele[MAX_BKT_BLOOM_ELEMENT_LEN+1][MAX_ALLOWED_BKT_BLOOMS];
	int blm_count;
	char ele_to_search[MAX_BKT_BLOOM_ELEMENT_LEN+1];
	int is_found;
}test_bkt_bloom_check_inputs;

void test_bkt_bloom_check(test_bkt_bloom_check_inputs *input) {
	int i, found;
	BKT_BLOOM bkt_bloom_list[MAX_ALLOWED_BKT_BLOOMS];
	const BKT_BLOOM *bloom_list_ptr[MAX_ALLOWED_BKT_BLOOMS];
	for (i=0; i<input->blm_count; i++) {
		bkt_bloom_list[i].bit_array_size = 10;
		bkt_bloom_list[i].nelements = 10;
		strcpy(bkt_bloom_list[i].first_element, input->f_ele[i]);
		bloom_list_ptr[i] = &bkt_bloom_list[i];
	}
	found = bkt_bloom_check(input->ele_to_search, bloom_list_ptr, input->blm_count);
	assert_int_equal(found, input->is_found);
}

static void test_bkt_bloom_check__all_testcases(void **state) {
	int i;
	test_bkt_bloom_check_inputs inputs[] = {
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "adfg", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "dadds", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "zzzzz", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "11000", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "000", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd","eeee","ffff","ggg","hh"}, 10, "z", 0},
		{{}, 0, "z", 0},
	};

	for (i=0; i<(sizeof(inputs)/sizeof(test_bkt_bloom_check_inputs)); i++) {
		test_bkt_bloom_check(&inputs[i]);
	}
}

void test_substring_bkt_bloom_check(test_bkt_bloom_check_inputs *input) {
	int i, found;
	BKT_BLOOM bkt_bloom_list[MAX_ALLOWED_BKT_BLOOMS];
	const BKT_BLOOM *bloom_list_ptr[MAX_ALLOWED_BKT_BLOOMS];
	for (i=0; i<input->blm_count; i++) {
		bkt_bloom_list[i].bit_array_size = 10;
		bkt_bloom_list[i].nelements = 10;
		strcpy(bkt_bloom_list[i].first_element, input->f_ele[i]);
		bloom_list_ptr[i] = &bkt_bloom_list[i];
	}
	expect_string(__wrap_convert_unicode_domain_to_punycode, in_domain, input->ele_to_search);
	will_return(__wrap_convert_unicode_domain_to_punycode, cast_ptr_to_largest_integral_type(input->ele_to_search));
	will_return(__wrap_convert_unicode_domain_to_punycode, 0);

	expect_string(__wrap_char_counter, str, input->ele_to_search);
	expect_value(__wrap_char_counter, c, '.');
	will_return(__wrap_char_counter, 1);

	found = substring_bkt_bloom_check(input->ele_to_search, bloom_list_ptr, input->blm_count);
	assert_int_equal(found, input->is_found);
}

static void test_substring_bkt_bloom_check__all_testcases(void **state) {
	int i;
	test_bkt_bloom_check_inputs inputs[] = {
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "adfg.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "dadds.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "zzzzz.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "11000.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "000.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd","eeee","ffff","ggg","hh"}, 10, "z.com", 0},
		{{}, 0, "z.com", 0},
	};

	for (i=0; i<(sizeof(inputs)/sizeof(test_bkt_bloom_check_inputs)); i++) {
		test_substring_bkt_bloom_check(&inputs[i]);
	}
}

static void test_bkt_bloom_array_create__bkt_bloom_array_destroy__all_testcases(void **state) {
	int i;
	BKT_BLOOM_ARRAY *bkt_bloom = bkt_bloom_array_create();
	for (i=0; i<MAX_ALLOWED_BKT_BLOOMS; i++) {
		assert_int_equal(bkt_bloom->bkt_bloom[i], NULL);
	}
	assert_int_equal(bkt_bloom->bkt_bloom_count, 0);

	bkt_bloom_array_destroy(&bkt_bloom);
	assert_int_equal(NULL, bkt_bloom);
}

static void test_build_bkt_bloom__all_testcases(void **state) {
	int rc, i;
	char *ele = "test_element";
	size_t ret_size[MAX_ALLOWED_BKT_BLOOMS] = {0};
	const size_t size = BIT_ARRAY_SIZE_BITS(1);
	const size_t total_size = sizeof(BKT_BLOOM) + BIT_ARRAY_SIZE_BYTES(size) + 1;
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS]={0};
	rc = build_bkt_bloom(ele, 1, bloom_list, ret_size, strlen(ele) + 1);
	assert_int_equal(rc, ADS_ERROR_SUCCESS);
	assert_string_equal(bloom_list[0]->first_element, ele);
	assert_int_equal(bloom_list[0]->bit_array_size, size);
	assert_int_equal(bloom_list[0]->nelements, 1);
	assert_int_equal(total_size, ret_size[0]);
	for (i=1; i<MAX_ALLOWED_BKT_BLOOMS; i++) {
		assert_int_equal(bloom_list[i], NULL);
		assert_int_equal(ret_size[i], 0);
	}
	bkt_bloom_destroy(&bloom_list[0]);
	assert_int_equal(bloom_list[0], NULL);
}

typedef struct test_substr_domain_bkt_bloom_check_inputs_t {
	char f_ele[MAX_BKT_BLOOM_ELEMENT_LEN+1][MAX_ALLOWED_BKT_BLOOMS];
	int blm_count;
	char substr_to_search[MAX_BKT_BLOOM_ELEMENT_LEN+1];
	char domain_to_search[MAX_BKT_BLOOM_ELEMENT_LEN+1];
	int is_found;
}test_substr_domain_bkt_bloom_check_inputs;


void test_substr_domain_bkt_bloom_check(test_substr_domain_bkt_bloom_check_inputs *input) {
	int i, found;
	BKT_BLOOM bkt_bloom_list[MAX_ALLOWED_BKT_BLOOMS];
	const BKT_BLOOM *bloom_list_ptr[MAX_ALLOWED_BKT_BLOOMS];
	for (i=0; i<input->blm_count; i++) {
		bkt_bloom_list[i].bit_array_size = 10;
		bkt_bloom_list[i].nelements = 10;
		strcpy(bkt_bloom_list[i].first_element, input->f_ele[i]);
		bloom_list_ptr[i] = &bkt_bloom_list[i];
	}
	expect_string(__wrap_convert_unicode_domain_to_punycode, in_domain, input->domain_to_search);
	will_return(__wrap_convert_unicode_domain_to_punycode, cast_ptr_to_largest_integral_type(input->domain_to_search));
	will_return(__wrap_convert_unicode_domain_to_punycode, 0);

	expect_string(__wrap_char_counter, str, input->domain_to_search);
	expect_value(__wrap_char_counter, c, '.');
	will_return(__wrap_char_counter, 1);

	found = substr_domain_bkt_bloom_check(input->substr_to_search, input->domain_to_search, bloom_list_ptr, input->blm_count);
	assert_int_equal(found, input->is_found);
}

static void test_substr_domain_bkt_bloom_check__all_testcases(void **state) {
	int i;
	test_substr_domain_bkt_bloom_check_inputs inputs[] = {
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "abc", "adfg.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "abc", "dadds.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "abc", "zzzzz.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "abc", "11000.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd"}, 6, "abc", "000.com", 0},
		{{"10000","1111","aaaa","bbbb","cccc","dddd","eeee","ffff","ggg","hh"}, 10, "abc", "z.com", 0},
		{{}, 0, "abc", "z.com", 0},
	};

	for (i=0; i<(sizeof(inputs)/sizeof(test_substr_domain_bkt_bloom_check_inputs)); i++) {
		test_substr_domain_bkt_bloom_check(&inputs[i]);
	}
}

int main()
{
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_bs_upper_bound__all_testcases),
		cmocka_unit_test(test_bkt_bloom_create__bkt_bloom_destroy__all_testcases),
		cmocka_unit_test(test_bkt_bloom_check__all_testcases),
		cmocka_unit_test(test_substring_bkt_bloom_check__all_testcases),
		cmocka_unit_test(test_bkt_bloom_array_create__bkt_bloom_array_destroy__all_testcases),
		cmocka_unit_test(test_build_bkt_bloom__all_testcases),
		cmocka_unit_test(test_substr_domain_bkt_bloom_check__all_testcases),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
