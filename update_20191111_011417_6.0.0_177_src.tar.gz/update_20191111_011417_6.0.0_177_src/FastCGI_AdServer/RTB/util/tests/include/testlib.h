#ifndef TESTLIB_H
#define TESTLIB_H

void generate_string(char * const str, const int str_size, const char * const signature);

#endif /* TESTLIB_H */
