void generate_string(char * const str, const int str_size, const char * const signature)
{
	int i = 0;
	int j = 0;
	if(signature[0] == '\0' || str_size < 1) return;
	for(i=0; i<(str_size - 1); i++) {
		if('\0' == signature[j]) {
			j = 0;
		}
		str[i] = signature[j++];
	}
	str[i] = '\0';
}
