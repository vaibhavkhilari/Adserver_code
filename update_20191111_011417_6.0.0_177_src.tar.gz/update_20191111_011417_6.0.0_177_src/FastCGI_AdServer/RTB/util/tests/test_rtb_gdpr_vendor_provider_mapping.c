#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include <rt_types.h>
#include "rtb_gdpr_vendor_provider_mapping.h"

int gbl_log_level = L_DEBUG;
gdpr_vendor_provider_mapping_t *g_gdpr_vendor_provider_map[2];
unsigned int g_cur_ref_vendor_provider_map;

int __wrap_check_consent_for_vendor(const gdpr_consent_object_t *consent, int vendor_id, int purpose_id) {
	if (vendor_id % 2) {
		return 0;
	} else {
		return 1;
	}
}

int __wrap_check_eb_consented_provider_list(const int *eb_cp_list, int eb_cp_count, int provider_id) {
	if (provider_id % 2) {
		return 0;
	} else {
		return 1;
	}
}

typedef struct test_append_static_provider_list_to_cplist_input {
	vendor_provider_pair_t vc_map[10];
	int nelements;
	char eb_cplist_int[100];
	char eb_cplist_str[100];
	char stat_list[100];
	char dyn_list[100];
	char trans_list[100];
} test_append_static_provider_list_to_cplist_input_t;

void test_append_static_provider_list_to_cplist(test_append_static_provider_list_to_cplist_input_t *input) {
	int retval = 0;
	gdpr_vendor_provider_mapping_t mapping;
	ad_server_req_param_t in_req_params;

	mapping.vp_map = input->vc_map;
	mapping.nelements = input->nelements;

	strcpy(in_req_params.eb_cp_list_int, input->eb_cplist_int);
	strcpy(in_req_params.eb_cp_list_str, input->eb_cplist_str);
	in_req_params.static_eb_cp_list_int[0] = '\0';
	in_req_params.translated_eb_cp_list_str[0] = '\0';
	in_req_params.dynamic_eb_cp_list_int[0] = '\0';

	retval = append_static_provider_list_to_cplist(&mapping, &in_req_params);

	assert_int_equal(retval, 0);
	assert_string_equal(input->stat_list, in_req_params.static_eb_cp_list_int);
	assert_string_equal(input->dyn_list, in_req_params.dynamic_eb_cp_list_int);
	assert_string_equal(input->trans_list, in_req_params.translated_eb_cp_list_str);
}

static void test_append_static_provider_list_to_cplist__all_testcases(void **state)
{
	int i;
	test_append_static_provider_list_to_cplist_input_t inputs[] = {
		{{},0,"","","","",""}, //Empty mapping table
		{{},0,"[1,2]","[\"1\",\"2\"]","","[1,2]","[\"1\",\"2\"]"}, //Empty mapping table
		{{{-1,11,0},{-1,35,0},{-1,23,0}},3,"","","[11,35,23]","","[\"11\",\"35\",\"23\"]"}, //static list
		{{{10,12,0},{1,32,0},{34,23,0}},3,"[1,2]","[\"1\",\"2\"]","","[1,2]","[\"1\",\"2\"]"}, //Dynamic list
		{{{-1,43,0},{-1,66,0}},2,"[12,25]","[\"12\",\"25\"]","[43,66]","[12,25]","[\"12\",\"25\",\"43\"]"}, //static + Dynamic list
		{{{11,12,0},{1,32,0},{39,23,0}},3,"","","","",""}, //Empty Dynamic list
		{{{11,12,0},{10,32,0},{39,23,0}},3,"[1]","[\"1\"]","","[1]","[\"1\"]"}, //one in Dynamic list
		{{{11,12,0},{1,32,0},{-1,87,0}},3,"","","[87]","","[\"87\"]"}, //one in Static list
		{{{11,12,0},{10,32,0},{-1,87,0}},3,"[32]","[\"32\"]","[87]","[32]","[\"32\",\"87\"]"}, //one in Static + dynamic list
	};

	for (i=0; i<(sizeof(inputs)/sizeof(test_append_static_provider_list_to_cplist_input_t)); i++) {
		test_append_static_provider_list_to_cplist(&inputs[i]);
	}
}

typedef struct test_translate_consent_str_to_provider_list_input {
	vendor_provider_pair_t vc_map[10];
	int nelements;
	char stat_list[100];
	char dyn_list[100];
	char trans_list[100];
} test_translate_consent_str_to_provider_list_input_t;

void test_translate_consent_str_to_provider_list(test_translate_consent_str_to_provider_list_input_t *input) {
	int retval = 0;
	gdpr_vendor_provider_mapping_t mapping;
	ad_server_req_param_t in_req_params;
	fte_additional_params_t fte_additional_parameters;

	mapping.vp_map = input->vc_map;
	mapping.nelements = input->nelements;
	in_req_params.static_eb_cp_list_int[0] = '\0';
	in_req_params.translated_eb_cp_list_str[0] = '\0';
	in_req_params.dynamic_eb_cp_list_int[0] = '\0';

	retval = translate_consent_str_to_provider_list(&mapping, &in_req_params, &fte_additional_parameters);

	assert_int_equal(retval, 0);
	assert_string_equal(input->stat_list, in_req_params.static_eb_cp_list_int);
	assert_string_equal(input->dyn_list, in_req_params.dynamic_eb_cp_list_int);
	assert_string_equal(input->trans_list, in_req_params.translated_eb_cp_list_str);
}

static void test_translate_consent_str_to_provider_list__all_testcases(void **state)
{
	int i;
	test_translate_consent_str_to_provider_list_input_t inputs[] = {
		{{},0,"","",""}, //Empty mapping table
		{{{-1,12,0},{-1,32,0},{-1,23,0}},3,"[12,32,23]","","[\"12\",\"32\",\"23\"]"}, //static list
		{{{10,12,0},{1,32,0},{34,23,0}},3,"","[12,23]","[\"12\",\"23\"]"}, //Dynamic list
		{{{10,12,0},{1,32,0},{34,23,0},{-1,43,0},{-1,67,0}},5,"[43,67]","[12,23]","[\"12\",\"23\",\"43\",\"67\"]"}, //static + Dynamic list
		{{{11,12,0},{1,32,0},{39,23,0}},3,"","",""}, //Empty Dynamic list
		{{{11,12,0},{10,32,0},{39,23,0}},3,"","[32]","[\"32\"]"}, //one in Dynamic list
		{{{11,12,0},{1,32,0},{-1,87,0}},3,"[87]","","[\"87\"]"}, //one in Static list
		{{{11,12,0},{10,32,0},{-1,87,0}},3,"[87]","[32]","[\"32\",\"87\"]"}, //one in Static + dynamic list
	};

	for (i=0; i<(sizeof(inputs)/sizeof(test_translate_consent_str_to_provider_list_input_t)); i++) {
		test_translate_consent_str_to_provider_list(&inputs[i]);
	}
}


int main()
{
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_translate_consent_str_to_provider_list__all_testcases),
		cmocka_unit_test(test_append_static_provider_list_to_cplist__all_testcases),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
