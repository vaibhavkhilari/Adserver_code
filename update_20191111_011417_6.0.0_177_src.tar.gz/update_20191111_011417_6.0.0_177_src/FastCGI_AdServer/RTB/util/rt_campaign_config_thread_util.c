#include <error.h>
#include <fte_util.h>
#include <signal_handler.h>
#include <unistd.h>
#include <global_rt_campaign_config.h>

#define MAX_MYSQL_CACHE_TIME_FOR_NOW_QUERIES 900

void set_time_for_query(db_connection_t *adflex) {
        time_t rawtime;
        struct tm * timeinfo;
        time ( &rawtime );
        rawtime = rawtime - rawtime%MAX_MYSQL_CACHE_TIME_FOR_NOW_QUERIES;
        timeinfo = localtime(&rawtime);
        strftime (adflex->timestamp, 24,"%Y-%m-%d %H-%M-%S", timeinfo);
        llog_write(L_DEBUG, "Formatted Time:%s\n", adflex->timestamp);
        return ;
}

//rt_campaign_config_update_thread updating config every 5 minutes
void* rt_campaign_config_update_thread(void *thread_params) {

	int ret_val = ADS_ERROR_SUCCESS;
	db_connection_t adflex_dbconn;
	(void)thread_params;

	ret_val = get_fte_db_connection(&adflex_dbconn);

        while (!Shutdown_notice_given()) {

		if(ret_val != ADS_ERROR_SUCCESS){
			llog_write(L_FATAL, "Connection to AdFlex DB failed\n");
			release_db_connection(&adflex_dbconn);
			//Sleeping for 5 minutes
			sleep(300);
			get_fte_db_connection(&adflex_dbconn);
		}

		//Sleeping for 5 minutes
		sleep(300);
		llog_write(L_DEBUG, "rt_campaign_config_update_thread calling update_global_rt_campaign_config\n");
		set_time_for_query(&adflex_dbconn);
		ret_val = update_global_rt_campaign_config(&adflex_dbconn);
        }

        release_db_connection(&adflex_dbconn);
        return NULL;
}

uint32_t init_rt_campaign_config_update_thread(pthread_t *tid) {

        int ret_val = ADS_ERROR_SUCCESS;
	db_connection_t adflex_dbconn;

        ret_val = get_fte_db_connection(&adflex_dbconn);
        if (ret_val != ADS_ERROR_SUCCESS) {
                llog_write(L_FATAL, "Connection to FTE DB failed\n");
                return ADS_ERROR_INTERNAL;
        }

	set_time_for_query(&adflex_dbconn);

        //First make synchronous call so that the data is available
        //before any adserving threads start
        update_global_rt_campaign_config(&adflex_dbconn);
	release_db_connection(&adflex_dbconn);

        //Now create a thread
        pthread_create(tid, NULL, rt_campaign_config_update_thread, NULL);

        return ADS_ERROR_SUCCESS;
}

