/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <error.h>
#include "ad_server_types.h"
#include "rt_types.h"
#include "dynamic_dsp_sp_margin.h"
#include "cache_dynamic_campaign_sp_margin.h"

int cache_get_campaign_dynamic_sp_margin(
		cache_handle_t* cache_handle,
		db_connection_t* adflex_dbconn,
		long campaign_id,
		dsp_sp_margin_map_t **margin_map,
		size_t *no_of_records);
	
void update_dynamic_second_price_margin(
			long campaign_id,
			double bid_price,
			double *second_price_margin,
			cache_handle_t* cache_handle,
                	db_connection_t* adflex_dbconn) {

	int retval = 0, i = 0;
	size_t no_of_records = 0;
	dsp_sp_margin_map_t *margin_map = NULL;

        DSPM_DEBUGLOG("Winning campaign id:%ld,bid price:%f,original second price margin:%f",campaign_id,bid_price,*second_price_margin);
	
	retval = cache_get_campaign_dynamic_sp_margin(cache_handle, adflex_dbconn, campaign_id, &margin_map, (size_t*)&no_of_records);
	if ( retval != ADS_ERROR_SUCCESS ) {
		llog_write(L_DEBUG,"\nError: Could not get campaign dynamic second price margin from cache");
		goto END;
	}

	if ( no_of_records == 0 || margin_map == NULL ) {
		DSPM_DEBUGLOG("No data found");
		goto END;
	}

	for ( i = 0; i < (int)no_of_records; i++ ) {
		if ( bid_price >= margin_map[i].lower_price && bid_price < margin_map[i].upper_price ) {
        		DSPM_DEBUGLOG("Found bid price in bucket number %d,setting new margin as %f",i, margin_map[i].sp_margin);
			(*second_price_margin) = margin_map[i].sp_margin;
			break;
		}
	}

#ifdef DSPM_DEBUG
	if ( i == no_of_records ) {
             	llog_write(L_DEBUG,"\nDSPM: No matching bucket found");
	}
#endif

END:
	DSPM_DEBUGLOG("New second price margin %f",(*second_price_margin));

	if ( margin_map != NULL ) {
		free(margin_map);
		margin_map = NULL;
	}	
	return;		
	
}
