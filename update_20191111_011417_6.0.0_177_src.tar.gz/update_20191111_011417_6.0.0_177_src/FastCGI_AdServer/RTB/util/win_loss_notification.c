/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <error.h>
#include <string.h>
#include "typedefs.h"
#include "ad_server_types.h"
#include "rt_types.h"
#include "rtb_util.h"
#include "win_loss_notification.h"
#include "string_util.h"
//If its unittest then function scope will global else it will be static
STATIC int pm_rff_to_ortb_rff_map[MAX_REASON_FOR_FILTERING];
void init_pm_rff_to_ortb_rff_map(){
	//In case win loss notification is not going to happen I am taking it WLN_CREATIVE_FILTERED_GENERAL
	int i= 0;
	for(i = 0; i< MAX_REASON_FOR_FILTERING; i++){
		pm_rff_to_ortb_rff_map[i] = WLN_UNFILTERED;
	}
	
	pm_rff_to_ortb_rff_map[UNFILTERED] = WLN_UNFILTERED;
	pm_rff_to_ortb_rff_map[LANDING_PAGE_FILTER] = WLN_CREATIVE_FILTERED_ADV_EXCLUSION;
	/*check thos*/
	pm_rff_to_ortb_rff_map[FILTER_TIMED_OUT] = WLN_IMPRESSION_OPPORTUNITY_EXPIRED; // = 17, 
	pm_rff_to_ortb_rff_map[ FILTER_ZERO_BID ] = WLN_ZERO_BID;   // = 18, 
	pm_rff_to_ortb_rff_map[ FILTER_REQUEST_ID_MISMATCH] = WLN_INVALID_BID_RESPONSE; // = 19,
	pm_rff_to_ortb_rff_map[ FILTER_ABNORMAL_ECPM ] = WLN_INVALID_BID_RESPONSE; // = 20,
	pm_rff_to_ortb_rff_map[ FILTER_LOW_BID] = WLN_BID_BELOW_AUCTION_FLOOR; // = 21,
	pm_rff_to_ortb_rff_map[ FILTER_INCOMPLETE_RESPONSE] = WLN_INVALID_BID_RESPONSE; // = 22,

	pm_rff_to_ortb_rff_map[ PMP_FLOOR_FILTER] = WLN_BID_BELOW_DEAL_FLOOR; // = 26, 

	pm_rff_to_ortb_rff_map[ FILTER_CREATIVE_ID_NOT_AVAILABLE] = WLN_MINIMUM_CREATIVE_APPROVAL_DATA; // = 30,
	pm_rff_to_ortb_rff_map[ FILTER_CREATIVE_ID_BLOCKED] = WLN_CREATIVE_FILTERED_DISAPPROVED_EXCH; // = 31,

	pm_rff_to_ortb_rff_map[ FILTER_BID_PRICE_DECRYPTION_FAILURE] = WLN_INVALID_BID_RESPONSE; // = 33,
	
	pm_rff_to_ortb_rff_map[ UNCATEGORIZED_ADVERTISER_FILTER] = WLN_CREATIVE_FILTERED_CATEGORY_EXCLUSION; // = 41,
	//Filter non secure campaigns
	pm_rff_to_ortb_rff_map[ REPEAT_IMPRESSION_ON_PAGE] = WLN_CREATIVE_FILTERED_GENERAL; // = 43,

	pm_rff_to_ortb_rff_map[ FILTER_TYPE_UNSECURE_RESPONSE] = WLN_CREATIVE_FILTERED_NOT_SECURE; // = 62,

	pm_rff_to_ortb_rff_map[ BIDDING_ECPM_FILTER] = WLN_BID_BELOW_AUCTION_FLOOR; // = 65,

	pm_rff_to_ortb_rff_map[ BID_LESS_THAN_MIN_PUB_ECPM_FILTER] = WLN_BID_BELOW_AUCTION_FLOOR; // = 69,

	pm_rff_to_ortb_rff_map[ FILTER_BIDS_WITHOUT_LANDING_PAGE_URL] = WLN_MINIMUM_CREATIVE_APPROVAL_DATA; // = 74,
	pm_rff_to_ortb_rff_map[ DEAL_WHITE_LIST_FILTER] = WLN_CREATIVE_FILTERED_NOT_ALLOWED_INPMP_DEAL; // = 75,

	pm_rff_to_ortb_rff_map[ FILTER_INVALID_CURRENCY_CODE] = WLN_INVALID_BID_RESPONSE; // = 81,

	pm_rff_to_ortb_rff_map[ FILTER_MAX_CREATIVE_SIZE] = WLN_CREATIVE_FILTERED_SIZE_EXCEED; // = 85,

	pm_rff_to_ortb_rff_map[ FILTER_ADVT_DOMAIN_CATEGORY_ID] = WLN_MALFORMED_RESPONSE; // = 87,

	pm_rff_to_ortb_rff_map[ FILTER_RM_CREATIVE_ATTR_BLOCKED] = WLN_CREATIVE_FILTERED_CATEGORY_ATTR_EXCLUSION; // = 94,
	pm_rff_to_ortb_rff_map[ FILTER_RM_CRTYPE_BLOCKED] = WLN_CREATIVE_FILTERED_ADTYPE_EXCLUSION; // = 95,
	pm_rff_to_ortb_rff_map[ FILTER_RM_BLOCKLIST_STRICT_CHECK] = WLN_CREATIVE_FILTERED_GENERAL; // = 96,

	pm_rff_to_ortb_rff_map[ GLOBAL_FILTER_CREATIVE_ID_BLOCKED] = WLN_CREATIVE_FILTERED_CATEGORY_EXCLUSION; // = 108,

	pm_rff_to_ortb_rff_map[ POST_BLOCK_OPEN_EXCHANGE] = WLN_INVALID_DEAL_ID; // = 110,

	pm_rff_to_ortb_rff_map[ FILTER_VIDEO_ATTR_MIMETYPE] = WLN_INVALID_BID_RESPONSE; // = 115,

	pm_rff_to_ortb_rff_map[ GLOBAL_PUB_PREFERRED_FILTER_CREATIVE_ID_BLOCKED] = WLN_CREATIVE_FILTERED_GENERAL; // = 117,

	pm_rff_to_ortb_rff_map[ GLOBAL_BUYER_BLOCKLIST_FILTER] = WLN_CREATIVE_FILTERED_GENERAL; // = 121,
	pm_rff_to_ortb_rff_map[ CHANNEL_PARTNER_BUYER_BLOCKLIST_FILTER] = WLN_CREATIVE_FILTERED_GENERAL; // = 122,
	pm_rff_to_ortb_rff_map[ PUB_LEVEL_BUYER_BLOCKLIST_FILTER] = WLN_CREATIVE_FILTERED_GENERAL; // = 123,	

};
#undef APPEND_STRING
#define APPEND_STRING(campaign_winloss_info, bytes_written, char_ptr, space_left, format, ...)         \
        do { \
                bytes_written = snprintf(char_ptr, space_left, format, ##__VA_ARGS__);          				  \
                if (bytes_written >= space_left) {                                                                                 \
                        llog_write(L_DEBUG, "\nWLN ERROR buffer overflow while creating win-loss info str %s:%d\n", __FILE__, __LINE__);   \
                        campaign_winloss_info->bids_set = 0;								  \
                        return 0;                                                                                		 \
                }       \
                space_left -= bytes_written;                                                                                            \
                char_ptr += bytes_written; \
        } while(0);

/*
  Compare method
*/
STATIC int compare_wlt(const void *m1, const void *m2){
	win_loss_table_data_t * l = (win_loss_table_data_t *)(m1);
	win_loss_table_data_t* r = (win_loss_table_data_t *)(m2);
	if (l->campaign_id < r->campaign_id){
		return -1;
	}	else if (l->campaign_id > r->campaign_id){
		return 1;
	}
	return 0;
}
// function to init queue 
STATIC void init_wl_Queue(win_loss_queue_t* queue)
{
	queue->capacity = WIN_LOSS_QUEUE_SIZE;
	queue->front = queue->size = 0;
	queue->rear = queue->capacity - 1;
	memset(queue->array,0, sizeof(queue->array));
}
	
// Queue is full when size becomes equal to the capacity
STATIC int isfull_wlq(win_loss_queue_t* queue)
{
	return (queue->size == queue->capacity);
}

// Queue is empty when size is 0
STATIC int isempty_wlq(win_loss_queue_t* queue)
{
	return (queue->size == 0);
}

/*
  Function to add win loss data for a campaign in given campaign queue
*/
STATIC void add_to_wlq(win_loss_queue_t* queue,
								 const char *request_id,
								 double winning_bid,
								 int client_auction_enabled,
								 const char *bid_id,
								 int reason,
								 const char *bid_currency_code)
{

	if (isfull_wlq(queue)){
		//replace it with fatal error
		fprintf(stderr,"Win loss queue is full:%s:%d\n", __FILE__, __LINE__);
		return;
	}
  
	queue->rear = (queue->rear + 1)%queue->capacity;
	//copy data
 
	campaign_winloss_info_t *dst_item = & queue->array[queue->rear];
	dst_item->bids_set = 1;

	strncpy(dst_item->request_id, request_id,MAX_UNIQUE_ID_LEN);
	dst_item->request_id[MAX_UNIQUE_ID_LEN]='\0';

	dst_item->winning_bid = winning_bid;
	dst_item->client_auction_enabled = client_auction_enabled;
  
	strncpy(dst_item->bid_id[0], bid_id,MAX_TRANSACTION_ID_SIZE);
	dst_item->bid_id[0][MAX_TRANSACTION_ID_SIZE] = '\0';
	dst_item->reasons[0] = reason;
  
  
	strncpy(dst_item->bid_currency_code, bid_currency_code,MAX_CURRENCY_CODE_SIZE);
	dst_item->bid_currency_code[MAX_CURRENCY_CODE_SIZE] = '\0';;
	//  queue->array[queue->rear] = item;
	queue->size = queue->size + 1;
	//  printf("%d enqueued to queue\n", item);
}
/* 
   Function to remove an item from queue.
   campaign object returned is by refrence so must not be freed in caller
*/
STATIC campaign_winloss_info_t* dequeue_wlq(win_loss_queue_t* queue)
{
	if (isempty_wlq(queue))
		return NULL;
  
	campaign_winloss_info_t* item = queue->array + queue->front;
	queue->front = (queue->front + 1)%queue->capacity;
	queue->size = queue->size - 1;
	//  fprintf(stderr,"dequeue:%s\n",item->request_id);
	return item;
}
/*
  Will serach object with same request id if found will return campaign_winloss_info_t * else NULL
  campaign object returned is by refrence so must not be freed in caller
*/
STATIC campaign_winloss_info_t* get_obj_with_same_request_inqueue(const char *request_id, win_loss_queue_t* queue){
	if (isempty_wlq(queue)){
		return NULL;
	}

	int index = 0;
	int inuse = queue->size;
	for(index = queue->front; inuse > 0;inuse--){
		//fprintf(stderr,":%s:%s\n",request_id, queue->array[index].request_id);
		if(strncmp(request_id, queue->array[index].request_id, MAX_UNIQUE_ID_LEN) == 0){
			return &queue->array[index];
		}
		index = (index + 1)%queue->capacity;
	}
	return NULL;
}

/* Function to initialize realtime win-loss hash table */
int init_winloss_table(win_loss_table_t **wlt) {
  
	*wlt = (win_loss_table_t *)malloc(sizeof (win_loss_table_t) );

	if ( NULL == *wlt ) {
		WLN_ERRORLOG("Malloc Failed");
		return WLN_NO_MEMORY;
	}
	(*wlt)->wlt_data_arr = NULL;
	(*wlt)->wlt_data_arr = (win_loss_table_data_t *)malloc(sizeof(win_loss_table_data_t)*INITIAL_WIN_LOSS_TABLE_LEN);
	if ( NULL == (*wlt)->wlt_data_arr ) {
		WLN_ERRORLOG("Malloc Failed");
		return WLN_NO_MEMORY;
	}
	(*wlt)->capacity = INITIAL_WIN_LOSS_TABLE_LEN;
	(*wlt)->use_count = 0;
	//each queue need to be initialised
  
	WLN_DEBUGLOG("WIn loss table initiated Size %d",(*wlt)->capacity);
	return WLN_SUCCESS;
}
/*
  free win loss table
*/
void free_winloss_table(win_loss_table_t ** wlt){
	free((*wlt)->wlt_data_arr);
	(*wlt)->wlt_data_arr = NULL;
	free(*wlt);
	*wlt = NULL;
}
/*
  Function to return address of campaign_winloss_info structure of given campaign from the  table
  this will be by reference so must not be freed by caller
*/
STATIC campaign_winloss_info_t * get_campaign_winloss_info(const win_loss_table_t * wlt,
														   int camp_id) {
	win_loss_table_data_t *found_wlt_data = NULL;
  
	if(0 == wlt->use_count){
		WLN_DEBUGLOG("No any Win-loss data avaiable for any campaign\n");
		return NULL;
	}
	
	found_wlt_data = bsearch(&camp_id,
							 wlt->wlt_data_arr,
							 wlt->use_count,
							 sizeof(win_loss_table_data_t),
							 compare_wlt);
	if(NULL == found_wlt_data){
		return NULL;
	}
	return dequeue_wlq(& (found_wlt_data->wlq));
}

/*
 * Function to write win-loss info JSON for given campaign
 * Clears campaign's data from hash table
 * Returns number of bytes written
 * Takes parameters as dest string, max len, campaign id and hash table
 * NOTE: Pointer dest is passed by value and hence wont get incremented here, plus dest will not be '\0' terminated
 */
int get_winloss_info_str(char *dest,
						 int max_len,
						 int camp_id,
						 const win_loss_table_t * wlt) {
  
	char *post_temp_ptr = NULL;
	int bytes_written = 0, space_left = max_len, bids_set = 0, bid_index = 0;
	campaign_winloss_info_t *campaign_winloss_info = get_campaign_winloss_info(wlt, camp_id);    //get campaign info struct from hash table
	
	if ( campaign_winloss_info == NULL ) {
		WLN_DEBUGLOG("No data found in hash table for campaign %d", camp_id);
		return bytes_written;
	}
	bids_set = campaign_winloss_info->bids_set;

	if ( bids_set <= 0 || bids_set > MAX_BIDS_LIMIT ) {
		WLN_DEBUGLOG("No data found in hash table for campaign %d", camp_id);
		return bytes_written;
	}
	post_temp_ptr = dest;

	APPEND_STRING( campaign_winloss_info, bytes_written, post_temp_ptr, space_left, "%s:{%s:\"%s\",%s:\"%s\",%s:%g,%s:%d,%s:[",
				   WLN_NOTIFICATION_STR,
				   WLN_REQUEST_ID, campaign_winloss_info->request_id, 
				   WLN_BID_CURRENCY, campaign_winloss_info->bid_currency_code, 
				   WLN_WINNING_BID, campaign_winloss_info->winning_bid, 
				   WLN_CLIENT_ACTION_CHECK, campaign_winloss_info->client_auction_enabled,
				   WLN_BID_INFO_STR );


	for ( bid_index = 0; bid_index < bids_set; bid_index++ ) {
		APPEND_STRING(campaign_winloss_info, bytes_written, post_temp_ptr, space_left, "{%s:\"%s\",%s:%d},", 
					  WLN_BID_ID, campaign_winloss_info->bid_id[bid_index], 
					  WLN_STATUS, campaign_winloss_info->reasons[bid_index]);
	}
	//remove last comma
	post_temp_ptr--;
	//close array and json
	APPEND_STRING(campaign_winloss_info, bytes_written, post_temp_ptr, space_left, "]}");

	//Now that the data has been consumed, clear all the data
	campaign_winloss_info->bids_set = 0;

	bytes_written=(post_temp_ptr)-(dest);
	WLN_DEBUGLOG("Win loss json size:%d",bytes_written);
	//in case there is no space left nothing should be written to avoid json break
	if (0 == space_left){
		bytes_written = 0;
		LOG_FATAL(FATAL_ERROR_GEN, MOD_DEFAULT, "post data capacity overflow for winloss data\n", __FILE__,__LINE__);
	}
	return bytes_written;
}

/* Function to add given campaigns info into hash table */
STATIC int add_campaign_winloss_info(win_loss_table_t * wlt,
									   int camp_id,
									   const char *request_id,
									   int reason_for_filtering, 
									   const char* bid_id,
									   double winning_bid,
									   int client_auction_enabled,
									   const char* bid_currency_code) {


	win_loss_table_data_t *found_wlt_data = NULL;
	campaign_winloss_info_t *campaign_winloss_info = NULL;
	int bid_index = 0;
	WLN_DEBUGLOG("WIN_LOSS_NOTIFICATION:c:%d rid:%s rf:%d bid:%s wb:%f cab:%d cur:%s",camp_id,request_id,reason_for_filtering,bid_id,winning_bid,client_auction_enabled,bid_currency_code);
	found_wlt_data = bsearch(&camp_id,
							wlt->wlt_data_arr,
							wlt->use_count,
							sizeof(win_loss_table_data_t),
							compare_wlt);
	if (NULL == found_wlt_data ){//campaign not found
		int index = 0;
		//If there is no  more space reallocate it
		if ( wlt->use_count == wlt->capacity){
			int new_capacity = wlt->capacity + INITIAL_WIN_LOSS_TABLE_LEN;
			win_loss_table_data_t * tmp_wlt_data_arr = NULL;
	  
			tmp_wlt_data_arr = (win_loss_table_data_t *)realloc(wlt->wlt_data_arr,sizeof(win_loss_table_data_t)*new_capacity);
			if(NULL == tmp_wlt_data_arr){
				WLN_ERRORLOG("Realloc Failed");
				return WLN_NO_MEMORY;
			}
	  
			wlt->wlt_data_arr = tmp_wlt_data_arr;
			wlt->capacity = new_capacity;
		}
		//it's new campaign not in the list add it
		for(index = wlt->use_count - 1;
			index >=0 && camp_id <  wlt->wlt_data_arr[index].campaign_id;
			index--){
			memcpy(&wlt->wlt_data_arr[index + 1], &wlt->wlt_data_arr[index], sizeof(win_loss_table_data_t));
		}
		found_wlt_data = & wlt->wlt_data_arr[index + 1];
		wlt->use_count++;
		//need to reset it
		memset(found_wlt_data,0,sizeof(win_loss_table_data_t));
		init_wl_Queue(&found_wlt_data->wlq);
		//update campaign info
		found_wlt_data->campaign_id = camp_id;
	}

	//if it's multibid repsonse then add it to existing request else add as new one
	campaign_winloss_info = get_obj_with_same_request_inqueue(request_id, &found_wlt_data->wlq);
	if (NULL != campaign_winloss_info){ //there is object with same requestid so its multibid update same object
	
		bid_index = campaign_winloss_info->bids_set;	//get index of next empty bid location (i.e. number of bids set)
		if ( bid_index == MAX_BIDS_LIMIT ) {
			WLN_DEBUGLOG("Bids capacity reached for campaign %d", found_wlt_data->campaign_id);
			return WLN_BIDS_OVERFLOW;
		}
		strncpy( campaign_winloss_info->bid_id[bid_index] , bid_id, MAX_TRANSACTION_ID_SIZE );
		campaign_winloss_info->bid_id[bid_index][MAX_TRANSACTION_ID_SIZE] = '\0';
		campaign_winloss_info->reasons[bid_index] = reason_for_filtering;
		campaign_winloss_info->bids_set++;
	}	else{//add to queue
		add_to_wlq(&found_wlt_data->wlq,
				   request_id,
				   winning_bid,
				   client_auction_enabled,
				   bid_id,
				   reason_for_filtering,
				   bid_currency_code);
	}
	return WLN_SUCCESS;
}

/* Function to return mapped winloss reason for filtering from adserver reason for filtering */
STATIC int get_winloss_reason_for_filtering( int adserver_reason_for_filtering ) { 
	
	if ( adserver_reason_for_filtering > MAX_REASON_FOR_FILTERING && adserver_reason_for_filtering < 0){
		return WLN_UNFILTERED;
	}
	return pm_rff_to_ortb_rff_map[adserver_reason_for_filtering];
}

/* Function to return bid of winning campaign or network */
STATIC double get_winning_bid( 
	const fte_additional_params_t *fte_additional_parameters,
	const int selected_campaign,
	const selected_campaign_attribute_t* selected_camp,
	const double bidding_ecpm
	) {
	(void) fte_additional_parameters;
	double winning_bid = -1.0;
	if ( selected_campaign >= 0 && NULL != selected_camp) {	//A campaign has won
		winning_bid =  selected_camp->campaign_price > selected_camp->winning_dynamic_cpm 
			? selected_camp->campaign_price : selected_camp->winning_dynamic_cpm;
	} else 	{	//Network has won
		winning_bid = bidding_ecpm;
	}
	return winning_bid;
}

void print_post_filter_table(
	const rt_response_params_t *rt_response_params, 
	const publisher_site_ad_campaign_list_t *adcampaigns, const int rt_response_count,
	const rt_request_params_t *rt_request_params, double winning_bid) {

#define DEBUG_BUFFER_SIZE 2047
	char debug_buffer[DEBUG_BUFFER_SIZE + 1];
	char *buffer_ptr = debug_buffer;
	int campaign_index = 0, bytes_written = 0, space_left = DEBUG_BUFFER_SIZE;
	ad_server_req_param_t *req_params = rt_request_params->in_server_req_params;
	debug_buffer[0] = debug_buffer[DEBUG_BUFFER_SIZE] = '\0';

	if ( !req_params ) return;
	
	for ( campaign_index = 0; campaign_index < rt_response_count; campaign_index++) {
		bytes_written = snprintf(buffer_ptr, space_left, ";C:%ld,RF:%d,REQID:%s",rt_response_params[campaign_index].campaign_id, 
								 adcampaigns[rt_response_params[campaign_index].campaign_index].ad_campaign_list_setings->reason_for_filtering,
								 rt_request_params->request_url_params.request_id[rt_response_params[campaign_index].rt_req_id_index]);
		if ( bytes_written >= space_left) break;
		space_left -= bytes_written; buffer_ptr += bytes_written;
	}

	llog_write(L_DEBUG,"\nPost Filters: P:%ld,S:%ld,A:%ld, WB:%lf %s",req_params->publisher_id, req_params->site_id, 
			   req_params->ad_id, winning_bid, debug_buffer);
}

/* Function to update realtime win-loss hash table for all the rtb campaigns associated with this impression */
int update_rtb_winloss_information(
	const fte_additional_params_t *fte_additional_parameters,
	const ad_server_additional_params_t* additional_params, 
	const publisher_site_ad_campaign_list_t *adcampaigns,
	const rt_request_params_t *rt_request_params,
	const int rt_response_count,
	const rt_response_params_t *rt_response_params,
	const selected_campaign_attribute_t* selected_camp,
	win_loss_table_t *wlt,
	const int selected_campaign,
	const double bidding_ecpm
	) {

	int winning_rtb_camp_response_index = -1;
	int campaign_index = 0;
	double winning_bid = 0.0;
	int client_auction_enabled = 0;
	int winloss_reason_for_filtering = 0;	//Reason for filtering as per win-loss reason for filtering standard
	int retval = 0;
	int winloss_currency_id = USD_CURRENCY_ID;

	if ( selected_campaign != -1 ) {
		winning_rtb_camp_response_index = adcampaigns[selected_campaign].ad_campaign_list_setings->rtb_campaign_response_index;
		winning_bid = get_winning_bid( fte_additional_parameters, selected_campaign, selected_camp, bidding_ecpm);

		if ( winning_bid < 0 || winning_bid > REALTIME_CAMPAIGN_MAX_BID ) {
			WLN_ERRORLOG("Invalid winning bid %lf obtained.. returning", winning_bid );
			return WLN_ERROR;
		}
	}
	if ( additional_params->adserver_config_params->rtb_debug_flag >= 1 && rt_response_count > 0 ) {
		print_post_filter_table(rt_response_params, adcampaigns, rt_response_count, rt_request_params, winning_bid);
	}

	for ( campaign_index = 0; campaign_index < rt_response_count; campaign_index++) {
		//Get win-loss reason for filtering from adserver reason for filtering
		if ( rt_response_params[campaign_index].send_winloss_info != 1 ) {
			continue;
		}

		client_auction_enabled = ( rt_response_params[campaign_index].open_auction_type == AUCTION_TYPE_SECOND_PRICE );

		if (-1 != winning_rtb_camp_response_index &&  campaign_index == winning_rtb_camp_response_index) { //this is winning rtb campaign
				winloss_reason_for_filtering = WLN_BID_WIN;
		} else {
			winloss_reason_for_filtering = get_winloss_reason_for_filtering(  adcampaigns[rt_response_params[campaign_index].campaign_index].ad_campaign_list_setings->reason_for_filtering);
			
			if ( winloss_reason_for_filtering ==  WLN_ZERO_BID) {
				//Dont send win-loss notification in case of zero bid
				continue;
			}	
			if ( winloss_reason_for_filtering == WLN_UNFILTERED ) { //campaign is unfiltered
				//if Campaign is unfiltered and its fp is greater than winning bid, send loss notification as floor filter
				winloss_reason_for_filtering = (adcampaigns[rt_response_params[campaign_index].campaign_index].campaign_price > winning_bid )?
					WLN_BID_BELOW_AUCTION_FLOOR:WLN_LOST_TO_HIGHER_BID;
				
				WLN_DEBUGLOG("Unfiltered campaign's cid:%ld fp:%f wb:%f",
							 rt_response_params[campaign_index].campaign_id, 
							 adcampaigns[rt_response_params[campaign_index].campaign_index].campaign_price, winning_bid);
			}
		}

		// if DSP bids with invalid currency code then send winloss notification in DSPs configured currency.
		winloss_currency_id = ( IS_INVALID_CURRENCY_ID(rt_response_params[campaign_index].currency_id, fte_additional_parameters->currency_count) 
								? adcampaigns[rt_response_params[campaign_index].campaign_index].dsp_currency_id : rt_response_params[campaign_index].currency_id );
		
		retval = add_campaign_winloss_info ( 	wlt, 
												rt_response_params[campaign_index].campaign_id, 
												rt_request_params->request_url_params.request_id[rt_response_params[campaign_index].rt_req_id_index], 
												winloss_reason_for_filtering,
												rt_response_params[campaign_index].bid_response_params.str_bid_id, 
												CONVERT_USD_TO_NATIVE_CURRENCY(winning_bid,
																			   winloss_currency_id,
																			   fte_additional_parameters->currency_xrate_map,
																			   fte_additional_parameters->currency_count),
												client_auction_enabled,
												GET_CURRENCY_CODE_FROM_ID(winloss_currency_id,
																		  fte_additional_parameters->currency_xrate_map,
																		  fte_additional_parameters->currency_count));

		if ( retval != WLN_SUCCESS ) {
			WLN_ERRORLOG("Failed to add campaign info to winloss table, errorcode:%d",retval);
		}
	}
	return WLN_SUCCESS;
}
