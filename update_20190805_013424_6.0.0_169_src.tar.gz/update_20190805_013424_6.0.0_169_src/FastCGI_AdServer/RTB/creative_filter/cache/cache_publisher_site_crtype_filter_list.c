/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "fte_util.h"
#include "rt_types.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "cache_publisher_site_crtype_filter_list.h"

publisher_site_crtype_filter_list_t * cache_get_publisher_site_crtype_filter_list(
				cache_handle_t* cache,
				db_connection_t* dbconn,
				long pub_id,
				long site_id
				) {

	/* Local variables */
	int retval = 0;	
	char crtype_list_key[MAX_KEY_SIZE +1];
	unsigned int crtype_list_key_len = 0;
	int ret_len = 0;
	publisher_site_crtype_filter_list_t *db_publisher_site_crtype_filter_list = 0;
	publisher_site_crtype_filter_list_t *cached_publisher_site_crtype_filter_list = 0;
	
	//Sanity check
	if( 0 == pub_id || 0 == site_id || 0 == dbconn || NULL == cache ){
		llog_write(L_DEBUG,"\nERROR in args to %s", __FUNCTION__);
		return NULL;
	}
	
	/* Create the key */
	crtype_list_key_len = sprintf(crtype_list_key, PUB_SITE_CRTYPE_LIST_KEY_FMT, pub_id, site_id);

	//Try to get from cache
	cached_publisher_site_crtype_filter_list = (publisher_site_crtype_filter_list_t*) libmemcached_get(
												cache, crtype_list_key, crtype_list_key_len, (int *)&ret_len);

	if ( 0 != cached_publisher_site_crtype_filter_list ) {
		DPRINTF("Cache HIT for crtype_list_key: %s", crtype_list_key);
		return cached_publisher_site_crtype_filter_list;
	}
	DPRINTF("Cache MISS for crtype_list_key: %s", crtype_list_key);

	//If ret_len is -1, that means there was some error, try to reinit the connection.
	if (ret_len == -1) {
		reinit_cache(cache);
	}

	db_publisher_site_crtype_filter_list = db_get_publisher_site_crtype_filter_list(dbconn, pub_id, site_id);
	if( 0 == db_publisher_site_crtype_filter_list) {
		//FATAL Error 
		return 0;
	}

	//Got the data from db or default data populated
	retval = libmemcached_set(cache, crtype_list_key, crtype_list_key_len, (void*)(db_publisher_site_crtype_filter_list),
			sizeof(publisher_site_crtype_filter_list_t), get_cache_timeout(), 0);

	//If we could not add the value, probably the server went down in between,
	//so reinit the server 
	if (retval != 0) {
		reinit_cache(cache);
	}

	return db_publisher_site_crtype_filter_list;
}
