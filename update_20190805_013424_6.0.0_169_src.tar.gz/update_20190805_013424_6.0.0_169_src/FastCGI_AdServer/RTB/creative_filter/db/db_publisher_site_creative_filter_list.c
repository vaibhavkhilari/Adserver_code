/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "bloom_filter.h"
#include "db_rt_campaign_config.h"
#include "error.h"
#include "creative_filter.h"

#define GET_PUBLISHER_SITE_CREATIVE_FILTER_LIST \
	"SELECT whitelisted_bloom_filter, whitelisted_creative_count, blacklisted_bloom_filter, blacklisted_creative_count FROM publisher_site_creative_id_filter WHERE pub_id = ? AND site_id in (?,0) ORDER BY site_id DESC LIMIT 1"

int db_get_publisher_site_creative_filter_list(db_connection_t *dbconn,
		long pub_id,
		long site_id,
		BLOOM** publisher_site_creative_filter_wht_list,
		BLOOM** publisher_site_creative_filter_blk_list,
		size_t *whitelist_ret_size,
		size_t *blacklist_ret_size) {

	/* Local variables */
	unsigned char* bit_array;
	int retval = ADS_ERROR_SUCCESS;
	size_t whitelist_memcache_obj_size = 0, blacklist_memcache_obj_size = 0;
	BLOOM *white_bloom = NULL, *black_bloom = NULL;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLINTEGER s_pub_id = 0;
	SQLLEN cb_s_pub_id = 0;
	SQLINTEGER s_site_id = 0;
	SQLLEN cb_s_site_id = 0;
	SQLCHAR *s_wht_bit_array = NULL, *s_blk_bit_array = NULL;
	SQLLEN cb_s_wht_bit_array = SQL_NTS, cb_s_blk_bit_array = SQL_NTS;
	SQLINTEGER s_wht_creative_cnt=0;
	SQLLEN cb_s_wht_creative_cnt=0;
	SQLINTEGER s_blk_creative_cnt=0;
	SQLLEN cb_s_blk_creative_cnt=0;

	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	strncpy((char *) sql_statement, GET_PUBLISHER_SITE_CREATIVE_FILTER_LIST, MAX_SQL_QUERY_STR_LEN );
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';


	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );

		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}

	/* Bind parameters */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );

		// Free The SQL Statement Handle

		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}
	s_pub_id = pub_id;

	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_s_site_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}
	s_site_id = site_id;

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);

	if (sql_retval == SQL_SUCCESS) {
		//allocate bit array
		s_wht_bit_array = (SQLCHAR *)calloc(BIT_ARRAY_SIZE+1, sizeof(char));
		if(s_wht_bit_array == NULL) {
			llog_write(L_DEBUG, "\nError: Failed to allocate memory for whitelisted bloom filter, %s:%d\n", __FILE__, __LINE__);
			return ADS_ERROR_NOMEMORY;
		}
		s_blk_bit_array = (SQLCHAR *)calloc(BIT_ARRAY_SIZE+1, sizeof(char));
		if(s_blk_bit_array == NULL) {
			llog_write(L_DEBUG, "\nError: Failed to allocate memory for blacklisted bloom filter, %s:%d\n", __FILE__, __LINE__);
			return ADS_ERROR_NOMEMORY;
		}
		/* Bind Column : whitelisted_bloom_filter */
		sql_retval = SQLBindCol(statement_handle, 1, SQL_C_BINARY, s_wht_bit_array, BIT_ARRAY_SIZE, &cb_s_wht_bit_array);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = ADS_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : whitelisted_creative_count */
		sql_retval = SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_wht_creative_cnt, 0, &cb_s_wht_creative_cnt);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = ADS_ERROR_INTERNAL;
			goto done;
		}
		
		/* Bind Column : blacklisted_bloom_filter */
		sql_retval = SQLBindCol(statement_handle, 3, SQL_C_BINARY, s_blk_bit_array, BIT_ARRAY_SIZE, &cb_s_blk_bit_array);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = ADS_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : blacklisted_creative_count */
		sql_retval = SQLBindCol(statement_handle, 4, SQL_C_ULONG, &s_blk_creative_cnt, 0, &cb_s_blk_creative_cnt);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = ADS_ERROR_INTERNAL;
			goto done;
		}


		sql_retval = SQLFetch(statement_handle);
		if (sql_retval == SQL_NO_DATA) {
			llog_write(L_DEBUG, "CIF_DB_INFO: No bloom filter for pub:%ld site:%ld, %s:%d\n",pub_id,site_id,__FILE__,__LINE__);
			retval = ADS_ERROR_SUCCESS;
			goto done;
		}
	}
	else {
		llog_write(L_DEBUG, "Error executing select statement, %s:%d\n",__FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		retval = ADS_ERROR_INTERNAL;
		goto done;
	}

	/* Hard limit on max size of blocklist = 200000 */
	if(s_wht_creative_cnt > MAX_ELEMENT_COUNT || s_wht_creative_cnt < 0 ||
			s_blk_creative_cnt > MAX_ELEMENT_COUNT || s_blk_creative_cnt < 0) {
		llog_write(L_DEBUG, "ERROR: Could not create creative id bloom filter, whitelisted_creative_count:%d blacklisted_creative_count:%d, %s:%d\n",
				(int)s_wht_creative_cnt, (int)s_blk_creative_cnt, __FILE__, __LINE__);
		retval = ADS_ERROR_NOMEMORY;
		goto done;
	}

	if(s_wht_creative_cnt > 0) {
		if(!(white_bloom = bloom_create((int)s_wht_creative_cnt, &whitelist_memcache_obj_size))) {
			llog_write(L_DEBUG, "\nERROR: Could not create creative id whitelist bloom filter for pub:%ld,site:%ld %s:%d\n",
					pub_id, site_id, __FILE__, __LINE__);
			retval = ADS_ERROR_NOMEMORY;
			goto done;
		}
	}
	if(s_blk_creative_cnt > 0) {
		if(!(black_bloom = bloom_create((int)s_blk_creative_cnt, &blacklist_memcache_obj_size))) {
			llog_write(L_DEBUG, "\nERROR: Could not create creative id blacklist bloom filter for pub:%ld,site:%ld %s:%d\n",
					pub_id, site_id, __FILE__, __LINE__);
			retval = ADS_ERROR_NOMEMORY;
			goto done;
		}
	}

	if(cb_s_wht_bit_array != SQL_NULL_DATA && cb_s_wht_bit_array != 0) {
		cb_s_wht_bit_array = (cb_s_wht_bit_array < BIT_ARRAY_SIZE)? cb_s_wht_bit_array : BIT_ARRAY_SIZE;
		bit_array = (unsigned char*)&((white_bloom)[1]);
		memcpy(bit_array, (unsigned char *)s_wht_bit_array, cb_s_wht_bit_array);
		BLOCKLIST_DEBUG("\nCreative_Bloom_White:pub:%ld site:%ld:: whitelisted_dsp_creative_count:%d, bit_array_size(in bits):%ld, "
			"bit_array_size(in bytes):%ld, whitelist_memcache_obj_size:%zu, %s:%d\n",
			pub_id, site_id, white_bloom->nelements, (long int)white_bloom->bit_array_size,
			(long int)BIT_ARRAY_SIZE_BYTES(white_bloom->bit_array_size),
			whitelist_memcache_obj_size, __FILE__, __LINE__);
	}
	if(cb_s_blk_bit_array != SQL_NULL_DATA && cb_s_blk_bit_array != 0) {
		cb_s_blk_bit_array = (cb_s_blk_bit_array < BIT_ARRAY_SIZE)? cb_s_blk_bit_array : BIT_ARRAY_SIZE;
		bit_array = (unsigned char*)&((black_bloom)[1]);
		memcpy(bit_array, (unsigned char *)s_blk_bit_array, cb_s_blk_bit_array);
		BLOCKLIST_DEBUG("\nCreative_Bloom_Black:pub:%ld site:%ld:: blacklisted_dsp_creative_count:%d, bit_array_size(in bits):%ld, "
			"bit_array_size(in bytes):%ld, blacklist_memcache_obj_size:%zu, %s:%d\n",
			pub_id, site_id, black_bloom->nelements, (long int)black_bloom->bit_array_size,
			(long int)BIT_ARRAY_SIZE_BYTES(black_bloom->bit_array_size),
			blacklist_memcache_obj_size, __FILE__, __LINE__);
	}

	(*whitelist_ret_size) = whitelist_memcache_obj_size;
	(*blacklist_ret_size) = blacklist_memcache_obj_size;
	(*publisher_site_creative_filter_wht_list) = white_bloom;
	(*publisher_site_creative_filter_blk_list) = black_bloom;

done:
	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	if (s_wht_bit_array != NULL) {
		free(s_wht_bit_array);
	}
	if (s_blk_bit_array != NULL) {
		free(s_blk_bit_array);
	}

	return retval;
}
