/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <debug.h>
#include <stdbool.h>
#include "log_fw.h"
#include "db_publisher_site_crtype_filter_list.h"
#include "str_bitmap.h"
/*
Use KomliAdServer;
CREATE TABLE publisher_site_crtype_filter ( 
	pub_id bigint(20) NOT NULL,  
	site_id bigint(20) NOT NULL DEFAULT 0,   
	crtype_id_json_list varchar(256) NOT NULL DEFAULT '[]',   
	crtype_id_bitmap bigint(20) NOT NULL DEFAULT 0,   
	update_time timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,   
	PRIMARY KEY (`pub_id`,`site_id`)  
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
*/

#define SQLQUERY_PUB_SITE_CRTYPE_LIST "select crtype_id_bitmap from publisher_site_crtype_filter where pub_id=? and site_id in ('0', ?) order by site_id desc limit 1"

publisher_site_crtype_filter_list_t * db_get_publisher_site_crtype_filter_list(
                                        db_connection_t* dbconn,
                                        long pub_id,
                                        long site_id
                                    )
{	
	publisher_site_crtype_filter_list_t * crtype_filter_list = NULL;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN +1];
	
	SQLINTEGER s_crtype_id_bitmap = 0; SQLLEN cb_crtype_id_bitmap = 0;
	
	SQLINTEGER s_pub_id = 0; SQLLEN cb_pub_id = 0;
	SQLINTEGER s_site_id = 0; SQLLEN cb_site_id = 0;	

	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);
	strcpy((char *) sql_statement, SQLQUERY_PUB_SITE_CRTYPE_LIST);
	DPRINTF("Prop SQL query : %s", (char *) sql_statement);
	
	crtype_filter_list = (publisher_site_crtype_filter_list_t *) malloc(sizeof (publisher_site_crtype_filter_list_t));
	if(0 == crtype_filter_list) {
		LOG_FATAL( MEMORY_ALLOC_FAILED, MOD_DEFAULT,__FILE__,__LINE__);
		return 0;
	}
	
	//Initialize bitmap to zero
	crtype_filter_list->crtype_id_bitmap = 0;
	do {
	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if(sql_retval!=SQL_SUCCESS) {
		llog_write(L_DEBUG, "\nError in SQLPrepare:");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
		break;
	}

	/* Bind parameters */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG, SQL_INTEGER, 0 , 0, 
								  &s_pub_id, 0, &cb_pub_id);
	if(sql_retval!=SQL_SUCCESS) {
		llog_write(L_DEBUG, "\nError in SQLBindParameter:");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
		break;
	}
	s_pub_id = pub_id;
	
	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG, SQL_INTEGER, 0, 0, 
								  &s_site_id, 0, &cb_site_id);
	if(sql_retval!=SQL_SUCCESS) {
		llog_write(L_DEBUG, "\nError in SQLBindParameter:");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
		break;
 	}
	s_site_id = site_id;
	
	sql_retval = SQLExecute(statement_handle);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
		LOG_FATAL( DB_CALL_FAIL, MOD_DEFAULT,__FILE__,__LINE__);
		break; 
	}
	
	//Bind output columns
	SQLBindCol(statement_handle, 1, SQL_C_ULONG, &s_crtype_id_bitmap, 0, &cb_crtype_id_bitmap);
	
	sql_retval = SQLFetch(statement_handle);
	if (sql_retval == SQL_NO_DATA) {
		DPRINTF("crtype_filter_list NOT found in DB for pub:%ld, site:%ld", pub_id, site_id);
		break;
	}
	
	crtype_filter_list->crtype_id_bitmap = s_crtype_id_bitmap;
	DPRINTF("crtype_filter_list found in DB crtype_id_bitmap:%u", crtype_filter_list->crtype_id_bitmap);
	}while(0);
	
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	
	return crtype_filter_list;
}

