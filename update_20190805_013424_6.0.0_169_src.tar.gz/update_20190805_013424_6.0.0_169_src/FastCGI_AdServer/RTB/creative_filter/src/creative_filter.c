/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include "fte_types.h"
#include <error.h>
#include "ad_server_types.h"
#include "rt_types.h"
#include "libstats_util.h"
#include "rtb_brand_control_util.h"
#include "publisher_site_block_list.h"
#include "creative_filter.h"
#include "generic_thread.h"
extern global_bloom_filter_data g_bloom_filter_data[MAX_GLOBAL_BLOOM_FILTERS];
#define ATTRIBUTE_ID_MAX_LEN 5

int apply_creative_filter(
                rt_request_params_t *rt_req_params,
                rt_response_params_t *rt_rsp_params,
                publisher_site_ad_campaign_list_t* adcampaigns,
                fte_additional_params_t *fte_additional_parameters,
		MULTI_BLOOM* creative_filter_dsp_list,
		pub_preferred_id_blocklist_t *pub_preferred_id_blocklist) {
	char creative_ucrid[MAX_UCRID_CREATIVE_LEN + 1] = {0};
	char pub_preferred_creative_ucrid[MAX_UCRID_CREATIVE_LEN + ATTRIBUTE_ID_MAX_LEN + 1] = {0};
	int default_creative_preference, j, creative_found = 0;
	BKT_BLOOM_ARRAY* global_malware_filter = GET_GLOBAL_BLOOM_FILTER(MALWARE_CREATIVE_BLOOM_FILTER);
	BKT_BLOOM_ARRAY* global_pub_pref_crtv_blk_filter = GET_GLOBAL_BLOOM_FILTER(PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_BLOOM);

	if(rt_req_params == NULL ||
		rt_rsp_params == NULL ||
		adcampaigns == NULL ||
		fte_additional_parameters == NULL) {
		llog_write(L_DEBUG, "\nERROR: Invalid Arguments to %s\n", __FUNCTION__);
		return ADS_ERROR_INVALID_ARGS;
	}

	if (adcampaigns->ad_campaign_list_setings->filtered_flag == 1) {
		// if already filtered, ignore.
		return ADS_ERROR_SUCCESS;
	}

	default_creative_preference = fte_additional_parameters->publisher_level_settings.default_creative_preference;

	MULTIBLOOM_DEBUG("\nCreative Filter:pub:%ld site:%ld campaign:%d default_preference:%d :%s:%d\n",
				rt_req_params->in_server_req_params->publisher_id,
				rt_req_params->in_server_req_params->site_id,
				adcampaigns->campaign_id,
				default_creative_preference,
				__FILE__, __LINE__);

	if(NEED_TO_FILTER_RTB_RESP_WITH_NO_CREATIVE_ID(rt_rsp_params->bid_response_params.creative_id[0],
				default_creative_preference,
				fte_additional_parameters->publisher_level_settings.filter_rtb_resp_without_creative_id)) {
		// if creative_id is not present in dsp_response, filter out creative.
		adcampaigns->ad_campaign_list_setings->filtered_flag = 1;
		adcampaigns->ad_campaign_list_setings->reason_for_filtering = FILTER_CREATIVE_ID_NOT_AVAILABLE;
		BLOCKLIST_DEBUG("\nCREATIVE_ID_FILTER Empty creative_id::pub:%ld site:%ld dsp:%d campaign:%d default_preference:%d"
				" filter_rtb_resp_without_creative_id:%d, %s:%d\n",
				rt_req_params->in_server_req_params->publisher_id,
				rt_req_params->in_server_req_params->site_id,
				rt_rsp_params->dp_id,
				adcampaigns->campaign_id,
				default_creative_preference,
				fte_additional_parameters->publisher_level_settings.filter_rtb_resp_without_creative_id,
				__FILE__, __LINE__);
		return ADS_ERROR_SUCCESS;
	}

	if(snprintf(creative_ucrid, MAX_UCRID_CREATIVE_LEN, "%llu", rt_rsp_params->bid_response_params.crc64_uniq_creative_id)
			>= MAX_UCRID_CREATIVE_LEN) {
		llog_write(L_DEBUG, "\nWarning: creative_id may be truncated, %s\n", creative_ucrid);
	}
	/*
	 * Below Loop Will detect in global malware list
	 */

	if ((NULL != global_malware_filter) && (NULL != global_malware_filter->bkt_bloom[0])) {
		if(bkt_bloom_check(creative_ucrid,
					(const BKT_BLOOM**)global_malware_filter->bkt_bloom,
					global_malware_filter->bkt_bloom_count)){
			MULTIBLOOM_DEBUG("\nGlobal_Creative_Bloom creative blocked: pub:%ld site:%ld:: %s Found in BktBloom\n",
					rt_req_params->in_server_req_params->publisher_id,
					rt_req_params->in_server_req_params->site_id,
					creative_ucrid);
			adcampaigns->ad_campaign_list_setings->filtered_flag = 1;
			adcampaigns->ad_campaign_list_setings->reason_for_filtering = GLOBAL_FILTER_CREATIVE_ID_BLOCKED;
			return ADS_ERROR_SUCCESS;
		}
	}

	/*
	 * This part will check in the pub preferred bloom
	 */
	int index;
	if ((NULL != pub_preferred_id_blocklist->attribute_id_list_ptr )
			&& (NULL != global_pub_pref_crtv_blk_filter) 
			&& (NULL != global_pub_pref_crtv_blk_filter->bkt_bloom[0])) {
		for(index=0; index < pub_preferred_id_blocklist->nelements ; index++) {
			if(snprintf(pub_preferred_creative_ucrid, MAX_UCRID_CREATIVE_LEN + ATTRIBUTE_ID_MAX_LEN, "%d_%llu",
						pub_preferred_id_blocklist->attribute_id_list_ptr[index],
						rt_rsp_params->bid_response_params.crc64_uniq_creative_id)
					>= MAX_UCRID_CREATIVE_LEN + ATTRIBUTE_ID_MAX_LEN) {
				llog_write(L_DEBUG, "\nWarning: pub_preferred_creative_id may be truncated, %s\n", pub_preferred_creative_ucrid);
			}
			if(bkt_bloom_check(pub_preferred_creative_ucrid,
						(const BKT_BLOOM**)global_pub_pref_crtv_blk_filter->bkt_bloom,
						global_pub_pref_crtv_blk_filter->bkt_bloom_count)){
				MULTIBLOOM_DEBUG("\nGlobal_Pub_Prefereed_Creative_Bloom creative blocked: pub:%ld site:%ld:: %s Found in BktBloom\n",
						rt_req_params->in_server_req_params->publisher_id,
						rt_req_params->in_server_req_params->site_id,
						pub_preferred_creative_ucrid);
				adcampaigns->ad_campaign_list_setings->filtered_flag = 1;
				adcampaigns->ad_campaign_list_setings->reason_for_filtering = GLOBAL_PUB_PREFERRED_FILTER_CREATIVE_ID_BLOCKED;
				return ADS_ERROR_SUCCESS;
			}
		}
	}


	if(!creative_filter_dsp_list->bloom_filter_0[0] && !creative_filter_dsp_list->bloom_filter_s[0]) {
		MULTIBLOOM_DEBUG("\nCreative_Bloom:No creative_filter_dsp_list(bloom filter) for pub:%ld site:%ld, %s:%d\n",
				rt_req_params->in_server_req_params->publisher_id,
				rt_req_params->in_server_req_params->site_id,
				__FILE__, __LINE__);

		if(default_creative_preference == PUBLISHER_DEFAULT_PREFERENCE_WHITELIST) {
			adcampaigns->ad_campaign_list_setings->filtered_flag = 1;
			adcampaigns->ad_campaign_list_setings->reason_for_filtering = FILTER_CREATIVE_ID_BLOCKED;
			BLOCKLIST_DEBUG("\nCreative_Bloom:pub:%ld site:%ld:: Creative Id Filtered : campaign_id:%d "
					"dp_id:%d creative_id:%s default_creative_preference:%d i.e. %s, %s:%d\n",
					rt_req_params->in_server_req_params->publisher_id,
					rt_req_params->in_server_req_params->site_id,
					adcampaigns->campaign_id,
					rt_rsp_params->dp_id,
					rt_rsp_params->bid_response_params.creative_id,
					default_creative_preference,
					(default_creative_preference) ? "WHITELIST":"BLACKLIST",
					__FILE__, __LINE__);
		}
		return ADS_ERROR_SUCCESS;
	}

	for(j=0; j<creative_filter_dsp_list->bloom_count_0 ; j++){
		if(bloom_check(creative_filter_dsp_list->bloom_filter_0[j], creative_ucrid)) {
			MULTIBLOOM_DEBUG("\nCreative_Bloom:pub:%ld site:%ld:: %s Found in PubBloom:%d\n", 
					rt_req_params->in_server_req_params->publisher_id,
					rt_req_params->in_server_req_params->site_id,
					creative_ucrid, j);
			creative_found = 1;
			break;
		}
	}
	if (!creative_found) {
		for(j=0; j<creative_filter_dsp_list->bloom_count_s ; j++){
			if(bloom_check(creative_filter_dsp_list->bloom_filter_s[j], creative_ucrid)) {
				MULTIBLOOM_DEBUG("\nCreative_Bloom:pub:%ld site:%ld:: %s Found in SiteBloom:%d\n", 
					rt_req_params->in_server_req_params->publisher_id,
					rt_req_params->in_server_req_params->site_id,
					creative_ucrid, j);
				creative_found = 1;
				break;
			}
		}
	}

	if(!creative_found) {
		//dsp_creative_id not found in filter list
		MULTIBLOOM_DEBUG("\nCreative_Bloom:pub:%ld site:%ld:: No match for %s :%s:%d\n", 
				rt_req_params->in_server_req_params->publisher_id,
				rt_req_params->in_server_req_params->site_id,
			creative_ucrid, __FILE__, __LINE__);
		//default pref is WHITELIST then filter the campaign 
		if(default_creative_preference == PUBLISHER_DEFAULT_PREFERENCE_WHITELIST) {
			adcampaigns->ad_campaign_list_setings->filtered_flag = 1;
			adcampaigns->ad_campaign_list_setings->reason_for_filtering = FILTER_CREATIVE_ID_BLOCKED;
			BLOCKLIST_DEBUG("\nCreative_Bloom:pub:%ld site:%ld:: Creative Id Filtered : campaign_id:%d "
					"dp_id:%d creative_id:%s default_creative_preference:%d i.e. %s, %s:%d\n",
					rt_req_params->in_server_req_params->publisher_id,
					rt_req_params->in_server_req_params->site_id,
					adcampaigns->campaign_id,
					rt_rsp_params->dp_id,
					rt_rsp_params->bid_response_params.creative_id,
					default_creative_preference,
					(default_creative_preference) ? "WHITELIST":"BLACKLIST",
					__FILE__, __LINE__);
		}
		//default pref is BLACKLIST then don't filter the campaign
	}
	else {
		//dsp_creative_id found in filter list
		MULTIBLOOM_DEBUG("\nCreative_Bloom:pub:%ld site:%ld:: match found for %s  :%s:%d\n",
				rt_req_params->in_server_req_params->publisher_id,
				rt_req_params->in_server_req_params->site_id,
				creative_ucrid, __FILE__, __LINE__); 
		//default pref is BLACKLIST then filter the campaign
		if(default_creative_preference == PUBLISHER_DEFAULT_PREFERENCE_BLACKLIST) {
			adcampaigns->ad_campaign_list_setings->filtered_flag = 1;
			adcampaigns->ad_campaign_list_setings->reason_for_filtering = FILTER_CREATIVE_ID_BLOCKED;
			BLOCKLIST_DEBUG("\nCreative_Bloom:pub:%ld site:%ld:: Creative Id Filtered : campaign_id:%d "
					"dp_id:%d creative_id:%s default_preference:%d i.e. %s, %s:%d\n",
					rt_req_params->in_server_req_params->publisher_id,
					rt_req_params->in_server_req_params->site_id,
					adcampaigns->campaign_id,
					rt_rsp_params->dp_id, 
					rt_rsp_params->bid_response_params.creative_id,
					default_creative_preference,
					(default_creative_preference) ? "WHITELIST":"BLACKLIST",
					__FILE__, __LINE__);
		}
		//default pref is WHITELIST then don't filter the campaign, skip Uncategorized Advertiser Filter
		else if(default_creative_preference == PUBLISHER_DEFAULT_PREFERENCE_WHITELIST) {
			rt_rsp_params->skip_UCAF = 1;
			MULTIBLOOM_DEBUG("\nCreative_Bloom:pub:%ld site:%ld:: Skipping UCAF : campaign_id:%d "
					"dp_id:%d creative_id:%s default_preference:%d i.e. %s, %s:%d\n",
					rt_req_params->in_server_req_params->publisher_id,
					rt_req_params->in_server_req_params->site_id,
					adcampaigns->campaign_id,
					rt_rsp_params->dp_id,
					rt_rsp_params->bid_response_params.creative_id,
					default_creative_preference,
					(default_creative_preference) ? "WHITELIST":"BLACKLIST",
					__FILE__, __LINE__);
		}

	}
	return ADS_ERROR_SUCCESS;
}
