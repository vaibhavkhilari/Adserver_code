/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __FLOOR_RULE_ENGINE_H__
#define __FLOOR_RULE_ENGINE_H__


//Rule Evaluation result holders
typedef struct floor_rule_evalaluation_result_holders
{
	int user_segment_evaluation_result;
	int time_parting_evaluation_result;
	int day_parting_evaluation_result;
	int fold_position_evaluation_result;
	int site_section_evaluation_result;
	int geo_evaluation_result;
} floor_rule_evalaluation_result_holders_t;


#ifdef __cplusplus
extern "C" {
#endif

#include "fte_types.h"
#include "rt_types.h"
#include "bloom_filter.h"

int serialize_memcached_floor_rules(memcached_floor_rules_t **memcached_floor_rules, void *floor_rules_protobuff_ctxt);
void *deserialize_memcached_floor_rules(memcached_floor_rules_t *memcached_floor_rules);
void free_memcached_floor_rules(memcached_floor_rules_t **memcached_floor_rules);
void free_floor_rules_protobuff_ctxt(void *floor_rules_protobuff_ctxt);

int copy_floor_rule_active_entities_from_db( db_publisher_site_floor_rules_settings_t *db_row, 
					void *floor_rules_protobuff_ctxt);

void *copy_floor_rule_from_db( long publisher_id, 
			long site_id, 
			db_publisher_site_floor_rules_settings_t *db_row, 
			int *active_entiities_array, 
			int active_entities_array_elements_count, 
			int prev_rule_id, 
			int *rc, 
			void *floor_rules_protobuff_ctxt);


int apply_floor_rules_filter(publisher_site_ad_campaign_list_t *adcampaigns, 
			int nelements, 
			const rt_response_params_t *rt_response_params, 
			void *protobuff_floor_rules_ctxt, 
			ad_server_req_param_t *in_req_params, 
			fte_additional_params_t *fte_additional_parameters,
			publisher_site_ad_t *in_ad, 
			site_impressions_ecpm_total_t *impr_ecpm_tot,
			MULTI_BLOOM floor_bloom[],
			const ad_server_additional_params_t *additional_parameters
			);

void dump_floor_rule(void *floior_rules_protobuff_ctxt, const char *fn, int ln);
void dump_floor_rules(void *floior_rules_protobuff_ctxt, const char *fn, int ln);
#ifdef __cplusplus
}
#endif

#endif //__FLOOR_RULE_ENGINE_H__

