/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cache_types.h"
#include "db_connection.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "db_error.h"
#include "error.h"
#include "rt_types.h"
#include "cache_get_unique_segments.h" 
#include "db_get_unique_segments.h"
#include "db_error.h"
#include "fte_util.h"


int cache_get_unique_segment_list(
		cache_handle_t *cache,
		db_connection_t *dbconn,
		long publisher_id,
		long site_id,
		char **segment_list
		)
{
	/* Local Variables */
	char unique_segment_list_key[MAX_KEY_SIZE];
	unsigned int unique_segment_key_len = 0;
	int retval = 0;
	int ret_len = 0;

	sprintf(unique_segment_list_key, UNIQUE_SEGMENT_LIST_KEY, publisher_id, site_id);
	unique_segment_key_len = strlen(unique_segment_list_key);

	(*segment_list) = (char *)libmemcached_get(cache,unique_segment_list_key ,unique_segment_key_len, &ret_len);
	if ((*segment_list) != NULL) { /* found in the cache */
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "DEBUG LOG: List found in cache: %s,%s:%d\n", (*segment_list), __FILE__, __LINE__);
#endif
		return ADS_ERROR_SUCCESS;
	}

	/* Not found in cache. Make the call to the database */
	retval = db_get_unique_segment_list(publisher_id, site_id, dbconn, segment_list);
	if (retval != DB_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR: Failed to get the unique segment list from the db. Error: %d, %s:%d\n", retval, __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	} 

	/* If we found no data in the database so in order to save any more database calls, we set a dummy variable */
	if ((*segment_list) == NULL) {
		(*segment_list) = malloc (sizeof(char) * 2);
		if ((*segment_list) == NULL) {
			return ADS_ERROR_NOMEMORY;
		}
		 llog_write(L_DEBUG, "Setting dummy segment list, %s:%d\n", __FILE__, __LINE__);
		(*segment_list)[0] = '\0';
		retval = libmemcached_set(cache, unique_segment_list_key, unique_segment_key_len, (char *)(*segment_list), 2 * sizeof (char), get_fte_cache_timeout(), 0);
		if (retval != 0) {
			reinit_cache(cache);
		}
		
		return ADS_ERROR_SUCCESS;
	}

	retval = libmemcached_set(cache, unique_segment_list_key, unique_segment_key_len, (char *)(*segment_list), strlen(*segment_list), get_fte_cache_timeout(), 0);

	if (retval != 0) {
		reinit_cache(cache);
	}
	return ADS_ERROR_SUCCESS;
}
