/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cache_types.h"
#include "fte_util.h"
#include "db_connection.h"
#include "cache_advertiser_domain.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "db_error.h"
#include "db_dsp_buyer.h"
#include "error.h"
#include "rt_types.h"



/*
 * Behaviour of the function:-
 * 1) Failure:- 
 *    a) Return code ADS_ERROR_INTERNAL or ADS_ERROR_NOMEMORY
 *    b) Set *dsp_buyer_map to NULL;
 *    c) Nothing is set in memcache, so next request for same pub_id and site_id will
 *       hit the DB because all errors in this function are assumed to be transitory(Duh!
 *       Boy, where did you learn that?)
 *
 * 2) Success:- (Yaaay !!!)
 * 		a) Return ADS_ERROR_SUCCESS 
 * 		b) If memcache returns NULL; go to DB, if there is no record non NULL record
 * 		   is found for this pub_id and site_id
 * 			 *dsp_buyer_map is set to NULL and *nelements set to 0 and memcache is set to a dummy value(guess why?..guess guess)
 * 			 												OR
 * 		   If memcache return dummy entry, it's free'd and *dsp_buyer_map is set to NULL and *nelements set to 0
 * 		   												OR
 * 		   If memcache returns something other than NULL or dummy entry,
 * 		   (*dsp_buyer_map) is set to appropriate list returned from db/cache and
 * 		   *nelements contains size(i.e number of elements NOT BYTES)
 * 		   
 */
int cache_get_dsp_buyer_map(
		long pub_id,
		long site_id,
		db_connection_t* conn,
		cache_handle_t* cache_handle,
		rt_dsp_buyer_map_t** dsp_buyer_map,
		int* nelements
		)
{
	// Local variables
	char dsp_buyer_key[MAX_KEY_SIZE];
	size_t dsp_buyer_key_len = 0;
	rt_dsp_buyer_map_t* cached_dsp_buyer_map = NULL;
	int retval = 0;
	int ret_len = 0;
	rt_dsp_buyer_map_t dummy_entry;
	// Hey dummy..are you stupid or something? My name is Forrest Gump...Run Forrest run..run Forrest run..alright STOP!!!

	(*dsp_buyer_map) = NULL;
	(*nelements) = 0;

	// Create the key
	snprintf(dsp_buyer_key, MAX_KEY_SIZE, DSP_BUYER_KEY_FORMAT, pub_id, site_id);
	dsp_buyer_key_len = strlen(dsp_buyer_key);

	/*
	 * Check if present in the cache
	 */
	cached_dsp_buyer_map = (rt_dsp_buyer_map_t*) libmemcached_get(cache_handle, dsp_buyer_key, dsp_buyer_key_len, &ret_len);
	if (cached_dsp_buyer_map != NULL) {
		// Found the dsp_buyer_map in the cache Yaaay!
		// return it without free'ing it if it's non DUMMY (for DUMMIES we have a NEW policy...policy A3B7 i.e free it...RTFM)
		// Will be free'd by the function calling cache_get_advertiser_domain_id()
		if (ret_len == sizeof(rt_dsp_buyer_map_t) && cached_dsp_buyer_map->dsp_id == 0) {
			// dummy entry
			free(cached_dsp_buyer_map);
			cached_dsp_buyer_map = NULL;
		}
		(*dsp_buyer_map) = cached_dsp_buyer_map;
		if ((*dsp_buyer_map) != NULL) {
			*nelements = ret_len/sizeof(rt_dsp_buyer_map_t);
		}
		// Hope you had fun, bbye!
		return ADS_ERROR_SUCCESS;
	}
	// TODO reinit is NOP as of now so if memcache fails, things will be bad, keep that in mind(do you have Any?)
	// If ret_len is -1, that means there was some other error rather than MEMCACHED_NOTFOUND, try to reinit the connection 
	if (ret_len == -1) {
		// this in NOP right now
		reinit_cache(cache_handle);
	}

	// Get the value from DB
	retval = get_dsp_buyer_map(pub_id, site_id, conn, dsp_buyer_map, nelements);
	if (retval != ADS_ERROR_SUCCESS) {

		// this is redundant buy anyway
		(*dsp_buyer_map) = NULL;
		(*nelements) = 0;

		if (retval == ADS_ERROR_INTERNAL) {
			llog_write(L_DEBUG, "ERROR May be the db is down, not setting the cache %s:%d\n", __FILE__, __LINE__);
			return ADS_ERROR_INTERNAL;
		}
		return ADS_ERROR_NOMEMORY;
	}

	if((*dsp_buyer_map) != NULL) {
		retval = libmemcached_set(cache_handle, dsp_buyer_key, dsp_buyer_key_len, (void *) (*dsp_buyer_map), (*nelements) * sizeof(rt_dsp_buyer_map_t), get_fte_cache_timeout(), 0);
	} else {
		// set the dummy entry
		dummy_entry.dsp_id = 0;
		dummy_entry.dsp_buyer_id = 0;
		dummy_entry.buyer_id = 0;
		retval = libmemcached_set(cache_handle, dsp_buyer_key, dsp_buyer_key_len, (void *) &dummy_entry, sizeof(rt_dsp_buyer_map_t), get_fte_cache_timeout(), 0);
	}

	/*
	 * TODO this is NOP right now
	 */
	if (retval != 0) {
		reinit_cache(cache_handle);
	}
	return ADS_ERROR_SUCCESS;
}
