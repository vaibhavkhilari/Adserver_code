/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "error.h"
#include "db_error.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "fte_util.h"
#include "floor_rules_types.h"
#include "db_publisher_site_floor_rules.h"
#include "cache_publisher_site_floor_rules.h"
#include "floor_rule_engine.h"



void *cache_get_publisher_site_floor_rules(long publisher_id,
		long site_id,
		cache_handle_t *cache,
		db_connection_t *dbconn,
		int *rc)
{

	char publisher_site_floor_rules_key[MAX_KEY_SIZE];
	unsigned int publisher_site_floor_rules_key_len = 0;
	int retval = 0;
	int ret_len = 0;
	void *protobuff_ctxt = NULL;
	*rc  = ADS_ERROR_SUCCESS;
	memcached_floor_rules_t *memcached_floor_rules = NULL;
	memcached_floor_rules_t dummy_memcached_floor_rules = { .nelements = 0,
															.total_sizeof_protobuff_floor_rules = sizeof (memcached_floor_rules_t)};


        sprintf(publisher_site_floor_rules_key, PUBLISHER_SITE_FLOOR_RULES_KEY, publisher_id, site_id);
        publisher_site_floor_rules_key_len = strlen(publisher_site_floor_rules_key);


	memcached_floor_rules = (memcached_floor_rules_t *) memcached_get_object_reference(cache, publisher_site_floor_rules_key, publisher_site_floor_rules_key_len, &ret_len);
	if (memcached_floor_rules != NULL) {
		if (memcached_floor_rules->nelements > 0) {
			protobuff_ctxt = deserialize_memcached_floor_rules(memcached_floor_rules);
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
			if (protobuff_ctxt != NULL) {
				dump_floor_rules(protobuff_ctxt, __FUNCTION__, __LINE__);
			}
#endif
			*rc = (protobuff_ctxt != NULL)? ADS_ERROR_SUCCESS: ADS_ERROR_INTERNAL;
		} 
		memcached_release_object_reference((char**)&memcached_floor_rules);
		return protobuff_ctxt;
	}
		
	protobuff_ctxt = get_publisher_site_floor_rules_settings(publisher_id, site_id, dbconn, &memcached_floor_rules, &retval);
	if (retval != DB_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR: Failed to get publisher site floor rules settings from DB, publisher_id: %ld, site_id:%ld, Error: %d %s:%d\n",
			publisher_id, site_id, retval, __FILE__, __LINE__);
		*rc = ADS_ERROR_INTERNAL;
		return protobuff_ctxt;
	}

	if (memcached_floor_rules == NULL) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "INFO floor rules default\n");
#endif
	
		retval = libmemcached_set(cache, publisher_site_floor_rules_key, publisher_site_floor_rules_key_len, 
			(void *) &dummy_memcached_floor_rules, dummy_memcached_floor_rules.total_sizeof_protobuff_floor_rules,
			get_fte_cache_timeout() , 0);
	} else {

		retval = libmemcached_set(cache, publisher_site_floor_rules_key, publisher_site_floor_rules_key_len, 
					(void *) memcached_floor_rules, memcached_floor_rules->total_sizeof_protobuff_floor_rules,
					get_fte_cache_timeout() , 0);

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "INFO floor rules default %s:%ld\n",publisher_site_floor_rules_key, (long int) memcached_floor_rules->total_sizeof_protobuff_floor_rules );
#endif
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		dump_floor_rules(protobuff_ctxt, __FUNCTION__, __LINE__);
#endif
		memcached_release_object_reference((char**)&memcached_floor_rules);
	}

	if (retval != 0) {
		reinit_cache(cache);
	}
	*rc  = ADS_ERROR_SUCCESS;
	return protobuff_ctxt;

}
