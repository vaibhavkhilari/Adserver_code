/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_connection.h"
#include "db_advertiser_domain.h"
#include "db_error.h"
#include "db_constants.h"
#include "error.h"
#include "rt_types.h"

//#define GET_ADVERTISER_AND_DOMAIN_ID 
//"(SELECT AD.id, AD.advertiser_id, left(AD.domain,6), AD.crc_32 FROM advertiser_domain as AD, publisher_site_floor_rules as PSFR where PSFR.pub_id = ? and PSFR.site_id in (?,0) and PSFR.status = 1 and PSFR.start_time < '%s' and '%s' <= PSFR.end_time and PSFR.advertiser_id != 0 and PSFR.advertiser_id = AD.advertiser_id group by AD.id, AD.advertiser_id) UNION (SELECT AD.id, AD.advertiser_id, left(AD.domain,6), AD.crc_32 FROM advertiser_domain as AD, publisher_site_floor_rules as PSFR where PSFR.pub_id = ? and PSFR.site_id in (0,?) and PSFR.status = 1 and PSFR.start_time < '%s' and '%s' <= PSFR.end_time and PSFR.domain_id != 0 and PSFR.domain_id = AD.id group by AD.id, AD.advertiser_id) UNION (SELECT AD.id, AD.advertiser_id, left(AD.domain,6), AD.crc_32 FROM advertiser_domain as AD, publisher_site_floor_rules as PSFR, advertiser_domain_category_mapping as ADCM where PSFR.pub_id = ? and PSFR.site_id in (0,?) and PSFR.status = 1 and PSFR.start_time < '%s' and '%s' <= PSFR.end_time and PSFR.advertiser_category_id != 0 and PSFR.advertiser_category_id = ADCM.category_id and AD.advertiser_id = ADCM.advertiser_id and AD.id = ADCM.domain_id group by AD.id, AD.advertiser_id) order by crc_32 limit 19500"


#define GET_ADVERTISER_AND_DOMAIN_ID \
"(SELECT AD.id, AD.advertiser_id, left(AD.domain,6), AD.crc_32 FROM advertiser_domain as AD inner join (select distinct advertiser_id from publisher_site_floor_rules as PSFR where  PSFR.pub_id = ? and PSFR.site_id in (?,0) and PSFR.status = 1 and PSFR.start_time < '%s' and '%s' <= PSFR.end_time and PSFR.advertiser_id != 0)t  on t.advertiser_id = AD.advertiser_id) UNION (SELECT AD.id, AD.advertiser_id, left(AD.domain,6), AD.crc_32 FROM advertiser_domain as AD inner join (select distinct domain_id from publisher_site_floor_rules as PSFR where  PSFR.pub_id = ? and PSFR.site_id in (?,0) and PSFR.status = 1 and PSFR.start_time < '%s' and '%s' <= PSFR.end_time and PSFR.domain_id != 0)t  on t.domain_id = AD.id) UNION (SELECT AD.id, AD.advertiser_id, left(AD.domain,6), AD.crc_32 FROM advertiser_domain as AD inner join (select distinct advertiser_id, domain_id from advertiser_domain_category_mapping as ADCM inner join ( select distinct advertiser_category_id from publisher_site_floor_rules as PSFR where  PSFR.pub_id = ? and PSFR.site_id in (?,0) and PSFR.status = 1 and PSFR.start_time < '%s' and '%s' <= PSFR.end_time and PSFR.advertiser_category_id != 0)t on t.advertiser_category_id = ADCM.category_id)u on u.advertiser_id = AD.advertiser_id and AD.id = u.domain_id) order by crc_32 limit 30000"

#define INITIAL_ADVERTISER_DOMAIN_ID_ALLOC_SIZE 20

//#define TRUNCATED_DOMAIN_NAME_LENGTH 6 previously it was 4 but we have changed it to 6 due to the values in db

/*
 * Function specification:-
 *
 * 1) Failure:-
 * 						a) Return ADS_ERROR_INTERNAL(on db failure) or ADS_ERROR_NOMEMORY(malloc or
 * 						realloc failure).
 *
 * 						b) Set *ad_domain_id_list to NULL and *nelements to 0
 *
 * 2) Success:-
 * 						a) Return ADS_ERROR_SUCCESS
 * 						b) Set *ad_domain_id_list to the following list :-
 *	                  
 *                       +---------+-----------------+------+---------.............
 * *ad_domain_id_list =  |domain_id|advertiser_domain|domain|  LIST GOES ON & ON & ON & ON....ok I am bored now
 *                       +---------+-----------------+------+---------.............
 *                       and set *nelements to the size of this list
 *
 *									                OR
 *
 *	 *ad_domain_id_list = NULL(if there are no non-NULL/empty records in this table) and set *nelements to 0
 *
 */
int get_advertiser_domain_id(
		long pub_id,
		long site_id,
		db_connection_t* dbconn,
		advertiser_domain_id_t** ad_domain_id_list,
		int* nelements
		)
{
	// Local variables
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];

	int alloc_count = INITIAL_ADVERTISER_DOMAIN_ID_ALLOC_SIZE;
	int use_count = 0;
	SQLINTEGER s_pub_id;
	SQLINTEGER s_site_id;

	SQLLEN len_domain_id = 0; // Length of each column fetched from the DB
	SQLLEN len_advertiser_id = 0; // Length of each column fetched from the DB
	SQLLEN len_crc_32 = 0; // Length of each column fetched from the DB
	SQLLEN len_domain = 0; // Length of each column fetched from the DB

	advertiser_domain_id_t buf; // To store data fetched from DB

	advertiser_domain_id_t* temp_ptr = NULL;
	advertiser_domain_id_t* result_ptr = NULL;

	*ad_domain_id_list = NULL;
	*nelements = 0;// initialize *nelements


	// Allocate the statement handle
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	// Create SQL char string which contains the query
//	strncpy((char *) sql_statement, GET_ADVERTISER_AND_DOMAIN_ID, MAX_SQL_QUERY_STR_LEN);
	snprintf((char *) sql_statement, MAX_SQL_QUERY_STR_LEN, GET_ADVERTISER_AND_DOMAIN_ID, dbconn->timestamp, dbconn->timestamp, dbconn->timestamp, dbconn->timestamp, dbconn->timestamp, dbconn->timestamp);
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';
	


	// Create a prepared statement
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "ERROR Preparing statement and error code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}

	// Bind parameters
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, NULL);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval, __LINE__, __FILE__);
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}
	s_pub_id=pub_id;

	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_site_id, 0, NULL);
	if(sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}
	s_site_id=site_id;

        sql_retval = SQLBindParameter(statement_handle, 3, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_pub_id, 0, NULL);
        if (sql_retval != SQL_SUCCESS) {
                llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval, __LINE__, __FILE__);
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return ADS_ERROR_INTERNAL;
        }
        s_pub_id=pub_id;

        sql_retval = SQLBindParameter(statement_handle, 4, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_site_id, 0, NULL);
        if(sql_retval != SQL_SUCCESS) {
                llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return ADS_ERROR_INTERNAL;
        }
        s_site_id=site_id;

        sql_retval = SQLBindParameter(statement_handle, 5, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_pub_id, 0, NULL);
        if (sql_retval != SQL_SUCCESS) {
                llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval, __LINE__, __FILE__);
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return ADS_ERROR_INTERNAL;
        }
        s_pub_id=pub_id;

        sql_retval = SQLBindParameter(statement_handle, 6, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_site_id, 0, NULL);
        if(sql_retval != SQL_SUCCESS) {
                llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n", sql_retval, __FILE__, __LINE__);
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return ADS_ERROR_INTERNAL;
        }
        s_site_id=site_id;




	/* Fetch the data */
	sql_retval = SQLExecute(statement_handle);

	// If The SQL Statement Executed Successfully, Retrieve
	// The Results
	if (sql_retval == SQL_SUCCESS) {

		// Bind columns
		SQLBindCol(statement_handle, 1, SQL_C_LONG, &(buf.domain_id), 0, &len_domain_id);
		SQLBindCol(statement_handle, 2, SQL_C_LONG, &(buf.advertiser_id), 0, &len_advertiser_id);
		SQLBindCol(statement_handle, 3, SQL_C_CHAR, buf.domain, ADVERTISER_DOMAIN_TRUNCATED_DOMAIN_NAME_LENGTH + 1, &len_domain);
		SQLBindCol(statement_handle, 4, SQL_C_ULONG, &(buf.crc_32), 0, &len_crc_32);

		result_ptr = (advertiser_domain_id_t*) malloc(sizeof(advertiser_domain_id_t) * alloc_count);
		if ( result_ptr == NULL ) {
			if (statement_handle != 0) {
				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			}
			return ADS_ERROR_NOMEMORY;
		}
		while (sql_retval != SQL_NO_DATA) {
			sql_retval = SQLFetch(statement_handle);

			if (sql_retval != SQL_NO_DATA) {
				if (use_count == alloc_count) {
					alloc_count *= 2;
					temp_ptr = realloc(result_ptr, alloc_count * sizeof(advertiser_domain_id_t));
					if (temp_ptr == NULL) {
						llog_write(L_DEBUG, "ERROR realloc failed %s:%d\n", __FILE__, __LINE__);
						free(result_ptr);
						result_ptr = NULL;
						// Free The SQL Statement Handle
						if (statement_handle != 0) {
							SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
						}
						return ADS_ERROR_NOMEMORY;
					}
					result_ptr = temp_ptr;
				}
				if (
						len_domain_id != SQL_NULL_DATA
						&&
						len_advertiser_id != SQL_NULL_DATA
						&&
						len_domain != SQL_NULL_DATA
						&&
						len_domain != 0
					 ) {
					// None of the columns is NULL or empty string
					result_ptr[use_count].domain_id = buf.domain_id;
					result_ptr[use_count].advertiser_id = buf.advertiser_id;
					len_domain = (len_domain < ADVERTISER_DOMAIN_TRUNCATED_DOMAIN_NAME_LENGTH)? len_domain : ADVERTISER_DOMAIN_TRUNCATED_DOMAIN_NAME_LENGTH;
					strncpy(result_ptr[use_count].domain, buf.domain, len_domain);
					result_ptr[use_count].domain[len_domain] = '\0';
					result_ptr[use_count].crc_32 = buf.crc_32;
					use_count++;
				} else {
					// Dhokaaaaaaa ....these 4 fields cannot be NULL
					// Print the error
					llog_write(L_DEBUG, "ERROR, some rows in the table advertiser_domain have NULL values or empty strings for the pub_id : %ld and site_id : %ld %s:%d", pub_id, site_id, __FILE__, __LINE__);
				}
			}
		}
	} else {

		llog_write(L_DEBUG,"ERROR executing select statement : %s,  return code = %d %s:%d\n", sql_statement, sql_retval, __FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__ ,__FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		if (result_ptr != NULL) { //Just in case....
			free(result_ptr);
			result_ptr = NULL;
		}
		return ADS_ERROR_INTERNAL;
	}

	if(use_count == 0) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "\n No non-NULL records found in the table advertiser_domain for pub_id : %ld, site_id : %ld %s:%d\n", pub_id, site_id, __FILE__, __LINE__);
#endif
		if (result_ptr != NULL) {
			free(result_ptr);
			result_ptr = NULL;
		}
	}
	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	
	(*nelements) = use_count;
	(*ad_domain_id_list) = result_ptr;
	
	llog_write(L_DEBUG, "NDBRecords:%d:%s.%d\n", use_count, __FILE__,  __LINE__);


	return ADS_ERROR_SUCCESS;
}
