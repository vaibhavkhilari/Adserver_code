/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include "time_parting.h"
#include "ad_server_click_track_utils.h"
#include "floor_rules_types.h"
#include "ad_server_types.h"
#include "error.h"

/* This function checks if the timestamp of the visitor lies in the time stamp as specified by the rule. The time format are in this manner
   time = hour<<12 | min<<6 | sec . This helps keeps the whole time as one entity as compared to sepapate hours, minutes and seconds. Hence 
   comparsion becomes easier */

int do_time_parting(
    int start_time_parting,
    int end_time_parting,
    ad_server_req_param_t *in_req_params,
    int *time_parting_evaluation_result
    ) {
	
	/* Local Variables */
	int impr_time = 0;
	int impr_year=0, impr_month=0, impr_date=0, impr_hr=0, impr_min=0, impr_sec=0;
	char *cli_date = NULL;
	const int max_time_of_day = 23<<12 | 59<<6 | 59; /* This is the Maximum time in a day, corresponding to 23:59:59 */

	/* Check if we have valid values for start_time_parting and end_time_parting */
	if (start_time_parting == end_time_parting) {
		llog_write(L_DEBUG, "ERROR: start_time_parting and end_time_parting are equal %s:%d\n", __FILE__, __LINE__);
		*time_parting_evaluation_result = TIME_PARTING_EVALUATION_FAIL;
		return ADS_ERROR_SUCCESS;
	}

	/* decode time variable from user page*/
	if(in_req_params->time_stamp != NULL && in_req_params->time_stamp[0] != '\0') {
		decode_click_url(&cli_date, in_req_params->time_stamp);
		if(cli_date != NULL) {
			sscanf(cli_date,"%d-%d-%d %d:%d:%d", &impr_year, &impr_month, &impr_date, &impr_hr, &impr_min, &impr_sec);
			free(cli_date);
		} else {
			llog_write(L_DEBUG, "ERROR: Not able to decode user time_stamp %s:%d\n", __FILE__, __LINE__);
			*time_parting_evaluation_result = TIME_PARTING_EVALUATION_FAIL;
			return ADS_ERROR_SUCCESS;
		}
	}

	if (impr_hr > 23 || impr_hr < 0 || impr_min > 59 || impr_min < 0 || impr_sec > 59 || impr_sec < 0) {
		llog_write(L_DEBUG, "\nERROR: Wrong hour:%d or min:%d or sec:%d %s:%d\n", impr_hr, impr_min, impr_sec, __FILE__, __LINE__);
		*time_parting_evaluation_result = TIME_PARTING_EVALUATION_FAIL;
	} else {
		/* convert the impression time stamp to the same format as start_time_parting and end_time_parting */
		impr_time = impr_hr << 12 | impr_min << 6 | impr_sec;

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "INFO: Start_Time Parting: %d, End_Time_Parting: %d, impr_hr: %d, impr_min: %d, impr_sec:%d, Encoded_Impression_Time: %d, %s:%d\n", start_time_parting, end_time_parting, impr_hr, impr_min, impr_sec, impr_time, __FILE__, __LINE__);
#endif

	/* Now we have the same (combined) format for all the times, check if the impression time lies in the time window */
		if ( start_time_parting < end_time_parting ) {
			if ( impr_time >= start_time_parting && impr_time <= end_time_parting ) {
				*time_parting_evaluation_result = TIME_PARTING_EVALUATION_PASS;
			} else {
				*time_parting_evaluation_result = TIME_PARTING_EVALUATION_FAIL;
			}
		} else {
		/* end time is lesser than the start time so we need to split the time window */
			if (( impr_time >= start_time_parting && impr_time <= max_time_of_day ) || ( impr_time >= 0 && impr_time <= end_time_parting )) {
				*time_parting_evaluation_result = TIME_PARTING_EVALUATION_PASS;
			} else {
				*time_parting_evaluation_result = TIME_PARTING_EVALUATION_FAIL;
			}
		}
	}
	
	return ADS_ERROR_SUCCESS;
}

