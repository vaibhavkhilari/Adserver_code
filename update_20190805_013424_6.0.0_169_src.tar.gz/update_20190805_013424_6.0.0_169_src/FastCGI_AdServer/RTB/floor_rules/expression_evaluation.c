/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "error.h"
#include "floor_rules_types.h"

#define MAXSTACK 100
#define EMPTYSTACK -1
#define ASCII_VALUE_ZERO 48

/* This file contains set of functions to evaluate the postfix expression using stack. */

static inline int full(int top) {
        if (top == (MAXSTACK - 1))
                return 1;
        else
                return 0;
}

static inline int empty(int top) {
        if (top == EMPTYSTACK)
                return 1;
        else
                return 0;
}

static inline void push (int items [], int *top, int c) {
        if (!full(*top)) 
                items [++(*top)] =c;
        else
        	llog_write(L_DEBUG, "stack overflow\n");
}

static inline int pop (int items [], int *top) {
        if (!empty(*top)) { 
                return items[(*top)--];
        } else {
		/* control will never reach here. Just doing 'return -1' to supress compiler warning */
                llog_write(L_DEBUG, "stack empty\n");
		return -1;
        }
}

/* The following function searches the token in the given list and returns '1' or '0' accordingly. Its our own version of strstr() */

static inline int seg_list_search(const char *segment_list, const char *token) {
	const char *tmp = segment_list;
	char *pos;
	int len = strlen(token);
	if ((pos = strstr(segment_list, token))) {
		if (pos == tmp) {
			if (*(pos + len) == ',' || *(pos + len) == '\0') { /* if we found the segment in the beginning and its the only segment in the list */
				return '1';
			}
		} else {
			do {
				/* Make sure the token(segment) had a comma before it (,a_b) and a comma after it or a NUL (a_b, or a_b\0) */
				if ( (*(pos-1) == ',') && (*(pos + len) == ',' || (*(pos + len) == '\0'))) {
					return '1';
				}
				tmp += len;
				/* If we stumbled upon a wrong segment then keep doing strstr unless it returns NULL */
				pos = strstr(tmp, token);
				if (pos == NULL) {
					return '0';
				}
			} while (1);
		}
	} 
	/* we did not find a trace of the segment in the list in our first call to strstr() so return '0' */
	return '0';
}
	
int evaluate_user_segments (const char *expression, const char *segment_list, int *res) {
	/* Local Variables */
	char *postfix = NULL;
	char *token = NULL;
	int len = 0;
	int count = 0;
	int result = 0;
	int op1, op2;
	char *saveptr = NULL;
	char *processing_string = NULL;
	int top = EMPTYSTACK;
	int items [MAXSTACK];

	(*res) = USER_SEGMENT_EVALUATION_FAIL;

	if(expression == NULL || segment_list == NULL) {
                llog_write(L_DEBUG,"ERROR: expression is NULL or segment list is NULL, %s:%d\n", __FILE__, __LINE__);
                return ADS_ERROR_SUCCESS;
        }

	processing_string = strdup(expression);
	if (processing_string == NULL) {
		llog_write(L_DEBUG, "ERROR: Failed to strdup expression, %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_NOMEMORY; 
	}

	postfix = malloc(sizeof(char) * (strlen(expression)));
	if(postfix == NULL) {
		llog_write(L_DEBUG,"ERROR: Memory is not available, %s:%d\n", __FILE__, __LINE__);
		if (processing_string != NULL) {
			free (processing_string);
			processing_string = NULL;
		}
                return ADS_ERROR_NOMEMORY;
        }
	
	/* parse the expression to generate our own expression of 1s and 0s */
	token = strtok_r(processing_string, ",", &saveptr);

	while (token != NULL) {
		if (*token != '&' && *token != '|') {
				postfix [len++] = seg_list_search(segment_list, token);
		} else {
			postfix [len++] = *token;
		}
		token = strtok_r(NULL, ",", &saveptr);
   	}

	postfix [len] = '\0';

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING 
	llog_write(L_DEBUG, "DEBUG LOG: Postfix expression: %s", postfix);
#endif

	/* Postfix evaluation */	
	for (count = 0; count < len; count++) {

	/* Check if the next character is operator or an operand */
		if (postfix [count] == '|' || postfix [count] == '&') { 

			/* convert to an integer by subtracting the ascii value of '0' since we do not have atoi() for chars */
			op1 = (pop(items, &top) - ASCII_VALUE_ZERO);   
			op2 = (pop(items, &top) - ASCII_VALUE_ZERO);

			/* Check if the operands are 1 and 0s only */
                        if ((op1 == 1 || op1 == 0) && (op2 == 1 || op2 == 0)) {
                                if (postfix [count] == '&')
                                        result = op1 && op2;
                                else if (postfix [count] == '|')
                                        result = op2 || op1;
                                push(items, &top, result + ASCII_VALUE_ZERO);  /* store it in character format */
                        } else {
                                llog_write(L_DEBUG, "ERROR: Expression is wrong. Cannot Evaluate !!!\n");
				/* Free processing_string */
				if (processing_string != NULL) {
					free (processing_string);
					processing_string = NULL;
				}
				/* Free postfix */
				if (postfix != NULL) {
					free (postfix);
					postfix = NULL;
				}
		
                                return ADS_ERROR_SUCCESS;
                        }
		} else {
			push(items, &top, postfix [count]);
		}
	}

	free (postfix);
	postfix = NULL;
	free(processing_string);
	processing_string = NULL;

	if (top == 0) {
		(*res) = pop(items, &top) - ASCII_VALUE_ZERO;
	} else {
		llog_write(L_DEBUG, "ERROR: Expression is wrong. Cannot Evaluate !!!\n");
                return ADS_ERROR_SUCCESS;
	}
	return ADS_ERROR_SUCCESS;
}

			
