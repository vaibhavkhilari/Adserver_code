/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DEFAULT_ADAPTER__
#define __DEFAULT_ADAPTER__

#include <rt_types.h>
#include <rtb_util.h>
#include "ad_server_constants.h"

#define BID_CURRENCY "bidCurrency" 
#define BID_ARRAY "bids" //Bid array for multibid in json format
#define ID "id"
#define BID "bid"
#define EBID "ebid"
#define REQUEST_ID "requestId"
#define CREATIVE_JS "creativeJSURL"
#define CREATIVE_HTML "creativeHTMLURL"
#define CREATIVE_TAG "creativeTAG"
#define PIGGYBACK_COOKIE "piggybackCookie"
#define TRACKING_PIXEL "trackingPixel"
#define LANDING_PAGE_URL "landingPageURL"
#define LANDING_PAGE_TLD "landingPageTLD"
#define CREATIVEID "creativeID"
#define CREATIVEID1 "creativeId"
#define CREATIVE_TYPE "crtype"
#define SEAT "buyer"
#define RICH_MEDIA_AD_CREATIVE_ATTRIBUTE "creativeAttribute"
#define RICH_MEDIA_TECH_ID "rmt"
#define DEAL_ID "dealId"
#define IURL			"iUrl"
#define DSP_CAMP_ID		"campaignId"
#define DEAL_NO_BID_REASON	"dnbr"
#define DSP_SELECTED_CMPG_ID	"dspSelPerformanceCmpId"
/* Pubconnect response parmas */
/* Komli/ATOM ioid = pubconnect campaign id on komli side */
#define PUBCONNECT_CAMPAIGN_ID_KEY "cmpId"
/* Pubconnect campaign target key value pair */
#define PUBCONNECT_TARGET_KEY "pckv"

#define SEATBID_EXT    "ext"

#define RICH_MEDIA_AD_FIRST_CREATIVE_ATTRIBUTE_ID    0
#define RICH_MEDIA_AD_LAST_CREATIVE_ATTRIBUTE_ID     7
#define RICH_MEDIA_IS_VALID_CREATIVE_ATTRIBUTE_ID(ID)             \
({                                                                \
        ((ID) >= RICH_MEDIA_AD_FIRST_CREATIVE_ATTRIBUTE_ID &&     \
         (ID) <= RICH_MEDIA_AD_LAST_CREATIVE_ATTRIBUTE_ID);       \
})

//Video RT response parameters
#define VIDEO_CREATIVE_URL "creativeURL"
#define VIDEO_CREATIVE_TYPE	"creativeAdType"
#define	VIDEO_CREATIVE_FORMAT	"creativeFormat"


//Function signatures of default request and response handler
extern int default_process_response (
            void *response_buffer, size_t size,
            size_t nmemb, void *response_url_params_ptr);

extern int default_get_request_url(rt_request_params_t *rt_request_params,
                            const rt_request_url_params_mask_t * rt_request_url_mask,
                            rt_response_params_t *out_response_params,
							ad_server_additional_params_t *additional_parameter,
                            char *request_url_with_mandatory_params,
							char* campaign_cookie,
							publisher_site_ad_campaign_list_t *adcampaigns);
                            //encoded_request_params_t *encoded_request_params);

extern void parse_response(rt_response_params_t* bid_response_params, ad_server_additional_params_t *additional_parameter, long campaign_id, long oper_id, fte_additional_params_t *fte_additional_params, rt_request_params_t *rt_request_params);

void parse_response_multi(long oper_id, rt_response_params_t **ptr_rt_response_params,
                          int *response_alloc_count,
                          int index,
                          ad_server_additional_params_t *additional_parameter,
                          int *response_count,
			  fte_additional_params_t *fte_additional_params,
			  rt_request_params_t *rt_request_params);

extern void lowercase_string(char* str, int left, int right);
bool check_if_json(const char *buffer);

void initialize_bid_response(rt_bid_response_params_t *bid_response_params);

#endif

