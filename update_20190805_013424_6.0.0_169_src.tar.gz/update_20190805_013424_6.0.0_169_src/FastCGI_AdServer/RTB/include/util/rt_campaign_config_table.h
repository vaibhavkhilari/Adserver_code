/*
PubMatic Inc. ("PubMatic") CONFIDENTIAL
Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of
PubMatic. The intellectual and technical concepts contained herein are
proprietary to PubMatic and may be covered by U.S. and Foreign Patents,
patents in process, and are protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is
strictly forbidden unless prior written permission is obtained from PubMatic.
Access to the source code contained herein is hereby forbidden to anyone
except current PubMatic employees, managers or contractors who have executed
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended
publication or disclosure of this source code, which includes information
that is confidential and/or proprietary, and is a trade secret, of PubMatic.
ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC
DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN
CONSENT OF PubMatic IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE
AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
THAT IT MAY DESCRIBE, IN WHOLE OR IN PART. 
*/
#ifndef __GLOBAL_RT_CAMPAIGN_CONFIG_TABLE_H__
#define __GLOBAL_RT_CAMPAIGN_CONFIG_TABLE_H__

#include "db_connection.h"
#include "db_error.h"
#include "rt_types.h"
#include "db_rt_campaign_config.h"

#if __cplusplus >= 201103L
#include <atomic>
#else
#include <cstdatomic>
#endif


/* RtCampaignConfigTable
 * ---------------------
 * Global Campaign Config Table
 * Create a global object of this class.
 * Double circular buffer storing rt_request_url_params_mask_t.
 */
class RtCampaignConfigTable {
private:
        std::atomic_char idx_inuse_;
        // TODO(@ktk57):- is this required?
        uint8_t padding_[64 - sizeof(idx_inuse_)];

        rt_request_url_params_mask_t * table_[2];
        int list_size_[2];
        // DB last modified on
        uint32_t modification_timestamp_;
        // TODO(@ktk57): add padding for cache line

        /* RtCampaignConfigTable::isTableModified
         * --------------------------------------
         * Check if database entries have been update since last read.
         * Inputs:
         * - dbconn: AdFlex Database connection.
         * Return Value:
         * true if recently modified
         * false otherwise
         */
        bool isTableModified(const db_connection_t * const dbconn);

public:
        RtCampaignConfigTable(const RtCampaignConfigTable &) = delete;
        RtCampaignConfigTable & operator=(const RtCampaignConfigTable&) = delete;

        RtCampaignConfigTable():idx_inuse_{-1}, table_{NULL, NULL}, list_size_{0, 0}, modification_timestamp_(0U) {}

        /* RtCampaignConfigTable::Update
         * -----------------------------
         * Update the Global Campaign Config Table from the database.
         * Use in a single thread, running in an infinite loop (waking up
         * periodically).
         * Inputs:
         * - dbconn: AdFlex Database connection.
         */
        void Update(const db_connection_t * const dbconn);

        /* RtCampaignConfigTable::Get
         * --------------------------
         * Get the Global Campaign Config Table.
         * Caller must not modify it's contents.  May be used by multiple threads.
         * Outputs:
         * - rt_request_url_params_mask: Pointer to the Global Campaign Config
         *   Table.
         * - ret_list_len
         * Return Value:
         * ADS Error Codes
         */
        int Get(const rt_request_url_params_mask_t ** rt_request_url_params_mask,
                        int * ret_list_len);

        /* RtCampaignConfigTable::PrintTable
         * ---------------------------------
         * Print internal data structures.
         */
        void PrintTable(void);
};

#endif
