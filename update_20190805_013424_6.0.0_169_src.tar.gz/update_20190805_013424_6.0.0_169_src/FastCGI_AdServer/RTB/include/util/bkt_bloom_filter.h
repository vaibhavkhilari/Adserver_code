/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __BKT_BLOOM_H__
#define __BKT_BLOOM_H__

#include "bloom_filter.h"

#define MAX_ALLOWED_BKT_BLOOMS 20
#define MAX_BKT_BLOOM_ELEMENT_LEN 255
#define MAX_ALLOWED_ELEMENT_PER_BKT_BLOOM 160000
#define MAX_TOTAL_BKT_BLOOM_ELEMENTS_LIMIT (MAX_ALLOWED_ELEMENT_PER_BKT_BLOOM * MAX_ALLOWED_BKT_BLOOMS)

typedef struct {
	size_t bit_array_size; /* number of bits in bit array i.e. (URL_COUNT_IN_BLOCKLIST * BITS_SET_PER_URL) */
	int nelements;	/* total number of elements in bloom */
	char first_element[MAX_BKT_BLOOM_ELEMENT_LEN+1]; /* First element in bloom */
} BKT_BLOOM;

typedef struct {
	BKT_BLOOM* bkt_bloom[MAX_ALLOWED_BKT_BLOOMS];
	int bkt_bloom_count;
} BKT_BLOOM_ARRAY;

/* Bkt_bloom Function declarations */
BKT_BLOOM *bkt_bloom_create(int nelements, size_t *memcache_obj_size);
int bkt_bloom_destroy(BKT_BLOOM **bkt_bloom);
int bkt_bloom_add(BKT_BLOOM *bkt_bloom, const char *s);
int bkt_bloom_check(const char *ele, const BKT_BLOOM *bkt_bloom[], int bkt_bloom_count);
int substring_bkt_bloom_check(const char *ele, const BKT_BLOOM *bkt_bloom_list[], int bkt_bloom_count);
int substr_domain_bkt_bloom_check(const char *substr, const char *domain, const BKT_BLOOM *bkt_bloom_list[], int bkt_bloom_count);
int build_bkt_bloom(const char *list, int ele_count, BKT_BLOOM **bkt_bloom_list, size_t *ret_size, int max_element_size);
BKT_BLOOM_ARRAY *bkt_bloom_array_create();
int bkt_bloom_array_destroy(BKT_BLOOM_ARRAY **bkt_bloom_array);

#endif /* __BKT_BLOOM_H__ */
