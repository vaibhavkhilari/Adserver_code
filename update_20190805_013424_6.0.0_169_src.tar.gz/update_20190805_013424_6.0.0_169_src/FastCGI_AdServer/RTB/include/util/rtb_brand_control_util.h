/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __RTB_BRAND_CONTROL_UTIL_H__
#define __RTB_BRAND_CONTROL_UTIL_H__
#include <stdio.h>
#include <stdlib.h>
#include <error.h>
#include <ad_server_types.h>
#include <fte_types.h>
#include <rt_types.h>
#include <libstats_util.h>
#include "cache_types.h"
#include "db_connection.h"
#include "bloom_filter.h"

int whitelist_landing_page_filter(
                long pub_id,
                long site_id,
                rt_response_params_t* rt_response_params,
                int rt_request_count,
                const ad_server_additional_params_t* additional_parameters,
                publisher_site_ad_campaign_list_t* adcampaigns,
                cache_handle_t* cache_handle,
                db_connection_t* kadserver_dbconn,
                db_connection_t* adflex_dbconn,
                libstat_counters_t* libstats
                );

int filter_landing_page(
		long pub_id,
		long site_id, 
		rt_response_params_t* rt_response_params,
		int rt_request_count,
		const ad_server_additional_params_t* additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		cache_handle_t* cache_handle,
		db_connection_t* kadserver_dbconn,
		db_connection_t* adflex_dbconn,
		libstat_counters_t* libstats
		);

int filter_advertiser_domain_category(db_connection_t* dbconn,
		cache_handle_t* cache_handle,
		const ad_server_additional_params_t* additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		libstat_counters_t* libstats,
		ad_server_req_param_t *in_req_params,
		rt_response_params_t* rt_response_params,
		int rt_request_count,
		int pub_id,
		int site_id
		);

int filter_landing_page_with_pm_as_bidder(
		const char* blocklist,
		long pub_id,
		long site_id,
		rt_response_params_t* rt_response_params,
		int rt_request_count,
		const ad_server_additional_params_t* additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		cache_handle_t* cache_handle,
		db_connection_t* kadserver_dbconn,
		libstat_counters_t* libstats
		);

/*  * function accepts: : pub_id, site_id, domain_name, cache_handle, db_conn
 *   * returns: 1:domain found in whitelist/0:domain not found in whitelist*/
int top_level_domain_whitelist(
								long pub_id,
								long site_id,
								const char *domain_kadpageurl,
								const char *domain_pageurl,
								cache_handle_t* cache_handle,
								db_connection_t* kadserver_dbconn,
								ad_server_additional_params_t *additional_params,
								const int is_sitecode_present,
								const char *app_entity);

void destroy_multi_bloom(MULTI_BLOOM* multi);

int apply_buyer_blocklist(db_connection_t* dbconn,
		cache_handle_t* cache_handle,
		const fte_additional_params_t *fte_additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		rt_response_params_t* rt_response_params,
		int rt_response_count,
		long pub_id);

#endif
