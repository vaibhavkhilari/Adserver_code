/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __RTB_CONFIG__
#define __RTB_CONFIG__
#include <ad_server_types.h>
#include <pthread.h>
#include <time.h>
#include <rt_types.h>
#include <url_generation.h>
#include "cache_types.h"
#include "ad_server_thread.h"

#define RTB_CONFIG_FILE	"/etc/rtb.properties"
#define RTB_MS_CONNECTION_TIMEOUT	"rtb_ms_connection_timeout"
#define RTB_TIMEOUT	"rtb_ms_timeout"
#define RTB_REQUESTS_PER_TEN_THOUSAND "rtb_req_per_ten_thousand"
#define RTB_DEBUG_FLAG "rtb_debug_flag"
#define RTB_MAX_REALTIME_THREADS "rtb_max_realtime_threads"
#define TIMESTAMP_BUFF_LENGTH 26
#define REALTIME_CAMPAIGN_MIN_BID 0.00
#define REALTIME_CAMPAIGN_MAX_BID 999.00
//
#define RTB_ENABLE_PERSISTENT_CONNECTIONS "rtb_enable_persistent_connections"
#define RTB_CONNECTION_POOL_SIZE "rtb_connection_pool_size"
#define RTB_GET_CONNECTION_REUSE_INFO "rtb_get_connection_reuse_info"
#define RTB_CURL_HANDLE_REINIT_VALUE "rtb_curl_handle_reinit_value"
#define RTB_ENABLE_PURE_RTB "rtb_enable_pure_rtb"
#define RTB_MAX_LANDING_PAGE_FILTERING_CAMPAIGNS "rtb_max_rtb_campaign_to_apply_for_landing_page_filter"
#define RTB_ENABLE_LANDING_PAGE_FILTERING "rtb.enable.landing_page_filtering"
#define RTB_ENABLE_CONTEXTUAL_DATA_PROVIDERS "rtb.enable.contextual.data.providers"
#define RTB_CONTEXTUAL_DATA_PROVIDERS_TIME_OUT_MS "rtb.contextual.data.providers.time.out.ms"
//kartik 20_12_2010
#define RTB_ECPM_NOTIFICATION_THRESHOLD "rtb.ecpm.notification.threshold"
//~kartik
//~

#define RTB_AUDIENCE_CONNECTION_TIMEOUT "rtb.audience.connection.timeout"
#define RTB_AUDIENCE_REQUEST_TIMEOUT "rtb.audience.request.timeout"
#define RTB_AUDIENCE_URL "rtb.audience.url"

//sagar
#define RTB_BIDDER_ENABLED "rtb_bidder_enabled"
#define RTB_BIDDER_CURL_HANDLE_REINIT_VALUE "rtb_bidder_curl_handle_reinit_value"
#define RTB_BIDDER_TIMEOUT "rtb_bidder_ms_timeout"
#define RTB_MIN_PAYLOAD_FOR_COMPRESSION "rtb.minpayload_compression"
#define MAX_TIMESTAMP_SIZE 26
//~sagar
#define RTB_DRPROXY_URL "rtb.drproxy.url"
#define RTB_GOPRO_URL "rtb.gopro.url"

#define RTB_FLOOR_RPUG_CONN_TIMEOUT "rtb.floor.rpug.conn.timeout"
#define RTB_FLOOR_RPUG_REQ_TIMEOUT "rtb.floor.rpug.req.timeout"
#define RTB_FLOOR_RPUG_URL "rtb.floor.rpug.url"

#define RTB_RPUG_CONN_TIMEOUT "rtb.rpug.conn.timeout"
#define RTB_RPUG_REQ_TIMEOUT "rtb.rpug.req.timeout"
#define RTB_RPUG_URL "rtb.rpug.url"
#define RTB_SPUG_URL "rtb.spug.url"
#define RTB_SPUG_CONN_TIMEOUT "rtb.spug.conn.timeout"
#define RTB_SPUG_REQ_TIMEOUT "rtb.spug.req.timeout"

//Integral Integration parameters
#define RTB_VARNISH_SERVERS "rtb.varnish.servers"
#define RTB_WOPS_VARNISH_SERVERS "rtb.wops.varnish.servers"
#define RTB_INTEGRAL_DP_URL "rtb.integral.dp.url"
#define RTB_INTEGRAL_CONN_TIMEOUT "rtb.integral.conn.timeout"
#define RTB_INTEGRAL_REQ_TIMEOUT "rtb.integral.req.timeout"
#define RTB_INTEGRAL_ENABLED "rtb.integral.enabled"

// Prebid fraud check integration params
#define RTB_PREBID_FRAUD_CHECK_CONN_TIMEOUT "rtb.prebid.fraud.check.conn.timeout"
#define RTB_PREBID_FRAUD_CHECK_REQ_TIMEOUT "rtb.prebid.fraud.check.req.timeout"
#define RTB_PREBID_FRAUD_CHECK_URL "rtb.prebid.fraud.check.url"
#define RTB_PREBID_FRAUD_CHECK_KEY_ID "rtb.prebid.fraud.check.key.id"
#define RTB_PREBID_FRAUD_CHECK_SECRET_KEY "rtb.prebid.fraud.check.secret.key"

/* OLD Native Protocol Implementation */
//Native specific params
#define IS_NATIVE_REQUEST (in_request_params->in_server_req_params->ad_type==AD_TYPE_NATIVE)
#define NATIVE_PARAMS_STRING "\"native\":{"
#define NATIVE_API_VER "nver"
#define NATIVE_ADM_SUPPORT "admsupport"
#define NATIVE_ADM_SUPPORT_DEFAULT_VALUE "[\"title\",\"text\",\"img\",\"icon\",\"ctatext\",\"rating\"]"
#define NATIVE_ADM_SUPPORT_TITLE "title"
#define NATIVE_ADM_SUPPORT_TEXT "text"
#define NATIVE_ADM_SUPPORT_IMAGE "img"
#define NATIVE_ADM_SUPPORT_ICON "icon"
#define NATIVE_ADM_SUPPORT_CTATEXT "ctatext"
#define NATIVE_ADM_SUPPORT_RATING "rating"
#define NATIVE_IMG_RATIO "imgratio"
#define NATIVE_SEQ_NUM "seq"
#define NATIVE_ICON_SIZE "iconSz"
#define NATIVE_IMAGE_SIZE "imgSz"
#define NATIVE_TITLE_LEN "titleln"
#define NATIVE_DESC_LEN "descln"
#define NATIVE_CTA_LEN "ctaln"
#define NATIVE_PARAMS_STRING_END "}"
#define NTV_ICON_LABEL "icon"
#define NTV_IMG_LABEL "img"
#define NTV_TEXT_LABEL "text"
#define NTV_TITLE_LABEL "title"
#define NTV_CTATEXT_LABEL "ctatext"
#define NTV_RATING_LABEL "rating"
#define NTV_ICON_LABEL_ID 1
#define NTV_IMG_LABEL_ID 2
#define NTV_TEXT_LABEL_ID 3
#define NTV_TITLE_LABEL_ID 4
#define NTV_CTATEXT_LABEL_ID 5
#define NTV_RATING_LABEL_ID 6

// NATIVE resp params
#define NATIVE_RESP_NATIVE_OBJ "native"
#define NATIVE_RESP_ASSETS_OBJ "assets"
#define NATIVE_RESP_ASSETS_VIDEO_OBJ "video"
#define NATIVE_RESP_ASSETS_VIDEO_VASTTAG_OBJ "vasttag"
#define NATIVE_RESP_TITLE "title"
#define NATIVE_RESP_TEXT "text"
#define NATIVE_RESP_ICON_IMG "iconImg"
#define NATIVE_RESP_MAIN_IMG "mainImg"
#define NATIVE_RESP_CTATEXT "ctatext"
#define NATIVE_RESP_RATING "rating"
#define NATIVE_RESP_CLICK "click"
#define NATIVE_RESP_IMP_TRACKER "imptrackers"
#define NATIVE_RESP_LINK "link"
#define NATIVE_RESP_LINK_URL "url"
#define NATIVE_RESP_CLK_TRCK_RTB "clicktrackers"
#define NATIVE_RESP_CLICK_TRACKER "clktracker"
#define NATIVE_CREATIVE "native"


int set_rtb_configuration(void);
void free_rtb_configuration();

int acquire_realtime_token(int, mt_state*);
int release_realtime_token();

#ifdef __cplusplus
extern "C"
#endif
char * get_current_timestamp(char *buff);

int compare_rt_campaign_encryption_algo_details(
        const void *campaign1,
        const void *campaign2
        );
void print_array(const easy_handle_to_campaign_id_map_t*);
int map_insert(easy_handle_to_campaign_id_map_t*, CURL*, long);
long map_search(const easy_handle_to_campaign_id_map_t*, CURL*);
int map_clear(easy_handle_to_campaign_id_map_t*);
int map_remove(easy_handle_to_campaign_id_map_t*);
int map_init(easy_handle_to_campaign_id_map_t* );

//sagar
int init_bidder_curl_easy_handles(fte_additional_params_t* fte_additional_parameters,int max_no_of_bidder_cluster_requests);
int clean_bidder_easy_handles(fte_additional_params_t* fte_additional_parameters,int max_no_of_bidder_cluster_requests);
//~sagar

int init_persistent_conn(CURLM**,int );
int init_curl_easy_handles(fte_additional_params_t*,int);
int clean_easy_handles(fte_additional_params_t*,int max_realtime_campaigns);
int init_curl_easy_handles(fte_additional_params_t* fte_additional_parameters,int max_realtime_campaigns);
//~
int reload_config_and_set_curl_handles(ad_server_additional_params_t* additional_params,cache_handle_t* cache_handle,ad_serv_thread_param_t* thread_params,int* all_curl_handles_initialized,fte_additional_params_t* fte_additional_parameters);

int enable_curl_conn(int rtb_enabled_flag,int* all_curl_handles_initialized, fte_additional_params_t* fte_additional_parameters);
//kartik_porting
void print_map(const easy_handle_to_campaign_id_map_t* map);
//~kartik_porting
//manish_porting
int clean_persistent_conn(CURLM**);
//~manish_porting

#endif
