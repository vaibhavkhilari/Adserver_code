/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __CREATIVE_FILTER_H__
#define __CREATIVE_FILTER_H__

/* Include required header files */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "error.h"
#include "cache_types.h"    /* cache related structures */
#include "cache_conf_intf.h"
#include "rt_types.h"       /* Adserver types */
#include "db_connection.h"  /* DB types */
#include "bloom_filter.h"

#define PUBLISHER_DEFAULT_PREFERENCE_BLACKLIST 0
#define PUBLISHER_DEFAULT_PREFERENCE_WHITELIST 1

#define CREATIVE_STATUS_ACCEPTED 3
#define CREATIVE_STATUS_REJECTED 4
#define CREATIVE_STATUS_INVALID  (CREATIVE_STATUS_REJECTED + 1)

#define NEED_TO_FILTER_RTB_RESP_WITH_NO_CREATIVE_ID(CREATIVE_ID,DEFAULT_PREFERENCE,FILTER_RTB_RESP_WITHOUT_CREATIVE_ID) ({ \
	(	(CREATIVE_ID == '\0') && \
		((DEFAULT_PREFERENCE == PUBLISHER_DEFAULT_PREFERENCE_WHITELIST) || \
		((DEFAULT_PREFERENCE == PUBLISHER_DEFAULT_PREFERENCE_BLACKLIST) && (FILTER_RTB_RESP_WITHOUT_CREATIVE_ID == 1))) \
	); \
})


#define FREE_DSP_LIST(dsp_list, creative_count) do {          \
    if (dsp_list) {                                           \
        creative_count --;                                        \
        while(creative_count > 0) {                               \
            free(dsp_list[creative_count].dsp_creative_list);     \
            creative_count --;                                    \
        }                                                         \
        free(dsp_list);                                           \
    }                                                         \
}while(0);

// DB interface to get data from "rtb_dsp_creative_publisher_status_mapping" in case of cache miss.
int db_get_publisher_site_creative_filter_list(db_connection_t *dbconn,
                long pub_id,
                long site_id,
                BLOOM** publisher_site_creative_filter_wht_list,
                BLOOM** publisher_site_creative_filter_blk_list,
                size_t *whitelist_ret_size,
                size_t *blacklist_ret_size);

// Cache interface to read "publisher_site_creative_filter_list_t" from cache.
int cache_get_publisher_site_creative_filter_list(
                                long pub_id,
                                long site_id,
                                cache_handle_t* cache,
                                db_connection_t* dbconn,
                                BLOOM** publisher_site_creative_filter_list,
                                int default_creative_preference);

int create_and_test_bloom ( void ) ;
// Apply creative filter to each publisher/site req.
int apply_creative_filter(
		rt_request_params_t *rt_req_aprams,
		rt_response_params_t *rt_res_params,
		publisher_site_ad_campaign_list_t* adcampaigns,
		fte_additional_params_t *fte_additional_parameters,
		MULTI_BLOOM* creative_filter_dsp_list,
		pub_preferred_id_blocklist_t *pub_preferred_id_blocklist);

#endif
