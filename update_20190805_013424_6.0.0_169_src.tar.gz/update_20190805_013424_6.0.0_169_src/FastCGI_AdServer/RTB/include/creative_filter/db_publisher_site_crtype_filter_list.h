/* 
 * File:   db_publisher_site_crtype_filter_list.h
 * Author: Srinivas
 *
 * Created on 18 August, 2015, 12:34 PM
 */

#ifndef DB_PUBLISHER_SITE_CRTYPE_FILTER_LIST_H
#define	DB_PUBLISHER_SITE_CRTYPE_FILTER_LIST_H

#ifdef	__cplusplus
extern "C" {
#endif

#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"


#define MAX_CRTYPE_LIST_SIZE 1024
#define MAX_CRTYPE_ID 8
    
typedef struct publisher_site_crtype_filter_list{
	unsigned int crtype_id_bitmap;
    //char crtype_id_list[MAX_CRTYPE_LIST_SIZE + 1];
} publisher_site_crtype_filter_list_t;
    
publisher_site_crtype_filter_list_t * db_get_publisher_site_crtype_filter_list(
                                        db_connection_t* dbconn,
                                        long pub_id,
                                        long site_id
                                    );

#ifdef	__cplusplus
}
#endif

#endif	/* DB_PUBLISHER_SITE_CRTYPE_FILTER_LIST_H */

