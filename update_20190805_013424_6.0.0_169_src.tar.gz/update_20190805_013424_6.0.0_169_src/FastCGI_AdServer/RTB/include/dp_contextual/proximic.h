/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __PROXIMIC_H
#define __PROXIMIC_H

//#include "db_connection.h"
#include "ad_server_types.h"
#include "dp_generic.h"
#include "dp_properties.h"
#include "dp_constants.h"
#include "json.h"
#include "dp_contextual_util.h"

/*
 * Proximic specigic macros for storing name and size.
 */
#define PROXIMIC_NAME					"Proximic" 
#define PROXIMIC_NAME_SIZE				256
#define PROXIMIC_AUTHENTCATE_KEY_SIZE	256
#define PROXIMIC_RES_TYPE_BUFF_SIZE		256
#define PROXIMIC_RES_FORMAT				"JSON"
#define PROXIMIC_TEMP_STR_SIZE			1024

/*
 * Keys that will be searched for contextual data in proximic json response.
 */
#define PROXIMIC_CONTEXTUAL				"contextual"
#define PROXIMIC_CATEGORY				"category"
#define PROXIMIC_WEIGHT					"weight"
#define PROXIMIC_SEGMENT				"id"
#define PROXIMIC_SCOPE					"scope"
#define PROXIMIC_TYPE					"type"
#define PROXIMIC_BP						"brandprotection"
#define PROXIMIC_RATING					"rating"
#define PROXIMIC_SAFETYLEVEL			"safetylevel"
#define PROXIMIC_NONSTANDARDCONTENT		"nonstandardcontent"

/*
 * Key values macros in proximic response data.
 */
#define PROXIMIC_SCOPE_PAGE			"page"
#define PROXIMIC_SCOPE_ENVIRONMENT	"environment"
#define PROXIMIC_TYPE_IAB			"iab"

/*
 * Structure to store proximic configuration read from DB. 
 */
typedef struct proximic_config{
	int isactive;
	int timeout;
	int conn_timeout;
	int calltype;
	char dp_base_url[MAX_URL_SIZE + 1];
	int dp_authentication_method;
	char dp_authentication_key[PROXIMIC_AUTHENTCATE_KEY_SIZE + 1];
	//int dp_authentication_session_timeout;
	char responsetype[PROXIMIC_RES_TYPE_BUFF_SIZE + 1]; //TODO id instead of char.
}proximic_config_t;

/*
 * Structure to store parsed info for proximic.
 */
typedef struct proximic_parse_info {
	char scope[PROXIMIC_TEMP_STR_SIZE + 1];
	char type[PROXIMIC_TEMP_STR_SIZE + 1];
}proximic_parse_info_t;

int init_proximic_config(proximic_config_t *);
int init_proximic_parse_info(proximic_parse_info_t *proximic_parse_info);

extern dp_ops_t g_proximic_ops;

int proximic_get_id(void);
const char* proximic_get_name(void);
int proximic_get_isenabled(void *);
int proximic_initialize(db_connection_t *dbconn, void **config, int *ret_size);
int proximic_release_config(void *dp_config);
int proximic_create_request(void *, const ad_server_req_param_t *, CURL *, void *);
int proximic_parse_contextual_response(
		json_object *px_json_object,
		dp_cont_bp_data_t *dp_cont_bp_data,
		proximic_parse_info_t *proximic_parse_info);
int proximic_parse_bp_response(
		json_object *px_json_object,
		dp_cont_bp_data_t *dp_cont_bp_data,
		proximic_parse_info_t *proximic_parse_info);

int proximic_check_response_prerequisites(
	proximic_config_t *px_config,
	json_object *px_json_object,
	proximic_parse_info_t *proximic_parse_info);
/* 
 * TODO Have not defined full signature yet
 * Not so critical ... hence skipping for last
 * in implementation as it wont be used for sometime to come
 */
int proximic_parse_response(void *dp_config, const char *px_response, int response_size, void *v_dp_cont_bp_data); 

#endif /*end __PROXIMIC_H */
