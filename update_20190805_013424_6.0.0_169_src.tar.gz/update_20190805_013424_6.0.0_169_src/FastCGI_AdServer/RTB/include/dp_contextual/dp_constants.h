/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DP_CONSTANTS_H
#define __DP_CONSTANTS_H

////////////////////////////
// Declare ID for each DP
///////////////////////////

#define PROXIMIC_ID		6

///////////////////////////
// End of Decl
//////////////////////////

// defined in rt_types.h and 
// in many other places
// So #ifndef does just safe inclusion 
#ifndef MAX_URL_SIZE
#define MAX_URL_SIZE		4096 //2048*2 i18
#endif

#define MAX_DP_RESPONSE_SIZE	2048
#define MAX_DP_COUNT		1
#define DP_ENABLED		1
#define DP_DISABLED		-1


/*
 * This is set in create_request by each DP
 * and hence a good place to declare is here
 *  
 * Common callback for all DPs
 *
 * Used in setting callback for handling responses
 *
 * It simply copies response to dp_resp_params[i].response 
 * and sets dp_resp_params[i].response_size
 *
 * Can copy min of response size or MAX_DP_RESPONSE_SIZE( currently 2048 )
 * No memory allocated 
 */
int dp_response_callback(void *in_ptr , size_t size, size_t nmemb, void *stream);


#endif /* __DP_CONSTANTS_H */
