/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DP_PROPERTIES_H
#define __DP_PROPERTIES_H

#include <curl/curl.h>
#include <curl/multi.h>

#include "dp_generic.h"
#include "dp_constants.h"
#include "rt_types.h"
#include "db/db_connection.h"
#include "dp_data_passing_generic.h"
#include "dp_data_passing_util.h"

#define PAGE_SCOPE_MAX_LEN	1024
#define PAGE_TYPE_MAX_LEN	1024
#define DP_SEGCOUNT_ALLOC_SIZE	10
#define DP_TEMP_STR_LEN	1024

/*typedef struct dp_multi_handle{
	CURLM *curlm_handle;
}dp_curl_multi_handle_t;
*/
typedef struct dp_easy_handle{
	CURL *curle_handle;
}dp_curl_easy_handle_t;

/*
 * one object per thread (local to thread) 
 * keeps fllowing :
 * 	- Read only references to config
 * 	- easy curl cache pool
 * 	- reference to curl multi handle
 * 
 * No cleaning required except adding/
 * removing easy handles to multi handle
 * 
 * This will be refreshed on each config reload
 * Dies when thread dies
 */
typedef struct dp_request_params{
	dp_config_t *dp_config[MAX_DP_COUNT]; //const references to dp specific config
	dp_curl_easy_handle_t dp_curle_handle[MAX_DP_COUNT]; // curl easy handle pool
	int dp_curl_easy_pool_initialized;
//	dp_curl_multi_handle_t dp_curlm_handle; // curl multi handle
//	int dp_curl_multi_pool_initialized;
	db_connection_t *db_conn; //DB connection handle for reading config
}dp_request_params_t;

/*
 * Structure which stores contextual data returned by data provider.
 */
typedef struct dp_id_wt_data {
	int wt; //weight of segment.
	int id; //id of segment.
}dp_id_wt_data_t;

typedef struct dp_bp_safety_node {
	int set_flag;
	dp_id_wt_data_t dp_id_wt_data;
}dp_bp_safety_node_t;

typedef struct dp_bp_safety_data {
	dp_bp_safety_node_t rating;
	dp_bp_safety_node_t safetylevel;
	dp_bp_safety_node_t nonstandardcontent;
}dp_bp_safety_data_t;
/*
 * Structure which stores contextual and brand safety data returned by data provider.
 */
typedef struct dp_cont_bp_data {
	int dpid; //DP unique ID.
	char page_scope[PAGE_SCOPE_MAX_LEN + 1];
	char page_type[PAGE_TYPE_MAX_LEN + 1];
	int cont_segment_count; //Count of contextual segments in this object.
	dp_id_wt_data_t *dp_contextual_data; //Object which stores contextual segments in array.
	dp_bp_safety_data_t dp_bp_safety_data;
}dp_cont_bp_data_t;

/*
 * one object per DP per thread
 * cleaned and reset on each RTB request
 *
 * Dies when the thread dies 
 */
typedef struct dp_response_params{
	int dpid;//DP unique ID
	char url_to_be_analysed[MAX_URL_SIZE+1];// Input URL to be analysed
	int response_type;//Response format JSON/xml 
	char response[MAX_DP_RESPONSE_SIZE+1];//Response glob
	char campaign_format_json[MAX_DP_RESPONSE_SIZE+1];
	int campaign_format_json_len;
	int response_size;//size of above glob
	int response_success_flag;//Flag to check if response was successful
	int timeout_never_occured_flag;//Flag to show if timeout occured
	int create_flag; //Flag to show create request was successful.
	dp_cont_bp_data_t dp_cont_bp_data; // structure which will store contextual and brand safety data returned by DP.
}dp_response_params_t;

/*
 * Function to init dp_cont_bp_data_t object.
 */
int dp_cont_bp_data_init(dp_cont_bp_data_t *dp_cont_bp_data);

/*
 * Function to clean dp_cont_bp_data_t object.
 */
void dp_cont_bp_data_release(dp_cont_bp_data_t *dp_cont_bp_data);

/*
 * Function to print contextual and brand safety data.
 */
void dp_cont_bp_data_print(dp_cont_bp_data_t *dp_cont_bp_data);

/*
 * Function to add segment id and weight in strucure.
 */
int dp_cont_id_wt_add(dp_cont_bp_data_t *dp_cont_bp_data, int wt, int id);

/*
 * DO curl_multi_init
 * set CURLMOPT_MAXCONNECTS to pool_size
 *
 * Expects dp_curlm_handle to be preallocated, return if NULL.
 * Return values:
 * 	Returns if DP_ERROR_SUCCESS 
 *			dp_curlm_handle->curlm_handle populated
 * 		else return error
 *
 *
 * Always call dp_clean_curlm_handle
 */
//comment niki
//int dp_init_curlm_handle(dp_curl_multi_handle_t *dp_curlm_handle, int pool_size);

/*
 * Do curl_multi_cleanup
 * set dp_curlm_handle->curlm_handle = NULL
 *
 * returns SUCCESS if dp_curlm_handle == NULL 
 */
//niki comment
//int dp_clean_curlm_handle(dp_curl_multi_handle_t *dp_curlm_handle);

/*
 * Do curl_easy_init
 * 
 * Expects dp_easy_cache_handle to be preallocated
 * and of size >= max_dp_count
 *
 * Return values :
 * 	For each i in max_dp_count
 * 	Set dp_easy_cache_handle[i].curle_handle
 *	if FAILED
 *		Set *failed_count = *failed_count+1
 *
 * Always call dp_clean_curl_cache_handles
 */
int dp_init_curl_cache_handles( dp_curl_easy_handle_t *dp_easy_cache_handle, int max_dp_count, int *failed_count);

/*
 * For each i in max_dp_count
 * 	Do curl_easy_cleanup
 * 	set dp_easy_cache_handle[i].curle_handle = NULL
 *
 * Returns SUCCESS always 
 */
int dp_clean_curl_cache_handles( dp_curl_easy_handle_t *dp_easy_cache_handle, int max_dp_count);

/*
 * Initialise all members of dp_config
 * 	- set generic pointer to respective global instance 
 * 	- Set all other fields to NULL
 * Initialise all members of dp_request_params
 * 	- Set all to NULL
 */
int dp_process_request_init(dp_config_t *dp_config, dp_request_params_t *dp_req_params, int max_dp_count);

/*
 * Initialise all memebers of dp_resp_params
 *
 * Always call dp_process_response_release
 */
int dp_process_response_init( dp_response_params_t *dp_resp_params, int max_resp_count);

/*
 * If we decide to go for memory allocation 
 * from heap for any member of response 
 * this is where we free it 
 *
 *
 * Currently UNUSED
 */
int dp_process_response_release( dp_response_params_t *dp_resp_params, int max_resp_count);

/*
 * For each i in max_dp_count 
 * 	Call initialize secific to each DP
 *
 * Call dp_init_curl_cache_handles
 * Call dp_init_curlm_handle
 * 	
 *
 * Always call dp_rel_env to free allocated resource
 */
int dp_init_env(dp_config_t *dp_config,
			dp_request_params_t *dp_req_params,
			db_connection_t *db_conn,
			int max_dp_count);


/*
 * For each i in max_dp_count
 *	Call release for specific DP
 *
 * Call dp_curlm_clean_handle
 * Call dp_clean_curl_cache_handles
 *
 * Skip if arguments are found NULL
 */
int dp_rel_env(dp_config_t *dp_config,
			dp_request_params_t *dp_req_params,
			int max_dp_count);

/*
 * For each i in max_dp_count
 * 	Call create_request for each DP
 *
 * Return INVALID_ARGS if arguments are NULL
 *
 */
int dp_create_request(dp_request_params_t *dp_req_params,
			const ad_server_req_param_t *in_req_params, 
			dp_response_params_t *dp_resp_params,
			int max_dp_count);


/*
 * For each i in max_dp_count
 * 	add curl_easy_handle to curl_multi_handle
 *	Increment failed_count for each failure
 *
 * Returns DP_ERROR_SUCCESS on success 
 * 
 * Call dp_remove_request to remove handles
 */
int dp_add_request( dp_response_params_t *dp_resp_params,
			dp_config_t *dp_config,
			CURLM *curl_multi_handle,
			dp_curl_easy_handle_t *dp_curl_easy_handle,
			int max_dp_count, int *failed_count);

/*
 * For each i in max_dp_count
 * 	remove curl_easy_handle from curl_multi_handle
 *
 * Returns DP_ERROR_SUCCESS on success
 */
int dp_remove_request( dp_response_params_t *dp_resp_params,
			dp_config_t *dp_config,
			CURLM *multi_curl_handle,
			dp_curl_easy_handle_t *dp_curl_easy_handle,
			int num_of_added_handles);

/*
 * Call multi_perform
 */
//int dp_request_do_perform(dp_curl_multi_handle_t *dp_curlm_handle);

/*
 * An interface to hook getting 
 * contextual data in RTB workflow
 *
 * This will call :
 * 	create_request
 * 	add_request
 * 	do_perform
 * 	remove_request
 *
 * Returns ADS_ERROR_SUCCESS if success
 * 	else ADS_ERROR_INTERNAL on error 
 */
int dp_get_data(dp_config_t *dp_config,
			dp_request_params_t *dp_req_params,
			dp_response_params_t *dp_resp_params, 
			CURLM *multi_curl_handle,
			int max_dp_count,
			void *contextual_output,
			int *contextual_output_size);

int dp_contextual_enable_curl_conn(	int rtb_enabled_flag,
									int* all_curl_handles_initialized,
									fte_additional_params_t* fte_additional_parameters,
									db_connection_t *dbconn,
									int reload_config_flag);


int dp_add_to_rtb( dp_request_params_t *dp_req_params,
			dp_response_params_t *dp_resp_params,
			int max_dp_count,
			void **rtb_dp_buf,
			int *rtb_dp_buff_size );

int dp_generic_data_creator(dp_data_passing_params_t *params,
	dp_response_params_t *dp_resp_params);

int dp_get_dpid_response(int dpid,
	data_provider_logger_data_params_t *data_provider_logger_data_params);

int dp_make_campaign_format_json(dp_response_params_t *dp_resp_params,
	int max_resp_count);
#endif /* __DP_PROPERTIES_H */
