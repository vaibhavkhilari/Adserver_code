/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DP_DATA_PASSING_GENERIC_H__

#define __DP_DATA_PASSING_GENERIC_H__

#include "ad_server_types.h"
#include "campaign_data_provider_data.h"
#include "campaign_data_provider_settings.h"

#define MAX_JSON_DATA_PROVIDER_DATA           2048
#define MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS   (80 * MAX_DATA_PROVIDERS)
#define MAX_JSON_DATA_PROVIDER_SEGMENT_IDS    80
#define MAX_CAMAIGN_DATA_PROVIDER_CONTEXTUAL_AND_BRAND_SAFETY_POST_DATA_LEN                    (						\
													(sizeof (data_provider_data_t) +	\
													(MAX_JSON_DATA_PROVIDER_DATA) + 	\
													256)					\
												)

/* Campaig Data that needs to be logged regarding data provided by Data-Provider(s). */
typedef struct campaign_data_provider_logger_data
{
	/* Cotextual Segment Ids of Data-Provider(s) whose data we have passed to DSPs for given Campaign. */
	char json_data_provider_contextual_segment_ids[MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + 1];
	/* Length of Data-Provider(s) Cotextual Segment Ids in JSON form. */
	int json_data_provider_contextual_segment_ids_len;
	/* Brand Safety Segment Ids of Data-Provider(s) whose data we have passed to DSPs for given Campaign. */
	char json_data_provider_brand_safety_segment_ids[MAX_JSON_DATA_PROVIDERS_SEGMENT_IDS + 1];
	/* Length of Data-Provider(s) Brand Safety Segment Ids in JSON form. */
	int json_data_provider_brand_safety_segment_ids_len;
} campaign_data_provider_logger_data_t;

/* Data that needs to be logged regarding data provided by Data-Provider(s). */
typedef struct data_provider_logger_data_params
{
	/* Data provided by Data-Provider(s) in JSON form. */
	char json_data_provider_data[MAX_JSON_DATA_PROVIDER_DATA + 1];
	/* Length of Data-Provider(s) data. */
	int json_data_provider_data_len;
	/* Data-Provider respoce params. */
	void *dp_resp_params;
} data_provider_logger_data_params_t;

/* Data-Provider data OPS params. */
typedef struct campaign_data_provider_data_ops_params
{
	/* Campaign for which we need to pass data provided by Data-Provider. */
	long campaign_id;
	/* Campaign level settings. */
	campaign_level_dp_settings_t cmpg_dp_settinngs;
	/* Data provided by Data-Provider(s) for given Campaign. */
	campaign_data_provider_data_t cmpg_dp_data;
	/* Data that needs to be logged regarding data provided by Data-Provider(s). */
	campaign_data_provider_logger_data_t cmpg_dp_logger_data;
} campaign_data_provider_data_ops_params_t;

typedef struct dp_data_passing_params
{
	/* Campaign for which we need to pass data provided by Data-Provider. */
	long campaign_id;
	/* Data-Provider level settings. */
	campaign_data_provider_settings_t *dp_settings;
	/* Data provided by various Data-Provider. */
	data_provider_data_t **dp_data;
	/* Cotextual Segment Ids of Data-Provider(s) that need to be logged. */
	char json_logger_data_provider_contextual_segment_ids[MAX_JSON_DATA_PROVIDER_SEGMENT_IDS + 1];
	/* Length of Data-Provider(s) Cotextual Segment Ids in JSON form that need to be logged.. */
	int json_logger_data_provider_contextual_segment_ids_len;
	/* Brand Safety Segment Ids of Data-Provider(s) that need to be logged. */
	char json_logger_data_provider_brand_safety_segment_ids[MAX_JSON_DATA_PROVIDER_SEGMENT_IDS + 1];
	/* Length of Data-Provider(s) Brand Safety Segment Ids in JSON form that need to be logged. */
	int json_logger_data_provider_brand_safety_segment_ids_len;
	/* Data-Provider respoce params. */
	void *dp_resp_params;
	/* Cache handle. */
	cache_handle_t *cache;
	/* DB connection handle. */
	db_connection_t *dbconn;
} dp_data_passing_params_t;

typedef int (*dpdataops_initialize_t)(dp_data_passing_params_t *params);
typedef int (*dpdataops_get_post_data_t)(dp_data_passing_params_t *params);
typedef int (*dpdataops_get_logger_data)(data_provider_logger_data_params_t *params);
typedef int (*dpdataops_cleanup_t)(dp_data_passing_params_t *params);
typedef struct dp_data_passing_ops
{
	dpdataops_initialize_t initialize;
	dpdataops_get_post_data_t get_post_data;
	dpdataops_get_logger_data get_logger_data;
	dpdataops_cleanup_t cleanup;
} dp_data_passing_ops_t;

struct rt_request_params;

//For given Campaignget Contextual & Brand Safety data from Data-Provider(s).
//Returns: On success 0 & on failure 1.
int get_campaign_data_provider_contextual_and_brandsafety_data(long campaign_id,
									  campaign_data_provider_data_ops_params_t *params,
									  struct rt_request_params *rt_request_params,
									  cache_handle_t *cache_handle,
									  db_connection_t *dbconn);
int get_data_provider_logger_data(char json_data_provider_data[MAX_JSON_DATA_PROVIDER_DATA + 1],
								struct rt_request_params *rt_request_params);
void cleanup_campaign_data_provider_data(long campaign_id,
							campaign_data_provider_data_ops_params_t *params,
							struct rt_request_params *rt_request_params);

#endif //__DP_DATA_PASSING_GENERIC_H__
