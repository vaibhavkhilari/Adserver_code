/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __CAMPAIGN_DATA_PROVIDER_DATA_H__

#define __CAMPAIGN_DATA_PROVIDER_DATA_H__

#include "dp_data_passing_constants.h"

/* Contextual data provided by Data-Provider. */
typedef struct data_provider_contextual_data
{
      int category_id;
      int weight;
} data_provider_contextual_data_t;

/* Brand Safety data provided by Data-Provider in JSON form. */
typedef struct data_provider_brand_safety_data
{
      int category_id;
      int weight;
} data_provider_brand_safety_data_t;

/* Data provided by Data-Provider. */
typedef struct data_provider_data
{
	/* Campaign ID. */
	long campaign_id;
	/* Id of the Data Provider. */
	int data_provider_id;
	/*
	* Values can be either "page" or "rough". This provides the context of categorization.
	* If it is not possible to determine page level categorization, then type "rough" is used to
	* denote categorization based on site domain.
	*/
	char scope[DATA_PROVIDER_DATA_SCOPE_LEN + 1];
	/* Currently, we support categorization based on list provided by IAB. */
	char type[DATA_PROVIDER_DATA_TYPE_SIZE + 1];
	/* Contextual data provided by Data-Provider in JSON form. */
	char *json_contextual_data;
	/* Length of Contextual data provided by Data-Provider in JSON form. */
	int json_contextual_data_len;
	/* Brand Safety data provided by Data-Provider in JSON form. */
	char *json_brand_safety_data;
	/* Length of Brand Safety data provided by Data-Provider in JSON form. */
	int json_brand_safety_data_len;
	/* Data which is in JSON form thats need to be logged. */
	char *json_logger_data;
	/* Legnth of data which is in JSON form thats need to be logged. */
	int json_logger_data_len;
} data_provider_data_t;

/* Data provided by Data-Provider(s) for given Campaign. */
typedef struct campaign_data_provider_data
{
	/* Data provided by various Data-Provider(s). */
	data_provider_data_t *dp_data[MAX_DATA_PROVIDERS];
	/* Count of entries in the above array. */
	int dp_data_count;
} campaign_data_provider_data_t;

#endif //__CAMPAIGN_DATA_PROVIDER_DATA_H__
