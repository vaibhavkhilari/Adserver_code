/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DB_DEAL_DEF_H__
#define __DB_DEAL_DEF_H__


#include "fte_types.h"
#include "floor_rules_types.h"
#include "fte_handle.h"
#include "ad_server_types.h"

typedef struct db_deals{

	SQLINTEGER s_publisher_id ;
	SQLINTEGER s_deal_id ;
	SQLINTEGER s_pubmatic_deal_id ;
	SQLCHAR s_pub_deal_id[MAX_DEAL_ID_LEN + 1];
	SQLINTEGER s_deal_meta_id ;
	SQLDOUBLE s_deal_ecpm ;
	SQLDOUBLE s_deal_second_price_margin ;
	SQLDOUBLE s_pub_margin ;
	SQLINTEGER s_site_id ;
	SQLINTEGER s_deal_level_feature_flag ;
	SQLCHAR s_site_section[MAX_SITE_SECTION_SIZE + 1];
	SQLINTEGER s_pubmatic_buyer_id ;
	SQLCHAR s_country_code[MAX_GEO_CODE_LEN + 1];
	SQLCHAR s_region_code[MAX_GEO_CODE_LEN + 1];
	SQLCHAR s_city_name[RED_MAX_GEO_NAME_LEN + 1];
	SQLINTEGER s_dma_code ;
	SQLINTEGER s_dsp_id ;
	SQLINTEGER s_campaign_id ;
	SQLCHAR s_active_entities[MAX_ACTIVE_ENTITY_SIZE + 1];
	SQLINTEGER s_dsp_buyer_id ;
	SQLINTEGER s_auction_id ;
	SQLCHAR s_segment[MAX_SEGMENT_EXPR_SIZE + 1];
	SQLINTEGER s_days_of_week;
	SQLINTEGER s_ad_size_id ;
	SQLINTEGER s_ad_id ;
	SQLINTEGER s_start_time_parting;
	SQLINTEGER s_end_time_parting;
	SQLINTEGER s_deal_type;
	SQLINTEGER s_line_item_id;
	SQLINTEGER s_os_id;
	SQLINTEGER s_os_type_id;
	SQLINTEGER s_make_model_id;
	SQLINTEGER s_carrier_id;
	SQLINTEGER s_browser_id;
	SQLINTEGER s_mobile_device_type_id;
	SQLINTEGER s_mobile_request_type_id;
	SQLINTEGER s_mobile_udid_type_validation;
	SQLINTEGER s_mobile_latlong_validation;
	SQLINTEGER s_video_ad_type;
	SQLINTEGER s_video_ad_position;
	SQLINTEGER s_video_playback;
	SQLINTEGER s_video_skippable;
	SQLINTEGER s_video_skip_offset;
	SQLINTEGER s_video_noskip_adlen;
	SQLINTEGER s_video_player_size;
	SQLINTEGER s_strategy_id;
	SQLINTEGER s_dow_bitmask ;
	SQLINTEGER s_fold_position_id;
  SQLINTEGER s_matched_user;
	SQLUBIGINT s_richmedia_allowed_creative_attr_map;
	SQLINTEGER s_ad_type_id;
	SQLINTEGER s_platform_id;
	SQLDOUBLE s_segment_price;
	SQLINTEGER s_deal_channel_type_id;
	SQLINTEGER s_source;
	SQLINTEGER s_publisher_owned;

	SQLLEN cb_publisher_id ;
	SQLLEN cb_deal_id ;
	SQLLEN cb_pubmatic_deal_id ;
	SQLLEN cb_pub_deal_id ;
	SQLLEN cb_deal_meta_id ;
	SQLLEN cb_deal_ecpm ;
	SQLLEN cb_deal_second_price_margin ;
	SQLLEN cb_pub_margin ;
	SQLLEN cb_site_id ;
	SQLLEN cb_deal_level_feature_flag ;
	SQLLEN cb_site_section ;
	SQLLEN cb_pubmatic_buyer_id ;
	SQLLEN cb_country_code ;
	SQLLEN cb_region_code ;
	SQLLEN cb_city_name ;
	SQLLEN cb_dma_code ;
	SQLLEN cb_dsp_id ;
	SQLLEN cb_campaign_id ;
	SQLLEN cb_active_entities ;
	SQLLEN cb_dsp_buyer_id ;
	SQLLEN cb_auction_id ;
	SQLLEN cb_segment;
	SQLLEN cb_days_of_week ;
	SQLLEN cb_ad_size_id ;
	SQLLEN cb_ad_id ;
	SQLLEN cb_deal_type;
	SQLLEN cb_line_item_id;
	SQLLEN cb_os_id;
	SQLLEN cb_os_type_id;
	SQLLEN cb_make_model_id;
	SQLLEN cb_carrier_id;
	SQLLEN cb_browser_id;
	SQLLEN cb_mobile_device_type_id;
	SQLLEN cb_mobile_request_type_id;
	SQLLEN cb_mobile_udid_type_validation;
	SQLLEN cb_mobile_latlong_validation;
	SQLLEN cb_video_ad_type;
	SQLLEN cb_video_ad_position;
	SQLLEN cb_video_playback;
	SQLLEN cb_video_skippable;
	SQLLEN cb_video_skip_offset;
	SQLLEN cb_video_noskip_adlen;
	SQLLEN cb_video_player_size;
	SQLLEN cb_strategy_id;
	SQLLEN cb_start_time_parting;
	SQLLEN cb_end_time_parting;
	SQLLEN cb_dow_bitmask ;
	SQLLEN cb_fold_position_id;
	SQLLEN cb_matched_user;
	SQLLEN cb_richmedia_allowed_creative_attr_map;
	SQLLEN cb_ad_type_id;
	SQLLEN cb_platform_id;
	SQLLEN cb_segment_price;
	SQLLEN cb_deal_channel_type_id;
	SQLLEN cb_source;
	SQLLEN cb_publisher_owned;
}db_deal_t;


#endif
