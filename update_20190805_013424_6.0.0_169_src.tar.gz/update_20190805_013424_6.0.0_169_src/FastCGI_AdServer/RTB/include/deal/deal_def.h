/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __DEAL_DEF_H__
#define __DEAL_DEF_H__



#define MAX_DEAL_ID_LEN											64
#define MAX_DEAL_ACTIVE_ENTITIES								8
#define MAX_DEAL_ACTIVE_ENTITIES_STR_LEN						128
#define MAX_DEAL_SITE_URL_LEN									64
#define MAX_DEAL_PAGE_URL_SIZE									64
#define MAX_DEAL_REF_URL_SIZE									64
#define MAX_DEAL_OBJECTS										400

#define AUCTION_TYPE_ERROR 0
#define AUCTION_TYPE_FIRST_PRICE 1
#define AUCTION_TYPE_SECOND_PRICE 2
#define AUCTION_TYPE_FIXED_PRICE 3
#define AUCTION_TYPE_FRA_DISCOUNT 4

#define DEAL_CHANNEL_TYPE_PMP 1
#define DEAL_CHANNEL_TYPE_PREFERRED 5
#define DEAL_CHANNEL_TYPE_PMPG 6

#define NO_DEAL_MARGIN 0
#define FIXED_DEAL_MARGIN 1
#define DYNAMIC_DEAL_MARGIN 2
#define NOT_CONFIGURED_MARGIN -999 //TODO:Modify this as default in DB
#define NOT_CONFIGURED_MARGIN_OLD 0 //TODO:Deprecate this after changing DB default to -999

#define IS_FEATURE_ENABLED(SOURCE_MAKS, CHECK_BIT)					(SOURCE_MAKS & CHECK_BIT)

#define CAMPAIGN_HAS_DEALS(CMPG, RT_REQ_PARAM_MASK)    ((CMPG)->ad_campaign_list_setings->applicable_dsp_buyers != NULL && \
		*(CMPG)->ad_campaign_list_setings->applicable_dsp_buyers != NULL && \
		(CMPG)->ad_campaign_list_setings->applicable_dsp_buyers_count > 0 && (RT_REQ_PARAM_MASK)->deal_id_passing_enable_flag == 1)

#define IS_BID_FOR_DEAL(CMPG) ((CMPG)->ad_campaign_list_setings->dsp_interested_deal != NULL)

#define IS_FIXED_PRICE_DEAL(CMPG) (IS_BID_FOR_DEAL(CMPG) && \
		(CMPG)->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type == AUCTION_TYPE_FIXED_PRICE)

#define IS_FIRST_PRICE_DEAL(CMPG) (IS_BID_FOR_DEAL(CMPG) && \
		(CMPG)->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type == AUCTION_TYPE_FIRST_PRICE)

#define IS_SECOND_PRICE_DEAL(CMPG) (IS_BID_FOR_DEAL(CMPG) && \
		(CMPG)->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type != AUCTION_TYPE_FIXED_PRICE && \
		(CMPG)->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type != AUCTION_TYPE_FIRST_PRICE)

//Margin can be applied only on static/dynamic margin enabled first/second price deals
#define IS_DEAL_PUB_MARGIN_APPLICABLE(CMPG) (IS_BID_FOR_DEAL(CMPG) && \
		((CMPG)->ad_campaign_list_setings->applied_floor_rules_settings.floor_rule_auction_type != AUCTION_TYPE_FIXED_PRICE) && \
		((CMPG)->ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->pub_margin_type != NO_DEAL_MARGIN)) 

//FOR FP-MLA, P2 can be applied only on first/second price deal with fixed/dynamic margin type
//For SP-MLA, P2 can be applied only on second price deals irrespective of margin type(no/fixed/dynamic)
#define IS_DEAL_P2_APPLICABLE(CMPG, PRICING_ALGO, IS_FPMLA) ((PRICING_2_0 == PRICING_ALGO) && \
		((IS_FPMLA && IS_DEAL_PUB_MARGIN_APPLICABLE(CMPG)) || (!IS_FPMLA && !IS_FIXED_PRICE_DEAL(CMPG))))

//MAP2 can be applied only on dynamic margin enabled first/second price deals
#define IS_DEAL_MAP2_APPLICABLE(CMPG) (IS_DEAL_PUB_MARGIN_APPLICABLE(CMPG) && \
		(CMPG)->ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->pub_margin_type == DYNAMIC_DEAL_MARGIN)

#define IS_DEAL_LEVEL_FEATURE_FLAG_SET(CMPG, FLAG_VAL) (IS_BID_FOR_DEAL(CMPG) &&  \
		(CMPG)->ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_level_feature_flag & FLAG_VAL)

#define IS_DEAL_SECOND_PRICE_MARGIN_APPLICABLE(CMPG)	 (IS_BID_FOR_DEAL(CMPG) && \
		(CMPG)->ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_second_price_margin >= 0.0)

#define IS_ACTIVE_ENTITY(IDX, ACTV_NTTY_BMP)            (test_bit((IDX), (unsigned long long *) (&(ACTV_NTTY_BMP))) != 0)

#define DEAL_PARAMS_STRING                  "\"deals\":["
#define DEAL_OBJECT_START_STRING            "{"
#define DEAL_ID_STRING                      "id"
#define DEAL_BUYER_ID_STRING                "buyerId"
#define DEAL_AUCTION_ID_STRING              "auctionId"
#define DEAL_FLOOR_STRING                   "floor"
#define DEAL_OBJECT_END_STRING              "}"
#define DEAL_PARAMS_STRING_END              "]"
/*deal_feature_flag in deal table is unsigned int, each bit represent functionality enabled on that deal */  
typedef enum deal_feature_flag{
	APPLY_DYNAMIC_FLOOR = 1,
	APPLY_DEAL_WHITE_LIST = 2,
	LAST_LOOK_BUY = 4,
	CUSTOM_TARGETING_ENABLED = 8, //For key-val targeting, hardcoded as 8 in  db_deals_custom_tageting_trie.c
	EVALUATE_PUBLISHER_REQUESTED_DEALS = 16 //If enabled ,deals will be passed to DSP if it come in request from publisher and pass all criteria.

}deal_feature_flag;


typedef enum mobile_udid_type_validation_flag{
	MOBILE_UDID_TYPE_ANDROID_FLAG = 1 << 3,
	MOBILE_UDID_TYPE_IDFA_FLAG	 = 1 << 1
}mobile_udid_type_validation_flag_t;

typedef struct memcached_deals{
    unsigned int nelements;
    ssize_t total_sizeof_protobuff_deals;
}memcached_deals_t;
/*
 * test_bit - Test a bit in memory
 * @nr: the bit to test.
 */
static inline unsigned long long test_bit(int nr, unsigned long long *addr)
{
	return ((1ULL << nr) & (*addr));
}


#ifdef DEAL_DEBUG
	#define DEAL_DEBUG_LOG(format, ...) fprintf(stderr, format " :%s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__);
#else
	#define DEAL_DEBUG_LOG(format, ...)
#endif

/*
typedef struct memcached_deal_params
{
	int deal_id;
	//Deal Id given by Management.
	int pubmatic_deal_id;
	unsigned long line_item_id;
  unsigned long strategy_id;
	// Deal ID as entered by Publisher.
	char pub_deal_id[MAX_DEAL_ID_LEN + 1];
	double deal_ecpm;
	double deal_second_price_margin;
	int deal_type;
	double pub_margin;
	int auction_id;
	long site_id;
	int dsp_id;
	int pubmatic_buyer_id;
	int dsp_buyer_id;
	long campaign_id;
	char site_section[MAX_SITE_SECTION_SIZE + 1];
	char country_code[MAX_GEO_CODE_LEN + 1];
	char region_code[MAX_GEO_CODE_LEN + 1];
	char city_name[RED_MAX_GEO_NAME_LEN + 1];
	char segment_expr[MAX_SEGMENT_EXPR_SIZE + 1];
	int dma_code;
    int start_time_parting;
    int end_time_parting;
    int days_of_week;
	long ad_id;
	unsigned long ad_size_id;
	int os_id;
	int device_id;
	int carrier_id;
	int browser_id;
	//Bitmap for active entities in the Deal.
	//NOTE: Size of this field should always in-sync with ACTIVE_ENTITIES_CODE.
	__u64 active_entities_bitmap;
	int active_entities_count;
} memcached_deal_params_t;

typedef struct memcached_deal_url_overriding_params
{
	int deal_id;
	int dsp_id;
	long campaign_id;
	char site_url[MAX_DEAL_SITE_URL_LEN + 1];
	char page_url[MAX_DEAL_PAGE_URL_SIZE + 1];
	char ref_url[MAX_DEAL_REF_URL_SIZE + 1];
} memcached_deal_url_overriding_params_t;

typedef struct deal_url_overriding_params
{
	int deal_id;
	int dsp_id;
	long campaign_id;
	//Memory for site, page & ref URL shall be allocated at the end of & along with deal_url_overriding_params_t.
	char *site_url;
	char *page_url;
	char *ref_url;
} deal_url_overriding_params_t;

typedef struct deal_criteria
{
	long campaign_id;
	//Memory for Site Section, Country Code, Region Code & City Name shall be allocated
	//at the end of & along with deal_criteria_t.
	char *site_section;
	char *country_code;
	char *region_code;
	char *city_name;
	char *segment_expr;
	int dma_code;
    int start_time_parting;
    int end_time_parting;
    int days_of_week;
	long ad_id;
	unsigned long ad_size_id;
	//Bitmap for active entities in the Deal.
	//NOTE: Size of this field should always in-sync with ACTIVE_ENTITIES_CODE.
	__u64 active_entities_bitmap;
	int active_entities_count;
	//Evaluation result holders
	int geo_evaluation_result;
	int site_section_evaluation_result;
	int segment_expr_evaluation_result;
	int time_parting_evaluation_result;
    int day_parting_evaluation_result;
	int ad_size_evaluation_result;
	int ad_id_evaluation_result;
	int browser_id_evaluation_result;
	int os_id_evaluation_result;
	int device_id_evaluation_result;
	int carrier_id_evaluation_result;
	int line_item_id;
  int strategy_id;
  int os_id;
  int device_id;
  int carrier_id;
  int browser_id;
} deal_criteria_t;

typedef struct deal_attributes
{
	long site_id;
	int pubmatic_buyer_id;
	int dsp_buyer_id;
	int dsp_id;
	//Pointer to parent/container.
	struct deal_params *parent_deal_params;
	int deal_criteria_count;
	deal_criteria_t **deal_criteria;
	
	//List of applicable deal_criteria;
	deal_criteria_t **applicable_deal_criteria;
	int applicable_deal_criteria_count;

} deal_attributes_t;

typedef struct deal_params
{
	int deal_id;
	//Deal Id given by Management.
	int pubmatic_deal_id;
	// Deal ID as entered by Publisher.
	char pub_deal_id[MAX_DEAL_ID_LEN + 1];
	//1 - Fixed, 2 - Second Price.
	int auction_id;
	double deal_ecpm;
	double deal_second_price_margin;
	double pub_margin;
	int deal_attributes_count;
	deal_attributes_t **deal_attributes;
	int deal_type;
} deal_params_t;
*/
/*
typedef struct db_deals{

	SQLINTEGER s_publisher_id ;
	SQLINTEGER s_deal_id ;
	SQLINTEGER s_pubmatic_deal_id ;
	SQLCHAR s_pub_deal_id[MAX_DEAL_ID_LEN + 1];
	SQLDOUBLE s_deal_ecpm ;
	SQLDOUBLE s_deal_second_price_margin ;
	SQLDOUBLE s_pub_margin ;
	SQLINTEGER s_site_id ;
	SQLCHAR s_site_section[MAX_SITE_SECTION_SIZE + 1];
	SQLINTEGER s_pubmatic_buyer_id ;
	SQLCHAR s_country_code[MAX_GEO_CODE_LEN + 1];
	SQLCHAR s_region_code[MAX_GEO_CODE_LEN + 1];
	SQLCHAR s_city_name[RED_MAX_GEO_NAME_LEN + 1];
	SQLINTEGER s_dma_code ;
	SQLINTEGER s_dsp_id ;
	SQLINTEGER s_campaign_id ;
	SQLCHAR s_active_entities[MAX_ACTIVE_ENTITY_SIZE + 1];
	SQLINTEGER s_dsp_buyer_id ;
	SQLINTEGER s_auction_id ;
	SQLCHAR s_segment[MAX_SEGMENT_EXPR_SIZE + 1];
	SQLINTEGER s_days_of_week;
	SQLINTEGER s_ad_size_id ;
	SQLINTEGER s_ad_id ;
	SQLINTEGER s_start_time_parting;
	SQLINTEGER s_end_time_parting;
	SQLINTEGER s_deal_type;
	SQLINTEGER s_line_item_id;
	SQLINTEGER s_os_id;
	//TODO  divyesh change to max device id len;
	SQLCHAR s_device_id[MAX_HASHED_DEVICE_ID_LEN +1];
	SQLINTEGER s_carrier_id;
	SQLINTEGER s_browser_id;
	SQLINTEGER s_strategy_id;
	SQLINTEGER s_dow_bitmask ;

	SQLLEN cb_publisher_id ;
	SQLLEN cb_deal_id ;
	SQLLEN cb_pubmatic_deal_id ;
	SQLLEN cb_pub_deal_id ;
	SQLLEN cb_deal_ecpm ;
	SQLLEN cb_deal_second_price_margin ;
	SQLLEN cb_pub_margin ;
	SQLLEN cb_site_id ;
	SQLLEN cb_site_section ;
	SQLLEN cb_pubmatic_buyer_id ;
	SQLLEN cb_country_code ;
	SQLLEN cb_region_code ;
	SQLLEN cb_city_name ;
	SQLLEN cb_dma_code ;
	SQLLEN cb_dsp_id ;
	SQLLEN cb_campaign_id ;
	SQLLEN cb_active_entities ;
	SQLLEN cb_dsp_buyer_id ;
	SQLLEN cb_auction_id ;
	SQLLEN cb_segment;
	SQLLEN cb_days_of_week ;
	SQLLEN cb_ad_size_id ;
	SQLLEN cb_ad_id ;
	SQLLEN cb_deal_type;
	SQLLEN cb_line_item_id;
	SQLLEN cb_os_id;
	SQLLEN cb_device_id;
	SQLLEN cb_carier_id;
	SQLLEN cb_browser_id;
	SQLLEN cb_strategy_id;
	SQLLEN cb_start_time_parting;
	SQLLEN cb_end_time_parting;
	SQLLEN cb_dow_bitmask ;
}db_deals_t;
*/
#endif



