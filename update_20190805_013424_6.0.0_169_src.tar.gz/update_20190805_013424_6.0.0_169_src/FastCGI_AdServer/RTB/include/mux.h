/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __MUX_H__
#define __MUX_H__

enum MUX_MODE {
	NO_MUX = 0,
	SINGLE_AD_SIZE_MUX,
	MULTI_AD_SIZE_MUX
};

#define CHECK_CONTROL_BIT(cntrlBitMap, bitpos) (cntrlBitMap & (1u << bitpos))

//Structure to keep track of response & curl handle of the dsps where mux is enabled
typedef struct rt_mux_info {
	int mux_mode; //refer above enum
	int orig_request_index; //index of rt_response_params object
	int max_multi_requests; // max requests per cam
	int protocol; // RTB Protocol

	/* drproxy_dsp_url is the DSP URL that should be used if
	 * use_drproxy == 1
	 */
	const char *drproxy_dsp_url;

	/* gopro_dsp_url is the DSP URL that should be used if
	 * use_gopro == 1
	 */
	const char *gopro_dsp_url;

	replace_info_t replace_info[MAX_REPLACE_PARAMS];
	uint8_t bidrequest_compress ; //flag to indicate request compression 0 => disabled 1 => enabled
	uint8_t bidresponse_compress ; //flag to indicate request compression 0 => disabled 1 => enabled
	int enable_camp_syncup_stats;
} rt_mux_info_t;

int prepare_mux_requests(rt_mux_info_t rt_mux[],
		const int mux_campaign_count,
		int *max_rt_batch_count,
		int *rt_requests_count,
		rt_response_params_t *rt_response_params,
		rt_request_params_t *rt_request_params,
		char post_data[][MAX_POST_DATA_LEN + 1],
		int *curl_handle_count,
		void *header_list_x,
		int *size_header_list,
		const int rtb_debug_enabled,
		ad_server_additional_params_t* additional_parameters,
		const rt_request_url_params_mask_t *rt_request_url_params_mask,
		int cache_ret_cnt,
		buffer_tracker_t *p_buffer_tracker,
		int adstimeout,
		int pub_camp_stats_map_cnt);

void update_camp_cookie_stats (libstat_counters_t * libstat_counters,
			       int is_cookied,
			       int is_digitrust, long campaign_id);
void update_pub_camp_eids_map (pub_camp_stats_map_t * pub_camp_stats_map,
			       int is_cookied,
			       int is_digitrust, long campaign_id);
#endif
