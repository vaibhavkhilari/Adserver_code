/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <strings.h>
#include "cookie_store_util.h"
#include "error.h"
#include "ad_server_type_helper.h"

void init_cookie_store_data(cookie_store_data_t *cookie_store_data) {
	rtb_piggyback_cookies_t		*piggyback_cookies = NULL;
	piggyback_data_per_campaign_t	*campaign_data = NULL;
	net_freq_data_t			*nfd = NULL;
	camp_freq_data_t		*cfd = NULL;
	int				i, j;

	if (cookie_store_data == NULL) {
		return;
	}
	cookie_store_data->pubmatic_uid[0] = '\0';
	cookie_store_data->pmoo[0] = '\0';

	// Init piggyback cookies part of CSD.
	piggyback_cookies = &(cookie_store_data->rtb_piggyback_data);
	piggyback_cookies->no_of_dsps = 0;
	for (i = 0; i < MAX_RTB_DSPS; i++) {
		piggyback_cookies->dspid[i] = 0;
		campaign_data = &(piggyback_cookies->dsp_cookie[i]);
		campaign_data->no_of_campaigns = 0;
		campaign_data->expiry = 0;
		for (j = 0; j < MAX_CAMPAIGNS_PER_DSP; j++) {
			campaign_data->campaignid[j] = 0;
			campaign_data->campaign_cookie[j][0] = '\0';
		}
	}

	// Init net-freq data part of CSD
	nfd = &(cookie_store_data->net_freq_data);
	nfd->no_of_net = 0;
	nfd->siteid = 0;
	nfd->pending_writes = 0;
	for (i = 0; i < MAX_NET_FREQ; i++) {
		nfd->network_data[i].net_id = 0;
		nfd->network_data[i].count = 0;
		nfd->network_data[i].expiry = 0;
	}
	cfd = &(cookie_store_data->camp_freq_data);
	cfd->no_freq_camp = 0;
	cfd->pending_writes = 0;
	for (i = 0; i < MAX_CAMP_FREQ; i++) {
		cfd->campaign_data[i].camp_id = 0;
		cfd->campaign_data[i].count = 0;
		cfd->campaign_data[i].expiry = 0;
	}

	

	return;
}

void print_cookie_store_data(cookie_store_data_t *cookie_store_data) {
	rtb_piggyback_cookies_t		*piggyback_cookies = NULL;
	piggyback_data_per_campaign_t	*campaign_data = NULL;
	net_freq_data_t			*nfd = NULL;
	camp_freq_data_t		*cfd = NULL;
	int i, j;

	if (cookie_store_data == NULL) {
		return;
	}
	llog_write(L_DEBUG, "----------------PASSED-COOKIE-DATA----------------------\n");
	llog_write(L_DEBUG, "pubmatic_uid: %s\n", cookie_store_data->pubmatic_uid);
	llog_write(L_DEBUG, "pmoo cookie: %s\n", cookie_store_data->pmoo);
	piggyback_cookies = &(cookie_store_data->rtb_piggyback_data);
	llog_write(L_DEBUG, "................PIGGYBACK-DATA................\n");
	for (i = 0; i < piggyback_cookies->no_of_dsps; i++) {
		campaign_data = &(piggyback_cookies->dsp_cookie[i]);
		llog_write(L_DEBUG, "dspid: %d expiry:%ld\n", piggyback_cookies->dspid[i], campaign_data->expiry);
		for (j = 0; j < campaign_data->no_of_campaigns; j++) {
			llog_write(L_DEBUG, "campid: %d cookie:%s\n", campaign_data->campaignid[j],
								campaign_data->campaign_cookie[j]);
		}
	}
	nfd = &(cookie_store_data->net_freq_data);
	llog_write(L_DEBUG, "...............NET_FREQ-DATA..................\n");
	llog_write(L_DEBUG, "siteid: %d\n", nfd->siteid);
	llog_write(L_DEBUG, "pending count: %d\n", nfd->pending_writes);
	for (i = 0; i < nfd->no_of_net; i++) {
		llog_write(L_DEBUG, "network_id: %d, frequency: %d, expiry: %lu\n", nfd->network_data[i].net_id,
				nfd->network_data[i].count, nfd->network_data[i].expiry);
	}
	cfd = &(cookie_store_data->camp_freq_data);
	llog_write(L_DEBUG, "...............CAMP_FREQ-DATA..................\n");
	llog_write(L_DEBUG, "pending count: %d\n", cfd->pending_writes);
	for (i = 0; i < cfd->no_freq_camp; i++) {
		llog_write(L_DEBUG, "campaign_id:%d, frequency: %d, expiry: %lu\n", cfd->campaign_data[i].camp_id,
				cfd->campaign_data[i].count, cfd->campaign_data[i].expiry);
	}
	llog_write(L_DEBUG, "...............USER_FLOOR_DATA.................\n");
	llog_write(L_DEBUG, "user_floor_value: %f\n", cookie_store_data->user_floor_data.cs_user_floor_value);
	llog_write(L_DEBUG, "default_site_flag: %d\n", cookie_store_data->user_floor_data.cs_default_site_flag);
	llog_write(L_DEBUG, "-------------------------------------------------------\n");
	return;
}

int init_cookie_store_curl_handle(CURL **handle, int conn_timeout, int req_timeout) {

	CURLcode curl_retval = CURLE_OK;

	if (conn_timeout <= 0 || req_timeout <= 0) {
		llog_write(L_DEBUG, "ERROR illegal input params to CScurl init %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	(*handle) = NULL;
	(*handle) = curl_easy_init();
	if ((*handle) == NULL){
		llog_write(L_DEBUG,"\nERROR curl_easy_init() failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	curl_retval = curl_easy_setopt((*handle), CURLOPT_CONNECTTIMEOUT_MS, conn_timeout);
	if (curl_retval != CURLE_OK){
		llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set cookie_store connection timeout %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	curl_retval = curl_easy_setopt((*handle), CURLOPT_TIMEOUT_MS, req_timeout);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set cookie_store request timeout %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	curl_retval = curl_easy_setopt((*handle), CURLOPT_NOSIGNAL, 1);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set no signal %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}
#if 0
	curl_retval = curl_easy_setopt((*handle), CURLOPT_VERBOSE, 1);
	if (curl_retval != CURLE_OK){
		llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed %s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}
#endif

	return ADS_ERROR_SUCCESS;
}

void free_cookie_store_curl_handle(CURL **handle){
	if ((*handle) != NULL){
		curl_easy_cleanup((*handle));
		(*handle) = NULL;
	}
}
