/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h>
#include "ctleaf_error.h"
#include "fetch_cookie_from_store.h"
#include "network_byte_order.h"
#include "c_func_header.h"
#include "ctleaf_wrapper.h"
#include "serversidestore_types.h"
#include "server_side_cookie_store.h"
#include <time.h>
#include "log_fw.h"
#include "slist.h"

extern char *g_rtb_rpug_url;
extern char *g_rtb_spug_url;
extern char *g_rtb_floor_rpug_url;
#if 0
static char* deserialize_int(unsigned char* buf, int* n) {
	*n=0;
	*n|=buf[0]<<24;
	*n|=buf[1]<<16;

	*n|=buf[2]<<8;
	*n|=buf[3];
	return (char *)(buf+4);
}
#endif
size_t
rpug_memory_callback(void *ptr,
				size_t size,
				size_t nmemb,
				void *data) {

	size_t	realsize = size * nmemb;
	rpug_memory_struct_t *mem = (rpug_memory_struct_t *) data;

	if ((mem->size + realsize + 1) > mem->max_length) {
		llog_write(L_DEBUG, "ERROR: Wrong data from cookie store, %s:%d\n", __FILE__, __LINE__);
		return 0; /* Return some invalid value to stop any more call back */
	}
	memcpy(&(mem->memory[mem->size]), ptr, realsize);
	mem->size += realsize;
	mem->memory[mem->size] = 0;
	return realsize;
}

size_t
spug_memory_callback(void *ptr,
			size_t size,
			size_t nmemb,
			void *data) {

	size_t	realsize = size * nmemb;
	spug_memory_struct_t *mem = (spug_memory_struct_t *) data;

	if ((mem->size + realsize + 1) > mem->max_length) {
		llog_write(L_DEBUG, "ERROR: Wrong data from spug server, %s:%d\n", __FILE__, __LINE__);
		return 0; /* Return some invalid value to stop any more call back */
	}
	memcpy(&(mem->memory[mem->size]), ptr, realsize);
	mem->size += realsize;
	mem->memory[mem->size] = 0;
	return realsize;
}

size_t
rpug_floor_memory_callback(void *ptr,
				size_t size,
				size_t nmemb,
				void *data) {

	size_t	realsize = size * nmemb;
	floor_rpug_memory_struct_t *mem = (floor_rpug_memory_struct_t *) data;
	if ((mem->size + realsize + 1) > mem->max_length) {
		llog_write(L_DEBUG, "FLOOR_ERROR: Wrong data from rpug server, %s:%d\n", __FILE__, __LINE__);
		return 0; /* Return some invalid value to stop any more call back */
	}
	memcpy(&(mem->memory[mem->size]), ptr, realsize);
	mem->size += realsize;
	mem->memory[mem->size] = 0;
	return realsize;
}

int fetch_cookiestore_data(CURL *curl,
			rpug_memory_struct_t *chunk,
			const char *partnerUID,
			int partnerID,
			int site_id) {

	CURLcode	curl_retval = CURLE_OK;
	int		error = ERROR_SUCCESS;

	char	cookie_store_url[MAX_URL_LEN + 1];

	if ((g_rtb_rpug_url == NULL) || (g_rtb_rpug_url[0] == '\0') ||
			partnerUID == NULL || site_id <= 0 || curl==NULL) {
		return ERROR_INVALID_ARGS;
        }
//	(*piggyback_cookie) = NULL;
//	(*len) = 0;
	snprintf(cookie_store_url, MAX_URL_LEN, "%s?partnerUID=%s&partnerID=%d&freq_siteid=%d", g_rtb_rpug_url,
			partnerUID, partnerID, site_id);
	//cookie_store_url[MAX_URL_LEN] = '\0';
#ifdef CS_DEBUG
	llog_write(L_DEBUG, "value of cookie_store_url(rpug) is %s: %s:%d\n", cookie_store_url, __FILE__, __LINE__);
#endif

	/*
	 * Allocate the memory for curl write back function
	 */
//	bzero(chunk, sizeof(rpug_memory_struct_t));
//	chunk->memory = malloc(MAX_COOKIE_STORE_OBJ_SIZE + 1);
//	if (chunk->memory == NULL) {
//		error = ERROR_NOMEMORY;
//		goto done;
//	}

	/*
	 * Initialize the chunk.size and chunk.memory to NULL to check
	 * in case we do not get any data from cookiestore
	 */
//	chunk->size = 0;
//	chunk->memory[0] = '\0';
	/* Set the limit for the data received from cookiestore */
//	chunk->max_length = MAX_COOKIE_STORE_OBJ_SIZE + 1;
								
	curl_retval = curl_easy_setopt(curl, CURLOPT_URL, cookie_store_url);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "ERROR CURL: error setting url: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
		error = ERROR_INTERNAL;
	}
	curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, rpug_memory_callback);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "ERROR CURL: error setting callback function: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
		error = ERROR_INTERNAL;
	}
        curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)chunk);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "ERROR CURL: error setting write buffer: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
		error = ERROR_INTERNAL;
	}

	/* get the data */
   /*     curl_retval = curl_easy_perform(curl);
	if (curl_retval != CURLE_OK) {
		if (curl_retval == CURLE_OPERATION_TIMEOUTED) {
			llog_write(L_DEBUG, "ERROR CURL: Operation Timed out, %s:%d\n", __FILE__, __LINE__);
			error = ERROR_CURL_TIMEOUT;
		} else {
			llog_write(L_DEBUG, "ERROR CURL: error easy perform: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
			error = ERROR_CURL_FAILURE;
		}
		goto done;
	}
	if (chunk.size > 0) { */ /* We got something from the cookie store to bite upon */
#ifdef CS_DEBUG 
		//llog_write(L_DEBUG, "DEBUG LOG: No of bytes received : %zu, %s:%d\n", chunk.size, __FILE__, __LINE__);
#endif

		/* make the piggyback_cookie point to the memory of chunk, this prevents extra copying */
	/*	(*piggyback_cookie) = chunk.memory;
		* return the exact lenth of the data copied */
	/*	(*len) = chunk.size;
		return ERROR_SUCCESS;
	} else {
		// empty response from cookie store
		error = ERROR_INTERNAL;
		goto done;
	}*/

        return error;
}

int construct_freq_update_url(char *partner_uid,
			int req_type,
			int camp_id,
			int site_id,
			int net_id,
			time_t cexpiry,
			time_t nexpiry,
			int secure,
			int client_call,
			char cookie_store_url[]) {
	/* Locals */
	int	retval = ERROR_SUCCESS;
	time_t	ts;
	char	*url_head = NULL;

	// get current time in EPOCH
	ts = time(&ts);

	// validate input params
	if (partner_uid == NULL ||  cookie_store_url == NULL) {
		llog_write(L_DEBUG, "Illegal parameters %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto done;
	}
	if ((req_type == UPDATE_FREQ_CAMP) && (camp_id <= 0 || site_id <= 0 || net_id <= 0 || (cexpiry != 0 && cexpiry < ts) ||
							(nexpiry != 0 && nexpiry < ts))) {
		llog_write(L_DEBUG, "Illegal input params for campaign freq spug update %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto done;
	}
	if ((req_type == UPDATE_FREQ_NET) && (site_id <= 0 || net_id <= 0 || (nexpiry != 0 && nexpiry < ts))) {
		llog_write(L_DEBUG, "Illegal input params for network freq spug update %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto done;
	}
	if (g_rtb_spug_url == NULL || g_rtb_spug_url[0] == '\0') {
		llog_write(L_DEBUG, "Illegal value of SPug url %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto done;
        }
	url_head = HTTP_REQ;
	if (secure == 1) {
		url_head = HTTPS_REQ;
	}

	/*
	 * create the SPUG server request url. It's either a update of campaign or network freq data
	 */

	if (req_type == UPDATE_FREQ_CAMP) {
		if (cexpiry > ts && nexpiry > ts) {
			snprintf(cookie_store_url, MAX_URL_LEN, "%s%s?partnerUID=%s&freq_opcode=%d&freq_campid=%d"
				"&freq_expiry=%lu&freq_siteid=%d&freq_netid=%d&freq_net_expiry=%lu&freq_client_update=%d",
				url_head, g_rtb_spug_url, partner_uid, UPDATE_FREQ_CAMP, camp_id, cexpiry,
								site_id, net_id, nexpiry, client_call);
		} else if (cexpiry > ts && nexpiry == 0) {
			snprintf(cookie_store_url, MAX_URL_LEN, "%s%s?partnerUID=%s&freq_opcode=%d&freq_campid=%d"
				"&freq_expiry=%lu&freq_siteid=%d&freq_netid=%d&freq_client_update=%d",
				url_head, g_rtb_spug_url, partner_uid, UPDATE_FREQ_CAMP, camp_id,
								cexpiry, site_id, net_id, client_call);
		} else if (cexpiry == 0 && nexpiry > ts) {
			snprintf(cookie_store_url, MAX_URL_LEN, "%s%s?partnerUID=%s&freq_opcode=%d&freq_campid=%d"
				"&freq_siteid=%d&freq_netid=%d&freq_net_expiry=%lu&freq_client_update=%d",
				url_head, g_rtb_spug_url, partner_uid, UPDATE_FREQ_CAMP, camp_id,
								site_id, net_id, nexpiry, client_call);
		} else if (cexpiry == 0 && nexpiry == 0) {
			snprintf(cookie_store_url, MAX_URL_LEN, "%s%s?partnerUID=%s&freq_opcode=%d&freq_campid=%d"
				"&freq_siteid=%d&freq_netid=%d&freq_client_update=%d",
				url_head, g_rtb_spug_url, partner_uid, UPDATE_FREQ_CAMP, camp_id, site_id, net_id, client_call);
		} else {
			llog_write(L_DEBUG, "ERROR Illegal value of expiry %s:%d\n", __FILE__, __LINE__);
			retval = ERROR_INVALID_ARGS;
			goto done;
		}
	} else if (req_type == UPDATE_FREQ_NET) {
		if (nexpiry > ts) {
			snprintf(cookie_store_url, MAX_URL_LEN, "%s%s?partnerUID=%s&freq_opcode=%d&freq_siteid=%d"
				"&freq_netid=%d&freq_net_expiry=%lu&freq_client_update=%d",
				url_head, g_rtb_spug_url, partner_uid, UPDATE_FREQ_NET, site_id, net_id, nexpiry, client_call);
		} else if (nexpiry == 0) {
			snprintf(cookie_store_url, MAX_URL_LEN, "%s%s?partnerUID=%s&freq_opcode=%d&freq_siteid=%d"
				"&freq_netid=%d&freq_client_update=%d",
				url_head, g_rtb_spug_url, partner_uid, UPDATE_FREQ_NET, site_id, net_id, client_call);
		} else {
			llog_write(L_DEBUG, "ERROR Illegal value of expiry %s:%d\n", __FILE__, __LINE__);
			retval = ERROR_INVALID_ARGS;
			goto done;
		}
	} else {
		llog_write(L_DEBUG, "ERROR Illegal update request for frequency cap %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto done;
	}
#ifdef CS_DEBUG
	llog_write(L_DEBUG, "value of spug_url is %s %s:%d\n", cookie_store_url, __FILE__, __LINE__);
#endif

done:
	return retval;
}

int update_spug_freq_data(CURL *curl,
			char cookie_store_url[]) {
	// Local variables
	CURLcode		curl_retval = CURLE_OK;
        spug_memory_struct_t	chunk;
	int			retval = ERROR_SUCCESS;

	// validate input params
	if (curl == NULL || cookie_store_url == NULL || cookie_store_url[0] == '\0') {
		llog_write(L_DEBUG, "Illegal parameters %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto done;
	}

	/* Initialize the chunk.size and chunk.memory to NULL to check in case we do not get any data from spug */
	chunk.size = 0;
	chunk.memory[0] = '\0';
	chunk.max_length = MAX_SPUG_RETURN_OBJ_SIZE + 1; /* Set the limit for the data received from spug */

	curl_retval = curl_easy_setopt(curl, CURLOPT_URL, cookie_store_url);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "ERROR CURL: error setting url: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
		retval = ERROR_INTERNAL;
		goto done;
	}
        curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, spug_memory_callback);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "ERROR CURL: error setting callback function: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
		retval = ERROR_INTERNAL;
		goto done;
	}
	
        curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "ERROR CURL: error setting write buffer: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
		retval = ERROR_INTERNAL;
		goto done;
	}

	/* get the data */
        curl_retval = curl_easy_perform(curl);
	if (curl_retval != CURLE_OK) {
		if (curl_retval == CURLE_OPERATION_TIMEOUTED) {
			llog_write(L_DEBUG, "ERROR CURL: Operation Timed out, %s:%d\n", __FILE__, __LINE__);
			//return ERROR_SUCCESS;
		}
		llog_write(L_DEBUG, "ERROR CURL: error easy perform: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
		retval = ERROR_INTERNAL;
		goto done;
	}
	if (chunk.size > 0) {  /* We got something from the cookie store to bite upon */
		#ifdef CS_DEBUG 
		llog_write(L_DEBUG, "DEBUG LOG: No of bytes received from spug: %zu, %s:%d\n", chunk.size, __FILE__, __LINE__);
		#endif

		/* validate the response, its either of SUCCESS or FAILURE */
		if (strncmp(chunk.memory, SPUG_SUCCESS, MAX_SPUG_RETURN_OBJ_SIZE) == 0) {
			#ifdef CS_DEBUG
			llog_write(L_DEBUG, "DATA successfully updated to Spug server\n");
			#endif
			retval = ERROR_SUCCESS;
			goto done;
		} else if (strncmp(chunk.memory, SPUG_FAILURE, MAX_SPUG_RETURN_OBJ_SIZE) == 0) {
			llog_write(L_DEBUG, "ERROR updating freq DATA Spug server %s:%d\n", __FILE__, __LINE__);
			retval = ERROR_INTERNAL;
			goto done;
		} else {
			llog_write(L_DEBUG, "ERROR: upexpected return value from SPug server %s:%d\n", __FILE__, __LINE__);
			retval = ERROR_INTERNAL;
			goto done;
		}
	} else {
		// empty response from spug server
		llog_write(L_DEBUG, "ERROR: empty response from spug server, shouldn't be the case %s:%d\n", __FILE__, __LINE__); 
		retval = ERROR_INTERNAL;
		goto done;
	}

done:
	return retval;
}


/*
 * Get the user-floor data for the given siteid using the pubmatic uid as a
 * key to citrusleaf db.
 */
int fetch_user_floor_cs(char *pubmatic_uid, const long site_id, cs_user_floor_data_t *user_floor_data) {
	int rc = ERROR_SUCCESS;
	char *user_floor_string = NULL;
	int flen = 0;

	rc = get_user_floor(pubmatic_uid, &user_floor_string, &flen);
	if (rc != ERROR_SUCCESS) {
		llog_write(L_DEBUG, "FLOOR_ERROR: error reading user-floor data %s:%d\n",__FILE__,__LINE__);
		goto done_floor;
	}
#ifdef CS_DEBUG
	print_user_floor_data(user_floor_string, flen);
#endif
	rc = get_user_floor_value(user_floor_string, flen, site_id, 
			&(user_floor_data->cs_user_floor_value), &(user_floor_data->cs_default_site_flag));
	if (rc != ERROR_SUCCESS || user_floor_data->cs_user_floor_value == 0.0) {
		llog_write(L_DEBUG, "FLOOR_ERROR: Could not get the floor value for site:%ld "
				"%s:%d\n", site_id, __FILE__, __LINE__);
		goto done_floor;
	}
#ifdef CS_DEBUG
	llog_write(L_DEBUG, "FLOOR_TRACE: user:%s siteid:%ld is_default: %d floor:%f\n", pubmatic_uid,
			site_id, user_floor_data->cs_default_site_flag, user_floor_data->cs_user_floor_value);
#endif

done_floor:
	if (user_floor_string != NULL) {
		free(user_floor_string);
		user_floor_string = NULL;
	}
	return rc;
}


/*
 * Operations : 
 * 1. Get valid pubmatic_uid from id_map(if map doesnt exist then create it)
 * 2. Get all cookies - KRTBCOOKIE, PMOO, CAMP_FCAP, NET_FCAP, USER_FLOOR
 * Returns Failure only if some issue in parsing data or timeout.
 * Return Success even if no cookies found in CS.
 */
int fetch_server_side_cookies(
		char **pubmaticUID,
		char *partnerUID,
		cookie_store_data_t *cookie_store_data,
		void **user_segment_list_info,
		const long freq_siteid,
		int *flag_read_fcap_from_cs,
		unsigned int *aero_call_counter,
		void *audience_stats,
		unsigned int *puid_cs_calls,
		unsigned int *puid_cs_map_found,
		unsigned int *puid_cs_data_found,
		int active_tag_new_approach) {

	int rc = ERROR_SUCCESS;
	char *piggyback_cookie = NULL;
	char *netfreq = NULL, *campfreq = NULL;
	char *site_netfreq = NULL, *user_floor_string = NULL;
	int flen=0, plen=0, clen=0, nlen=0, snlen=0;
	unsigned int gen = 0;
	//int cookie_len, data_len;
	float user_floor_value = 0.0;
	int default_site = 0;
#if CS_TIME_LOGGING
	/*timeval struct for execution time check*/
	struct timeval tv1,tv2,tv3,tv4;
	/*current local date.time*/
	time_t now;
#endif

	/* 
	* 1.If pubmaticID & partnerUID both are NULL, we won't be able to fetch cookies
	* 2.If its S2S ad-request partnerUID would be NULL, fetch cookies using pubmaticUID
	* 3.If we fail to generate pubmatic uid(i.e. guid) then pubmaticUID would be NULL so fetch cookies using partnerUID
	* In case 2 & 3, we must create id_map if its not present already.
	*/
	if ( (*pubmaticUID == NULL && partnerUID[0] == '\0') || 
							freq_siteid <= 0) {
		llog_write(L_DEBUG, "SSCR_ERROR: Invalid Parameters %s:%d\n", __FILE__, __LINE__);
		rc = ERROR_INTERNAL;
		goto done;
	}

	/* 
	 * Get the right pubmatic_uid for partner_uid
	 * If publisher uid(i.e. partner_uid) is present, make query on that userids basis.
	 */
	if( (partnerUID[0] != '\0') && (*pubmaticUID == NULL) ) {

		if( *pubmaticUID == NULL ) {
			(*pubmaticUID) = (char *) malloc( sizeof(char) * (MAX_USERID_LEN + 1));
			if( *pubmaticUID == NULL ) {
				llog_write(L_DEBUG, "ERROR: malloc failed for user_cookie_value %s:%d\n",
												__FILE__, __LINE__);
				return ERROR_NOMEMORY;
			}
			*pubmaticUID[0]='\0';
		}

		// increament stat cs call counter. 
		++(*puid_cs_calls);

		rc = get_pubmaticuid_from_partneruid(partnerUID, *pubmaticUID);
		if (rc != ERROR_SUCCESS) {
			///llog_write(L_DEBUG, "SSCR_ERROR: error getting mapping %s:%d\n",__FILE__,__LINE__);
			free(*pubmaticUID);
			*pubmaticUID = NULL;
			goto done;
		}

		// increament stat counters.
		++(*puid_cs_map_found);

	} 

	if((*pubmaticUID == NULL) || (*pubmaticUID)[0] == '\0') {
		llog_write(L_DEBUG, "SSCR_ERROR: No PubMatic UserId generated, %s:%d\n", __FILE__, __LINE__);
		rc = ERROR_INTERNAL;
		goto done;
	}
	
#if CS_TIME_LOGGING
	/*get time of the day before execution*/
	gettimeofday(&tv3, NULL);
#endif
	DEBUG_PRINTF("Valid PUBMATIC uid:%s\n", *pubmaticUID);
		gen = 0;
		llog_write(L_DEBUG, "Fetch server side cookie Pubmatic UID [%s]\n",*pubmaticUID);
		//count aerospike call
		(*aero_call_counter)++;
		rc = get_all_cookies(
					*pubmaticUID, 
					&campfreq, 
					&clen, 
					&netfreq,
					&nlen, 
					&piggyback_cookie, 
					&plen, 
					&user_floor_string, 
					&flen, 
					&gen, 
					user_segment_list_info,
					audience_stats,
					*flag_read_fcap_from_cs );
		if (rc != ERROR_SUCCESS) {
			if (rc == ERROR_KEY_NOT_FOUND) {
				DEBUG_PRINTF("SSCR_INFO: New User for cookie store:%s %s:%d\n",*pubmaticUID,__FILE__,__LINE__);
				rc = ERROR_SUCCESS;
				goto done;
			}
			//llog_write(L_DEBUG, "SSCR_ERROR: error reading cookie store data %s:%d\n",__FILE__,__LINE__);
			LOG_CRITICAL(SSCR_ERROR_READ,MOD_DEFAULT,"cookie store data",__FILE__,__LINE__);
			goto done;
		}

#ifdef CS_DEBUG
		llog_write(L_DEBUG,"\n**********ADSERVER-CS-START********************\n");
		llog_write(L_DEBUG,"PubMatic userID: %s", *pubmaticUID);
		print_proto_string(piggyback_cookie, plen);
		print_campfreq_data(campfreq, clen);
		print_netfreq_data(netfreq, nlen);
		print_user_floor_data(user_floor_string, flen);
		llog_write(L_DEBUG,"\n**********ADSERVER-CS-END********************\n");
#endif
		
		/*
		 * set frequency cap after calculation back to cs only if 
		 * 		we read, parse and populated respective structures. 
		 */
		if( 1 == *flag_read_fcap_from_cs ) {
			if(active_tag_new_approach == 1){
				DEBUG_PRINTF("Info:using new approach for counting active tag %s:%d\n",__FILE__,__LINE__);
				rc = generate_netfreq_data(freq_siteid, 0, 0, &netfreq, &nlen, &site_netfreq, &snlen);
				if (rc != ERROR_SUCCESS) {
					llog_write(L_DEBUG, "SSCR_ERROR: error generating netfreq protobuf "
							"object %s:%d\n", __FILE__, __LINE__);
					goto done;
				}
			}
			else {
				/*below code need to be removed once new approach is stable*/
				rc = generate_campfreq_data(0, 0, &campfreq, &clen);
				if (rc != ERROR_SUCCESS) {
					llog_write(L_DEBUG, "SSCR_ERROR: error generating campfreq protobuf "
							"object %s:%d\n", __FILE__, __LINE__);
					goto done;
				}
				rc = generate_netfreq_data(freq_siteid, 0, 0, &netfreq, &nlen, &site_netfreq, &snlen);
				if (rc != ERROR_SUCCESS) {
					llog_write(L_DEBUG, "SSCR_ERROR: error generating netfreq protobuf "
							"object %s:%d\n", __FILE__, __LINE__);
					goto done;
				}

				//count aerospike call
				(*aero_call_counter)++;
				rc = set_freqcookies(*pubmaticUID, campfreq, clen, netfreq, nlen, gen);
				if (rc != ERROR_SUCCESS) {
					*flag_read_fcap_from_cs = 0;
					clen = snlen = 0;
					if (rc != ERROR_FAIL_GENERATION) {
						LOG_CRITICAL(SSCR_ERROR_WRITE,MOD_DEFAULT,"citrusleaf", __FILE__, __LINE__);
					}
					else {	
						llog_write(L_DEBUG, "SSCR_INFO: ctleaf write failed due to gen mismatch\n");
					}
				} else {
					//llog_write(L_DEBUG, "SSCR_INFO: cookie data successflly updated\n");
					LOG_INFO(SSCR_INFO_COOKIE,MOD_DEFAULT,"data update success");
				}
			}
		}

		if (plen | clen | snlen) {
			rc = parse_proto_string(cookie_store_data, piggyback_cookie, plen, campfreq, clen, site_netfreq, snlen);

			if (rc != ERROR_SUCCESS) {
				llog_write(L_DEBUG, "SSCR_ERROR: in parsing server store data %s:%d\n", __FILE__, __LINE__);
				goto done;
			}

			if ( (partnerUID[0] != '\0') && 
					(NULL != piggyback_cookie && plen > 0) ) {

				// increament stat counters.
				++(*puid_cs_data_found);
			}
		}
		if (flen > 0) {
			if (ERROR_SUCCESS == get_user_floor_value(user_floor_string, flen,
						freq_siteid, &user_floor_value, &default_site)) {
				cookie_store_data->user_floor_data.cs_user_floor_value = user_floor_value;
				cookie_store_data->user_floor_data.cs_default_site_flag = default_site;
			}
		}

done:
#if CS_TIME_LOGGING
	/*get time of the day after execution*/
	gettimeofday(&tv4, NULL);
	/*get date for providing logs*/
	time(&now);
	llog_write(L_DEBUG,"\nSSCR_INFO: Time Log Get All Cookies [%.24s] : time_s=%ld,time = %ld\n",
			ctime(&now),
			tv4.tv_sec - tv3.tv_sec,
			tv4.tv_usec - tv3.tv_usec);
#endif

	if (piggyback_cookie) {
		free(piggyback_cookie);
		piggyback_cookie = NULL;
	}
	if (campfreq != NULL) {
		free(campfreq);
		campfreq = NULL;
	}
	if (netfreq != NULL) {
		free(netfreq);
		netfreq = NULL;
	}
	if (site_netfreq != NULL) {
		free(site_netfreq);
		site_netfreq = NULL;
	}
	if (user_floor_string != NULL) {
		free(user_floor_string);
		user_floor_string = NULL;
	}
	return rc;
}

int is_pubmatic_optout(char *pubmatic_uid) {
	char *piggyback_string = NULL;
	int data_len = 0;
	int rc = 0;
	unsigned int gen = 0;
	if(pubmatic_uid == NULL) {
		llog_write(L_DEBUG,"\nInvalid args, %s:%d\n", __FILE__, __LINE__);
		return 0;
	}

	rc = get_piggybackcookie_from_pubmatic_uid(pubmatic_uid, &piggyback_string, &data_len, &gen);
	if(rc != ERROR_SUCCESS) {
		if(rc == ERROR_KEY_NOT_FOUND) {
			llog_write(L_DEBUG,"ERROR: pmoo not found in cookie store for uid:%s\n",pubmatic_uid);
			//opt in
			rc = 0;
		}
		else {
			llog_write(L_DEBUG,"ERROR: Couldn't get piggyback_cookie for uid:%s\n",pubmatic_uid);
			//opt out
			rc = 1;
		}
		goto done;
	}

	rc = parse_pmoo_cookie(pubmatic_uid, piggyback_string, data_len);
done:
	if(piggyback_string != NULL) {
		free(piggyback_string);
		piggyback_string = NULL;
	}
	return rc;
}


#if 0
int populate_cookie_store_data(cookie_store_data_t *cookie_store_data,
			char *csdata,
			int len) {

	// Local variables
	int	retval = ERROR_SUCCESS;
//	char	*csdata = NULL;
	char	*piggyback = NULL, *campfreq = NULL, *netfreq = NULL, *userfloor = NULL;
	//int	len = 0, 
	int plen = 0, clen = 0, nlen = 0, flen = 0;

	if (cookie_store_data == NULL) {
		llog_write(L_DEBUG, "Illegal parameters %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto err;
	}

/*	retval = fetch_cookiestore_data(curl, &csdata, &len, partner_uid, partner_id, site_id);
	if (retval != ERROR_SUCCESS) {
#ifdef CS_DEBUG
		llog_write(L_DEBUG, "ERROR: couldn't get the data from serverstore %s:%d\n",
									__FILE__, __LINE__);
#endif
		goto err;
	}*/

	/*
	 * This string which is in binary format contains the data for piggyback_cookie, campaign freq and
	 * network freq. We need to extract each data before sending it to protocol buffer parsing routine.
	 */
//partner_id=0;
//site_id=0;
	retval = extract_individual_data(csdata, len, &piggyback, &plen, &campfreq, &clen, &netfreq, &nlen, &userfloor, &flen);
	if (retval != ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR: Illegal data from cookie store %s:%d\n", __FILE__, __LINE__);
		goto err;
	}
	
	// all the data fields can not be empty
	if (plen <= 0 && clen <= 0 && nlen <= 0 && flen <= 0) {
		llog_write(L_DEBUG, "ERROR: Illegal data from cookie store %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto err;
	}

	retval = parse_proto_string(cookie_store_data, piggyback, plen, campfreq, clen, netfreq, nlen);
	if (retval != ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR: in parsing server store data %s:%d\n", __FILE__, __LINE__);
		goto err;
	}

	if (flen > 0) {
		retval = parse_userfloor_data(userfloor, &(cookie_store_data->user_floor_data.cs_user_floor_value),
					&(cookie_store_data->user_floor_data.cs_default_site_flag)); 
		if (retval != ERROR_SUCCESS) {
			cookie_store_data->user_floor_data.cs_user_floor_value = 0.0;
			cookie_store_data->user_floor_data.cs_default_site_flag = 0;
			//llog_write(L_DEBUG, "ERROR: in parsing user floor data %s:%d\n", __FILE__, __LINE__);
			retval = ERROR_SUCCESS;
			
		}
	}

err:
	//if (csdata != NULL) {
	//	free(csdata);
	//	csdata = NULL;
//	}
	if (piggyback != NULL) {
		free(piggyback);
		piggyback = NULL;
	}
	if (campfreq != NULL) {
		free(campfreq);
		campfreq = NULL;
	}
	if (netfreq != NULL) {
		free(netfreq);
		netfreq = NULL;
	}
	if (userfloor != NULL) {
		free(userfloor);
		userfloor = NULL;
	}
	return retval;
}
#endif
int extract_individual_data(char *cookie_store_data,
				int len,
				char **piggyback,
				int *plen,
				char **campfreq,
				int *clen,
				char **netfreq,
				int *nlen,
				char **userfloor,
				int *flen) {

	/* Local Variables */
	int	retval = ERROR_SUCCESS;
	char	*bufp = NULL;

	// validate Arguments
	if (cookie_store_data == NULL || len <= 0) {
		llog_write(L_DEBUG, "ERROR: Illegal cookie store binary data %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto err;
	}
	if (piggyback == NULL || plen == NULL || campfreq == NULL || clen == NULL ||
	    netfreq == NULL || nlen == NULL || userfloor == NULL || flen == NULL) {
		llog_write(L_DEBUG, "ERROR: Illegal input params %s:%d\n", __FILE__, __LINE__);
		retval = ERROR_INVALID_ARGS;
		goto err;
	}

	// Init input params
	*piggyback = *campfreq = *netfreq = *userfloor = NULL;
	*plen = *clen = *nlen = *flen = 0;

	// Validate the length of the binary data with actual length as from the data
	retval = validate_binary_data(cookie_store_data, len, plen, clen, nlen, flen);
	if (retval != ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR: some problem in fetched data from store %s:%d\n", __FILE__, __LINE__);
		goto err;
	}

	// now read the actual data
	// read piggyback cookie
	bufp = cookie_store_data + SIZE_OF_INT;
	if (*plen != 0) {
		retval = allocate_and_copy(bufp, *plen, piggyback);
		if (retval != ERROR_SUCCESS) {
			llog_write(L_DEBUG, "ERROR copying data from cookie store %s:%d\n", __FILE__, __LINE__);
			goto err;
		}
	}
	bufp += (*plen) + SIZE_OF_INT;
	// read campaign freq data
	if (*clen != 0) {
		retval = allocate_and_copy(bufp, *clen, campfreq);
		if (retval != ERROR_SUCCESS) {
			llog_write(L_DEBUG, "ERROR copying data from cookie store %s:%d\n", __FILE__, __LINE__);
			goto err;
		}
	}
	bufp += (*clen) + SIZE_OF_INT;
	// read net freq data
	if (*nlen != 0) {
		retval = allocate_and_copy(bufp, *nlen, netfreq);
		if (retval != ERROR_SUCCESS) {
			llog_write(L_DEBUG, "ERROR copying data from cookie store %s:%d\n", __FILE__, __LINE__);
			goto err;
		}
	}
	bufp += (*nlen) + SIZE_OF_INT;
	//read user floor data
	if (*flen != 0) {
		retval = allocate_and_copy(bufp, *flen, userfloor);
		if (retval != ERROR_SUCCESS) {
			llog_write(L_DEBUG, "ERROR copying data from cookie store %s:%d\n", __FILE__, __LINE__);
			goto err;
		}
	}

err:
	if (retval != ERROR_SUCCESS) {
		if (*piggyback != NULL) {
			free(*piggyback);
			*piggyback = NULL;
		}
		if (*campfreq != NULL) {
			free(*campfreq);
			*campfreq = NULL;
		}
		if (*netfreq != NULL) {
			free(*netfreq);
			*netfreq = NULL;
		}
		if (*userfloor != NULL) {
			free(*userfloor);
			*userfloor = NULL;
		}
		*plen = *clen = *nlen = *flen = 0;
	}
	return retval;
}

/*
 * function to vvalidate the binary data received from cookie store.
 */

int validate_binary_data(char *data,
			int len,
			int *plen,
			int *clen,
			int *nlen,
			int *flen) {

	/* Locals */
	char	buf[SIZE_OF_INT];
	char	*bufp = NULL;

	// validate input params
	if (data == NULL || plen == NULL || clen == NULL || nlen == NULL || flen == NULL || len <= 0) {
		llog_write(L_DEBUG, "Illegal input params to validate_binary_data() %s:%d\n", __FILE__, __LINE__);
		return ERROR_INVALID_ARGS;
	}

	bufp = data;

	/*
	 * extract the lengths of individual components in the binary data and return
	 * the lengths to the caller.
	 */

	//extract piggyback cookie data len
	bzero(buf, SIZE_OF_INT);
	memcpy(buf, bufp, SIZE_OF_INT);
	bufp += SIZE_OF_INT;
	convert_byte_order_to_int(plen,buf);
	if((*plen) > len){
	     llog_write(L_DEBUG,"\nRPUG_ERROR:Length exceeded, len limit:%d, plen:%d %s:%d\n",
         len,(*plen),__FILE__,__LINE__);
	     return ERROR_INTERNAL;
    }

	bufp += *plen;
	// extract camp freq data len
	bzero(buf, SIZE_OF_INT);
	memcpy(buf, bufp, SIZE_OF_INT);
	bufp += SIZE_OF_INT;
	convert_byte_order_to_int(clen,buf);
	if((*plen)+(*clen) > len){
	     llog_write(L_DEBUG,"\nRPUG_ERROR:Length exceeded, len limit:%d, plen:%d, clen:%d, %s:%d\n",
         len,(*plen),(*clen),__FILE__,__LINE__);
	     return ERROR_INTERNAL;
    }
	bufp += *clen;
	// extract net freq data len
	bzero(buf, SIZE_OF_INT);
	memcpy(buf, bufp, SIZE_OF_INT);
	bufp += SIZE_OF_INT;
	convert_byte_order_to_int(nlen,buf);
	if((*plen)+(*clen)+(*nlen) > len){
	     llog_write(L_DEBUG,"\nRPUG_ERROR:Length exceeded, len limit:%d, plen:%d, clen:%d, nlen:%d, %s:%d\n",
         len,(*plen),(*clen),(*nlen),__FILE__,__LINE__);
	     return ERROR_INTERNAL;
    }
	bufp += *nlen;
	// extract userfloor data len
	bzero(buf, SIZE_OF_INT);
	memcpy(buf, bufp, SIZE_OF_INT);
	bufp += SIZE_OF_INT;
	convert_byte_order_to_int(flen,buf);
	if((*plen)+(*clen)+(*nlen)+(*flen) > len){
	     llog_write(L_DEBUG,"\nRPUG_ERROR:Length exceeded, len limit:%d, plen:%d, clen:%d, nlen:%d, flen:%d, %s:%d\n",
         len,(*plen),(*clen),(*nlen),(*flen),__FILE__,__LINE__);
	     return ERROR_INTERNAL;
    }
	bufp += *flen;

	if (*plen < 0 || *clen < 0 || *nlen < 0 || *flen < 0) {
		llog_write(L_DEBUG, "Error: in length of data fetched from cookie store %s:%d\n", __FILE__, __LINE__);
		return ERROR_INVALID_ARGS;
	}

	if ((*plen + *clen + *nlen + *flen + (4 * SIZE_OF_INT)) != len) {
		llog_write(L_DEBUG, "ERROR: in data fetched from cookie store %s:%d\n", __FILE__, __LINE__);
		return ERROR_INVALID_ARGS;
	}
	return ERROR_SUCCESS;
}

/*
 * Function to copy a buffer of given length. The allocated memory assosiated with
 * the copied buffer needs to be freed by the caller
 */

int allocate_and_copy(char *buf, int len, char **data) {

	if (buf == NULL || len <= 0 || data == NULL) {
		llog_write(L_DEBUG, "ERROR: Illegal input params %s:%d\n", __FILE__, __LINE__);
		return ERROR_INVALID_ARGS;
	}
	(*data) = (char *) malloc(len);
	if (*data == NULL) {
		llog_write(L_DEBUG, "ERROR: malloc failed %s:%d\n", __FILE__, __LINE__);
		return ERROR_NOMEMORY;
	}
	memcpy(*data, buf, len);
	return ERROR_SUCCESS;
}

int fetch_user_floor_value(CURL *curl,
		floor_rpug_memory_struct_t *chunk,
		const char *pubmatic_uid,
		int site_id) {

	// Local variables
	CURLcode			curl_retval = CURLE_OK;
	int				error = ERROR_SUCCESS;
	char				cookie_store_url[MAX_URL_LEN + 1];

	// validate input params
	if (g_rtb_floor_rpug_url == NULL || g_rtb_floor_rpug_url[0] == '\0' ||
			pubmatic_uid == NULL || site_id < 0 || curl==NULL) {
		llog_write(L_DEBUG, "FLOOR_ERROR: Illegal parameters to fetch_user_floor_value() %s:%d\n",
					__FILE__, __LINE__);
		error = ERROR_INVALID_ARGS;
        }

	// init params

	// construct the url for getting user floor from cookie store
	snprintf(cookie_store_url, MAX_URL_LEN, "%s?floor_uid=%s&floor_siteid=%d",
					g_rtb_floor_rpug_url, pubmatic_uid, site_id);
	cookie_store_url[MAX_URL_LEN] = '\0';
#ifdef CS_DEBUG
	llog_write(L_DEBUG, "FLOOR_INFO: value of cookie_store_url(rpug) is %s\n", cookie_store_url);
#endif
	
	
//	bzero(chunk, sizeof(floor_rpug_memory_struct_t));
//	chunk->memory = malloc(MAX_RPUG_FLOOR_OBJ_SIZE + 1);
//	if (chunk->memory == NULL) {
//		error = ERROR_NOMEMORY;
//	}
        // Initialize the chunk.size and chunk.memory to NULL to check in case we do not get any data from spug
//	chunk->size = 0;
//	chunk->memory[0] = '\0';
//	chunk->max_length = MAX_RPUG_FLOOR_OBJ_SIZE + 1; // Set the limit for the data received from spug

	curl_retval = curl_easy_setopt(curl, CURLOPT_URL, cookie_store_url);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "FLOOR_ERROR: CURL error setting url: %d, %s:%d\n",
						curl_retval, __FILE__, __LINE__);
		error = ERROR_INTERNAL;
	}
       curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, rpug_floor_memory_callback);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "FLOOR_ERROR: CURL error setting callback function: %d, %s:%d\n",
								curl_retval, __FILE__, __LINE__);
		error = ERROR_INTERNAL;
	}
        curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)chunk);
	if (curl_retval != CURLE_OK) {
		llog_write(L_DEBUG, "FLOOR_ERROR: CURL error setting write buffer: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
		error = ERROR_INTERNAL;
	}

	// get the data
      /*  curl_retval = curl_easy_perform(curl);
	if (curl_retval != CURLE_OK) {
		if (curl_retval == CURLE_OPERATION_TIMEOUTED) {
			llog_write(L_DEBUG, "FLOOR_ERROR: CURL Operation Timed out, %s:%d\n", __FILE__, __LINE__);
		}
		llog_write(L_DEBUG, "FLOOR_ERROR: CURL error easy perform: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
		error = ERROR_INTERNAL;
		goto done;
	}

	if (chunk.size > 0) {  // We got something from the cookie store to bite upon
		#ifdef CS_DEBUG 
		llog_write(L_DEBUG, "FLOOR_INFO: value returned from rpug is %s\n", chunk.memory);
		#endif

		error = parse_userfloor_data(chunk.memory, user_floor_value, default_site_flag);
		if (error != ERROR_SUCCESS) {
			llog_write(L_DEBUG, "ERROR: in parsing user floor data %s:%d\n", __FILE__, __LINE__);
			goto done;
		}
	} else {
		// empty response from cookie store
		error = ERROR_INTERNAL;
		goto done;
	}

done:*/
        return error;
}

int parse_userfloor_data(char *floor_string,
			 float *cs_ufv,
			 int *cs_dsf) {
	char	*tmpptr = NULL, *tmpptr1 = NULL;
	char	siteid_buff[MAX_INT_BUFFER_LEN + 1];
	char	floor_buff[MAX_FLOAT_BUFFER_LEN + 1];
	int	rv = ERROR_SUCCESS;

	if (floor_string == NULL || floor_string[0] == '\0' || cs_ufv == NULL || cs_dsf == NULL) {
		llog_write(L_DEBUG, "Ileegal input params parse_userfloor_data %s:%d\n", __FILE__, __LINE__);
		rv = ERROR_INTERNAL;
		goto done;
	}

	//init input params
	*cs_ufv = 0.0;
	*cs_dsf = 0;
	siteid_buff[0] = '\0';
	floor_buff[0] = '\0';

	tmpptr = floor_string;
	tmpptr1 = strchr(floor_string, ':');
	if (tmpptr1 == NULL) {
		llog_write(L_DEBUG, "ERROR: wrong floor data from cs:%s\n", floor_string);
		rv = ERROR_INTERNAL;
		goto done;
	}
	if ((tmpptr1 - tmpptr) > MAX_INT_BUFFER_LEN) {
		llog_write(L_DEBUG, "FLOOR_ERROR: illegal site id returned from cs %s:%d\n", __FILE__, __LINE__);
		rv = ERROR_INTERNAL;
		goto done;
	}
	strncpy(siteid_buff, tmpptr, tmpptr1 - tmpptr);
	siteid_buff[tmpptr1 - tmpptr] = '\0';
	tmpptr1++;
	strncpy(floor_buff, tmpptr1, MAX_FLOAT_BUFFER_LEN);
	floor_buff[MAX_FLOAT_BUFFER_LEN] = '\0';
	(*cs_ufv) = atof(floor_buff);
	if (atoi(siteid_buff) == 0) {
		*cs_dsf = 1;
	}

done:
	return rv;
}
