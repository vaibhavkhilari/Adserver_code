/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>

#include "dp_error.h"
#include "dp_db.h"

/*
 * Function:-	init_dp_contextual_config.
 * Desc:-	Function initilizes dp_contextual configuration structure.
 * Parameters:-
 * 		1) dp_contextual_config.
 *			structure variable of type dp_contextual_config_t.
 */
int init_dp_contextual_config(
	dp_contextual_config_t *dp_contextual_config) {
	/*
	 * Check function parameters.
	 */
	if(dp_contextual_config == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		return DP_ERROR_INVALID_ARGS;
	}

	dp_contextual_config->isactive = 0;
	dp_contextual_config->timeout = 0;
	dp_contextual_config->conn_timeout = 0;
	dp_contextual_config->calltype = 0;
	dp_contextual_config->dp_base_url[0] = '\0';
	dp_contextual_config->dp_authentication_method = 0;
	dp_contextual_config->dp_authentication_key[0] = '\0';
	dp_contextual_config->responsetype[0] = '\0';

	return DP_ERROR_SUCCESS;
}

/*
 * Function: dp_contextual_read_conf
 * desc:
 *		Function reads configuration information from DB for any data provider.
 */
int dp_contextual_read_conf(
	db_connection_t *dbconn,
	dp_contextual_config_t *dp_contextual_config,
	int dp_id,
	int dc_id) {
	/*
	 * Local Variables.
	 */
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN];
	SQLHANDLE statement_handle = 0;
	SQLINTEGER s_src_dp_id;
	SQLINTEGER s_src_datacenter_id;
	SQLCHAR s_src_dp_name[DP_NAME_SIZE + 1];
	SQLINTEGER s_src_dp_is_enabled;
	SQLINTEGER s_src_dp_request_timeout;
	SQLINTEGER s_src_dp_connection_timeout;
	SQLCHAR s_src_dp_base_url[MAX_URL_SIZE + 1];
	SQLINTEGER s_src_dp_authentication_type;
	SQLCHAR s_src_dp_authentication_key[DP_AUTHENTCATE_KEY_SIZE + 1];
	SQLCHAR s_src_dp_response_type[DP_RES_TYPE_BUFF_SIZE + 1];

	SQLLEN cb_src_dp_id = 0;
	SQLLEN cb_src_datacenter_id = 0;
	SQLLEN cb_src_dp_is_enabled = 0;
	SQLLEN cb_src_dp_request_timeout = 0;
	SQLLEN cb_src_dp_connection_timeout = 0;
	SQLLEN cb_src_dp_authentication_type = 0;

	int retval = DP_ERROR_SUCCESS;
	int count = 0;

#ifdef DEBUG
	llog_write(L_DEBUG, "Inside : '%s'\n", __FUNCTION__);
#endif

	/*
	 * Check function parameters.
	 */
	if ((dbconn == NULL) || (dp_contextual_config == NULL)) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	/*
	 * Allocate the statement  handle.
	 */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle,
			&statement_handle);

	/*
	 * Create SQL char string which contains the query.
	 */
	strcpy((char *) sql_statement, DP_CONTEXTUAL_READ_CONF_QUERY);

	/*
	 * Create a prepared statement.
	 */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__ );

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Bind parameters for read.
	 */
	sql_retval = SQLBindParameter(statement_handle, DP_ID_IN_IDX, SQL_PARAM_INPUT,
			SQL_C_ULONG, SQL_INTEGER, 0, 0, &s_src_dp_id, 0,
			&cb_src_dp_id);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
		sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	sql_retval = SQLBindParameter(statement_handle, DP_DATACENTER_ID_IN_IDX, SQL_PARAM_INPUT,
			SQL_C_ULONG, SQL_INTEGER, 0, 0, &s_src_datacenter_id, 0,
			&cb_src_datacenter_id);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
		sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	/*
	 * Copy the parameters for read.
	 */
	s_src_dp_id = dp_id;
	s_src_datacenter_id = dc_id;

	/*
	 * Execute the query for updating the sink db based on data from source db.
	 */
	sql_retval = SQLExecute(statement_handle);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, " FAIL THE UPDATE QUIERY :\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
			sql_retval, __LINE__, __FILE__ );

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Reaches here if the statement was executed successfully, now bind the
	 * column to get the result.
	 */
	sql_retval = SQLBindCol(statement_handle, DP_ID_OUT_IDX, SQL_C_ULONG, &s_src_dp_id,
					0, &cb_src_dp_id);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding: s_src_dp_id\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	sql_retval = SQLBindCol(statement_handle, DP_NAME_OUT_IDX, SQL_C_CHAR, &s_src_dp_name,
					DP_NAME_SIZE, NULL);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding: s_src_dp_name\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	sql_retval = SQLBindCol(statement_handle, DP_IS_ENABLED_OUT_IDX, SQL_C_ULONG, &s_src_dp_is_enabled,
					0, &cb_src_dp_is_enabled);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding: s_src_dp_is_enabled\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	sql_retval = SQLBindCol(statement_handle, DP_REQUEST_TIMEOUT_OUT_IDX, SQL_C_ULONG, &s_src_dp_request_timeout,
					0, &cb_src_dp_request_timeout);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding: s_src_dp_request_timeout\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	sql_retval = SQLBindCol(statement_handle, DP_CONNECTION_TIMEOUT_OUT_IDX, SQL_C_ULONG, &s_src_dp_connection_timeout,
					0, &cb_src_dp_connection_timeout);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding: s_src_dp_connection_timeout\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	sql_retval = SQLBindCol(statement_handle, DP_BASE_URL_OUT_IDX, SQL_C_CHAR, &s_src_dp_base_url,
					MAX_URL_SIZE, NULL);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding: s_src_dp_base_url\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	sql_retval = SQLBindCol(statement_handle, DP_AUTHENTICATION_TYPE_OUT_IDX, SQL_C_ULONG, &s_src_dp_authentication_type,
					0, &cb_src_dp_authentication_type);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding: s_src_dp_authentication_type\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	sql_retval = SQLBindCol(statement_handle, DP_AUTHENTICATION_KEY_OUT_IDX, SQL_C_CHAR, &s_src_dp_authentication_key,
					DP_AUTHENTCATE_KEY_SIZE, NULL);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding: s_src_dp_authentication_key\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	sql_retval = SQLBindCol(statement_handle, DP_RESPONSE_TYPE_OUT_IDX, SQL_C_CHAR, &s_src_dp_response_type,
					DP_RES_TYPE_BUFF_SIZE, NULL);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error binding: s_src_dp_response_type\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle,
				sql_retval, __LINE__, __FILE__);

		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}
	while (sql_retval != SQL_NO_DATA) {
		s_src_dp_name[DP_NAME_SIZE] = '\0';
		s_src_dp_base_url[MAX_URL_SIZE] = '\0';
		s_src_dp_authentication_key[DP_AUTHENTCATE_KEY_SIZE] = '\0';
		s_src_dp_response_type[DP_RES_TYPE_BUFF_SIZE] = '\0';
		/*
		 * Get data from source and update the sink.
		 */
		sql_retval = SQLFetch(statement_handle);
		if (sql_retval != SQL_NO_DATA) {
			llog_write(L_DEBUG, "dp_id : '%d', dpname : '%s', enabled : '%d', timeout : '%d', connection timeout : '%d',"
							" base_url : '%s', authen_type : '%d', authen_key : '%s', response_type : '%s'\n",
				 			(int) s_src_dp_id, s_src_dp_name, (int) s_src_dp_is_enabled, (int) s_src_dp_request_timeout, (int) s_src_dp_connection_timeout,
							s_src_dp_base_url, (int) s_src_dp_authentication_type, s_src_dp_authentication_key, s_src_dp_response_type);
			/*
			 * Copy data read from DB to proximic structure.
			 */
			dp_contextual_config->isactive = s_src_dp_is_enabled;
			dp_contextual_config->timeout = s_src_dp_request_timeout;
			dp_contextual_config->conn_timeout = s_src_dp_connection_timeout;
			//dp_contextual_config->calltype = ;
			dp_contextual_config->dp_base_url[MAX_URL_SIZE] = '\0';
			strncpy(dp_contextual_config->dp_base_url, (char *)s_src_dp_base_url, MAX_URL_SIZE);
			dp_contextual_config->dp_authentication_key[DP_AUTHENTCATE_KEY_SIZE] = '\0';
			strncpy(dp_contextual_config->dp_authentication_key, (char *)s_src_dp_authentication_key, DP_AUTHENTCATE_KEY_SIZE);
			dp_contextual_config->responsetype[DP_RES_TYPE_BUFF_SIZE] = '\0';
			strncpy(dp_contextual_config->responsetype, (char *)s_src_dp_response_type, DP_RES_TYPE_BUFF_SIZE);
			count++;
		}
	}

	/*
	 * Check if conf is read or not.
	 */
	if (count == 0) {
		llog_write(L_DEBUG, "Error: conf for dp_id : '%d' and dc_id : '%d' not present in DB \n",
							dp_id, dc_id);
		retval = DP_DB_ERROR_INTERNAL;
		goto done;
	}

done:

	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}

	return retval;
}
