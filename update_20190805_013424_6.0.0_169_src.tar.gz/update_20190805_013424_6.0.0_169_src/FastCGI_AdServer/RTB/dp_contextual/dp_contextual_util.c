/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <malloc.h>

#include <dp_error.h>
#include <dp_contextual_util.h>

int init_dp_contextual_string_data(dp_contextual_string_data_t *dp_contextual_string_data) {
	/*
	 * Check parameters passed.
	 */
	if(dp_contextual_string_data == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		return DP_ERROR_INVALID_ARGS;
	}

	dp_contextual_string_data->string_data = NULL;
	dp_contextual_string_data->total_size = 0;
	dp_contextual_string_data->curr_size = 0;

	return DP_ERROR_SUCCESS;
}

void release_dp_contextual_string_data(dp_contextual_string_data_t *dp_contextual_string_data) {
	/*
	 * Check parameters passed.
	 */
	if(dp_contextual_string_data == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		return;
	}

	if (dp_contextual_string_data->string_data != NULL) {
		free(dp_contextual_string_data->string_data);
	}

	init_dp_contextual_string_data(dp_contextual_string_data);

}

char *get_dp_contextual_string_data(dp_contextual_string_data_t *dp_contextual_string_data) {
	/*
	 * Local variables.
	 */
	char *string_data = NULL;

	/*
	 * Check parameters passed.
	 */
	if(dp_contextual_string_data == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		goto done;
	}

	string_data = dp_contextual_string_data->string_data;

done:

	return string_data;
}

int get_dp_contextual_string_curr_size(dp_contextual_string_data_t *dp_contextual_string_data) {
	/*
	 * Local variables.
	 */
	int retval;

	/*
	 * Check parameters passed.
	 */
	if(dp_contextual_string_data == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = -DP_ERROR_INTERNAL;
		goto done;
	}

	retval = (int ) dp_contextual_string_data->curr_size;

done:
	return retval;
}

int get_dp_contextual_string_total_size(dp_contextual_string_data_t *dp_contextual_string_data) {
	/*
	 * Local variables.
	 */
	int retval;

	/*
	 * Check parameters passed.
	 */
	if(dp_contextual_string_data == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = -DP_ERROR_INTERNAL;
		goto done;
	}

	retval = (int ) dp_contextual_string_data->total_size;

done:
	return retval;
}


int write_dp_contextual_string_data(dp_contextual_string_data_t *dp_contextual_string_data, const char *json_string) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	size_t json_string_len = 0;
	size_t realloc_size = 0;
	size_t space_left;
	
	/*
	 * Check parameters passed.
	 */
	if((dp_contextual_string_data == NULL) || (json_string == NULL)){
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	json_string_len  = strlen(json_string);
	/*
	 * Check if need for realloc.
	 */
	if ((dp_contextual_string_data->string_data == NULL) || ((json_string_len + dp_contextual_string_data->curr_size + 1) > dp_contextual_string_data->total_size)) {
		realloc_size = dp_contextual_string_data->curr_size + json_string_len + DP_CONTEXTUAL_JSON_REALLOC_SIZE + 1;
		dp_contextual_string_data->string_data = (char *) realloc (dp_contextual_string_data->string_data, realloc_size);
		if (dp_contextual_string_data->string_data == NULL) {
			llog_write(L_DEBUG, "Error while realloc of size : '%d',  '%s:%s:%d'\n",
									(int )realloc_size, __FILE__, __FUNCTION__, __LINE__);
			retval = DP_ERROR_NOMEMORY;
			goto done;
		}
		dp_contextual_string_data->total_size = realloc_size;
	}

	space_left = dp_contextual_string_data->total_size - dp_contextual_string_data->curr_size;
	snprintf(dp_contextual_string_data->string_data + dp_contextual_string_data->curr_size, space_left, "%s", json_string);
	
	/*
	 * Update current size.
	 */
	dp_contextual_string_data->curr_size = dp_contextual_string_data->curr_size + json_string_len;
	dp_contextual_string_data->string_data[dp_contextual_string_data->curr_size] = '\0';

done:
	return retval;
}

int copy_dp_contextual_string_data(
		dp_contextual_string_data_t *dest,
		const dp_contextual_string_data_t *src) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	/*
	 * Check parameters passed.
	 */
	if((dest == NULL) || (src == NULL) || (src->string_data == NULL)){
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	retval = write_dp_contextual_string_data(dest, src->string_data);
	if(retval != DP_ERROR_SUCCESS) {
			llog_write(L_DEBUG, "Error: write_dp_contextual_string_data failed: '%s:%s:%d'\n",
								__FILE__, __FUNCTION__, __LINE__);
		goto done;
	}

done:
	return retval;
}
