/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>

#include "proximic.h"

//#include "dp_generic.h" // This is not required ... Removing plz notify if otherwise

#include "dp_contextual_util.h"
#include "dp_properties.h"
#include "dp_error.h"
#include "json.h"
#include "json_object_private.h"
#include "dp_db.h"

/*
 * extern variables.
 */
extern int g_datacenter_id;

// Global ops structure for PROXIMIC
dp_ops_t g_proximic_ops = {
	.get_id = proximic_get_id,
	.get_name = proximic_get_name,
	.get_isenabled = proximic_get_isenabled,
	.initialize = proximic_initialize,
	.release_config = proximic_release_config,
	.create_request = proximic_create_request,
	.parse_response = proximic_parse_response
};

int init_proximic_parse_info(
	proximic_parse_info_t *proximic_parse_info) {
	/*
 	 * Check function parameters.
	 */
	if(proximic_parse_info == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		return DP_ERROR_INVALID_ARGS;
	}

	proximic_parse_info->scope[0] = '\0';
	proximic_parse_info->type[0] = '\0';

	return DP_ERROR_SUCCESS;
}

/*
 * Function:-	init_proximic_config.
 * Desc:-	Function initilizes proximic configuration structure.
 * Parameters:-
 * 		1) proximic_config.
 *			structure variable of type proximic_config_t.
 */
int init_proximic_config(
	proximic_config_t *proximic_config) {
	/*
	 * Check function parameters.
	 */
	if(proximic_config == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		return DP_ERROR_INVALID_ARGS;
	}

	proximic_config->isactive = 0;
	proximic_config->timeout = 0;
	proximic_config->conn_timeout = 0;
	proximic_config->calltype = 0;
	proximic_config->dp_base_url[0] = '\0';
	proximic_config->dp_authentication_method = 0;
	proximic_config->dp_authentication_key[0] = '\0';
	proximic_config->responsetype[0] = '\0';

	return DP_ERROR_SUCCESS;
}

/*
 * Function returns DP ID for Proximic.
 */
int proximic_get_id(void) {
	return PROXIMIC_ID;
}

/*
 * Function returns name for Proximic.
 */
const char* proximic_get_name(void) {
	return PROXIMIC_NAME;
}

/*
 * Function checks communication with proximic cache servers is enabled or disabled.
 */
int proximic_get_isenabled(
	void *config) {
	/*
	 * Check function parameters.
	 */
	if (config == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		return (-DP_ERROR_INVALID_ARGS);
	}

	proximic_config_t *px_config = (proximic_config_t *) config;
	return px_config->isactive;
}

/*
 * Function: proximic_initialize
 * desc:
 *		Function reads configuration information from DB for proximic.
 */
int proximic_initialize(
	db_connection_t *dbconn,
	void **config, int *ret_size) {
	/*
	 * Local Variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	proximic_config_t *px_config = NULL;
	dp_contextual_config_t dp_contextual_config;

#ifdef DEBUG
	llog_write(L_DEBUG, "Inside : '%s'\n", __FUNCTION__);
#endif

	/*
	 * Check function parameters.
	 */
	if ((dbconn == NULL) || (config == NULL)) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	/*
	 * Init generic dp_contextual_config.
	 */
	init_dp_contextual_config(&dp_contextual_config);

	/*
	 * *((proximic_config_t **)config) should always be NULL.
	 */
	if (*((proximic_config_t **)config) != NULL) {
		llog_write(L_DEBUG, "config != NULL : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}
	/*
	 * Allocate memory for proximic config structure.
	 * Also initialise the structure variable.
	 */
	px_config = (proximic_config_t *) malloc(sizeof(proximic_config_t));
	if (px_config == NULL) {
		llog_write(L_DEBUG, "Error while allocating memory for px_config : '%s:%s:%d'\n",
							__FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_NOMEMORY;
		goto done;
	}
	init_proximic_config(px_config);

	/*
	 * Now read generic config and copy to proxic config.
	 */
	retval = dp_contextual_read_conf(dbconn, &dp_contextual_config, PROXIMIC_ID, g_datacenter_id);
	if (retval != DP_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "Error reading generic conf for proximic : '%s:%s:%d'\n",
							__FILE__, __FUNCTION__, __LINE__);
		
		if(px_config) {
		  free(px_config);
		  px_config=NULL;
		}
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Copy data read from DB to proximic structure.
	 */
	px_config->isactive = dp_contextual_config.isactive;
	px_config->timeout = dp_contextual_config.timeout;
	px_config->conn_timeout = dp_contextual_config.conn_timeout;
	px_config->dp_base_url[MAX_URL_SIZE] = '\0';
	strncpy(px_config->dp_base_url, dp_contextual_config.dp_base_url, MAX_URL_SIZE);
	px_config->dp_authentication_key[PROXIMIC_AUTHENTCATE_KEY_SIZE] = '\0';
	strncpy(px_config->dp_authentication_key, dp_contextual_config.dp_authentication_key, PROXIMIC_AUTHENTCATE_KEY_SIZE);
	px_config->responsetype[PROXIMIC_RES_TYPE_BUFF_SIZE] = '\0';
	strncpy(px_config->responsetype, dp_contextual_config.responsetype, PROXIMIC_RES_TYPE_BUFF_SIZE);

	*((proximic_config_t **)config) = px_config;

	/*
	 * Copy structure size in ret_size.
	 */
	if (ret_size != NULL) {
		*ret_size = sizeof(*px_config);
	}

done:
	return retval;
}

/*
 * Function:-	proximic_release_config
 * Parameters:-
 * 		1) config
 * 			void * pointer which stores pointer to proximic config structure.
 * Desc:-	Free any memory allocated while reading proximic configuration.
 */
int proximic_release_config(
	void *config) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;

	/*
	 * Check function parameters.
	 */
	if (config == NULL) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	/*
	 * Free memory for structure object.
	 */
	free(config);
	config = NULL;

done:
	return retval;
}	

/*
 * Function:-	Proximic_create_request
 * Desc:-	Function sets parametrs for CURL call to proximic cache servers.
 *			Parameters like URL, timeouts, callback function are set here.
 * Parameters:-
 * 		1) config:- DP specific configuration.
 * 		2) url :- url for which data needs to be collected.
 * 		3) easy_handle:- CURL handle for DP.
 * 		4) response_params :- response parameters needed to pass to CURL callback function.
 */
int proximic_create_request(
	void *config,
	const ad_server_req_param_t *in_req_params,
	CURL *easy_handle,
	void *dp_response_params) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	proximic_config_t *px_config;
	char request_url[MAX_URL_SIZE + DP_AUTHENTCATE_KEY_SIZE + DP_AUTHENTCATE_KEY_SIZE + 1];
	CURLcode curl_retval=CURLE_OK;

	/*
	 * Check input parameters to function.
	 */
	if ((config == NULL) || (request_url == NULL) || (easy_handle == NULL) || (dp_response_params == NULL)) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}
	px_config = (proximic_config_t *) config;

	/*
	 * If ad is from Iframe, dont create the request.
	 */
	if (in_req_params->inIframe != 0) {
#ifdef MULTI_CURL_CALL
		llog_write(L_DEBUG, "\nIframe based ads not supported by proximic  : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
#endif
		retval = DP_ERROR_NOT_SUPPORTED;
		goto done;
	}

	/*
	 * Now construct the URL.
	 */
	request_url[MAX_URL_SIZE + DP_AUTHENTCATE_KEY_SIZE + DP_AUTHENTCATE_KEY_SIZE] = '\0';
	snprintf(request_url, MAX_URL_SIZE + DP_AUTHENTCATE_KEY_SIZE + DP_AUTHENTCATE_KEY_SIZE, "%s?dkey=%s&url=%s",
								px_config->dp_base_url, px_config->dp_authentication_key, in_req_params->page_url);
							//	px_config->dp_base_url, px_config->dp_authentication_key, "http://www.espnstar.com/football");


	
	/*
	 * Now set CURL call parameters.
	 * Set the URL for CURL request.
	 */
	curl_retval = curl_easy_setopt(easy_handle, CURLOPT_URL, request_url);
	if(curl_retval != CURLE_OK ) {
		llog_write(L_DEBUG,"\nERROR: curl_easy_setopt CURLOPT_URL failed : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	curl_retval = curl_easy_setopt(easy_handle, CURLOPT_NOSIGNAL, 1L);
	if(curl_retval != CURLE_OK ) {
		llog_write(L_DEBUG,"\nERROR: curl_easy_setopt CURLOPT_CONNECTTIMEOUT_MS failed : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	curl_retval = curl_easy_setopt(easy_handle, CURLOPT_HTTPGET, 1L);
	if(curl_retval != CURLE_OK ) {
		llog_write(L_DEBUG,"\nERROR: curl_easy_setopt CURLOPT_HTTPGET failed : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Set connection timeout.
	 */
	
	curl_retval = curl_easy_setopt(easy_handle, CURLOPT_CONNECTTIMEOUT_MS, px_config->conn_timeout);
	if(curl_retval != CURLE_OK ) {
		llog_write(L_DEBUG,"\nERROR: curl_easy_setopt CURLOPT_CONNECTTIMEOUT_MS failed : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}
	

	/*
	 * Set response timeout.
	 */
	
	curl_retval = curl_easy_setopt(easy_handle, CURLOPT_TIMEOUT_MS, px_config->timeout);
	if(curl_retval != CURLE_OK ) {
		llog_write(L_DEBUG,"\nERROR: curl_easy_setopt CURLOPT_TIMEOUT_MS failed : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}
	
	/*
	 * Set callback function for copying response.
	 */
	curl_retval = curl_easy_setopt(easy_handle, CURLOPT_WRITEDATA, (void *)dp_response_params);
	if(curl_retval != CURLE_OK ) {
		llog_write(L_DEBUG,"\nERROR: curl_easy_setopt CURLOPT_WRITEDATA failed : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Set data which will be needed in callback function.
	 */
	curl_retval = curl_easy_setopt(easy_handle, CURLOPT_WRITEFUNCTION, dp_response_callback);
	if(curl_retval != CURLE_OK ) {
		llog_write(L_DEBUG,"\nERROR: curl_easy_setopt CURLOPT_WRITEFUNCTION failed : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

done:
	return retval;
}

/*
 * Fuction :-	get_json_child_from_parent
 * Desc:-
 *			Function returns a child object from a parent json object. If child object is not found then NULL is returned.
 *			Function also checks type of the child object. Even if child object is found but type does not match, NULL
 *			will be returned.
 * Parameters:-
 *			1) parent_json_object:- parent json object.
 *			2) key:- key for child object.
 *			3) child_json_type :- type for child object.
 */
json_object *get_json_child_from_parent(
	json_object *parent_json_object,
	const char *key,
	json_type child_json_type) {
	/*
	 * Local variables.
	 */
	json_object *child_json_object = NULL;

	/*
	 * Check function parameters.
	 */
	if ((parent_json_object == NULL) || (key == NULL) || (json_type_object != parent_json_object->o_type) ){
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);
		goto done;
	}

	child_json_object = json_object_object_get(parent_json_object, key);
	if (child_json_object == NULL) {
#ifdef DEBUG
           llog_write(L_DEBUG, "Key : '%s' not present in json object\n", key);
#endif
		goto done;
	}

	/*
	 * Now check object type.
	 */
	if (json_object_is_type(child_json_object, child_json_type) == 0) {
#ifdef DEBUG
		llog_write(L_DEBUG, "Invalid JSON object type : '%s:%s:%d'\n",
						__FILE__, __FUNCTION__, __LINE__);
#endif
		child_json_object = NULL;
		goto done;
	}

done:
	return child_json_object;
}

/*
 * Function:- proximic_category_parse
 * Desc:- Function parses category JSON object from proximic response.
 *		  Category object is array of JSON objects. Sample:-
 *		  {"weight":100, "id":20614}
 *		  parser will parse "weight" and "id" from each such type of object.
 * Parameters:-
 *		1) px_category_json_object:- JSON category object.
 *		2) dp_cont_bp_data:- Structure which stores contextual data.
 *		3) proximic_parse_info :- structure which stores parsed info for each response.
 */
int proximic_category_parse(
	json_object *px_category_json_object,
	dp_cont_bp_data_t *dp_cont_bp_data,
	proximic_parse_info_t *proximic_parse_info) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	int json_array_len = 0;
	json_object *proximic_segment_json_object = NULL;
	json_object *proximic_weight_json_object = NULL;
	json_object *proximic_segment_value_json_object = NULL;
	int i;

	/*
	 * Check function parameters.
	 */
	if ((px_category_json_object == NULL) || (dp_cont_bp_data == NULL) || (proximic_parse_info == NULL)) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}
	
	/*
	 * Check object type before proceeding.
	 * JSON "category" object should be of type 'json_type_array'.
	 */	
	if (json_object_is_type(px_category_json_object, json_type_array) == 0) {
		llog_write(L_DEBUG, "Invalid JSON object type for proximic category response : '%s:%s:%d'\n",
						__FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Set page scope and type.
	 */
	dp_cont_bp_data->page_scope[PAGE_SCOPE_MAX_LEN] = '\0';
	snprintf(dp_cont_bp_data->page_scope, PAGE_SCOPE_MAX_LEN + 1, "%s", proximic_parse_info->scope);

	dp_cont_bp_data->page_type[PAGE_TYPE_MAX_LEN] = '\0';
	snprintf(dp_cont_bp_data->page_type, PAGE_TYPE_MAX_LEN + 1, "%s", proximic_parse_info->type);


	/*
	 * Get array length.
	 */
	json_array_len = json_object_array_length(px_category_json_object);
	if (json_array_len <= 0) {
		goto done;
	}

	for(i = 0 ; i < json_array_len ; i++) {
		proximic_segment_json_object = json_object_array_get_idx(px_category_json_object, i);
		/*
		 * Check NULL value as well as JSON object type.
		 * Object type should be json_type_object.
		 */
		if((proximic_segment_json_object != NULL) && (json_object_is_type(proximic_segment_json_object, json_type_object))) {
			/*
			 * Get weight.
			 */
			proximic_weight_json_object = get_json_child_from_parent(proximic_segment_json_object, PROXIMIC_WEIGHT, json_type_int);
			if (proximic_weight_json_object == NULL) {
				continue;
			}

			/*
			 * Get segment.
			 */
			proximic_segment_value_json_object = get_json_child_from_parent(proximic_segment_json_object, PROXIMIC_SEGMENT, json_type_string);
			if (proximic_segment_value_json_object == NULL) {
				continue;
			}

			retval = dp_cont_id_wt_add(dp_cont_bp_data, proximic_weight_json_object->o.c_int, atoi(proximic_segment_value_json_object->o.c_string));
			if(retval != DP_ERROR_SUCCESS) {
				goto done;
			}

#if 0
			temp_string[PROXIMIC_TEMP_STR_SIZE] = '\0';
			snprintf(temp_string, PROXIMIC_TEMP_STR_SIZE, "{ \"id\":\"%s\",\"wt\":\"%d\"}",
									proximic_segment_value_json_object->o.c_string, proximic_weight_json_object->o.c_int);
			retval = write_dp_contextual_string_data(dp_contextual_string_data, temp_string);
			if(retval != DP_ERROR_SUCCESS) {
				goto done;
			}
			

			llog_write(L_DEBUG, "--------------------------------------------------------------------------------\n");
			llog_write(L_DEBUG, "%s : '%d', %s : '%s'\n",
									PROXIMIC_WEIGHT, proximic_weight_json_object->o.c_int,
									PROXIMIC_SEGMENT, proximic_segment_value_json_object->o.c_string);
			llog_write(L_DEBUG, "--------------------------------------------------------------------------------\n");
#endif
		}
	}

done:
	return retval;
}

/*
 * Function :- proximic_check_response_scope
 * Desc:- Function checks scope fron the proximic response. It should be one of "page" or "environment".
 * Parameters:-
 *		1) px_contextual_json_object:- contextual JSON object.
 *		2) proximic_parse_info :- structure which stores parsed info for each response.
 */
int proximic_check_response_scope(
	json_object *px_contextual_json_object,
	proximic_parse_info_t *proximic_parse_info) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	json_object *px_contextual_scope_object = NULL;

	/*
	 * Check function parameters.
	 */
	if ((px_contextual_json_object == NULL) || (proximic_parse_info == NULL)) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	/*
	 * Get scope from contextual object.
	 */
	px_contextual_scope_object = get_json_child_from_parent(px_contextual_json_object, PROXIMIC_SCOPE, json_type_string);
	if (px_contextual_scope_object == NULL) {
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Now check scope is one of "page" or "environment"
	 */
	if((px_contextual_scope_object->o.c_string == NULL)) {
		llog_write(L_DEBUG, "Scope is NULL : '%p'\n", px_contextual_scope_object->o.c_string);
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	if ((strcmp(px_contextual_scope_object->o.c_string, PROXIMIC_SCOPE_PAGE) != 0) && 
								(strcmp(px_contextual_scope_object->o.c_string, PROXIMIC_SCOPE_ENVIRONMENT) != 0)) {
		llog_write(L_DEBUG, "Invalid scope for URL : '%s'\n", px_contextual_scope_object->o.c_string);
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	snprintf(proximic_parse_info->scope, PROXIMIC_TEMP_STR_SIZE, "%s", px_contextual_scope_object->o.c_string);

done:
	return retval;
}

/*
 * Function :- proximic_check_response_type
 * Desc:- Function checks type fron the proximic response. It should be one of "page" or "environment".
 * Parameters:-
 *		1) px_contextual_json_object:- contextual JSON object.
 *		2) proximic_parse_info :- structure which stores parsed info for each response.
 */
int proximic_check_response_type(
	json_object *px_contextual_json_object,
	proximic_parse_info_t *proximic_parse_info) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	json_object *px_contextual_type_object = NULL;

	/*
	 * Check function parameters.
	 */
	if ((px_contextual_json_object == NULL) || (proximic_parse_info == NULL)){
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	/*
	 * Get scope from contextual object.
	 */
	px_contextual_type_object = get_json_child_from_parent(px_contextual_json_object, PROXIMIC_TYPE, json_type_string);
	if (px_contextual_type_object == NULL) {
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Now check type is "iab".
	 */
	if((px_contextual_type_object->o.c_string == NULL)) {
		llog_write(L_DEBUG, "Type is NULL : '%p'\n", px_contextual_type_object->o.c_string);
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	if (strcmp(px_contextual_type_object->o.c_string, PROXIMIC_TYPE_IAB) != 0) {
		llog_write(L_DEBUG, "Invalid type for URL : '%s'\n", px_contextual_type_object->o.c_string);
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	snprintf(proximic_parse_info->type, PROXIMIC_TEMP_STR_SIZE, "%s", px_contextual_type_object->o.c_string);

done:
	return retval;
}

/*
 * Function :- proximic_check_response_prerequisites
 * Desc:- Function checks the prerequisites in the response needed for parsing response.
 * Parameters:-
 * 		1) px_config :- proximic config.
 * 		2) px_config:- Proximic JSON object.
 * 		3) proximic_parse_info :- structure which stores parsed info for each response.
 */

int proximic_check_response_prerequisites(
		proximic_config_t *px_config,
		json_object *px_json_object,
		proximic_parse_info_t *proximic_parse_info) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	json_object *px_contextual_json_object = NULL;

	/*
	 * Check if response is in JSON format.
	 */
	if (strcmp(px_config->responsetype, PROXIMIC_RES_FORMAT) != 0) {
		llog_write(L_DEBUG, "Invalid response format : '%s', '%s:%s:%d'\n",
							px_config->responsetype, __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	/*
	 * Check scope of the response. It should be one of "page" or "environment"
	 */
	retval = proximic_check_response_scope(px_json_object, proximic_parse_info);
	if (retval != DP_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "Error while parsing category for proximic response : '%s:%s:%d'\n",
						__FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Get contextual object from proximic json response.
	 */
	px_contextual_json_object = get_json_child_from_parent(px_json_object, PROXIMIC_CONTEXTUAL, json_type_object);
	if (px_contextual_json_object == NULL) {
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Check type of the response. It should be one of "iab".
	 */
	retval = proximic_check_response_type(px_contextual_json_object, proximic_parse_info);
	if (retval != DP_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "Error while parsing category for proximic response : '%s:%s:%d'\n",
						__FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}
done:
	return retval;
}


/*
 * Function:- proximic_parse_contextual_response
 * Desc:- top level function which parses proximic contextual response.
 * Parameters:-
 *		1) px_config:- config info for proximic.
 *		2) px_json_object :- JSON object for response.
 *		3) dp_cont_bp_data :- object storing contextual data.
 *		4) proximic_parse_info :- object storing parsed info.
 */
int proximic_parse_contextual_response(
	json_object *px_json_object,
	dp_cont_bp_data_t *dp_cont_bp_data,
	proximic_parse_info_t *proximic_parse_info) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	json_object *px_contextual_json_object = NULL;
	json_object *px_category_json_object = NULL;

	/*
	 * Check function parameters.
	 */
	if ((px_json_object == NULL) || (dp_cont_bp_data == NULL) || (proximic_parse_info == NULL)) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	/*
	 * Get contextual object from proximic json response.
	 */
	px_contextual_json_object = get_json_child_from_parent(px_json_object, PROXIMIC_CONTEXTUAL, json_type_object);
	if (px_contextual_json_object == NULL) {
		retval = DP_ERROR_INTERNAL;
		goto done;
	}
	
	/*
	 * Get category object from proximic contextual json response.
	 */
	px_category_json_object = get_json_child_from_parent(px_contextual_json_object, PROXIMIC_CATEGORY, json_type_array);
	if (px_category_json_object == NULL) {
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Now parse category object for getting swgments.
	 */
	retval = proximic_category_parse(px_category_json_object, dp_cont_bp_data, proximic_parse_info);
	if(retval != DP_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "Error while parsing category for proximic response : '%s:%s:%d'\n",
						__FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

done:
	return retval;
}

/*
 * Function:- proximic_parse_bp_rating.
 * Desc:- parses rating from brandprotection json object.
 * Parameters:-
 *		1) px_bp_json_object:- config info for proximic.
 *		2) bp_rating :- object for storing string rating data.
 */
int proximic_parse_bp_rating(
		json_object *px_bp_json_object,
		dp_bp_safety_node_t *rating) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	json_object *px_rating_json_object = NULL;
	struct json_object_iter iter;

	/*
	 * Now get rating object from brandprotection object.
	 */
	px_rating_json_object = get_json_child_from_parent(px_bp_json_object, PROXIMIC_RATING, json_type_object);
	if (px_rating_json_object == NULL) {
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	json_object_object_foreachC(px_rating_json_object, iter) {
		if (iter.val->o_type == json_type_int) {
			rating->set_flag = 1;
			rating->dp_id_wt_data.id = atoi(iter.key);
			rating->dp_id_wt_data.wt = iter.val->o.c_int;
			break;
		}
	}

done:
	return retval;
}

/*
 * Function:- proximic_parse_bp_safetylevel.
 * Desc:- parses safetylevel from brandprotection json object.
 * Parameters:-
 *		1) px_bp_json_object:- config info for proximic.
 *		2) bp_safetylevel :- object for storing string safetylevel data.
 */
int proximic_parse_bp_safetylevel(
		json_object *px_bp_json_object,
		dp_bp_safety_node_t *safetylevel) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	json_object *px_safetylevel_json_object = NULL;
	struct json_object_iter iter;

	/*
	 * Now get rating object from brandprotection object.
	 */
	px_safetylevel_json_object = get_json_child_from_parent(px_bp_json_object, PROXIMIC_SAFETYLEVEL, json_type_object);
	if (px_safetylevel_json_object == NULL) {
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	json_object_object_foreachC(px_safetylevel_json_object, iter) {
        if (iter.val->o_type == json_type_int) {
            safetylevel->set_flag = 1;
            safetylevel->dp_id_wt_data.id = atoi(iter.key);
            safetylevel->dp_id_wt_data.wt = iter.val->o.c_int;
            break;
        }
    }

done:
	return retval;
}

/*
 * Function:- proximic_parse_bp_nonstandardcontent.
 * Desc:- parses nonstandardcontent from brandprotection json object.
 * Parameters:-
 *		1) px_bp_json_object:- config info for proximic.
 *		2) bp_nonstandardcontent :- object for storing string nonstandardcontent data.
 */
int proximic_parse_bp_nonstandardcontent(
		json_object *px_bp_json_object,
		dp_bp_safety_node_t *nonstandardcontent) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	json_object *px_nonstandardcontent_json_object = NULL;
	struct json_object_iter iter;

	/*
	 * Now get nonstandardcontent object from brandprotection object.
	 */
	px_nonstandardcontent_json_object = get_json_child_from_parent(px_bp_json_object, PROXIMIC_NONSTANDARDCONTENT, json_type_object);
	if (px_nonstandardcontent_json_object == NULL) {
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	json_object_object_foreachC(px_nonstandardcontent_json_object, iter) {
        if (iter.val->o_type == json_type_int) {
            nonstandardcontent->set_flag = 1;
            nonstandardcontent->dp_id_wt_data.id = atoi(iter.key);
            nonstandardcontent->dp_id_wt_data.wt = iter.val->o.c_int;
            break;
        }
    }
	
done:
	return retval;
}


/*
 * Function:- proximic_parse_bp_response
 * Desc:- top level function which parses proximic brand protection response.
 * Parameters:-
 *		1) px_config:- config info for proximic.
 *		2) px_json_object :- JSON object for response.
 *		3) dp_cont_bp_data :- object storing brand safety data.
 *		4) proximic_parse_info :- object storing parsed info.
 */
int proximic_parse_bp_response(
	json_object *px_json_object,
	dp_cont_bp_data_t *dp_cont_bp_data,
	proximic_parse_info_t *proximic_parse_info) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	json_object *px_bp_json_object = NULL;

	/*
	 * Check function parameters.
	 */
	if ((px_json_object == NULL) || (dp_cont_bp_data == NULL) || (proximic_parse_info == NULL)) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	/*
	 * Get brandprotection object from proximic json response.
	 */
	px_bp_json_object = get_json_child_from_parent(px_json_object, PROXIMIC_BP, json_type_object);
	if (px_bp_json_object == NULL) {
		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	proximic_parse_bp_rating(px_bp_json_object, &dp_cont_bp_data->dp_bp_safety_data.rating);
	proximic_parse_bp_safetylevel(px_bp_json_object, &dp_cont_bp_data->dp_bp_safety_data.safetylevel);
	proximic_parse_bp_nonstandardcontent(px_bp_json_object, &dp_cont_bp_data->dp_bp_safety_data.nonstandardcontent);

done:
	return retval;
}


/*
 * Function:- proximic_parse_response
 * Desc:- Parser function to parse proximic response.
 * Pramaters:-
 *		1) config:- proximic config.
 *		2) px_response:- proximic response.
 *		3) response_size.
 */
int proximic_parse_response(
	void *config,
	const char *px_response,
	int response_size,
	void *v_dp_cont_bp_data) {
	/*
	 * Local variables.
	 */
	int retval = DP_ERROR_SUCCESS;
	json_object *px_json_object = NULL;
	proximic_config_t *px_config = NULL;
	dp_cont_bp_data_t *dp_cont_bp_data;
	proximic_parse_info_t proximic_parse_info;
//todo manishb
response_size = response_size;

#ifdef DEBUG
	llog_write(L_DEBUG, "Inside function : '%s'\n", __FUNCTION__);
#endif

	/*
	 * Check function parameters.
	 */
	if ((config == NULL) || (px_response == NULL) || (v_dp_cont_bp_data == NULL)) {
		llog_write(L_DEBUG, "Invalid parameters : '%s:%s:%d'\n", __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INVALID_ARGS;
		goto done;
	}

	/*
	 * Init local data structure.
	 */
	dp_cont_bp_data = (dp_cont_bp_data_t *)v_dp_cont_bp_data;
	dp_cont_bp_data->dpid = proximic_get_id();
	init_proximic_parse_info(&proximic_parse_info);

	px_config = (proximic_config_t *) config;

	/*
	 * Convert the JSON response from proximic to JSON object.
	 */
	px_json_object = json_tokener_parse(px_response);
	if ((px_json_object == NULL) || (is_error(px_json_object))) {
		llog_write(L_DEBUG, "json_tokener_parse failed for proximic response : '%s', '%s:%s:%d'\n",
						px_response, __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Check object type before proceeding. JSON object should be of type 'json_type_object'.
	 * Types like json_type_int, json_type_array, json_type_string are invalid.
	 */
	if (json_object_is_type(px_json_object, json_type_object) == 0) {
		llog_write(L_DEBUG, "Invalid JSON object type for proximic response : '%s', '%s:%s:%d'\n",
						px_response, __FILE__, __FUNCTION__, __LINE__);

		retval = DP_ERROR_INTERNAL;
		goto done;
	}

	/*
	 * Checl prerequisites in the Proximic response.
	 */
	retval = proximic_check_response_prerequisites(px_config, px_json_object, &proximic_parse_info);
	if(retval != DP_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "Error while response prerequisites check: '%s', '%s:%s:%d'\n",
							px_response, __FILE__, __FUNCTION__, __LINE__);
		retval = DP_ERROR_INTERNAL;
		goto done;
	}
	
	/*
	 * Now parse contextual data.
	 */
	retval = proximic_parse_contextual_response(px_json_object, dp_cont_bp_data, &proximic_parse_info);
	if(retval != DP_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "Error while parsing proximic contextual response : '%s', '%s:%s:%d'\n",
							px_response, __FILE__, __FUNCTION__, __LINE__);
	}

	/*
	 * Now parse brandprotection data.
	 */
	retval = proximic_parse_bp_response(px_json_object, dp_cont_bp_data, &proximic_parse_info);
	if(retval != DP_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "Error while parsing proximic contextual response : '%s', '%s:%s:%d'\n",
							px_response, __FILE__, __FUNCTION__, __LINE__);
	}

#ifdef DEBUG
	dp_cont_bp_data_print(dp_cont_bp_data);
#endif

done:
	/*
	 * Free JSON object.
	 */
	if ((px_json_object != NULL) && (!is_error(px_json_object))){
		json_object_put(px_json_object);
		px_json_object = NULL;
	}

	return retval;
}
