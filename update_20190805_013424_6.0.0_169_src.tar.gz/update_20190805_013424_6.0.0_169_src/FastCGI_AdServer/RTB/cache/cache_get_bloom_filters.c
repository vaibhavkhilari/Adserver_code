/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


/* Include required header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "cache_get_bloom_filters.h"
#include "fte_util.h"
#include "error.h"
#include "db_error.h"
#include "rt_types.h"
//kartik_porting
#include "cache_libmemcached.h"
#include "db_get_bloom_filters.h"
//~kartik_porting

extern int g_fte_cache_element_timeout;


static int __cache_get_bloom_filters(
				cache_handle_t* cache,
				db_connection_t* dbconn,
				const char *cache_key,
				const char *db_query,
				BLOOM** bloom_filter,
				int* bloom_count,
				const long pub_id,
				const long site_id,
				const int bloom_type) {
	char bloom_filter_key[MAX_KEY_SIZE+1];
	BLOOM *cached_bloom_filter = NULL;
	const BLOOM dummy_entry = { .bit_array_size=0, .nelements=0};
	int retval = 0;
	int key_length=0;
	int ret_len = 0;
	int bloom_idx=0;
	int i=0;
	size_t ret_size[MAX_ALLOWED_BLOOMS]={0};
	bloom_filter[0] = NULL;
	*bloom_count=0;

	/* Create the key */
	snprintf(bloom_filter_key, MAX_KEY_SIZE, cache_key, pub_id, site_id, bloom_type, bloom_idx);
	bloom_filter_key[MAX_KEY_SIZE]=0;
	key_length = strlen(bloom_filter_key);

	cached_bloom_filter = 
		(BLOOM*) memcached_get_object_reference(cache,
				bloom_filter_key, key_length,	&ret_len);

	//At the end of this bloom we are appending: Total_Bloom at PubSiteLevel and BloomType
	//first bloom struct: BLOOM_nBloom(char)_bloomType(char)
	//if in between we miss any bloom we go for DB query
	if (cached_bloom_filter != NULL) {
		MULTIBLOOM_DEBUG("\nCACHE_MULTI_BLOOM_FOUND:: key:%s memcache_obj_size:%d, element_count:%d, bit_array_size_bits:%zd, bit_array_size_bytes:%ld, %s:%d\n",
				bloom_filter_key, ret_len,
				cached_bloom_filter->nelements,
				cached_bloom_filter->bit_array_size,
				BIT_ARRAY_SIZE_BYTES(cached_bloom_filter->bit_array_size),
				__FILE__, __LINE__);

		if(INVALID_FILTER_IN_CACHE(cached_bloom_filter)){
			memcached_release_object_reference((char**)&cached_bloom_filter);
			return ADS_ERROR_SUCCESS; // return success if dummy bloom present for the publisher/site
		}
		bloom_idx++;

		//Valid bloom present
		bloom_filter[0] = cached_bloom_filter;
		*bloom_count=(int)(*((char*)cached_bloom_filter +(size_t) TOTAL_BLOOM_OBJECT_SIZE(cached_bloom_filter[0].nelements)));
		int get_failed=0;
		while( *bloom_count > bloom_idx  && MAX_ALLOWED_BLOOMS > bloom_idx){
			snprintf(bloom_filter_key, MAX_KEY_SIZE, cache_key, pub_id, site_id, bloom_type, bloom_idx);
			key_length = strlen(bloom_filter_key);
			bloom_filter_key[MAX_KEY_SIZE]=0;

			cached_bloom_filter = 
				(BLOOM*) memcached_get_object_reference(cache,
						bloom_filter_key, key_length,	&ret_len);
			if (cached_bloom_filter != NULL) {
				if(INVALID_FILTER_IN_CACHE(cached_bloom_filter)) {
					*bloom_count = bloom_idx;
					memcached_release_object_reference((char**)&cached_bloom_filter);
					return ADS_ERROR_SUCCESS;
				}

				bloom_filter[bloom_idx]=cached_bloom_filter;
				bloom_idx++;
				MULTIBLOOM_DEBUG("\nCACHE_MULTI_BLOOM_FOUND:: key:%s memcache_obj_size:%d, element_count:%d, bit_array_size_bits:%zd, bit_array_size_bytes:%ld, %s:%d\n",
						bloom_filter_key, ret_len,
						cached_bloom_filter->nelements,
						cached_bloom_filter->bit_array_size,
						BIT_ARRAY_SIZE_BYTES(cached_bloom_filter->bit_array_size),
						__FILE__, __LINE__);
			}else{
				MULTIBLOOM_DEBUG("\nCACHE_MULTI_BLOOM_WARNING:: Cache Get Failed OR '%s' Expired\n", bloom_filter_key);
				get_failed=1;
				break;
			}
		}
		if(get_failed){ //cache call failed -> release ref & go for db calls
			for( i=0; i< bloom_idx; i++){
				memcached_release_object_reference((char**)&bloom_filter[i]);
			}
		}else //valid data found in cache -> return
			return ADS_ERROR_SUCCESS;
	}

	if (ret_len == -1) {
		reinit_cache(cache);
	}

	MULTIBLOOM_DEBUG("\nCACHE_MULTI_BLOOM_NOT_FOUND:: Going for DB Call : '%s'\n", bloom_filter_key);

	retval = db_get_bloom_filters(dbconn,
			db_query,
			bloom_filter,
			bloom_count,
			ret_size,
			pub_id,
			site_id);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG,"\n DB call failed for db_get_publisher_site_block_list()");	
		return retval;
	}
	if( NULL != bloom_filter && NULL != bloom_filter[0]){
		i=0;
		void * retptr=NULL;
		//append bloom count to first bloom object
		retptr=realloc(bloom_filter[0],ret_size[0]+sizeof(char));
		if(NULL == retptr){
			for(i=0; i<*bloom_count; i++){
				bloom_destroy( &bloom_filter[i] );
			}
			*bloom_count=0;
			return ADS_ERROR_NOMEMORY;
		}else
			bloom_filter[0]=retptr;

		char nblooms=(char)(*bloom_count);
		memcpy((char*)bloom_filter[0]+ret_size[0],&nblooms,sizeof(char));
		ret_size[0] += sizeof(char);

		i = 0;
		snprintf(bloom_filter_key, MAX_KEY_SIZE, cache_key, pub_id, site_id, bloom_type, i);
		retval = libmemcached_set(cache, bloom_filter_key,
				key_length, (void *) (bloom_filter[0]),
				ret_size[0], g_fte_cache_element_timeout, 0);

		for( i=1; bloom_filter[i]!= NULL && *bloom_count>i; i++ ){
			//handle setting first bloom with no. and type if bloom
			snprintf(bloom_filter_key, MAX_KEY_SIZE, cache_key, pub_id, site_id, bloom_type, i);
			key_length = strlen(bloom_filter_key);
			bloom_filter_key[MAX_KEY_SIZE]=0;

			retval = libmemcached_set(cache, bloom_filter_key,
					key_length, (void *) (bloom_filter[i]),
					ret_size[i], g_fte_cache_element_timeout, 0);
			if (0 != retval) {
				llog_write(L_DEBUG, "WARN: Failed to set key:%s, retval:%d\n", bloom_filter_key, retval);
			}
		}
	}	else {
		snprintf(bloom_filter_key, MAX_KEY_SIZE, cache_key, pub_id, site_id, bloom_type, 0);
		bloom_filter_key[MAX_KEY_SIZE]=0;
		//handle setting first bloom with no. and type if bloom
		retval = libmemcached_set(cache, bloom_filter_key,
				key_length, (void *)(&dummy_entry),
				sizeof(BLOOM),
				get_fte_cache_timeout(), 0);
	}
	if (retval != 0) {
		reinit_cache(cache);
	}
	return ADS_ERROR_SUCCESS;
}

int cache_get_bloom_filters(
				cache_handle_t* cache,
				db_connection_t* dbconn,
				const char *cache_key,
				const char *db_query,
				MULTI_BLOOM* multi_bloom,
				const long pub_id,
				const long site_id,
				const int bloom_type) {
	int retval = ADS_ERROR_SUCCESS;

	//1. GET COMMON BLOOMs for ALL SITEs
	retval = __cache_get_bloom_filters(cache,
																		dbconn,
																		cache_key,
																		db_query,
																		multi_bloom->bloom_filter_0,
																		&(multi_bloom->bloom_count_0),
																		pub_id,
																		0,
																		bloom_type);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "\nCACHE_MULTI_BLOOM_ERROR: Failed to get cache/db object %s for p:%ld s:0\n", cache_key, pub_id);
		return retval;
	}

	//2. GET SITE SPECIFIC BLOOMs, skip if bloom type passed = -1
	if (bloom_type != -1) {
		retval = __cache_get_bloom_filters(cache,
								dbconn,
								cache_key,
								db_query,
								multi_bloom->bloom_filter_s,
								&(multi_bloom->bloom_count_s),
								pub_id,
								site_id,
								bloom_type);
		if (retval != ADS_ERROR_SUCCESS) {
			llog_write(L_DEBUG, "\nCACHE_MULTI_BLOOM_ERROR: Failed to get cache/db object %s for p:%ld s:%ld\n", cache_key, pub_id, site_id);
		}
	}

	return retval;
}
