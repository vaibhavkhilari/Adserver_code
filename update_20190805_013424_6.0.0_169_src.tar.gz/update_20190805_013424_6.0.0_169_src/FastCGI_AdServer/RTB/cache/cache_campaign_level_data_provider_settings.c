/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "error.h"
#include "fte_util.h"
#include "db_error.h"
#include "cache_types.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "cache_campaign_data_provider_segment_type_settings.h"
#include "campaign_data_provider_data.h"
#include "dp_data_passing_util.h"
#include "db_campaign_data_provider_segment_type_settings.h"





/*
 * Cache call for getting Campaign Data-Provider Segment Type settings.
 * It will fill given campaign_data_provider_segment_type_settings_t object.
 */
int cache_get_cmpg_data_provider_segment_type_settings(
				long campaign_id,
				int data_provider_id,
                memcache_cmpg_dp_data_passing_settings_t **cmpg_dp_settings,
				cache_handle_t *cache,
                db_connection_t *dbconn)
{
	char cache_cmpg_dp_settings_key[MAX_KEY_SIZE + 1];
    int cache_cmpg_dp_settings_key_len = 0;
    memcache_cmpg_dp_data_passing_settings_t *cached_cmpg_settings = NULL;
	memcache_cmpg_dp_data_passing_settings_t dummy_cmpg_settings = {
               .dp_settings_count = -1L,
	};
    int ret_len = 0;
	int ret_val;


    //Sanity checks.
    if (cache == NULL ||
        dbconn == NULL ||
        cmpg_dp_settings == NULL ||
		*cmpg_dp_settings != NULL)
    {
		llog_write(L_DEBUG, "\n(%s:%d): One of the input param is NULL, return.\n", __FUNCTION__, __LINE__);
        return ADS_ERROR_INVALID_ARGS;
    }

    /* Initialize. */
    (*cmpg_dp_settings) = NULL;

    snprintf(cache_cmpg_dp_settings_key,
             MAX_KEY_SIZE,
             CACHE_CAMPAIGN_DATA_PROVIDER_SETTINGS_KEY,
             campaign_id,
			 data_provider_id);
    cache_cmpg_dp_settings_key[MAX_KEY_SIZE] = '\0';
	cache_cmpg_dp_settings_key_len = strlen(cache_cmpg_dp_settings_key);
#ifdef DEBUG
	llog_write(L_DEBUG, "%s(): key %s\n",
					__FUNCTION__,
					cache_cmpg_dp_settings_key);
#endif //DEBUG

    cached_cmpg_settings = (memcache_cmpg_dp_data_passing_settings_t *) libmemcached_get(
                                                                     cache,
                                                                     cache_cmpg_dp_settings_key,
                                                                     cache_cmpg_dp_settings_key_len,
                                                                     &ret_len);
    if (cached_cmpg_settings != NULL)
    {
		//Cache hits.
        if (cached_cmpg_settings->dp_settings_count == -1L)
		{
#ifdef DEBUG
             llog_write(L_DEBUG, "%s(): Found dummy settings in memcache\n", __FUNCTION__);
#endif //DEBUG
			 free(cached_cmpg_settings);
             cached_cmpg_settings = NULL;
			 *cmpg_dp_settings = NULL;
		}
		else
		{
		     *cmpg_dp_settings = cached_cmpg_settings;
		     //dump_cmpg_dp_seg_type_settings(*seg_type_settings);
		}

        return ADS_ERROR_SUCCESS;
	}

	//Cache miss.
    ret_val = get_campaign_data_provider_settings(
							campaign_id,
							data_provider_id,
							dbconn,
							cmpg_dp_settings);
    if (ret_val != DB_ERROR_SUCCESS)
    {
		llog_write(L_DEBUG, "(%s:%d): Not able to get DP Settings from DB, Error: %d.\n",
                        __FUNCTION__, __LINE__, ret_val);
		return ADS_ERROR_INTERNAL;
    }
	if (*cmpg_dp_settings != NULL)
	{
		//dump_cmpg_dp_seg_type_settings(*seg_type_settings);

		ret_val = libmemcached_set(
						cache,
						cache_cmpg_dp_settings_key,
						cache_cmpg_dp_settings_key_len,
						(void *) (*cmpg_dp_settings),
						(sizeof (memcache_cmpg_dp_data_passing_settings_t) +
						(sizeof (memcached_dp_data_passing_settings_t) * (*cmpg_dp_settings)->dp_settings_count)),
						get_fte_cache_timeout(),
						0);

		if (ret_val != 0)
		{
			reinit_cache(cache);
		}
	}
	else
	{
         //Set dummpy settings in Memcache we does not found any settings for given Segment type.
         ret_val = libmemcached_set(
						cache,
						cache_cmpg_dp_settings_key,
						cache_cmpg_dp_settings_key_len,
						(void *) &dummy_cmpg_settings,
						(sizeof (memcache_cmpg_dp_data_passing_settings_t)),
						get_fte_cache_timeout(),
						0);

		if (ret_val != 0)
		{
			reinit_cache(cache);
		}
	}

    return ADS_ERROR_SUCCESS;
}

