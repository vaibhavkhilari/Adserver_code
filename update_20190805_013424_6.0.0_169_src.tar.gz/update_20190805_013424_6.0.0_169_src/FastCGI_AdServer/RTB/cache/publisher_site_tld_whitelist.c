/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


/* Include required header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "cache_libmemcached.h"
#include "rt_types.h"
#include "publisher_site_tld_whitelist.h"
#include "db_publisher_site_tld_whitelist.h"
#include "publisher_site_tld_whitelist.h"
#include <ad_server_types.h>

int cache_get_publisher_site_tld_whitelist(
		long pub_id, 
		long site_id, 
		publisher_site_top_level_domain_name_t *publisher_site_top_level_domain_name[MAX_PUB_AGG_CACHE_OBJ], 
		cache_handle_t *cache, 
		db_connection_t *dbconn,
		int ret_list[MAX_PUB_AGG_CACHE_OBJ]) {

	/*Local Variables*/
	char publisher_site_tld_whitelist_key[MAX_PUB_AGG_CACHE_OBJ][MAX_KEY_SIZE];
	int key_length[MAX_PUB_AGG_CACHE_OBJ] = {0};
	int ret_len[MAX_PUB_AGG_CACHE_OBJ] = {0};
	int retval = 0;
	publisher_site_top_level_domain_name_t *cache_publisher_site_top_level_domain_name[MAX_PUB_AGG_CACHE_OBJ] = {NULL};
	publisher_site_top_level_domain_name_t dummy_entry;
	(*publisher_site_top_level_domain_name) = NULL;
        int lower_limit = 0;
	int i = 0;
	int temp_ret_len = 0;
	int dummy_entry_found = 0;


	/* Create key */
	for(i = 0; i < MAX_PUB_AGG_CACHE_OBJ; i++) {
	    snprintf(publisher_site_tld_whitelist_key[i], MAX_KEY_SIZE, PUBLISHER_SITE_TLD_WHITELIST_KEY, pub_id, site_id, i);
	    key_length[i] = strlen(publisher_site_tld_whitelist_key[i]);
	}

	
	/*
         * Check if the information about this ad's active account is present in
         * the cache based on the key
         */
	for(i = 0; i < MAX_PUB_AGG_CACHE_OBJ; i++) {
	
		cache_publisher_site_top_level_domain_name[i] = 
			(publisher_site_top_level_domain_name_t*) memcached_get_object_reference(cache,
					publisher_site_tld_whitelist_key[i],
					key_length[i],
					&ret_len[i]);

		temp_ret_len = ret_len[i] / sizeof(publisher_site_top_level_domain_name_t);
	    
#ifdef MOBILE_TEST
	    llog_write(L_DEBUG, "\nCache object %d return length %d\n", i, temp_ret_len);
#endif

	    //Exiting from loop as the current object contains less than MAX_TLD_LIMIT_PUB_SITE_PER_CACHE_OBJ 
	    if(temp_ret_len  < MAX_TLD_LIMIT_PUB_SITE_PER_CACHE_OBJ) {
		break;
	    }	    
	 
	}


	for(i = 0; i < MAX_PUB_AGG_CACHE_OBJ; i++) {
	    ret_list[i] = 0;
	    if (cache_publisher_site_top_level_domain_name[i] != NULL) {
		/*
                 * Found the information in cache, so return it now,
                 * by coping it to the o/p parameter
                 */
		if (ret_len[i] == sizeof(publisher_site_top_level_domain_name_t)
		    &&
		    cache_publisher_site_top_level_domain_name[i]->domain_name[0] == '\0'
			 ) {
			dummy_entry_found = 1;
			memcached_release_object_reference((char**)&cache_publisher_site_top_level_domain_name[i]);
			cache_publisher_site_top_level_domain_name[i] = NULL;
		}
		if (cache_publisher_site_top_level_domain_name[i] != NULL) {
	
		    ret_list[i] = ret_len[i]/sizeof(publisher_site_top_level_domain_name_t);
#ifdef PUBAGG
		    llog_write(L_DEBUG,"\nElements found in cache\tret_list=%d\n",ret_list[i]);
#endif
                }
		publisher_site_top_level_domain_name[i] = cache_publisher_site_top_level_domain_name[i];
               	
	    }
	    
	}

	if(ret_list[0] > 0 ) {
	    return ADS_ERROR_SUCCESS;
	} else if(dummy_entry_found == 1) {
	    return ADS_ERROR_NOTHING;
	}
	/*
         * If ret_len is 0, that means there was some error, try to reinit the
         * connection
         */

	if (ret_len[0] == -1) {
                reinit_cache(cache);
        }

	/*
         * Reaches here when we do not find the ad's account information in the cache, so now
         * get it from the database and add it to the cache and return
         */
#ifdef PUBAGG
	llog_write(L_DEBUG,"\nGetting data from db\n");
#endif
	
	lower_limit = 0;

	for (i = 0 ; i < MAX_PUB_AGG_CACHE_OBJ; i++) {
	    ret_list[i] = 0;
	    retval = db_get_publisher_site_tld_whitelist(dbconn,
							 pub_id,
							 site_id,
							 &publisher_site_top_level_domain_name[i],
							 &ret_list[i],
							 lower_limit,
							 MAX_TLD_LIMIT_PUB_SITE_PER_CACHE_OBJ);
	    
	    if( retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG,"\n DB call failed for db_get_publisher_site_tld_whitelist()");
		return retval;
	    }
	    
	    lower_limit = lower_limit + MAX_TLD_LIMIT_PUB_SITE_PER_CACHE_OBJ ;
	    
	    // if the current query fetches less than MAX_TLD_LIMIT_PUB_SITE_PER_CACHE_OBJ no need to make further DB calls
	    if ( ret_list[i] < MAX_TLD_LIMIT_PUB_SITE_PER_CACHE_OBJ) {
		break;
	    }
	}

		
	for (i = 0 ; i < MAX_PUB_AGG_CACHE_OBJ; i++) {
	    
	    if ( publisher_site_top_level_domain_name[i] != NULL ) {
		/*Element found in db so add it to cache*/
		retval = libmemcached_set(cache, publisher_site_tld_whitelist_key[i],
					  key_length[i], (void *) (publisher_site_top_level_domain_name[i]),
					  sizeof(publisher_site_top_level_domain_name_t)*(ret_list[i]),
					  get_cache_timeout(), 0);
	 
		/*
		 * If we could not add the value, probably the server went down in between,
		 * so reinit the server
		 */
		if (retval != 0) {
		    reinit_cache(cache);
		}
	    } else {

		// not creating dummy entries for remaining objects as there is no data for it and first object can be used to check for data
		if(i > 0) {
		    break;
		}
		dummy_entry.domain_name[0] = '\0';
		retval = libmemcached_set(cache, publisher_site_tld_whitelist_key[i],
					  key_length[i], (void *)(&dummy_entry),
					  sizeof(publisher_site_top_level_domain_name_t),
					  get_cache_timeout(), 0);
	    

		/*
		 * If we could not add the value, probably the server went down in between,
		 * so reinit the server
		 */
		if (retval != 0) {
		    reinit_cache(cache);
		}

	    }	    
	    
	}
	
        return ADS_ERROR_SUCCESS;
}

