/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


/* Include required header files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "publisher_site_block_list.h"
#include "fte_util.h"
#include "error.h"
#include "db_error.h"
#include "rt_types.h"
//kartik_porting
#include "cache_libmemcached.h"
#include "db_publisher_site_block_list.h"
//~kartik_porting

extern int g_fte_cache_element_timeout;
#if 0
int cache_get_publisher_site_block_list(
				long pub_id,
				long site_id,
				BLOOM** publisher_site_landing_page_domain_name,
				cache_handle_t* cache,
				db_connection_t* dbconn,
				size_t* ret_size) {

	/* Local variables */
	char publisher_site_block_list_key[MAX_KEY_SIZE];
	BLOOM *cached_publisher_site_landing_page_domain_name = NULL;
	const BLOOM dummy_entry = { .bit_array_size=0, .nelements=0};
	int retval = 0;
	int key_length=0;
	int ret_len = 0;
	(*publisher_site_landing_page_domain_name) = NULL;
	(*ret_size) = 0;
	/* Create the key */
	snprintf(publisher_site_block_list_key, MAX_KEY_SIZE, PUBLISHER_SITE_BLK_LST, pub_id, site_id);
	key_length = strlen(publisher_site_block_list_key);

	/*
	 * Check if the information about this ad's active account is present in
	 * the cache based on the key
	 */
	cached_publisher_site_landing_page_domain_name = 
		(BLOOM*) memcached_get_object_reference(cache,  
				publisher_site_block_list_key, 
				key_length, 
				&ret_len);

	if (cached_publisher_site_landing_page_domain_name != NULL) {
		BLOCKLIST_DEBUG("\nLPF_Bloom:pub:%ld site:%ld:: memcache_obj_size:%d, blocked_domain_count:%d, bit_array_size_bits:%d, bit_array_size_bytes:%ld, %s:%d\n",
				pub_id, site_id, ret_len,
				cached_publisher_site_landing_page_domain_name->nelements,
				cached_publisher_site_landing_page_domain_name->bit_array_size,
				BIT_ARRAY_SIZE_BYTES(cached_publisher_site_landing_page_domain_name->bit_array_size),
				__FILE__, __LINE__);
		
		if(INVALID_FILTER_IN_CACHE(cached_publisher_site_landing_page_domain_name)) {
			memcached_release_object_reference(&cached_publisher_site_landing_page_domain_name);
			return ADS_ERROR_SUCCESS; // return success if no/invalid blocklist for the publisher/site
		}
		//reaches here only if valid blocklist found in cache
		(*publisher_site_landing_page_domain_name) = cached_publisher_site_landing_page_domain_name;
		return ADS_ERROR_SUCCESS;
	}

	/*
	 * If ret_len is 0, that means there was some error, try to reinit the
	 * connection
	 */
	if (ret_len == -1) {
		reinit_cache(cache);
	}

	/*
	 * Reaches here when we do not find the ad's account information in the cache, so now
	 * get it from the database and add it to the cache and return
	 */
	retval = db_get_publisher_site_block_list(dbconn, 
			pub_id,
			site_id,
			publisher_site_landing_page_domain_name,
			ret_size);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG,"\n DB call failed for db_get_publisher_site_block_list()");	
		return retval;
	}

	if( (*publisher_site_landing_page_domain_name) != NULL) {

		/* Element found in the database add it to the cache */
		if(pub_id != 0) {
			retval = libmemcached_set(cache, publisher_site_block_list_key, 
					key_length, (void *) (*publisher_site_landing_page_domain_name),
					(*ret_size), 
					get_fte_cache_timeout(), 0);
		} else if (pub_id == 0) { //setting up the same expiry time for all elements of array of bloom
			retval = libmemcached_set(cache, publisher_site_block_list_key,
          key_length, (void *) (*publisher_site_landing_page_domain_name),
          (*ret_size),
          g_fte_cache_element_timeout, 0);
		}
	INPC_REFERENCE_DEBUG("\nINPC_REFERENCE:: %p key:%s, fetched from DB\n", *publisher_site_landing_page_domain_name, publisher_site_block_list_key);
	} else {
		if(pub_id != 0 ) {
			retval = libmemcached_set(cache, publisher_site_block_list_key, 
					key_length, (void *)(&dummy_entry),
					sizeof(BLOOM), 
					get_fte_cache_timeout(), 0);
		} else if (pub_id == 0) {
			retval = libmemcached_set(cache, publisher_site_block_list_key,
          key_length, (void *)(&dummy_entry),
          sizeof(BLOOM), 
          g_fte_cache_element_timeout, 0);
		}
	}
	/*
	 * If we could not add the value, probably the server went down in between,
	 * so reinit the server
	 */
	if (retval != 0) {
		reinit_cache(cache);
	}
	return ADS_ERROR_SUCCESS;
}
#endif
int cache_get_publisher_site_url_bloom(
				long pub_id,
				long site_id,
				BLOOM** publisher_site_url_bloom,
				int* bloom_count,
				int bloom_type,
				cache_handle_t* cache,
				db_connection_t* dbconn) {
	char publisher_site_url_bloom_key[MAX_KEY_SIZE+1];
	BLOOM *cached_publisher_site_url_bloom = NULL;
	const BLOOM dummy_entry = { .bit_array_size=0, .nelements=0};
	int retval = 0;
	int key_length=0;
	int ret_len = 0;
	int bloom_idx=0;
	int i=0;
	size_t ret_size[MAX_ALLOWED_BLOOMS]={0};
	publisher_site_url_bloom[0] = NULL;
	*bloom_count=0;
	/* Create the key */
	snprintf(publisher_site_url_bloom_key, MAX_KEY_SIZE, PUBLISHER_SITE_URL_BLOOM, pub_id, site_id, bloom_type, bloom_idx);
	publisher_site_url_bloom_key[MAX_KEY_SIZE]=0;
	key_length = strlen(publisher_site_url_bloom_key);

	cached_publisher_site_url_bloom = 
		(BLOOM*) memcached_get_object_reference(cache,
				publisher_site_url_bloom_key,key_length,	&ret_len);

	//At the end of this bloom we are appending: Total_Bloom at PubSiteLevel and BloomType
	//first bloom struct: BLOOM_nBloom(char)_bloomType(char)
	//if in between we miss any bloom we go for DB query
	if (cached_publisher_site_url_bloom != NULL) {
		/*llog_write(L_DEBUG,"URLBloom_1:pub:%ld site:%ld:: memcache_obj_size:%d, blocked_domain_count:%d, bit_array_size_bits:%d, bit_array_size_bytes:%ld, %s:%d\n",
				pub_id, site_id, ret_len,
				cached_publisher_site_url_bloom->nelements,
				cached_publisher_site_url_bloom->bit_array_size,
				BIT_ARRAY_SIZE_BYTES(cached_publisher_site_url_bloom->bit_array_size),
				__FILE__, __LINE__);*/
		
		if(INVALID_FILTER_IN_CACHE(cached_publisher_site_url_bloom)){
			memcached_release_object_reference((char**)&cached_publisher_site_url_bloom);
			return ADS_ERROR_SUCCESS; // return success if no/invalid blocklist for the publisher/site
		}
		bloom_idx++;
		
		//So we have a valid bloom
		publisher_site_url_bloom[0] = cached_publisher_site_url_bloom;
		*bloom_count=(int)(*((char*)cached_publisher_site_url_bloom +(size_t) TOTAL_BLOOM_OBJECT_SIZE(cached_publisher_site_url_bloom[0].nelements)));
		int get_failed=0;
		while( *bloom_count>bloom_idx  && MAX_ALLOWED_BLOOMS>bloom_idx){
			snprintf(publisher_site_url_bloom_key, MAX_KEY_SIZE, PUBLISHER_SITE_URL_BLOOM, pub_id, site_id, bloom_type, bloom_idx);
			key_length = strlen(publisher_site_url_bloom_key);
			publisher_site_url_bloom_key[MAX_KEY_SIZE]=0;
			
			cached_publisher_site_url_bloom = 
				(BLOOM*) memcached_get_object_reference(cache,
						publisher_site_url_bloom_key,key_length,	&ret_len);
			if (cached_publisher_site_url_bloom != NULL && !INVALID_FILTER_IN_CACHE(cached_publisher_site_url_bloom)){
				publisher_site_url_bloom[bloom_idx]=cached_publisher_site_url_bloom;
				bloom_idx++;
			}else{
				get_failed=1;
				break;
			}
		}
		if(get_failed){
			for( i=0; i< bloom_idx; i++){
				memcached_release_object_reference((char**)&publisher_site_url_bloom[i]);
			}
		}else //assume it to be a cache call fail and return after free()/else go for DB
		return ADS_ERROR_SUCCESS;
	}

	if (ret_len == -1) {
		reinit_cache(cache);
	}

	retval = db_get_publisher_site_bloom_list(dbconn,
			pub_id,
			site_id,
			publisher_site_url_bloom,
			ret_size,
			bloom_type,
			bloom_count,
			MAX_ALLOWED_BLOOMS);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG,"\n DB call failed for db_get_publisher_site_block_list()");	
		return retval;
	}
	if( NULL != publisher_site_url_bloom && NULL != publisher_site_url_bloom[0]){
		i=0;
		void * retptr=NULL;
		retptr=realloc(publisher_site_url_bloom[0],ret_size[0]+sizeof(char));
		if(NULL == retptr){
			for(i=0; i<*bloom_count; i++){
				memcached_release_object_reference((char**)&publisher_site_url_bloom[i] );
			}
			*bloom_count=0;
			return ADS_ERROR_NOMEMORY;
		}else
			publisher_site_url_bloom[0]=retptr;

		char nblooms=(char)(*bloom_count);
		memcpy((char*)publisher_site_url_bloom[0]+ret_size[0],&nblooms,sizeof(char));
		ret_size[0] += sizeof(char);

		retval = libmemcached_set(cache, publisher_site_url_bloom_key,
				key_length, (void *) (publisher_site_url_bloom[0]),
				ret_size[0], g_fte_cache_element_timeout, 0);

	for( i=1; publisher_site_url_bloom[i]!= NULL && *bloom_count>i && retval==0 ; i++ ){
		//handle setting first bloom with no. and type if bloom
		snprintf(publisher_site_url_bloom_key, MAX_KEY_SIZE, PUBLISHER_SITE_URL_BLOOM, pub_id, site_id,bloom_type ,i);
		key_length = strlen(publisher_site_url_bloom_key);
		publisher_site_url_bloom_key[MAX_KEY_SIZE]=0;

		retval = libmemcached_set(cache, publisher_site_url_bloom_key,
				key_length, (void *) (publisher_site_url_bloom[i]),
				ret_size[i], g_fte_cache_element_timeout, 0);
		}
	}	else {
		snprintf(publisher_site_url_bloom_key, MAX_KEY_SIZE, PUBLISHER_SITE_URL_BLOOM, pub_id, site_id, bloom_type,0);
		publisher_site_url_bloom_key[MAX_KEY_SIZE]=0;
		//handle setting first bloom with no. and type if bloom
		retval = libmemcached_set(cache, publisher_site_url_bloom_key,
				key_length, (void *)(&dummy_entry),
				sizeof(BLOOM),
				get_fte_cache_timeout(), 0);
	}
	if (retval != 0) {
		reinit_cache(cache);
	}
	return ADS_ERROR_SUCCESS;
}
