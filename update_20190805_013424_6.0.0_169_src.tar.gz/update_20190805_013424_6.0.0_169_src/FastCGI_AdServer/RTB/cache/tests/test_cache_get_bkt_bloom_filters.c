#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include "cache_libmemcached.h"
#include "rt_types.h"
#include <ad_server_types.h>
#include "cache_get_bkt_bloom_filters.h"
#include "db_get_bkt_bloom_filters.h"
int gbl_log_level = L_DEBUG;
int __wrap_db_get_bkt_bloom_filters(db_connection_t *dbconn,
		const char *db_query,
		BKT_BLOOM** out_bloom_filter,
		int *bloom_count,
		size_t *ret_size,
		char *update_time) {
	check_expected(db_query);
	out_bloom_filter[0] = mock_type(BKT_BLOOM*);
	*bloom_count = mock_type(int);
	ret_size[0] = mock_type(size_t);
	return mock_type(int);
}

int __wrap_bkt_bloom_destroy(BKT_BLOOM **bkt_bloom) {
	return 0;
}

int __wrap_get_cache_timeout() {
	return mock_type(int);
}

int __wrap_reinit_cache(cache_handle_t *cache_handle) {
	return mock_type(int);
}
char* __wrap_memcached_get_object_reference(cache_handle_t *cache_handle, const char* key, size_t key_length, int* ret_length) {
	check_expected(key);
	check_expected(key_length);
	*ret_length = mock_type(int);
	return mock_ptr_type(char *);
}

void __wrap_memcached_release_object_reference(char** data_ptr) {
}

int __wrap_libmemcached_set(cache_handle_t *cache_handle,
		const char *key,
		size_t key_length,
		const char *value,
		size_t value_length,
		time_t expiration,
		uint32_t flags) {
	check_expected(key);
	check_expected(key_length);
	check_expected(value_length);
	check_expected(expiration);
	check_expected(flags);
	return mock_type(int);
}

typedef struct test_cache_get_bkt_bloom_filters_inputs_t {
	char cache_key[100];
	char db_query[200];
	int blm_count;
	int ret_dummy_cache;
	int ret_cache_get;
	int db_data_present;
	int ret_db_call;
	int ret_val;
} test_cache_get_bkt_bloom_filters_inputs;

void test_cache_get_bkt_bloom_filters(test_cache_get_bkt_bloom_filters_inputs *input) {
	BKT_BLOOM_ARRAY bkt_bloom_array;
	char cache_key[10][MAX_KEY_SIZE];
	db_connection_t dbconn;
	cache_handle_t cache;
	BKT_BLOOM dummy_bloom = {.bit_array_size=0, .nelements=0, .first_element={0}};
	BKT_BLOOM *bloom = (BKT_BLOOM*) malloc (sizeof(BKT_BLOOM));
	bloom->bit_array_size = 1;
	bloom->nelements = 1;
	bloom->first_element[0] = '\0';
	char bloom_data[1000];
	int key_len, ret;
	int i;

	char blm_cnt = input->blm_count;
	int bloom_size = sizeof(BKT_BLOOM);

	memcpy(bloom_data, bloom, bloom_size);
	memcpy(bloom_data+bloom_size, &blm_cnt, 1);

	if (input->ret_dummy_cache) {
		key_len = snprintf(cache_key[0], MAX_KEY_SIZE, "%s_%d", input->cache_key, 0);
		expect_string(__wrap_memcached_get_object_reference, key, cache_key);
		expect_value(__wrap_memcached_get_object_reference, key_length, key_len);
		will_return(__wrap_memcached_get_object_reference, sizeof(BKT_BLOOM));
		will_return(__wrap_memcached_get_object_reference, &dummy_bloom);
	} else {
		if (0 == input->ret_cache_get) {
			for (i=0; i < blm_cnt; i++) {
				key_len = snprintf(cache_key[i], MAX_KEY_SIZE, "%s_%d", input->cache_key, i);
				expect_string(__wrap_memcached_get_object_reference, key, cache_key[i]);
				expect_value(__wrap_memcached_get_object_reference, key_length, key_len);
				will_return(__wrap_memcached_get_object_reference, sizeof(BKT_BLOOM)+1);
				will_return(__wrap_memcached_get_object_reference, bloom_data);
			}
		} else {
			key_len = snprintf(cache_key[0], MAX_KEY_SIZE, "%s_%d", input->cache_key, 0);
			expect_string(__wrap_memcached_get_object_reference, key, cache_key[0]);
			expect_value(__wrap_memcached_get_object_reference, key_length, key_len);
			will_return(__wrap_memcached_get_object_reference, -1);
			will_return(__wrap_memcached_get_object_reference, NULL);

			will_return(__wrap_reinit_cache, 0);

			expect_value(__wrap_db_get_bkt_bloom_filters, db_query, input->db_query);
			if (1 == input->db_data_present) {
				will_return(__wrap_db_get_bkt_bloom_filters, bloom);
				will_return(__wrap_db_get_bkt_bloom_filters, input->blm_count);
				will_return(__wrap_db_get_bkt_bloom_filters, 1);
			} else {
				will_return(__wrap_db_get_bkt_bloom_filters, NULL);
				will_return(__wrap_db_get_bkt_bloom_filters, 0);
				will_return(__wrap_db_get_bkt_bloom_filters, 0);
			}

			will_return(__wrap_db_get_bkt_bloom_filters, input->ret_db_call);

			if (0 == input->ret_db_call) {
				will_return(__wrap_get_cache_timeout, 10);

				expect_string(__wrap_libmemcached_set, key, cache_key[0]);
				expect_value(__wrap_libmemcached_set, key_length, key_len);

				if (1 == input->db_data_present) {
					expect_value(__wrap_libmemcached_set, value_length, 2);
				} else {
					expect_value(__wrap_libmemcached_set, value_length, sizeof(BKT_BLOOM));
				}
				expect_value(__wrap_libmemcached_set, expiration, 10);
				expect_value(__wrap_libmemcached_set, flags, 0);

				will_return(__wrap_libmemcached_set, 0);
			}
		}
	}

	ret = cache_get_bkt_bloom_filters(&cache, &dbconn, input->cache_key, input->db_query, &bkt_bloom_array);
	assert_int_equal(ret, input->ret_val);
	assert_int_equal(bkt_bloom_array.bkt_bloom_count,input->blm_count);
	free(bloom);
}

static void test_cache_get_bkt_bloom_filters__all_testcases(void **state) {
	int i;
	test_cache_get_bkt_bloom_filters_inputs inputs[] = {
		/* cache_key,db_query,blm_cnt,ret_dummy,ret_cache_get,db_data_present,ret_db_call,ret_val */
		{"cache_key","db_query",0,1,0,0,0,0}, /* return dummy cache */
		{"cache_key","db_query",1,0,0,0,0,0}, /* return 1 bkt_bloom from cache */
		{"cache_key","db_query",4,0,0,0,0,0}, /* return 4 bkt_bloom from cache */
		{"cache_key","db_query",9,0,0,0,0,0}, /* return 9 bkt_bloom from cache */
		{"cache_key","db_query",0,0,-1,0,0,0}, /* cache_get fails, no data from DB, dummy set */
		{"cache_key","db_query",1,0,-1,1,0,0}, /* cache_get fails, data from DB, cache set */
		{"cache_key","db_query",0,0,-1,1,-1,-1}, /* cache_get fails, DB call fails */
	};
	for (i=0; i<(sizeof(inputs)/sizeof(test_cache_get_bkt_bloom_filters_inputs)); i++) {
		test_cache_get_bkt_bloom_filters(&inputs[i]);
	}
}

int main() {
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_cache_get_bkt_bloom_filters__all_testcases),
	};
	return cmocka_run_group_tests(tests, NULL, NULL);
}
