#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include "cache_libmemcached.h"
#include "rt_types.h"
#include "db_pub_site_advertiser_domain_category_list.h"
#include "cache_pub_site_advertiser_domain_category_list.h"
#include <ad_server_types.h>
int gbl_log_level = L_DEBUG;

int __wrap_db_get_pub_site_domain_category_blocklist(db_connection_t *dbconn,
		const int **pub_site_domain_category_blocklist,
		int *nelements,
		long pub_id,
		long site_id){
	check_expected(pub_id);
	check_expected(site_id);
	*pub_site_domain_category_blocklist = mock_type(int *);
	*nelements = mock_type(int);
	return mock_type(int);
}

int __wrap_db_get_pub_site_domain_advertiser_blocklist(db_connection_t *dbconn,
		const long **pub_site_domain_advertiser_blocklist,
		int *nelements,
		long pub_id,
		long site_id){
	check_expected(pub_id);
	check_expected(site_id);
	*pub_site_domain_advertiser_blocklist = mock_type(long *);
	*nelements = mock_type(int);
	return mock_type(int);
}
int __wrap_get_cache_timeout(){
	return mock_type(int);
}

int __wrap_reinit_cache(cache_handle_t *cache_handle){
	return mock_type(int);
}
char* __wrap_memcached_get_object_reference(cache_handle_t *cache_handle, const char* key, size_t key_length, int* ret_length) {
	check_expected(key);
	check_expected(key_length);
	*ret_length = mock_type(int);
	return mock_ptr_type(char *);
}

void __wrap_memcached_release_object_reference(char** data_ptr) {
}

int __wrap_libmemcached_set(cache_handle_t *cache_handle,
		const char *key,
		size_t key_length,
		const char *value,
		size_t value_length,
		time_t expiration,
		uint32_t flags) {
	check_expected(key);
	check_expected(key_length);
	check_expected(value_length);
	check_expected(expiration);
	check_expected(flags);
	return mock_type(int);
}

typedef struct test_cache_get_pub_site_domain_category_list_inputs_t{
	int pub_id;
	int site_id;
	int ret_mem_get_ref;
	int cache_data;
	int ret_db_call;
	int db_data;
	int ret_mem_set;
	int ret_val;
}test_cache_get_pub_site_domain_category_list_inputs;

void test_cache_get_pub_site_domain_advertiser_blocklist(test_cache_get_pub_site_domain_category_list_inputs *input){
	char cache_key[MAX_KEY_SIZE];
	db_connection_t dbconn;
	cache_handle_t cache;
	int key_len, ret;
	long *adv_blocklist = NULL;
	int ret_list = 0;
	long data = input->cache_data;
	long db_data = input->db_data;
	key_len = snprintf(cache_key, MAX_KEY_SIZE, PUB_SITE_DOM_ADV_BLK_KEY, (long)input->pub_id, (long)input->site_id);

	expect_string(__wrap_memcached_get_object_reference, key, cache_key);
	expect_value(__wrap_memcached_get_object_reference, key_length, key_len);
	if(0 == input->ret_mem_get_ref){
		will_return(__wrap_memcached_get_object_reference, sizeof(long));
		will_return(__wrap_memcached_get_object_reference, &data);
	}
	else{
		will_return(__wrap_memcached_get_object_reference, -1);
		will_return(__wrap_memcached_get_object_reference, NULL);

		will_return(__wrap_reinit_cache, 0);


		expect_value(__wrap_db_get_pub_site_domain_advertiser_blocklist, pub_id, input->pub_id);
		expect_value(__wrap_db_get_pub_site_domain_advertiser_blocklist, site_id, input->site_id);
		if(0 != input->db_data){
			will_return(__wrap_db_get_pub_site_domain_advertiser_blocklist, &db_data);
			will_return(__wrap_db_get_pub_site_domain_advertiser_blocklist, 2);
		}
		else{
			will_return(__wrap_db_get_pub_site_domain_advertiser_blocklist, NULL);
			will_return(__wrap_db_get_pub_site_domain_advertiser_blocklist, 0);
		}

		will_return(__wrap_db_get_pub_site_domain_advertiser_blocklist, input->ret_db_call);

		if(0 == input->ret_db_call){
			will_return(__wrap_get_cache_timeout, 10);

			expect_string(__wrap_libmemcached_set, key, cache_key);
			expect_value(__wrap_libmemcached_set, key_length, key_len);

			if(0 != input->db_data){
				expect_value(__wrap_libmemcached_set, value_length, sizeof(long) * 2);
			}
			else{
				expect_value(__wrap_libmemcached_set, value_length, sizeof(long));
			}
			expect_value(__wrap_libmemcached_set, expiration, 10);
			expect_value(__wrap_libmemcached_set, flags, 0);

			will_return(__wrap_libmemcached_set, 0);
		}
	}

	ret = cache_get_pub_site_domain_advertiser_blocklist(&dbconn, &cache, (long **)&adv_blocklist, &ret_list, input->pub_id, input->site_id);
	assert_int_equal(ret, input->ret_val);
	if(0 == input->ret_mem_get_ref && input->cache_data){
		assert_int_equal(*adv_blocklist, input->cache_data);
		assert_int_equal(ret_list, 1);
	}
	else if(0 == input->ret_db_call && input->db_data){
		assert_int_equal(*adv_blocklist, input->db_data);
		assert_int_equal(ret_list, 2);
	}
	else{
		assert_int_equal(adv_blocklist, NULL);
		assert_int_equal(ret_list, 0);
	}
}

static void test_cache_get_pub_site_domain_advertiser_blocklist__all_testcases(void **state){
	int i;
	test_cache_get_pub_site_domain_category_list_inputs inputs[]={
		// Positive testcases
		{123,333,0,5,0,0,0,0}, // data present in mem cache - valid data
		{111,333,0,0,0,0,0,0}, // data present in mem cache - dummy data
		{111,333,-1,0,0,10,0,0}, // data not present in mem cache - DB call returned data
		// Negative testcase
		{111,333,-1,0,0,0,0,0}, // data not present in mem cache - DB call returned no data
		{111,333,-1,0,-1,0,0,-1}, // data not present in mem cache - DB call failed
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_cache_get_pub_site_domain_category_list_inputs));i++){
		test_cache_get_pub_site_domain_advertiser_blocklist(&inputs[i]);
	}
}

void test_cache_get_pub_site_domain_category_blocklist(test_cache_get_pub_site_domain_category_list_inputs *input){
	char cache_key[MAX_KEY_SIZE];
	db_connection_t dbconn;
	cache_handle_t cache;
	int key_len, ret;
	int *adv_blocklist = NULL;
	int ret_list = 0;
	int data = input->cache_data;
	int db_data = input->db_data;
	key_len = snprintf(cache_key, MAX_KEY_SIZE, PUB_SITE_DOM_CAT_BLK_KEY, (long)input->pub_id, (long)input->site_id);

	expect_string(__wrap_memcached_get_object_reference, key, cache_key);
	expect_value(__wrap_memcached_get_object_reference, key_length, key_len);
	if(0 == input->ret_mem_get_ref){
		will_return(__wrap_memcached_get_object_reference, sizeof(int));
		will_return(__wrap_memcached_get_object_reference, &data);
	}
	else{
		will_return(__wrap_memcached_get_object_reference, -1);
		will_return(__wrap_memcached_get_object_reference, NULL);

		will_return(__wrap_reinit_cache, 0);


		expect_value(__wrap_db_get_pub_site_domain_category_blocklist, pub_id, input->pub_id);
		expect_value(__wrap_db_get_pub_site_domain_category_blocklist, site_id, input->site_id);
		if(0 != input->db_data){
			will_return(__wrap_db_get_pub_site_domain_category_blocklist, &db_data);
			will_return(__wrap_db_get_pub_site_domain_category_blocklist, 2);
		}
		else{
			will_return(__wrap_db_get_pub_site_domain_category_blocklist, NULL);
			will_return(__wrap_db_get_pub_site_domain_category_blocklist, 0);
		}

		will_return(__wrap_db_get_pub_site_domain_category_blocklist, input->ret_db_call);

		if(0 == input->ret_db_call){
			will_return(__wrap_get_cache_timeout, 10);

			expect_string(__wrap_libmemcached_set, key, cache_key);
			expect_value(__wrap_libmemcached_set, key_length, key_len);

			if(0 != input->db_data){
				expect_value(__wrap_libmemcached_set, value_length, sizeof(int) * 2);
			}
			else{
				expect_value(__wrap_libmemcached_set, value_length, sizeof(int));
			}
			expect_value(__wrap_libmemcached_set, expiration, 10);
			expect_value(__wrap_libmemcached_set, flags, 0);

			will_return(__wrap_libmemcached_set, 0);
		}
	}

	ret = cache_get_pub_site_domain_category_blocklist(&dbconn, &cache, (int **)&adv_blocklist, &ret_list, input->pub_id, input->site_id);
	assert_int_equal(ret, input->ret_val);
	if(0 == input->ret_mem_get_ref && input->cache_data){
		assert_int_equal(*adv_blocklist, input->cache_data);
		assert_int_equal(ret_list, 1);
	}
	else if(0 == input->ret_db_call && input->db_data){
		assert_int_equal(*adv_blocklist, input->db_data);
		assert_int_equal(ret_list, 2);
	}
	else{
		assert_int_equal(adv_blocklist, NULL);
		assert_int_equal(ret_list, 0);
	}
}

static void test_cache_get_pub_site_domain_category_blocklist__all_testcases(void **state){
	int i;
	test_cache_get_pub_site_domain_category_list_inputs inputs[]={
		// Positive testcases
		{123,333,0,5,0,0,0,0}, // data present in mem cache - valid data
		{111,333,0,0,0,0,0,0}, // data present in mem cache - dummy data
		{111,333,-1,0,0,10,0,0}, // data not present in mem cache - DB call returned data
		// Negative testcase
		{111,333,-1,0,0,0,0,0}, // data not present in mem cache - DB call returned no data
		{111,333,-1,0,-1,0,0,-1}, // data not present in mem cache - DB call failed
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_cache_get_pub_site_domain_category_list_inputs));i++){
		test_cache_get_pub_site_domain_category_blocklist(&inputs[i]);
	}
}

int main(){
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_cache_get_pub_site_domain_advertiser_blocklist__all_testcases),
		cmocka_unit_test(test_cache_get_pub_site_domain_category_blocklist__all_testcases)
	};
	return cmocka_run_group_tests(tests, NULL, NULL);
}
