/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cache_types.h"
#include "fte_util.h"
#include "db_connection.h"
#include "url_blocklist.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include "db_error.h"
#include "db_url_blocklist.h"
#include "error.h"


#define MAGIC_COOKIE "@RID3R@" // Guess who?
/* Or how about "Se7en" or "@Rusty@"?  */


/*
 * Behaviour of the function:-
 * 1) Failure:- 
 *    a) Return code other than ADS_ERROR_SUCCESS
 *    b) From rt_request_params set json_url_blockedlist & json_allowed_creative_attributes_list to Empty string.
 *       Also, set json_allowed_creative_attributes_list_len & json_url_blockedlist_len ot zero.
 *    c) Nothing is set in memcache, so next request for same pub_id and site_id will
 *       hit the DB because all errors in this function are assumed to be transitory(Duh!)
 *
 * 2) Success:- 
 * 		a) Return ADS_ERROR_SUCCESS 
 * 		b) If memcache returns NULL; go to DB, if there is no record for a
 * 		   pub_id and site_id OR all the 4 blocklists are NULL in the DB, json_url_blockedlist is
 * 		   set to MAGIC_COOKIE in memcache.
 * 			 												OR
 * 		   If memcache return MAGIC_COOKIE from rt_request_params set json_url_blockedlist & json_allowed_creative_attributes_list to Empty string.
 *         Also, set json_allowed_creative_attributes_list_len & json_url_blockedlist_len ot zero.
 * 		   												OR
 * 		   If memcache returns something other than NULL or MAGIC_COOKIE,
 * 		   Set json_url_blockedlist, json_allowed_creative_attributes_list,
 *         json_allowed_creative_attributes_list_len & json_url_blockedlist_len to values return by memcache.
 */
int cache_get_json_blocklist(long pub_id, long site_id, cache_handle_t* cache_handle, db_connection_t* conn, rt_request_params_t *rt_request_params) {
	// Local variables
	char url_blocklist_key[MAX_KEY_SIZE];
	unsigned int url_blocklist_key_len=0;
	//char* cached_url_blocklist = NULL;
	memcached_blocklist_t *cached_blocklist = NULL, *blocked_list = NULL;
	int retval = 0;
	int ret_len = 0;
	//int len_blocklist=0;


	// Create the key
	sprintf(url_blocklist_key, URL_BLOCKLIST_FORMAT, pub_id, site_id); // sprintf is "safe" here
	url_blocklist_key_len = strlen(url_blocklist_key);

	/*
	 * Check if the information about json_blocklist of this pub_id and site_id is present
	 * in the cache based on the key
	 */
	//cached_url_blocklist = (char*)libmemcached_get(cache_handle, url_blocklist_key, url_blocklist_key_len, &ret_len);
	cached_blocklist = (memcached_blocklist_t *) libmemcached_get(cache_handle, url_blocklist_key, url_blocklist_key_len, &ret_len);
	if (cached_blocklist != NULL) {
		// Found the json_blocklist in the cache
#ifdef FUNCTIONAL_TESTING
		// This is to get logs while testing
		int i;
		llog_write(L_DEBUG,"\nret_val = %d, CACHED_JSON_STRING=", ret_len);
		for(i = 0; i < cached_blocklist->json_url_blockedlist_len; i++) {
			llog_write(L_DEBUG,"%c",cached_blocklist->json_url_blocked_list[i]);
		}
		llog_write(L_DEBUG,"\n");
#endif
		if(strncmp(cached_blocklist->json_url_blocked_list,MAGIC_COOKIE, (sizeof(MAGIC_COOKIE) - 1))==0) {
			/*
			 * Either there was no record for this pub_id, site_id combination in the table
			 * "publisher_site_cooked_brand_contol_blocklists" or all the 4 blocklists are NULL
			 *
			 */
			free(cached_blocklist);
			rt_request_params->pub_site_rich_media_params->blocked_list = NULL;
		} else {
			// We got the json_blocklist
			rt_request_params->pub_site_rich_media_params->blocked_list = cached_blocklist;
		}
		// Hope you had fun, bbye!
		return ADS_ERROR_SUCCESS;
	}
	// TODO reinit is NOP as of now so if memcache fails, there is a sword lurking right above
	// your neck.
	// If ret_len is -1, that means there was some other error rather than MEMCACHED_NOTFOUND, try to reinit the connection TODO
	// check the below assumption
	if (ret_len == -1) {
		 rt_request_params->pub_site_rich_media_params->blocked_list = NULL;
		 reinit_cache(cache_handle);
	}

	// Get the value from DB.
	retval = get_url_blocklist(pub_id, site_id, conn, rt_request_params);
	if (retval != DB_ERROR_SUCCESS) {
		if (retval == DB_ERROR_INTERNAL) {
			llog_write(L_DEBUG,"ERROR May be the db is down, not setting the cache %s:%d\n",__FILE__,__LINE__);
			// Return internal error to main which would release the connection and get new connection 
			return ADS_ERROR_INTERNAL;
		}
		return ADS_ERROR_NOMEMORY;
	}

	blocked_list = rt_request_params->pub_site_rich_media_params->blocked_list;
	if(	blocked_list->json_url_blockedlist_len > 0 ||
		blocked_list->json_allowed_creative_attributes_list_len > 0) {
		// Remove after testing
#ifdef FUNCTIONAL_TESTING
		int i;
		llog_write(L_DEBUG,"\nDB_JSON_STRING=");
		for(i=0;i< blocked_list->json_url_blockedlist_len; i++) {
			llog_write(L_DEBUG,"%c",(blocked_list->json_url_blocked_list)[i]);
		}
		llog_write(L_DEBUG,"\n");
#endif

		retval = libmemcached_set(cache_handle,
                                  url_blocklist_key,
                                  url_blocklist_key_len,
                                  (void *) blocked_list,
                                  sizeof (memcached_blocklist_t),
                                  get_fte_cache_timeout(),
                                  0);
	} else {
		/* Initialize caching attributes. */
		memcpy(blocked_list->json_url_blocked_list,
			(void *) MAGIC_COOKIE,
			(sizeof(MAGIC_COOKIE) - 1));
		blocked_list->json_url_blockedlist_len = 0;
		blocked_list->json_allowed_creative_attributes_list[0] = '\0';
		blocked_list->json_allowed_creative_attributes_list_len = 0;
		blocked_list->json_total_len = 0;

		// set MAGIC_COOKIE as all 4 columns are NULL.
		retval = libmemcached_set(cache_handle,
                                  url_blocklist_key,
                                  url_blocklist_key_len,
                                  (void *) blocked_list,
                                  sizeof (memcached_blocklist_t),
                                  get_fte_cache_timeout(),
                                  0);
	}

	/*
	 * If we could not add the value, probably the server went down in between,
	 * so reinit the server
	 * TODO change this later, right now this function doesn't work
	 */
	if (retval != 0) {
		reinit_cache(cache_handle);
	}
	return ADS_ERROR_SUCCESS;
}
