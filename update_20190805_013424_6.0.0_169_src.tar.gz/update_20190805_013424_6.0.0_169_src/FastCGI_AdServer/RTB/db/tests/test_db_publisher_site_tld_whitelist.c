#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include "error.h"
#include "db_connection.h"
#include "rt_types.h"
#include "db_publisher_site_tld_whitelist.h"

#define TEST_GET_PUBLISHER_SITE_TLD_WHITELIST \
	"select left (tld_name, 4), crc_32, id, application_profile_id, platform_id, site_code from publisher_aggregator_site_tld where pub_id = ? and site_id = ? and deleted = 0 order by crc_32 ASC limit ?,?"

int gbl_log_level = L_DEBUG;
void __wrap_db_conn_print_error(SQLSMALLINT htype, SQLHANDLE hndl, SQLRETURN frc, int line, char *file){
}

SQLRETURN __wrap_SQLBindCol(
		SQLHSTMT       StatementHandle,
		SQLUSMALLINT   ColumnNumber,
		SQLSMALLINT    TargetType,
		SQLPOINTER     TargetValuePtr,
		SQLLEN         BufferLength,
		SQLLEN *       StrLen_or_Ind){
	check_expected(ColumnNumber);
	check_expected(TargetType);
	check_expected(BufferLength);
	memcpy(TargetValuePtr, mock_type(SQLPOINTER),4);
	*StrLen_or_Ind = mock_type(int);
	//memcpy(StrLen_or_Ind, mock_type(SQLLEN *),4);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLExecute(SQLHSTMT StatementHandle){
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFetch(SQLHSTMT StatementHandle){
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLBindParameter(
		SQLHSTMT        StatementHandle,
		SQLUSMALLINT    ParameterNumber,
		SQLSMALLINT     InputOutputType,
		SQLSMALLINT     ValueType,
		SQLSMALLINT     ParameterType,
		SQLULEN         ColumnSize,
		SQLSMALLINT     DecimalDigits,
		SQLPOINTER      ParameterValuePtr,
		SQLLEN          BufferLength,
		SQLLEN *        StrLen_or_IndPtr){
	check_expected(ParameterNumber);
	check_expected(InputOutputType);
	check_expected(ValueType);
	check_expected(ParameterType);
	check_expected(ColumnSize);
	check_expected(DecimalDigits);
	check_expected(BufferLength);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFreeHandle(SQLSMALLINT HandleType, SQLHANDLE Handle){
	check_expected(HandleType);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLAllocHandle(SQLSMALLINT HandleType,SQLHANDLE InputHandle,SQLHANDLE *OutputHandlePtr){
	check_expected(HandleType);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLPrepare(SQLHSTMT StatementHandle, SQLCHAR *StatementText, SQLINTEGER TextLength){
	check_expected(StatementText);
	check_expected(TextLength);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLRowCount(
		SQLHSTMT   StatementHandle,
		SQLLEN *   RowCountPtr){
	memcpy(RowCountPtr, mock_type(SQLLEN *),1);
	return mock_type(SQLRETURN);
}

typedef struct test_db_get_publisher_site_tld_whitelist_inputs_t{
	int pub_id;
	int site_id;
	int ret_sql_prepare;
	int ret_sql_bind[4];
	int ret_sql_exec;
	int ret_sql_fetch;
	int ret_sql_rowcount;
	int row_count;
	char domain_name[10];
	int crc_32;
	int tld_id;
	int app_prof_id;
	int platform;
	int site_code;
	int ret_val;
}test_db_get_publisher_site_tld_whitelist_inputs;

void test_db_get_publisher_site_tld_whitelist(test_db_get_publisher_site_tld_whitelist_inputs *input){
	int tmp_int=3, i, rv, nelement = 0;
	int bind_fail = 0;
	publisher_site_top_level_domain_name_t *tld_info = NULL;
	db_connection_t db_conn;
	expect_value(__wrap_SQLAllocHandle, HandleType, SQL_HANDLE_STMT);
	will_return(__wrap_SQLAllocHandle, SQL_SUCCESS);

	expect_string(__wrap_SQLPrepare, StatementText, TEST_GET_PUBLISHER_SITE_TLD_WHITELIST);
	expect_value(__wrap_SQLPrepare, TextLength, SQL_NTS);
	will_return(__wrap_SQLPrepare, input->ret_sql_prepare);

	if(input->ret_sql_prepare == SQL_SUCCESS){
		for(i=0;i<4;i++){
			expect_value(__wrap_SQLBindParameter, ParameterNumber, i+1);
			expect_value(__wrap_SQLBindParameter, InputOutputType, SQL_PARAM_INPUT);
			expect_value(__wrap_SQLBindParameter, ValueType, SQL_C_ULONG);
			expect_value(__wrap_SQLBindParameter, ParameterType, SQL_INTEGER);
			expect_value(__wrap_SQLBindParameter, ColumnSize, 0);
			expect_value(__wrap_SQLBindParameter, DecimalDigits, 0);
			expect_value(__wrap_SQLBindParameter, BufferLength, 0);
			will_return(__wrap_SQLBindParameter, input->ret_sql_bind[i]);
			if(input->ret_sql_bind[i] != SQL_SUCCESS){
				bind_fail = 1;
				break;
			}
		}

		if(!bind_fail){
			will_return(__wrap_SQLExecute, input->ret_sql_exec);

			if(input->ret_sql_exec == SQL_SUCCESS){
				expect_value(__wrap_SQLBindCol, ColumnNumber, 1);
				expect_value(__wrap_SQLBindCol, TargetType, SQL_C_CHAR);
				expect_value(__wrap_SQLBindCol, BufferLength, TLD_WHITELIST_TRUNCATED_DOMAIN_NAME_LENGTH+1);
				will_return(__wrap_SQLBindCol, &input->domain_name);
				will_return(__wrap_SQLBindCol, tmp_int);
				will_return(__wrap_SQLBindCol, SQL_SUCCESS);

				expect_value(__wrap_SQLBindCol, ColumnNumber, 2);
				expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
				expect_value(__wrap_SQLBindCol, BufferLength, 0);
				will_return(__wrap_SQLBindCol, &input->crc_32);
				will_return(__wrap_SQLBindCol, tmp_int);
				will_return(__wrap_SQLBindCol, SQL_SUCCESS);

				expect_value(__wrap_SQLBindCol, ColumnNumber, 3);
				expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
				expect_value(__wrap_SQLBindCol, BufferLength, 0);
				will_return(__wrap_SQLBindCol, &input->tld_id);
				will_return(__wrap_SQLBindCol, tmp_int);
				will_return(__wrap_SQLBindCol, SQL_SUCCESS);

				expect_value(__wrap_SQLBindCol, ColumnNumber, 4);
				expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
				expect_value(__wrap_SQLBindCol, BufferLength, 0);
				will_return(__wrap_SQLBindCol, &input->app_prof_id);
				will_return(__wrap_SQLBindCol, tmp_int);
				will_return(__wrap_SQLBindCol, SQL_SUCCESS);

				expect_value(__wrap_SQLBindCol, ColumnNumber, 5);
				expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
				expect_value(__wrap_SQLBindCol, BufferLength, 0);
				will_return(__wrap_SQLBindCol, &input->platform);
				will_return(__wrap_SQLBindCol, tmp_int);
				will_return(__wrap_SQLBindCol, SQL_SUCCESS);

				expect_value(__wrap_SQLBindCol, ColumnNumber, 6);
				expect_value(__wrap_SQLBindCol, TargetType, SQL_C_CHAR);
				expect_value(__wrap_SQLBindCol, BufferLength, MAX_SITE_URL_ID_LENGTH+1);
				will_return(__wrap_SQLBindCol, &input->site_code);
				will_return(__wrap_SQLBindCol, tmp_int);
				will_return(__wrap_SQLBindCol, SQL_SUCCESS);

				will_return(__wrap_SQLRowCount, &input->row_count);
				will_return(__wrap_SQLRowCount, input->ret_sql_rowcount);

				if(input->ret_sql_rowcount == SQL_SUCCESS && input->row_count > 0){
					will_return(__wrap_SQLFetch, input->ret_sql_fetch);
					if(input->ret_sql_fetch != SQL_NO_DATA)
						will_return(__wrap_SQLFetch, SQL_NO_DATA);
				}
			}
		}
	}
	//expect_value(__wrap_SQLFreeHandle, HandleType, SQL_HANDLE_STMT);
	//will_return(__wrap_SQLFreeHandle, SQL_SUCCESS);

	rv = db_get_publisher_site_tld_whitelist(&db_conn, input->pub_id, input->site_id, &tld_info, &nelement, 1, 2);
	assert_int_equal(rv, input->ret_val);
	if(input->ret_val == 0 && input->row_count > 0){
		assert_int_equal(tld_info->crc_32, input->crc_32);
		assert_int_equal(tld_info->top_level_domain_id, input->tld_id);
		assert_int_equal(tld_info->application_profile_id, input->app_prof_id);
		assert_int_equal(tld_info->platform_id, input->platform);
		assert_int_equal(nelement, input->row_count);
		assert_string_equal(tld_info->domain_name, input->domain_name);

		free(tld_info);
	}
	else{
		assert_int_equal(nelement, 0);
		assert_int_equal(tld_info, NULL);
	}
}

static void test_db_get_publisher_site_tld_whitelist__all_testcases(void **state){
	int i;
	test_db_get_publisher_site_tld_whitelist_inputs inputs[]={
		//Positive testcases
		//Pub, site, SQLPrepare_ret,{SQLBindParam_ret},SQLExec_ret,SQLFetch_ret,SQLRowCount_ret,row_count,domain,crc32,tld,appid,plat,site_code,fun_ret
		{123,1234,0,{0,0,0,0},0,0,0,1,"dom",123,12,12,1,12,0},
		// Negative testcases
		{123,1234,0,{0,0,0,0},0,0,0,0,"dom",123,12,12,1,12,0}, // SQLRowcount returns zero count
		{123,1234,0,{0,0,0,0},0,0,-1,0,"dom",123,12,12,1,12,4}, // SQLRowcount failure
		{123,1234,0,{0,0,0,0},0,-1,0,1,"dom",123,12,12,1,12,0}, // SQLFetch failure
		{123,1234,0,{0,0,0,0},-1,-1,0,1,"dom",123,12,12,1,12,4}, // SQLExec failure
		{123,1234,0,{0,0,0,-1},-1,-1,0,1,"dom",123,12,12,1,12,4}, // First SQLBind failure
		{123,1234,0,{0,0,-1,-1},-1,-1,0,1,"dom",123,12,12,1,12,4}, // Second SQLBind failure
		{123,1234,0,{0,-1,-1,-1},-1,-1,0,1,"dom",123,12,12,1,12,4}, // Third SQLBind failure
		{123,1234,0,{-1,-1,-1,-1},-1,-1,0,1,"dom",123,12,12,1,12,4}, // Fourth SQLBind failure
		{123,1234,-1,{-1,-1,-1,-1},-1,-1,0,1,"dom",123,12,12,1,12,4}, // SQLPrepare failure
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_db_get_publisher_site_tld_whitelist_inputs));i++){
		test_db_get_publisher_site_tld_whitelist(&inputs[i]);
	}
}

int main()
{
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_db_get_publisher_site_tld_whitelist__all_testcases),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
