#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include "error.h"
#include "db_connection.h"
#include "rt_types.h"
#include "db_pub_site_advertiser_domain_category_list.h"
int gbl_log_level = L_DEBUG;
void __wrap_db_conn_print_error(SQLSMALLINT htype, SQLHANDLE hndl, SQLRETURN frc, int line, char *file){
}

SQLRETURN __wrap_SQLBindCol(
		SQLHSTMT       StatementHandle,
		SQLUSMALLINT   ColumnNumber,
		SQLSMALLINT    TargetType,
		SQLPOINTER     TargetValuePtr,
		SQLLEN         BufferLength,
		SQLLEN *       StrLen_or_Ind){
	check_expected(ColumnNumber);
	check_expected(TargetType);
	check_expected(BufferLength);
	memcpy(TargetValuePtr, mock_type(SQLPOINTER),4);
	*StrLen_or_Ind = mock_type(int);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLExecute(SQLHSTMT StatementHandle){
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFetch(SQLHSTMT StatementHandle){
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFreeHandle(SQLSMALLINT HandleType, SQLHANDLE Handle){
	check_expected(HandleType);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLAllocHandle(SQLSMALLINT HandleType,SQLHANDLE InputHandle,SQLHANDLE *OutputHandlePtr){
	check_expected(HandleType);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLPrepare(SQLHSTMT StatementHandle, SQLCHAR *StatementText, SQLINTEGER TextLength){
	check_expected(StatementText);
	check_expected(TextLength);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLRowCount(
		SQLHSTMT   StatementHandle,
		SQLLEN *   RowCountPtr){
	memcpy(RowCountPtr, mock_type(SQLLEN *),1);
	return mock_type(SQLRETURN);
}

typedef struct test_db_get_pub_site_domain_blocklist_inputs_t{
	int pub_id;
	int site_id;
	int ret_sql_prepare;
	int ret_sql_exec;
	int ret_sql_fetch;
	int ret_sql_rowcount;
	int row_count;
	long adv_id;
	int ret_val;
}test_db_get_pub_site_domain_blocklist_inputs;

void test_db_get_pub_site_domain_advertiser_blocklist(test_db_get_pub_site_domain_blocklist_inputs *input){
	int tmp_int=3, rv, nelement = 0;
	long *adv_info = NULL;
	char query[MAX_SQL_QUERY_STR_LEN];
	db_connection_t db_conn;

	expect_value(__wrap_SQLAllocHandle, HandleType, SQL_HANDLE_STMT);
	will_return(__wrap_SQLAllocHandle, SQL_SUCCESS);

	snprintf(query, MAX_SQL_QUERY_STR_LEN, GET_PUB_SITE_DOM_ADV_BLOCKLIST, (long)input->pub_id, (long)input->site_id);
	expect_string(__wrap_SQLPrepare, StatementText, query);
	expect_value(__wrap_SQLPrepare, TextLength, SQL_NTS);
	will_return(__wrap_SQLPrepare, input->ret_sql_prepare);

	if(SQL_SUCCESS == input->ret_sql_prepare){
		will_return(__wrap_SQLExecute, input->ret_sql_exec);

		if(SQL_SUCCESS == input->ret_sql_exec){
			expect_value(__wrap_SQLBindCol, ColumnNumber, 1);
			expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
			expect_value(__wrap_SQLBindCol, BufferLength, 0);
			will_return(__wrap_SQLBindCol, &input->adv_id);
			will_return(__wrap_SQLBindCol, tmp_int);
			will_return(__wrap_SQLBindCol, SQL_SUCCESS);

			will_return(__wrap_SQLRowCount, &input->row_count);
			will_return(__wrap_SQLRowCount, input->ret_sql_rowcount);

			if(SQL_SUCCESS == input->ret_sql_rowcount && input->row_count > 0){
				will_return(__wrap_SQLFetch, input->ret_sql_fetch);
				if(SQL_NO_DATA != input->ret_sql_fetch)
					will_return(__wrap_SQLFetch, SQL_NO_DATA);
			}
		}
	}

	rv = db_get_pub_site_domain_advertiser_blocklist(&db_conn, (long **)&adv_info, &nelement, input->pub_id, input->site_id);
	assert_int_equal(rv, input->ret_val);
	if(0 == input->ret_val && input->row_count > 0){
		assert_int_equal(*adv_info, input->adv_id);
		assert_int_equal(nelement, input->row_count);

		free(adv_info);
	}
	else{
		assert_int_equal(nelement, 0);
		assert_int_equal(adv_info, NULL);
	}
}

static void test_db_get_pub_site_domain_advertiser_blocklist__all_testcases(void **state){
	int i;
	test_db_get_pub_site_domain_blocklist_inputs inputs[]={
		//Positive testcases
		//Pub, site, SQLPrepare_ret,SQLExec_ret,SQLFetch_ret,SQLRowCount_ret,row_count,adv_id,fun_ret
		{123,1234,0,0,0,0,1,12,0},
		// Negative testcases
		{123,1234,0,0,0,0,0,12,0}, // SQLRowcount returns zero count
		{123,1234,0,0,0,-1,0,12,4}, // SQLRowcount failure
		{123,1234,0,0,-1,0,0,12,0}, // SQLFetch failure
		{123,1234,0,-1,-1,0,1,12,4}, // SQLExec failure
		{123,1234,-1,-1,-1,0,1,12,4}, // SQLPrepare failure
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_db_get_pub_site_domain_blocklist_inputs));i++){
		test_db_get_pub_site_domain_advertiser_blocklist(&inputs[i]);
	}
}


void test_db_get_pub_site_domain_category_blocklist(test_db_get_pub_site_domain_blocklist_inputs *input){
	int tmp_int=3, rv, nelement = 0;
	int *cat_info = NULL;
	char query[MAX_SQL_QUERY_STR_LEN];
	db_connection_t db_conn;

	expect_value(__wrap_SQLAllocHandle, HandleType, SQL_HANDLE_STMT);
	will_return(__wrap_SQLAllocHandle, SQL_SUCCESS);

	snprintf(query, MAX_SQL_QUERY_STR_LEN, GET_PUB_SITE_DOM_CAT_BLOCKLIST, (long)input->pub_id, (long)input->site_id);
	expect_string(__wrap_SQLPrepare, StatementText, query);
	expect_value(__wrap_SQLPrepare, TextLength, SQL_NTS);
	will_return(__wrap_SQLPrepare, input->ret_sql_prepare);

	if(SQL_SUCCESS == input->ret_sql_prepare){
		will_return(__wrap_SQLExecute, input->ret_sql_exec);

		if(SQL_SUCCESS == input->ret_sql_exec){
			expect_value(__wrap_SQLBindCol, ColumnNumber, 1);
			expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
			expect_value(__wrap_SQLBindCol, BufferLength, 0);
			will_return(__wrap_SQLBindCol, &input->adv_id);
			will_return(__wrap_SQLBindCol, tmp_int);
			will_return(__wrap_SQLBindCol, SQL_SUCCESS);

			will_return(__wrap_SQLRowCount, &input->row_count);
			will_return(__wrap_SQLRowCount, input->ret_sql_rowcount);

			if(SQL_SUCCESS == input->ret_sql_rowcount && input->row_count > 0){
				will_return(__wrap_SQLFetch, input->ret_sql_fetch);
				if(SQL_NO_DATA != input->ret_sql_fetch)
					will_return(__wrap_SQLFetch, SQL_NO_DATA);
			}
		}
	}

	rv = db_get_pub_site_domain_category_blocklist(&db_conn, (int **)&cat_info, &nelement, input->pub_id, input->site_id);
	assert_int_equal(rv, input->ret_val);
	if(0 == input->ret_val && input->row_count > 0){
		assert_int_equal(*cat_info, input->adv_id);
		assert_int_equal(nelement, input->row_count);

		free(cat_info);
	}
	else{
		assert_int_equal(nelement, 0);
		assert_int_equal(cat_info, NULL);
	}
}

static void test_db_get_pub_site_domain_category_blocklist__all_testcases(void **state){
	int i;
	test_db_get_pub_site_domain_blocklist_inputs inputs[]={
		//Positive testcases
		//Pub, site, SQLPrepare_ret,SQLExec_ret,SQLFetch_ret,SQLRowCount_ret,row_count,adv_id,fun_ret
		{123,1234,0,0,0,0,1,12,0},
		// Negative testcases
		{123,1234,0,0,0,0,0,12,0}, // SQLRowcount returns zero count
		{123,1234,0,0,0,-1,0,12,4}, // SQLRowcount failure
		{123,1234,0,0,-1,0,0,12,0}, // SQLFetch failure
		{123,1234,0,-1,-1,0,1,12,4}, // SQLExec failure
		{123,1234,-1,-1,-1,0,1,12,4}, // SQLPrepare failure
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_db_get_pub_site_domain_blocklist_inputs));i++){
		test_db_get_pub_site_domain_category_blocklist(&inputs[i]);
	}
}

int main()
{
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_db_get_pub_site_domain_advertiser_blocklist__all_testcases),
		cmocka_unit_test(test_db_get_pub_site_domain_category_blocklist__all_testcases),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
