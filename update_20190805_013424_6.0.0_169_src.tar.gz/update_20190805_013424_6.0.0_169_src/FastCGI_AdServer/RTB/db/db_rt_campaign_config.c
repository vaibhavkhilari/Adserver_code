/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "rt_types.h"
#include "db_rt_campaign_config.h"

#define ACTIVE_RTB_ALLOC_SIZE 150

extern int g_datacenter_id;
extern char * g_drproxy_url;
extern char * g_gopro_url;

// get_rt_campaign_config
// ----------------------
// XXX: rt_request_url_params_mask_t can be modified only in this
// function.  Please do not attempt to modify
// rt_request_url_params_mask_t in realtime_bidding_tasks().
int get_rt_campaign_config(rt_request_url_params_mask_t **rt_request_url_params_mask, const db_connection_t * const dbconn,  int *ret_elements ) {

        const char * GET_RT_NW_INFO =
        "select BCC.cluster_lb_url, "
                "BDC.bidder_cluster_id, "
                "RT_CAMPAIGN_CONFIG.dsp_config_id, "
                "BDC.bidder_enabled, "
                "RT_API_CONF.use_timezone, "
                "RT_API_CONF.use_ip, "
                "RT_API_CONF.use_category, "
                "RT_API_CONF.use_keyword, "
                "RT_API_CONF.use_reference_URL, "
                "RT_API_CONF.use_uid, "
                "RT_API_CONF.use_cookie, "
                "RT_API_CONF.use_frequency, "
                "RT_API_CONF.use_adtag_type, "
                "RT_API_CONF.use_browser, "
                "RT_API_CONF.use_language, "
                "RT_API_CONF.use_screen_resolution, "
                "RT_API_CONF.use_ad_position, "
                "RT_API_CONF.click_tracker, "
                "RT_API_CONF.campaign_id, "
                "RT_API_CONF.second_price_auction, "
                "RT_API_CONF.second_price_macro, "
                "RT_API_CONF.second_price_margin_percentage, "
                "RT_API_CONF.use_adid, "
                "RT_API_CONF.use_in_iframe, "
                "RT_API_CONF.use_pubid, "
                "RT_API_CONF.use_siteid, "
                "RT_API_CONF.use_fold_placement, "
                "RT_API_CONF.use_creative_attributes, "
                "RT_API_CONF.use_url_block_lists, "
                "RT_API_CONF.use_creative_categories, "
                "RT_API_CONF.use_pmoptout, "
                "RT_API_CONF.filter_defaulted_request, "
                "RT_API_CONF.filter_non_cookied_request, "
                "RT_API_CONF.use_pmp_enabled, "
                "BDC.dsp_url, "
                "RT_API_CONF.use_secure_params, "
                "RT_API_CONF.use_rich_media_params, "
                "RT_API_CONF.use_mobile_params, "
                "RT_API_CONF.use_geo_params, "
                "RT_API_CONF.bid_price_encryption_enabled, "
                "RT_API_CONF.second_price_encryption_enabled, "
                "RT_API_CONF.click_tracking_url_encoding_enabled, "
                "skip_user_floor, "
                "apply_normal_distribution, "
                "deal_id_passing_enable_flag, "
                "buyer_id_passing_enable_flag, "
                "RT_API_CONF.pass_blank_click_tracking_url, "
                "RT_API_CONF.send_secure_inventory, "
                "RT_API_CONF.suppress_second_price_auction_on_same_campaign, "
                "RT_API_CONF.is_multibid, "
                "RT_API_CONF.use_price_floor, "
                "RT_API_CONF.use_adtruth_id, "
                "RT_API_CONF.use_video_params, "
                "RT_API_CONF.protocol, "
                "RT_API_CONF.use_vertical_id, "
                "RT_API_CONF.minimum_clearing_price_margin, "
                "RT_API_CONF.filter_cookied_request , "
                "RT_API_CONF.send_winloss_info, "
                "RT_API_CONF.supports_native_ad_format, "
                "RT_API_CONF.share_cookies_of, "
                "RT_API_CONF.use_drproxy, "
                "RT_API_CONF.send_hardfloor, "
                "RT_API_CONF.use_audio_params, "
                "RT_API_CONF.send_is_dspuid_inferred, "
                "RT_CAMPAIGN_CONFIG.campaign_throttle_percent, "
                "RT_API_CONF.pixel_id, "
		"RT_API_CONF.server_side_cookie_expiry, "
		"RT_API_CONF.max_multi_requests, "
		"RT_CAMPAIGN_CONFIG.att_bitmap, "
		"RT_API_CONF.pass_granular_site_id, "
		"RT_API_CONF.change_native_img_type, "
		"RT_API_CONF.bidrequest_compress, "
		"RT_API_CONF.bidresponse_compress, "
		"RT_API_CONF.video_placement_percent, "
		"RT_API_CONF.send_publisher_name, "
		"RT_API_CONF.digitrust_retargeting_enabled, "
		"RT_API_CONF.remove_cookie_prefix_uid, "
		"RT_API_CONF.truncate_refurl_if_nonutf8, "
		"RT_API_CONF.audience_dpids_in_bid_req "
        "from "
                "realtime_api_config as RT_API_CONF, "
                "campaign as CAM, "
                "realtime_campaign_config as RT_CAMPAIGN_CONFIG, "
                "bidder_dsp_config BDC, "
                "bidder_cluster_config BCC "
        "where "
                "CAM.realtime = 1 AND "
                "CAM.id = RT_API_CONF.campaign_id AND "
                "RT_CAMPAIGN_CONFIG.campaign_id = RT_API_CONF.campaign_id AND "
                "RT_CAMPAIGN_CONFIG.datacenter_id = ? AND "
                "CAM.campaign_active_flag = 1 AND "
                "campaign_state_id = 1 AND "
                "( isnull(CAM.start_time) OR CAM.start_time < '%s' ) AND "
                "( isnull(CAM.end_time) OR end_time >  '%s' ) AND "
                "RT_CAMPAIGN_CONFIG.dsp_config_id = BDC.id AND "
                "BCC.datacenter_id = RT_CAMPAIGN_CONFIG.datacenter_id AND "
                "BDC.bidder_cluster_id = BCC.id "
        "ORDER BY RT_API_CONF.campaign_id ASC";
	

	/* Local variables */
	rt_request_url_params_mask_t *retvalue=NULL;	
	rt_request_url_params_mask_t *tmp_retvalue=NULL;
	SQLINTEGER s_datacenter_id=0;
	SQLLEN cb_s_datacenter_id=0;		
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN];
	SQLCHAR s_ad_nw_url[MAX_RTB_URL_SIZE + 1 ];
	SQLCHAR s_clicktrack_keyword[MAX_RTB_CLICKTRACK_KEYWORD_LEN + 1];
	SQLCHAR s_second_price_macro[MAX_SECOND_PRICE_MACRO_SIZE + 1];
	SQLINTEGER s_pub_url = 0;
	SQLINTEGER s_ret_campaign_id;
	SQLLEN cb_s_ret_campaign_id;
	SQLINTEGER s_timezone;
	SQLLEN cb_s_timezone;
	SQLINTEGER s_user_ip;
	SQLLEN cb_s_user_ip;
	SQLINTEGER s_catagory;
	SQLLEN cb_s_catagory;
	SQLINTEGER s_keyword;
	SQLLEN cb_s_keyword;
	SQLINTEGER s_ref_url;
	SQLLEN cb_s_ref_url;
 	SQLINTEGER s_user_id;
	SQLLEN cb_s_user_id;
	SQLINTEGER s_cookie;
	SQLLEN cb_s_cookie;
	SQLINTEGER s_browser;
	SQLLEN cb_s_browser;
	SQLINTEGER s_language;
	SQLLEN cb_s_language;
	SQLINTEGER s_screen_resolution;
	SQLLEN cb_s_screen_resolution;
	SQLINTEGER s_ad_position;
	SQLLEN cb_s_ad_position;
	SQLINTEGER s_frequency;
	SQLLEN cb_s_frequency;
	SQLINTEGER s_adtagtype = 0;
	SQLLEN cb_adtagtype;
	SQLLEN cb_s_ad_nw_url = SQL_NTS;
	SQLLEN cb_s_clicktrack_keyword = SQL_NTS;
	SQLINTEGER s_second_price_auction;
	SQLLEN cb_s_second_price_auction;
	SQLLEN cb_s_second_price_macro = SQL_NTS;
	SQLDOUBLE s_second_price_margin;
	SQLLEN cb_s_second_price_margin = 0;
	SQLINTEGER s_adid=0;
	SQLLEN cb_s_adid=0;
	SQLINTEGER s_use_in_iframe=0;
	SQLLEN cb_s_use_in_iframe=0;
	SQLINTEGER s_siteId=0;
	SQLLEN cb_s_siteId=0;
	SQLINTEGER s_pubId=0;
	SQLLEN cb_s_pubId=0;
	SQLINTEGER s_fold_position=0;
	SQLLEN cb_s_fold_position=0;
	SQLINTEGER s_use_optout=0;
	SQLLEN cb_s_use_optout=0;
	SQLINTEGER s_filter_defaulted_request=0;
	SQLLEN cb_filter_defaulted_request=0;
	SQLINTEGER s_filter_non_cookied_request=0;
	SQLLEN cb_filter_non_cookied_request=0;
	SQLINTEGER s_use_pmp_enabled = 0;
	SQLLEN cb_s_use_pmp_enabled = 0;
 	SQLINTEGER s_use_secure_params = 0;
	SQLLEN cb_s_use_secure_params = 0;
	SQLINTEGER s_use_mobile_params = 0;
	SQLLEN cb_s_use_mobile_params = 0;
	SQLINTEGER s_use_geo_params = 0;
	SQLLEN cb_s_use_geo_params = 0;
	SQLINTEGER s_bid_price_encryption_enabled = 0;
	SQLLEN cb_s_bid_price_encryption_enabled = 0;
	SQLINTEGER s_second_price_encryption_enabled = 0;
	SQLLEN cb_s_second_price_encryption_enabled = 0;
	SQLINTEGER s_click_tracking_url_encoding_enabled = 0;
	SQLLEN cb_s_click_tracking_url_encoding_enabled = 0;
	SQLINTEGER s_pass_blank_click_tracking_url = 0;
	SQLLEN cb_s_pass_blank_click_tracking_url = 0;
	SQLINTEGER s_skip_user_floor = 0;
	SQLLEN cb_skip_user_floor = 0;
	SQLINTEGER s_apply_normal_distribution = 0;
	SQLLEN cb_apply_normal_distribution = 0;
	SQLINTEGER s_deal_id_passing_enable_flag = 0;
	SQLLEN cb_s_deal_id_passing_enable_flag = 0;
	SQLINTEGER s_buyer_id_passing_enable_flag = 0;
	SQLLEN cb_s_buyer_id_passing_enable_flag = 0;
	SQLINTEGER s_supress_second_price_auction_on_same_campaign = 0;
	SQLLEN cb_supress_second_price_auction_on_same_campaign = 0;
	SQLINTEGER s_is_multibid = 0;
	SQLLEN cb_is_multibid = 0;
	SQLINTEGER s_send_secure_inventory = 0;
	SQLLEN cb_s_send_secure_inventory = 0;
	SQLINTEGER s_price_floor = 0;
	SQLLEN cb_s_price_floor = 0;
	SQLINTEGER s_use_adtruth_id = 0;
	SQLLEN cb_s_use_adtruth_id = 0;
	SQLINTEGER s_use_video_params =0;
	SQLLEN cb_use_video_params =0;
	SQLINTEGER s_protocol = 0;
	SQLLEN cb_protocol = 0;
	SQLINTEGER s_vertical_id = 0;
	SQLLEN cb_s_vertical_id = 0;
	SQLDOUBLE s_minimum_clearing_price_margin = 0.0;
	SQLLEN cb_s_minimum_clearing_price_margin = 0;
	SQLINTEGER s_filter_cookied_request = 0;
	SQLLEN cb_s_filter_cookied_request = 0;
	SQLINTEGER s_send_winloss_info = 0;
        SQLLEN cb_s_send_winloss_info = 0;
	SQLINTEGER s_use_creative_attributes;
	SQLINTEGER s_use_url_blocklist;	
	SQLINTEGER s_use_creative_categories;
	SQLLEN cb_use_creative_attributes=0;
	SQLLEN cb_use_url_blocklist=0;
	SQLLEN cb_use_creative_categories=0;
	SQLINTEGER s_use_rich_media_params;
	SQLLEN cb_s_use_rich_media_params;
	SQLCHAR s_cluster_lb_url[MAX_BIDDER_CLUSTER_URL_SIZE + 1];
	SQLINTEGER s_dsp_config_id;
	SQLLEN cb_s_dsp_config_id = 0;
	SQLINTEGER s_bidder_cluster_id;
	SQLLEN cb_s_bidder_cluster_id = 0;
	SQLLEN cb_s_cluster_lb_url = SQL_NTS;
	SQLINTEGER s_bidder_enabled;
	SQLINTEGER s_bidrequest_compress = 0 ;
	SQLINTEGER s_bidresponse_compress = 0 ;
	SQLLEN cb_bidrequest_compress = 0 ;
	SQLLEN cb_bidresponse_compress = 0 ;
	SQLLEN cb_s_bidder_enabled = 0;
	SQLINTEGER s_supports_native_ad_format = 0;
	SQLLEN cb_s_supports_native_ad_format = 0;
	SQLINTEGER s_share_cookies_of = 0;
	SQLLEN cb_s_share_cookies_of = 0;
	SQLINTEGER s_use_drproxy = 0;
	SQLLEN cb_s_use_drproxy = 0;
	SQLINTEGER s_video_placement_percent = 0;
	SQLLEN cb_s_video_placement_percent = 0;
	SQLINTEGER s_digitrust_retargeting_enabled=0;
	SQLLEN cb_digitrust_retargeting_enabled=0;

	SQLINTEGER s_send_publisher_name = 0;
	SQLLEN cb_s_send_publisher_name = 0;

	SQLINTEGER s_att_bitmap = 0;
	SQLLEN cb_s_att_bitmap = 0;
	SQLINTEGER s_send_hardfloor = 0;
	SQLLEN cb_s_send_hardfloor = 0;
	SQLINTEGER s_use_audio_params =0;
	SQLLEN cb_use_audio_params =0;

	SQLINTEGER s_send_is_dspuid_inferred = 0;
	SQLLEN cb_send_is_dspuid_inferred = 0;

	SQLDOUBLE s_campaign_throttle_percent;
	SQLLEN cb_campaign_throttle_percent = 0;

        SQLINTEGER s_pixel_id = 0;
        SQLLEN cb_pixel_id = 0;

	SQLINTEGER s_server_side_cookie_expiry = 0;
	SQLLEN cb_server_side_cookie_expiry = 0;

	SQLINTEGER s_max_multi_requests = 0;
	SQLLEN cb_max_multi_requests = 0;

	SQLINTEGER s_pass_granular_site_id = 0;
	SQLLEN cb_pass_granular_site_id = 0;
	
	SQLINTEGER s_remove_cookie_prefix_uid = 0;
	SQLLEN cb_remove_cookie_prefix_uid = 0;

	SQLINTEGER s_truncate_refurl_if_nonutf8 = 0;
	SQLLEN cb_truncate_refurl_if_nonutf8 = 0;
	
	SQLINTEGER s_change_native_img_type = 0;
	SQLLEN cb_change_native_img_type = 0;
	
	SQLCHAR s_audience_dpids_in_bid_req[MAX_AUDIENCE_IDS_IN_BID_REQ*20]; // 20 bytes per id + PIPE
	SQLLEN cb_audience_dpids_in_bid_req = SQL_NTS;
	s_audience_dpids_in_bid_req[0] = '\0' ;
	
	int use_count = 0;
	int alloc_count = ACTIVE_RTB_ALLOC_SIZE;
	char query_string[MAX_SQL_QUERY_STR_LEN];

//	strncpy(query_string, GET_RT_NW_INFO, MAX_SQL_QUERY_STR_LEN);
	snprintf((char *) query_string, MAX_SQL_QUERY_STR_LEN, GET_RT_NW_INFO, dbconn->timestamp, dbconn->timestamp);
	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	strcpy((char *) sql_statement, query_string);
	//llog_write(L_DEBUG, "\n Query : %s", query_string);

	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if(sql_retval!=SQL_SUCCESS)
	{
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
					sql_retval,__LINE__,__FILE__ );
		if (retvalue != NULL) {
			free(retvalue);
			retvalue = NULL;
		}
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}


	/* Bind parameters */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_datacenter_id, 0, &cb_s_datacenter_id);
	if(sql_retval!=SQL_SUCCESS)
	{
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
	//llog_write(L_DEBUG, "%s: %d\n", __FILE__, __LINE__);
		return DB_ERROR_INTERNAL;
	}
	//Assigning the datacenter id to s_datacenter_id
	s_datacenter_id = g_datacenter_id;

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);
	//llog_write(L_DEBUG,"\n After execute");
	// If The SQL Statement Executed Successfully, Retrieve
	// The Results
	if (sql_retval == SQL_SUCCESS)
	{
		//llog_write(L_DEBUG, "\n in bindcol block");
		//sagar
		SQLBindCol(statement_handle, 1, SQL_C_CHAR, &s_cluster_lb_url,
		                MAX_BIDDER_CLUSTER_URL_SIZE, &cb_s_cluster_lb_url);
		SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_bidder_cluster_id,
				0, &cb_s_bidder_cluster_id);
		SQLBindCol(statement_handle, 3, SQL_C_ULONG, &s_dsp_config_id,
				0, &cb_s_dsp_config_id);
		SQLBindCol(statement_handle, 4, SQL_C_ULONG, &s_bidder_enabled,
				0, &cb_s_bidder_enabled);
		SQLBindCol(statement_handle, 5, SQL_C_ULONG, &s_timezone,
				0, &cb_s_timezone);
		SQLBindCol(statement_handle, 6, SQL_C_ULONG, &s_user_ip,
				0, &cb_s_user_ip);
		SQLBindCol(statement_handle, 7, SQL_C_ULONG, &s_catagory,
				0, &cb_s_catagory);
		SQLBindCol(statement_handle, 8, SQL_C_ULONG, &s_keyword,
				0, &cb_s_keyword);
		SQLBindCol(statement_handle, 9, SQL_C_ULONG, &s_ref_url,
                                0, &cb_s_ref_url);
		SQLBindCol(statement_handle, 10, SQL_C_ULONG, &s_user_id,
                                0, &cb_s_user_id);
		SQLBindCol(statement_handle, 11, SQL_C_ULONG, &s_cookie,
                                0, &cb_s_cookie);	
		SQLBindCol(statement_handle, 12, SQL_C_ULONG, &s_frequency,
                                0, &cb_s_frequency);
		SQLBindCol(statement_handle, 13, SQL_C_ULONG, &s_adtagtype,
                                0, &cb_adtagtype);
		SQLBindCol(statement_handle, 14, SQL_C_ULONG, &s_browser,
                                0, &cb_s_browser);
		SQLBindCol(statement_handle, 15, SQL_C_ULONG, &s_language,
                                0, &cb_s_language);
		SQLBindCol(statement_handle, 16, SQL_C_ULONG, &s_screen_resolution,
                                0, &cb_s_screen_resolution);
		SQLBindCol(statement_handle, 17, SQL_C_ULONG, &s_ad_position,
                                0, &cb_s_ad_position);
		SQLBindCol(statement_handle, 18, SQL_C_CHAR, &s_clicktrack_keyword,
                                MAX_RTB_CLICKTRACK_KEYWORD_LEN, &cb_s_clicktrack_keyword);	
		SQLBindCol(statement_handle, 19, SQL_C_ULONG, &s_ret_campaign_id,
                		0, &cb_s_ret_campaign_id);
		SQLBindCol(statement_handle, 20, SQL_C_ULONG, &s_second_price_auction,
                                0, &cb_s_second_price_auction);
		SQLBindCol(statement_handle, 21, SQL_C_CHAR, &s_second_price_macro,
                                MAX_SECOND_PRICE_MACRO_SIZE, &cb_s_second_price_macro);
		SQLBindCol(statement_handle, 22, SQL_C_DOUBLE, &s_second_price_margin,
		                0, &cb_s_second_price_margin);
		SQLBindCol(statement_handle, 23, SQL_C_ULONG, &s_adid,
                                0, &cb_s_adid);
		SQLBindCol(statement_handle, 24, SQL_C_ULONG, &s_use_in_iframe,
                                0, &cb_s_use_in_iframe);
		SQLBindCol(statement_handle, 25, SQL_C_ULONG, &s_pubId,
                                0, &cb_s_pubId);
		SQLBindCol(statement_handle, 26, SQL_C_ULONG, &s_siteId,
                                0, &cb_s_siteId);
		SQLBindCol(statement_handle, 27, SQL_C_ULONG, &s_fold_position,
                                0, &cb_s_fold_position);
		SQLBindCol(statement_handle, 28, SQL_C_ULONG, &s_use_creative_attributes,
                                0, &cb_use_creative_attributes);
		SQLBindCol(statement_handle, 29, SQL_C_ULONG, &s_use_url_blocklist,
                                0, &cb_use_url_blocklist);
		SQLBindCol(statement_handle, 30, SQL_C_ULONG, &s_use_creative_categories,
                                0, &cb_use_creative_categories);
		SQLBindCol(statement_handle, 31, SQL_C_ULONG, &s_use_optout,
                                0, &cb_s_use_optout);
		SQLBindCol(statement_handle, 32, SQL_C_ULONG, &s_filter_defaulted_request,
                                0, &cb_filter_defaulted_request);
		SQLBindCol(statement_handle, 33, SQL_C_ULONG, &s_filter_non_cookied_request,
                                0, &cb_filter_non_cookied_request);
		SQLBindCol(statement_handle, 34, SQL_C_ULONG, &s_use_pmp_enabled,
                                0, &cb_s_use_pmp_enabled);
		SQLBindCol(statement_handle, 35, SQL_C_CHAR, &s_ad_nw_url,
                                MAX_RTB_URL_SIZE, &cb_s_ad_nw_url);
		SQLBindCol(statement_handle, 36, SQL_C_ULONG, &s_use_secure_params,
                                0, &cb_s_use_secure_params);
		SQLBindCol(statement_handle, 37, SQL_C_ULONG, &s_use_rich_media_params,
                                0, &cb_s_use_rich_media_params);
		SQLBindCol(statement_handle, 38, SQL_C_ULONG, &s_use_mobile_params,
				0, &cb_s_use_mobile_params);
		SQLBindCol(statement_handle, 39, SQL_C_ULONG, &s_use_geo_params,
				0, &cb_s_use_geo_params);
		SQLBindCol(statement_handle, 40, SQL_C_ULONG, &s_bid_price_encryption_enabled,
				0, &cb_s_bid_price_encryption_enabled);
		SQLBindCol(statement_handle, 41, SQL_C_ULONG, &s_second_price_encryption_enabled,
				0, &cb_s_second_price_encryption_enabled);
		SQLBindCol(statement_handle, 42, SQL_C_ULONG, &s_click_tracking_url_encoding_enabled,
				0, &cb_s_click_tracking_url_encoding_enabled);
		SQLBindCol(statement_handle, 43, SQL_C_ULONG, &s_skip_user_floor,
				0, &cb_skip_user_floor);
		SQLBindCol(statement_handle, 44, SQL_C_ULONG, &s_apply_normal_distribution,
				0, &cb_apply_normal_distribution);
		SQLBindCol(statement_handle, 45, SQL_C_ULONG, &s_deal_id_passing_enable_flag,
				0, &cb_s_deal_id_passing_enable_flag);
		SQLBindCol(statement_handle, 46, SQL_C_ULONG, &s_buyer_id_passing_enable_flag,
				0, &cb_s_buyer_id_passing_enable_flag);
		SQLBindCol(statement_handle, 47, SQL_C_ULONG, &s_pass_blank_click_tracking_url,
				0, &cb_s_pass_blank_click_tracking_url);

		SQLBindCol(statement_handle, 48, SQL_C_ULONG, &s_send_secure_inventory, 0, &cb_s_send_secure_inventory);
		SQLBindCol(statement_handle, 49, SQL_C_ULONG, &s_supress_second_price_auction_on_same_campaign, 0, &cb_supress_second_price_auction_on_same_campaign);
		SQLBindCol(statement_handle, 50, SQL_C_ULONG, &s_is_multibid, 0, &cb_is_multibid);
    		SQLBindCol(statement_handle, 51, SQL_C_ULONG, &s_price_floor, 0, &cb_s_price_floor);
		SQLBindCol(statement_handle, 52, SQL_C_ULONG, &s_use_adtruth_id, 0, &cb_s_use_adtruth_id);
		SQLBindCol(statement_handle, 53, SQL_C_ULONG, &s_use_video_params, 0, &cb_use_video_params);
		SQLBindCol(statement_handle, 54, SQL_C_ULONG, &s_protocol, 0, &cb_protocol);
		SQLBindCol(statement_handle, 55, SQL_C_ULONG, &s_vertical_id, 0, &cb_s_vertical_id);
		SQLBindCol(statement_handle, 56, SQL_C_DOUBLE, &s_minimum_clearing_price_margin, 0, &cb_s_minimum_clearing_price_margin);
		SQLBindCol(statement_handle, 57, SQL_C_ULONG, &s_filter_cookied_request, 0, &cb_s_filter_cookied_request);
		SQLBindCol(statement_handle, 58, SQL_C_ULONG, &s_send_winloss_info, 0, &cb_s_send_winloss_info);	
		SQLBindCol(statement_handle, 59, SQL_C_ULONG, &s_supports_native_ad_format, 0, &cb_s_supports_native_ad_format);
		SQLBindCol(statement_handle, 60, SQL_C_ULONG, &s_share_cookies_of, 0, &cb_s_share_cookies_of);
		SQLBindCol(statement_handle, 61, SQL_C_ULONG, &s_use_drproxy, 0, &cb_s_use_drproxy);
		SQLBindCol(statement_handle, 62, SQL_C_ULONG, &s_send_hardfloor, 0,	&cb_s_send_hardfloor);
		SQLBindCol(statement_handle, 63, SQL_C_ULONG, &s_use_audio_params, 0, &cb_use_audio_params);
		SQLBindCol(statement_handle, 64, SQL_C_ULONG, &s_send_is_dspuid_inferred, 0, &cb_send_is_dspuid_inferred);
		SQLBindCol(statement_handle, 65, SQL_C_DOUBLE, &s_campaign_throttle_percent,
		                0, &cb_campaign_throttle_percent);
		SQLBindCol(statement_handle, 66, SQL_C_ULONG, &s_pixel_id,
                                0, &cb_pixel_id);
		SQLBindCol(statement_handle, 67, SQL_C_ULONG, &s_server_side_cookie_expiry, 0, &cb_server_side_cookie_expiry);
		SQLBindCol(statement_handle, 68, SQL_C_ULONG, &s_max_multi_requests, 0, &cb_max_multi_requests);
		SQLBindCol(statement_handle, 69, SQL_C_ULONG, &s_att_bitmap, 0, &cb_s_att_bitmap);
		SQLBindCol(statement_handle, 70, SQL_C_ULONG, &s_pass_granular_site_id, 0, &cb_pass_granular_site_id);
		SQLBindCol(statement_handle, 71, SQL_C_ULONG, &s_change_native_img_type, 0, &cb_change_native_img_type);
		SQLBindCol(statement_handle, 72, SQL_C_ULONG, &s_bidrequest_compress, 0, &cb_bidrequest_compress);
		SQLBindCol(statement_handle, 73, SQL_C_ULONG, &s_bidresponse_compress, 0, &cb_bidresponse_compress);
		SQLBindCol(statement_handle, 74, SQL_C_ULONG, &s_video_placement_percent, 0, &cb_s_video_placement_percent);
		SQLBindCol(statement_handle, 75, SQL_C_ULONG, &s_send_publisher_name, 0, &cb_s_send_publisher_name);
		SQLBindCol(statement_handle, 76, SQL_C_ULONG, &s_digitrust_retargeting_enabled, 0, &cb_digitrust_retargeting_enabled);
		SQLBindCol(statement_handle, 77, SQL_C_ULONG, &s_remove_cookie_prefix_uid, 0, &cb_remove_cookie_prefix_uid);
		SQLBindCol(statement_handle, 78, SQL_C_ULONG, &s_truncate_refurl_if_nonutf8, 0, &cb_truncate_refurl_if_nonutf8);
		SQLBindCol(statement_handle, 79, SQL_C_CHAR, &s_audience_dpids_in_bid_req, sizeof(s_audience_dpids_in_bid_req), &cb_audience_dpids_in_bid_req);
		
		// While There Are Records In The Result Data Set
		// Produced, Retrieve And Display Them

		retvalue = (rt_request_url_params_mask_t *) malloc ((sizeof(rt_request_url_params_mask_t) * ACTIVE_RTB_ALLOC_SIZE));	
		while (sql_retval != SQL_NO_DATA)
		{
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {

				const int PROXY_USE_OFF     = 0;
				const int PROXY_USE_DRPROXY = 1;
				const int PROXY_USE_GOPRO   = 2;
				char *saveptr = NULL ;
				uint32_t i_dpid = 0 ;
				char *token = NULL ;
				char delim = '|' ;
				// Ensure that drproxy is disabled on all DCs where drproxy VIP is not there
				int use_drproxy = 
					PROXY_USE_DRPROXY == s_use_drproxy &&
					5 <= strlen(g_drproxy_url);
				use_drproxy = use_drproxy ? 1 : 0;

				// https URLs force enables use_gopro
				int use_gopro =
					 (PROXY_USE_OFF == s_use_drproxy &&
					 0 == strncmp((char*)s_ad_nw_url, "https", 5)) ||
					 PROXY_USE_GOPRO == s_use_drproxy;
				use_gopro =
					use_gopro &&
					5 <= strlen(g_gopro_url);
				use_gopro = use_gopro ? 1 : 0;

				int https_supported = (1 == use_drproxy || 1 == use_gopro) ? 1 : 0;
				if (0 == strncmp((char*)s_ad_nw_url, "https", 5) && 0 == https_supported) {
					LOG_FATAL(DSP_URL_CONTAINING_HTTPS,MOD_DEFAULT,s_ad_nw_url);
					continue;
				}

               	if (use_count == alloc_count) {
               		alloc_count++;
               		tmp_retvalue = realloc(retvalue, sizeof(rt_request_url_params_mask_t) * alloc_count);
               		if (tmp_retvalue == NULL) {
               			if (retvalue != NULL) {
               				free(retvalue);
               				retvalue = NULL;
               			}
               // Free The SQL Statement Handle
               			if (statement_handle != 0) {
               				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
               			}
           				return DB_ERROR_NO_MEMORY;
          			}
               		retvalue = tmp_retvalue;
       			}
				
					retvalue[use_count].feature_flag_bitmap = 0; //initialize first then keep orring binary features
					strncpy(retvalue[use_count].cluster_lb_url, (char *)s_cluster_lb_url, MAX_BIDDER_CLUSTER_URL_SIZE);
					retvalue[use_count].dsp_config_id = s_dsp_config_id;
					retvalue[use_count].bidder_cluster_id = s_bidder_cluster_id;
					retvalue[use_count].bidder_enabled = s_bidder_enabled;
					retvalue[use_count].bidrequest_compress = s_bidrequest_compress ;
					retvalue[use_count].bidresponse_compress = s_bidresponse_compress ;

					retvalue[use_count].audience_dpids_in_bid_req_count = 0 ;
					token = strtok_r( (char*)s_audience_dpids_in_bid_req, &delim, &saveptr ) ;

					for( i_dpid = 0 ; token != NULL && i_dpid < MAX_AUDIENCE_IDS_IN_BID_REQ ; i_dpid++ ) {
						retvalue[use_count].audience_dpids_in_bid_req[i_dpid] = (uint32_t)atoi(token ) ;
						retvalue[use_count].audience_dpids_in_bid_req_count++ ;
						token = strtok_r( NULL, &delim, &saveptr ) ;
					}

				
					 strncpy(retvalue[use_count].ad_nw_url, (char *)s_ad_nw_url, MAX_RTB_URL_SIZE);
					//llog_write(L_DEBUG,"\n >>> AdNw %ld URL from db: %s", s_ret_campaign_id, retvalue[use_count].ad_nw_url);
					retvalue[use_count].pub_url = s_pub_url; 
					retvalue[use_count].timezone = s_timezone;
					retvalue[use_count].user_ip = s_user_ip;
					retvalue[use_count].catagory = s_catagory;
					//retvalue[use_count].keyword = s_keyword;
					retvalue[use_count].ref_url = s_ref_url;
					retvalue[use_count].user_id = s_user_id;
					retvalue[use_count].cookie = s_cookie;
					retvalue[use_count].browser = s_browser;
					retvalue[use_count].language = s_language;
					retvalue[use_count].screen_resolution = s_screen_resolution;
					retvalue[use_count].ad_position = s_ad_position;
					retvalue[use_count].frequency = s_frequency;
					retvalue[use_count].adtagtype = s_adtagtype;
					retvalue[use_count].second_price_auction = s_second_price_auction; 
					strncpy(retvalue[use_count].second_price_macro, (char *)s_second_price_macro, MAX_SECOND_PRICE_MACRO_SIZE);
					strncpy(retvalue[use_count].clicktrack_keyword, (char *)s_clicktrack_keyword, MAX_RTB_CLICKTRACK_KEYWORD_LEN);
					retvalue[use_count].second_price_margin = s_second_price_margin;
					retvalue[use_count].campaign_id = s_ret_campaign_id;
					retvalue[use_count].adid = s_adid;
					retvalue[use_count].use_in_iframe = s_use_in_iframe;
					retvalue[use_count].siteId = s_siteId;
					retvalue[use_count].pubId = s_pubId;
					retvalue[use_count].fold_position = s_fold_position;
					retvalue[use_count].use_pmp_enabled = s_use_pmp_enabled;
					retvalue[use_count].use_secure_params = s_use_secure_params;
					retvalue[use_count].use_mobile_params = s_use_mobile_params;
					retvalue[use_count].use_geo_params = s_use_geo_params;
					retvalue[use_count].bid_price_encryption_enabled = s_bid_price_encryption_enabled;
					retvalue[use_count].second_price_encryption_enabled = s_second_price_encryption_enabled;
					retvalue[use_count].click_tracking_url_encoding_enabled = s_click_tracking_url_encoding_enabled;
					retvalue[use_count].pass_blank_click_tracking_url = s_pass_blank_click_tracking_url;
					retvalue[use_count].skip_user_floor = s_skip_user_floor;
					retvalue[use_count].apply_normal_distribution = s_apply_normal_distribution;
					retvalue[use_count].deal_id_passing_enable_flag = s_deal_id_passing_enable_flag;
					retvalue[use_count].buyer_id_passing_enable_flag = s_buyer_id_passing_enable_flag;
					retvalue[use_count].send_secure_inventory = s_send_secure_inventory;
					retvalue[use_count].supress_second_price_auction_on_same_campaign = s_supress_second_price_auction_on_same_campaign;
					retvalue[use_count].is_multibid = s_is_multibid;
          				retvalue[use_count].use_price_floor = s_price_floor;
					retvalue[use_count].use_adtruth_id = s_use_adtruth_id;
					retvalue[use_count].send_video_params = s_use_video_params;
					retvalue[use_count].protocol = s_protocol;
					retvalue[use_count].use_vertical_id = s_vertical_id;
					retvalue[use_count].minimum_clearing_price_margin = s_minimum_clearing_price_margin;
					retvalue[use_count].filter_cookied_request = s_filter_cookied_request;
					retvalue[use_count].send_winloss_info = s_send_winloss_info;
					retvalue[use_count].enabled_ias_services = 0; //will be set later
					retvalue[use_count].share_cookies_of = s_share_cookies_of;
					retvalue[use_count].use_drproxy = use_drproxy;
					// use_gopro is NOT present in the DB.  It is derived as above.
					retvalue[use_count].use_gopro = use_gopro;
					retvalue[use_count].send_hardfloor = s_send_hardfloor;
					retvalue[use_count].use_audio_params = s_use_audio_params;
					retvalue[use_count].send_is_dspuid_inferred = s_send_is_dspuid_inferred;

                                        retvalue[use_count].campaign_throttle_percent =
                                                s_campaign_throttle_percent >= 0 ?
                                                s_campaign_throttle_percent : 0;

					if(cb_use_creative_attributes!=SQL_NULL_DATA) {
						retvalue[use_count].use_creative_attributes = s_use_creative_attributes;
					} else {
						retvalue[use_count].use_creative_attributes = 0;
					}
					if(cb_use_url_blocklist!=SQL_NULL_DATA) {
						retvalue[use_count].use_url_blocklist = s_use_url_blocklist;
					} else {
						retvalue[use_count].use_url_blocklist = 0;
					}
					if(cb_use_creative_categories!=SQL_NULL_DATA) {
						retvalue[use_count].use_creative_categories = s_use_creative_categories;
					} else {
						retvalue[use_count].use_creative_categories = 0;
					}
					if(cb_s_use_optout!= SQL_NULL_DATA) {
						retvalue[use_count].use_pmoptout = s_use_optout;
					} else {
						retvalue[use_count].use_pmoptout = 0;
					}
					if(cb_filter_defaulted_request != SQL_NULL_DATA) {
						retvalue[use_count].filter_defaulted_request = s_filter_defaulted_request;
					} else {
						retvalue[use_count].filter_defaulted_request = 0;
					}
					if(cb_filter_non_cookied_request != SQL_NULL_DATA) {
						retvalue[use_count].filter_non_cookied_request = s_filter_non_cookied_request;
					} else {
						retvalue[use_count].filter_non_cookied_request = 0;
					}
					if(cb_pixel_id != SQL_NULL_DATA) {
                                                // Allowing the possiblity of negative pixel_id
						retvalue[use_count].pixel_id = s_pixel_id;
					} else {
						retvalue[use_count].pixel_id = 0;
					}
					if (s_video_placement_percent >= 0 && s_video_placement_percent <= 100){
						retvalue[use_count].video_placement_percent = s_video_placement_percent;
					}
					
					retvalue[use_count].send_publisher_name = s_send_publisher_name;

					if(cb_digitrust_retargeting_enabled != SQL_NULL_DATA) {
						retvalue[use_count].digitrust_retargeting_enabled = (1 == s_digitrust_retargeting_enabled) ? 1 : 0;
					} else {
						retvalue[use_count].digitrust_retargeting_enabled = 0;
					}
					
					retvalue[use_count].server_side_cookie_expiry = s_server_side_cookie_expiry;
					retvalue[use_count].max_multi_requests = s_max_multi_requests;
					retvalue[use_count].use_rich_media_params = s_use_rich_media_params;
					retvalue[use_count].supports_native_ad_format = s_supports_native_ad_format;
					retvalue[use_count].att_bitmap = s_att_bitmap;
					if (s_pass_granular_site_id) {
						retvalue[use_count].feature_flag_bitmap |= (1 << CS_BIT_POS_RTB_PASS_GRANULAR_SITE_ID);
					}

					if (s_change_native_img_type) {
						retvalue[use_count].feature_flag_bitmap |= (1 << CS_BIT_POS_RTB_CHANGE_NATIVE_IMAGE_TYPE);
					}
					if (s_remove_cookie_prefix_uid) {
						retvalue[use_count].feature_flag_bitmap |= (1 << CS_BIT_POS_RTB_REMOVE_COOKIE_PREFIX_UID);
					}
					if (1 == s_truncate_refurl_if_nonutf8) {
						retvalue[use_count].feature_flag_bitmap |= (1 << CS_BIT_POS_RTB_TRUNCATE_REFURL_IF_NONUTF8);
					}
					use_count++;
				}
			}
		} else {
			llog_write(L_DEBUG, "Error executing select statement:\n");
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
			if (retvalue != NULL) {
				free(retvalue);
				retvalue = NULL;
			}
		// Free The SQL Statement Handle
			if (statement_handle != 0) {
				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			}
		return DB_ERROR_INTERNAL;
		}

	if(use_count == 0){
		if(retvalue!= NULL){
			free(retvalue);
			retvalue=NULL;
		}
	}	
	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	(*ret_elements) = use_count;
	(*rt_request_url_params_mask) = retvalue;
	return DB_ERROR_SUCCESS;
}

int get_rt_campaign_config_modification_time(
        unsigned int * mod_time,
        const db_connection_t * const dbconn
) {
        if (mod_time == NULL || dbconn == NULL) {
                llog_write(L_DEBUG, "ERROR: invalid args  %s:%d\n", __FILE__, __LINE__);
                return DB_ERROR_INVALID_ARGS;
        }

        char * query = 
        "select UNIX_TIMESTAMP(max(modification_time)) as modification_time from (( "
                "(select max(modification_time) as modification_time from realtime_api_config) union "
                "(select max(modification_time) as modification_time from campaign) union "
                "(select max(modification_time) as modification_time from realtime_campaign_config) union "
                "(select max(modification_time) as modification_time from bidder_dsp_config) union "
                "(select max(modification_time) as modification_time from bidder_cluster_config) "
        ") as A)";

        SQLRETURN rv = 0;
        SQLHANDLE stmt = 0;

        rv = SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &stmt);
        if (!SQL_SUCCEEDED(rv)) {
                llog_write(L_DEBUG, "ERROR: allocating SQL stmt handle rv=%d  %s:%d\n", rv, __FILE__, __LINE__);
                rv = DB_ERROR_INTERNAL;
                goto get_rt_campaign_config_modification_time_end;
        }

        rv = SQLExecDirect(stmt, (SQLCHAR *)query, SQL_NTS);
        if (!SQL_SUCCEEDED(rv)) {
                llog_write(L_DEBUG, "ERROR: executing query:%s rv=%d  %s:%d\n", query, rv, __FILE__, __LINE__);
                rv = DB_ERROR_INTERNAL;
                goto get_rt_campaign_config_modification_time_end;
        }

        rv = SQLFetch(stmt);
        if (!SQL_SUCCEEDED(rv)) {
                llog_write(L_DEBUG, "ERROR: fetching query rv=%d  %s:%d\n", rv, __FILE__, __LINE__);
                rv = DB_ERROR_INTERNAL;
                goto get_rt_campaign_config_modification_time_end;
        }

        rv = SQLGetData(stmt, 1, SQL_C_ULONG, mod_time, 0, NULL);
        if (!SQL_SUCCEEDED(rv)) {
                llog_write(L_DEBUG, "ERROR: getting data from DB rv=%d  %s:%d\n", rv, __FILE__, __LINE__);
                rv = DB_ERROR_INTERNAL;
                goto get_rt_campaign_config_modification_time_end;
        }

get_rt_campaign_config_modification_time_end:
        if (stmt == 0) {
                SQLFreeHandle(SQL_HANDLE_STMT, stmt);
        }
        return rv;
}


void print_rt_request_url_params_mask(
        const rt_request_url_params_mask_t * const m,
        int len
) {
        if (m == NULL) {
                return;
        }

        int i = 0;
        for (i = 0; i < len; i++) {
                llog_write(L_DEBUG, "#%d:%d,%d,%d,%ld\n",
                                i,
                                m[i].pubId,
                                m[i].siteId,
                                m[i].adid,
                                m[i].campaign_id);

                if (i == 5) {
                        llog_write(L_DEBUG, "...\n");
                        i = len - 5;
                }
        }
}


#define GET_SITE_CAMP_SECOND_PRICE_MARGIN_MAP \
	"select site_id, campaign_id, second_price_margin from site_camp_second_price_settings order by 1, 2 limit 50000"

#define SITE_CAMP_SECOND_PRICE_MARGIN_MAP_LEN 127 
#define SITE_CAMP_SECOND_PRICE_MARGIN_ALLOC_SIZE 50

int get_site_camp_sp_margin(site_camp_sp_margin_map_t **site_camp_sp_margin_map, db_connection_t *dbconn,  int *element_count ) {
	site_camp_sp_margin_map_t *retvalue=NULL;	
	site_camp_sp_margin_map_t *tmp_retvalue=NULL;
	*element_count = 0;
	*site_camp_sp_margin_map = 0;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[SITE_CAMP_SECOND_PRICE_MARGIN_MAP_LEN + 1];
	SQLINTEGER s_campaign_id = 0;
	SQLLEN cb_campaign_id = 0;
	SQLDOUBLE s_second_price_margin = 0;
	SQLLEN cb_second_price_margin = 0;
	SQLINTEGER s_site_id=0;
	SQLLEN cb_site_id=0;

	int use_count = 0;
	snprintf((char *) sql_statement, SITE_CAMP_SECOND_PRICE_MARGIN_MAP_LEN, "%s", GET_SITE_CAMP_SECOND_PRICE_MARGIN_MAP);
	sql_statement[SITE_CAMP_SECOND_PRICE_MARGIN_MAP_LEN] = '\0';
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if(sql_retval!=SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}

	sql_retval = SQLExecute(statement_handle);
	if (sql_retval == SQL_SUCCESS) {
		SQLBindCol(statement_handle, 1, SQL_C_LONG, &s_site_id, 0, &cb_site_id);
		SQLBindCol(statement_handle, 2, SQL_C_LONG, &s_campaign_id, 0, &cb_campaign_id);
		SQLBindCol(statement_handle, 3, SQL_C_DOUBLE, &s_second_price_margin, 0, &cb_second_price_margin);
		int alloc_count = SITE_CAMP_SECOND_PRICE_MARGIN_ALLOC_SIZE;
		retvalue = (site_camp_sp_margin_map_t *) malloc ((sizeof(site_camp_sp_margin_map_t) * alloc_count));	
		while (sql_retval != SQL_NO_DATA) {
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {
				if (use_count == alloc_count) {
					alloc_count <<= 1;
					tmp_retvalue = realloc(retvalue, sizeof(site_camp_sp_margin_map_t) * alloc_count);
					if (tmp_retvalue == NULL) {
						if (retvalue != NULL) {
							free(retvalue);
							retvalue = NULL;
						}
						if (statement_handle != 0) {
							SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
						}
						return DB_ERROR_NO_MEMORY;
					}
					retvalue = tmp_retvalue;
				}	
				retvalue[use_count].site_id = s_site_id;
				retvalue[use_count].campaign_id = s_campaign_id;
				retvalue[use_count].second_price_margin = s_second_price_margin;
				use_count++;
			}
		}
	} 
	else {
		llog_write(L_DEBUG, "Error executing select statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
			sql_retval,__LINE__,__FILE__ );
		if (retvalue != NULL) {
			free(retvalue);
			retvalue = NULL;
		}
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}

	if(use_count == 0){
		if(retvalue!= NULL){
			free(retvalue);
			retvalue=NULL;
		}
	}	
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	(*element_count) = use_count;
	(*site_camp_sp_margin_map) = retvalue;
	llog_write(L_DEBUG, "L:GetSiteCampSPMap:Count:%d\n", use_count);
	if (use_count == 0) {
		return DB_ERROR_NOT_FOUND;
	}
	//log("test");
	return DB_ERROR_SUCCESS;
}
