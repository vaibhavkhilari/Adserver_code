/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "db_connection.h"
#include "cache_publisher_site_iframe_buster_tech.h"
#include "db_publisher_site_iframe_buster_tech.h"
#include "rt_types.h"
#include "db_error.h"
#include "db_constants.h"
#include "error.h"

#define GET_IFRAME_BUSTER_TECH_LIST                                                   \
    " (SELECT json_richmedia_supported_technologies, 1                                \
       FROM rich_media_site_psf_status                                                \
       WHERE pub_id = ? AND site_id = ? AND LOWER(url) = ?)                           \
      UNION                                                                           \
      (SELECT json_richmedia_supported_technologies, 0                                \
      FROM rich_media_site_psf_status                                                 \
      WHERE pub_id = ? AND site_id = ?)"

/*
 * From DB get the list of iFrame buster technologies in JSON form that
 * Publisher has installed on his site.
 *
 * On Success: From pub_site_rich_media_params set json_available_iframe_buster_tech_list to the list
 *             return by DB & Save it's length in json_available_iframe_buster_tech_list_len.
 *
 * On Failure: From pub_site_rich_media_params set json_available_iframe_buster_tech_list to empty
 *             string & Save it's length (zero) in json_available_iframe_buster_tech_list_len.
 */
int get_publisher_site_iframe_buster_tech_list(long pub_id,
                                               long site_id,
                                               db_connection_t* dbconn,
                                               ad_server_additional_params_t *additional_parameters,
                                               publisher_site_ad_rich_media_params_t *pub_site_rich_media_params)
{
	int record_found = 0;
	memcached_publisher_site_iframe_buster_tech_t *psf_tech_list = NULL;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
 	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	//Parameters:-
	SQLINTEGER s_pub_id;
	SQLINTEGER s_site_id;
	//SQLINTEGER s_pub_id_2;
	//SQLINTEGER s_site_id_2;
	char s_site_domain[MAX_DOMAIN_NAME_LENGTH + 1];
	//Column
	char s_iframe_buster_tech_list[MAX_AVAILABLE_IFRAME_BUSTER_TECH_LIST_LEN + 1];
	SQLLEN cb_s_iframe_buster_tech_list;
	SQLINTEGER s_is_runtime_verified;
	SQLLEN cb_s_is_runtime_verified;

	/* Initialized Rich Media related params. */
	pub_site_rich_media_params->psf_tech_list = psf_tech_list = (memcached_publisher_site_iframe_buster_tech_t *)
									malloc(sizeof (memcached_publisher_site_iframe_buster_tech_t));
	if (psf_tech_list == NULL)
	{
		llog_write(L_DEBUG, "%s(): Not able to allocate memory for iFrame Buster tech list.\n",
				__FUNCTION__);
		return DB_ERROR_NO_MEMORY;
	}
	psf_tech_list->json_available_iframe_buster_tech_list[0] = '\0';
	psf_tech_list->json_available_iframe_buster_tech_list_len = 0;
	psf_tech_list->is_runtime_verified = -1;

	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);
	// Create SQL char string which contains the query
	strncpy((char *) sql_statement, GET_IFRAME_BUSTER_TECH_LIST, MAX_SQL_QUERY_STR_LEN);
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';// copy the NUL character in case of buffer overflow

	// Create a prepared statement
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS)
	{
		llog_write(L_DEBUG, "ERROR Preparing statement and error code = %d %s:%d\n",
				sql_retval,
				__FILE__,
				__LINE__);
		db_conn_print_error((SQLSMALLINT) SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__);
		// Free The SQL Statement Handl
		if (statement_handle != 0)
		{
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		free(psf_tech_list);
		pub_site_rich_media_params->psf_tech_list = NULL;
		return DB_ERROR_INTERNAL;
	}

	// Bind parameters
	sql_retval = SQLBindParameter(
				statement_handle,
				1,
				SQL_PARAM_INPUT,
				SQL_C_ULONG,
				SQL_INTEGER,
				0,
				0,
				&s_pub_id,
				0,
				NULL);
	if (sql_retval != SQL_SUCCESS)
	{
		llog_write(L_DEBUG, "ERROR SQLBindParameter() failed with return code = %d %s:%d\n",
				sql_retval,
				__FILE__,
				__LINE__);
		db_conn_print_error(
			(SQLSMALLINT) SQL_HANDLE_STMT,
			statement_handle,
			sql_retval,
			__LINE__,
			__FILE__);
		// Free The SQL Statement Handle
		if (statement_handle != 0)
		{
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}

		free(psf_tech_list);
		pub_site_rich_media_params->psf_tech_list = NULL;
		return DB_ERROR_INTERNAL;
	}
	s_pub_id = pub_id;

	sql_retval = SQLBindParameter(
			statement_handle,
			2,
			SQL_PARAM_INPUT,
			SQL_C_ULONG,
			SQL_INTEGER,
			0,
			0,
			&s_site_id,
			0,
			NULL);
	if (sql_retval != SQL_SUCCESS)
	{
		llog_write(L_DEBUG, "ERROR SQLBindParameter() failed with return code = %d %s:%d\n",
				sql_retval,
				__FILE__,
				__LINE__);
		db_conn_print_error((
			SQLSMALLINT) SQL_HANDLE_STMT,
			statement_handle,
			sql_retval,
			__LINE__,
			__FILE__ );
		if (statement_handle != 0)
		{
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}

		free(psf_tech_list);
		pub_site_rich_media_params->psf_tech_list = NULL;
		return DB_ERROR_INTERNAL;
	}
	s_site_id = site_id;

	sql_retval = SQLBindParameter(
			statement_handle,
			3,
			SQL_PARAM_INPUT,
			SQL_C_CHAR,
			SQL_CHAR,
			MAX_DOMAIN_NAME_LENGTH,
			0,
			s_site_domain,
			MAX_DOMAIN_NAME_LENGTH,
			NULL);
	if (sql_retval != SQL_SUCCESS)
	{
		llog_write(L_DEBUG, "ERROR SQLBindParameter() failed with return code = %d %s:%d\n",
				sql_retval,
				__FILE__,
				__LINE__);
		db_conn_print_error(
			(SQLSMALLINT) SQL_HANDLE_STMT,
			statement_handle,
			sql_retval,
			__LINE__,
			__FILE__ );
		if (statement_handle != 0)
		{
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}

		free(psf_tech_list);
		pub_site_rich_media_params->psf_tech_list = NULL;
		return DB_ERROR_INTERNAL;
	}
	//TODO:check if its correct that site_domain.name(DB value) used to lookup DB
	snprintf(s_site_domain, MAX_DOMAIN_NAME_LENGTH, "%s", additional_parameters->site.site_url);
	s_site_domain[MAX_DOMAIN_NAME_LENGTH] = '\0';

	sql_retval = SQLBindParameter(
				statement_handle,
				4,
				SQL_PARAM_INPUT,
				SQL_C_ULONG,
				SQL_INTEGER,
				0,
				0,
				&s_pub_id,
				0,
				NULL);
	if (sql_retval != SQL_SUCCESS)
	{
		llog_write(L_DEBUG, "ERROR SQLBindParameter() failed with return code = %d %s:%d\n",
				sql_retval,
				__FILE__,
				__LINE__);
		db_conn_print_error(
			(SQLSMALLINT) SQL_HANDLE_STMT,
			statement_handle,
			sql_retval,
			__LINE__,
			__FILE__);
		// Free The SQL Statement Handle
		if (statement_handle != 0)
		{
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}

		free(psf_tech_list);
		pub_site_rich_media_params->psf_tech_list = NULL;
		return DB_ERROR_INTERNAL;
	}
	s_pub_id = pub_id;

	sql_retval = SQLBindParameter(
			statement_handle,
			5,
			SQL_PARAM_INPUT,
			SQL_C_ULONG,
			SQL_INTEGER,
			0,
			0,
			&s_site_id,
			0,
			NULL);
	if (sql_retval != SQL_SUCCESS)
	{
		llog_write(L_DEBUG, "ERROR SQLBindParameter() failed with return code = %d %s:%d\n",
				sql_retval,
				__FILE__,
				__LINE__);
		db_conn_print_error((
			SQLSMALLINT) SQL_HANDLE_STMT,
			statement_handle,
			sql_retval,
			__LINE__,
			__FILE__ );
		if (statement_handle != 0)
		{
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}

		free(psf_tech_list);
		pub_site_rich_media_params->psf_tech_list = NULL;
		return DB_ERROR_INTERNAL;
	}
	s_site_id = site_id;

	/* Fetch the data */
	sql_retval = SQLExecute(statement_handle);

	// If The SQL Statement Executed Successfully, Retrieve
	// The Results
	if (sql_retval == SQL_SUCCESS)
	{
		SQLBindCol(
		statement_handle,
		1, //JSON list of iframe buster technologies.
		SQL_C_CHAR,
		s_iframe_buster_tech_list,
		MAX_AVAILABLE_IFRAME_BUSTER_TECH_LIST_LEN,
		&cb_s_iframe_buster_tech_list);
		SQLBindCol(
		statement_handle,
		2,
		SQL_C_ULONG,
		&s_is_runtime_verified,
		0,
		&cb_s_is_runtime_verified);

		sql_retval=SQLFetch(statement_handle);
		while (sql_retval != SQL_NO_DATA)
		{
			record_found = 1;// We have found 1 record
			if (cb_s_iframe_buster_tech_list == SQL_NULL_DATA)
			{
				s_iframe_buster_tech_list[0] = '\0';
				cb_s_iframe_buster_tech_list = 0;
			}
			break;// as only a single record is expected
		}
	}
	else
	{
		llog_write(L_DEBUG, "ERROR executing select statement, return code = %d %s:%d\n",
				sql_retval,
				__FILE__,
				__LINE__);
		db_conn_print_error(
			(SQLSMALLINT) SQL_HANDLE_STMT,
			statement_handle,
			sql_retval,
			__LINE__,
			__FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0)
		{
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}

		free(psf_tech_list);
		pub_site_rich_media_params->psf_tech_list = NULL;
		return DB_ERROR_INTERNAL;
	}

	// Free The SQL Statement Handle
	if (statement_handle != 0)
	{
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}

	if (record_found == 1)
	{
		cb_s_iframe_buster_tech_list = (cb_s_iframe_buster_tech_list < MAX_AVAILABLE_IFRAME_BUSTER_TECH_LIST_LEN)?
						cb_s_iframe_buster_tech_list:
						MAX_AVAILABLE_IFRAME_BUSTER_TECH_LIST_LEN;
		memcpy(psf_tech_list->json_available_iframe_buster_tech_list,
			s_iframe_buster_tech_list,
			cb_s_iframe_buster_tech_list);
		psf_tech_list->json_available_iframe_buster_tech_list_len = cb_s_iframe_buster_tech_list;

		psf_tech_list->is_runtime_verified = s_is_runtime_verified;
	}
	else
	{
		psf_tech_list->json_available_iframe_buster_tech_list[0] = '\0';
		psf_tech_list->json_available_iframe_buster_tech_list_len = 0;
		psf_tech_list->is_runtime_verified = -1;
	}

#ifdef DEBUG
	llog_write(L_DEBUG, "DB iframe buster list: %d %s is_runtime_verified %d\n",
			psf_tech_list->json_available_iframe_buster_tech_list_len,
			psf_tech_list->json_available_iframe_buster_tech_list,
			psf_tech_list->is_runtime_verified);
#endif //DEBUG
	return DB_ERROR_SUCCESS;
}

