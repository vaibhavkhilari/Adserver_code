/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "error.h"
#include "db_connection.h"
#include "rt_types.h"
#include "db_publisher_site_tld_whitelist.h"

#define GET_PUBLISHER_SITE_TLD_WHITELIST \
"select left (tld_name, 4), crc_32, id, application_profile_id, platform_id, site_code from publisher_aggregator_site_tld where pub_id = ? and site_id = ? and deleted = 0 order by crc_32 ASC limit ?,?"

int db_get_publisher_site_tld_whitelist(db_connection_t *dbconn,
		long pub_id,
                long site_id,
                publisher_site_top_level_domain_name_t **publisher_site_top_level_domain_name,
		int *nelements,
		int lower_limit,
		int size_limit) {
	
	/*Local Variables*/
	int use_count = 0;
	int alloc_count = 0;
	publisher_site_top_level_domain_name_t *retvalue = NULL;

	SQLHANDLE statement_handle = 0;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLINTEGER s_pub_id=0;
	SQLLEN cb_s_pub_id=0;
	SQLINTEGER s_site_id=0;
	SQLLEN cb_s_site_id=0;
	SQLCHAR s_domain_name[TLD_WHITELIST_TRUNCATED_DOMAIN_NAME_LENGTH + 1];
	SQLLEN cb_s_domain_name = SQL_NTS;
	SQLCHAR s_site_code[MAX_SITE_URL_ID_LENGTH + 1];
	SQLLEN cb_s_site_code = SQL_NTS;
	SQLUINTEGER s_crc_32 = 0;
	SQLLEN cb_crc_32 = 0;
	SQLINTEGER s_tld_id = 0;
	SQLLEN cb_tld_id = 0;
	SQLINTEGER s_application_profile_id = 0;
	SQLLEN cb_application_profile_id = 0;
	SQLINTEGER s_platform_id = 0;
	SQLLEN cb_platform_id = 0;

	SQLINTEGER s_lower_limit = 0;
	SQLLEN cb_s_lower_limit = 0;

	SQLINTEGER s_size_limit = 0;
	SQLLEN cb_s_size_limit = 0;


	/*Allocate the statement handle*/
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
        strncpy((char *) sql_statement, GET_PUBLISHER_SITE_TLD_WHITELIST, MAX_SQL_QUERY_STR_LEN );
        sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

	/* Create a prepared statement */
        sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
        if (sql_retval != SQL_SUCCESS) {
                llog_write(L_DEBUG, "Error preparing statement:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );

                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return ADS_ERROR_INTERNAL;
        }

	/* Bind parameters */
        sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);
        if (sql_retval != SQL_SUCCESS) {
                printf("Error binding:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );

                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                //llog_write(L_DEBUG, "%s: %d\n", __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }
        s_pub_id = pub_id;

        sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_s_site_id);
        if (sql_retval != SQL_SUCCESS) {
                printf("Error binding:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                //llog_write(L_DEBUG, "%s: %d\n", __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }
        s_site_id = site_id;


	// lower limit 
	sql_retval = SQLBindParameter(statement_handle, 3, SQL_PARAM_INPUT, SQL_C_ULONG,
				      SQL_INTEGER, 0, 0, &s_lower_limit, 0, &cb_s_lower_limit);
        if (sql_retval != SQL_SUCCESS) {
                printf("Error binding:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                //llog_write(L_DEBUG, "%s: %d\n", __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }
        s_lower_limit = lower_limit;


	//size limit
        sql_retval = SQLBindParameter(statement_handle, 4, SQL_PARAM_INPUT, SQL_C_ULONG,
                        SQL_INTEGER, 0, 0, &s_size_limit, 0, &cb_s_size_limit);
        if (sql_retval != SQL_SUCCESS) {
                printf("Error binding:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                //llog_write(L_DEBUG, "%s: %d\n", __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }
        s_size_limit = size_limit;

#ifdef MOBILE_TEST
	llog_write(L_DEBUG, "\nDB call for tld whitelist lower limit : %d size limit : %d\n", lower_limit, size_limit);
#endif

	// Execute The SQL Statement
        sql_retval = SQLExecute(statement_handle);

        if (sql_retval == SQL_SUCCESS) {

                SQLBindCol(statement_handle, 1, SQL_C_CHAR, &s_domain_name, TLD_WHITELIST_TRUNCATED_DOMAIN_NAME_LENGTH + 1, &cb_s_domain_name);
                // While There Are Records In The Result Data Set
                // Produced, Retrieve And Display Them
                SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_crc_32, 0, &cb_crc_32);
		SQLBindCol(statement_handle, 3, SQL_C_ULONG, &s_tld_id, 0, &cb_tld_id);
		SQLBindCol(statement_handle, 4, SQL_C_ULONG, &s_application_profile_id, 0, &cb_application_profile_id);
		SQLBindCol(statement_handle, 5, SQL_C_ULONG, &s_platform_id, 0, &cb_platform_id);
		SQLBindCol(statement_handle, 6, SQL_C_CHAR, &s_site_code, MAX_SITE_URL_ID_LENGTH+ 1, &cb_s_site_code);

		SQLLEN key_count;
		SQLRETURN sql_ret = SQL_SUCCESS;
		sql_ret = SQLRowCount(statement_handle, &key_count); // Get the count of rows returned by select query execution.
		if((sql_ret == SQL_SUCCESS || sql_ret == SQL_SUCCESS_WITH_INFO)){
			alloc_count = key_count;
			if(alloc_count > 0){
				retvalue = (publisher_site_top_level_domain_name_t *) malloc ((sizeof(publisher_site_top_level_domain_name_t) * (alloc_count)));
				if (retvalue == NULL) {
					if (statement_handle != 0)
						SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
					return ADS_ERROR_NOMEMORY;
				}
			}
			else{ // If the row count in result set is 0 then there is no need to go ahead and fetch rows, so return from here.
				(*nelements) = 0;
				(*publisher_site_top_level_domain_name) = retvalue;
				// Free The SQL Statement Handle
				if (statement_handle != 0) {
					SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
				}
				return ADS_ERROR_SUCCESS;
			}
		}
		else{
			llog_write(L_DEBUG, "\nError: SQLRowCount failed to get row count from select query result:\n");
			if (statement_handle != 0)
				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			return ADS_ERROR_INTERNAL;
		}
                while (sql_retval != SQL_NO_DATA) {
                        sql_retval = SQLFetch(statement_handle);
                        if (sql_retval != SQL_NO_DATA) {
                                if(cb_s_domain_name != SQL_NULL_DATA && cb_s_domain_name != 0) {
                                        cb_s_domain_name = (cb_s_domain_name < TLD_WHITELIST_TRUNCATED_DOMAIN_NAME_LENGTH)? cb_s_domain_name : TLD_WHITELIST_TRUNCATED_DOMAIN_NAME_LENGTH;
                                        strncpy(retvalue[use_count].domain_name, (char *)s_domain_name, cb_s_domain_name);
                                        retvalue[use_count].domain_name[cb_s_domain_name] = '\0';
                                        retvalue[use_count].crc_32 = (unsigned int)s_crc_32;
										retvalue[use_count].top_level_domain_id = (unsigned int)s_tld_id;
										if(cb_application_profile_id !=SQL_NULL_DATA )
										{
											retvalue[use_count].application_profile_id = s_application_profile_id;
										}else
										{
											retvalue[use_count].application_profile_id = -1;
										}
										retvalue[use_count].platform_id = (unsigned int)s_platform_id;
                                        use_count++;
                                }
                        }
                }
        } else {
                llog_write(L_DEBUG, "Error executing select statement:\n");
                db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
                                sql_retval,__LINE__,__FILE__ );
                if (retvalue != NULL) {
                        free(retvalue);
                        retvalue = NULL;
                }
                // Free The SQL Statement Handle
                if (statement_handle != 0) {
                        SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
                }
                return ADS_ERROR_INTERNAL;
        }

	if(use_count == 0){
                if (retvalue!= NULL) {
                        free(retvalue);
                        retvalue=NULL;
                }
        }
        // Free The SQL Statement Handle
        if (statement_handle != 0) {
                SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
        }

        (*nelements) = use_count;
        (*publisher_site_top_level_domain_name) = retvalue;
        return ADS_ERROR_SUCCESS;
}

