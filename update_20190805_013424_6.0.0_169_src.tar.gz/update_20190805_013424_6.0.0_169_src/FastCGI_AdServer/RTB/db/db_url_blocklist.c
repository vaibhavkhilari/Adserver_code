/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "url_blocklist.h"
#include "db_connection.h"
#include "db_url_blocklist.h"
#include "rt_types.h"
#include "db_error.h"
#include "db_constants.h"
#include "error.h"

/*#define GET_URL_BLOCKLIST_QUERY_STR \
	"SELECT json_brand_block_list, json_category_block_list, json_vertical_block_list, json_url_block_list FROM publisher_site_cooked_brand_control_blocklists WHERE pub_id = ? and site_id in (0,?) order by site_id desc"*/

#define GET_URL_BLOCKLIST_QUERY_STR \
	"SELECT json_creative_attributes, json_creative_categories, json_iab_creative_categories, json_url_block_list, json_allowed_creative_attributes FROM publisher_site_cooked_blocklists WHERE pub_id = ? and site_id in (0,?) order by site_id desc"

//DB entry for json_allowed_creative_attributes which means All Creative Attributes has been blocked.
#define RICH_MEDIA_ALL_CREATIVE_ATTRIBUTES_BLOCKED_STR " "
//List of all Creative Attributes in JSON form.
#define RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST "[1,2,3,4,5,6,7,8]"

/* 
 * Function specification:-
 *
 * Failure:-
 * 				 Kidding?
 *
 * Success:-
 * 				 a) Converts a 4 byte integer to network byte order and puts in an input buffer.
 *				 Note:- No buffer overflow checks made, caller must ensure that 'buf' has
 *				 atleast 4 bytes of valid memory
 *				 
 * 				 b) Returns buf+4
 */

static char* serialize_int(unsigned char* buf, int n) {
	buf[0]=n>>24;
	buf[1]=n>>16;
	buf[2]=n>>8;
	buf[3]=n;
	return (char *)(buf+4);
}

/*
 * Function specification:-
 *
 * 1) Failure:-
 * 						a) Return DB_ERROR_INTERNAL(db related errors)
 *
 * 						b) From rt_request_params set json_url_blockedlist & json_allowed_creative_attributes_list to Empty string.
 *                         Also, set json_allowed_creative_attributes_list_len & json_url_blockedlist_len ot zero.
 *
 * 2) Success:-
 * 						a) From rt_request_params set json_url_blockedlist & json_allowed_creative_attributes_list as the following:-
 *	                  
 *                      +----+-------------------+----+-------------------+----+-----------------------+----+--------------------------+
 * json_url_blockedlist |size|CREATIVE_ATTRIBUTES|size|ADVT_CATEGORIES|size|ADVT_IAB_CATEGORIES|size|LANDING_PAGE_URL_BLOCKLIST|
 *                      +----+-------------------+----+-------------------+----+-----------------------+----+--------------------------+
 *                                       +---------------------------+
 * json_allowed_creative_attributes_list |ALLOWED_CREATIVE_ATTRIBUTES|
 *                                       +---------------------------+
 *                    
 *									                OR
 * 3) If all json_creative_attributes, json_creative_categories & json_url_block_list, strings are NULL/Emptry then,
 *                      Set json_url_blockedlist to Empty string & json_url_blockedlist_len ot zero.
 *
 * 4) If json_allowed_creative_attributes_list (returned by DB) is " " (String which has single space char in it)
 *    which means all Creative Attributes have been blocked then,
 *                      Set json_allowed_creative_attributes_list to Empty String &
 *                      Set json_allowed_creative_attributes_list_len to zero.
 *
 * 5) If for given Publisher's site record does not exist in the DB
 *    (Which means, "No Creative Attribute" has been blocked by Publisher) then,
 *                      Set json_url_blockedlist to Empty string & json_url_blockedlist_len ot zero.
 *                      Set json_allowed_creative_attributes_list to list of all creative attributes &
 *                      Set json_allowed_creative_attributes_list_len accordingly.
 */
int get_url_blocklist(long pub_id, long site_id, db_connection_t* dbconn, rt_request_params_t *rt_request_params) {

	// Local variables
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN];
	//Parameters:-
	SQLINTEGER s_pub_id;
	SQLINTEGER s_site_id;

	int i;
	int record_found=0;// To indicate if there is a record for this pub_id, site_id
	// combination in the table "publisher_site_cooked_brand_contol_blocklists"
	//----------------------
	SQLLEN indicator[5]; // Length of each column fetched from the DB
	int columns=5; // Each record consists of 3 columns
	char buf[columns][MAX_SINGLE_BLOCKLIST_SIZE + 1];// To store data fetched from DB; It works because columns is computed at compile time
	int flag=0;// To indicate that atleast one of the 4 lists is non-empty
	char* temp_ptr=NULL;
	char *json_allowed_creative_attributes_list_temp_ptr = NULL;
	publisher_site_ad_rich_media_params_t *pub_site_rich_media_params = NULL;


	/* Initialized Rich Media related params. */
	pub_site_rich_media_params = rt_request_params->pub_site_rich_media_params;
	pub_site_rich_media_params->blocked_list = (memcached_blocklist_t *) malloc(sizeof (memcached_blocklist_t));
	if (pub_site_rich_media_params->blocked_list == NULL)
	{
		llog_write(L_DEBUG, "%s(): Not able to allocate memory for blocked list.\n",
				__FUNCTION__);
		return ADS_ERROR_NOMEMORY;
	}
	pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list[MAX_ALLOWED_CREATIVE_ATTRIBUTES_LIST_LEN] = '\0';
	pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list[0] = '\0';
	pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list_len = 0;
	pub_site_rich_media_params->blocked_list->json_url_blockedlist_len = 0;// initialize *len_blocklist
	pub_site_rich_media_params->blocked_list->json_total_len = 0;//bug fix
	json_allowed_creative_attributes_list_temp_ptr = pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list;
	temp_ptr = pub_site_rich_media_params->blocked_list->json_url_blocked_list;

	for(i=0;i<columns;i++) {
		buf[i][0]=0;// set to NUL character
		indicator[i]=0;
	}


	// Allocate the statement handle
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	// Create SQL char string which contains the query
	strncpy((char *) sql_statement, GET_URL_BLOCKLIST_QUERY_STR,MAX_SQL_QUERY_STR_LEN);
	sql_statement[MAX_SQL_QUERY_STR_LEN-1]=0;// copy the NUL character in case of buffer overflow

	// Create a prepared statement
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if(sql_retval!=SQL_SUCCESS) {
		llog_write(L_DEBUG, "ERROR Preparing statement and error code = %d %s:%d\n",sql_retval,__FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,sql_retval,__LINE__,__FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		free(pub_site_rich_media_params->blocked_list);
		pub_site_rich_media_params->blocked_list = NULL;
		return DB_ERROR_INTERNAL;
	}

	// Bind parameters
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, NULL);
	if(sql_retval!=SQL_SUCCESS) {
		//printf("ERROR binding:\n");
		llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n",sql_retval,__FILE__,__LINE__);// TODO is SQLRETURN an int so that %d is safe?
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__);
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		free(pub_site_rich_media_params->blocked_list);
		pub_site_rich_media_params->blocked_list = NULL;
		return DB_ERROR_INTERNAL;
	}
	s_pub_id=pub_id;

	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_site_id, 0, NULL);
	if(sql_retval!=SQL_SUCCESS) {
		//printf("ERROR binding:\n");
		llog_write(L_DEBUG,"ERROR SQLBindParameter() failed with return code = %d %s:%d\n",sql_retval,__FILE__,__LINE__);// TODO is SQLRETURN an int so that %d is safe? Yeah I am paranoid
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		free(pub_site_rich_media_params->blocked_list);
		pub_site_rich_media_params->blocked_list = NULL;
		return DB_ERROR_INTERNAL;
	}
	s_site_id=site_id;

	/* Loop through the rows in the result-set binding to local variables */
	for (i = 0; i < columns; i++) {
		SQLBindCol(statement_handle, i + 1, SQL_C_CHAR,
				buf[ i ], sizeof(buf[ i ]), &indicator[ i ] );
	}

	/* Fetch the data */
	sql_retval = SQLExecute(statement_handle);

	// If The SQL Statement Executed Successfully, Retrieve
	// The Results
	if (sql_retval == SQL_SUCCESS) {
		sql_retval=SQLFetch(statement_handle);
		while (sql_retval != SQL_NO_DATA) {
			record_found=1;// We have found 1 record
			for ( i = 0; i < columns; i ++ ) {
				if (indicator[ i ] == SQL_NULL_DATA) {
					buf[i][0]=0;
				}
			}
			break;// as only a single record is expected
		}
	} else {
		llog_write(L_DEBUG,"ERROR executing select statement, return code = %d %s:%d\n",sql_retval,__FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		free(pub_site_rich_media_params->blocked_list);
		pub_site_rich_media_params->blocked_list = NULL;
		return DB_ERROR_INTERNAL;
	}

	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
#ifdef FUNCTIONAL_TESTING
	for(i=0;i<columns;i++) {
			if(indicator[i]!=SQL_NULL_DATA) {
				llog_write(L_DEBUG,"\nINDICATOR[%d]=%ld %s:%d\n",i+1,indicator[i],__FILE__,__LINE__);
			}
	}
#endif
	if(record_found==1) {
		for(i=0;i<columns;i++) {
            		if (i < 4)
			{
			    if(indicator[i]!=SQL_NULL_DATA && indicator[i]!=0) {
			     	// It's neither NULL nor empty string
				indicator[i] = (indicator[i] < MAX_SINGLE_BLOCKLIST_SIZE)? indicator[i]:MAX_SINGLE_BLOCKLIST_SIZE;
				temp_ptr = serialize_int((unsigned char *)temp_ptr, indicator[i]);
				pub_site_rich_media_params->blocked_list->json_url_blockedlist_len += 4;// sizeof(int)
				memcpy(temp_ptr,buf[i],indicator[i]);
				temp_ptr+=indicator[i];
				pub_site_rich_media_params->blocked_list->json_url_blockedlist_len += indicator[i];
				flag=1;
			    } else {
		     		temp_ptr=serialize_int((unsigned char *)temp_ptr, 0);
			    	//fix for cores coming due to NULL values on 24_01_2011
			    	(pub_site_rich_media_params->blocked_list->json_url_blockedlist_len) += 4;// sizeof(int)
			    }
			}
			else if (i == 4)
			{
				//4th column is a list of allowed creative attributes in JSON form.
				if (	indicator[i] != SQL_NULL_DATA &&
					indicator[i] != 0 &&
					strcmp(buf[i], RICH_MEDIA_ALL_CREATIVE_ATTRIBUTES_BLOCKED_STR) != 0)
				{
					//It's neither NULL nor empty string.
					indicator[i] = (indicator[i] < MAX_ALLOWED_CREATIVE_ATTRIBUTES_LIST_LEN)?
							indicator[i]:
							MAX_ALLOWED_CREATIVE_ATTRIBUTES_LIST_LEN;
                    			memcpy(
						json_allowed_creative_attributes_list_temp_ptr,
						buf[i],
						indicator[i]);
					json_allowed_creative_attributes_list_temp_ptr += indicator[i];
					pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list_len = indicator[i];
					flag = 1;
				}
				else if (strcmp(buf[i], RICH_MEDIA_ALL_CREATIVE_ATTRIBUTES_BLOCKED_STR) == 0)
				{
					//Alli creative attributes are allowed.
					memcpy(json_allowed_creative_attributes_list_temp_ptr,
							RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST,
							(sizeof (RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST) - 1));
					pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list_len = (sizeof (RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST) - 1);
				}
				else
				{
					pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list[0] = '\0';
					pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list_len = 0;
				}
			}
		}
		if(flag==0) {
			// all 4 lists are empty/NULL
			pub_site_rich_media_params->blocked_list->json_url_blocked_list[0] = '\0';
			pub_site_rich_media_params->blocked_list->json_url_blockedlist_len = 0;
			//All creative attributes are allowed.
			memcpy(json_allowed_creative_attributes_list_temp_ptr,
				RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST,
				(sizeof (RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST) - 1));
			pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list_len = (sizeof (RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST) - 1);
		}
	} else {
		pub_site_rich_media_params->blocked_list->json_url_blocked_list[0] = '\0';
		pub_site_rich_media_params->blocked_list->json_url_blockedlist_len = 0;
		//All creative attributes are allowed.
		memcpy(json_allowed_creative_attributes_list_temp_ptr,
			RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST,
			(sizeof (RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST) - 1));
		pub_site_rich_media_params->blocked_list->json_allowed_creative_attributes_list_len = (sizeof (RICH_MEDIA_JSON_ALL_CREATIVE_ATTRIBUTES_LIST) - 1);
	}
	return DB_ERROR_SUCCESS;
}

