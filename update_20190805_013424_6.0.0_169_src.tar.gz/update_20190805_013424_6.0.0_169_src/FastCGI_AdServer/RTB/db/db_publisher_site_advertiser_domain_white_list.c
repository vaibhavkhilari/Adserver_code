/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_rt_campaign_config.h"
#include "error.h"
#include "bloom_filter.h"

/* 
	here, ORDER BY site_id DESC LIMIT 1 ensures that if bloom filter of specified site exists then it will be fetched 
	o.w. bloom filter of site id 0 i.e. ALL will be fetched 
*/
#define GET_PUBLISHER_SITE_ADV_DOM_WHT_LIST \
"SELECT bloom_filter, accepted_domain_count FROM publisher_site_advertiser_domain_filter WHERE pub_id = 0 AND site_id = 0 LIMIT 1"

int db_get_publisher_site_advertiser_domain_white_list(db_connection_t *dbconn,
				BLOOM** publisher_site_advertiser_domain_name,
				size_t *ret_size) {

	/* Local variables */
	unsigned char *bit_array;
	int retval = ADS_ERROR_SUCCESS;
	size_t memcache_obj_size = 0;
	BLOOM* bloom = NULL;	
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLCHAR *s_bit_array = NULL;
	SQLLEN cb_s_bit_array = SQL_NTS;
	SQLINTEGER s_accepted_domain_cnt=0;
	SQLLEN cb_s_accepted_domain_cnt=0;

	(*ret_size) = 0;
	(*publisher_site_advertiser_domain_name) = NULL;

	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	strncpy((char *) sql_statement, GET_PUBLISHER_SITE_ADV_DOM_WHT_LIST, MAX_SQL_QUERY_STR_LEN );
	sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';


	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		retval = ADS_ERROR_INTERNAL;
		goto done;
	}

	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);

	if (sql_retval == SQL_SUCCESS) {

		s_bit_array = (SQLCHAR *)calloc(BIT_ARRAY_SIZE+1, sizeof(char));
		if(s_bit_array == NULL) {
			llog_write(L_DEBUG, "\nError: Failed to allocate memory for bloom filter, %s:%d\n", __FILE__, __LINE__);
			return ADS_ERROR_NOMEMORY;
		}
		/* Bind Column : bloom_filter */
		sql_retval = SQLBindCol(statement_handle, 1, SQL_C_BINARY, s_bit_array, BIT_ARRAY_SIZE, &cb_s_bit_array);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = ADS_ERROR_INTERNAL;
			goto done;
		}

		/* Bind Column : blocked_domain_count */
		sql_retval = SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_accepted_domain_cnt, 0, &cb_s_accepted_domain_cnt);
		if (sql_retval != SQL_SUCCESS) {
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT, statement_handle, sql_retval, __LINE__, __FILE__ );
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			retval = ADS_ERROR_INTERNAL;
			goto done;
		}
		/* Fetch Result */
		sql_retval = SQLFetch(statement_handle);
		if (sql_retval == SQL_NO_DATA) {
			llog_write(L_DEBUG, "ADF_DB_INFO: No bloom filter, %s:%d\n",__FILE__,__LINE__);
			retval = ADS_ERROR_SUCCESS;
			goto done;
		}
	}
	else {
		llog_write(L_DEBUG, "Error executing select statement, %s:%d\n",__FILE__,__LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		retval = ADS_ERROR_INTERNAL;
		goto done;
	}

	/* Hard limit on max size of blocklist = 200000 */	
	if(s_accepted_domain_cnt > MAX_ELEMENT_COUNT) {
		llog_write(L_DEBUG, "ERROR: Could not create bloom filter because blocklist size > %d, %s:%d\n",MAX_ELEMENT_COUNT,__FILE__,__LINE__);
		retval = ADS_ERROR_NOMEMORY;
		goto done;
	}

	if(!(bloom = bloom_create((int)s_accepted_domain_cnt, &memcache_obj_size))) {
		llog_write(L_DEBUG, "\nERROR: Could not create bloom filter, %s:%d\n",__FILE__, __LINE__);
		retval = ADS_ERROR_NOMEMORY;
		goto done;
	}

	BLOCKLIST_DEBUG("\nADF_Bloom:pub:0 site:0:: db_accepted_domain_count:%d, db_bit_array_size_bytes:%ld\n", 
				s_accepted_domain_cnt, cb_s_bit_array);

	if(cb_s_bit_array != SQL_NULL_DATA && cb_s_bit_array != 0) {
		cb_s_bit_array = (cb_s_bit_array < BIT_ARRAY_SIZE)? cb_s_bit_array : BIT_ARRAY_SIZE;
		bit_array = (unsigned char*)&((bloom)[1]);
		memcpy(bit_array, (unsigned char *)s_bit_array, cb_s_bit_array);
	}

	BLOCKLIST_DEBUG("\nADF_Bloom:pub:0 site:0:: accepted_domain_count:%d, sizeof(BLOOM):%zu, bit_array_size(in bits):%ld, "
			"bit_array_size(in bytes):%ld, memcache_obj_size:%zd, %s:%d\n",
			bloom->nelements, sizeof(BLOOM), bloom->bit_array_size, 
			BIT_ARRAY_SIZE_BYTES(bloom->bit_array_size), 
			memcache_obj_size, __FILE__, __LINE__);

	(*ret_size) = memcache_obj_size;
	(*publisher_site_advertiser_domain_name) = bloom;

done:
	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	if (s_bit_array != NULL) {
		free(s_bit_array);
	}
	return retval;
}
