/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "rt_types.h"
#include "db_campaign_site_blocking_params.h"
#include "stdlib.h"
#include <sys/time.h>
#include <errno.h>

#define ACTIVE_RTB_ALLOC_SIZE 5


#define GET_SITE_CAMP_BLOCKLIST_MAP  \
"select campaign_id, bid_blocking_percentage from campaign_site_blocking_parameters where site_id = ?"

int get_campaign_site_blocking_params(
                campaign_site_blocking_params_t **campaign_site_blocking_params,
                long site_id,
                db_connection_t *dbconn,
                int *ret_elements) {
	
	/* Local variables */
	campaign_site_blocking_params_t *retvalue=NULL;	
	campaign_site_blocking_params_t *tmp_retvalue=NULL;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN];
	SQLINTEGER s_site_id=0;
	SQLLEN cb_s_site_id=0;
	SQLINTEGER s_campaign_id=0;
	SQLLEN cb_s_campaign_id=0;
	SQLINTEGER s_blocking_percentage=0;
	SQLLEN cb_s_blocking_percentage=0;

	int use_count = 0;
	int alloc_count = ACTIVE_RTB_ALLOC_SIZE;
	char query_string[MAX_SQL_QUERY_STR_LEN];
	
	strncpy(query_string, GET_SITE_CAMP_BLOCKLIST_MAP, MAX_SQL_QUERY_STR_LEN);
	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);

	/* Create SQL char string which contains the query */
	strcpy((char *) sql_statement, query_string);
	//llog_write(L_DEBUG, "\n Query : %s", query_string);

	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if(sql_retval!=SQL_SUCCESS)
	{
		llog_write(L_DEBUG, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
					sql_retval,__LINE__,__FILE__ );
		if (retvalue != NULL) {
			free(retvalue);
			retvalue = NULL;
		}
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return DB_ERROR_INTERNAL;
	}


	/* Bind parameters */
	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_s_site_id);
	if(sql_retval!=SQL_SUCCESS)
	{
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
	//llog_write(L_DEBUG, "%s: %d\n", __FILE__, __LINE__);
		return DB_ERROR_INTERNAL;
	}
	s_site_id = site_id;
	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);
	//llog_write(L_DEBUG,"\n After execute");
	// If The SQL Statement Executed Successfully, Retrieve
	// The Results
	if (sql_retval == SQL_SUCCESS)
	{

		SQLBindCol(statement_handle, 1, SQL_C_ULONG, &s_campaign_id,
                                0, &cb_s_campaign_id);
		
		SQLBindCol(statement_handle, 2, SQL_C_ULONG, &s_blocking_percentage,
                                0, &cb_s_blocking_percentage);

		
		// While There Are Records In The Result Data Set
		// Produced, Retrieve And Display Them

		retvalue = (campaign_site_blocking_params_t *) malloc ((sizeof(campaign_site_blocking_params_t) * ACTIVE_RTB_ALLOC_SIZE));	
		//Get time 
		//gettimeofday(&tv,NULL);
		errno = 0;
		while (sql_retval != SQL_NO_DATA)
		{
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {
               	if (use_count == alloc_count) {
               		alloc_count++;
               		tmp_retvalue = realloc(retvalue, sizeof(campaign_site_blocking_params_t) * alloc_count);
               		if (tmp_retvalue == NULL) {
               			if (retvalue != NULL) {
               				free(retvalue);
               				retvalue = NULL;
               			}
               // Free The SQL Statement Handle
               			if (statement_handle != 0) {
               				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
               			}
           				return DB_ERROR_NO_MEMORY;
          			}
               		retvalue = tmp_retvalue;
       			}
					retvalue[use_count].campaign_id  = s_campaign_id;
					retvalue[use_count].blocking_percentage = s_blocking_percentage; 
					retvalue[use_count].found_flag = 0;
					//llog_write(L_DEBUG, "\nDB CampId: %ld BlockPer: %ld ", retvalue[use_count].campaign_id, retvalue[use_count].blocking_percentage);
					use_count++;
				}
			}
		} else {
			llog_write(L_DEBUG, "Error executing select statement:\n");
			db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
			if (retvalue != NULL) {
				free(retvalue);
				retvalue = NULL;
			}
		// Free The SQL Statement Handle
			if (statement_handle != 0) {
				SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
			}
		return DB_ERROR_INTERNAL;
		}

	if(use_count == 0){
		if(retvalue!= NULL){
			free(retvalue);
			retvalue=NULL;
		}
	}	
	// Free The SQL Statement Handle
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	(*ret_elements) = use_count;
	(*campaign_site_blocking_params) = retvalue;
	return DB_ERROR_SUCCESS;
}
