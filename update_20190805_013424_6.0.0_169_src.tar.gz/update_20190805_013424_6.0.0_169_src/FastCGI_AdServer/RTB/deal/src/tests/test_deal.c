#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include <assert.h>

#include <stdarg.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>

#include "debug.h"
#include "platform.h"
#include "error_code.h"
#include "log_fw.h"
#include "pb_deal.h"
#include "error.h"
#include "debug.h"
#include "db_error.h"
#include "fte_util.h"
#include "cache_libmemcached.h"
#include "cache_conf_intf.h"
#include <string_util.h>
#include "rtb_brand_control_util.h"
#include "rt_types.h"
#include "deal.h"
#include "deal_util.h"
#include "audience_targeting_util.h"
#include "time_parting.h"
#include "day_parting.h"
#include "libstats_util.h"
#include "log_fw.h"
#include "deal_def.h"

#include "wrap.c"

fte_additional_params_t fte_additional_parameters;
publisher_site_ad_campaign_list_t adcampaigns; 
deal_criteria_t deal_criteria;  
rt_response_params_t rt_response_param;
int *deal_attr_alloc_count;
struct publisher_site_ad *in_ad;
custom_targeted_deals_list_t ctr_deal_list = {NULL,0,0};
char *impr;

/*
 *  set_bit - Set a bit in memory
 *  @nr: the bit to set
 *  @addr: the address to start counting from
 **/
void set_bit(int nr, unsigned long long *addr)
{
        *addr = ((1ULL << nr) | *addr);
}

int is_deal_criterion_applicable(fte_additional_params_t *fte_additional_parameters,
		publisher_site_ad_campaign_list_t *adcampaigns,
		deal_criteria_t *deal_criterion,
		struct publisher_site_ad *in_ad,
		rt_response_params_t *rt_response_param,
		custom_targeted_deals_list_t *ctr_deal_list,
		int deal_meta_id,
		int debug_deal_meta,
		char *impression_id);

static void initialize_variables(){
	deal_criteria.active_entities_count = 1;
	ad_server_req_param_t *in_server_req_params = (ad_server_req_param_t*)malloc(sizeof(ad_server_req_param_t)); 
	fte_additional_parameters.in_server_req_params = in_server_req_params; 
	fte_additional_parameters.in_server_req_params->site_ad = (publisher_site_ad_t*)malloc(sizeof(publisher_site_ad_t));
}

static void test__is_deal_criterion_applicable__SOURCE_all_inventory_ssp_req(void **state){
        (void) state;

	initialize_variables();

	//test case specific setup
        deal_criteria.source_evaluation_result = SOURCE_NOT_EVALUATED;
        set_bit(SOURCE, &deal_criteria.active_entities_bitmap);
        deal_criteria.source = ALL_INVENTORY;

	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(is_applicable, 1);
	assert_int_equal(deal_criteria.source_evaluation_result, SOURCE_EVALUATION_PASS);
}
static void test__is_deal_criterion_applicable__SOURCE_all_inventory_phoenix_req(void **state){
        (void) state;

        initialize_variables();
	
	//test case specific setup
        deal_criteria.source = ALL_INVENTORY;
	fte_additional_parameters.in_server_req_params->is_phoenix_request = 1;
	deal_criteria.source_evaluation_result = SOURCE_NOT_EVALUATED;
        set_bit(SOURCE, &deal_criteria.active_entities_bitmap);

	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(is_applicable, 1); 
        assert_int_equal(deal_criteria.source_evaluation_result, SOURCE_EVALUATION_PASS);
}

static void test__is_deal_criterion_applicable__SOURCE_ssp_req(void **state){
        (void) state;

	initialize_variables();
	
	//test case specific setup
	deal_criteria.source_evaluation_result = SOURCE_NOT_EVALUATED;
	set_bit(SOURCE, &deal_criteria.active_entities_bitmap);
	deal_criteria.source = NON_PHOENIX_INVNETORY;

	//test call and assertion
	int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(is_applicable, 1);
	assert_int_equal(deal_criteria.source_evaluation_result, SOURCE_EVALUATION_PASS);
	
}
static void test__is_deal_criterion_applicable__SOURCE_phoenix_req(void **state){
        (void) state;
	
	initialize_variables();	
	
	//test case specific setup
	deal_criteria.source = PHOENIX_INVENTORY;
	deal_criteria.source_evaluation_result = SOURCE_NOT_EVALUATED;
	set_bit(SOURCE, &deal_criteria.active_entities_bitmap);
	fte_additional_parameters.in_server_req_params->is_phoenix_request = 1;

	//test call and assertion
	int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(is_applicable, 1);
	assert_int_equal(deal_criteria.source_evaluation_result, SOURCE_EVALUATION_PASS);
	
}
static void test__is_deal_criterion_applicable__SOURCE_unapplicable_deal_case_1(void **state){
        (void) state;

	initialize_variables();

	//test case specific setup
	deal_criteria.source = NON_PHOENIX_INVNETORY;
	deal_criteria.source_evaluation_result = SOURCE_NOT_EVALUATED;
        set_bit(SOURCE, &deal_criteria.active_entities_bitmap);
	fte_additional_parameters.in_server_req_params->is_phoenix_request = 1;

        //test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(is_applicable, 0);
        assert_int_equal(deal_criteria.source_evaluation_result, SOURCE_EVALUATION_FAIL);
            
}
static void test__is_deal_criterion_applicable__SOURCE_unapplicable_deal_case_2(void **state){
        (void) state;

	initialize_variables();

	//test case specific setup
        deal_criteria.source_evaluation_result = SOURCE_NOT_EVALUATED;
        set_bit(SOURCE, &deal_criteria.active_entities_bitmap);
	deal_criteria.source = PHOENIX_INVENTORY;

        //test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(is_applicable, 0); 
        assert_int_equal(deal_criteria.source_evaluation_result, SOURCE_EVALUATION_FAIL);
    
}
static void test__is_deal_criterion_applicable__SOURCE_already_evaluated_success(void **state){
	(void) state;

	//test case specific setup
	set_bit(SOURCE, &deal_criteria.active_entities_bitmap);
	deal_criteria.source_evaluation_result = SOURCE_EVALUATION_PASS;

	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(deal_criteria.source_evaluation_result, SOURCE_EVALUATION_PASS);
        assert_int_equal(is_applicable, 1);
}
static void test__is_deal_criterion_applicable__SOURCE_already_evaluated_fail(void **state){
        (void) state;

	//test case specific setup
        set_bit(SOURCE, &deal_criteria.active_entities_bitmap);
        deal_criteria.source_evaluation_result = SOURCE_EVALUATION_FAIL;

	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(deal_criteria.source_evaluation_result, SOURCE_EVALUATION_FAIL);
        assert_int_equal(is_applicable, 1); 
}
static void test__is_deal_criterion_applicable__PLATFORM_ID_targeted_applicable_deal(void **state){
	(void) state;

	initialize_variables();
	
	//test case specific setup
	deal_criteria.platform_id_evaluation_result = PLATFORM_ID_NOT_EVALUATED;
	deal_criteria.platform_id = 1;	
	
	fte_additional_parameters.in_server_req_params->site_ad->platform_id = 1;
	deal_criteria.active_entities_count = 1;
	set_bit(PLATFORM_ID, &deal_criteria.active_entities_bitmap);
	
	//test call and assertion
	int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	
	assert_int_equal(deal_criteria.platform_id_evaluation_result, PLATFORM_ID_EVALUATION_PASS);
	assert_int_equal(is_applicable, 1);
}

static void test__is_deal_criterion_applicable__PLATFORM_ID_targeted_inapplicable_deal(void **state){
	(void) state;

	initialize_variables();

	//test case specific setup
	deal_criteria.platform_id_evaluation_result = PLATFORM_ID_NOT_EVALUATED;
	deal_criteria.platform_id = 1;	
	fte_additional_parameters.in_server_req_params->site_ad->platform_id = 0;
	deal_criteria.active_entities_count = 1;
	set_bit(PLATFORM_ID, &deal_criteria.active_entities_bitmap);

	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(deal_criteria.platform_id_evaluation_result, PLATFORM_ID_EVALUATION_FAIL);
	assert_int_equal(is_applicable, 0);
}
typedef struct{
	int playback_method;
	int is_playback_targetetted;
	//result
	int is_applicable;
	int video_playback_evaluation_result;
}test_playback_method_st;
test_playback_method_st test_playback_method_cases[]={
	{
		.playback_method = 2,
		.is_playback_targetetted = FLAG_SET,
		//result           
		.video_playback_evaluation_result = VIDEO_PLAYBACK_EVALUATION_PASS,
		.is_applicable = 1

	},
	{
		.playback_method = 6,
		.is_playback_targetetted = FLAG_SET,
		//result           
		.video_playback_evaluation_result = VIDEO_PLAYBACK_EVALUATION_PASS,
		.is_applicable = 1

	},
};
static void test__is_deal_criterion_applicable__playback_method_targeted_inapplicable_deal(void **state){
	(void) state;

	initialize_variables();
	set_bit(VIDEO_PLAYBACK, &deal_criteria.active_entities_bitmap);
	deal_criteria.video_playback_evaluation_result = VIDEO_PLAYBACK_NOT_EVALUATED;

	//test case specific setup
	int item_count = sizeof(test_playback_method_cases)/sizeof(test_playback_method_st);
	int i = 0;
	for (i = 0; i < item_count; i++){

		fte_additional_parameters.in_server_req_params->video_params.playback[0] = test_playback_method_cases[i].is_playback_targetetted;
		deal_criteria.video_playback = test_playback_method_cases[i].playback_method;		
		fte_additional_parameters.in_server_req_params->video_params.playback[test_playback_method_cases[i].playback_method] = FLAG_SET;
		//test call and assertion
		int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
		assert_int_equal(deal_criteria.video_playback_evaluation_result, test_playback_method_cases[i].video_playback_evaluation_result);
		assert_int_equal(is_applicable,  test_playback_method_cases[i].is_applicable);
	}
}
static void test__is_deal_criterion_applicable__PLATFORM_already_evaluated_success(void **state){
	(void) state;

	//test case specific setup
	deal_criteria.active_entities_count = 1;
	deal_criteria.platform_id_evaluation_result = PLATFORM_ID_EVALUATION_PASS;
        set_bit(PLATFORM_ID, &deal_criteria.active_entities_bitmap);
	
	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(deal_criteria.platform_id_evaluation_result, PLATFORM_ID_EVALUATION_PASS);
	assert_int_equal(is_applicable, 1);
}
static void test__is_deal_criterion_applicable__PLATFORM_already_evaluated_fail(void **state){
	(void) state;

	//test case specific setup
	deal_criteria.active_entities_count = 1;
        set_bit(PLATFORM_ID, &deal_criteria.active_entities_bitmap);
	deal_criteria.platform_id_evaluation_result = PLATFORM_ID_EVALUATION_FAIL;
	
	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(deal_criteria.platform_id_evaluation_result, PLATFORM_ID_EVALUATION_FAIL);
	assert_int_equal(is_applicable, 1);
}
static void test__is_deal_criterion_applicable__AD_TYPE_ID_all_conditions_pass(void **state){
	(void) state;

	initialize_variables();

	//test case specific setup
        set_bit(AD_TYPE_ID, &deal_criteria.active_entities_bitmap);
	deal_criteria.ad_type_id_evaluation_result = AD_TYPE_ID_NOT_EVALUATED;
	deal_criteria.ad_type_id = AD_TYPE_TEXT_IMAGE;
	fte_additional_parameters.in_server_req_params->ad_type = AD_TYPE_TEXT_IMAGE;
	
	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(deal_criteria.ad_type_id_evaluation_result, AD_TYPE_ID_EVALUATION_PASS);
	assert_int_equal(is_applicable, 1);
}
static void test__is_deal_criterion_applicable__AD_TYPE_ID_only_AD_TYPE_TEXT_IMAGE_pass(void **state){
	(void) state;

	initialize_variables();

	//test case specific setup
        set_bit(AD_TYPE_ID, &deal_criteria.active_entities_bitmap);
	deal_criteria.ad_type_id_evaluation_result = AD_TYPE_ID_NOT_EVALUATED;
	deal_criteria.ad_type_id = AD_TYPE_TEXT_IMAGE;
	fte_additional_parameters.in_server_req_params->ad_type = AD_TYPE_TEXT_ONLY;
	
	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(deal_criteria.ad_type_id_evaluation_result, AD_TYPE_ID_EVALUATION_PASS);
	assert_int_equal(is_applicable, 1);
}
static void test__is_deal_criterion_applicable__AD_TYPE_ID_only_equality_condition_pass(void **state){
	(void) state;

	initialize_variables();

	//test case specific setup
        set_bit(AD_TYPE_ID, &deal_criteria.active_entities_bitmap);
	deal_criteria.ad_type_id_evaluation_result = AD_TYPE_ID_NOT_EVALUATED;
	deal_criteria.ad_type_id = AD_TYPE_NATIVE;
	fte_additional_parameters.in_server_req_params->ad_type = AD_TYPE_NATIVE;
	
	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(deal_criteria.ad_type_id_evaluation_result, AD_TYPE_ID_EVALUATION_PASS);
	assert_int_equal(is_applicable, 1);
}
static void test__is_deal_criterion_applicable__AD_TYPE_ID_both_fail(void **state){
	(void) state;

	initialize_variables();

	//test case specific setup
        set_bit(AD_TYPE_ID, &deal_criteria.active_entities_bitmap);
	deal_criteria.ad_type_id_evaluation_result = AD_TYPE_ID_NOT_EVALUATED;
	deal_criteria.ad_type_id = AD_TYPE_NATIVE;
	fte_additional_parameters.in_server_req_params->ad_type = AD_TYPE_VIDEO;
	
	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(deal_criteria.ad_type_id_evaluation_result, AD_TYPE_ID_EVALUATION_FAIL);
	assert_int_equal(is_applicable, 0);
}
static void test__is_deal_criterion_applicable__AD_TYPE_ID_already_evaluated_pass(void **state){
	(void) state;

	//test case specific setup
        set_bit(AD_TYPE_ID, &deal_criteria.active_entities_bitmap);
	deal_criteria.ad_type_id_evaluation_result = AD_TYPE_ID_EVALUATION_PASS;
	
	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(deal_criteria.ad_type_id_evaluation_result, AD_TYPE_ID_EVALUATION_PASS);
	assert_int_equal(is_applicable, 1);
}
static void test__is_deal_criterion_applicable__AD_TYPE_ID_already_evaluated_fail(void **state){
	(void) state;

	//test case specific setup
        set_bit(AD_TYPE_ID, &deal_criteria.active_entities_bitmap);
	deal_criteria.ad_type_id_evaluation_result = AD_TYPE_ID_EVALUATION_FAIL;
	
	//test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
	assert_int_equal(deal_criteria.ad_type_id_evaluation_result, AD_TYPE_ID_EVALUATION_FAIL);
	assert_int_equal(is_applicable, 1);
}
static void test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_all_conditions_pass_org_pass(void **state){
        (void) state;

	initialize_variables();
	
	//test case specific setup
        set_bit(RICHMEDIA_CREATIVE_ATTRIBUTE, &deal_criteria.active_entities_bitmap);
        deal_criteria.ad_type_id_evaluation_result = RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_PASS;
	deal_criteria.richmedia_allowed_creative_attr = 1;
	fte_additional_parameters.in_server_req_params->blocked_richmedia_creative_attr_map = 0;
	strcpy(fte_additional_parameters.in_server_req_params->rich_media_technologies, "richmedia");
	strcpy(fte_additional_parameters.in_server_req_params->ad_expansion_direction, "adexpansion");

        //test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(deal_criteria.richmedia_creative_attr_evaluation_result, RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_PASS);
        assert_int_equal(is_applicable, 1);
}

static void test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_all_conditions_pass_org_fail(void **state){
        (void) state;

	initialize_variables();
	
	//test case specific setup
        set_bit(RICHMEDIA_CREATIVE_ATTRIBUTE, &deal_criteria.active_entities_bitmap);
        deal_criteria.ad_type_id_evaluation_result = RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL;
	deal_criteria.richmedia_allowed_creative_attr = 1;
	fte_additional_parameters.in_server_req_params->blocked_richmedia_creative_attr_map = 0;
	strcpy(fte_additional_parameters.in_server_req_params->rich_media_technologies, "richmedia");
	strcpy(fte_additional_parameters.in_server_req_params->ad_expansion_direction, "adexpansion");

        //test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(deal_criteria.richmedia_creative_attr_evaluation_result, RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_PASS);
        assert_int_equal(is_applicable, 1);
}
static void test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_condition2_1_fails(void **state){
        (void) state;

	initialize_variables();
	
	//test case specific setup
        set_bit(RICHMEDIA_CREATIVE_ATTRIBUTE, &deal_criteria.active_entities_bitmap);
        deal_criteria.ad_type_id_evaluation_result = RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL;
	deal_criteria.richmedia_allowed_creative_attr = 0;
	fte_additional_parameters.in_server_req_params->blocked_richmedia_creative_attr_map = 1;

        //test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(deal_criteria.richmedia_creative_attr_evaluation_result, RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL);
        assert_int_equal(is_applicable, 0);
}
static void test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_condition2_2_fails(void **state){
        (void) state;

	initialize_variables();
	
	//test case specific setup
        set_bit(RICHMEDIA_CREATIVE_ATTRIBUTE, &deal_criteria.active_entities_bitmap);
        deal_criteria.ad_type_id_evaluation_result = RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL;
	deal_criteria.richmedia_allowed_creative_attr = 0;
	fte_additional_parameters.in_server_req_params->blocked_richmedia_creative_attr_map = 1;
	strcpy(fte_additional_parameters.in_server_req_params->rich_media_technologies, "richmedia");
	strcpy(fte_additional_parameters.in_server_req_params->ad_expansion_direction, "adexpansion");


        //test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(deal_criteria.richmedia_creative_attr_evaluation_result, RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL);
        assert_int_equal(is_applicable, 0);
}
static void test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_condition1_1_fails(void **state){
        (void) state;

	initialize_variables();
	
	//test case specific setup
        set_bit(RICHMEDIA_CREATIVE_ATTRIBUTE, &deal_criteria.active_entities_bitmap);
        deal_criteria.ad_type_id_evaluation_result = RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL;
	deal_criteria.richmedia_allowed_creative_attr = 1;
	fte_additional_parameters.in_server_req_params->blocked_richmedia_creative_attr_map = 1;

        //test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(deal_criteria.richmedia_creative_attr_evaluation_result, RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL);
        assert_int_equal(is_applicable, 0);
}
static void test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_condition1_2_fails(void **state){
        (void) state;

	initialize_variables();
	
	//test case specific setup
        set_bit(RICHMEDIA_CREATIVE_ATTRIBUTE, &deal_criteria.active_entities_bitmap);
        deal_criteria.richmedia_creative_attr_evaluation_result = RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL;
	deal_criteria.richmedia_allowed_creative_attr = 1;
	fte_additional_parameters.in_server_req_params->blocked_richmedia_creative_attr_map = 1;
	strcpy(fte_additional_parameters.in_server_req_params->rich_media_technologies, "richmedia");
	strcpy(fte_additional_parameters.in_server_req_params->ad_expansion_direction, "adexpansion");

        //test call and assertion
        int is_applicable = is_deal_criterion_applicable( &fte_additional_parameters, &adcampaigns, &deal_criteria, in_ad, &rt_response_param, &ctr_deal_list, 0, 0, impr);
        assert_int_equal(deal_criteria.richmedia_creative_attr_evaluation_result, RICHMEDIA_CREATIVE_ATRIBUTE_EVALUATION_FAIL);
        assert_int_equal(is_applicable, 0);
}

static void test_evaluate_publisher_requested_deal(void ** state){
	deal_params_t deal;
	publisher_requested_pmp_t pub_pmp_obj;
	int debug_deal_meta = 34;
	char* impression_id = "6789-7895-3432-8957";
	long camp_id = 89;

	//TEST CASE 1 : publisher owned , feature flag enabled, present in pmp json
	int is_deal_applicable = 0;
	deal.publisher_owned = 1;
	deal.deal_level_feature_flag = 16;
	deal.deal_meta_id = 34;
	strcpy(deal.pub_deal_id, "ASD0");
	deal.deal_id = 1;	
	pub_pmp_obj.ndeals = 2;
	pub_pmp_obj.deals[0] = (publisher_request_deal_t *)malloc(sizeof(publisher_request_deal_t));
	pub_pmp_obj.deals[1] = (publisher_request_deal_t *)malloc(sizeof(publisher_request_deal_t));

	strcpy(pub_pmp_obj.deals[0]->id, "ASD0");
	strcpy(pub_pmp_obj.deals[1]->id, "ASD2");

	is_deal_applicable= evaluate_publisher_requested_deal(&deal, &pub_pmp_obj, debug_deal_meta, impression_id, camp_id);
	assert_int_equal(is_deal_applicable, 1);

	//TEST CASE 2 : pubmatic owned , feature flag enabled, present in pmp json
	deal.publisher_owned = 0;
	is_deal_applicable= evaluate_publisher_requested_deal(&deal, &pub_pmp_obj, debug_deal_meta, impression_id, camp_id);
	assert_int_equal(is_deal_applicable, 1);

	//TEST CASE 3 : publisher owned , feature flag enabled, not present in pmp json
	strcpy(pub_pmp_obj.deals[0]->id, "ASD0");
	deal.publisher_owned = 1;
	is_deal_applicable= evaluate_publisher_requested_deal(&deal, &pub_pmp_obj, debug_deal_meta, impression_id, camp_id);
	assert_int_equal(is_deal_applicable, 1);

	//TEST CASE 4 : publisher owned , feature flag enabled, pmp obj ndeals  = 0
	pub_pmp_obj.ndeals = 0;
	is_deal_applicable= evaluate_publisher_requested_deal(&deal, &pub_pmp_obj, debug_deal_meta, impression_id, camp_id);
	assert_int_equal(is_deal_applicable, 0);

	//TEST CASE 5 : publisher owned , feature flag enabled, pmp json NULL
	is_deal_applicable= evaluate_publisher_requested_deal(&deal, NULL, debug_deal_meta, impression_id, camp_id);
	assert_int_equal(is_deal_applicable, 0);

	//TEST CASE 6 : publisher owned , feature flag disabled, present in pmp json
	deal.deal_level_feature_flag = 15;
	is_deal_applicable= evaluate_publisher_requested_deal(&deal, &pub_pmp_obj, debug_deal_meta, impression_id, camp_id);
	assert_int_equal(is_deal_applicable, 1);

}

int main(){
        const struct CMUnitTest test_encrypt[] = { 
		//Active entity SOURCE
			    cmocka_unit_test(test__is_deal_criterion_applicable__SOURCE_all_inventory_ssp_req),
                cmocka_unit_test(test__is_deal_criterion_applicable__SOURCE_all_inventory_phoenix_req),
                cmocka_unit_test(test__is_deal_criterion_applicable__SOURCE_ssp_req),
                cmocka_unit_test(test__is_deal_criterion_applicable__SOURCE_phoenix_req),
                cmocka_unit_test(test__is_deal_criterion_applicable__SOURCE_unapplicable_deal_case_1),
               	cmocka_unit_test(test__is_deal_criterion_applicable__SOURCE_unapplicable_deal_case_2),
               	cmocka_unit_test(test__is_deal_criterion_applicable__SOURCE_already_evaluated_success),
               	cmocka_unit_test(test__is_deal_criterion_applicable__SOURCE_already_evaluated_fail),
				
		//Active entity PLATFORM_ID
               	cmocka_unit_test(test__is_deal_criterion_applicable__PLATFORM_ID_targeted_applicable_deal),
               	cmocka_unit_test(test__is_deal_criterion_applicable__PLATFORM_ID_targeted_inapplicable_deal),
                cmocka_unit_test(test__is_deal_criterion_applicable__PLATFORM_already_evaluated_success),
				cmocka_unit_test(test__is_deal_criterion_applicable__PLATFORM_already_evaluated_fail),
			
		//Active entity AD_TYPE_ID
                cmocka_unit_test(test__is_deal_criterion_applicable__AD_TYPE_ID_all_conditions_pass),
                cmocka_unit_test(test__is_deal_criterion_applicable__AD_TYPE_ID_only_AD_TYPE_TEXT_IMAGE_pass),
                cmocka_unit_test(test__is_deal_criterion_applicable__AD_TYPE_ID_only_equality_condition_pass),
                cmocka_unit_test(test__is_deal_criterion_applicable__AD_TYPE_ID_both_fail),
                cmocka_unit_test(test__is_deal_criterion_applicable__AD_TYPE_ID_already_evaluated_pass),
                cmocka_unit_test(test__is_deal_criterion_applicable__AD_TYPE_ID_already_evaluated_fail),
			
		//Active entity RICHMEDIA_CREATIVE_ATTRIBUTE
		//Richmedia creative attribute validation is done everytime; irrespective of the attribute being previously checked
                cmocka_unit_test(test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_all_conditions_pass_org_pass),
                cmocka_unit_test(test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_all_conditions_pass_org_fail),
                cmocka_unit_test(test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_condition2_1_fails),
                cmocka_unit_test(test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_condition2_2_fails),
                cmocka_unit_test(test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_condition1_1_fails),
                cmocka_unit_test(test__is_deal_criterion_applicable__RICHMEDIA_CREATIVE_ATTRIBUTE_condition1_2_fails),
                cmocka_unit_test(test_evaluate_publisher_requested_deal),
				cmocka_unit_test(test__is_deal_criterion_applicable__playback_method_targeted_inapplicable_deal),
        };
        return cmocka_run_group_tests(test_encrypt, NULL, NULL);
}
