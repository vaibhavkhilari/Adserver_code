/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include <stdio.h>
#include <unistd.h>
#include <curl/curl.h>
#include <curl/multi.h>
#include <poll.h>
#include <sys/epoll.h>
#include <unistd.h>
#include <typedefs.h>
#include <rt_types.h>
#include <rtb_util.h>
#include <rt_adaptermap.h>
#include <ad_server_types.h>
#include <rt_campaign_config.h>
#include <netinet/in.h>
#include "campaign_data_provider_data.h"
#include "url_blocklist.h"
#include "cache_publisher_site_iframe_buster_tech.h"
#include "deal.h"
#include "mobile_header.h"
#include <error.h>
#include <errno.h>
#include "video.h"
#include "http_response_wrapper.h"
#include "win_loss_notification.h"
#include "url_categorization.h"
#include "mbf.h"
#include "rt_bidding.h"
#include "json_wrapper.h"
#include "adserver_control_parameter_cache.h"
#include <sys/timerfd.h>
#include "alpha2_to_alpha3_map.h"
#include "json_wrapper.h"
#include "openrtb_common_util.h"
//
#include <assert.h>
#include "curlstat_util.h"
extern int g_rtb_ms_connection_timeout;
extern int g_rtb_ms_timeout;
//extern int g_rtb_enable_persistent_connections;
//extern int g_connection_reuse_info;
//extern int g_rtb_curl_handle_reinit_value;
extern int g_mob_nw_timeout;
extern int g_rtb_integral_enabled;
extern int g_curlstat_enabled_flag;
extern int g_allow_config_reload_flag;

extern void json_append_fixed_value_string(char **buff, const char *name, int len, int add_separator);
extern const char * get_alpha3_from_alpha2(const char *country);
extern const char* get_header_value( const http_header_map_t* header_map, const char* key);
static void json_encode_string(char **buff, char *name, char *value, int add_separator);
void json_encode_double_truncated(char **buff, char *name, double value, int add_separator);

#define MAX_INVENTORY_ID_LEN  24
#define MAX_EVENTS 5 * MAX_REALTIME_REQUESTS
#define ADD_COMMA 1
#define DONT_ADD_COMMA 0

#define INITIAL_STRING "{"
#define ADD_COMMA        1
#define DONT_ADD_COMMA   0
#define EXCLUDE_STRING "\"exclude\":{"
//#define BRANDS_STRING "\"brands\":"
//#define CATEGORIES_STRING "creative_categories:"
#define CATEGORIES_STRING "\"creative_attributes\":"
//#define VERTICALS_STRING "ad_verticals:"
#define ADVT_CATEGORIES "\"creative_categories\":"
#define ADVT_IAB_CATEGORIES "\"bcat\":"
#define URLS_STRING "\"urls\":"
#define EXCLUDE_END_STRING "}"

#define RICH_MEDIA_SITE_ATTRIBUTES_STRING "\"site_richmedia_attributes\":{"
#define RICH_MEDIA_CREATIVE_ATTRIBUTES_STRING "\"richmedia_creative_attributes\":"
#define RICH_MEDIA_SUPPORTED_TECHNOLOGIES "\"richmedia_supported_technologies\":"
#define RICH_MEDIA_AD_EXPANSION_DIRECTION "\"expansion_direction\":"
#define RICH_MEDIA_AD_RUNTIME_VERIFIED "\"runtime_verified\":"
#define RICH_MEDIA_END_STRING "}"

//New rich media Params
#define RICH_MEDIA_STRING   "\"rm\":{"
#define RM_SUPPORTED_TECH   "\"ifb\":"
#define RM_AD_EXPANSION_DIR "\"expdir\":"   
#define RICH_MEDIA_END_STRING "}"

#define URL_CATEGORIES_STRING  "\"pagecat\":"
#define BRAND_SAFETY_SCORE  "\"bsc\":"

#define MOBILE_PARAMS_STRING                "\"mobile\":{"
#define MOBILE_DEVICE_PARAMS_STRING         "\"device\":{"
#define MOBILE_DEVICE_PARAMS_STRING_END     "}"
#define MOBILE_ORIGIN_PARAMS_STRING         "\"origin\":{"
#define MOBILE_ORIGIN_PARAMS_STRING_END     "}"
#define MOBILE_USER_PARAMS_STRING           "\"user\":{"
#define MOBILE_USER_PARAMS_STRING_END       "}"
#define MOBILE_MISC_PARAMS_STRING           "\"misc\":{"
#define MOBILE_MISC_PARAMS_STRING_END       "}"
#define MOBILE_PARAMS_STRING_END            "}"

#define ETHNICITY_STRING          "ethnicity"
#define INCOME_STRING             "income"
#define CARRIER_USER_ID         "cuid"
#define CARRIER_USER_ID_TYPE    "cuidtype"
#define CARRIER_USER_ID_TYPE_VERIZON    1

#define DEVICE_TYPE_STRING      "devicetype"

#define FLASH_VERSION_STRING    "flashver"

#define GEO_PARAMS_STRING         "\"geo\":{"
#define COUNTRY_STRING            "country"
#define STATE_STRING              "state"
#define CITY_STRING               "city"
#define LATITUDE_STRING           "lat"
#define LONGITUDE_STRING          "lon"
#define DMA_STRING                "dma"
#define GEO_SOURCE_TYPE_STRING    "geo_type"
#define LOC_CAT_STRING                  "\"cat\":"
#define LOC_BRAND_STRING                "\"brand\":"
#define LOC_CAT_SRC_STRING          "loccatsrc"

#define LOC_SOURCE_TYPE_STRING    "loc_source"
#define GEO_PARAMS_STRING_END     "}"

#define GDPR_REQUEST_VALUE "\"gdpr\":"
#define GDPR_CONSENT_VALUE "\"consent\":"
#define GDPR_GOOGLE_EB_CP_LIST "\"consented_providers\":"

#define CONTEXTUAL_BRAND_SAFETY_DATA            "\"contextual_brand_safety_data\":["
#define CONTEXTUAL_BRAND_SAFETY_DATA_OBJ        "{"
#define DATA_PROVIDER_PROVIDER                  "provider"
#define DATA_PROVIDER_DATA_SCOPE                "scope"
#define DATA_PROVIDER_DATA_TYPE                 "type"
#define CONTEXTUAL_BRAND_SAFETY_DATA_OBJ_END    "}"
#define CONTEXTUAL_BRAND_SAFETY_DATA_END        "]"
#define ADTRUTH_RTB_JSON "\"adtruth_rtb_json\":"

#define NET_TYPE_STRING "nettype" 

#define APP_DOMAIN_STRING "domain"

#define END_STRING "}"

#define NEED_TO_PASS_EXCLUDE_LIST(BLOCKED_LIST, RT_REQ_MASK, RICH_MEDIA_PARAMS, REQ_PARAMS) ({       \
        ( (BLOCKED_LIST) != NULL &&                                                                  \
          (((RT_REQ_MASK)->use_creative_attributes == 1 &&                                           \
            (BLOCKED_LIST)->json_blocked_creative_attributes_len > 0) ||                         \
           ((RT_REQ_MASK)->use_creative_categories == 1 &&                                           \
            (BLOCKED_LIST)->json_blocked_advt_categories_len > 0) ||                             \
       ((RT_REQ_MASK)->use_creative_categories == 1 &&                       \
        (BLOCKED_LIST)->json_blocked_iab_advt_categories_len > 0) ||                 \
           ((RT_REQ_MASK)->use_url_blocklist == 1 &&                                                 \
            (BLOCKED_LIST)->json_url_blockedlist_len > 0) ||                                         \
       ((RT_REQ_MASK)->use_creative_attributes == 1 &&                                           \
         ((REQ_PARAMS)->blocked_creative_attr[0] != '\0' ))                                        \
          )                                                                                          \
        );                                                                                           \
})

#define MAX_AD_EXPANDION_DIR_STR_LEN 5
#define MAX_AD_RUNTIME_VERIFIED_LEN 1

#ifdef min
#undef min
#endif
#ifdef max
#undef max
#endif

#define min(a, b) (((a) < (b)) ? (a) : (b))
#define max(a, b) (((a) > (b)) ? (a) : (b))

//append value if there is any new protocol is introduced
static int pubmatic_ortb_protocol_mapping[] = {
	PROTOCOL_VAST_INVALID,
	PROTOCOL_VAST_1_0_INLINE,
	PROTOCOL_VAST_2_0_INLINE_ONLY,
	PROTOCOL_VAST_3_0_INLINE_ONLY,
	PROTOCOL_VAST_1_0,
	PROTOCOL_VAST_2_0,
	PROTOCOL_VAST_3_0,
	PROTOCOL_VAST_4_0_INLINE_ONLY,
	PROTOCOL_VAST_4_0
};
void json_encode_double_truncated(char **buff, char *name, double value, int add_separator);

static int NEED_TO_PASS_USER_PARAMS(
	const rt_request_params_t* in_request_params,
	const psc_t psc
)
{
		if(
				(
				 in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE
				 &&
				 in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE
				)
				&& 
				(
					psc.disable_user_data_over_rtb == 0
				)
				&&
				(
 				 (in_request_params->in_server_req_params->year_of_birth[0] != '\0')
					|| 
				 (in_request_params->in_server_req_params->gender[0] != '\0')
					|| 
				 (in_request_params->in_server_req_params->ethnicity[0] != '\0')
					||
				 (in_request_params->in_server_req_params->income[0] != '\0')
				 	||
				(in_request_params->in_server_req_params->zip_code[0] != '\0')
					|| 
				(in_request_params->in_server_req_params->country[0] != '\0') 
					||
				(in_request_params->in_server_req_params->state[0] != '\0')
					 ||
				(in_request_params->in_server_req_params->city[0] != '\0')
					||
				(in_request_params->in_server_req_params->keywords[0] != '\0')
					||
				(in_request_params->in_server_req_params->verizon_id[0] != '\0')
		 	 )
		  )
		 {
				  return 1;
		  }
		return 0;

}

static int NEED_TO_PASS_MOBILE_PARAMS(
		const rt_request_url_params_mask_t* req_mask,
		const ad_server_req_param_t* req_params
		)
{
	if (
			(
       req_params->is_mobile_device == MOBILE_INVENTORY
       ||
			 req_params->mobile_request_type == ADS_MOB_WEB_REQUEST 
			 ||
			 req_params->mobile_request_type == ADS_MOB_APP_REQUEST
			)
			&&
			(
			 req_mask->use_mobile_params == 1
			)
			&&
			(
			 req_params->mobile_device_make[0] != '\0'
			 ||
			 req_params->mobile_device_model[0] != '\0'
			 ||
			 req_params->mobile_device_location[0] != '\0'
			 ||
			 req_params->mobile_device_os[0] != '\0'
			 ||
			 req_params->mobile_data.application_api[0] != '\0'
             ||
             req_params->mobile_data.application_bundle[0] != '\0'
             ||
             req_params->mobile_data.application_id[0] != '\0'
             ||
             req_params->mobile_data.application_name[0] != '\0'
             ||
             req_params->mobile_data.application_version[0] != '\0'
			)
		 )
		 {
			 return 1;
		 }
	return 0;
}

static inline int NEED_TO_PASS_RM_PARAM(const rt_request_url_params_mask_t* req_mask,  const ad_server_req_param_t* req_params) {
	if ( (req_mask->use_rich_media_params == 1) && 
	     (req_params->rich_media_technologies[0] != '\0' || req_params->ad_expansion_direction[0] != '\0')
	   ) {
		return 1;
	}
	return 0;	
}

#define ADD_SEPARATOR               1
#define DO_NOT_ADD_SEPARATOR        0

//video related macros
#define VIDEO_PARAMS_STRUCT (in_request_params->in_server_req_params->video_params)
#define IS_VIDEO_REQUEST (in_request_params->in_server_req_params->oper_id==SERV_ADS_VIDEO_OPER)
#define VIDEO_PARAMS_STRING "\"video\":{"
#define VIDEO_TYPE "\"type\":"
#define VIDEO_POSITION "\"pos\":"
#define VIDEO_MIN_LEN "\"minLen\":"
#define VIDEO_MAX_LEN "\"maxLen\":"
#define VIDEO_HAS_COMP "\"comp\":"
#define VIDEO_MIN_BTR "\"minBitRate\":"
#define VIDEO_MAX_BTR "\"maxBitRate\":"
#define VIDEO_STREAM_FORMAT_JSON_KEY "\"streamFmt\":["
#define VIDEO_AD_FORMAT "\"adFmt\":"
#define VIDEO_COMP_WIDTH "\"compW\":"
#define VIDEO_COMP_HEIGHT "\"compH\":"
#define VIDEO_API "\"api\":"
#define VIDEO_RESP_FORMAT "\"resFmt\":"
#define VIDEO_PG_CONT "\"context\":"
#define VIDEO_PLAYBACK_JSON_KEY "\"playbackmethod\":["
#define VIDEO_PLAYER_HEIGHT "\"h\":"
#define VIDEO_PLAYER_WIDTH  "\"w\":"
#define VIDEO_WINDOW_HEIGHT "\"wndh\":"
#define VIDEO_WINDOW_WIDTH  "\"wndw\":"
#define VIDEO_AD_HEIGHT     "\"adh\":"
#define VIDEO_AD_WIDTH			"\"adw\":"
#define VIDEO_WINDOW_PAGE_URL "wndurl"
#define VIDEO_WINDOW_REF_URL  "wndref"
#define VIDEO_IFRAME_DEPTH    "\"depth\":"
#define VIDEO_ASPECT_RATIO "\"ar\":"
#define VIDEO_PLAYER_STRETCHING_MODE "\"sm\":"
#define VIDEO_LANGUAGE "\"vcln\":"

#define VIDEO_SKIP          "\"skip\":"
#define VIDEO_SKIP_DELAY    "\"skipdelay\":"
#define VIDEO_NOSKIP_AD_LEN "\"noskipadlen\":"

#define VIDEO_AUDIO_FLAG          "\"audio\":"

#define VIDEO_PARAMS_STRING_END "}"

/*
Native specific params
#define IS_NATIVE_REQUEST (in_request_params->in_server_req_params->ad_type==AD_TYPE_NATIVE)
#define NATIVE_PARAMS_STRING "\"native\":{"
#define NATIVE_API_VER "\"nver\":"
#define NATIVE_ADM_SUPPORT "\"admsupport\":"
#define NATIVE_ADM_SUPPORT_DEFAULT_VALUE "[\"title\",\"text\",\"img\",\"icon\",\"ctatext\",\"rating\"]"
#define NATIVE_ADM_SUPPORT_TITLE "title"
#define NATIVE_ADM_SUPPORT_TEXT "text"
#define NATIVE_ADM_SUPPORT_IMAGE "img"
#define NATIVE_ADM_SUPPORT_ICON "icon"
#define NATIVE_ADM_SUPPORT_CTATEXT "ctatext"
#define NATIVE_ADM_SUPPORT_RATING "rating"
#define NATIVE_IMG_RATIO "\"imgratio\":"
#define NATIVE_SEQ_NUM "\"seq\":"
#define NATIVE_ICON_SIZE "\"iconSz\":"
#define NATIVE_IMAGE_SIZE "\"imgSz\":"
#define NATIVE_TITLE_LEN "\"titleln\":"
#define NATIVE_DESC_LEN "\"descln\":"
#define NATIVE_CTA_LEN "\"ctaln\":"
#define NATIVE_PARAMS_STRING_END "}"
*/

extern struct curl_slist* header_list_get;
extern struct curl_slist* header_list_post;

/*
 * Check whether given IP Address is of the form A.B.C.D or not.
 * Returns: On Success :- 1.
 *          On Failure :- 0.
 */
int is_full_ip_address(char *ip_address)
{
       int dot_count;

       //Sanity Checks.
       if (ip_address == NULL)
       {
           return 0;
	}

       //Parse IP to find number of occurrences of ".".
       dot_count = 0;
       while (*ip_address != '\0')
	{
		if (*ip_address == '.')
		{
                	dot_count++;
		}
            	ip_address++;
	}

	return (dot_count == 3)? 1: 0;
}

int is_ipv4_address(const char *ip_address){
	int status = 0;
	if ( strchr( ip_address , '.' ) ){
		status = 1;
	}
	return status;
}

/*
 * Append pubmatic payment tag id to payment tag id chain
 */

int append_pubmatic_pay_tagid(
		cache_handle_t *cache, db_connection_t *dbconn,
		const publisher_level_settings_t *publisher_level_settings,
		long pub_id, char *payment_tagid_chain) {
	int payment_chain_tagid_len=0;
	char cp_pubmatic_payment_tagid[MAX_PUBMATIC_PAYMENT_TAGID_LEN + 1];
	cp_pubmatic_payment_tagid[0]='\0';
	int retval = ADS_ERROR_SUCCESS;
	retval = cache_get_pubmatic_payment_tagid(cache, dbconn, cp_pubmatic_payment_tagid);
	if (ADS_ERROR_SUCCESS != retval || ('\0' == cp_pubmatic_payment_tagid[0])){
		payment_tagid_chain[0] = '\0';
		return ADS_ERROR_NOT_FOUND;
	}
	if((1 == publisher_level_settings->is_aggregator && 1 == publisher_level_settings->acl_aggregator_flag)
			|| '\0' != payment_tagid_chain[0]){
		strcat(payment_tagid_chain, PAYMENT_TAGID_SEPRATOR);
	}   
	payment_chain_tagid_len = strlen(payment_tagid_chain);
	snprintf( payment_tagid_chain+payment_chain_tagid_len, MAX_PAYMENT_TAGID_CHAIN_LEN-payment_chain_tagid_len, "%s:%ld", 
			cp_pubmatic_payment_tagid,pub_id);
	return ADS_ERROR_SUCCESS;
}
/*
 * Encode given string in JSON form.
 */
static void json_encode_string(char **buff, char *name, char *value, int add_separator)
{
       if (buff == NULL ||
           name == NULL ||
           value == NULL)
       {
           return;
       }

       if (add_separator == 1)
       {
           memcpy(*buff, ",", strlen(","));
           *buff += strlen(",");
       }
       memcpy(*buff, "\"", strlen("\""));
       *buff += strlen("\"");
       memcpy(*buff, name, strlen(name));
       *buff += strlen(name);
       memcpy(*buff, "\":\"", strlen("\":\""));
       *buff += strlen("\":\"");
       memcpy(*buff, value, strlen(value));
       *buff += strlen(value);
       memcpy(*buff, "\"", strlen("\""));
       *buff += strlen("\"");
}

/*
 * Encode given integer in JSON form.
 */
static void json_encode_integer(char **buff, char *name, int value, int add_separator)
{
       char int_str[80 + 1];

       if (buff == NULL ||
           name == NULL)
       {
           return;
       }

       if (add_separator == 1)
       {
           memcpy(*buff, ",", strlen(","));
           *buff += strlen(",");
       }
       memcpy(*buff, "\"", strlen("\""));
       *buff += strlen("\"");
       memcpy(*buff, name, strlen(name));
       *buff += strlen(name);
       memcpy(*buff, "\":", strlen("\":"));
       *buff += strlen("\":");
       sprintf(int_str, "%d", value);
       memcpy(*buff, int_str, strlen(int_str));
       *buff += strlen(int_str);
}

static void json_encode_double(char **buff, char *name, double value, int add_separator)
{
  char float_str[80 + 1];

  if (buff == NULL ||
      name == NULL)
  {
    return;
  }

  if (add_separator == 1)
  {
    memcpy(*buff, ",", strlen(","));
    *buff += strlen(",");
  }
  memcpy(*buff, "\"", strlen("\""));
  *buff += strlen("\"");
  memcpy(*buff, name, strlen(name));
  *buff += strlen(name);
  memcpy(*buff, "\":", strlen("\":"));
  *buff += strlen("\":");
  sprintf(float_str, "%.9g", value);
  memcpy(*buff, float_str, strlen(float_str));
  *buff += strlen(float_str);
}


static void replace_special_char(char *input) {
	int j = 0;

	char special_chars[] = {'\'','\"'};
	if (input == NULL) {
		return ;
	}
	while(*input) {
		for (j = 0; special_chars[j]; j++) { 
			if (*input == special_chars[j]) {
				*input = ' ';
				break;
			}
		}
		input++;
	}
	*input = '\0';
}


/* Function specification:-
 *
 * Deserialize an integer sent in network byte order
 *
 */
char* deserialize_int(unsigned char* buf, int* n) {
	*n=0;
	*n|=buf[0]<<24;
	*n|=buf[1]<<16;

	*n|=buf[2]<<8;
	*n|=buf[3];
	return (char *)(buf+4);
}


/*
 * Function specification:-
 * This function returns the length of post_data field and *flag indicates whether post_data is empty or
 * not. *flag should be 0 before this function is called. 
 * No errors defined
 *
 */
static int get_post_data(char* post_data,
			 campaign_data_provider_data_ops_params_t *cmpg_dp_params,
			 rt_request_params_t *in_request_params,
			 const rt_request_url_params_mask_t * rt_request_url_params_mask1,
			 ad_server_additional_params_t *additional_parameter,
			 publisher_site_ad_campaign_list_t *adcampaign,
			 rt_response_params_t *out_response_params,
			 int* flag,
			 publisher_site_ad_campaign_list_t *adcampaigns_list,
			 int nelements,
			 int current_index
			 )
{
	(void) out_response_params;
	(void) adcampaigns_list;
	(void) nelements;
	(void) current_index;
	char* post_temp_ptr=post_data;
	char* temp_ptr = NULL;
	publisher_site_ad_rich_media_params_t *pub_site_rich_media_params = in_request_params->pub_site_rich_media_params;
	//char ad_expansion_dir_str[MAX_AD_EXPANDION_DIR_STR_LEN + 1];
	memcached_blocklist_t *blocked_list;
	const psc_t psc = adcampaign->ad_campaign_list_setings->psc;
	integral_data_t *integral_data;
	char buff[256 + 1];
	int has_mobile_params = 0;
	int has_origin_params = 0;
	int has_user_params = 0;
	int has_misc_params = 0;
	int has_geo_params = 0;
	int loc_info_sent = 0;
	char *country = NULL;
	char *state = NULL;
	char *city = NULL;
	int *dma = NULL;
	int dma_code = 0;
	float *latitude = NULL;
	float *longitude = NULL;
	char *postal_code = NULL;
	//int *geo_source_type = NULL;
	campaign_data_provider_data_t *cmpg_dp_data = NULL;
	int i;
	int vid_post_len;
	int bytes_written = 0;
	//int native_post_len = 0;
	char *video_ptr = NULL;

	float lat = 0.0, lon = 0.0, count = 0;
	const ad_server_req_param_t* req_params = in_request_params->in_server_req_params;

	int is_mob_impression = 0;
	bool lat_lon_masking_enabled =  adcampaign->ad_campaign_list_setings->lat_lon_masking_enabled;

    if (
            in_request_params->in_server_req_params->is_mobile_device == MOBILE_INVENTORY
            ||
            in_request_params->in_server_req_params->mobile_request_type == ADS_MOB_WEB_REQUEST
            ||
            in_request_params->in_server_req_params->mobile_request_type == ADS_MOB_APP_REQUEST
    ) {
        is_mob_impression = 1;
    }

	//Initialized post_data.
	post_data[0] = '\0';

	integral_data=&(in_request_params->fte_additional_params->integral_data);
	blocked_list = pub_site_rich_media_params->blocked_list;
	temp_ptr = (blocked_list != NULL)? (blocked_list->json_url_blocked_list + 4): NULL;

	strncpy(post_temp_ptr, INITIAL_STRING, sizeof(INITIAL_STRING) - 1);
	post_temp_ptr += sizeof(INITIAL_STRING) - 1;

	/* OTF BLocklist : Blocked adveriser domains to replace blocked urls from DB(if present)  */
	int otf_blocklist_enabled = 0;
	int otf_adv_dom_present = 0;
	int otf_cat_id_present  = 0;

	otf_blocklist_enabled = additional_parameter->pubsite_default_settings.pass_n_block_advt_info_enabled;

	/* Append GDPR parameters here */

	if(otf_blocklist_enabled  == 1 && in_request_params->in_server_req_params->blk_adv_dom_count > 0  && in_request_params->in_server_req_params->blk_adv_dom_json[0] != '\0') {
	    otf_adv_dom_present = 1;
	} 

	if( otf_blocklist_enabled == 1 && in_request_params->in_server_req_params->blk_cat_id_count > 0  && in_request_params->in_server_req_params->blk_cat_id_json[0] != '\0') {
	    otf_cat_id_present = 1;	    
	}	


	if(otf_cat_id_present == 1 || otf_adv_dom_present == 1) {

	    //Start of Exclude attributes
	    strncpy(post_temp_ptr, EXCLUDE_STRING, sizeof (EXCLUDE_STRING) - 1);
		post_temp_ptr += sizeof (EXCLUDE_STRING) - 1;

		if(otf_cat_id_present == 1) {
			memcpy(post_temp_ptr, ADVT_IAB_CATEGORIES, sizeof(ADVT_IAB_CATEGORIES) - 1);
			post_temp_ptr += sizeof(ADVT_IAB_CATEGORIES) - 1;
			memcpy(post_temp_ptr, in_request_params->in_server_req_params->blk_cat_id_json, in_request_params->in_server_req_params->blk_cat_id_json_length);
		post_temp_ptr += in_request_params->in_server_req_params->blk_cat_id_json_length;
		*flag = 1;
	    }
	    
	    if(otf_adv_dom_present == 1) {
		if(*flag == 1) {
		    memcpy(post_temp_ptr,",",1);
		    post_temp_ptr++;
		}
		memcpy(post_temp_ptr, URLS_STRING, sizeof(URLS_STRING) - 1);
		post_temp_ptr += sizeof(URLS_STRING) - 1;
		
		memcpy(post_temp_ptr, in_request_params->in_server_req_params->blk_adv_dom_json, in_request_params->in_server_req_params->blk_adv_dom_json_length);
		post_temp_ptr += in_request_params->in_server_req_params->blk_adv_dom_json_length;
		*flag = 1;
	    }
	    
	}


	if( (blocked_list == NULL && (otf_adv_dom_present == 1 || otf_cat_id_present == 1)) || ((blocked_list != NULL && NEED_TO_PASS_EXCLUDE_LIST(blocked_list, rt_request_url_params_mask1, pub_site_rich_media_params, req_params) == 0) && (otf_adv_dom_present == 1 || otf_cat_id_present == 1))) {
	    //End of Exclude Attributes.
	    memcpy(post_temp_ptr, EXCLUDE_END_STRING, sizeof(EXCLUDE_END_STRING) - 1);
	    post_temp_ptr += sizeof(EXCLUDE_END_STRING) - 1;
	}	

	if (blocked_list != NULL )
	{
		if (NEED_TO_PASS_EXCLUDE_LIST(blocked_list, rt_request_url_params_mask1, pub_site_rich_media_params, req_params))
		{

		    if(otf_cat_id_present != 1 && otf_adv_dom_present != 1) {
		    	//Start of Exclude attributes
			strncpy(post_temp_ptr, EXCLUDE_STRING, sizeof (EXCLUDE_STRING) - 1);
			post_temp_ptr += sizeof (EXCLUDE_STRING) - 1;
		    }

#ifdef FUNCTIONAL_TESTING
			llog_write(L_DEBUG,"\nrt_request_url_params_mask1->use_creative_attributes=%d\n",rt_request_url_params_mask1->use_creative_attributes);
			llog_write(L_DEBUG,"\nrt_request_url_params_mask1->use_creative_categories=%d\n",rt_request_url_params_mask1->use_creative_categories);
			llog_write(L_DEBUG,"\nrt_request_url_params_mask1->use_url_blocklist=%d\n",rt_request_url_params_mask1->use_url_blocklist);
#endif
			if (	rt_request_url_params_mask1->use_creative_attributes == 1 &&
        			blocked_list->json_blocked_creative_attributes_len > 0 &&
		    	        req_params->blocked_creative_attr[0] == '\0' )
			{
				if (*flag == 1)
				{
					memcpy(post_temp_ptr,",",1);
					post_temp_ptr++;
				}
				//strncpy(post_temp_ptr,CATEGORIES_STRING,strlen(CATEGORIES_STRING));
				memcpy(post_temp_ptr, CATEGORIES_STRING, sizeof (CATEGORIES_STRING) - 1);
				post_temp_ptr += sizeof (CATEGORIES_STRING) - 1;
				//strncpy(post_temp_ptr,temp_ptr,len_creative_attributes);
				memcpy(post_temp_ptr, temp_ptr, blocked_list->json_blocked_creative_attributes_len);
				post_temp_ptr += blocked_list->json_blocked_creative_attributes_len;
				//strncpy(post_temp_ptr,",",1);
				*flag=1;
			}
			temp_ptr += (blocked_list->json_blocked_creative_attributes_len + 4);
			if (	rt_request_url_params_mask1->use_creative_categories==1 &&
        			blocked_list->json_blocked_advt_categories_len > 0 && otf_cat_id_present != 1)
			{
				if(*flag == 1)
				{
					memcpy(post_temp_ptr,",",1);
					post_temp_ptr++;
				}
				//strncpy(post_temp_ptr,ADVT_CATEGORIES,strlen(ADVT_CATEGORIES));
				memcpy(post_temp_ptr, ADVT_CATEGORIES, sizeof(ADVT_CATEGORIES) - 1);
				post_temp_ptr += sizeof(ADVT_CATEGORIES) - 1;
				//strncpy(post_temp_ptr,temp_ptr,len_creative_categories);
				memcpy(post_temp_ptr, temp_ptr, blocked_list->json_blocked_advt_categories_len);
				post_temp_ptr += blocked_list->json_blocked_advt_categories_len;			
			        
			 
				//strncpy(post_temp_ptr,",",1);
				*flag = 1;
			}
			temp_ptr += (blocked_list->json_blocked_advt_categories_len + 4);

			if (    rt_request_url_params_mask1->use_creative_categories==1 &&
                                blocked_list->json_blocked_iab_advt_categories_len > 0 && otf_cat_id_present != 1)
                        {
                                if(*flag == 1)
                                {
                                        memcpy(post_temp_ptr,",",1);
                                        post_temp_ptr++;
                                }
                                //strncpy(post_temp_ptr,VERTICALS_STRING,strlen(VERTICALS_STRING));
                                memcpy(post_temp_ptr, ADVT_IAB_CATEGORIES, sizeof(ADVT_IAB_CATEGORIES) - 1);
                                post_temp_ptr += sizeof(ADVT_IAB_CATEGORIES) - 1;
                                //strncpy(post_temp_ptr,temp_ptr,len_creative_categories);
                                memcpy(post_temp_ptr, temp_ptr, blocked_list->json_blocked_iab_advt_categories_len);
                                post_temp_ptr += blocked_list->json_blocked_iab_advt_categories_len;


                                //strncpy(post_temp_ptr,",",1);
                                *flag = 1;
                        }
                        temp_ptr += (blocked_list->json_blocked_iab_advt_categories_len + 4);

			if (	rt_request_url_params_mask1->use_url_blocklist == 1 &&
        			blocked_list->json_url_blockedlist_len > 0 && otf_adv_dom_present != 1)
			{
				if (*flag == 1)
				{
					memcpy(post_temp_ptr,",",1);
					post_temp_ptr++;
				}
				//strncpy(post_temp_ptr,URLS_STRING,strlen(URLS_STRING));
				memcpy(post_temp_ptr, URLS_STRING, sizeof(URLS_STRING) - 1);
				post_temp_ptr += sizeof(URLS_STRING) - 1;
				//strncpy(post_temp_ptr,temp_ptr,len_url);
				memcpy(post_temp_ptr, temp_ptr, blocked_list->json_url_blockedlist_len);
				post_temp_ptr += blocked_list->json_url_blockedlist_len;
				
				*flag=1;
			}
			if ( rt_request_url_params_mask1->use_creative_attributes == 1 && req_params->blocked_creative_attr[0] != '\0' ) {
				if (*flag == 1) {
					memcpy(post_temp_ptr,",",1);
					post_temp_ptr++;
				}
				memcpy(post_temp_ptr, CATEGORIES_STRING, sizeof (CATEGORIES_STRING) - 1);
				post_temp_ptr += (sizeof (CATEGORIES_STRING) - 1);
				memcpy(post_temp_ptr, req_params->blocked_creative_attr, req_params->battr_len);
				post_temp_ptr += req_params->battr_len;
				*flag=1;
			}

			//End of Exclude Attributes.
			memcpy(post_temp_ptr, EXCLUDE_END_STRING, sizeof(EXCLUDE_END_STRING) - 1);
			post_temp_ptr += sizeof(EXCLUDE_END_STRING) - 1;
		}

	}

	if (NEED_TO_PASS_RM_PARAM(rt_request_url_params_mask1, req_params)) {
		int has_rm_params = 0;
		if (*flag == 1) {
			memcpy(post_temp_ptr, ",", 1);
			post_temp_ptr++;
		}
		memcpy(post_temp_ptr, RICH_MEDIA_STRING, (sizeof (RICH_MEDIA_STRING) - 1));
		post_temp_ptr += (sizeof (RICH_MEDIA_STRING) - 1);

		if ( req_params->rich_media_technologies[0] != '\0' ) {
			memcpy(post_temp_ptr, RM_SUPPORTED_TECH, (sizeof (RM_SUPPORTED_TECH) - 1));
			post_temp_ptr += (sizeof (RM_SUPPORTED_TECH) - 1);
			memcpy(post_temp_ptr, req_params->rich_media_technologies, req_params->rmt_len);
			post_temp_ptr += req_params->rmt_len;
			has_rm_params = 1;
		}
		if ( req_params->ad_expansion_direction[0] != '\0' ) {
			if (has_rm_params == 1) {
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr++;
			}
			memcpy(post_temp_ptr, RM_AD_EXPANSION_DIR, (sizeof (RM_AD_EXPANSION_DIR) - 1));
			post_temp_ptr += (sizeof (RM_AD_EXPANSION_DIR) - 1);
			memcpy(post_temp_ptr, req_params->ad_expansion_direction, req_params->aed_len);
			post_temp_ptr += req_params->aed_len;
			has_rm_params = 1;
		}
		memcpy(post_temp_ptr, RICH_MEDIA_END_STRING, sizeof(RICH_MEDIA_END_STRING) - 1);
		post_temp_ptr += sizeof(RICH_MEDIA_END_STRING) - 1;
		*flag = 1;
	}

	if ( (rt_request_url_params_mask1->enabled_ias_services & PAGE_CAT_MAP)  && integral_data->page_categories[0] != '\0') {
		json_append_fixed_value_string(&post_temp_ptr, URL_CATEGORIES_STRING, sizeof(URL_CATEGORIES_STRING) - 1, *flag);
		json_append_fixed_value_string(&post_temp_ptr, integral_data->page_categories, integral_data->page_cat_len, DONT_ADD_COMMA);
		*flag = 1;
	}
	if ( (rt_request_url_params_mask1->enabled_ias_services & BSC_MAP) && integral_data->brand_safety_score[0] != '\0' ) {
		json_append_fixed_value_string(&post_temp_ptr, BRAND_SAFETY_SCORE, sizeof(BRAND_SAFETY_SCORE) - 1, *flag);
		json_append_fixed_value_string(&post_temp_ptr, integral_data->brand_safety_score, integral_data->bsc_len, DONT_ADD_COMMA);
		*flag = 1;
	}

	if (NEED_TO_PASS_MOBILE_PARAMS(rt_request_url_params_mask1, in_request_params->in_server_req_params))
 	{
		//Seprator.
		if (*flag == 1)
		{
			memcpy(post_temp_ptr, ",", 1);
			post_temp_ptr++;
		}

		//Start of Mobile params.
		memcpy(post_temp_ptr, MOBILE_PARAMS_STRING, (sizeof (MOBILE_PARAMS_STRING) - 1));
		post_temp_ptr += (sizeof (MOBILE_PARAMS_STRING) - 1);

		//Start of Mobile device params.
		memcpy(post_temp_ptr, MOBILE_DEVICE_PARAMS_STRING, (sizeof (MOBILE_DEVICE_PARAMS_STRING) - 1));
		post_temp_ptr += (sizeof (MOBILE_DEVICE_PARAMS_STRING) - 1);
		//We won't be receiving Device Id & Platform specific Id in case of Mobile Web request.
		if (
				in_request_params->in_server_req_params->device_id[0] != '\0'
				&&
				in_request_params->in_server_req_params->platform_specific_id[0] != '\0'
				&&
				in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE
			 )
		{

			//Device ID.
			json_encode_string(&post_temp_ptr, HASHED_DEVICE_ID, in_request_params->in_server_req_params->device_id, has_mobile_params);
                        has_mobile_params = 1;
			//Device ID type.
			if(in_request_params->in_server_req_params->udid_type[0] != '\0'){
				//TODO: The didtype should be deprecated
				json_encode_string(&post_temp_ptr, HASHED_DEVICE_ID_TYPE, in_request_params->in_server_req_params->udid_type, has_mobile_params);
				has_mobile_params = 1;

				json_encode_string(&post_temp_ptr, HASHED_DEVICE_DID_TYPE, in_request_params->in_server_req_params->udid_type, has_mobile_params);
				has_mobile_params = 1;
			}
			//Platform specific id.
			json_encode_string(&post_temp_ptr, SHA1_HASHED_PLATFORM_SPECIFIC_ID, in_request_params->in_server_req_params->platform_specific_id, has_mobile_params);
			has_mobile_params = 1;

			if (in_request_params->in_server_req_params->udid_hash >= 0 && in_request_params->in_server_req_params->udid_hash < 4) {
				json_encode_integer(&post_temp_ptr, DEVICE_ID_HASHING_TYPE, in_request_params->in_server_req_params->udid_hash, has_mobile_params);
				has_mobile_params = 1;
			}

		}
		//Mobile Carrier.
		if (in_request_params->in_server_req_params->mobile_carrier[0] != '\0')
		{
			json_encode_string(&post_temp_ptr, MOBILE_CARRIER, in_request_params->in_server_req_params->mobile_carrier, has_mobile_params);
			has_mobile_params = 1;
		}
		else if (additional_parameter->isp_name[0] != '\0')
			{
			json_encode_string(&post_temp_ptr, MOBILE_CARRIER, additional_parameter->isp_name, has_mobile_params);
                        has_mobile_params = 1;
			}
		if(in_request_params->in_server_req_params->mobile_nettype[0] != '\0'){
			json_encode_string(&post_temp_ptr, NET_TYPE_STRING, in_request_params->in_server_req_params->mobile_nettype, has_mobile_params);
			has_mobile_params = 1;
		}
                else if(additional_parameter->connection_name[0] != '\0'){
			json_encode_string(&post_temp_ptr, NET_TYPE_STRING, additional_parameter->connection_name, has_mobile_params);
			has_mobile_params = 1;
		}

		//Mobile Device make.
		if (in_request_params->in_server_req_params->mobile_device_make[0] != '\0')
		{
			if (has_mobile_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}

			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);
			memcpy(post_temp_ptr, MOBILE_DEVICE_MAKE, (sizeof (MOBILE_DEVICE_MAKE) - 1));
			post_temp_ptr += (sizeof (MOBILE_DEVICE_MAKE) - 1);
			memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
			post_temp_ptr += (sizeof ("\":\"") - 1);
			memcpy(post_temp_ptr,
				in_request_params->in_server_req_params->mobile_device_make,
				strlen(in_request_params->in_server_req_params->mobile_device_make));
			post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_device_make);
			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);

			has_mobile_params = 1;
		}
		//Mobile Device Model.
		if (in_request_params->in_server_req_params->mobile_device_model[0] != '\0')
		{
			if (has_mobile_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}

			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);
			memcpy(post_temp_ptr, MOBILE_DEVICE_MODEL, (sizeof(MOBILE_DEVICE_MODEL) - 1));
			post_temp_ptr += (sizeof(MOBILE_DEVICE_MODEL) - 1);
			memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
			post_temp_ptr += (sizeof ("\":\"") - 1);
			memcpy(post_temp_ptr,
				in_request_params->in_server_req_params->mobile_device_model,
				strlen(in_request_params->in_server_req_params->mobile_device_model));
			post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_device_model);
			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);

			has_mobile_params = 1;
		}
		//Mobile Device OS.
		if (in_request_params->in_server_req_params->mobile_device_os[0] != '\0')
		{
			if (has_mobile_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}

			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);
			memcpy(post_temp_ptr, MOBILE_DEVICE_OS, (sizeof (MOBILE_DEVICE_OS) - 1));
			post_temp_ptr += (sizeof (MOBILE_DEVICE_OS) - 1);
			memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
			post_temp_ptr += (sizeof ("\":\"") - 1);
			memcpy(post_temp_ptr,
				in_request_params->in_server_req_params->mobile_device_os,
				strlen(in_request_params->in_server_req_params->mobile_device_os));
			post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_device_os);
			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);

			has_mobile_params = 1;
		}
		//Mobile Device OS version.
		if (in_request_params->in_server_req_params->mobile_device_os_version[0] != '\0')
		{
			if (has_mobile_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}

			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);
			memcpy(post_temp_ptr, MOBILE_DEVICE_OS_VERSION, (sizeof (MOBILE_DEVICE_OS_VERSION) - 1));
			post_temp_ptr += (sizeof (MOBILE_DEVICE_OS_VERSION) - 1);
			memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
			post_temp_ptr += (sizeof ("\":\"") - 1);
			memcpy(post_temp_ptr,
				in_request_params->in_server_req_params->mobile_device_os_version,
				strlen(in_request_params->in_server_req_params->mobile_device_os_version));
			post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_device_os_version);
			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);

			has_mobile_params = 1;
		}
		//JS Enabled.
		if (in_request_params->in_server_req_params->js_enabled != -1)
		{
			if (has_mobile_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}

			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);
			memcpy(post_temp_ptr, JS_ENABLED, (sizeof (JS_ENABLED) - 1));
			post_temp_ptr += (sizeof (JS_ENABLED) - 1);
			memcpy(post_temp_ptr, "\":", (sizeof ("\":") - 1));
			post_temp_ptr += (sizeof ("\":") - 1);
			sprintf(buff, "%d", in_request_params->in_server_req_params->js_enabled);
			memcpy(post_temp_ptr,
				buff,
				strlen(buff));
			post_temp_ptr += strlen(buff);

			has_mobile_params = 1;
		}
		//Mobile Device location.
		if ( in_request_params->in_server_req_params->loc_source == 1 
		  	 && 
		  	 in_request_params->in_server_req_params->mobile_device_location[0] != '\0'
		   )
		{
			if (has_mobile_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}

			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);
			memcpy(post_temp_ptr, MOBILE_DEVICE_LOCATION, (sizeof (MOBILE_DEVICE_LOCATION) - 1));
			post_temp_ptr += (sizeof (MOBILE_DEVICE_LOCATION) - 1);
			memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
			post_temp_ptr += (sizeof ("\":\"") - 1);
			memcpy(post_temp_ptr,
				in_request_params->in_server_req_params->mobile_device_location,
				strlen(in_request_params->in_server_req_params->mobile_device_location));
			post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_device_location);
			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);

			has_mobile_params = 1;
		}

		if(in_request_params->in_server_req_params->is_tablet == 1)
		{
			json_encode_integer(&post_temp_ptr, DEVICE_TYPE_STRING, DEVICE_TYPE_TABLET, has_mobile_params);
			has_mobile_params = 1;
		}else if(in_request_params->in_server_req_params->device_type != -1)
		{
			json_encode_integer(&post_temp_ptr, DEVICE_TYPE_STRING, in_request_params->in_server_req_params->device_type, has_mobile_params);
			has_mobile_params = 1;
		}

 		//End of Mobile device params.
		memcpy(post_temp_ptr, MOBILE_DEVICE_PARAMS_STRING_END, (sizeof (MOBILE_DEVICE_PARAMS_STRING_END) - 1));
		post_temp_ptr += (sizeof (MOBILE_DEVICE_PARAMS_STRING_END) - 1);

		if (in_request_params->in_server_req_params->mobile_request_type == ADS_MOB_APP_REQUEST) {
		//Start of Mobile origin params.
		memcpy(post_temp_ptr, ",", 1);
		post_temp_ptr += 1;
		memcpy(post_temp_ptr, MOBILE_ORIGIN_PARAMS_STRING, (sizeof (MOBILE_ORIGIN_PARAMS_STRING) - 1));
		post_temp_ptr += (sizeof (MOBILE_ORIGIN_PARAMS_STRING) - 1);

		//Application id.
    if (in_request_params->in_server_req_params->mobile_data.application_id[0] != '\0')  {
      if (has_origin_params == 1)
      {
        memcpy(post_temp_ptr, ",", 1);
        post_temp_ptr += 1;
      }
      memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
      post_temp_ptr += (sizeof ("\"") - 1);
      memcpy(post_temp_ptr, APPLICATION_ID, (sizeof (APPLICATION_ID) - 1));
      post_temp_ptr += (sizeof (APPLICATION_ID) - 1);
      memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
      post_temp_ptr += (sizeof ("\":\"") - 1);
      //sprintf(buff, "%d", in_request_params->in_server_req_params->mobile_data.application_id);
      memcpy(post_temp_ptr,
          in_request_params->in_server_req_params->mobile_data.application_id,
          strlen(in_request_params->in_server_req_params->mobile_data.application_id));
      post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_data.application_id);
      memcpy(post_temp_ptr, "\"", 1);
      post_temp_ptr += 1;
      has_origin_params = 1;
    }
		//Application Name,
		if (in_request_params->in_server_req_params->mobile_data.application_name[0] != '\0') {
			if (has_origin_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}
			memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
			post_temp_ptr += (sizeof ("\"") - 1);
			memcpy(post_temp_ptr, APPLICATION_NAME, (sizeof (APPLICATION_NAME) - 1));
			post_temp_ptr += (sizeof (APPLICATION_NAME) - 1);
            memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
            post_temp_ptr += (sizeof ("\":\"") - 1);
            memcpy(post_temp_ptr,
                in_request_params->in_server_req_params->mobile_data.application_name,
                strlen(in_request_params->in_server_req_params->mobile_data.application_name));
            post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_data.application_name);
            memcpy(post_temp_ptr, "\"", 1);
            post_temp_ptr += 1;

            has_origin_params = 1;

		}
		//Application Store URL
    if (in_request_params->in_server_req_params->mobile_data.store_url[0] != '\0') {
      if (has_origin_params == 1)
      {
        memcpy(post_temp_ptr, ",", 1);
        post_temp_ptr += 1;
      }
      memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
      post_temp_ptr += (sizeof ("\"") - 1);
      memcpy(post_temp_ptr, APP_STORE_URL, (sizeof (APP_STORE_URL) - 1));
      post_temp_ptr += (sizeof (APP_STORE_URL) - 1);
      memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
      post_temp_ptr += (sizeof ("\":\"") - 1);
      memcpy(post_temp_ptr,
          in_request_params->in_server_req_params->mobile_data.store_url,
          strlen(in_request_params->in_server_req_params->mobile_data.store_url));
      post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_data.store_url);
      memcpy(post_temp_ptr, "\"", 1);
      post_temp_ptr += 1;

      has_origin_params = 1;
    }

		//Application Version.
		if (in_request_params->in_server_req_params->mobile_data.application_version[0] != '\0')
 		{
			if (has_origin_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}
			memcpy(post_temp_ptr, "\"", 1);
			post_temp_ptr += 1;
			memcpy(post_temp_ptr, APPLICATION_VERSION, (sizeof (APPLICATION_VERSION) - 1));
			post_temp_ptr += (sizeof (APPLICATION_VERSION) - 1);
			memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
			post_temp_ptr += (sizeof ("\":\"") - 1);
            memcpy(post_temp_ptr,
                in_request_params->in_server_req_params->mobile_data.application_version,
                strlen(in_request_params->in_server_req_params->mobile_data.application_version));
            post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_data.application_version);

            memcpy(post_temp_ptr, "\"", 1);
            post_temp_ptr += 1;

			has_origin_params = 1;
		}

		//Application Bundle.
    if ( PLATFORM_MOBILE_APP_IOS == in_request_params->in_server_req_params->site_ad->platform_id
        && in_request_params->in_server_req_params->mobile_data.application_id[0] != '\0' ) {
      if (has_origin_params == 1)
      {
        memcpy(post_temp_ptr, ",", 1);
        post_temp_ptr += 1;
      }
      memcpy(post_temp_ptr, "\"", 1);
      post_temp_ptr += 1;
      memcpy(post_temp_ptr, APPLICATION_BUNDLE, (sizeof (APPLICATION_BUNDLE) - 1));
      post_temp_ptr += (sizeof (APPLICATION_BUNDLE) - 1);
      memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
      post_temp_ptr += (sizeof ("\":\"") - 1);
      memcpy(post_temp_ptr,
          in_request_params->in_server_req_params->mobile_data.application_id,
          strlen(in_request_params->in_server_req_params->mobile_data.application_id));
      post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_data.application_id);
      memcpy(post_temp_ptr, "\"", 1);
      post_temp_ptr += 1;
      has_origin_params = 1;
    } else if ( PLATFORM_MOBILE_APP_ANDROID == in_request_params->in_server_req_params->site_ad->platform_id
        && in_request_params->in_server_req_params->mobile_data.application_bundle[0] != '\0' ) {
      if (has_origin_params == 1)
      {
        memcpy(post_temp_ptr, ",", 1);
        post_temp_ptr += 1;
      }
      memcpy(post_temp_ptr, "\"", 1);
      post_temp_ptr += 1;
      memcpy(post_temp_ptr, APPLICATION_BUNDLE, (sizeof (APPLICATION_BUNDLE) - 1));
      post_temp_ptr += (sizeof (APPLICATION_BUNDLE) - 1);
      memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
      post_temp_ptr += (sizeof ("\":\"") - 1);
      memcpy(post_temp_ptr,
          in_request_params->in_server_req_params->mobile_data.application_bundle,
          strlen(in_request_params->in_server_req_params->mobile_data.application_bundle));
      post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_data.application_bundle);
      memcpy(post_temp_ptr, "\"", 1);
      post_temp_ptr += 1;
      has_origin_params = 1;
    }

		// API
		if (in_request_params->in_server_req_params->mobile_data.application_api[0] != '\0') {
            if (has_origin_params == 1)
            {
                memcpy(post_temp_ptr, ",", 1);
                post_temp_ptr += 1;
            }
            memcpy(post_temp_ptr, "\"", (sizeof ("\"") - 1));
            post_temp_ptr += (sizeof ("\"") - 1);
            memcpy(post_temp_ptr, APPLICATION_API, (sizeof (APPLICATION_API) - 1));
            post_temp_ptr += (sizeof (APPLICATION_API) - 1);
            memcpy(post_temp_ptr, "\":", (sizeof ("\":") - 1));
            post_temp_ptr += (sizeof ("\":") - 1);
            memcpy(post_temp_ptr,
                in_request_params->in_server_req_params->mobile_data.application_api,
                strlen(in_request_params->in_server_req_params->mobile_data.application_api));
            post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_data.application_api);

            has_origin_params = 1;

		}
		// Domain Name
		if ((in_request_params->in_server_req_params->mobile_data.app_domain[0] != '\0' && additional_parameter->pubsite_default_settings.realtime_domain_enabled == 1) || in_request_params->fte_additional_params->site_url[0] != '\0') {
            if (has_origin_params == 1)
            {
                memcpy(post_temp_ptr, ",", 1);
                post_temp_ptr += 1;
            }

	    if(in_request_params->in_server_req_params->mobile_data.app_domain[0] != '\0') {
		json_append_escaped_string(&post_temp_ptr, APP_DOMAIN_STRING,  in_request_params->in_server_req_params->mobile_data.app_domain, 0, MAX_DOMAIN_NAME_LENGTH);
	    } else {
		
		memcpy(post_temp_ptr, "\"", 1);
		post_temp_ptr += 1;
		memcpy(post_temp_ptr, SITE_DOMAIN_NAME, (sizeof (SITE_DOMAIN_NAME) - 1));
		post_temp_ptr += (sizeof (SITE_DOMAIN_NAME) - 1);
		memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
		post_temp_ptr += (sizeof ("\":\"") - 1);
		memcpy(post_temp_ptr,
		       in_request_params->fte_additional_params->site_url,
		       strlen(in_request_params->fte_additional_params->site_url));
		post_temp_ptr += strlen(in_request_params->fte_additional_params->site_url);
		memcpy(post_temp_ptr, "\"", 1);
		post_temp_ptr += 1;
	    }
            has_origin_params = 1;
	    
		}
		
		// IAB category
		if (in_request_params->in_server_req_params->mobile_data.iab_category[0] != '\0') {
            if (has_origin_params == 1)
            {
                memcpy(post_temp_ptr, ",", 1);
                post_temp_ptr += 1;
            }
            memcpy(post_temp_ptr, "\"", 1);
            post_temp_ptr += 1;
            memcpy(post_temp_ptr, APPSTORE_CATEGORY, (sizeof (APPSTORE_CATEGORY) - 1));
            post_temp_ptr += (sizeof (APPSTORE_CATEGORY) - 1);
            memcpy(post_temp_ptr, "\":", (sizeof ("\":") - 1));
            post_temp_ptr += (sizeof ("\":") - 1);
            memcpy(post_temp_ptr,
				in_request_params->in_server_req_params->mobile_data.iab_category,
                strlen(in_request_params->in_server_req_params->mobile_data.iab_category));
            post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_data.iab_category);

            has_origin_params = 1;

		}

		//Paid Application.
		if (in_request_params->in_server_req_params->mobile_data.is_paid_application != -1)
		{
			if (has_origin_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}
			memcpy(post_temp_ptr, "\"", 1);
			post_temp_ptr += 1;
			memcpy(post_temp_ptr, IS_PAID_APPLICATION, (sizeof (IS_PAID_APPLICATION) - 1));
			post_temp_ptr += (sizeof (IS_PAID_APPLICATION) - 1);
			memcpy(post_temp_ptr, "\":", (sizeof ("\":") - 1));
			post_temp_ptr += (sizeof ("\":") - 1);
			sprintf(buff, "%d", in_request_params->in_server_req_params->mobile_data.is_paid_application);
			memcpy(post_temp_ptr,
				buff,
				strlen(buff));
			post_temp_ptr += strlen(buff);

			has_origin_params = 1;
		}
		//End of Mobile origin params.
		memcpy(post_temp_ptr, MOBILE_ORIGIN_PARAMS_STRING_END, (sizeof (MOBILE_ORIGIN_PARAMS_STRING_END) - 1));
		post_temp_ptr += (sizeof (MOBILE_ORIGIN_PARAMS_STRING_END) - 1);
		}

		//Start of Mobile User params.
		/* This is bad code example....ideally this code should be deprecated...but we are supporting it for backward compatibility with DSPs */
		if ( 0 == psc.disable_user_data_over_rtb ){
			memcpy(post_temp_ptr, ",", 1);
			post_temp_ptr += 1;
			memcpy(post_temp_ptr, MOBILE_USER_PARAMS_STRING, (sizeof (MOBILE_USER_PARAMS_STRING) - 1));
			post_temp_ptr += (sizeof (MOBILE_USER_PARAMS_STRING) - 1);
			//Year Of Birth.
			if (
					in_request_params->in_server_req_params->year_of_birth[0] != '\0'
					&&
					in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE
					&&
					in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE
				 ) {
				if (has_user_params == 1)
				{
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr += 1;
				}
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;
				memcpy(post_temp_ptr, YEAR_OF_BIRTH, (sizeof (YEAR_OF_BIRTH) - 1));
				post_temp_ptr += (sizeof (YEAR_OF_BIRTH) - 1);
				memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
				post_temp_ptr += (sizeof ("\":\"") - 1);
				memcpy(post_temp_ptr,
						in_request_params->in_server_req_params->year_of_birth,
						strlen(in_request_params->in_server_req_params->year_of_birth));
				post_temp_ptr += strlen(in_request_params->in_server_req_params->year_of_birth);
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;

				has_user_params = 1;
			}
			//Gender.
			if (
					in_request_params->in_server_req_params->gender[0] != '\0'
					&&
					in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE
					&&
					in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE
				 ) {
				if (has_user_params == 1)
				{
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr += 1;
				}
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;
				memcpy(post_temp_ptr, GENDER, (sizeof (GENDER) - 1));
				post_temp_ptr += (sizeof (GENDER) - 1);
				memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
				post_temp_ptr += (sizeof ("\":\"") - 1);
				memcpy(post_temp_ptr,
						in_request_params->in_server_req_params->gender,
						strlen(in_request_params->in_server_req_params->gender));
				post_temp_ptr += strlen(in_request_params->in_server_req_params->gender);
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;

				has_user_params = 1;
			}
			//Zip Code.
			if (in_request_params->in_server_req_params->zip_code[0] != '\0')
			{
				if (has_user_params == 1)
				{
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr += 1;
				}
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;
				memcpy(post_temp_ptr, ZIP_CODE, (sizeof (ZIP_CODE) - 1));
				post_temp_ptr += (sizeof (ZIP_CODE) - 1);
				memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
				post_temp_ptr += (sizeof ("\":\"") - 1);
				memcpy(post_temp_ptr,
						in_request_params->in_server_req_params->zip_code,
						strlen(in_request_params->in_server_req_params->zip_code));
				post_temp_ptr += strlen(in_request_params->in_server_req_params->zip_code);
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;

				has_user_params = 1;
			}
			//Country.
			if (in_request_params->in_server_req_params->country[0] != '\0')
			{
				if (has_user_params == 1)
				{
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr += 1;
				}
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;
				memcpy(post_temp_ptr, COUNTRY, (sizeof (COUNTRY) - 1));
				post_temp_ptr += (sizeof (COUNTRY) - 1);
				memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
				post_temp_ptr += (sizeof ("\":\"") - 1);
				memcpy(post_temp_ptr,
						in_request_params->in_server_req_params->country,
						strlen(in_request_params->in_server_req_params->country));
				post_temp_ptr += strlen(in_request_params->in_server_req_params->country);
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;

				has_user_params = 1;
			}
			//Keywords.
			if (in_request_params->in_server_req_params->keywords[0] != '\0')
			{
				if (has_user_params == 1)
				{
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr += 1;
				}
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;
				memcpy(post_temp_ptr, KEYWORDS, (sizeof (KEYWORDS) - 1));
				post_temp_ptr += (sizeof (KEYWORDS) - 1);
				memcpy(post_temp_ptr, "\":\"", (sizeof ("\":\"") - 1));
				post_temp_ptr += (sizeof ("\":\"") - 1);
				memcpy(post_temp_ptr,
						in_request_params->in_server_req_params->keywords,
						strlen(in_request_params->in_server_req_params->keywords));
				post_temp_ptr += strlen(in_request_params->in_server_req_params->keywords);
				memcpy(post_temp_ptr, "\"", 1);
				post_temp_ptr += 1;

				has_user_params = 1;
			}
			if(in_request_params->in_server_req_params->state[0] != '\0'){
				json_encode_string(&post_temp_ptr, STATE_STRING, in_request_params->in_server_req_params->state, has_user_params);
				has_user_params = 1;
			}

			if(in_request_params->in_server_req_params->city[0] != '\0'){
				json_encode_string(&post_temp_ptr, CITY_STRING, in_request_params->in_server_req_params->city, has_user_params);
				has_user_params = 1;
			}
			if(in_request_params->in_server_req_params->dma[0] != '\0'){
				dma_code = atoi(in_request_params->in_server_req_params->dma);
				json_encode_integer(&post_temp_ptr, DMA_STRING, dma_code, has_user_params);
				has_user_params = 1;
			}
			if ( (in_request_params->in_server_req_params->ethnicity[0] != '\0') &&
					(in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE) &&
					(in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE) ) {

				json_encode_string(&post_temp_ptr, ETHNICITY_STRING, in_request_params->in_server_req_params->ethnicity, has_user_params);
				has_user_params = 1;
			}
			if ( (in_request_params->in_server_req_params->income[0] != '\0') &&
					(in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE) &&
					(in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE) ) {

				json_encode_string(&post_temp_ptr, INCOME_STRING, in_request_params->in_server_req_params->income, has_user_params);
				has_user_params = 1;
			}
			if(in_request_params->in_server_req_params->geo_source_type == GEO_SOURCE_USER_PROVIDED){
				json_encode_integer(&post_temp_ptr, GEO_SOURCE_TYPE_STRING, in_request_params->in_server_req_params->geo_source_type, has_user_params);
				has_user_params = 1;
			}
			if(in_request_params->in_server_req_params->verizon_id[0] != '\0'){
				json_append_escaped_string(&post_temp_ptr, CARRIER_USER_ID,  in_request_params->in_server_req_params->verizon_id, has_user_params, MAX_HASHED_DEVICE_ID_LEN);
				has_user_params = 1;
				json_encode_integer(&post_temp_ptr, CARRIER_USER_ID_TYPE, CARRIER_USER_ID_TYPE_VERIZON, has_user_params);
				has_user_params = 1;
			}
			//End of Mobile User params.
			memcpy(post_temp_ptr, MOBILE_USER_PARAMS_STRING_END, (sizeof (MOBILE_USER_PARAMS_STRING_END) - 1));
			post_temp_ptr += (sizeof (MOBILE_USER_PARAMS_STRING_END) - 1);

		}

		//Start of Mobile Misc. params.
		memcpy(post_temp_ptr, ",", 1);
		post_temp_ptr += 1;
		memcpy(post_temp_ptr, MOBILE_MISC_PARAMS_STRING, (sizeof (MOBILE_MISC_PARAMS_STRING) - 1));
		post_temp_ptr += (sizeof (MOBILE_MISC_PARAMS_STRING) - 1);
		//Minimum compliance level required.
		if (in_request_params->in_server_req_params->min_compliance_level_required != -1)
		{
			if (has_misc_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}
			memcpy(post_temp_ptr, "\"", 1);
			post_temp_ptr += 1;
			memcpy(post_temp_ptr, COMPLIANCE_LEVEL_REQUIRED, (sizeof (COMPLIANCE_LEVEL_REQUIRED) - 1));
			post_temp_ptr += (sizeof (COMPLIANCE_LEVEL_REQUIRED) - 1);
			memcpy(post_temp_ptr, "\":", (sizeof ("\":") - 1));
			post_temp_ptr += (sizeof ("\":") - 1);
			sprintf(buff, "%d", in_request_params->in_server_req_params->min_compliance_level_required);
			memcpy(post_temp_ptr,
				buff,
				strlen(buff));
			post_temp_ptr += strlen(buff);

			has_misc_params = 1;
		}
				//Ad orientation Id for given ad request.
		if (in_request_params->in_server_req_params->ad_orientation_id != -1)
		{
			if (has_misc_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}
			memcpy(post_temp_ptr, "\"", 1);
			post_temp_ptr += 1;
			memcpy(post_temp_ptr, AD_ORIENTATION_ID, (sizeof (AD_ORIENTATION_ID) - 1));
			post_temp_ptr += (sizeof (AD_ORIENTATION_ID) - 1);
			memcpy(post_temp_ptr, "\":", (sizeof ("\":") - 1));
			post_temp_ptr += (sizeof ("\":") - 1);
			sprintf(buff, "%d", in_request_params->in_server_req_params->ad_orientation_id);
			memcpy(post_temp_ptr,
				buff,
				strlen(buff));
			post_temp_ptr += strlen(buff);

			has_misc_params = 1;
		}
		//Device orientation Id.
		if (in_request_params->in_server_req_params->device_orientation_id != -1)
		{
			if (has_misc_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}
			memcpy(post_temp_ptr, "\"", 1);
			post_temp_ptr += 1;
			memcpy(post_temp_ptr, DEVICE_ORIENTATION_ID, (sizeof (DEVICE_ORIENTATION_ID) - 1));
			post_temp_ptr += (sizeof (DEVICE_ORIENTATION_ID) - 1);
			memcpy(post_temp_ptr, "\":", (sizeof ("\":") - 1));
			post_temp_ptr += (sizeof ("\":") - 1);
			sprintf(buff, "%d", in_request_params->in_server_req_params->device_orientation_id);
			memcpy(post_temp_ptr,
				buff,
			strlen(buff));
			post_temp_ptr += strlen(buff);

			has_misc_params = 1;
		}
		//Number of times ad is refreshed per minute.
		if (in_request_params->in_server_req_params->ad_refresh_rate != -1.0F)
		{
			if (has_misc_params == 1)
			{
				memcpy(post_temp_ptr, ",", 1);
				post_temp_ptr += 1;
			}
			memcpy(post_temp_ptr, "\"", 1);
			post_temp_ptr += 1;
			memcpy(post_temp_ptr, AD_REFRESH_RATE, (sizeof (AD_REFRESH_RATE) - 1));
			post_temp_ptr += (sizeof (AD_REFRESH_RATE) - 1);
			memcpy(post_temp_ptr, "\":", (sizeof ("\":") - 1));
			post_temp_ptr += (sizeof ("\":") - 1);
			sprintf(buff, "%f", in_request_params->in_server_req_params->ad_refresh_rate);
			memcpy(post_temp_ptr,
				buff,
				strlen(buff));
			post_temp_ptr += strlen(buff);

			has_misc_params = 1;
		}
		//End of Mobile Misc. params.
		memcpy(post_temp_ptr, MOBILE_MISC_PARAMS_STRING_END, (sizeof (MOBILE_MISC_PARAMS_STRING_END) - 1));
		post_temp_ptr += (sizeof (MOBILE_MISC_PARAMS_STRING_END) - 1);

		//End of Mobile params.
		memcpy(post_temp_ptr, MOBILE_PARAMS_STRING_END, (sizeof (MOBILE_PARAMS_STRING_END) - 1));
		post_temp_ptr += (sizeof (MOBILE_PARAMS_STRING_END) - 1);

		*flag = 1;
	}

	if(NEED_TO_PASS_USER_PARAMS(in_request_params, psc)) {
		//Seprator.
		if (*flag == 1){
			 memcpy(post_temp_ptr,",",1);
			post_temp_ptr++;
		}
		memcpy(post_temp_ptr, MOBILE_USER_PARAMS_STRING, (sizeof (MOBILE_USER_PARAMS_STRING) - 1));
		post_temp_ptr += (sizeof (MOBILE_USER_PARAMS_STRING) - 1);
		has_user_params = 0;
		//Year Of Birth.
		if (in_request_params->in_server_req_params->year_of_birth[0] != '\0') {
			json_encode_string(&post_temp_ptr, YEAR_OF_BIRTH, in_request_params->in_server_req_params->year_of_birth, has_user_params);
			has_user_params = 1;
		}
		//Gender.
		if (in_request_params->in_server_req_params->gender[0] != '\0') {
				json_encode_string(&post_temp_ptr, GENDER, in_request_params->in_server_req_params->gender, has_user_params);
			has_user_params = 1;
		}
		//Zip Code.
		if (in_request_params->in_server_req_params->zip_code[0] != '\0'){
			json_encode_string(&post_temp_ptr, ZIP_CODE, in_request_params->in_server_req_params->zip_code, has_user_params);
			has_user_params = 1;
		}
		//Country.
		if (in_request_params->in_server_req_params->country[0] != '\0'){
			json_encode_string(&post_temp_ptr, COUNTRY, in_request_params->in_server_req_params->country, has_user_params);
			has_user_params = 1;
		}
		if (in_request_params->in_server_req_params->keywords[0] != '\0'){
			json_encode_string(&post_temp_ptr, KEYWORDS, in_request_params->in_server_req_params->keywords, has_user_params);
			has_user_params = 1;
		}
		if(in_request_params->in_server_req_params->state[0] != '\0'){
			json_encode_string(&post_temp_ptr, STATE_STRING, in_request_params->in_server_req_params->state, has_user_params);
			has_user_params = 1;
		}
		if(in_request_params->in_server_req_params->city[0] != '\0'){
			json_encode_string(&post_temp_ptr, CITY_STRING, in_request_params->in_server_req_params->city, has_user_params);
			has_user_params = 1;
		}
		if(in_request_params->in_server_req_params->dma[0] != '\0'){
			dma_code = atoi(in_request_params->in_server_req_params->dma);
			json_encode_integer(&post_temp_ptr, DMA_STRING, dma_code, has_user_params);
			has_user_params = 1;
		}
		if(in_request_params->in_server_req_params->ethnicity[0] != '\0'){

				json_encode_string(&post_temp_ptr, ETHNICITY_STRING, in_request_params->in_server_req_params->ethnicity, has_user_params);
				has_user_params = 1;
		}
		if (in_request_params->in_server_req_params->income[0] != '\0') {

				json_encode_string(&post_temp_ptr, INCOME_STRING, in_request_params->in_server_req_params->income, has_user_params);
				has_user_params = 1;
		}
		if(in_request_params->in_server_req_params->geo_source_type == GEO_SOURCE_USER_PROVIDED){
				json_encode_integer(&post_temp_ptr, GEO_SOURCE_TYPE_STRING, in_request_params->in_server_req_params->geo_source_type, has_user_params);
				has_user_params = 1;
		}
		if (in_request_params->in_server_req_params->verizon_id[0] != '\0') {

				json_append_escaped_string(&post_temp_ptr, CARRIER_USER_ID,  in_request_params->in_server_req_params->verizon_id, has_user_params, MAX_HASHED_DEVICE_ID_LEN);
				has_user_params = 1;
				json_encode_integer(&post_temp_ptr, CARRIER_USER_ID_TYPE, CARRIER_USER_ID_TYPE_VERIZON, has_user_params);
				has_user_params = 1;
		}
	//End of Mobile User params.
	memcpy(post_temp_ptr, MOBILE_USER_PARAMS_STRING_END, (sizeof (MOBILE_USER_PARAMS_STRING_END) - 1));
	post_temp_ptr += (sizeof (MOBILE_USER_PARAMS_STRING_END) - 1);
	*flag = 1;
}

	if (	rt_request_url_params_mask1->use_geo_params == 1 ||
		additional_parameter->pubsite_default_settings.is_ip_address_blocked == 1)
		{
			if (is_full_ip_address(in_request_params->ad_server_req_gen_params->remote_ip_addr) == 1)  
			  {
			    country = additional_parameter->gd.iso_country_code;
			    state = additional_parameter->gd.region_code;
			    city = additional_parameter->gd.city;
			    latitude = &(additional_parameter->gd.latitude);
			    longitude =  &(additional_parameter->gd.longitude);
			    dma = &(additional_parameter->gd.dma_code);
			    postal_code = additional_parameter->gd.postal_code;
			    //geo_source_type = &(additional_parameter->gd.geo_source_type);
			  }

		//Publisher passed Mobile Device location.
		if (in_request_params->in_server_req_params->mobile_device_location[0] != '\0') {
		  count = sscanf(in_request_params->in_server_req_params->mobile_device_location,"%f,%f",&lat,&lon);
		}

		//In case of desktop, LEGACY CHECK: Sanity checks & Also, check whether we have received all mandatory params or not.
		//In case of mobile, go ahead
		if ( (  
			is_mob_impression != 1 
			&& 
			(
				country != NULL &&
                                state != NULL &&
                                city != NULL &&
                                dma != NULL &&
                                country[0] != '\0'
			)
		     )
		     ||
		     (
			is_mob_impression == 1
		     )
		)
		    {
		      //Seprator.
		      if (*flag == 1)
		      {
			memcpy(post_temp_ptr,",",1);
			post_temp_ptr++;
		      }

		      //Start of Geo params.
		      memcpy(post_temp_ptr, GEO_PARAMS_STRING, (sizeof (GEO_PARAMS_STRING) - 1));
		      post_temp_ptr += (sizeof (GEO_PARAMS_STRING) - 1);

		      //Country
		      if (country != NULL && country[0] != '\0')
		      {
		      	json_encode_string(&post_temp_ptr, COUNTRY_STRING, country, has_geo_params);
			has_geo_params = 1;
		      }
		      //State
		      if (state != NULL && state[0] != '\0')
		      {
			json_encode_string(&post_temp_ptr, STATE_STRING, state, has_geo_params);
			has_geo_params = 1;
		      }
		      //City
		      if (city != NULL && city[0] != '\0')
		      {
			json_encode_string(&post_temp_ptr, CITY_STRING, city, has_geo_params);
			has_geo_params = 1;
		      }
		      //DMA
		      if (dma != NULL && *dma != 0)
		      {
			json_encode_integer(&post_temp_ptr, DMA_STRING, *dma, has_geo_params);
			has_geo_params = 1;
		      }
		      if ( count == 2 ) { // Publisher passed geo location
			if(1 == lat_lon_masking_enabled){
			  json_encode_double_truncated(&post_temp_ptr, LATITUDE_STRING, lat, has_geo_params);
			  has_geo_params = 1;
			  json_encode_double_truncated(&post_temp_ptr, LONGITUDE_STRING, lon, has_geo_params);
			  has_geo_params = 1;
			}
			else{
			  json_encode_double(&post_temp_ptr, LATITUDE_STRING, lat, has_geo_params);
			  has_geo_params = 1;
			  json_encode_double(&post_temp_ptr, LONGITUDE_STRING, lon, has_geo_params);
			  has_geo_params = 1;
			}
			if (  in_request_params->in_server_req_params->loc_source >= 0
			      &&
			      in_request_params->in_server_req_params->loc_source < 4
			      ) {
			  json_encode_integer(&post_temp_ptr, LOC_SOURCE_TYPE_STRING, in_request_params->in_server_req_params->loc_source, has_geo_params);
			  has_geo_params = 1;
			}
		      } else if (is_mob_impression != 1) {
			  if(latitude && IS_VALID_LATITUDE(*latitude))
			  {
			    if(1 == lat_lon_masking_enabled){
			      json_encode_double_truncated(&post_temp_ptr, LATITUDE_STRING, *latitude, has_geo_params);
			    }
			    else{
			      json_encode_double(&post_temp_ptr, LATITUDE_STRING, *latitude, has_geo_params);
			    }
			    has_geo_params = 1;
			    loc_info_sent = 1;
			  }
			  if(longitude && IS_VALID_LONGITUDE(*longitude))
			  {
			    if(1 == lat_lon_masking_enabled){
			      json_encode_double_truncated(&post_temp_ptr, LONGITUDE_STRING, *longitude, has_geo_params);
			    }
			    else{
			      json_encode_double(&post_temp_ptr, LONGITUDE_STRING, *longitude, has_geo_params);
			    }
			    has_geo_params = 1;
			    loc_info_sent = 1;
			  }
			  if (loc_info_sent == 1) {
                                json_encode_integer(&post_temp_ptr, LOC_SOURCE_TYPE_STRING, GEO_SOURCE_IP_ADDRESS, has_geo_params);
                                has_geo_params = 1;
                          }
		      }

		      //postal code
		      if (postal_code != NULL && postal_code[0] != '\0')
		      {
			json_encode_string(&post_temp_ptr, ZIP_CODE, postal_code, has_geo_params);
			has_geo_params = 1;
		      }
		/* Deprecated: MPS-74
			//Geo source type
		      if(geo_source_type != NULL && *geo_source_type > 0 && *geo_source_type < 4)
		      {
			json_encode_integer(&post_temp_ptr, GEO_SOURCE_TYPE_STRING, *geo_source_type, ADD_SEPARATOR);
		      }
		*/
		      
			if (in_request_params->in_server_req_params->loc_category[0] != '\0')
			{
				if (has_geo_params == 1)
				{
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr += 1;
				}
		    memcpy(post_temp_ptr, LOC_CAT_STRING, (sizeof (LOC_CAT_STRING) - 1));
		    post_temp_ptr += (sizeof (LOC_CAT_STRING) - 1);
				
				memcpy(post_temp_ptr,
						in_request_params->in_server_req_params->loc_category,
						strlen(in_request_params->in_server_req_params->loc_category));
				post_temp_ptr += strlen(in_request_params->in_server_req_params->loc_category);

				has_geo_params = 1;
			}

			if (in_request_params->in_server_req_params->loc_brand[0] != '\0')
			{
				if (has_geo_params == 1)
				{
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr += 1;
				}
		    memcpy(post_temp_ptr, LOC_BRAND_STRING, (sizeof (LOC_BRAND_STRING) - 1));
		    post_temp_ptr += (sizeof (LOC_BRAND_STRING) - 1);
				
				memcpy(post_temp_ptr,
						in_request_params->in_server_req_params->loc_brand,
						strlen(in_request_params->in_server_req_params->loc_brand));
				post_temp_ptr += strlen(in_request_params->in_server_req_params->loc_brand);

				has_geo_params = 1;
			}

			if (in_request_params->in_server_req_params->loc_cat_src != -1) {
				json_encode_integer(&post_temp_ptr, LOC_CAT_SRC_STRING, in_request_params->in_server_req_params->loc_cat_src, has_geo_params);
				has_geo_params = 1;
			}

					if (has_geo_params == 1) 
		      {
		      		memcpy(post_temp_ptr, GEO_PARAMS_STRING_END, (sizeof(GEO_PARAMS_STRING_END) - 1));
		      		post_temp_ptr += (sizeof(GEO_PARAMS_STRING_END) - 1);

		      		*flag = 1;
		      } else {
				post_temp_ptr -= (sizeof (GEO_PARAMS_STRING) - 1);
				if (*flag == 1) {
					post_temp_ptr -= 1;
				}
		      }
		    }
		}


	cmpg_dp_data = &(cmpg_dp_params->cmpg_dp_data);
	if (cmpg_dp_data->dp_data_count > 0)
	{
		//Seprator.
		if (*flag == 1)
		{
			memcpy(post_temp_ptr, ",", 1);
			post_temp_ptr++;
		}
		//Start of Contextual and Brand Safety data.
		memcpy(	post_temp_ptr,
			CONTEXTUAL_BRAND_SAFETY_DATA,
			(sizeof (CONTEXTUAL_BRAND_SAFETY_DATA) - 1));
		post_temp_ptr += (sizeof (CONTEXTUAL_BRAND_SAFETY_DATA) - 1);
		for (i = 0; i < cmpg_dp_data->dp_data_count; i++)
		{
			if (cmpg_dp_data->dp_data[i] != NULL)
			{
				if (i > 0)
				{
					//Seprator.
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr++;
				}

				//Contextual brand & safety data obj start.
				memcpy(	post_temp_ptr,
					CONTEXTUAL_BRAND_SAFETY_DATA_OBJ,
					(sizeof (CONTEXTUAL_BRAND_SAFETY_DATA_OBJ) - 1));
				post_temp_ptr += (sizeof (CONTEXTUAL_BRAND_SAFETY_DATA_OBJ) - 1);

				//Data Provider Id.
				json_encode_integer(	&post_temp_ptr,
							DATA_PROVIDER_PROVIDER,
							cmpg_dp_data->dp_data[i]->data_provider_id,
							DO_NOT_ADD_SEPARATOR);
				//Scope.
				json_encode_string(	&post_temp_ptr,
							DATA_PROVIDER_DATA_SCOPE,
							cmpg_dp_data->dp_data[i]->scope,
							ADD_SEPARATOR);
				//Type.
				json_encode_string(	&post_temp_ptr,
							DATA_PROVIDER_DATA_TYPE,
							cmpg_dp_data->dp_data[i]->type,
							ADD_SEPARATOR);

				//Contextual data provided by Data-Provider in JSON form.
				if (cmpg_dp_data->dp_data[i]->json_contextual_data_len > 0)
				{
					//Seprator.
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr++;

					memcpy(	post_temp_ptr,
						cmpg_dp_data->dp_data[i]->json_contextual_data,
						cmpg_dp_data->dp_data[i]->json_contextual_data_len);
					post_temp_ptr += cmpg_dp_data->dp_data[i]->json_contextual_data_len;
				}

				//Brand Safety data provided by Data-Provider in JSON form.
				if (cmpg_dp_data->dp_data[i]->json_brand_safety_data_len > 0)
				{
					//Seprator.
					memcpy(post_temp_ptr, ",", 1);
					post_temp_ptr++;

					memcpy(	post_temp_ptr,
						cmpg_dp_data->dp_data[i]->json_brand_safety_data,
						cmpg_dp_data->dp_data[i]->json_brand_safety_data_len);
					post_temp_ptr += cmpg_dp_data->dp_data[i]->json_brand_safety_data_len;
				}

				//Contextual brand & safety data obj ends.
				memcpy(	post_temp_ptr,
					CONTEXTUAL_BRAND_SAFETY_DATA_OBJ_END,
					(sizeof (CONTEXTUAL_BRAND_SAFETY_DATA_OBJ_END) - 1));
				post_temp_ptr += (sizeof (CONTEXTUAL_BRAND_SAFETY_DATA_OBJ_END) - 1);
			}
		}
		//End of Contextual and Brand Safety data.
		memcpy(	post_temp_ptr,
			CONTEXTUAL_BRAND_SAFETY_DATA_END,
			(sizeof (CONTEXTUAL_BRAND_SAFETY_DATA_END) - 1));
		post_temp_ptr += (sizeof (CONTEXTUAL_BRAND_SAFETY_DATA_END) - 1);

		*flag = 1;
	}

	if (CAMPAIGN_HAS_DEALS(adcampaign, rt_request_url_params_mask1))
	{
		//Compose Deals params.
		compose_deals_params_post_data(&post_temp_ptr, adcampaign, rt_request_url_params_mask1, in_request_params->fte_additional_params, flag);
	}

	//adtruth_rtb_json
	if ( (in_request_params->in_server_req_params->adtruth_data.adtruth_rtb_json[0] != '\0') &&
			(rt_request_url_params_mask1->use_adtruth_id == 1 ) &&
			(in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE) &&
			(in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE) ) { 

		if( *flag == 1 ) {
			memcpy(post_temp_ptr, ",", 1);
			post_temp_ptr++;
		}

		memcpy(post_temp_ptr, ADTRUTH_RTB_JSON, (sizeof(ADTRUTH_RTB_JSON)-1));
		post_temp_ptr += (sizeof(ADTRUTH_RTB_JSON)-1);

		memcpy(post_temp_ptr, in_request_params->in_server_req_params->adtruth_data.adtruth_rtb_json, 
						strlen(in_request_params->in_server_req_params->adtruth_data.adtruth_rtb_json));
		post_temp_ptr += strlen(in_request_params->in_server_req_params->adtruth_data.adtruth_rtb_json);
		*flag = 1;
		adcampaign->ad_campaign_list_setings->adtruth_id_used=1;
	}

/* OLD Native Protocol Implementation
	if (IS_NATIVE_REQUEST) {
#ifdef NATIVE_DEBUG
		llog_write(L_DEBUG,"\nMB_NATIVE Adding Native object to PubRTB request %s:%d\n",__FILE__,__LINE__);
#endif
		native_params_t *native_params = &(in_request_params->in_server_req_params->in_native_params);

                if (*flag == 1) {
                        memcpy(post_temp_ptr, ",", 1);
                        post_temp_ptr++;
                }
                memcpy(post_temp_ptr, NATIVE_PARAMS_STRING, (sizeof (NATIVE_PARAMS_STRING) - 1));
                post_temp_ptr += (sizeof (NATIVE_PARAMS_STRING) - 1);

		native_post_len = post_temp_ptr - post_data;


		// nver is mandatory
		native_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - native_post_len,
					    "\"%s\":\"%s\",", NATIVE_API_VER, native_params->api_ver);
		post_temp_ptr = post_data + native_post_len;

		// admsupport is mandatory
		native_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - native_post_len,
                            "\"%s\":%s,", NATIVE_ADM_SUPPORT, native_params->parsed_admsupport);
		post_temp_ptr = post_data + native_post_len;

		if (native_params->cover_img_selected == 1 && native_params->imgratio[0] != '\0') {
	                native_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - native_post_len,
	                                            "\"%s\":\"%s\",", NATIVE_IMG_RATIO, native_params->imgratio);
	                post_temp_ptr = post_data + native_post_len;
		}

		if (native_params->seq_num != -1) {
                        native_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - native_post_len,
                                                    "\"%s\":%ld,", NATIVE_SEQ_NUM, native_params->seq_num);
                        post_temp_ptr = post_data + native_post_len;
                }

		if (native_params->icon_img_selected == 1 && native_params->icon_size[0] != '\0') {
                        native_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - native_post_len,
                                                    "\"%s\":\"%s\",", NATIVE_ICON_SIZE, native_params->icon_size);
                        post_temp_ptr = post_data + native_post_len;
                }

                if (native_params->cover_img_selected == 1 && native_params->img_size[0] != '\0') {
                        native_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - native_post_len,
                                                    "\"%s\":\"%s\",", NATIVE_IMAGE_SIZE, native_params->img_size);
                        post_temp_ptr = post_data + native_post_len;
                }

                if (native_params->title_selected == 1 && native_params->title_len != -1) {
                        native_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - native_post_len,
                                                    "\"%s\":%d,", NATIVE_TITLE_LEN, native_params->title_len);
                        post_temp_ptr = post_data + native_post_len;
                }

                if (native_params->desc_selected == 1 && native_params->desc_len != -1) {
                        native_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - native_post_len,
                                                    "\"%s\":%d,", NATIVE_DESC_LEN, native_params->desc_len);
                        post_temp_ptr = post_data + native_post_len;
                }

                if (native_params->cta_selected == 1 && native_params->cta_len != -1) {
                        native_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - native_post_len,
                                                    "\"%s\":%d,", NATIVE_CTA_LEN, native_params->cta_len);
                        post_temp_ptr = post_data + native_post_len;
                }

                post_temp_ptr--;
                memcpy(post_temp_ptr, NATIVE_PARAMS_STRING_END, (sizeof (NATIVE_PARAMS_STRING_END) - 1));
                post_temp_ptr += (sizeof (NATIVE_PARAMS_STRING_END) - 1);

                *flag = 1;
	}
*/

	if(IS_VIDEO_REQUEST){
		video_param_t *video_params = &(in_request_params->in_server_req_params->video_params);

		if (*flag == 1)	{
			memcpy(post_temp_ptr, ",", 1);
			post_temp_ptr++;
		}
		memcpy(post_temp_ptr, VIDEO_PARAMS_STRING, (sizeof (VIDEO_PARAMS_STRING) - 1));
		post_temp_ptr += (sizeof (VIDEO_PARAMS_STRING) - 1);

		vid_post_len = post_temp_ptr - post_data;

		//type is mandatory in RTB
		if(video_params->type < VIDEO_AD_TYPE_LINEAR || video_params->type > VIDEO_AD_TYPE_OVERLAY ){
			video_params->type = VIDEO_AD_TYPE_ANY;
                }
		vid_post_len += snprintf(post_temp_ptr, 
					 MAX_POST_DATA_LEN - vid_post_len, 
					 "%s%d,",VIDEO_TYPE, video_params->type);
		post_temp_ptr = post_data + vid_post_len;

		//pos is optional
		if((video_params->position > MIN_VIDEO_POSITION_VALUE) && (video_params->position <= MAX_VIDEO_POSITION_VALUE)){
			vid_post_len += snprintf(post_temp_ptr, 
						 MAX_POST_DATA_LEN - vid_post_len, 
						 "%s%d,", VIDEO_POSITION, video_params->position);
			post_temp_ptr = post_data + vid_post_len;

		}

		//Both minLength and maxLength are mandatory
		vid_post_len += snprintf(post_temp_ptr, 
					 MAX_POST_DATA_LEN - vid_post_len, 
					 "%s%d,", VIDEO_MIN_LEN, video_params->min_length);
		post_temp_ptr = post_data + vid_post_len;
		
		vid_post_len += snprintf(post_temp_ptr, 
					 MAX_POST_DATA_LEN - vid_post_len,
					 "%s%d,", VIDEO_MAX_LEN, video_params->max_length);
		post_temp_ptr = post_data + vid_post_len;

		//Both min & max bitrates are optional
		if(video_params->min_bit_rate > 0){
			vid_post_len += snprintf(post_temp_ptr,
						 MAX_POST_DATA_LEN - vid_post_len,
						 "%s%d,", VIDEO_MIN_BTR, video_params->min_bit_rate);
			post_temp_ptr = post_data + vid_post_len;
		}

		if(video_params->max_bit_rate > 0){
			vid_post_len += snprintf(post_temp_ptr,
						 MAX_POST_DATA_LEN - vid_post_len,
						 "%s%d,", VIDEO_MAX_BTR, video_params->max_bit_rate);
			post_temp_ptr = post_data + vid_post_len;

		}

		//comp is optional along with compwidth and compheight
		if(video_params->has_companion == 1){
			vid_post_len += snprintf(post_temp_ptr,
						 MAX_POST_DATA_LEN - vid_post_len,
						 "%s%d,", VIDEO_HAS_COMP,video_params->has_companion);
			post_temp_ptr = post_data + vid_post_len;

			if(video_params->companion_width > 0){
				vid_post_len += snprintf(post_temp_ptr,
							 MAX_POST_DATA_LEN - vid_post_len,
							 "%s%d,", VIDEO_COMP_WIDTH, video_params->companion_width);
				post_temp_ptr = post_data + vid_post_len;

			}

			if(video_params->companion_height > 0){
				vid_post_len += snprintf(post_temp_ptr,
							MAX_POST_DATA_LEN - vid_post_len,
							"%s%d,", VIDEO_COMP_HEIGHT, video_params->companion_height);
				post_temp_ptr = post_data + vid_post_len;

			}
		}

		//AdFormat is mandatory in PubMatic RTB
		if(video_params->vid_protocol <= MAX_PROTOCOL_TYPE_VALUE) {
		vid_post_len += snprintf(post_temp_ptr,
					 MAX_POST_DATA_LEN - vid_post_len,
					 "%s%d,", VIDEO_AD_FORMAT,
					 pubmatic_ortb_protocol_mapping[video_params->vid_protocol]);
		post_temp_ptr = post_data + vid_post_len;
		}

		//stream_format is optional in RTB
	        if(video_params->stream_format[0] == FLAG_SET){

                        int stream_format_json_key_size = (sizeof(VIDEO_STREAM_FORMAT_JSON_KEY)-1);
                        memcpy( post_temp_ptr , VIDEO_STREAM_FORMAT_JSON_KEY , stream_format_json_key_size);
                        vid_post_len += stream_format_json_key_size;
                        post_temp_ptr = post_data + vid_post_len;

                        for(i=1; i<=MAX_STREAM_FORMAT_ID; i++){
                                if(video_params->stream_format[i] == FLAG_SET){
                                        vid_post_len += snprintf(post_temp_ptr,MAX_POST_DATA_LEN- vid_post_len, "%d,", i);
                                        post_temp_ptr = post_data + vid_post_len;
                                }
                        }

                        vid_post_len--;
                        post_temp_ptr--;

                        vid_post_len += snprintf(post_temp_ptr,MAX_POST_DATA_LEN- vid_post_len, "],");
                        post_temp_ptr = post_data + vid_post_len;

                }

			
		/*if(video_params->response_format > 0){
			vid_post_len += snprintf(post_temp_ptr, 
					MAX_POST_DATA_LEN- vid_post_len, 
					"%s%d,",VIDEO_RESP_FORMAT, video_params->response_format);
			post_temp_ptr = post_data + vid_post_len;

		} */

		if(video_params->vid_api > 0){
			vid_post_len += snprintf(post_temp_ptr,
						 MAX_POST_DATA_LEN - vid_post_len,
						 "%s%d,", VIDEO_API,  video_params->vid_api);
			post_temp_ptr = post_data + vid_post_len;

		}
		
		//playback is optional
        if(video_params->playback[0] == FLAG_SET){
			
			int playback_json_key_size = (sizeof(VIDEO_PLAYBACK_JSON_KEY)-1);
			memcpy( post_temp_ptr , VIDEO_PLAYBACK_JSON_KEY , playback_json_key_size);
			vid_post_len += playback_json_key_size;
			post_temp_ptr = post_data + vid_post_len;

			for(i=1;i<=MAX_VIDEO_PLAYBACK_ID;i++){
				if(video_params->playback[i] == FLAG_SET){
					vid_post_len += snprintf(post_temp_ptr,MAX_POST_DATA_LEN- vid_post_len, "%d,", i);
					post_temp_ptr = post_data + vid_post_len;
				}
			}

			vid_post_len--;
			post_temp_ptr--;
			
			vid_post_len += snprintf(post_temp_ptr,MAX_POST_DATA_LEN- vid_post_len, "],");
			post_temp_ptr = post_data + vid_post_len;

		}
		//aspect ratio is optional
                if( video_params->aspect_ratio[0] != '\0' ){
                        vid_post_len += snprintf(post_temp_ptr,
                                        MAX_POST_DATA_LEN - vid_post_len,
                                        "%s\"%s\",", VIDEO_ASPECT_RATIO,  video_params->aspect_ratio);
                        post_temp_ptr = post_data + vid_post_len;
                }

		//player stretching mode is optional
		if( video_params->player_stretching_mode > 0 ){
			vid_post_len += snprintf(post_temp_ptr,
					MAX_POST_DATA_LEN - vid_post_len,
					"%s%d,", VIDEO_PLAYER_STRETCHING_MODE,  video_params->player_stretching_mode);
			post_temp_ptr = post_data + vid_post_len;
		}

        //language is optional
                if( video_params->language[0] != '\0' ){
                        vid_post_len += snprintf(post_temp_ptr,
                                        MAX_POST_DATA_LEN - vid_post_len,
                                        "%s\"%s\",", VIDEO_LANGUAGE,  video_params->language);
                        post_temp_ptr = post_data + vid_post_len;
                }



		if(video_params->page_contextual_info[0]!='\0'){
		//TODO_NIKI: escaping needed. Can break json.
			replace_special_char(video_params->page_contextual_info);
			vid_post_len += snprintf(post_temp_ptr,
						 MAX_POST_DATA_LEN - vid_post_len,
						 "%s\"%s\",", VIDEO_PG_CONT,  video_params->page_contextual_info);
			post_temp_ptr = post_data + vid_post_len;
		}
		
		if(video_params->window_height > 0){
				vid_post_len += snprintf(post_temp_ptr,
								MAX_POST_DATA_LEN - vid_post_len,
								"%s%d,", VIDEO_WINDOW_HEIGHT, video_params->window_height);
				post_temp_ptr = post_data + vid_post_len;
		}
		
		if(video_params->window_width > 0){
				vid_post_len += snprintf(post_temp_ptr,
								MAX_POST_DATA_LEN - vid_post_len,
								"%s%d,", VIDEO_WINDOW_WIDTH, video_params->window_width);
				post_temp_ptr = post_data + vid_post_len;
		}
	
		if(video_params->video_ad_height > 0){
				vid_post_len += snprintf(post_temp_ptr,
								MAX_POST_DATA_LEN - vid_post_len,
								"%s%d,", VIDEO_AD_HEIGHT, video_params->video_ad_height);
				post_temp_ptr = post_data + vid_post_len;
		}

		if(video_params->video_ad_width > 0){
				vid_post_len += snprintf(post_temp_ptr,
								MAX_POST_DATA_LEN - vid_post_len,
								"%s%d,", VIDEO_AD_WIDTH, video_params->video_ad_width);
				post_temp_ptr = post_data + vid_post_len;
    	}

	    if(video_params->player_height > 0){
				vid_post_len += snprintf(post_temp_ptr,
								MAX_POST_DATA_LEN - vid_post_len,
								"%s%d,", VIDEO_PLAYER_HEIGHT, video_params->player_height);
				post_temp_ptr = post_data + vid_post_len;
    	}

	    if(video_params->player_width > 0){
				vid_post_len += snprintf(post_temp_ptr,
								MAX_POST_DATA_LEN - vid_post_len,
								"%s%d,", VIDEO_PLAYER_WIDTH, video_params->player_width);
				post_temp_ptr = post_data + vid_post_len;
    	}

		if(video_params->video_page_url[0] != '\0'){
			video_ptr = post_temp_ptr;
			json_append_escaped_string(&post_temp_ptr, VIDEO_WINDOW_PAGE_URL, video_params->video_page_url, DONT_ADD_COMMA, MAX_PAGE_URL_SIZE);
			sprintf(post_temp_ptr,"%c", ',');
			vid_post_len += post_temp_ptr - video_ptr + 1;
			post_temp_ptr = post_data + vid_post_len;
		}
		
		if(video_params->video_ref_url[0] != '\0'){
			 video_ptr = post_temp_ptr;
			 json_append_escaped_string(&post_temp_ptr, VIDEO_WINDOW_REF_URL, video_params->video_ref_url, DONT_ADD_COMMA, MAX_PAGE_URL_SIZE);
			 sprintf(post_temp_ptr,"%c", ',');
			 vid_post_len += post_temp_ptr - video_ptr + 1;
			 post_temp_ptr = post_data + vid_post_len;
			
    		}
		
		if(in_request_params->in_server_req_params->iframe_depth >= 0){
				vid_post_len += snprintf(post_temp_ptr,
								MAX_POST_DATA_LEN - vid_post_len,
								"%s%d,", VIDEO_IFRAME_DEPTH, in_request_params->in_server_req_params->iframe_depth);
				post_temp_ptr = post_data + vid_post_len;
    	}	

		if(video_params->skip == 1){
			vid_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - vid_post_len,
						 "%s%d,%s%d,%s%d,", 
						 VIDEO_SKIP, video_params->skip,
						 VIDEO_SKIP_DELAY, video_params->skip_delay,
						 VIDEO_NOSKIP_AD_LEN, video_params->noskip_ad_len
						);
			post_temp_ptr = post_data + vid_post_len;
		}

		if(video_params->audio == TRUE){
			vid_post_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - vid_post_len,
						 "%s%d,", 
						 VIDEO_AUDIO_FLAG, TRUE
						);
			post_temp_ptr = post_data + vid_post_len;
		}

		post_temp_ptr--;
		memcpy(post_temp_ptr, VIDEO_PARAMS_STRING_END, (sizeof (VIDEO_PARAMS_STRING_END) - 1));
		post_temp_ptr += (sizeof (VIDEO_PARAMS_STRING_END) - 1);

		*flag = 1;

	}

	if (additional_parameter->soft_floor > 0.0000) {
		double soft_floor = CONVERT_USD_TO_NATIVE_CURRENCY(additional_parameter->soft_floor,
				adcampaign->dsp_currency_id,
				in_request_params->fte_additional_params->currency_xrate_map,
				in_request_params->fte_additional_params->currency_count);
		if (*flag == 1) {
			json_encode_double(&post_temp_ptr, BID_GUIDE_FLOOR_STRING, soft_floor, ADD_SEPARATOR);
		} else {
			json_encode_double(&post_temp_ptr, BID_GUIDE_FLOOR_STRING, soft_floor, 0);
		}
		*flag = 1;
	}

	if(in_request_params->in_server_req_params->is_tablet == 1)
	{
		if (*flag == 1) {
			json_encode_integer(&post_temp_ptr, DEVICE_TYPE_STRING, DEVICE_TYPE_TABLET, ADD_SEPARATOR);
		} else {
			json_encode_integer(&post_temp_ptr, DEVICE_TYPE_STRING, DEVICE_TYPE_TABLET, 0);

		}
		*flag = 1;

	}else if(in_request_params->in_server_req_params->device_type != -1)
	{
		if (*flag == 1) {
			json_encode_integer(&post_temp_ptr, DEVICE_TYPE_STRING, in_request_params->in_server_req_params->device_type, ADD_SEPARATOR);

		} else {
			json_encode_integer(&post_temp_ptr, DEVICE_TYPE_STRING, in_request_params->in_server_req_params->device_type, 0);
		}
		*flag = 1;

	}


	if ( rt_request_url_params_mask1->send_winloss_info == 1 ) {
		if (*flag == 1) { 
			memcpy(post_temp_ptr,",",1);
			post_temp_ptr++;
		}
		bytes_written = get_winloss_info_str(post_temp_ptr, MAX_WINLOSS_STR_LEN, adcampaign->campaign_id,
                                                    &(in_request_params->fte_additional_params->hash_table));
                if ( (bytes_written == 0) && (*flag == 1) ) {
                        post_temp_ptr--;                //remove the comma added
                } 
		if ( bytes_written > 0 ) {
                        post_temp_ptr += bytes_written; //increase pointer as it was passed by value
                        *flag = 1;
                }
	}

	/* Reset all gdpr object creation flags */
	int add_gdpr_ext = 0;
	int add_iab_gdpr_consent = 0;
	int add_eb_provider_list = 0;
	char *eb_provider_list = NULL;

	/* take decision, whether we want to send gdpr singal in RTB request */
	gdpr_object_creation_decision(in_request_params->in_server_req_params,
			in_request_params->fte_additional_params,
			adcampaign->ad_campaign_gdpr_settings.dont_pass_iab_consent_obj,
			&add_gdpr_ext,
			&add_iab_gdpr_consent,
			&add_eb_provider_list,
			&eb_provider_list);

	/* Add gdpr signal in RTB request */
	if (1 == add_gdpr_ext) {
		int gdpr_len = post_temp_ptr - post_data;
		if (1 == *flag) {
			gdpr_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - gdpr_len, ",");
			post_temp_ptr = post_data + gdpr_len;
		}
		gdpr_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - gdpr_len, "%s%d", GDPR_REQUEST_VALUE, req_params->gdpr);
		post_temp_ptr = post_data + gdpr_len;

		/* Add gdpr signal in RTB request */
		if (1 == add_iab_gdpr_consent && '\0' != req_params->consent[0]) {
			gdpr_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - gdpr_len, ",%s\"%s\"", GDPR_CONSENT_VALUE, req_params->consent);
			post_temp_ptr = post_data + gdpr_len;
		}
		/* Append google EB consented provider list */
		if (1 == add_eb_provider_list && NULL != eb_provider_list && '\0' != eb_provider_list[0]) {
			gdpr_len += snprintf(post_temp_ptr, MAX_POST_DATA_LEN - gdpr_len, ",%s%s", GDPR_GOOGLE_EB_CP_LIST, eb_provider_list);
			post_temp_ptr = post_data + gdpr_len;
		}
	}

	memcpy(post_temp_ptr,END_STRING, (sizeof (END_STRING) - 1));
	post_temp_ptr += (sizeof (END_STRING) - 1);
	return post_temp_ptr-post_data;
}

//Returns the ptr to structure which contains function pointers to create request and process response. 
//By default, it returns default adapter. 
rt_campaign_t* rt_get_ops(int campaign_id){
	(void) campaign_id;
	return  rt_campaign_adapter_map[DEFAULT_ADAPTER].rt_campaign_adapter;
}

//Max len of truncated_ip must be >= ip
int truncate_ipv4(char* truncated_ip, const char* ip) {
	int dots = 0, index = 0;
	int status = 0;
	while (ip[index] != '\0') {
		if ( ip[index] == '.' ) {
			dots++;
		}
		if ( dots == IPV4_LEVEL ) {
			break;
		}
		truncated_ip[index] = ip[index];
		index++;
		
		truncated_ip[index] = '\0';
	}
	return status;
}
int truncate_ipv6(char* truncated_ip, const char* ip){
	int status=-1;
	struct in6_addr  ipv6_addr;
    if (inet_pton(AF_INET6, ip , &ipv6_addr)> 0){
        sprintf(truncated_ip,"%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x",
        ipv6_addr.s6_addr[0], ipv6_addr.s6_addr[1], ipv6_addr.s6_addr[2], ipv6_addr.s6_addr[3],
        ipv6_addr.s6_addr[4], ipv6_addr.s6_addr[5], ipv6_addr.s6_addr[6], ipv6_addr.s6_addr[7],
        ipv6_addr.s6_addr[8], ipv6_addr.s6_addr[9], ipv6_addr.s6_addr[10], ipv6_addr.s6_addr[11],
        ipv6_addr.s6_addr[12], ipv6_addr.s6_addr[13], ipv6_addr.s6_addr[14], ipv6_addr.s6_addr[15]);
        
		truncated_ip[IPV6_TRUNCATE_END] = '\0';
		status=0;
    }  
	return status;
}
int truncate_ip_address(char* truncated_ip, const char* ip) {
	int status = -1;
	if ( strchr( ip , '.' ) ) {
    	status = truncate_ipv4 (truncated_ip,ip);
	}
	else if ( strchr(ip , ':' ) ) {
		status = truncate_ipv6 (truncated_ip,ip);
	}
	DEBUG_LOG("IP:%s Truncated IP:%s\n",ip,truncated_ip);
	return status;
}

void truncate_xff(const char* xff, char* truncated_xff)
{
	char tmp_xff[MAX_LEN_XFF+1];
	char truncated_ip_add[MAX_IPSTR_LEN];
	const char* delim=",";
	char * saveptr=NULL;
	char * token=NULL;
	int len=0,i=0,retval=-1;

	if(!xff) return; 

	tmp_xff[0]='\0';
	tmp_xff[MAX_LEN_XFF]='\0';
	strncpy(tmp_xff,xff,MAX_LEN_XFF);
	token=strtok_r(tmp_xff,delim,&saveptr);

	while(token){
		retval= truncate_ip_address(truncated_ip_add, token);
		if(retval == 0){
			len=strlen(truncated_ip_add);
			if(i+len>=MAX_LEN_XFF){
				llog_write(L_DEBUG, "\nError Exceeding max XFF limit for XFF  %s\n",xff);
				break;
			}
			strncpy(truncated_xff+i,truncated_ip_add,len);
      			i+=len;
			truncated_xff[i++]=',';
		}
		token=strtok_r(NULL,delim,&saveptr);
	} 
	if(i>0)
	truncated_xff[--i]='\0';
}

//initialize RTB specific custom params
void init_rtb_custom_params( rt_request_params_t* in_request_params, const ad_server_additional_params_t* additional_parameter ) {
	const char* country = NULL;
	const char* str_con_name = NULL;
	rt_custom_params_t *rt_custom_params = &(in_request_params->rt_custom_params);
	int ret;
	//Convert country code from alpha2 to alpha3 format as required by OpenRTB
	rt_custom_params->maxmind_country_code = NULL;
	if (in_request_params->ad_server_req_gen_params->remote_ip_addr != NULL && in_request_params->ad_server_req_gen_params->remote_ip_addr[0] != '\0') {
		country = additional_parameter->gd.iso_country_code;
	}
	if (country != NULL && country[0] != '\0' ) {
		rt_custom_params->maxmind_country_code = (char *)get_alpha3_from_alpha2(country);
	}

	rt_custom_params->publisher_country_code = NULL;
	if ( in_request_params->in_server_req_params->country[0] != '\0' ) {
		rt_custom_params->publisher_country_code = (char *)get_alpha3_from_alpha2(in_request_params->in_server_req_params->country);
	}

	//Convert language parameter into alpha2 parameter as required by OpenRTB
	if (in_request_params->ad_server_req_gen_params->accept_lang[0] != '\0') {
		strncpy(rt_custom_params->alpha2_lang, in_request_params->ad_server_req_gen_params->accept_lang, ALPHA2_LEN);
		rt_custom_params->alpha2_lang[ALPHA2_LEN] = '\0';
	} else {
		rt_custom_params->alpha2_lang[0] = '\0';
	}

	if (in_request_params->in_server_req_params->timezone[0] != '\0' && IsValidTimeZone(in_request_params->in_server_req_params->timezone)) {
		rt_custom_params->utcoffset = (int) (atof(in_request_params->in_server_req_params->timezone) * 60); //convert to minutes
	} else {
		rt_custom_params->utcoffset = INT_MAX;
	}

	/* Truncate ip and xff if coppa_compliant is 1 */
	rt_custom_params->truncated_ip[0] = '\0';
	rt_custom_params->truncated_xff[0] = '\0';
	if (in_request_params->in_server_req_params->is_coppa_compliant == 1) { 
		//in case of coppa, remove lowest 8 bits of IP4 and 32 bits of IPv6
		ret = truncate_ip_address(rt_custom_params->truncated_ip, in_request_params->ad_server_req_gen_params->remote_ip_addr);
		if(ret != 0){
				strncpy(rt_custom_params->truncated_ip, in_request_params->ad_server_req_gen_params->remote_ip_addr, MAX_IPSTR_LEN-1);
				rt_custom_params->truncated_ip[MAX_IPSTR_LEN - 1] = '\0';
		}
		const char* xff_header = get_header_value(&(additional_parameter->header_map), "HTTP_X_FORWARDED_FOR");
		truncate_xff(xff_header, rt_custom_params->truncated_xff);
	}


	if(in_request_params->in_server_req_params->mobile_nettype[0] != '\0') {
		str_con_name = &(in_request_params->in_server_req_params->mobile_nettype[0]);
	} else if (additional_parameter->connection_name[0] != '\0') {
		str_con_name = &(additional_parameter->connection_name[0]);
	}

#define WIFI_ID          2
#define CELLULAR_ID      3

	rt_custom_params->int_con_type = 0;
	if ( str_con_name != NULL && str_con_name[0] != '\0' ) {
		if (strcasestr(str_con_name, "cellular") != NULL) {
			rt_custom_params->int_con_type = CELLULAR_ID;
		} else if ( strcasestr(str_con_name, "wifi") != NULL) {
			rt_custom_params->int_con_type = WIFI_ID;
		}
	}

	return;
}

//This is called while generating RTB request data for a campaign, It initializes datastructures used in realtime bidding
void rt_bidding_initialize(
		rt_response_params_t* response_params
		)
{
	
		//Set default values to initialize structure variables
		response_params->campaign_id = 0;
		response_params->campaign_index = -1;
		response_params->dp_id = 0;
		response_params->dsp_user_match_found = 0;
		response_params->digitrust_id_present = 0;
		response_params->log_qps_logger = 0;
		response_params->skip_user_floor = 0;
		response_params->apply_normal_distribution = 0;
		response_params->bid_price_encryption_enabled = 0;
		response_params->second_price_encryption_enabled = 0;
		response_params->click_tracking_url_encoding_enabled = 0;
		response_params->pass_blank_click_tracking_url = 0;
		response_params->is_multibid = 0;
		response_params->send_winloss_info = 0;
		response_params->protocol = 0;
		response_params->deal_no_bid_reason = 0;
		response_params->enabled_ias_services = 0;
		response_params->skip_UCAF = 0;
		response_params->log_full_user_id = 0;
		response_params->open_auction_type = AUCTION_TYPE_SECOND_PRICE;
		response_params->rt_req_id_index = 0;
		response_params->parent_index = -1;
		response_params->child_index = -1;

		response_params->bid_response_params.str_bid_id[0] = '\0';
		response_params->bid_response_params.request_url[0] = '\0';
		response_params->bid_response_params.transaction_id[0] = '\0';
		response_params->bid_response_params.request_id[0] = '\0';
		response_params->bid_response_params.ebid[0] = '\0';
		response_params->bid_response_params.u_url.html_url[0] = '\0';
		response_params->bid_response_params.cookie[0] = '\0';
		//clicktrack_keyword, second_price_macro are initialized in rt_bidding_create_request()
		response_params->bid_response_params.landing_page_url[0] = '\0';
		response_params->bid_response_params.landing_page_tld[0] = '\0';
		response_params->bid_response_params.creative_id[0] = '\0';
		response_params->bid_response_params.creative_type = -1;
		response_params->bid_response_params.iurl[0] = '\0';
		response_params->bid_response_params.dsp_campaign_id[0] = '\0';
		response_params->bid_response_params.rich_media_tech_name[0] = '\0';
		response_params->bid_response_params.viewabilityvendors[0] = '\0';
		response_params->bid_response_params.pub_deal_id[0] = '\0';
		response_params->bid_response_params.creative_len = 0;
		response_params->bid_response_params.type = INVALID_TYPE; // neither HTML nor JS nor creative_tag
		response_params->bid_response_params.bid_id = 0;
		response_params->bid_response_params.ecpm = 0.0;
		response_params->bid_response_params.req_processed = 0; // !=1 value means Time out i.e no response received from DSP
		response_params->bid_response_params.response_buffer_length = 0;
		response_params->bid_response_params.response_buffer = NULL;
		response_params->bid_response_params.response_buffer_alloc_count = 0;
		response_params->bid_response_params.response_complete = 0; // !=1 value mean mandatory params missing
		response_params->bid_response_params.landing_page_flag = 0;
		response_params->bid_response_params.advertiser_id = 0;
		response_params->bid_response_params.domain_id = 0;
		response_params->bid_response_params.pubmatic_buyer_id = 0;
		response_params->bid_response_params.pubmatic_dsp_buyer_id = 0;
		response_params->bid_response_params.dsp_buyer_id = DEFAULT_DSP_BUYER_ID;
		response_params->bid_response_params.rich_media_ad_creative_attribute_id = -1;
		response_params->bid_response_params.advertiser_category_id.list = NULL; 
		response_params->bid_response_params.advertiser_category_id.count = 0;
		response_params->bid_response_params.http_response_code = -1;
		//response_params->bid_response_params.str_dsp_buyer_id[0] = '\0';
	
		response_params->bid_response_params.stamp_after_api_call.tv_usec = response_params->bid_response_params.stamp_after_api_call.tv_sec = 0;
		response_params->bid_response_params.gzipped = 0 ;
		response_params->bid_response_params.flexidrproxy_dsp_status_code = FLEXIDRPROXY_DSP_UNKNOWN ;
}

//Debuging function. 
int print_all_params( rt_request_params_t *in_request_params) {
	int i;
	llog_write(L_DEBUG, "\n printing general params");
#if defined(__LP64__) || defined(_LP64)
	llog_write(L_DEBUG, "\n addr gen p %llx", (unsigned long long)in_request_params->ad_server_req_gen_params);
	llog_write(L_DEBUG, "\n addr req p %llx", (unsigned long long)in_request_params->in_server_req_params);
#else
	llog_write(L_DEBUG, "\n addr gen p %lx", (long unsigned int)in_request_params->ad_server_req_gen_params);
	llog_write(L_DEBUG, "\n addr req p %lx", (long unsigned int)in_request_params->in_server_req_params);
#endif /* defined(__LP64__) || defined(_LP64) */
	llog_write(L_DEBUG,"\n%s", in_request_params->ad_server_req_gen_params->browser);
	llog_write(L_DEBUG,"\n%s", in_request_params->ad_server_req_gen_params->accept_lang);
	llog_write(L_DEBUG,"\n%s", in_request_params->in_server_req_params->timezone);
	llog_write(L_DEBUG,"\n%s", in_request_params->in_server_req_params->screen_resolution);
	llog_write(L_DEBUG,"\n%s", in_request_params->in_server_req_params->ad_position);
	llog_write(L_DEBUG,"\n%s", in_request_params->ad_server_req_gen_params->user_guid);
	llog_write(L_DEBUG,"\n%s", in_request_params->ad_server_req_gen_params->unique_id);
	llog_write(L_DEBUG,"\n%s", in_request_params->ad_server_req_gen_params->remote_ip_addr);
	llog_write(L_DEBUG, "\n params");
	llog_write(L_DEBUG,"\n operid :%ld",in_request_params->in_server_req_params->oper_id);
	llog_write(L_DEBUG,"\n pub id :%ld",in_request_params->in_server_req_params->publisher_id);
	llog_write(L_DEBUG,"\nsite id: %ld",in_request_params->in_server_req_params->site_id);
	llog_write(L_DEBUG,"\n ad_id: %ld",in_request_params->in_server_req_params->ad_id);
	llog_write(L_DEBUG,"\n selected adserver id: %ld",in_request_params->in_server_req_params->selected_adserver_id);
	llog_write(L_DEBUG,"\n ad height %ld", (long int)in_request_params->in_server_req_params->ad_height);
	llog_write(L_DEBUG,"\n ad width %ld", (long int)in_request_params->in_server_req_params->ad_width);
	llog_write(L_DEBUG,"\n def server %ld", (long int)in_request_params->in_server_req_params->defaulted_adserver_id);
	llog_write(L_DEBUG,"\n adhistory %s",in_request_params->in_server_req_params->adhistory);
	llog_write(L_DEBUG,"\n pg url%s",in_request_params->in_server_req_params->page_url);
	llog_write(L_DEBUG,"\n frame name %s",in_request_params->in_server_req_params->frame_name);
	llog_write(L_DEBUG,"\n bg color%s",in_request_params->in_server_req_params->bg_color);
	llog_write(L_DEBUG,"\n text color %s",in_request_params->in_server_req_params->text_color);
	llog_write(L_DEBUG,"\n link color%s",in_request_params->in_server_req_params->link_color);
	llog_write(L_DEBUG,"\n time st%s",in_request_params->in_server_req_params->time_stamp);
	llog_write(L_DEBUG,"\n rand no %s",in_request_params->in_server_req_params->random_number);
	//llog_write(L_DEBUG,"\n ref url%s",in_request_params->in_server_req_params->ref_url); 
	llog_write(L_DEBUG,"\n rt params");
	llog_write(L_DEBUG,"\n timezone %s",in_request_params->request_url_params.timezone);
	//llog_write(L_DEBUG,"\n keyword %s",in_request_params->request_url_params.keyword_list);
	llog_write(L_DEBUG,"\n catagory %s",in_request_params->request_url_params.catagory_list);
	//llog_write(L_DEBUG,"\n frequency %d", in_request_params->request_url_params.frequency);
	llog_write(L_DEBUG,"\n cookie %s", in_request_params->request_url_params.cookie);
	for(i=0;i<in_request_params->request_url_params.max_rt_batch_count; i++)
		llog_write(L_DEBUG,"\nreq id[%d] %s",i,in_request_params->request_url_params.request_id[i]);
	return ADS_ERROR_SUCCESS;
}
static struct curl_slist* rtb_req_proxy_get_headers(
	struct curl_slist** header_list,
	int* size_header_list,
	const char* cmpg_url,
	int adstimeout
) {
	struct curl_slist *result = NULL;
	header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "Content-Type: application/json");
	header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "Expect:");
	char tmp_buff[1024];
	sprintf(tmp_buff, "X-purl: %s", cmpg_url);
	result = header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], tmp_buff);
	snprintf(tmp_buff, sizeof(tmp_buff)-1, REQ_ADSERVER_TIMEOUT_HEADER_TEMPLATE, adstimeout );
	tmp_buff[sizeof(tmp_buff)-1] = '\0';
	
	result = header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], tmp_buff);
	(*size_header_list)++;
#ifdef DEBUG
	ERROR_LOG("proxy: hdr: %s, data = %s, next = %p, size_of_header_lists = %d\n", tmp_buff, result->data, result->next, *size_header_list);
#endif
	return result;
}

//Creation of curl easy handle, setting config params per realtime campaign.
int rt_bidding_create_request( void *in_request_params_x,
			       int request_count,
			       void *out_response_params_x, long campaign_id,
			       void *site_x,
			       cache_handle_t *cache_handle,
			       db_connection_t *dbconn,
			       const void * rt_request_url_params_mask1_x,
			       void *additional_parameter_x,
			       void *cmpg_dp_params_x,
			       char *request_url_with_mandatory_params,
			       char* post_data,
			       char* campaign_cookie,
			       void *adcampaign_x,
			       void *header_list_x,
			       int *size_header_list,
			       void* adcampaigns_list_x,
			       const int nelements,
			       const int current_index,
				void *p_buffer_tracker
			       )
//encoded_request_params_t *encoded_request_params)
{
	(void) campaign_id;
	(void) site_x;
	(void) cache_handle;
	(void) dbconn;
	(void) p_buffer_tracker;
	rt_request_params_t *in_request_params = (rt_request_params_t *) in_request_params_x;
        rt_response_params_t *out_response_params = (rt_response_params_t *) out_response_params_x;
        const rt_request_url_params_mask_t * rt_request_url_params_mask1 =
                (rt_request_url_params_mask_t *) rt_request_url_params_mask1_x;
        ad_server_additional_params_t *additional_parameter = (ad_server_additional_params_t *)additional_parameter_x;
        campaign_data_provider_data_ops_params_t *cmpg_dp_params = (campaign_data_provider_data_ops_params_t *)cmpg_dp_params_x;
        publisher_site_ad_campaign_list_t *adcampaign = (publisher_site_ad_campaign_list_t *)adcampaign_x;
	struct curl_slist** header_list = (struct curl_slist**) header_list_x;
	publisher_site_ad_campaign_list_t * adcampaigns_list=(publisher_site_ad_campaign_list_t *)adcampaigns_list_x;

	int retval=0;
	CURLcode curl_retval=CURLE_OK;	
	char* temp_ptr;
	int post_data_len;
	int flag=0;// Whether post data to be sent is not NULL?
	memcached_blocklist_t *blocked_list = NULL;
	int rtb_debug_enabled = additional_parameter->adserver_config_params->rtb_debug_flag;
	post_data[0] = post_data[MAX_POST_DATA_LEN] = '\0';

	if(in_request_params->fte_additional_params->curl_handle_cache[request_count] ==  NULL) {
		in_request_params->fte_additional_params->curl_handle_cache[request_count] = curl_easy_init();
		if(in_request_params->fte_additional_params->curl_handle_cache[request_count] == NULL) {
			llog_write(L_DEBUG,"\nERROR: Curl easy handle failed %s:%d\n",__FILE__,__LINE__);
			return(RTB_ERROR);
		}
	}

        retval = default_get_request_url(in_request_params, 
                  	rt_request_url_params_mask1, 
                        out_response_params, 
                      	additional_parameter,
                      	request_url_with_mandatory_params,
                      	campaign_cookie,
                      	adcampaign
                      	);
	
	if(retval != RTB_SUCCESS)	{
		return(RTB_ERROR);
	}

	
	/* Copy the string in response_params. Used for click tracking support */
	strncpy(out_response_params->bid_response_params.clicktrack_keyword, rt_request_url_params_mask1->clicktrack_keyword, MAX_RTB_CLICKTRACK_KEYWORD_LEN);
	out_response_params->bid_response_params.clicktrack_keyword[MAX_RTB_CLICKTRACK_KEYWORD_LEN] = '\0';
	strncpy(out_response_params->bid_response_params.second_price_macro, rt_request_url_params_mask1->second_price_macro, MAX_SECOND_PRICE_MACRO_SIZE);
	out_response_params->bid_response_params.second_price_macro[MAX_SECOND_PRICE_MACRO_SIZE] = '\0';

	//Caching the easy handles
	/* Call curl functions now */
	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
			CURLOPT_URL, 
			out_response_params->bid_response_params.request_url);

	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}
	// Whether to use this or use curl_easy_reset?
	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
			CURLOPT_HTTPGET, 
			1L);

   	if(curl_retval != CURLE_OK ){
 	 	return(RTB_ERROR);
   	}

	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
			CURLOPT_WRITEFUNCTION,
			default_process_response);

	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}

	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
			CURLOPT_WRITEDATA, 
			(void *)&(out_response_params->bid_response_params));

	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}

	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
			CURLOPT_NOSIGNAL, 1);

	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}
	blocked_list = in_request_params->pub_site_rich_media_params->blocked_list;
    if (	blocked_list != NULL &&
			blocked_list->json_total_len > 12) //TODO: need to changes json_total len ????
	{
            temp_ptr = blocked_list->json_url_blocked_list;
            temp_ptr = deserialize_int((unsigned char *)temp_ptr, &blocked_list->json_blocked_creative_attributes_len);
            temp_ptr += blocked_list->json_blocked_creative_attributes_len;
            temp_ptr = deserialize_int((unsigned char *)temp_ptr, &blocked_list->json_blocked_advt_categories_len);
            temp_ptr += blocked_list->json_blocked_advt_categories_len;
		temp_ptr = deserialize_int((unsigned char *)temp_ptr, &blocked_list->json_blocked_iab_advt_categories_len);
		temp_ptr += blocked_list->json_blocked_iab_advt_categories_len;
            temp_ptr = deserialize_int((unsigned char *)temp_ptr, &blocked_list->json_url_blockedlist_len);
	}
	else if (blocked_list != NULL)
	{
            blocked_list->json_blocked_creative_attributes_len = 0;
            blocked_list->json_blocked_advt_categories_len = 0;
		blocked_list->json_blocked_iab_advt_categories_len = 0;
	    blocked_list->json_url_blockedlist_len = 0;
	}

#ifdef FUNCTIONAL_TESTING
		if (blocked_list != NULL)
		{
			llog_write(L_DEBUG,"\nlen_creative_attributes=%d len_creative_categories=%d len_iab_creative_categories=%d len_url=%d allowed_creative_attributes=%d %s:%d\n",
        	                blocked_list->json_blocked_creative_attributes_len,
                	        blocked_list->json_blocked_advt_categories_len,
							blocked_list->json_blocked_iab_advt_categories_len,
                        	blocked_list->json_url_blockedlist_len,
	                        blocked_list->json_allowed_creative_attributes_list_len,
				__FILE__,
				__LINE__);
		}

#endif
		post_data_len=get_post_data(post_data,
					    cmpg_dp_params,
					    in_request_params,
					    rt_request_url_params_mask1,
					    additional_parameter,
					    adcampaign,
					    out_response_params,
					    &flag,
					    adcampaigns_list,
					    nelements,
					    current_index
					    );

		// Remove after testing
        if (rtb_debug_enabled == 1) {
            fprintf(stderr,"\n cid: %u post_data_len=%d and flag = %d and post_data = ", adcampaign->campaign_id, post_data_len, flag);
	    fprintf(stderr,"%.*s\n",(int)post_data_len,post_data);
        }

        post_data[post_data_len]='\0';
#ifdef RTB_JSON_TESTING
        validate_json(post_data);
#endif

		if(flag==1) {
			curl_retval =  curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count], CURLOPT_POSTFIELDSIZE, post_data_len);
			if(curl_retval != CURLE_OK ){
				return(RTB_ERROR);
			}
			curl_retval =  curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count], CURLOPT_POSTFIELDS, post_data);
			if(curl_retval != CURLE_OK ){
				return(RTB_ERROR);
			}
			int use_proxy = 1 == rt_request_url_params_mask1->use_drproxy ||
					1 == rt_request_url_params_mask1->use_gopro;
			if (use_proxy) {
				char header[32];
				int n = snprintf(header, 32, "X-cid: %u", adcampaign->campaign_id);
				if (32 <= n) {
					ERROR_LOG("String buffer overflow while writing X-cid.  Buffer length required = %d", n);
				}
				header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list],header);

				struct curl_slist *hdr = rtb_req_proxy_get_headers(
						header_list,
						size_header_list,
						rt_request_url_params_mask1->ad_nw_url,
						additional_parameter->rtb_timeout);
				curl_retval =  curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],CURLOPT_HTTPHEADER, hdr);

			} else {
				curl_retval =  curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],CURLOPT_HTTPHEADER, header_list_post);
			}
			if(curl_retval != CURLE_OK ){
				return(RTB_ERROR);
			}
		} else {
			//reset post data
			post_data[0] = '\0';

			int use_proxy = 1 == rt_request_url_params_mask1->use_drproxy ||
					1 == rt_request_url_params_mask1->use_gopro;
			if (use_proxy) {
				char header[32];
				int n = snprintf(header, 32, "X-cid: %u", adcampaign->campaign_id);
				if (32 <= n) {
					ERROR_LOG("String buffer overflow while writing X-cid.  Buffer length required = %d", n);
				}
				header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list],header);

				struct curl_slist *hdr = rtb_req_proxy_get_headers(
						header_list,
						size_header_list,
						rt_request_url_params_mask1->ad_nw_url,
						additional_parameter->rtb_timeout);
			curl_retval =  curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],CURLOPT_HTTPHEADER, hdr);
			} else {
			curl_retval =  curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],CURLOPT_HTTPHEADER, header_list_get);// header_list_get is always NULL
			}
                        if(curl_retval != CURLE_OK ){
                                return(RTB_ERROR);
                        }
		}

	       curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count], CURLOPT_HEADERFUNCTION, NULL);
                if(curl_retval != CURLE_OK ){
                        return(RTB_ERROR);
                }

                curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count], CURLOPT_HEADERDATA,NULL);
                if(curl_retval != CURLE_OK ){
                        return(RTB_ERROR);
                }	

	/* Keeping high versose level for testing and debugging */
#ifdef FUNCTIONAL_TESTING_LOGGER_CURL
	curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],CURLOPT_VERBOSE, 1);
#endif
	/* we are done with setting up the request */
	return(RTB_SUCCESS);
}

//
//New easy handle caching code
int rt_bidding_add_request(rt_handle_t *in_handle, CURL* curl_handle) {

	CURLMcode retval = CURLM_OK;

	retval = curl_multi_add_handle(in_handle->curl_multi_handle, 
			curl_handle);

	if( retval != CURLM_OK ) {
		llog_write(L_DEBUG, "\nERROR curl_multi_add_handle() return error = %d %s:%d\n", retval, __FILE__, __LINE__);
		//llog_write(L_DEBUG,"\n Add bidding request was successful");	
		return(RTB_ERROR);
	}
	return(RTB_SUCCESS);	
}

int epoll_socket_callback(CURL* easy, curl_socket_t fd, int run_epoll, void* u, void* s) {
	(void) easy;
	(void) s;
        rt_handle_t* in_handle = (rt_handle_t*) u;
        int epollFd = in_handle->epoll_fd;
        struct epoll_event event;
        event.events = 0;
        event.data.fd = fd;

        if (run_epoll == CURL_POLL_REMOVE) {
                epoll_ctl(epollFd, EPOLL_CTL_DEL, fd, &event);
                /*
                if (res == -1 && errno != EBADF)
                        llog_write(L_DEBUG, "ERROR epoll_ctl(DEL)");
                return 0;
                */
                return 0;
        }

        if (run_epoll == CURL_POLL_IN || run_epoll == CURL_POLL_INOUT) {
                event.events |= EPOLLIN;
        }
        if (run_epoll == CURL_POLL_OUT || run_epoll == CURL_POLL_INOUT) {
                event.events |= EPOLLOUT;
        }

        if (event.events != 0) {
                int res = epoll_ctl(epollFd, EPOLL_CTL_ADD, fd, &event);
                if (res == -1) {
                        res = epoll_ctl(epollFd, EPOLL_CTL_MOD, fd, &event);
                }
		/*
                if (res == -1) {
                        llog_write(L_DEBUG, "ERROR epoll_ctl(MOD)");
                }
                */
        }

        return 0;
}

static int arm_rtb_timeout_timer(int fd, long value_ms) {
        struct itimerspec temp;
        memset(&temp, 0, sizeof(temp));
        temp.it_value.tv_sec = 0; // We assume that we would never have more than 1 second of timeout
        temp.it_value.tv_nsec = 1000000L * value_ms; // 10^6 nanoseconds in 1 millisecond
        // Arm the timer for RTB timeout
        int rc = timerfd_settime(fd, 0, &temp, NULL);
        if (rc < 0) {
                llog_write(L_DEBUG, "\nERROR timerfd_settime() failed:%s %s:%d\n", strerror(errno), __FILE__, __LINE__);
        }
        return rc;
}

static int disarm_rtb_timeout_timer(int fd) {
        struct itimerspec temp;
        memset(&temp, 0, sizeof(temp));
        // Disarm the timer for RTB timeout
        int rc = timerfd_settime(fd, 0, &temp, NULL);
        if (rc < 0) {
                llog_write(L_DEBUG, "\nERROR timerfd_settime() failed:%s %s:%d\n", strerror(errno), __FILE__, __LINE__);
        }
        return rc;
}

/**
 * epoll() timer callback function
 * It reduces the timeout value for epoll_wait()
 */
int epoll_timer_callback(CURLM* multi, long timeout_ms, void* u) {
        // llog_write(L_DEBUG, "timer_callback:ThreadId:%d|timeout_ms:%ld|time_left =%d\n", params->th_id, timeout_ms, params->time_left);
        (void) multi;
        rt_handle_t *in_handle = (rt_handle_t *)u;
        in_handle->wait_time_ms = timeout_ms;
        return 0;
}


/**
 * Run RTB calls using epoll() implementation
 */
int execute_epoll(rt_handle_t *in_handle) {
        CURLMcode retval;
        struct epoll_event events[MAX_EVENTS];
        int running_handles;
        int it = 0;
        int event_count;
        int time_over = 0; // 1 indicates time is over

        retval = curl_multi_socket_action(in_handle->curl_multi_handle, CURL_SOCKET_TIMEOUT, 0, &running_handles);
        if ( retval != CURLM_OK) {
                llog_write(L_DEBUG, "ERROR curl_multi_socket_action() return error = %d %s:%d\n", retval,__FILE__, __LINE__);
                return RTB_ERROR;
        }

        int rc = arm_rtb_timeout_timer(in_handle->fd_time_left, in_handle->time_left_ms);
	if (rc != 0) {
                llog_write(L_DEBUG, "\nERROR arm_rtb_timeout_time() return error = %d, skipping RTB %s:%d\n", rc, __FILE__, __LINE__);
                return RTB_ERROR;
        }
        int ep_wait_time_ms = 0;
        while (running_handles > 0 &&  time_over == 0) {
                ep_wait_time_ms = in_handle->wait_time_ms;
                event_count = epoll_wait(in_handle->epoll_fd, events, MAX_EVENTS, ep_wait_time_ms);
                if (event_count == -1) {
                        llog_write(L_DEBUG, "\nERROR epoll_wait:%d|%s:%s:%d\n", errno, strerror(errno), __FILE__, __LINE__);
                        disarm_rtb_timeout_timer(in_handle->fd_time_left);
                        // Something HORRIBLE has happened
                        return RTB_ERROR;
                } else if (event_count == 0) {
                        // reset the timer to -1 in case we never get callbacks to timer_cb
                        in_handle->wait_time_ms = -1;
                        retval = curl_multi_socket_action(in_handle->curl_multi_handle, CURL_SOCKET_TIMEOUT, 0, &running_handles);
                        if ( retval != CURLM_OK) {
                                llog_write(L_DEBUG, "\nERROR curl_multi_socket_action() return error = %d %s:%d\n", retval,__FILE__, __LINE__);
                                disarm_rtb_timeout_timer(in_handle->fd_time_left);
                                return RTB_ERROR;
                        }
                } else {
                        // Some event including RTB timeout has happened :D
                        for(it = 0; it < event_count; it++) {
				int ev_bitmask = 0;
                                switch (events[it].events) {
                                        case EPOLLIN:
                                                ev_bitmask |= CURL_CSELECT_IN;
                                                break;
                                        case EPOLLOUT:
                                                ev_bitmask |= CURL_CSELECT_OUT;
                                                break;
                                        case EPOLLERR:
                                                ev_bitmask |= CURL_CSELECT_ERR;
                                                break;
                                        default:
                                                // More than one I/O event is detected on this fd, let curl figure out on its own what set of events has happened
                                                ev_bitmask = 0;
                                }
                                if (events[it].data.fd != in_handle->fd_time_left) {
                                        retval = curl_multi_socket_action(in_handle->curl_multi_handle, events[it].data.fd, ev_bitmask, &running_handles);
                                        if (retval != CURLM_OK) {
                                                llog_write(L_DEBUG, "\nERROR curl_multi_socket_action() return error = %d %s:%d\n", retval,__FILE__, __LINE__);
                                                disarm_rtb_timeout_timer(in_handle->fd_time_left);
                                                return RTB_ERROR;
                                        }
                                } else {
                                        time_over = 1;
                                        // We allow to process all the events which were received, its Okay, be a bit generous :)
                                }
                        }
                }
        }
        disarm_rtb_timeout_timer(in_handle->fd_time_left);
        return 1;
}

/**
 * Run RTB calls using select() implementation
 */
int execute_select(rt_handle_t *in_handle) {
        CURLMcode retval = CURLM_OK;
        int still_running = 0;
        struct timeval timeout;
        int rc; /* select() return code */
        fd_set fdread;
        fd_set fdwrite;
        fd_set fdexcep;
        int maxfd;

        timeout.tv_sec =  in_handle->time_left_ms/1000;
        timeout.tv_usec = (in_handle->time_left_ms%1000)*1000; /*conversion factor */

        //Curl multi-perform call
        while((retval=curl_multi_perform(in_handle->curl_multi_handle, &still_running)) == CURLM_CALL_MULTI_PERFORM );

        if ( retval != CURLM_OK) {
                llog_write(L_DEBUG, "\nERROR curl_multi_perform() return error = %d %s:%d\n", retval,__FILE__, __LINE__);
                return (RTB_ERROR);
        }

	while(still_running) {
                FD_ZERO(&fdread);
                FD_ZERO(&fdwrite);
                FD_ZERO(&fdexcep);

                /* get file descriptors from the transfers */
                retval = curl_multi_fdset(in_handle->curl_multi_handle, &fdread, &fdwrite, &fdexcep, &maxfd);
                if(retval != CURLM_OK){
                        llog_write(L_DEBUG, "\nERROR curl_multi_fdset() return error = %d %s:%d\n", retval,  __FILE__, __LINE__);
                        return(RTB_ERROR);
                }
                if(maxfd == -1){
                        llog_write(L_DEBUG, "\nERROR curl_multi_perform maxfd = -1 %s:%d\n", __FILE__, __LINE__);
                        break;
                }
                else{
                        if(timeout.tv_sec <= 0 && timeout.tv_usec <= 0){
                                llog_write(L_DEBUG, "\nERROR tv_sec = 0 and tv_usec = 0 %s:%d\n", __FILE__, __LINE__);
                                still_running = 0;
                                rc = 0;
                                break;
                        } else {
                                errno = 0;
                                rc = select(maxfd+1, &fdread, &fdwrite, &fdexcep, &timeout);
                                /*if (rc == -1 && errno != EINPROGRESS) {
                                        rc = -1;
                                        }*/
                        }
                }
		
		switch(rc) {
                        case -1:
                                /* select error */
                                //
                                llog_write(L_DEBUG,"\nERROR:RTB select returned error %s:%d\n",__FILE__,__LINE__);
                                perror("\nERROR SELECT RTB");
                                still_running = 0;
                                //assert(0);
                                break;
                        case 0:
                                //Timeout case. setting still_running to 0 essentially breaks the loop
                                //
                                //llog_write(L_DEBUG,"ERROR:RTB select timed out %s:%d\n",__FILE__,__LINE__);
                                //~
                                still_running = 0;
                                break;
                        default:
                                /* one or more of curl's file descriptors say there's data to read
                                         or write */
                                while((retval=curl_multi_perform(in_handle->curl_multi_handle, &still_running)) ==
                                                CURLM_CALL_MULTI_PERFORM );
                                if (retval != CURLM_OK) {
                                        llog_write(L_DEBUG, "\nERROR curl_multi_perform() return error = %d %s:%d\n", retval, __FILE__, __LINE__);
                                        return (RTB_ERROR);
                                }
                                break;
                }
        }

        return 1;
}

/**
 * Execute RTB calls.
 */
int rt_bidding_do_task(rt_handle_t *in_handle, int rtb_timeout, int use_epoll)
{
        int retval = 0;
        int timeout_value = (rtb_timeout > 0)?rtb_timeout:g_rtb_ms_timeout;

        in_handle->time_left_ms = timeout_value;
        in_handle->wait_time_ms = 0;

        if (1 == use_epoll) {
                /* SET socket callback function */
                retval = curl_multi_setopt(in_handle->curl_multi_handle, CURLMOPT_SOCKETFUNCTION, epoll_socket_callback);
                if ( retval != CURLM_OK) {
                        llog_write(L_DEBUG,"\nERROR curl_multi_setopt() failed : %s %s:%d\n", curl_multi_strerror(retval), __FILE__, __LINE__);
                        return RTB_ERROR;
                }

                /* SET socket callback function parameters*/
                retval = curl_multi_setopt(in_handle->curl_multi_handle, CURLMOPT_SOCKETDATA, (void*)in_handle);
                if ( retval != CURLM_OK) {
                        llog_write(L_DEBUG,"\nERROR curl_multi_setopt() failed : %s %s:%d\n", curl_multi_strerror(retval), __FILE__, __LINE__);
                        return RTB_ERROR;
                }
		
		/* SET timmer function */
                retval = curl_multi_setopt(in_handle->curl_multi_handle, CURLMOPT_TIMERFUNCTION, epoll_timer_callback);
                if ( retval != CURLM_OK) {
                        llog_write(L_DEBUG,"\nERROR curl_multi_setopt() failed : %s %s:%d\n", curl_multi_strerror(retval), __FILE__, __LINE__);
                        return RTB_ERROR;
                }

                /* SET timmer function parameters */
                retval = curl_multi_setopt(in_handle->curl_multi_handle, CURLMOPT_TIMERDATA, (void*)in_handle);
                if ( retval != CURLM_OK) {
                        llog_write(L_DEBUG,"\nERROR curl_multi_setopt() failed : %s %s:%d\n", curl_multi_strerror(retval), __FILE__, __LINE__);
                        return RTB_ERROR;
                }

                retval = execute_epoll(in_handle);
        }else{
                retval = execute_select(in_handle);
        }

        return retval;
}


//removing curl easy handles  and desroying them.
//
int rt_bidding_cleanup(rt_handle_t *in_handle, CURL* in_response_params[], int* curl_reinit_value, rt_response_params_t* rt_response_params, int rt_request_count, int handle_cnt) {
	(void) curl_reinit_value;
	int i=0;	

	for(i=0; i< handle_cnt; i++) {
		if(in_response_params[i]!=NULL) {
			CURLMcode retval = CURLM_OK;
			retval = curl_multi_remove_handle(in_handle->curl_multi_handle, in_response_params[i]);
			
			/* Curl RTB-S2S Performance Metrics Logging */
			if (g_allow_config_reload_flag == 1 && g_curlstat_enabled_flag == 1 ) {
			    log_curlstat(in_response_params[i], __FILE__, __LINE__);			   			    
			}
			
			/* Curl RTB-S2S Performance Metrics Logging End */

			if (retval != CURLM_OK) {
				llog_write(L_DEBUG, "\nERROR curl_multi_remove_handle RTB failed with rc = %d %s:%d\n", retval, __FILE__, __LINE__);
			}
		}
		
	}

	for(i=0; i< rt_request_count; i++) {
		if (rt_response_params[i].bid_response_params.advertiser_category_id.list != NULL) {
			free (rt_response_params[i].bid_response_params.advertiser_category_id.list);
			rt_response_params[i].bid_response_params.advertiser_category_id.list = NULL;
		} 
	}
	//
	/*if(g_rtb_enable_persistent_connections!=1) {
		curl_multi_cleanup(in_handle->curl_multi_handle);
	}*/
	//~
	return(RTB_SUCCESS);
}
