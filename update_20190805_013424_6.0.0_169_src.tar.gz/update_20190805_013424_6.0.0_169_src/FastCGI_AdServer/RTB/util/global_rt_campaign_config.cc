#include "rt_campaign_config_table.h"
#include "global_rt_campaign_config.h"

RtCampaignConfigTable g_rt_campaign_config_table;

int update_global_rt_campaign_config(
        const db_connection_t * const dbconn
) {
        g_rt_campaign_config_table.Update(dbconn);
        // g_rt_campaign_config_table.PrintTable();
        return ADS_ERROR_SUCCESS;
}

int get_global_rt_campaign_config(
        const rt_request_url_params_mask_t ** rt_request_url_params_mask,
        int * ret_list_len
) {
        return g_rt_campaign_config_table.Get(
                        rt_request_url_params_mask, ret_list_len);
}
