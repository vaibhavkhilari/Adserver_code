/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <rtb_util.h>
#include <error.h>
#include <stdio.h>
#include <config.h>
#include <curl/curl.h>
#include <ad_server_types.h>
#include <pthread.h>
#include <assert.h>
#include "cache_adserver_config.h"
#include "json.h"
#include "json_util.h"
#include "json_object_private.h"
#include "url_util.h"

//moved from rtb_util.c by 
//
int g_rtb_debug_flag;
int g_rtb_ms_connection_timeout;
int g_rtb_ms_timeout;
int g_max_ads_per_ten_thousand;
int g_config_realtime_max_thread_cap;
//int g_rtb_enable_persistent_connections;
int g_rtb_connection_pool_size;
//int g_connection_reuse_info;
//int g_rtb_curl_handle_reinit_value;
int g_max_landing_page_filtering_campaigns;
int g_enable_landing_page_filtering;
int g_rtb_enable_contextual_data_providers;
int g_dp_ms_timeout;

//configuration for cookie-store curl handle
int	g_rtb_floor_rpug_conn_timeout;
int	g_rtb_floor_rpug_req_timeout;
char	*g_rtb_floor_rpug_url = NULL;
int	g_rtb_rpug_conn_timeout;
int	g_rtb_rpug_req_timeout;
char	*g_rtb_rpug_url = NULL;
int	g_rtb_spug_conn_timeout;
int	g_rtb_spug_req_timeout;
char	*g_rtb_spug_url = NULL;

//sagar
//for RTBBIBBER
int g_rtb_bidder_enabled;//to toggle between direct request method & bidder request method
//int g_rtb_bidder_curl_handle_reinit_value;kartik
int g_rtb_bidder_ms_timeout;
//~sagar

//Integral Integration parameters
int g_rtb_integral_conn_timeout;
int g_rtb_integral_req_timeout;
char *g_rtb_varnish_servers = NULL;
char *g_rtb_wops_varnish_servers = NULL;
int g_total_varnish_servers;
int g_total_wops_varnish_servers;
int g_rtb_integral_enabled;

//Prebid fraud check integration params
int g_rtb_prebid_fraud_check_conn_timeout;
int g_rtb_prebid_fraud_check_req_timeout;
int g_min_payload_for_compression ;
char *g_rtb_prebid_fraud_check_url = NULL;
char *g_rtb_prebid_fraud_check_url_host = NULL;
char *g_rtb_prebid_fraud_check_url_path = NULL;
char *g_rtb_prebid_fraud_check_key_id = NULL;
char *g_rtb_prebid_fraud_check_secret_key = NULL;

char *g_drproxy_url = NULL;
char *g_gopro_url = NULL;

double g_ecpm_notification_threshold;
/*citrus eanbled global object*/
extern int g_citrus_leaf_enabled;
//~
/* Here we read the confuration parametrs */
volatile int g_realtime_max_thread_cap; /* max number of threads that can use realtime bidding at any given point of time */
pthread_mutex_t g_realtime_mutex = PTHREAD_MUTEX_INITIALIZER;

//called during thread initialization. sets timeout information in global variables
int set_rtb_configuration(void) {

        /* local variables */
        int retval = 0;
        property_list_t *config_properties = NULL;
		char *tmp_str = NULL;

	/* Read the configuration from the configuration file */
        retval = get_config_properties(RTB_CONFIG_FILE, &config_properties);
        if (retval != ADS_ERROR_SUCCESS) {
                llog_write(L_DEBUG, "Could not get the RTB configuration properties\n");
				free_property_list(&config_properties);
                return retval;
        }

	//sagar
	retval = get_property_value(config_properties, RTB_BIDDER_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB BIDDER timeout user name not specified in configuration properties\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_bidder_ms_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_BIDDER_CURL_HANDLE_REINIT_VALUE, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR RTB_BIDDER_CURL_HANDLE_REINIT_VALUE not specified in configuration properties %s:%d\n",__FILE__,__LINE__);
		free_property_list(&config_properties);
		return retval;
	}
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_BIDDER_ENABLED, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR RTB_BIDDER_ENABLED not specified in configuration properties %s:%d\n",__FILE__,__LINE__);
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_bidder_enabled = atoi(tmp_str);
	free(tmp_str);
	//~sagar

	//
	/*
	retval = get_property_value(config_properties, RTB_ENABLE_PERSISTENT_CONNECTIONS, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR RTB Enable Persistent Connections not specified in configuration properties %s:%d\n",__FILE__,__LINE__);
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_enable_persistent_connections = atoi(tmp_str);
	free(tmp_str);
	*/

	retval = get_property_value(config_properties, RTB_CONNECTION_POOL_SIZE, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR RTB Connection Pool Size  not specified in configuration properties %s:%d\n",__FILE__,__LINE__);
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_connection_pool_size = atoi(tmp_str);
	free(tmp_str);

	/*retval = get_property_value(config_properties, RTB_GET_CONNECTION_REUSE_INFO, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR RTB Connection Reuse Information not specified in configuration properties %s:%d\n",__FILE__,__LINE__);
		free_property_list(&config_properties);
		return retval;
	}
	g_connection_reuse_info= atoi(tmp_str);
	free(tmp_str);*/

	/*retval = get_property_value(config_properties, RTB_CURL_HANDLE_REINIT_VALUE, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "ERROR RTB Curl easy handle reinit value not specified in configuration properties %s:%d\n",__FILE__,__LINE__);
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_curl_handle_reinit_value= atoi(tmp_str);
	llog_write(L_DEBUG, "RTB:START_STATUS RTB Curl easy handle reinit value = %d %s:%d\n",g_rtb_curl_handle_reinit_value,__FILE__,__LINE__);
	free(tmp_str);

	if(g_rtb_curl_handle_reinit_value < 0 ) {
		llog_write(L_DEBUG, "ERROR RTB Curl easy handle reinit value specified in configuration properties should not be negative%s:%d\n",__FILE__,__LINE__);
		free_property_list(&config_properties);
		return retval;
	}*/

	/*retval = get_property_value(config_properties, RTB_ENABLE_PURE_RTB, &tmp_str);
	  if (retval != ADS_ERROR_SUCCESS) {
	  llog_write(L_DEBUG, "ERROR RTB Curl easy handle reinit value not specified in configuration properties %s:%d\n",__FILE__,__LINE__);
	  free_property_list(&config_properties);
	  return retval;
	  }
	  g_enable_pure_rtb= atoi(tmp_str);
	  llog_write(L_DEBUG, "RTB:START_STATUS Pure rtb value = %d %s:%d\n",g_enable_pure_rtb,__FILE__,__LINE__);
	 */

	//~

	retval = get_property_value(config_properties, RTB_MS_CONNECTION_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB Connection timeout not specified in configuration properties\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_ms_connection_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB timeout user name not specified in configuration properties\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_ms_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_REQUESTS_PER_TEN_THOUSAND, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB Ads per ten thousand requests value not set\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_max_ads_per_ten_thousand = atoi(tmp_str);
	free(tmp_str);
	retval = get_property_value(config_properties, RTB_DEBUG_FLAG, &tmp_str);
	if(retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB Debug flag entry not found\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_debug_flag = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_MAX_REALTIME_THREADS, &tmp_str);
	if(retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB rtb_max_realtime_threads  entry not found \n");
		free_property_list(&config_properties);
		return retval;
	}
	g_config_realtime_max_thread_cap = atoi(tmp_str);
	free(tmp_str);


	retval = get_property_value(config_properties, RTB_MAX_LANDING_PAGE_FILTERING_CAMPAIGNS, &tmp_str);
	if(retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB rtb_max_rtb_campaign_to_apply_for_landing_page_filter  entry not found \n");
		free_property_list(&config_properties);
		return retval;
	}
	g_max_landing_page_filtering_campaigns = atoi(tmp_str);
	free(tmp_str);


	retval = get_property_value(config_properties, RTB_ENABLE_LANDING_PAGE_FILTERING, &tmp_str);
	if(retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB  rtb.enable.landing_page_filtering entry not found \n");
		free_property_list(&config_properties);
		return retval;
	}
	g_enable_landing_page_filtering =  atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_ECPM_NOTIFICATION_THRESHOLD, &tmp_str);
	if(retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB  rtb.ecpm.notification.threshold entry not found \n");
		free_property_list(&config_properties);
		return retval;
	}
	g_ecpm_notification_threshold =  atof(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_ENABLE_CONTEXTUAL_DATA_PROVIDERS, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
			llog_write(L_DEBUG, "ERROR rtb.enable.contextual.data.providers value not specified in configuration properties %s:%d\n",__FILE__,__LINE__);
			free_property_list(&config_properties);
			return retval;
	}
	g_rtb_enable_contextual_data_providers= atoi(tmp_str);
	llog_write(L_DEBUG, "RTB:START_STATUS rtb.enable.contextual.data.providers is = %d %s:%d\n",g_rtb_enable_contextual_data_providers,__FILE__,__LINE__);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_CONTEXTUAL_DATA_PROVIDERS_TIME_OUT_MS, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
			llog_write(L_DEBUG, "ERROR '%s' value not specified in configuration properties %s:%d\n",RTB_CONTEXTUAL_DATA_PROVIDERS_TIME_OUT_MS, __FILE__,__LINE__);
			free_property_list(&config_properties);
			return retval;
	}
	g_dp_ms_timeout= atoi(tmp_str);
	llog_write(L_DEBUG, "RTB:START_STATUS %s is = %d %s:%d\n",
							RTB_CONTEXTUAL_DATA_PROVIDERS_TIME_OUT_MS, g_dp_ms_timeout,__FILE__,__LINE__);
	free(tmp_str);


	retval = get_property_value(config_properties, RTB_FLOOR_RPUG_CONN_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_FLOOR_RPUG_CONN_TIMEOUT);
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_floor_rpug_conn_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_FLOOR_RPUG_REQ_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_FLOOR_RPUG_REQ_TIMEOUT);
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_floor_rpug_req_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_FLOOR_RPUG_URL, &g_rtb_floor_rpug_url);
	if (retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_FLOOR_RPUG_URL);
		free_property_list(&config_properties);
		return retval;
	}

	retval = get_property_value(config_properties, RTB_RPUG_CONN_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB rtb.rpug.conn.timeout entry not found\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_rpug_conn_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_RPUG_REQ_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB rtb.rpug.req.timeout entry not found\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_rpug_req_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_RPUG_URL, &g_rtb_rpug_url);
	if (retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB rtb.rpug.url entry not found\n");
		free_property_list(&config_properties);
		return retval;
	}

	retval = get_property_value(config_properties, RTB_SPUG_CONN_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB rtb.spug.conn.timeout entry not found\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_spug_conn_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_SPUG_REQ_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB rtb.spug.req.timeout entry not found\n");
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_spug_req_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_SPUG_URL, &g_rtb_spug_url);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB rtb.spug.url entry not found\n");
		free_property_list(&config_properties);
		return retval;
	}

	//Integral Integration parameters
	retval = get_property_value(config_properties, RTB_INTEGRAL_CONN_TIMEOUT, &tmp_str);
        if (retval != ADS_ERROR_SUCCESS) {
                llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_INTEGRAL_CONN_TIMEOUT);
                free_property_list(&config_properties);
                return retval;
        }
        g_rtb_integral_conn_timeout = atoi(tmp_str);
        free(tmp_str);

        retval = get_property_value(config_properties, RTB_INTEGRAL_REQ_TIMEOUT, &tmp_str);
        if (retval != ADS_ERROR_SUCCESS){
                llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_INTEGRAL_REQ_TIMEOUT);
                free_property_list(&config_properties);
                return retval;
        }
        g_rtb_integral_req_timeout = atoi(tmp_str);
        free(tmp_str);

        retval = get_property_value(config_properties, RTB_VARNISH_SERVERS, &g_rtb_varnish_servers);
        if (retval != ADS_ERROR_SUCCESS) {
                llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_VARNISH_SERVERS);
                free_property_list(&config_properties);
                return retval;
        }

        retval = get_property_value(config_properties, RTB_WOPS_VARNISH_SERVERS, &g_rtb_wops_varnish_servers);
        if (retval != ADS_ERROR_SUCCESS) {
                ERROR_LOG("RTB %s entry not found\n", RTB_WOPS_VARNISH_SERVERS);
                free_property_list(&config_properties);
                return retval;
        }

        retval = get_property_value(config_properties, RTB_DRPROXY_URL, &g_drproxy_url);
				if (retval != ADS_ERROR_SUCCESS) {
					llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_DRPROXY_URL);
					free_property_list(&config_properties);
					return retval;
				}

        retval = get_property_value(config_properties, RTB_GOPRO_URL, &g_gopro_url);
	if (ADS_ERROR_SUCCESS != retval) {
		ERROR_LOG("RTB %s entry not found", RTB_GOPRO_URL);
		free_property_list(&config_properties);
		return retval;
	}

	retval = get_property_value(config_properties, RTB_INTEGRAL_ENABLED, &tmp_str);
        if (retval != ADS_ERROR_SUCCESS){
                llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_INTEGRAL_ENABLED);
                free_property_list(&config_properties);
                return retval;
        }
        g_rtb_integral_enabled = atoi(tmp_str);
        free(tmp_str);

	// Prebid fraud check integration parameter parsing
	retval = get_property_value(config_properties, RTB_PREBID_FRAUD_CHECK_CONN_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_PREBID_FRAUD_CHECK_CONN_TIMEOUT);
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_prebid_fraud_check_conn_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_PREBID_FRAUD_CHECK_REQ_TIMEOUT, &tmp_str);
	if (retval != ADS_ERROR_SUCCESS){
		llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_PREBID_FRAUD_CHECK_REQ_TIMEOUT);
		free_property_list(&config_properties);
		return retval;
	}
	g_rtb_prebid_fraud_check_req_timeout = atoi(tmp_str);
	free(tmp_str);

	retval = get_property_value(config_properties, RTB_PREBID_FRAUD_CHECK_URL, &g_rtb_prebid_fraud_check_url);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_PREBID_FRAUD_CHECK_URL);
		free_property_list(&config_properties);
		return retval;
	}

	retval = parse_hostname_path_from_url(g_rtb_prebid_fraud_check_url,
				&g_rtb_prebid_fraud_check_url_host,
				&g_rtb_prebid_fraud_check_url_path);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB failed to parse hostname and path from url\n");
		free_property_list(&config_properties);
		return retval;
	}

	retval = get_property_value(config_properties, RTB_PREBID_FRAUD_CHECK_KEY_ID, &g_rtb_prebid_fraud_check_key_id);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_PREBID_FRAUD_CHECK_KEY_ID);
		free_property_list(&config_properties);
		return retval;
	}

	retval = get_property_value(config_properties, RTB_PREBID_FRAUD_CHECK_SECRET_KEY, &g_rtb_prebid_fraud_check_secret_key);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_PREBID_FRAUD_CHECK_SECRET_KEY);
		free_property_list(&config_properties);
		return retval;
	}

	retval = get_property_value(config_properties, RTB_MIN_PAYLOAD_FOR_COMPRESSION, &tmp_str);
	g_min_payload_for_compression = atoi(tmp_str) ;
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "RTB %s entry not found\n", RTB_MIN_PAYLOAD_FOR_COMPRESSION);
		free_property_list(&config_properties);
		return retval;
	}
	free(tmp_str);

	llog_write(L_DEBUG, "INFO: g_rtb_floor_rpug_conn_timeout:%d, g_rtb_floor_rpug_req_timeout:%d, g_rtb_floor_rpug_url:%s\n",
				g_rtb_floor_rpug_conn_timeout, g_rtb_floor_rpug_req_timeout, g_rtb_floor_rpug_url);
	llog_write(L_DEBUG, "INFO: g_rtb_rpug_conn_timeout:%d, g_rtb_rpug_req_timeout:%d, g_rtb_rpug_url:%s\n",
				g_rtb_rpug_conn_timeout, g_rtb_rpug_req_timeout, g_rtb_rpug_url);
	llog_write(L_DEBUG, "INFO: g_rtb_spug_conn_timeout:%d, g_rtb_spug_req_timeout:%d, g_rtb_spug_url:%s\n",
				g_rtb_spug_conn_timeout, g_rtb_spug_req_timeout, g_rtb_spug_url);
	llog_write(L_DEBUG, "INFO: %s:%d, %s:%d, %s:%d, %s:%s, %s:%s, %s:%s\n",
				RTB_INTEGRAL_ENABLED     , 	g_rtb_integral_enabled, 
				RTB_INTEGRAL_CONN_TIMEOUT, 	g_rtb_integral_conn_timeout, 
				RTB_INTEGRAL_REQ_TIMEOUT , 	g_rtb_integral_req_timeout, 
				RTB_VARNISH_SERVERS,	g_rtb_varnish_servers,
				RTB_DRPROXY_URL, g_drproxy_url,
				RTB_GOPRO_URL, g_gopro_url);

	llog_write(L_DEBUG, "INFO: %s:%d, %s:%d, %s:%s, %s:%s, %s:%s, %s:%s, %s:%s, %s:%s\n",
			RTB_PREBID_FRAUD_CHECK_CONN_TIMEOUT, g_rtb_prebid_fraud_check_conn_timeout,
			RTB_PREBID_FRAUD_CHECK_REQ_TIMEOUT, g_rtb_prebid_fraud_check_req_timeout,
			RTB_PREBID_FRAUD_CHECK_URL, g_rtb_prebid_fraud_check_url,
			"Parsed Hostname", g_rtb_prebid_fraud_check_url_host,
			"Parsed Path", g_rtb_prebid_fraud_check_url_path,
			RTB_PREBID_FRAUD_CHECK_KEY_ID, g_rtb_prebid_fraud_check_key_id,
			RTB_PREBID_FRAUD_CHECK_SECRET_KEY, g_rtb_prebid_fraud_check_secret_key,
			RTB_WOPS_VARNISH_SERVERS, g_rtb_wops_varnish_servers);

	free_property_list(&config_properties);

	llog_write(L_DEBUG,"\n+--------------RTB setup complete-----------------+i\n");
	return ADS_ERROR_SUCCESS;
}

//capping implemented to control number of threads using realtime apis
//this function increments token 
int acquire_realtime_token(int rtb_skip_percentage, mt_state* state)
{
	if (rtb_skip_percentage <= 0 || rtb_skip_percentage > 100) {
		return 1;
	}
	unsigned int allow_range = 4294967295U * ((100 - rtb_skip_percentage)/100.0);
	unsigned int value = mts_lrand(state);
	if (value < allow_range) {
		return 1;
	}
	return 0;
#if 0
	//int retval = 0;	
	//retval = pthread_mutex_trylock(&g_realtime_mutex);
	//if(retval == 0){
	if(g_realtime_max_thread_cap < (g_config_realtime_max_thread_cap+1)){
		g_realtime_max_thread_cap++;	
		//pthread_mutex_unlock(&g_realtime_mutex);
		return(1);
		//}
		//pthread_mutex_unlock(&g_realtime_mutex);
}
return(0);	
#endif
}

//capping implemented to control number of threads using realtime apis
//this function decrements token
int release_realtime_token(){
		//pthread_mutex_lock(&g_realtime_mutex);
		g_realtime_max_thread_cap--;
		//pthread_mutex_unlock(&g_realtime_mutex);
		//
		return ADS_ERROR_SUCCESS;
		//~
}

char * get_current_timestamp(char *buff)
{
	/*time_t result;
		struct tm re_ent_ptr;
		char buf[72];
		char *p=NULL;
		result = time(NULL);
		if(buff!=NULL){
		buff[0] = '\0';
		strncpy(buff, asctime_r(localtime_r(&result, &re_ent_ptr), buf), TIMESTAMP_BUFF_LENGTH );
		p=strchr(buff,'\n');
		if(p!=NULL){
	 *p='\0';
	 }		
	 }*/
	time_t now;
	time(&now);
	ctime_r(&now,buff);
	buff[24]=0;
	return(buff);
}

int compare_rt_campaign_encryption_algo_details(
        const void *campaign1,
        const void *campaign2
        ) {
  return (((rt_campaign_encryption_algo_details_t *)campaign1)->campaign_id - 
          ((rt_campaign_encryption_algo_details_t *)campaign2)->campaign_id);    
}
#if 0
rt_campaign_encryption_algo_details_t *bsearch_rt_campaign_encryption_algo_details(
        rt_campaign_encryption_algo_details_t *search_campaign_entry,
        rt_campaign_encryption_algo_details_t *rt_campaign_encryption_algo_details,
        int rt_campaign_count
        ) {

    // Binary search rt_campaign_encryption_algo_details_t
  rt_campaign_encryption_algo_details_t *result = NULL;
  int left = 0;
  int right = rt_campaign_count - 1;
  int middle = 0;
  while(left <= right) {
      middle = (left + right)/2;
      if(rt_campaign_encryption_algo_details[middle].campaign_id < search_campaign_entry->campaign_id) {
          // go right
          left = middle + 1;
      }
      else if(rt_campaign_encryption_algo_details[middle].campaign_id > search_campaign_entry->campaign_id) { 
          // go left
          right = middle - 1;
      }
      else {
          // element found
          break;
      }
  }
  if (left <= right) {
      if (rt_campaign_encryption_algo_details[middle].algorithm_purpose == search_campaign_entry->algorithm_purpose) {
          return (&rt_campaign_encryption_algo_details[middle]);
      }
      else if(middle > 0 &&
              rt_campaign_encryption_algo_details[middle - 1].campaign_id == search_campaign_entry->campaign_id &&
              rt_campaign_encryption_algo_details[middle - 1].algorithm_purpose == search_campaign_entry->algorithm_purpose) {
          return (&rt_campaign_encryption_algo_details[middle - 1]);
      }
      else if(middle < (rt_campaign_count - 1) &&
              rt_campaign_encryption_algo_details[middle + 1].campaign_id == search_campaign_entry->campaign_id &&
              rt_campaign_encryption_algo_details[middle + 1].algorithm_purpose == search_campaign_entry->algorithm_purpose) {
          return (&rt_campaign_encryption_algo_details[middle + 1]);
      }
  }
  return NULL;
}
#endif
int map_init(easy_handle_to_campaign_id_map_t* map) {
	map->nelements = 0;
	return ADS_ERROR_SUCCESS;
}

//TODO:Can we remove this, never called
int map_insert(easy_handle_to_campaign_id_map_t* map, CURL* handle, long campaign_id) {
	//Find if there is space in the map
	if(map->nelements >= MAX_REALTIME_REQUESTS) {
		llog_write(L_DEBUG, "ERROR:RTB map is full, unable to insert %s:%d\n",__FILE__,__LINE__);
		return ADS_ERROR_BUFFER_OVERFLOW;
	}
	// Find the slot where the pair could be inserted; the map is sorted w.r.t CURL handle
	int j=map->nelements - 1;
	while( j>=0 && map->pair_vector[j].easy_handle > handle) {
		map->pair_vector[j+1] = map->pair_vector[j];
		j--;
	}
	//slot found i.e j+1; now insert in it
	map->pair_vector[j+1].easy_handle = handle;
	map->pair_vector[j+1].campaign_id = campaign_id;
	//increment the number of elements
	map->nelements+=1;
	return ADS_ERROR_SUCCESS;
}

void print_map(const easy_handle_to_campaign_id_map_t* map) {
	llog_write(L_DEBUG,"STATUS_CHECK: Map :-\n");
	int i=0;
	for(i=0;i<map->nelements;i++) {
		llog_write(L_DEBUG,"%p : %ld\n",map->pair_vector[i].easy_handle,map->pair_vector[i].campaign_id);
	}
	llog_write(L_DEBUG,"********************************************\n");
}


long map_search(const easy_handle_to_campaign_id_map_t* map, CURL* handle) {
	// Binary search the map for a CURL handle and return the corresponding campaign id
	int left=0;
	int right = map->nelements - 1;
	int middle;
	while(left<=right) {
		middle = (left + right)/2;
		if(map->pair_vector[middle].easy_handle < handle) {
			// go right
			left = middle + 1;
		}
		else if(map->pair_vector[middle].easy_handle > handle) { 
			// go left
			right = middle - 1;
		}
		else {
			// element found; return the campaign id
			return map->pair_vector[middle].campaign_id;
		}
	}
	// We didn't find the element, return -1 

#ifdef DEBUG
	print_map(map);
#endif
	return -1;
}

int map_clear(easy_handle_to_campaign_id_map_t* map) {
	map->nelements = 0;
	return ADS_ERROR_SUCCESS;
}

int map_remove(easy_handle_to_campaign_id_map_t* map) {
	map->nelements = 0;
	return ADS_ERROR_SUCCESS;
}
int init_persistent_conn(CURLM** handle,int pool_size ) {
	CURLMcode rc_curl;
	*handle = curl_multi_init();
	if(*handle == NULL) {
		llog_write(L_DEBUG,"\nERROR curl_multi_init failed : %s:%d\n",__FILE__,__LINE__);
		return ADS_ERROR_INTERNAL;
	}
	rc_curl = curl_multi_setopt(*handle, CURLMOPT_MAXCONNECTS, pool_size);
	if(rc_curl!=CURLM_OK) {
		llog_write(L_DEBUG,"ERROR curl_multi_setopt failed...exiting : %s  %s:%d\n", curl_multi_strerror(rc_curl),__FILE__,__LINE__);
		return ADS_ERROR_INTERNAL;
	}
	llog_write(L_DEBUG,"START_STATUS:RTB persistent connections are enabled and connection pool size is = %d %s:%d\n",pool_size,__FILE__,__LINE__);
	return ADS_ERROR_SUCCESS;
}
int init_curl_easy_handles(fte_additional_params_t* fte_additional_parameters,int max_realtime_requests) {     
	int i;
	for(i=0;i<max_realtime_requests;i++) {
		//assert(fte_additional_parameters->curl_handle_cache[i] == NULL);
		fte_additional_parameters->curl_handle_cache[i] = curl_easy_init();
		if(fte_additional_parameters->curl_handle_cache[i]== NULL) {
			llog_write(L_DEBUG,"\nERROR curl_easy_init()  failed %s:%d\n",__FILE__,__LINE__);
			return ADS_ERROR_INTERNAL;
		}
		fte_additional_parameters->curl_reinit_value[i] = 0;
	}
	// TODO_kartik use ADS_ERROR_SUCCESS and ADS_ERROR_INTERNAL
	return ADS_ERROR_SUCCESS;
}
//sagar
int init_bidder_curl_easy_handles(fte_additional_params_t* fte_additional_parameters,int max_no_of_bidder_cluster_requests) {     
	int i;
	for(i=0;i<max_no_of_bidder_cluster_requests;i++) {
		//assert(fte_additional_parameters->bidder_curl_handle[i] == NULL);
		fte_additional_parameters->bidder_curl_handle[i] = NULL;
		fte_additional_parameters->bidder_curl_handle[i] = curl_easy_init();
		if(fte_additional_parameters->bidder_curl_handle[i]== NULL) {
			llog_write(L_DEBUG,"ERROR bidder_curl_easy_init()  failed %s:%d\n",__FILE__,__LINE__);
			return ADS_ERROR_INTERNAL;
		}
		fte_additional_parameters->bidder_curl_reinit_value[i] = 0;
		llog_write(L_DEBUG,"handle_no=%d : bidder_curl_easy_init() done: %s:%d\n",i,__FILE__,__LINE__);
	}
	// TODO_kartik use ADS_ERROR_SUCCESS and ADS_ERROR_INTERNAL
	return ADS_ERROR_SUCCESS;
}

int clean_bidder_easy_handles(fte_additional_params_t* fte_additional_parameters,int max_no_of_bidder_cluster_requests) {
	int i;
	for(i=0;i<max_no_of_bidder_cluster_requests;i++) {
		if(fte_additional_parameters->bidder_curl_handle[i]!=NULL) {
			curl_easy_cleanup(fte_additional_parameters->bidder_curl_handle[i]);
			fte_additional_parameters->bidder_curl_handle[i]=NULL;
		}
		fte_additional_parameters->bidder_curl_reinit_value[i]=0;
	}
	return ADS_ERROR_SUCCESS;
}
//~sagar

int clean_persistent_conn(CURLM** handle) {
	CURLMcode rc_curl;
	rc_curl = curl_multi_cleanup(*handle);
	if(rc_curl!=CURLM_OK) {
		llog_write(L_DEBUG,"\nERROR curl_multi_cleanup failed : %s  %s:%d\n", curl_multi_strerror(rc_curl),__FILE__,__LINE__);
		return ADS_ERROR_INTERNAL;
	}
	*handle=NULL;
	return ADS_ERROR_SUCCESS;
}
int clean_easy_handles(fte_additional_params_t* fte_additional_parameters,int max_realtime_requests) {
	int i;
	for(i=0;i<max_realtime_requests;i++) {
		if(fte_additional_parameters->curl_handle_cache[i]!=NULL) {
			curl_easy_cleanup(fte_additional_parameters->curl_handle_cache[i]);
			fte_additional_parameters->curl_handle_cache[i]=NULL;
		}
		fte_additional_parameters->curl_reinit_value[i]=0;
	}
	return ADS_ERROR_SUCCESS;
}
static int print_config(adserver_config_params_t *config){


	if (config != NULL){
		llog_write(L_DEBUG, "%s=%d\n", ADS_GEO_ENABLED_FLAG, config->geo_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", ADS_FTE_ENABLED_FLAG, config->fte_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", ADS_RTB_ENABLED_FLAG, config->rtb_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", ADS_CONTEXTUAL_ENABLED_FLAG, config->contextual_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", ADS_FREQUENCY_ENABLED_FLAG, config->adserver_frequency_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", ADS_CPC_ENABLED_FLAG, config->fte_cpc_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", RTB_DEBUG_ENABLED_FLAG, config->rtb_debug_flag);
		llog_write(L_DEBUG, "%s=%d\n", STAT_COLLECTION_ENABLED_FLAG, config->stats_collection_enable);
		llog_write(L_DEBUG, "%s=%s\n", GEO_FILE_PATH, config->geo_file_path);
		llog_write(L_DEBUG, "%s=%s\n", ISP_FILE_PATH, config->isp_file_path);
		llog_write(L_DEBUG, "%s=%s\n", NET_SPEED_FILE_PATH, config->net_speed_file_path);
		//sagar
		llog_write(L_DEBUG, "%s=%d\n", RTB_BIDDER_ENABLED_FLAG, config->rtb_bidder_enabled_flag);
		//~sagar
		llog_write(L_DEBUG, "%s=%d\n", WURFL_ENABLED_FLAG, config->wurfl_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", ADHOC_ANALYSIS_ENABLED, config->adhoc_analysis_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", COOKIE_STORE_ENABLED_FLAG, config->cookie_store_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", CENTRALISED_ICAP_ENABLED_FLAG, config->centralised_icap_enabled_flag);
		llog_write(L_DEBUG, "%s=0x%" PRIx64 "\n", MODULE_ENABLED_FLAG, config->module_enabled_flag);
		llog_write(L_DEBUG, "%s=%d\n", CACHE_SWITCH, config->cache_switch);
		llog_write(L_DEBUG, "%s=%d\n", USER_BID_PRICE_CACHING_ENABLED, config->user_bid_caching_enabled);
		llog_write(L_DEBUG, "%s=%d\n", FAST_TARGETING_ENABLED_FLAG, config->fast_targeting_enabled_flag);
		llog_write(L_DEBUG, "%s=%s\n", REQUEST_PARAM_LOG, config->request_param_log);
		llog_write(L_DEBUG, "%s=%d\n", DEAL_PARAM_LOG, config->deal_param_log);
		llog_write(L_DEBUG, "%s=%s\n", DISTRIBUTED_CACHE_SERVER_LIST, config->distributed_cache_server_list);
		llog_write(L_DEBUG, "%s=%d\n", AUDIENCE_EARLY_MERGE_ENABLE, config->audience_early_merge_enable);
		llog_write(L_DEBUG, "%s=%d\n", ACTIVE_TAG_NEW_APPROACH, config->active_tag_new_approach);
		llog_write(L_DEBUG, "%s=%d\n", USE_EPOLL_FLAG, config->use_epoll_flag);
		llog_write(L_DEBUG, "%s=%d\n", SHUTDOWN_FLAG, config->shutdown_flag);
		llog_write(L_DEBUG, "%s=%d\n", LOG_LEVEL, config->log_level);
		llog_write(L_DEBUG, "%s=%s\n", NETACUITY_DATA_DIR, config->netacuity_data_dir);
		llog_write(L_DEBUG, "%s=%lf\n", LOG_TIME_PC_DB, config->log_time_pc);
	}
	else
	{
		llog_write(L_DEBUG, "Config Passed is NULL to func :%s\n", __FUNCTION__);
	}

	return ADS_ERROR_SUCCESS;
}
int reload_config_and_set_curl_handles(ad_server_additional_params_t* additional_params,cache_handle_t* cache_handle,ad_serv_thread_param_t* thread_params,int* all_curl_handles_initialized,fte_additional_params_t* fte_additional_parameters) {

	int retval;

	//llog_write(L_DEBUG, "Get Config From Cache  For Thread: %d\n", thread_params->thread_id);
	/*free the previous config*/
	if (additional_params->adserver_config_params != NULL) {
		free(additional_params->adserver_config_params);
		additional_params->adserver_config_params = NULL;
	}

	retval = cache_get_adserver_config_param(&(additional_params->adserver_config_params), cache_handle);
	if (retval != ADS_ERROR_SUCCESS) {
		llog_write(L_DEBUG, "\nERROR unable to fetch config params from cache for thread : %ld", thread_params->thread_id);
		return ADS_ERROR_INTERNAL;
	}
	if (additional_params->adserver_config_params == NULL) {
		llog_write(L_DEBUG, "\nERROR config structure not formed for thread %ld", thread_params->thread_id);
		return ADS_ERROR_INTERNAL;
	}
	/*if citrus is not available disable centralised icap as well as cookie store even if its enabled from reload flag
	 */
	if(g_citrus_leaf_enabled != 1){
		additional_params->adserver_config_params->centralised_icap_enabled_flag = 0;
		additional_params->adserver_config_params->cookie_store_enabled_flag = 0;
	}
	llog_write(L_DEBUG, "Reloaded config from cache for Thread : %lu\n", thread_params->thread_id);
	print_config(additional_params->adserver_config_params);
	
	// Initialize persistent connections and curl easy handles
	return enable_curl_conn(additional_params->adserver_config_params->rtb_enabled_flag,all_curl_handles_initialized,fte_additional_parameters);
}
int enable_curl_conn(int rtb_enabled_flag,int* all_curl_handles_initialized,fte_additional_params_t* fte_additional_parameters) {

	int retval;
	switch(rtb_enabled_flag) {
		case 0:
			if(*all_curl_handles_initialized==1) {
				clean_easy_handles(fte_additional_parameters,MAX_REALTIME_REQUESTS);
				clean_bidder_easy_handles(fte_additional_parameters,MAX_NO_OF_BIDDER_CLUSTERS);
				*all_curl_handles_initialized=0;
			}
			// Removed by kartik, we use this multi handle for mobile network realtime calls, so it need to be initialize ALWAYS
			/*if(g_rtb_enable_persistent_connections==1 && *curl_multi_initialized==1) {
				retval=clean_persistent_conn(&(fte_additional_parameters->realtime_api_handle.curl_multi_handle));
				if(retval!=ADS_ERROR_SUCCESS) {
					llog_write(L_DEBUG,"ERROR clean_persistent_conn() FAILED %s:%d\n",__FILE__,__LINE__);
					return ADS_ERROR_INTERNAL;
				}
				*curl_multi_initialized=0;
			}*/
			break;

		case 1:
			//if(g_rtb_enable_persistent_connections==1 && *curl_multi_initialized!=1) {
			/*if(*curl_multi_initialized!=1) {
				retval=init_persistent_conn(&(fte_additional_parameters->realtime_api_handle.curl_multi_handle),g_rtb_connection_pool_size);
				if(retval!=0) {
					llog_write(L_DEBUG,"ERROR init_persistent_conn failed %s:%d\n",__FILE__,__LINE__);
					return ADS_ERROR_INTERNAL;
				}
				*curl_multi_initialized=1;
			}*/
			//sagar
			if(*all_curl_handles_initialized!=1) {
				//if (g_rtb_curl_handle_reinit_value==0) { kartik
					retval=init_curl_easy_handles(fte_additional_parameters,MAX_REALTIME_REQUESTS);
					if(retval!=0) {
						llog_write(L_DEBUG,"ERROR init_curl_easy_handles failed %s:%d\n",__FILE__,__LINE__);
						return ADS_ERROR_INTERNAL;
					}
				//}
				
				//if(g_rtb_bidder_curl_handle_reinit_value==0) {
					retval=init_bidder_curl_easy_handles(fte_additional_parameters,MAX_NO_OF_BIDDER_CLUSTERS);
					if(retval!=0) {
						llog_write(L_DEBUG,"ERROR init_bidder_curl_easy_handles failed %s:%d\n",__FILE__,__LINE__);
						return ADS_ERROR_INTERNAL;
					}
				//}
				*all_curl_handles_initialized=1;
			}
			//~sagar
			break;
		default:
			llog_write(L_DEBUG,"\nERROR rtb value is neither 0 nor 1 %s:%d\n",__FILE__,__LINE__);
			//assert(0);
	}
	return ADS_ERROR_SUCCESS;
}
