/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <error.h>
#include <ctype.h>
#include "ad_server_types.h"
#include "rt_types.h"
#include "url_categorization.h"
#include "json.h"
#include "json_util.h"
#include "json_object_private.h"
#include "client_lb.h"
#include "default_adapter.h"

json_object *get_json_child_from_parent(json_object *parent_json_object, const char *key, json_type child_json_type);
extern backend_servers_t varnish_unit;
extern struct curl_slist *slist_integral ;

typedef struct integral_data_list {
        integral_data_t * integral_data;
        unsigned int n;
} integral_data_list_t;

int cmp_integral_settings(const void * xx, const void * yy) {
        integral_settings_t * x = (integral_settings_t *) xx;
        integral_settings_t * y = (integral_settings_t *) yy;

        if (x->campaign_id > y->campaign_id) {
                return 1;
        } else if (x->campaign_id < y->campaign_id) {
                return -1;
        } else {
                return 0;
        }
}

int get_enabled_ias_services_for_campaign(
        integral_data_t * integral_data,
        unsigned int campaign_id
) {
        integral_settings_t s;
        s.campaign_id = campaign_id;

        integral_settings_t *d = (integral_settings_t *) bsearch(
                (void *) &s,
                (void *) integral_data->integral_settings,
                integral_data->number_of_settings,
                sizeof (integral_settings_t),
                cmp_integral_settings
        );
        if (d != NULL) {
                return d->enabled_ias_services;
        }
        return 0;
}

// Function to copy ias settings to rt_request_params_mask. Both are sorted array, so traverse them in parallel
void update_campaign_ias_setting(rt_request_url_params_mask_t *mask, int mask_size, const integral_data_t *integral_data) {
	int mask_index = 0, setting_index = 0;
	int settings_size = integral_data->number_of_settings;
	const integral_settings_t *settings = integral_data->integral_settings;

	if ( settings_size == 0 || mask_size == 0 ) return;

	while ( mask_index < mask_size &&  setting_index < settings_size ) {
		if ( mask[mask_index].campaign_id > settings[setting_index].campaign_id ) {
			setting_index++;
		} else if ( mask[mask_index].campaign_id < settings[setting_index].campaign_id ) {
			mask_index++;
		} else { //Campaign found
			UCAT_DEBUGLOG("Campaign found.. Mask id:%ld, settings id:%d, settings:%d", mask[mask_index].campaign_id, 
					settings[setting_index].campaign_id, settings[setting_index].enabled_ias_services);

			if ( (settings[setting_index].enabled_ias_services & PAGE_CAT_MAP) && integral_data->page_categories[0] != '\0' ) {
				UCAT_DEBUGLOG("Page cat found and set in DB");
				mask[mask_index].enabled_ias_services |= PAGE_CAT_MAP;
			}
			if ( (settings[setting_index].enabled_ias_services & BSC_MAP) && integral_data->brand_safety_score[0] != '\0' ) {
				UCAT_DEBUGLOG("BSC found and set in DB");
				mask[mask_index].enabled_ias_services |= BSC_MAP;
			}
			UCAT_DEBUGLOG("Updated settings.. id:%ld, new settings:%d",
					mask[mask_index].campaign_id, mask[mask_index].enabled_ias_services);
			setting_index++; mask_index++;
		}
	}
}

int init_integral_curl_handle(CURL **curl_handle,
                        const char* connection_name,
                        const int connection_timeout,
                        const int request_timeout,
                        const int no_signal
                        ) {

        CURLcode curl_retval = CURLE_OK;

        (*curl_handle) = NULL;

        UCAT_DEBUGLOG("Initializing integral curl handle\n");

        (*curl_handle) = curl_easy_init();

        if ((*curl_handle) == NULL){
                llog_write(L_DEBUG,"\nERROR curl_easy_init() for %s failed %s:%d\n", connection_name, __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }

	curl_retval =   curl_easy_setopt((*curl_handle) , CURLOPT_HTTPHEADER, slist_integral);
	if ( curl_retval != CURLE_OK ) {
		llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set ias header %s:%d\n", __FILE__, __LINE__);
	}

        curl_retval = curl_easy_setopt((*curl_handle), CURLOPT_CONNECTTIMEOUT_MS, connection_timeout);
        if (curl_retval != CURLE_OK){
                llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set %s connection timeout %s:%d\n", connection_name,
                                __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }

        curl_retval = curl_easy_setopt((*curl_handle), CURLOPT_TIMEOUT_MS, request_timeout);
        if (curl_retval != CURLE_OK){
                llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set %s request timeout %s:%d\n", connection_name,
                                __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }

        curl_retval = curl_easy_setopt((*curl_handle), CURLOPT_NOSIGNAL, no_signal);
        if (curl_retval != CURLE_OK){
                llog_write(L_DEBUG, "ERROR curl_easy_setopt() failed to set no signal for %s %s:%d\n", connection_name,
                                __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }

	UCAT_DEBUGLOG("Curl Handle Initialized\n");
        return ADS_ERROR_SUCCESS;
}

#define AGE_HEADER "Age:"

static size_t write_data_ias_header(void *ptr, size_t size, size_t nmemb, void *data)
{
	size_t realsize = size * nmemb;
	int *imiss = (int *)data;
	if (strncmp(ptr, AGE_HEADER, sizeof(AGE_HEADER) - 1) == 0) {
		const char* temp_ptr = ptr;
		temp_ptr += sizeof(AGE_HEADER) - 1;
		long age_val = strtol(temp_ptr, NULL, 10);
		if ( age_val == 0 )
			*imiss = 1;
#ifdef FIX_IAS
		llog_write(L_DEBUG, "Age header:%d\n",  (int) age_val);
#endif
	}
	return realsize;
}





static size_t write_memory_integral_callback(void *ptr, size_t size, size_t nmemb, void *data) {
        size_t realsize = size * nmemb;
        integral_curl_data_t *mem = (integral_curl_data_t *)data;

        UCAT_DEBUGLOG("Data Received:%s, size:%d\n", (char *)ptr,(int) realsize);
        
	
	if ( realsize + 1 > MAX_CURL_INTEGRAL_DATA_SIZE ) {
                llog_write(L_DEBUG, "ERROR: Wrong data from server, %s:%d\n", __FILE__, __LINE__);
                return 0;
	}

        memcpy(mem->data, ptr, realsize);
        
	mem->size = realsize;
        mem->data[realsize] = '\0';

        return realsize;
}

/*
 * Fuction to remove query params from string
 * Stop copying when ? found. src must end with \0
 * On overflow, it will reset dest
 */
void remove_query_params(char *dest, const char* src, size_t max_size) {
	size_t i;
	if (!src)
		return;

	for( i = 0; i < max_size - 1 && src[i] != '\0' && src[i] != '?' && src[i] != '&' && src[i] != ';'; i++ ) {
		if ( src[i] == '%' ) { // all escape sequences start with %
			if( (src[i+1] == '3') &&  ( src[i+2] == 'F' || src[i+2] == 'f' || src[i+2] == 'B' || src[i+2] == 'b' )) { //%3F is encoding of ? %3B is for ;
				UCAT_DEBUGLOG("Skipping query params from page url");
				break;
			} else {
				if (  src[i+1] == '2' && ( src[i+2] == '6' )) { //%26 is encoding of &
					UCAT_DEBUGLOG("Skipping query params from page url");
					break;
				}
			}
		}

		dest[i] = src[i];
	}
	if ( i == (max_size - 1) && src[i] != '\0' ) { //overflow
		llog_write(L_DEBUG,"\nERROR: buffer overflow  %s:%d", __FILE__, __LINE__);
		dest[0] = '\0';      //As cutting page url may break encoding
	} else {
		dest[i] = '\0';
	}
}

/*
 * dest must have enough memory to hold the str
 * level specify how many domains u need to consider
 * str can be url encoded or decoded
 */


#define HTTP_STR "http:/"
#define HTTPS_STR "https:/"
#define WWW_STR "www."

void extract_tld_level ( char ** dest ,  int level) {
	char  *ptr = NULL;
	int http_found_flag =0;
	int skip_len = sizeof(HTTP_STR) - 1;
	ptr = (char *) strstr( *dest , HTTP_STR);
	//Remove http:/ from initial position if present
	if (ptr == *dest) {
		(*dest) += skip_len;
		http_found_flag =1;
	}

	//Remove https:/ from initial position id present
	else{
		skip_len = sizeof(HTTPS_STR) - 1;
		ptr = (char *) strstr( *dest , HTTPS_STR);
		if (ptr == *dest) {
                	(*dest) += skip_len;
                	http_found_flag =1;
        	}
	}
	while( http_found_flag && **dest == '/') {
		(*dest)++;
	}

	//Remove www. from initial position if present
	skip_len = sizeof(WWW_STR) - 1;
	ptr = (char *) strstr( *dest , WWW_STR);
	if (ptr == *dest) {
               	(*dest) += skip_len;
       	}

	if(**dest=='\0')
		return;

	//skipped the initial // now go ahead
	ptr=*dest;
	int count = -1;
	while (  (*ptr)!='\0' && count < level ) {
		if ( *ptr== '/' ) {
			count++;
			if (count == level){
				break;
			}
		}
		ptr++;
	}
	if ( count == level)
	{	
		*ptr = '\0';
	} 
	return;
}

int set_integral_options ( const ad_server_req_param_t *in_server_req_params,
			   CURL *curl, integral_curl_data_t *integral_chunk, integral_data_t *integral_data, int ias_tld_level ) {

        CURLcode curl_retval = CURLE_OK;
	char connection_url[MAX_CONNECTION_URL_LENGTH + 1];
	char process_str[MAX_CONNECTION_URL_LENGTH + 1];
	char encoded_adsafe_url[MAX_CONNECTION_URL_LENGTH + 1];
	int bytes_written = 0;
	char adsafe_url[MAX_CONNECTION_URL_LENGTH + 1];
	char backend_addr[MAX_BACKEND_URL_LEN + 1];
	
	adsafe_url[0]= adsafe_url[MAX_CONNECTION_URL_LENGTH] = '\0';
	connection_url[0]= connection_url[MAX_CONNECTION_URL_LENGTH] = '\0';
	backend_addr[0] = backend_addr[MAX_BACKEND_URL_LEN] = '\0';
	process_str[0] = process_str[MAX_CONNECTION_URL_LENGTH] = '\0';	
	encoded_adsafe_url[0]=encoded_adsafe_url[MAX_CONNECTION_URL_LENGTH] ='\0';

	if ( in_server_req_params->decoded_final_extracted_url != NULL && in_server_req_params->decoded_final_extracted_url[0] != '\0'  ) {
		strcpy(process_str , in_server_req_params->decoded_final_extracted_url );
	} else {
		UCAT_DEBUGLOG("Page URL Not found");
		return ADS_ERROR_INTERNAL;
	}
	if( strcasecmp(process_str,DEFAULT_PAGE_URL_STR)==0 ){
		UCAT_DEBUGLOG("No Page URL specified");
		return ADS_ERROR_INTERNAL;
	}
	
	char *tld_str = &process_str[0];
	if ( ias_tld_level >= 0) {
		extract_tld_level ( &tld_str ,  ias_tld_level);
	}
	// get rid of query params 
	remove_query_params(encoded_adsafe_url, tld_str , MAX_CONNECTION_URL_LENGTH);
	//always encode urls before call to varnish/IAS
	html_url_encode(encoded_adsafe_url, adsafe_url, MAX_CONNECTION_URL_LENGTH );
	if (adsafe_url[0] == '\0') return ADS_ERROR_INTERNAL;
	integral_data->backend_server_id = get_server_id(&varnish_unit, adsafe_url, backend_addr);
	if (integral_data->backend_server_id == -1 || backend_addr[0] == '\0') {
	  UCAT_DEBUGLOG("Varnish backend server not found");
	  return ADS_ERROR_INTERNAL;
	}
	UCAT_DEBUGLOG("Server id:%d,Address:%s", integral_data->backend_server_id, backend_addr);

	bytes_written = snprintf(connection_url, MAX_CONNECTION_URL_LENGTH, "%s?%s=%s", backend_addr,
                                                        INTEGRAL_PLATFORM_NAME, adsafe_url);

	if ( bytes_written > MAX_CONNECTION_URL_LENGTH ) {
		llog_write(L_DEBUG,"\nERROR: buffer overflow occured while creating integral request url %s:%d", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}

	UCAT_DEBUGLOG("Request URL:%s  \nPageURL:%s",connection_url,in_server_req_params->decoded_final_extracted_url);

	curl_retval = curl_easy_setopt(curl, CURLOPT_URL , connection_url);
        if (curl_retval != CURLE_OK){
                llog_write(L_DEBUG, "ERROR integral: error setting connection url '%s' %s:%d\n", connection_url,
                                __FILE__, __LINE__); 
                return ADS_ERROR_INTERNAL;
        }

        curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_memory_integral_callback);
        if (curl_retval != CURLE_OK) {
                llog_write(L_DEBUG, "ERROR integral: error setting callback function: %d, %s:%d\n", curl_retval,
                                __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }
        curl_retval = curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION , write_data_ias_header );
        if (curl_retval != CURLE_OK) {
                llog_write(L_DEBUG, "ERROR integral: error setting callback function: %d, %s:%d\n", curl_retval,
                                __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }


	

	curl_retval = curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)integral_chunk);
        if (curl_retval != CURLE_OK) {
                llog_write(L_DEBUG, "ERROR integral: error setting write buffer: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }
	curl_easy_setopt(curl, CURLOPT_HEADERDATA, &(integral_data->cache_miss));
	if (curl_retval != CURLE_OK) {
                llog_write(L_DEBUG, "ERROR integral: error setting write buffer: %d, %s:%d\n", curl_retval, __FILE__, __LINE__);
                return ADS_ERROR_INTERNAL;
        }
	return ADS_ERROR_SUCCESS;
}


#define  LOW_RISK 1
#define  MODERATE_RISK 2
#define  HIGH_RISK 4
#define  VERY_HIGH_RISK 8
#define  NO_SCORE      16

#define  LOW_RISK_THREHOLD 751
#define  MODERATE_RISK_THRESHOLD 501
#define  HIGH_RISK_THRESHOLD 251
#define  VERY_HIGH_RISK_THRESHOLD 0

static int get_score_level ( int score ) {
	if ( score == -1 )
		return NO_SCORE ;
	if ( score >= LOW_RISK_THREHOLD )
		return LOW_RISK;
	else if ( score >= MODERATE_RISK_THRESHOLD )
		return MODERATE_RISK;
	else if ( score >= HIGH_RISK_THRESHOLD )
		return HIGH_RISK;
	else if ( score >= VERY_HIGH_RISK_THRESHOLD )
		return VERY_HIGH_RISK;
	else
		return NO_SCORE;

}



static int copy_data_from_json(char *dest, const char *src, size_t max_size, const char *key, int skip_len, char stop) {
	int valid_json_found = 0;
	int quotes_cnt = 0, comma_cnt = 0;	//for error handling
	size_t src_index = 0, dest_index = 0;
	
	//search for iab object in the response
	char *copy_json_ptr = strstr(src, key);
	if ( copy_json_ptr == NULL ) {
		UCAT_DEBUGLOG("Invalid JSON found... No %s object",key);
		dest[0] = '\0';
		return ADS_ERROR_INTERNAL;
	}	
	
	src_index = (int ) (copy_json_ptr - src);
	src_index += skip_len;

	// src[src_index] is now pointing to [/{
	if ( src[src_index + 1] == stop) {
                UCAT_DEBUGLOG("empty/invalid %s object found",key);
                dest[0] = '\0';
		return ADS_ERROR_INTERNAL;
	} else { //next non-space char must be "
		int i = 1;
		while( isspace(src[src_index + i] )) {
			i++;	
		}
		if ( src[src_index + i] != '\"' ) {
			UCAT_DEBUGLOG("Invalid JSON found... Missing starting quotes");
	                dest[0] = '\0';
	                return ADS_ERROR_INTERNAL;
		}
	}
	
	//copy response from [/{ till ]/} i.e. valid json in integral_data
	for ( dest_index = 0; dest_index < max_size - 1; dest_index++, src_index++ ) {
		if ( src[src_index] == '\0' ) {
			//Invalid json found.. ]/} not found 
			break;
		}

		if ( src[src_index] == '"' ) {
			quotes_cnt++;
		} else if ( src[src_index] == ',' ) {
			comma_cnt++;
		}

		dest[dest_index] = src[src_index];

		if( src[src_index] == stop ) {
                        valid_json_found = 1;
                        break;
                }
	}
	if ( valid_json_found == 0 ) {
                UCAT_DEBUGLOG("Invalid JSON found...No %c found",stop);
                dest[0] = '\0';
                return ADS_ERROR_INTERNAL;
        }

	//error handling
	if ( (quotes_cnt == 0) || ( quotes_cnt != (comma_cnt + 1) * 2) ) {
		UCAT_DEBUGLOG("Invalid JSON found...Malformed %s object",key);
                dest[0] = '\0';
                return ADS_ERROR_INTERNAL;
	}
	dest[++dest_index] = '\0';
	return ADS_ERROR_SUCCESS;
}


#define SHIFT_1_SCORE 8 
void fill_ias_score_levels(const integral_curl_data_t *integral_chunk, integral_data_t *integral_data) { 
	int sam=0;
	int i=0;
	char bsc_keys[][5] = { "drg" ,"alc" , "off" ,"dlm" ,"adt" ,"hat"};	

	json_object *new_obj = NULL ;
	if ( !check_if_json( integral_chunk->data ) ) {
		integral_data->bsc_level = NO_SCORE ;
		integral_data->fraud_level = NO_SCORE ;
		goto done;	

	}
	json_object *obj_bsc = NULL ;
	json_object *obj_sam = NULL ;
	integral_data->logger_score_field = 0 ;	 

	 /* get the bsc object
	*
	*/
	new_obj = json_tokener_parse( integral_chunk->data );
	if ( new_obj == NULL || (is_error( new_obj ) )) {
		integral_data->bsc_level = NO_SCORE ;
		integral_data->fraud_level = NO_SCORE ;
		goto done;
	}	
	obj_bsc = get_json_child_from_parent(new_obj, JSON_BSC , json_type_object );
	if ( obj_bsc == NULL ) {
		integral_data->bsc_level = NO_SCORE ; 
		integral_data->fraud_level = NO_SCORE ;
		goto done;
	}

#ifdef MOVE_EXISTING_IAS
	strncpy( integral_data->brand_safety_score , json_object_get_string( obj_bsc ),MAX_BSC_SIZE );
	integral_data->brand_safety_score[MAX_BSC_SIZE] = '\0';

	obj_iab = get_json_child_from_parent( new_obj , JSON_IAB , json_type_object );
	if ( obj_iab == NULL ) {
		integral_data->page_categories[0] ='\0';	
	} else {
		strncpy( integral_data->page_categories , json_object_get_string( obj_iab ),MAX_URLCAT_DATA_SIZE );
		integral_data->page_categories[MAX_URLCAT_DATA_SIZE] = '\0';
	}
#endif

	/* get the sam value
	*
	*/

	obj_sam = get_json_child_from_parent( obj_bsc , JSON_SAM , json_type_int );
	if ( obj_sam == NULL ) {
		integral_data->fraud_level = NO_SCORE ;
	} else {
		sam = obj_sam->o.c_int ;
		integral_data->fraud_level = get_score_level(sam) ;
	}
	/*
	 * Get the minimum score from the bsc json object
	 */

	int temp_min = MAX_IAS_VALUE;
	int temp_data;

	for ( i = 0 ; i < 6 ; i++) {
		json_object *bid_arr = get_json_child_from_parent( obj_bsc , bsc_keys[i], json_type_int);
		if ( bid_arr == NULL ) {
			continue ;
		}
		temp_data = bid_arr->o.c_int ;
		if ( temp_min >  temp_data ) 
			temp_min = temp_data;
	}  	



#ifdef DEBUG
	llog_write(L_DEBUG,"Temp min is %d \n" , temp_min);
#endif
	integral_data->bsc_level = get_score_level(temp_min) ;

	/*
	 * assign data to score field
	 */


done:
	integral_data->logger_score_field = integral_data->bsc_level ;
	integral_data->logger_score_field <<= SHIFT_1_SCORE;
	integral_data->logger_score_field |= integral_data->fraud_level ;
	if ((new_obj != NULL) && (!is_error(new_obj))){
		json_object_put(new_obj);
		new_obj = NULL;
	}
}

int parse_integral_data(const integral_curl_data_t *integral_chunk, integral_data_t *integral_data) {
	int cat_retval = 0, bsc_retval = 0 ;
#ifndef MOVE_EXISTING_IAS
	cat_retval = copy_data_from_json(integral_data->page_categories, integral_chunk->data, 
					MAX_URLCAT_DATA_SIZE, IAB_KEYWORD, sizeof(IAB_KEYWORD) - 2,']');

	bsc_retval = copy_data_from_json(integral_data->brand_safety_score, integral_chunk->data,
						MAX_BSC_SIZE, BSC_KEYWORD, sizeof(BSC_KEYWORD) - 2,'}');
#endif
	fill_ias_score_levels(integral_chunk,integral_data);
	return (cat_retval && bsc_retval);
}
