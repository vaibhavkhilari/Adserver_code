/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <rt_types.h>
#include <rtb_util.h>
#include <string_util.h>
#include <default_adapter.h>
#include "deal.h"
#include "http_header_helper.h"
#define  MAX_BUF_SIZE ((MAX_REQUEST_URL_SIZE) * 3)
/*Create url with mandatory params*/
int get_url_with_mandatory_params(rt_request_params_t *rt_request_params, publisher_site_t *site, char *url,
		ad_server_additional_params_t *additional_parameters, replace_info_t mandat_replace_info[]) {
	(void)site;
	(void)additional_parameters;
	// url is an array on stack hence no checking for NULL
	char* strptr = NULL;

	int len = 0;
	int space_left = MAX_REQUEST_URL_SIZE + 1;
	int macs = MAX_CREATIVE_TAG_SIZE / 1024;

	strptr = url;

	mandat_replace_info[RT_REQUEST_ID].start = strptr;

	len = snprintf(strptr, space_left, "requestId=%s",
			rt_request_params->request_url_params.request_id[0]);
	if (len >= space_left) {
		llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
		return RTB_SUCCESS;
	}  else if ( len < 0 ) {
		llog_write(L_DEBUG, "\n SNPRINTF ERROR %s:%d\n", __FILE__, __LINE__);
		return RTB_SUCCESS;  
	}

	space_left -= len;
	strptr = strptr + len;

	mandat_replace_info[RT_REQUEST_ID].end = strptr;
	mandat_replace_info[RT_AD_SIZE].start = strptr;

	if(rt_request_params->in_server_req_params->ad_width != 0 && rt_request_params->in_server_req_params->ad_height !=0){
		len = snprintf(strptr, space_left, "&adWidth=%d&adHeight=%d", 
			rt_request_params->in_server_req_params->ad_width,  
			rt_request_params->in_server_req_params->ad_height);
	
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		} else if ( len < 0 ) {
			llog_write(L_DEBUG, "\n SNPRINTF ERROR %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;	
		}
		space_left -= len;
		strptr = strptr + len;
	}

	mandat_replace_info[RT_AD_SIZE].end = strptr;

	len = snprintf(strptr, space_left, "&uid=%s", rt_request_params->ad_server_req_gen_params->user_guid);
	if (len >= space_left) {
		llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
		return RTB_SUCCESS;
	} else if ( len < 0) {
		llog_write(L_DEBUG, "\nSNPRINTF ERROR %s:%d\n", __FILE__, __LINE__);
		return RTB_SUCCESS;
	}

	space_left -= len;
	strptr = strptr + len;

	if ( rt_request_params->fte_additional_params->publisher_level_settings.max_allowed_creative_size_kb > 0 ) {
		macs = rt_request_params->fte_additional_params->publisher_level_settings.max_allowed_creative_size_kb;
	}
	len = snprintf(strptr, space_left, "&macs=%d", macs);
	if (len >= space_left) {
		llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
		return RTB_SUCCESS;
	}
	space_left -= len;
	strptr = strptr + len;

	/*
	// Get the x_forwarded_for header's value
	const char* xff_header = get_header_value(&(additional_parameters->header_map), "HTTP_X_FORWARDED_FOR");
	if (xff_header != NULL && xff_header[0] != '\0') {
#define ENCODED_XFF_MAX_LEN (2*MAX_LEN_XFF)
		char encoded_xff_header[ENCODED_XFF_MAX_LEN+1];
		encoded_xff_header[0] = '\0';
		encoded_xff_header[ENCODED_XFF_MAX_LEN] = '\0';
		if(((additional_parameters->pub_country_level_privacy_flag ==1) || 
			(1 == ip_masking_enabled)) &&
			(additional_parameters->masked_xff[0]!='\0')){
		  html_url_encode(additional_parameters->masked_xff, encoded_xff_header,ENCODED_XFF_MAX_LEN);
		}
		else{
		  html_url_encode(xff_header, encoded_xff_header,ENCODED_XFF_MAX_LEN);
		}
		len = snprintf(strptr, space_left, "&xff=%s", encoded_xff_header);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
	}
	*/
	if (rt_request_params->in_server_req_params->oper_id == SERV_ADS_HTML_OPER) {
		len = snprintf(strptr, space_left, "&adTagType=%s", "Iframe");
		if (len >= space_left) {
			        llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
					return RTB_SUCCESS;
		}
    	space_left -= len;
	    strptr = strptr + len;
		

	}
	else if (rt_request_params->in_server_req_params->oper_id == SERV_ADS_JSCRIPT_OPER) {
		len = snprintf(strptr, space_left, "&adTagType=%s", "JavaScript");
		
		if (len >= space_left) {
					llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
					return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;

	//TODO_NIKI:Review this.
	}else if (rt_request_params->in_server_req_params->oper_id == SERV_ADS_VIDEO_OPER) {
		len = snprintf(strptr, space_left, "&adTagType=%s", "Video");
		
		if (len >= space_left) {
					llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
					return RTB_SUCCESS;
		}
		space_left -= len;
		strptr = strptr + len;
		
		/* Add version for Video */
		if(rt_request_params->in_server_req_params->video_params.protocol_version[0] != '\0'){
			len = snprintf(strptr, space_left, "&ver=%s", rt_request_params->in_server_req_params->video_params.protocol_version);

			if (len >= space_left) {
					llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
					return RTB_SUCCESS;
			}
			space_left -= len;
			strptr = strptr + len;
		}

	}
	return(RTB_SUCCESS);
}

/* encode other optional parms to avoid optimize request url creation */
int encode_params(
		rt_request_params_t* rt_request_params,
		encoded_request_params_t* encoded_request_params
		)
{
	// no need to check the number of bytes written

	html_url_encode(rt_request_params->ad_server_req_gen_params->referer_url, encoded_request_params->encoded_ref_url, MAX_REF_URL_SIZE + 1);

	html_url_encode(rt_request_params->request_url_params.catagory_list, encoded_request_params->encoded_catagory, MAX_CATAGORY_SIZE + 1);

	html_url_encode(rt_request_params->ad_server_req_gen_params->accept_lang, encoded_request_params->encoded_language, MAX_LANGUAGE_SIZE + 1);

	html_url_encode(rt_request_params->ad_server_req_gen_params->browser, encoded_request_params->encoded_browser, MAX_BROWSER_NAME_LEN);

	return RTB_SUCCESS;
}

int get_mandatory_site_url(char **str_ptr, int *spaceleft, ad_server_additional_params_t *additional_parameters, rt_request_params_t *rt_request_params, const int force_pageurl_transparency)
{
	int len = 0;
	int space_left = *spaceleft;
	char *strptr = *str_ptr;

	if (additional_parameters->pubsite_default_settings.url_hiding_enabled == 1 &&
			force_pageurl_transparency == 0) {
		if (rt_request_params->in_server_req_params->anonymized_sitedomain != NULL && 
				rt_request_params->in_server_req_params->anonymized_sitedomain[0] != '\0') {
			len = snprintf(strptr, space_left, "&siteurl=");
			if (len >= space_left)
			{
				llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
				return RTB_ERROR;
			} else if (len < 0 ) {
				llog_write(L_DEBUG, "\nSNPRINTF ERROR :%s:%d\n", __FILE__, __LINE__);
				return RTB_ERROR;
			}
			space_left -= len;
			strptr = strptr + len;
			len = html_url_encode(rt_request_params->in_server_req_params->anonymized_sitedomain, strptr, space_left);
		}
	}
	else if ( rt_request_params->in_server_req_params->decoded_final_extracted_domain &&
			rt_request_params->in_server_req_params->decoded_final_extracted_domain[0] != '\0') {
		len = snprintf(strptr, space_left, "&siteurl=");
		if (len >= space_left)
		{
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_ERROR;
		} else if (len < 0 ) {
			llog_write(L_DEBUG, "\nSNPRINTF ERROR :%s:%d\n", __FILE__, __LINE__);
			return RTB_ERROR;
		}
		space_left -= len;
		strptr = strptr + len;
		len = html_url_encode(rt_request_params->in_server_req_params->decoded_final_extracted_domain, strptr, space_left);
	}

	if (len >= space_left) {
		llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
		return RTB_ERROR;
	} else if (len < 0 ) {
		llog_write(L_DEBUG, "\nSNPRINTF ERROR :%s:%d\n", __FILE__, __LINE__);
		return RTB_ERROR;
	}
	space_left -= len;
	strptr = strptr + len;

	*spaceleft = space_left;
	*str_ptr = strptr;
	return RTB_SUCCESS;
}

int get_mandatory_pageurl(char **str_ptr, int *spaceleft, ad_server_additional_params_t *additional_parameters, rt_request_params_t *rt_request_params, const int force_pageurl_transparency)
{
	int len = 0;
	int space_left = *spaceleft;
	char *strptr = *str_ptr;

	/*
	 * page url passing logic:
	 * If url hiding is enabled as per publisher/site level settings and force_pageurl_transparency is disabled for pub/camapign, 
	 * then we pass the default url as configured in the DB.
	 * If there is no default url(or null/empty url) in DB then we don't pass the url.
	 * If url hiding is disabled as per publisher/site level settings, then we pass the pageurl from the adtag if
	 * it is provided else we pass on the actual pageurl we get from showad.js script.
	 */
	if (additional_parameters->pubsite_default_settings.url_hiding_enabled == 1 &&
			force_pageurl_transparency == 0) {
		if (additional_parameters->pubsite_default_params.anonymized_pageurl[0] != '\0') {
			len = snprintf(strptr, space_left, "&pageurl=");
			if (len >= space_left) {
				llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
				return RTB_ERROR;
			}
			space_left -= len;
			strptr = strptr + len;
			len = html_url_encode(additional_parameters->pubsite_default_params.anonymized_pageurl, strptr, space_left);
			space_left -= len;
			strptr = strptr + len;
		}
	} else if ( rt_request_params->in_server_req_params->encoded_final_extracted_url && 
			rt_request_params->in_server_req_params->encoded_final_extracted_url[0] != '\0') {
		// dynamic_page_url is already encoded, so we don't encode it again
		len = snprintf(strptr, space_left, "&pageurl=%s", rt_request_params->in_server_req_params->encoded_final_extracted_url);
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_ERROR;
		}
		space_left -= len;
		strptr = strptr + len;
	} 		
	*spaceleft = space_left;
	*str_ptr = strptr;
	return RTB_SUCCESS;
}

int get_mandatory_refurl(char **str_ptr, int *spaceleft, ad_server_additional_params_t *additional_parameters, rt_request_params_t *rt_request_params, const int force_pageurl_transparency)
{
	int len = 0;
	int space_left = *spaceleft;
	char *strptr = *str_ptr;

	/* 
	 * If Publisher has given overridding Referrer URL and force_pageurl_transparency is disabled for pub/camapign 
	 * then override Referrer URL which has been received as params with it.
	 */
	if (additional_parameters->pubsite_default_settings.override_referrer_url == 1 &&
			additional_parameters->pubsite_default_params.overriding_referrer_url[0] != '\0' &&
			force_pageurl_transparency == 0) {
		len = snprintf(strptr, space_left, "&refurl=");
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_ERROR;
		}
		space_left -= len;
		strptr = strptr + len;
		len = html_url_encode(additional_parameters->pubsite_default_params.overriding_referrer_url, strptr, space_left);
		space_left -= len;
		strptr = strptr + len;
	} else if (rt_request_params->ad_server_req_gen_params->referer_url[0] != '\0') {
		//Use Referrer URL passed as AdServer params.
		len = snprintf(strptr, space_left, "&refurl=");
		if (len >= space_left) {
			llog_write(L_DEBUG, "\nERROR BUFFER OVERFLOW IN CREATING MANDATORY PARAMS FOR URL, PLEASE INCREASE BUFFER SIZE %s:%d\n", __FILE__, __LINE__);
			return RTB_ERROR;
		}
		space_left -= len;
		strptr = strptr + len;
		len = html_url_encode(rt_request_params->ad_server_req_gen_params->referer_url, strptr, space_left);
		space_left -= len;
		strptr = strptr + len;
	}

	*spaceleft = space_left;
	*str_ptr = strptr;
	return RTB_SUCCESS;
}

