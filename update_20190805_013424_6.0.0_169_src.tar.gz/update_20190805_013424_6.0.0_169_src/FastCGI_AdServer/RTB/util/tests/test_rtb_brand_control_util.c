#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include <rt_types.h>
#include "bloom_filter.h"
#include "daa_deviceid_optout_bloomfilter.h"
#include "crc32_util.h"

u_int32_t crc_tab[256];
int gbl_log_level = L_DEBUG;

buyer_block_list_t *g_global_buyer_blocklist[2] = {0};
unsigned int g_cur_global_buyer_blocklist_idx = 0;
buyer_block_list_t *g_channel_partner_buyer_blocklist[2] = {0};
unsigned int g_cur_channel_partner_buyer_blocklist_idx = 0;


int __wrap_cache_get_buyer_blocklist(
		db_connection_t *dbconn,
		cache_handle_t *cache,
		buyer_block_list_t **buyer_block_list,
		long pub_id) {
	return 0;
}

static u_int32_t __wrap_chksum_crc32 (unsigned char *block, unsigned int length)
{
    register unsigned long crc;
    unsigned long i;

    crc = 0xFFFFFFFF;
    for (i = 0; i < length; i++)
    {
        crc = ((crc >> 8) & 0x00FFFFFF) ^ crc_tab[(crc ^ *block++) & 0xFF];
    }
    return (crc ^ 0xFFFFFFFF);
}

/* chksum_crc32gentab() --      to a global crc_tab[256], this one will
 *        calculate the crcTable for crc32-checksums.
 *        it is generated to the polynom [..]
 */

static void __wrap_chksum_crc32gentab()
{
    unsigned long crc, poly;
    int i, j;

    poly = 0xEDB88320L;
    for (i = 0; i < 256; i++)
    {
        crc = i;
        for (j = 8; j > 0; j--)
        {
            if (crc & 1)
            {
                crc = (crc >> 1) ^ poly;
            }
            else
            {
                crc >>= 1;
            }
        }
        crc_tab[i] = crc;
    }
}

unsigned long __wrap_calculate_crc(unsigned char *block, unsigned int length){
	/*generate crc table*/
	if(crc_tab[1] == 0){
		__wrap_chksum_crc32gentab();
	}
	/*calculate checksum*/
	return __wrap_chksum_crc32(block, length);
}

int filter_advertiser_domain_category(db_connection_t* dbconn,
		cache_handle_t* cache_handle,
		const ad_server_additional_params_t* additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		libstat_counters_t* libstats,
		ad_server_req_param_t *in_req_params,
		rt_response_params_t* rt_response_params,
		int rt_request_count,
		int pub_id,
		int site_id
		);

int __wrap_cache_get_bloom_filters(){return 0;}
int __wrap_cache_get_publisher_site_url_bloom(){return 0;}
int __wrap_substring_multi_concat_bloom_search(){return 0;}
int __wrap_substring_multi_bloom_search(){return 0;}
int __wrap_get_actual_url_start_pos(){return 0;}
int __wrap_evaluate_url_filter(){return 0;}
int __wrap_elog(){return 0;}

int __wrap_char_counter(const char *str, char c)
{
	int counter = 0;
	while(*str) {
		if((*str) == c) {
			counter++;
		}
		str++;
	}
	return counter;
}

int __wrap_compare_string(const void * left,const void * right)
{
	return(strcmp((char*)left,(char*)right));
}

int __wrap_cache_get_pub_site_domain_category_blocklist(
		db_connection_t *dbconn,
		cache_handle_t *cache,
		int **pub_site_domain_category_blocklist,
		int* ret_list,
		long pub_id,
		long site_id)
{
	check_expected(pub_id);
	check_expected(site_id);
	(*pub_site_domain_category_blocklist) = mock_type(int *);
	(*ret_list) = mock_type(int);
	return mock_type(int);
}

int __wrap_cache_get_pub_site_domain_advertiser_blocklist(
		db_connection_t *dbconn,
		cache_handle_t *cache,
		long **pub_site_domain_advertiser_blocklist,
		int* ret_list,
		long pub_id,
		long site_id)
{
	check_expected(pub_id);
	check_expected(site_id);
	(*pub_site_domain_advertiser_blocklist) = mock_type(long *);
	(*ret_list) = mock_type(int);
	return mock_type(int);
}

int __wrap_get_acd_str_for_domain(
		const char *advertiser_domain,
		long *advertiser_id,
		long *domain_id,
		char *sub1_iab_cat,
		char *pri_iab_cat,
		char *sub2_iab_cat,
		char *sub2_pri_iab_cat,
		char *sub3_iab_cat,
		char *sub3_pri_iab_cat,
		int *iab_sub_cat_int)
{
	check_expected(advertiser_domain);
	(*advertiser_id) = mock_type(long);
	(*domain_id) = mock_type(long);

	strcpy(pri_iab_cat, mock_type(char *));
	strcpy(sub1_iab_cat, mock_type(char *));
	strcpy(sub2_iab_cat, mock_type(char *));
	strcpy(sub2_pri_iab_cat, mock_type(char *));
	strcpy(sub3_iab_cat, mock_type(char *));
	strcpy(sub3_pri_iab_cat, mock_type(char *));
	memcpy(iab_sub_cat_int, mock_type(int *), sizeof(int) * MAX_PUB_TO_IAB_CAT_MAPPING);
	return mock_type(int);
}

int __wrap_increment_stats_counters(
		libstat_counters_t *libstat_counters,
		int stats_id,
		long int campaign_id)
{
	check_expected(stats_id);
	check_expected(campaign_id);
	return 0;
}

int __wrap_compare_long(const void * left,const void * right)
{
	return (long) (*(long*)left - *(long*)right);
}

int __wrap_compare_int(const void *left, const void *right)
{
	return (int) (*(int*)left - *(int*)right);
}

int __wrap_cache_get_publisher_site_tld_whitelist(
		long pub_id,
		long site_id,
		publisher_site_top_level_domain_name_t **publisher_site_top_level_domain_name,
		cache_handle_t *cache,
		db_connection_t *dbconn,
		int* ret_list){
	check_expected(pub_id);
	check_expected(site_id);
	(*publisher_site_top_level_domain_name) = mock_type(publisher_site_top_level_domain_name_t *);
	(*ret_list) = mock_type(int);
	return mock_type(int);
}

int __wrap_memcached_release_object_reference(char** data_ptr){return 0;}

typedef struct test_filter_advertiser_domain_category_inputs_t{
	int pub_id;
	int site_id;
	int camp_id;
	int block_advt_info_flag;
	int block_uncat_adv_flag;
	int is_camp_filtered;
	int skip_UCAF;
	char landing_page[100];
	int ret_get_acd_for_domain;
	char iab_cat_str[MAX_IAB_CAT_LEN+1];
	int iab_cat_int;
	long adv_id;
	long domain_id;
	int filtered_flag;
	int reason_for_filtering;
	int ret_fun;
}test_filter_advertiser_domain_category_inputs;


typedef struct test_top_level_domain_whitelist_inputs{
	int pub_id;
	int site_id;
	int publisher_site_tld_whitelist_length;
	int cache_ret_fun;
	char app_entity[50];
	char domain_kadpageurl[100];
	char domain_pageurl[100];
	int is_sitecode_present;
	int reason_for_filtering;
}test_top_level_domain_whitelist_inputs_t;

void test_filter_advertiser_domain_category(test_filter_advertiser_domain_category_inputs *input){
	db_connection_t dbconn;
	cache_handle_t cache_handle;
	ad_server_additional_params_t additional_parameters;
	publisher_site_ad_campaign_list_t adcampaigns[2];
	libstat_counters_t libstats;
	ad_server_req_param_t in_req_params;
	rt_response_params_t rt_response_params[2];
	ad_campaign_list_setings_t ad_campaign_list_setings;
	adserver_config_params_t adserver_config_params;
	int ret;
	int cat_list[10] = {131,132,133,134,135,136,137,138,139,140};
	long adv_list[10] = {111,222,333,444,555,666,777,888,999,1000};

	long blk_dom_ids[10] = {100,200,300,400,500,600,700,800,900,1000};
	long blk_adv_ids[10] = {110,210,310,410,510,610,710,810,910,1100};
	char blk_cat_id[10][17] = {"IAB1","IAB1-1","IAB2","IAB2-1","IAB3","IAB3-1","IAB4","IAB4-1","IAB5","IAB5-1"};
	char blk_ad_dom[10][MAX_ADV_DOM_LEN + 1] = {"1.com","123.com","a.b.com","a.com","abc.com","bcd.com","fyr.com","r.c.in","x.y.z","xyz.com"};

	memcpy(in_req_params.blk_domain_id, blk_dom_ids, 10*sizeof(long));
	in_req_params.blk_domain_id_count = 10;

	memcpy(in_req_params.blk_advt_id, blk_adv_ids, 10*sizeof(long));
	in_req_params.blk_advt_id_count = 10;

	memcpy(in_req_params.blk_cat_id, blk_cat_id, 170);
	in_req_params.blk_cat_id_count = 10;

	memcpy(in_req_params.blk_adv_dom, blk_ad_dom, 10 * (MAX_ADV_DOM_LEN + 1));
	in_req_params.blk_adv_dom_count = 10;

	int iab_cats_int[MAX_PUB_TO_IAB_CAT_MAPPING] = {0};
	char iab_cats_str[20];
	char empty_iab_cat[2] = {'\0'};
	iab_cats_int[0] = input->iab_cat_int;
	strcpy(iab_cats_str,input->iab_cat_str);

	adserver_config_params.stats_collection_enable = 0;
	ad_campaign_list_setings.filtered_flag = input->is_camp_filtered;
	ad_campaign_list_setings.reason_for_filtering = 0;
	rt_response_params[0].campaign_index = 0;
	rt_response_params[0].skip_UCAF = input->skip_UCAF;
	strcpy(rt_response_params[0].bid_response_params.landing_page_tld, input->landing_page);
	adcampaigns[0].campaign_id = input->camp_id;
	adcampaigns[0].ad_campaign_list_setings = &ad_campaign_list_setings;
	additional_parameters.pubsite_default_settings.pass_n_block_advt_info_enabled = input->block_advt_info_flag;
	additional_parameters.pubsite_default_settings.filter_uncategorized_advertisers_enabled = input->block_uncat_adv_flag;
	additional_parameters.adserver_config_params = &adserver_config_params;

	if(input->block_advt_info_flag || input->block_uncat_adv_flag){
		expect_value(__wrap_cache_get_pub_site_domain_category_blocklist, pub_id, input->pub_id);
		expect_value(__wrap_cache_get_pub_site_domain_category_blocklist, site_id, input->site_id);
		will_return(__wrap_cache_get_pub_site_domain_category_blocklist, cast_ptr_to_largest_integral_type(cat_list));
		will_return(__wrap_cache_get_pub_site_domain_category_blocklist, 10);
		will_return(__wrap_cache_get_pub_site_domain_category_blocklist, 0);

		expect_value(__wrap_cache_get_pub_site_domain_advertiser_blocklist, pub_id, input->pub_id);
		expect_value(__wrap_cache_get_pub_site_domain_advertiser_blocklist, site_id, input->site_id);
		will_return(__wrap_cache_get_pub_site_domain_advertiser_blocklist, cast_ptr_to_largest_integral_type(adv_list));
		will_return(__wrap_cache_get_pub_site_domain_advertiser_blocklist, 10);
		will_return(__wrap_cache_get_pub_site_domain_advertiser_blocklist, 0);

		if(!input->is_camp_filtered && '\0' != input->landing_page[0]){
			expect_string(__wrap_get_acd_str_for_domain, advertiser_domain, input->landing_page);
			will_return(__wrap_get_acd_str_for_domain, cast_ptr_to_largest_integral_type(input->adv_id));
			will_return(__wrap_get_acd_str_for_domain, cast_ptr_to_largest_integral_type(input->domain_id));
			will_return(__wrap_get_acd_str_for_domain, cast_ptr_to_largest_integral_type(iab_cats_str));
			will_return(__wrap_get_acd_str_for_domain, cast_ptr_to_largest_integral_type(empty_iab_cat));
			will_return(__wrap_get_acd_str_for_domain, cast_ptr_to_largest_integral_type(empty_iab_cat));
			will_return(__wrap_get_acd_str_for_domain, cast_ptr_to_largest_integral_type(empty_iab_cat));
			will_return(__wrap_get_acd_str_for_domain, cast_ptr_to_largest_integral_type(empty_iab_cat));
			will_return(__wrap_get_acd_str_for_domain, cast_ptr_to_largest_integral_type(empty_iab_cat));
			will_return(__wrap_get_acd_str_for_domain, cast_ptr_to_largest_integral_type(iab_cats_int));
			will_return(__wrap_get_acd_str_for_domain, input->ret_get_acd_for_domain);
		}
	}
	ret = filter_advertiser_domain_category(&dbconn, &cache_handle, &additional_parameters, adcampaigns, &libstats, &in_req_params, rt_response_params, 1, input->pub_id, input->site_id);

	assert_int_equal(ret, input->ret_fun);
	assert_int_equal(ad_campaign_list_setings.filtered_flag, input->filtered_flag);
	assert_int_equal(ad_campaign_list_setings.reason_for_filtering, input->reason_for_filtering);
}

static void test_filter_advertiser_domain_category__all_testcases(void **state){
	int i;
	test_filter_advertiser_domain_category_inputs inputs[] = {
		//pub,site,camp_id,adv_info,blk_uncat,camp_filtered,skip_UCAF,landing_page,ret_get_acd,iab_str,iab_int,adv_id,dom_id,ret
		{111,222,333,0,0,0,0,"landing.page",0,"IAB1",132,1234,4445,0,0,0}, //both filters are off
		{111,222,333,1,1,1,1,"landing.page",0,"IAB1",132,1234,4445,1,0,0}, //Camp is already filtered
		{111,222,333,1,0,0,1,"",0,"IAB1",132,1234,4445,0,0,0}, //Landing page is empty and block_uncat_domain flag is off, skip_UCAF on
		{111,222,333,1,1,0,0,"",0,"IAB1",132,1234,4445,1,41,0}, //Landing page is empty and block_uncat_domain flag is On, skip_UCAF off
		{111,222,333,0,1,0,0,"",0,"IAB1",132,1234,4445,1,41,0}, //Landing page is empty and block_uncat_domain flag is Off, skip_UCAF On
		{111,222,333,0,1,0,0,"landing.page",0,"IAB1",132,1234,4445,1,41,0}, // domain info not found in khash block_uncat_domain flag is On
		{111,222,333,1,0,0,0,"landing.page",0,"IAB1",132,1234,4445,0,0,0}, // domain info not found in khash adv_info flag on
		{111,222,333,1,1,0,0,"landing.page",1,"IAB24",132,1234,4445,1,41,0}, // domain info found in khash IAB24

		{111,222,333,1,1,0,0,"landing.page",1,"IAB4-4",112,1234,500,1,87,0}, // domain info found in khash, block by domain_id
		{111,222,333,1,1,0,0,"landing.page",1,"IAB4-4",112,710,502,1,87,0}, // domain info found in khash, block by adv id(from req)
		{111,222,333,1,1,0,0,"landing.page",1,"IAB4-4",112,666,502,1,87,0}, // domain info found in khash, block by adv id(from db)
		{111,222,333,1,1,0,0,"landing.page",1,"IAB4-1",112,619,502,1,87,0}, // domain info found in khash, block by iab_cat (from req)
		{111,222,333,1,1,0,0,"landing.page",1,"IAB4-4",137,619,502,1,87,0}, // domain info found in khash, block by iab_cat (from db)
		{111,222,333,1,1,0,0,"a.com",1,"IAB4-4",112,619,502,1,87,0}, // domain info found in khash, block by landing page
		{111,222,333,1,1,0,0,"c.a.b.com",1,"IAB4-4",112,619,502,1,87,0}, // domain info found in khash, block by landing page
		{111,222,333,1,1,0,0,"b.com",1,"IAB4-4",112,619,502,0,0,0}, // domain info found in khash, landing page not found

		{111,222,333,1,1,0,0,"cfb.com",1,"IAB4-4",112,619,502,0,0,0}, // domain info found in khash, no blocking
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_filter_advertiser_domain_category_inputs));i++){
		test_filter_advertiser_domain_category(&inputs[i]);
	}
}

// top leve domain testing

void test_top_level_domain_whitelist(test_top_level_domain_whitelist_inputs_t *input){
	db_connection_t dbconn;
	cache_handle_t cache_handle;
	ad_server_additional_params_t additional_parameters;
	publisher_site_ad_campaign_list_t adcampaigns[2];
	ad_server_req_param_t in_req_params;
	rt_response_params_t rt_response_params[2];
	ad_campaign_list_setings_t ad_campaign_list_setings;
	adserver_config_params_t adserver_config_params;
	int retval;
	//int tmp_buff[5] = {1,2,3,4,5};
	publisher_site_top_level_domain_name_t tmp_array[4] = {
		{444, "456", 193568556, 1, 5},
		{111, "kad", 963692945, 1, 2},
		{222, "pag", 1961607184, 1, 2},
		{333, "abc", 4028234778, 1, 2}
	};

	expect_value(__wrap_cache_get_publisher_site_tld_whitelist, pub_id, input->pub_id);
	expect_value(__wrap_cache_get_publisher_site_tld_whitelist, site_id, input->site_id);
	will_return(__wrap_cache_get_publisher_site_tld_whitelist, cast_ptr_to_largest_integral_type(tmp_array));
	will_return(__wrap_cache_get_publisher_site_tld_whitelist, input->publisher_site_tld_whitelist_length);
	will_return(__wrap_cache_get_publisher_site_tld_whitelist, input->cache_ret_fun);

	top_level_domain_whitelist(input->pub_id,
			input->site_id,
			input->domain_kadpageurl,
			input->domain_pageurl,
			&cache_handle,
			&dbconn,
			&additional_parameters,
			input->is_sitecode_present,
			input->app_entity);

	assert_int_equal(additional_parameters.passback_flag, input->reason_for_filtering);
}

static void test_top_level_domain_whitelist__all_testcases(void **state){
	int i;
	test_top_level_domain_whitelist_inputs_t inputs[] = {
		{111,222,4,0,"","abc.kadpage.com","",0,0},
    {111,222,4,0,"","","pageurl.com",0,0},
		{111,222,4,0,"456778","","",0,0},
		{111,222,4,0,"","abc.kadpage.com","pageurl.com",0,0},
		{111,222,4,0,"","abc.kadpage.com","pageurl1.com",0,0},
		{111,222,4,0,"","abc.kadpage1.com","pageurl.com",0,0},
		// Negative test case
		{111,222,0,0,"","abc.kadpage.com","",0,2},
		{111,222,0,0,"","","pageurl.com",0,2},
		{111,222,4,0,"","abc.kadpage1.com","",0,2},
    {111,222,4,0,"","","pageurl1.com",0,2},
		{111,222,4,0,"4567789","","",0,2},
		{111,222,4,0,"","abc.kadpage2.com","pageurl2.com",0,2},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_top_level_domain_whitelist_inputs_t));i++){
		test_top_level_domain_whitelist(&inputs[i]);
	}
}
int main()
{
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_filter_advertiser_domain_category__all_testcases),
		cmocka_unit_test(test_top_level_domain_whitelist__all_testcases),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
