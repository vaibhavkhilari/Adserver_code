#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include <rt_types.h>
#include "bloom_filter.h"
#include "daa_deviceid_optout_bloomfilter.h"
int gbl_log_level = L_DEBUG;
void check_daa_deviceid_optout(ad_server_req_param_t *params, cache_handle_t* cache_handle, db_connection_t* dbconn, int *optout_flag);

int __wrap_get_md5_hash(char * out_str, int max_out_len_with_null, const char *in_str){
	check_expected(in_str);
	check_expected(max_out_len_with_null);

	strncpy(out_str, mock_ptr_type(char *), max_out_len_with_null - 1);
	out_str[max_out_len_with_null-1] = '\0';
	return mock_type(int);
}

int __wrap_get_sha1_hash(char * out_str, int max_out_len_with_null, const char *in_str){
	check_expected(in_str);
	check_expected(max_out_len_with_null);

	strncpy(out_str, mock_ptr_type(char *), max_out_len_with_null -
			1);
	out_str[max_out_len_with_null-1] = '\0';
	return mock_type(int);
}

int __wrap_cache_get_bloom_filters(cache_handle_t* cache, db_connection_t* dbconn, const char *cache_key,
						const char *db_query, MULTI_BLOOM* multi_bloom, const long pub_id, const long site_id, const int bloom_type) {
	int i;
	check_expected(cache);
	check_expected(dbconn);
	check_expected(db_query);
	check_expected(pub_id);
	check_expected(site_id);
	check_expected(bloom_type);

	MULTI_BLOOM *tmp = mock_ptr_type(MULTI_BLOOM*);
	multi_bloom->bloom_count_0 = tmp->bloom_count_0;
	multi_bloom->bloom_count_s = tmp->bloom_count_s;
	for(i=0; i< MAX_ALLOWED_BLOOMS; i++){
		multi_bloom->bloom_filter_0[i] = tmp->bloom_filter_0[i]; 
		multi_bloom->bloom_filter_s[i] = tmp->bloom_filter_s[i];
	}
	return mock_type(int);
}

void __wrap_lowercase_string( char* s, int left, int right){
	check_expected(s);
	check_expected(left);
	check_expected(right);
}

void __wrap_destroy_multi_bloom(MULTI_BLOOM* multi) {
}

int __wrap_bloom_check(const BLOOM *bloom, const char *s){

	check_expected(s);
	return mock_type(int);
}

static void check_daa_deviceid_optout_bloom_filter__negative_failed_to_get_bloom_filter(void **state)
{
	int rv = 0;
	cache_handle_t cache_handle;
	db_connection_t dbconn_handle;
	char *device[1] ={"vijay"};
	char *dbquery = GET_DAA_DEVICE_OPTOUT_BLOOM; 

	BLOOM dummy;
	MULTI_BLOOM mbloom;
	mbloom.bloom_count_0 = 1;
	mbloom.bloom_count_s = 0;
	mbloom.bloom_filter_0[0] = &dummy;

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 1);
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, -1);

	rv = check_daa_deviceid_optout_bloom_filter(device, 1, 1, &cache_handle, &dbconn_handle);

	assert_int_equal(rv, -1);
}

static void check_daa_deviceid_optout_bloom_filter__negative_bloom_lookup_failed(void **state)
{
	int rv = 0;
	cache_handle_t cache_handle;
	db_connection_t dbconn_handle;
	char *device[1] ={"vijay"};
	char *str = "vijay";
	char *dbquery = GET_DAA_DEVICE_OPTOUT_BLOOM; 

	BLOOM dummy;
	MULTI_BLOOM mbloom;
	mbloom.bloom_count_0 = 1;
	mbloom.bloom_count_s = 0;
	mbloom.bloom_filter_0[0] = &dummy;

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 1);
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);

	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 0);

	rv = check_daa_deviceid_optout_bloom_filter(device, 1, 1, &cache_handle, &dbconn_handle);

	assert_int_equal(rv, -1);
}

static void check_daa_deviceid_optout_bloom_filter__positive_bloom_lookup_success(void **state)
{
	int rv = 0;
	cache_handle_t cache_handle;
	db_connection_t dbconn_handle;
	char *device[1] ={"vijay"};
	char *str = "vijay";
	char *dbquery = GET_DAA_DEVICE_OPTOUT_BLOOM; 

	BLOOM dummy;
	MULTI_BLOOM mbloom;
	mbloom.bloom_count_0 = 1;
	mbloom.bloom_count_s = 0;
	mbloom.bloom_filter_0[0] = &dummy;

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 1);
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);

	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 1);

	rv = check_daa_deviceid_optout_bloom_filter(device, 1, 1, &cache_handle, &dbconn_handle);

	assert_int_equal(rv, 0);
}

static void check_daa_deviceid_optout__positive_sha1_deviceid(void **state)
{
	cache_handle_t cache_handle;
	db_connection_t dbconn_handle;
	char *str = "abcdabcdabcdabcd";
	char *dbquery = GET_DAA_DEVICE_OPTOUT_BLOOM; 
	ad_server_req_param_t params;
	int opt_out = 0;
	strcpy(params.device_id,"abcdabcdabcdabcd");
	params.udid_hash = 2;
	BLOOM dummy;
	MULTI_BLOOM mbloom;
	mbloom.bloom_count_0 = 1;
	mbloom.bloom_count_s = 0;
	mbloom.bloom_filter_0[0] = &dummy;

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 2);
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);

	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 1);

	check_daa_deviceid_optout(&params, &cache_handle, &dbconn_handle, &opt_out);
	assert_int_equal(opt_out, 1);
}

static void check_daa_deviceid_optout__positive_md5_deviceid(void **state)
{
	cache_handle_t cache_handle;
	db_connection_t dbconn_handle;
	char *str = "abcdabcdabcdabcd";
	char *dbquery = GET_DAA_DEVICE_OPTOUT_BLOOM; 
	ad_server_req_param_t params;
	int opt_out = 0;
	strcpy(params.device_id,"abcdabcdabcdabcd");
	params.udid_hash = 3;
	BLOOM dummy;
	MULTI_BLOOM mbloom;
	mbloom.bloom_count_0 = 1;
	mbloom.bloom_count_s = 0;
	mbloom.bloom_filter_0[0] = &dummy;

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 3); //MD5
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);

	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 1);

	check_daa_deviceid_optout(&params, &cache_handle, &dbconn_handle, &opt_out);
	assert_int_equal(opt_out, 1);
}

static void check_daa_deviceid_optout__positive_raw_deviceid_sha1(void **state)
{
	cache_handle_t cache_handle;
	db_connection_t dbconn_handle;
	char *str = "abcdabcdabcdabcd";
	char *dbquery = GET_DAA_DEVICE_OPTOUT_BLOOM; 
	ad_server_req_param_t params;
	int opt_out = 0;
	strcpy(params.device_id,"abcdabcdabcdabcd");
	params.udid_hash = 1;
	BLOOM dummy;
	MULTI_BLOOM mbloom;
	mbloom.bloom_count_0 = 1;
	mbloom.bloom_count_s = 0;
	mbloom.bloom_filter_0[0] = &dummy;

	/* Mock sha1 function */
	expect_string(__wrap_get_sha1_hash, in_str, params.device_id);
	expect_value(__wrap_get_sha1_hash, max_out_len_with_null, MAX_DAA_OPTOUT_DEVICEID_LEN);

	will_return(__wrap_get_sha1_hash, cast_ptr_to_largest_integral_type(str));
	will_return(__wrap_get_sha1_hash, 0);

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 2); //SHA1
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);

	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 1);

	check_daa_deviceid_optout(&params, &cache_handle, &dbconn_handle, &opt_out);
	assert_int_equal(opt_out, 1);
}

static void check_daa_deviceid_optout__positive_raw_deviceid_md5(void **state)
{
	cache_handle_t cache_handle;
	db_connection_t dbconn_handle;
	char *str = "abcdabcdabcdabcd";
	char *dbquery = GET_DAA_DEVICE_OPTOUT_BLOOM; 
	ad_server_req_param_t params;
	int opt_out = 0;
	strcpy(params.device_id,"abcdabcdabcdabcd");
	params.udid_hash = 1;
	BLOOM dummy;
	MULTI_BLOOM mbloom;
	mbloom.bloom_count_0 = 1;
	mbloom.bloom_count_s = 0;
	mbloom.bloom_filter_0[0] = &dummy;

	/* Mock sha1 function */
	expect_string(__wrap_get_sha1_hash, in_str, params.device_id);
	expect_value(__wrap_get_sha1_hash, max_out_len_with_null, MAX_DAA_OPTOUT_DEVICEID_LEN);

	will_return(__wrap_get_sha1_hash, cast_ptr_to_largest_integral_type(str));
	will_return(__wrap_get_sha1_hash, 0);

	/* Mock md5 function */
	expect_string(__wrap_get_md5_hash, in_str, params.device_id);
	expect_value(__wrap_get_md5_hash, max_out_len_with_null, MAX_DAA_OPTOUT_DEVICEID_LEN);

	will_return(__wrap_get_md5_hash, cast_ptr_to_largest_integral_type(str));
	will_return(__wrap_get_md5_hash, 0);

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 2); //SHA1
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);

	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 0);

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 3); //MD5
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);

	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 1);

	check_daa_deviceid_optout(&params, &cache_handle, &dbconn_handle, &opt_out);
	assert_int_equal(opt_out, 1);
}

static void check_daa_deviceid_optout__positive_unknown_deviceid_sha1(void **state)
{
	cache_handle_t cache_handle;
	db_connection_t dbconn_handle;
	char *str = "abcdabcdabcdabcd";
	char *dbquery = GET_DAA_DEVICE_OPTOUT_BLOOM; 
	ad_server_req_param_t params;
	int opt_out = 0;
	strcpy(params.device_id,"abcdabcdabcdabcd");
	params.udid_hash = 0;
	BLOOM dummy;
	MULTI_BLOOM mbloom;
	mbloom.bloom_count_0 = 1;
	mbloom.bloom_count_s = 0;
	mbloom.bloom_filter_0[0] = &dummy;

	/* Mock sha1 function */
	expect_string(__wrap_get_sha1_hash, in_str, params.device_id);
	expect_value(__wrap_get_sha1_hash, max_out_len_with_null, MAX_DAA_OPTOUT_DEVICEID_LEN);

	will_return(__wrap_get_sha1_hash, cast_ptr_to_largest_integral_type(str));
	will_return(__wrap_get_sha1_hash, 0);

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 2); //SHA1
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);

	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);
	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 0);
	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 1);

	check_daa_deviceid_optout(&params, &cache_handle, &dbconn_handle, &opt_out);
	assert_int_equal(opt_out, 1);
}

static void check_daa_deviceid_optout__positive_unknown_deviceid_md5(void **state)
{
	cache_handle_t cache_handle;
	db_connection_t dbconn_handle;
	char *str = "abcdabcdabcdabcd";
	char *dbquery = GET_DAA_DEVICE_OPTOUT_BLOOM; 
	ad_server_req_param_t params;
	int opt_out = 0;
	strcpy(params.device_id,"abcdabcdabcdabcd");
	params.udid_hash = 0;
	BLOOM dummy;
	MULTI_BLOOM mbloom;
	mbloom.bloom_count_0 = 1;
	mbloom.bloom_count_s = 0;
	mbloom.bloom_filter_0[0] = &dummy;

	/* Mock sha1 function */
	expect_string(__wrap_get_sha1_hash, in_str, params.device_id);
	expect_value(__wrap_get_sha1_hash, max_out_len_with_null, MAX_DAA_OPTOUT_DEVICEID_LEN);

	will_return(__wrap_get_sha1_hash, cast_ptr_to_largest_integral_type(str));
	will_return(__wrap_get_sha1_hash, 0);

	/* Mock md5 function */
	expect_string(__wrap_get_md5_hash, in_str, params.device_id);
	expect_value(__wrap_get_md5_hash, max_out_len_with_null, MAX_DAA_OPTOUT_DEVICEID_LEN);

	will_return(__wrap_get_md5_hash, cast_ptr_to_largest_integral_type(str));
	will_return(__wrap_get_md5_hash, 0);

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 2); //SHA1
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);

	expect_memory(__wrap_cache_get_bloom_filters, cache, &cache_handle, sizeof(cache_handle));
	expect_memory(__wrap_cache_get_bloom_filters, dbconn, &dbconn_handle, sizeof(dbconn_handle));
	expect_string(__wrap_cache_get_bloom_filters, db_query, dbquery);
	expect_value(__wrap_cache_get_bloom_filters, pub_id, 3); //MD5
	expect_value(__wrap_cache_get_bloom_filters, site_id, 0);
	expect_value(__wrap_cache_get_bloom_filters, bloom_type, -1);

	will_return(__wrap_cache_get_bloom_filters, cast_ptr_to_largest_integral_type(&mbloom));
	will_return(__wrap_cache_get_bloom_filters, 0);


	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);
	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);
	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);
	expect_string(__wrap_lowercase_string, s, str);
	expect_value(__wrap_lowercase_string, left, 0);
	expect_value(__wrap_lowercase_string, right, MAX_DAA_OPTOUT_DEVICEID_LEN - 1);

	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 0);
	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 0);
	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 0);
	expect_string(__wrap_bloom_check, s, str);
	will_return(__wrap_bloom_check, 1);

	check_daa_deviceid_optout(&params, &cache_handle, &dbconn_handle, &opt_out);
	assert_int_equal(opt_out, 1);
}

int main()
{
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(check_daa_deviceid_optout__positive_sha1_deviceid),
		cmocka_unit_test(check_daa_deviceid_optout__positive_md5_deviceid),
		cmocka_unit_test(check_daa_deviceid_optout__positive_raw_deviceid_md5),
		cmocka_unit_test(check_daa_deviceid_optout__positive_raw_deviceid_sha1),
		cmocka_unit_test(check_daa_deviceid_optout__positive_unknown_deviceid_md5),
		cmocka_unit_test(check_daa_deviceid_optout__positive_unknown_deviceid_sha1),
		cmocka_unit_test(check_daa_deviceid_optout_bloom_filter__negative_failed_to_get_bloom_filter),
		cmocka_unit_test(check_daa_deviceid_optout_bloom_filter__negative_bloom_lookup_failed),
		cmocka_unit_test(check_daa_deviceid_optout_bloom_filter__positive_bloom_lookup_success),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
