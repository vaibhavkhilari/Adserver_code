/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include<limits.h>
#include<stdarg.h>
#include<stdio.h>
#include"bloom_filter.h"
#include<string.h>
#include"error.h"
#include"deal_def.h"
#include"ad_server_types.h"
#include "log_fw.h"

#define HTTP_URL_PROTOCOL_STR "http://"
#define LEN_HTTP_URL_PROTOCOL_STR  7
#define HTTPS_URL_PROTOCOL_STR "https://"
#define LEN_HTTPS_URL_PROTOCOL_STR 8

/*
 * param 1 : bit array of size, we allocate it 25% more than use_count i.e. domain name count
 * param 2 : # of hash functions
 * param 3 : ... va_list of hasn functions
 */
BLOOM *bloom_create(int nelements, size_t *memcache_obj_size) {
	BLOOM *bloom;
	/* Calculate size of bit array to be used as a bloom filter for the publishers blocklist.
	   Here we allocate 25% more than that of exact requirement, it helps in reducing false positives */
	const size_t size = BIT_ARRAY_SIZE_BITS(nelements);
	(*memcache_obj_size) = 0;

	if(nelements <= 0) {
		llog_write(L_DEBUG, "\nError: Invaid nelements:%d, %s:%d\n", nelements, __FILE__, __LINE__);
		return NULL;
	}

	//one time memory allocation
	(*memcache_obj_size) = sizeof(BLOOM) + BIT_ARRAY_SIZE_BYTES(size) + 1;
	if(!(bloom=(BLOOM *)malloc(*memcache_obj_size))) return NULL;

	//zero-out the memory
	memset(bloom, 0, (*memcache_obj_size));
	
	bloom->bit_array_size = size;
	bloom->nelements = nelements;

	return bloom;
}

int bloom_destroy(BLOOM **bloom) {
	if((bloom) && (*bloom)) {
		free(*bloom);
		*bloom = NULL;
	}
	return 0;
}

int bloom_add(BLOOM *bloom, const char *s) {
	int i,j;
	word64 res[3];
	unsigned char* bit_array = (unsigned char*)&((bloom)[1]);
	
	BLOCKLIST_DEBUG("\n%s:%s:",__FUNCTION__,s);
	tiger((byte*)s, strlen(s), res);
	for(i=0; i<3; i++) {
		for(j=(BIT_LIMIT-BIT_COUNT); j>=0; j-=SKIPED_BITS) {
			BLOCKLIST_DEBUG("%ld_",((word32)((res[i]>>j)&BIT_CHUNK)) % bloom->bit_array_size);
			SETBIT(bit_array, ((word32)((res[i]>>j)&BIT_CHUNK)) % bloom->bit_array_size);
		}
	}
	BLOCKLIST_DEBUG("\n");
	return 0;
}

int bloom_check(const BLOOM *bloom, const char *s) {
	int i,j;
	word64 res[3];
	unsigned char* bit_array = (unsigned char*)&((bloom)[1]);
	BLOCKLIST_DEBUG("\n%s:%s:",__FUNCTION__,s);

	if (!bit_array) {
		//Serious Issue, Idealy bit_array shoud not be NULL
		LOG_FATAL(BLOOM_CHECK_FAILED, MOD_RTB_DEBUG, s);
		return 0;
	}

	tiger((byte*)s, strlen(s), res);
	for(i=0; i<3; i++) {
		for(j=(BIT_LIMIT-BIT_COUNT); j>=0; j-=SKIPED_BITS) {
			BLOCKLIST_DEBUG("%ld_",((word32)((res[i]>>j)&BIT_CHUNK)) % bloom->bit_array_size);
			if(!(GETBIT(bit_array, ((word32)((res[i]>>j)&BIT_CHUNK)) % bloom->bit_array_size))) {
				//BLOCKLIST_DEBUG("\nBloom:: No match for %s\n", s);
				return 0;
			}
		}
	}
	//BLOCKLIST_DEBUG("\nBloom:: match found for %s\n", s);
	return 1;
}

#define swap(a, b) \
	do { \
		char temp = a; \
		a = b; \
		b = temp; \
	} while(0);



int char_counter(
		const char* str,
		char c
		)
{
	int counter = 0;
	while(*str) {
		if((*str) == c) {
			counter++;
		}
		str++;
	}
	return counter;
}

/*
 * Helpers for IDNA convertions.
 */
static int is_ASCII_name(const char *hostname) {
	const unsigned char *ch = (const unsigned char*)hostname;

	while(*ch) {
		if(*ch++ & 0x80)
			return IS_NON_ASCII;
	}
	return IS_ASCII;
}

/*
 * Convert uniocde domain to punycode e.g. japanese domain to its ascii-equivalent domain
 * On SUCCESS :- This allocates memory for out_domain and stores punycode in it
 */
int convert_unicode_domain_to_punycode(const char *in_domain, char **out_domain) {
	int rc;

	// no need to convert if its ascii domain
	if(is_ASCII_name(in_domain)) {
		return NO_ASC_CONVERSION;
	}
	
	if(stringprep_check_version(LIBIDN_REQUIRED_VERSION)) {
		char *ace_hostname = NULL;
		rc = idna_to_ascii_8z(in_domain, &ace_hostname, 0);
		//llog_write(L_DEBUG, "Input domain encoded as `%s'\n",
		//		stringprep_locale_charset ());
		if(rc != IDNA_SUCCESS) {
			llog_write(L_DEBUG, "I18_ERROR: Failed to convert %s to ACE, rc:%d, %s:%d\n",
					in_domain, rc, __FILE__, __LINE__);

			if(ace_hostname != NULL) {
				free(ace_hostname);
				ace_hostname = NULL;
			}
			rc = ASC_CONVERT_ERROR;
		}
		else {
			/* change the name pointer to point to the encoded hostname */
			*out_domain = ace_hostname;
			rc = ASC_CONVERT_SUCCESS;
		}
	}
	else {
		llog_write(L_DEBUG, "\nI18_ERROR: Invalid libidn version:%s, %s:%d\n",
				LIBIDN_REQUIRED_VERSION, __FILE__, __LINE__);
		rc = ASC_INVALID_VERSION;
	}

	return rc;
}

int get_actual_url_start_pos(char*in_str){
	char * cur_pos=in_str;
	if(strncmp(in_str, HTTP_URL_PROTOCOL_STR, LEN_HTTP_URL_PROTOCOL_STR)==0)
		cur_pos+=LEN_HTTP_URL_PROTOCOL_STR;
	else if(strncmp(in_str,HTTPS_URL_PROTOCOL_STR, LEN_HTTPS_URL_PROTOCOL_STR)==0)
		cur_pos+=LEN_HTTPS_URL_PROTOCOL_STR;
	if(strncmp(cur_pos, WWW_STR, WWW_STR_LEN)==0)
		cur_pos+=WWW_STR_LEN;
	return cur_pos-in_str;
}

//evaluate_url_filter
int evaluate_url_filter(
		char* domain_to_be_searched,
		const BLOOM** bloom,
		const int bloom_count,
		const int depth_of_search,
		char delim
		)
{
	int rc = NO_ASC_CONVERSION;
	char *domain_punycode = NULL;
	char *processing_string = NULL;
	char *actual_url = NULL;
	int domain_found = 0;
	int i,j;

	if(NULL == domain_to_be_searched || bloom==NULL|| depth_of_search<0)
		return domain_found;
	
	actual_url=domain_to_be_searched;
	rc = convert_unicode_domain_to_punycode(actual_url, &domain_punycode);
	BLOCKLIST_DEBUG("URL Bloom:I18:TLDs:: Unicode:%s Punycode:%s, rc:%d\n", actual_url, domain_punycode, rc);
	if((rc == ASC_CONVERT_SUCCESS) && (domain_punycode != NULL)) {
		actual_url=domain_punycode;
	}

	processing_string = actual_url;
	// for ex: a.b.com/games/outdoor/cricket, we want to search for a.b.c.com, a.b.c.com/games and a.b.c.com/games/outdoor 
	// if depth_of_search=2

	processing_string = strchr(processing_string, delim);
	for (i=0; i<=depth_of_search && domain_found !=1 ; i++) {
		if(NULL != processing_string)
			*processing_string = 0;

		for(j=0; j<bloom_count ; j++){
			if(bloom_check(bloom[j],actual_url )) {
				BLOCKLIST_DEBUG("URL BloomList: Found::%s in Bloom:%d\n", actual_url,j);
				domain_found = 1;
				break;
			}
		}
		if(NULL != processing_string){
			*processing_string = delim;
			processing_string++;
			processing_string = strchr(processing_string, delim);
		}else break;
	}
	
	if(domain_punycode != NULL) {
		free(domain_punycode);
		domain_punycode = NULL;
	}
	return domain_found;
}


int substring_bloom_search(
		char* domain_to_be_searched,
		const BLOOM* bloom
		) 
{
	int rc = NO_ASC_CONVERSION;
	char *domain_punycode = NULL;
	char *processing_string = domain_to_be_searched;
	int subdomain_levels = 0;
	int domain_found = 0;
	int i;
	char subdomain_delimiter = '.';


	rc = convert_unicode_domain_to_punycode(processing_string, &domain_punycode);
	BLOCKLIST_DEBUG("\nI18:TLDs:: Unicode:%s Punycode:%s, rc:%d\n", processing_string, domain_punycode, rc);
	if((rc == ASC_CONVERT_SUCCESS) && (domain_punycode != NULL)) {
		//assign punycode to processing_string for further checks
		processing_string = domain_punycode;
	}

	subdomain_levels = char_counter(processing_string, subdomain_delimiter);

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "\nLanding Page Filter : RTB response TLD = %s, subdomain_levels = %d %s:%d\n", processing_string, subdomain_levels, __FILE__, __LINE__);
#endif
	
	// for a.b.c.com, we want to search for a.b.c.com, b.c.com and c.com
	for (i=1; i<=subdomain_levels; i++) {

		if(bloom_check(bloom, processing_string)) {
			//We found the domain in list
			domain_found = 1;
			break;
		}
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "\nLanding Page Filter : Match didn't happen. Searching for parent TLD %s:%d\n", __FILE__, __LINE__);
#endif
		// Above ensures that strchr will never return NULL
		processing_string = strchr(processing_string, subdomain_delimiter);
		processing_string++;
	}

	//free out the memory allocated by idna_to_ascii_8z()	
	if(domain_punycode != NULL) {
		free(domain_punycode);
		domain_punycode = NULL;
	}

	return domain_found;
}

int substring_multi_bloom_search(
		char* domain_to_be_searched,
		const MULTI_BLOOM* multi_bloom
		) 
{
	int rc = NO_ASC_CONVERSION;
	char *domain_punycode = NULL;
	char *processing_string = domain_to_be_searched;
	int subdomain_levels = 0;
	int domain_found = 0;
	int i,j;
	char subdomain_delimiter = '.';


	rc = convert_unicode_domain_to_punycode(processing_string, &domain_punycode);
	BLOCKLIST_DEBUG("\nI18:TLDs:: Unicode:%s Punycode:%s, rc:%d\n", processing_string, domain_punycode, rc);
	if((rc == ASC_CONVERT_SUCCESS) && (domain_punycode != NULL)) {
		//assign punycode to processing_string for further checks
		processing_string = domain_punycode;
	}

	subdomain_levels = char_counter(processing_string, subdomain_delimiter);

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "\nLanding Page Filter : RTB response TLD = %s, subdomain_levels = %d %s:%d\n", processing_string, subdomain_levels, __FILE__, __LINE__);
#endif
	
	// for a.b.c.com, we want to search for a.b.c.com, b.c.com and c.com
	for (i=1; i<=subdomain_levels; i++) {
		for(j=0; j<multi_bloom->bloom_count_0 ; j++){
			if(bloom_check(multi_bloom->bloom_filter_0[j], processing_string)) {
				MULTIBLOOM_DEBUG("MULTI_BLOOM:: %s Found in PubBloom:%d\n", processing_string, j);
				domain_found = 1;
				goto done;
			}
		}
		for(j=0; j<multi_bloom->bloom_count_s ; j++){
			if(bloom_check(multi_bloom->bloom_filter_s[j], processing_string)) {
				MULTIBLOOM_DEBUG("MULTI_BLOOM:: %s Found in SiteBloom:%d\n", processing_string, j);
				domain_found = 1;
				goto done;
			}
		}
	
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "\nLanding Page Filter : Match didn't happen. Searching for parent TLD %s:%d\n", __FILE__, __LINE__);
#endif
		// Above ensures that strchr will never return NULL
		processing_string = strchr(processing_string, subdomain_delimiter);
		processing_string++;
	}

done:
	//free out the memory allocated by idna_to_ascii_8z()	
	if(domain_punycode != NULL) {
		free(domain_punycode);
		domain_punycode = NULL;
	}

	return domain_found;
}

int substring_multi_concat_bloom_search(
		int id,
		const char* domain_to_be_searched,
		const MULTI_BLOOM* multi_bloom
		) 
{
	int rc = NO_ASC_CONVERSION;
	char *domain_punycode = NULL;
	const char *processing_string = domain_to_be_searched;
	int subdomain_levels = 0;
	int domain_found = 0;
	int i,j;
	char subdomain_delimiter = '.';
	char buffer[MAX_DEAL_ID_LEN + MAX_DOMAIN_NAME_LENGTH +2]; // +1 for _

	rc = convert_unicode_domain_to_punycode(processing_string, &domain_punycode);
	BLOCKLIST_DEBUG("\nI18:TLDs:: Unicode:%s Punycode:%s, rc:%d\n", processing_string, domain_punycode, rc);
	if((rc == ASC_CONVERT_SUCCESS) && (domain_punycode != NULL)) {
		//assign punycode to processing_string for further checks
		processing_string = domain_punycode;
	}

	subdomain_levels = char_counter(processing_string, subdomain_delimiter);

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "\nLanding Page Filter : RTB response TLD = %s, subdomain_levels = %d %s:%d\n", processing_string, subdomain_levels, __FILE__, __LINE__);
#endif
	
	// for a.b.c.com, we want to search for a.b.c.com, b.c.com and c.com
	for (i=1; i<=subdomain_levels; i++) {
    
		snprintf(buffer, MAX_DEAL_ID_LEN + MAX_DOMAIN_NAME_LENGTH +2 ,"%d_%s", id, processing_string);
		
		for(j=0; j<multi_bloom->bloom_count_0 ; j++){
			if(bloom_check(multi_bloom->bloom_filter_0[j], buffer)) {
				MULTIBLOOM_DEBUG("DEAL_BLOOM:: %s Found in PubBloom:%d\n", buffer, j);
				domain_found = 1;
				goto done;
			}
		}
		for(j=0; j<multi_bloom->bloom_count_s ; j++){
			if(bloom_check(multi_bloom->bloom_filter_s[j], buffer)) {
				MULTIBLOOM_DEBUG("DEAL_BLOOM:: %s Found in SiteBloom:%d\n", buffer, j);
				domain_found = 1;
				goto done;
			}
		}
	
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "\nLanding Page Filter : Match didn't happen. Searching for parent TLD %s:%d\n", __FILE__, __LINE__);
#endif
		// Above ensures that strchr will never return NULL
		processing_string = strchr(processing_string, subdomain_delimiter);
		processing_string++;
	}

done:
	//free out the memory allocated by idna_to_ascii_8z()	
	if(domain_punycode != NULL) {
		free(domain_punycode);
		domain_punycode = NULL;
	}

	return domain_found;
}


int substring_deal_bloom_search(
		int deal_meta_id,
                char* domain_to_be_searched,
                const BLOOM* bloom
		)
{
	int rc = NO_ASC_CONVERSION;
	char *domain_punycode = NULL;
	char *processing_string = domain_to_be_searched;
        int domain_found = 0;
        char subdomain_delimiter = '.';
        char buffer[MAX_DEAL_ID_LEN + MAX_DOMAIN_NAME_LENGTH +2]; // +1 for _

	rc = convert_unicode_domain_to_punycode(processing_string, &domain_punycode);
	BLOCKLIST_DEBUG("\nI18:TLDs::DEAL Unicode:%s Punycode:%s, rc:%d\n", processing_string, domain_punycode, rc);
	if((rc == ASC_CONVERT_SUCCESS) && (domain_punycode != NULL)) {
		//assign punycode to processing_string for further checks
		processing_string = domain_punycode;
	}

        // for a.b.c.com, we want to search for a.b.c.com, b.c.com and c.com
        while(1){
                snprintf(buffer, MAX_DEAL_ID_LEN + MAX_DOMAIN_NAME_LENGTH +2 ,"%d_%s", deal_meta_id, processing_string);
                if(bloom_check(bloom, buffer)) {
                        //We found the domain in list
                        domain_found = 1;
                        break;
                }
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
                llog_write(L_DEBUG, "\nLanding Page Filter : Match didn't happen. Searching for parent TLD %s:%d\n", __FILE__, __LINE__);
#endif
                // Above ensures that strchr will never return NULL
                processing_string = strchr(processing_string, subdomain_delimiter);
                if (processing_string == NULL){
                        break;
                }
                processing_string++;
        }

	//free out the memory allocated by idna_to_ascii_8z()
	if(domain_punycode != NULL) {
		free(domain_punycode);
		domain_punycode = NULL;
	}

        return domain_found;
}

 /*
  * This is a generic helper function which check string in bloom.
  * Input: Bloom and string
  * Output: 1 found in bloom
  *         0 not found.
  */
int check_in_blocklist_bloom(const char *processing_data, const MULTI_BLOOM *multi_bloom) {
  int j;
  int found_in_bloom = 0;
  if ( NULL == multi_bloom || NULL == processing_data ) {
    llog_write(L_DEBUG, "\n check_in_blocklist_bloom: Incorrect Argument %s : %d \n", __FILE__,__LINE__);
    goto done;
  }
  if (!multi_bloom->bloom_filter_0[0] && !multi_bloom->bloom_filter_s[0]) {
    MULTIBLOOM_DEBUG("\nDCBL_INFO: Bloom Filter does not Exists, %s:%d\n",
        __FILE__, __LINE__);
    goto done;
  }

	/*
	 * Here No need to check multi_bloom->bloom_filter_0 and
	 * multi_bloom->bloom_filter_s individually
	 * If Anyone is Null then it's count will be 0
	 */

  for(j=0; j<multi_bloom->bloom_count_0; j++){
    if(bloom_check(multi_bloom->bloom_filter_0[j], processing_data)) {
      MULTIBLOOM_DEBUG("MULTI_BLOOM:: %s Found in DSPBloom:%d\n", processing_data, j);
      found_in_bloom = 1;
      goto done;
    }
  }

  for(j=0; j<multi_bloom->bloom_count_s; j++){
    if(bloom_check(multi_bloom->bloom_filter_s[j], processing_data)) {
      MULTIBLOOM_DEBUG("MULTI_BLOOM:: %s Found in CAMBloom:%d\n", processing_data, j);
      found_in_bloom = 1;
      goto done;
    }
  }
done:
  return found_in_bloom;
}
