/*
	 PubMatic Inc. ("PubMatic") CONFIDENTIAL
	 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/


#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <fte_types.h>
#include "bloom_filter.h"
#include <libstats_util.h>
#include "rtb_brand_control_util.h"
#include "publisher_site_block_list.h"
#include "cache_pub_site_advertiser_domain_white_list.h"
#include "cache_publisher_site_deal_domain_list.h"
#include "crc32_util.h"
#include <rt_types.h>
#include "log_fw.h"
#include "compare_util.h"
#include "cache_get_bloom_filters.h"
#include "publisher_site_tld_whitelist.h"
//#include "get_advertiser_id_from_adv_domain.h"
#include "cache_pub_site_advertiser_domain_category_list.h"
#include "get_advertiser_id.h"
#include "cache_get_buyer_blocklist.h"

//PubMatic As Bidder Changes
#define SUBDOMAIN_DELIMITER '.'
#define URL_LIST_SEPARATOR ','
#define MAX_BLOOM_LIMIT 3 
#define MAX_GLOBAL_BLKLIST_BLOOM_SIZE 3

#define GET_TIMESTAMP_DIFF_IN_MIS(time_diff, end, start) \
	(time_diff) = (((end.tv_sec * 1000000) + end.tv_usec) - ((start.tv_sec * 1000000) + start.tv_usec));

extern buyer_block_list_t *g_global_buyer_blocklist[2];
extern unsigned int g_cur_global_buyer_blocklist_idx;
extern buyer_block_list_t *g_channel_partner_buyer_blocklist[2];
extern unsigned int g_cur_channel_partner_buyer_blocklist_idx;

void destroy_multi_bloom(MULTI_BLOOM* multi) {
	int i;
	if (!multi)
		return;
	for(i=0; i<MAX_ALLOWED_BLOOMS ; i++){
		if(multi->bloom_filter_0[i]!=NULL)
			memcached_release_object_reference((char**)&multi->bloom_filter_0[i]);
		if(multi->bloom_filter_s[i]!=NULL)
			memcached_release_object_reference((char**)&multi->bloom_filter_s[i]);
	}
}


int filter_landing_page(
		long pub_id,
		long site_id,
		rt_response_params_t* rt_response_params,
		int rt_request_count,
		const ad_server_additional_params_t* additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		cache_handle_t* cache_handle,
		db_connection_t* kadserver_dbconn,
		db_connection_t* adflex_dbconn,
		libstat_counters_t* libstats
		)
{

	MULTI_BLOOM lpf_bloom;
	MULTI_BLOOM g_lpf_bloom;
	MULTI_BLOOM deal_bloom;

	memset((void*)&lpf_bloom, 0, sizeof(MULTI_BLOOM));
	memset((void*)&g_lpf_bloom, 0, sizeof(MULTI_BLOOM));
	memset((void*)&deal_bloom, 0, sizeof(MULTI_BLOOM));

	BLOOM *pub_site_url_bloom[MAX_ALLOWED_BLOOMS]={0};
	int url_bloom_count=0;

	int i=0;
	char processing_string[MAX_DOMAIN_NAME_LENGTH + 1];
	char processing_url_string[MAX_DOMAIN_NAME_LENGTH + 1];
	char * char_pos=NULL;
	int len = 0;
	int domain_found = 0;
	int whitelist_enabled = additional_parameters->pubsite_default_settings.whitelist_enabled;

	//Nothing to Filter
	if(rt_request_count <= 0) {
		return ADS_ERROR_SUCCESS;
	}

		//Code to read bloom for deal level whitelist for site
		cache_get_bloom_filters(cache_handle,
					adflex_dbconn,
					PUB_SITE_DEAL_WHITELIST_KEY,
					GET_PUB_SITE_DEAL_WHITELIST_BLOOM,
					&deal_bloom,
					pub_id,
					site_id,
					1);

		//if site whitelist is enabled, read whitelist else blocklist
		if(whitelist_enabled == 1){
			cache_get_bloom_filters(cache_handle,
					kadserver_dbconn,
					PUB_SITE_DOM_WHITELIST_KEY,
					GET_PUB_SITE_DOMAIN_WHITELIST_BLOOM,
					&lpf_bloom,
					pub_id,
					site_id,
					whitelist_enabled);

		}else if(whitelist_enabled == 0){
			cache_get_bloom_filters(cache_handle,
					kadserver_dbconn,
					PUB_SITE_GLOBAL_BLK_LST_KEY,
					GET_PUB_SITE_DOMAIN_BLOCKLIST_BLOOM,
					&g_lpf_bloom,
					0,
					0,
					-1);

			cache_get_bloom_filters(cache_handle,
					kadserver_dbconn,
					PUB_SITE_DOM_BLOCKLIST_KEY,
					GET_PUB_SITE_DOMAIN_BLOCKLIST_BLOOM,
					&lpf_bloom,
					pub_id,
					site_id,
					whitelist_enabled);
		} else {
			llog_write(L_DEBUG, "\nError in getting publisher_site_white_or_block_list pubid: %ld site_id: %ld white_list_flag :%d", 
					pub_id, site_id, whitelist_enabled);
			return ADS_ERROR_INVALID_ARGS; 
		}
		
		if(0 != additional_parameters->pubsite_default_settings.url_block_list_enabled ){
			cache_get_publisher_site_url_bloom(pub_id,
					site_id,
					pub_site_url_bloom,
					&url_bloom_count,
					whitelist_enabled,
					cache_handle,
					kadserver_dbconn);
		}
		LOG_MESSAGE(MOD_DEFAULT,"URL_PUB_SITE_BLOOM_LIST:"
				"BloomIn:PubId:%ld,Site:%ld,BloomCount:%d\n",pub_id,site_id,url_bloom_count);

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		if (!lpf_bloom.bloom_filter_0[0] && !lpf_bloom.bloom_filter_s[0]){
			llog_write(L_DEBUG, "\nNo bloom filter found from cache or db for filter_landing_page,pub:%ld site:%ld %s:%d\n", pub_id, site_id, __FILE__, __LINE__);
		}
		else {
			if(lpf_bloom.bloom_filter_0[0]) {
				llog_write(L_DEBUG, "\nReceived a Publisher level bloom filter for filter_landing_page,pub:%ld %s:%d\n",
						pub_id, __FILE__, __LINE__);
			}
			if (lpf_bloom.bloom_filter_s[0]) {
				llog_write(L_DEBUG, "\nReceived a Site level  bloom filter for filter_landing_page,pub:%ld site:%ld %s:%d\n", 
						pub_id, site_id, __FILE__, __LINE__);
			}
		}
#endif

		for (i=0; i < rt_request_count; i++) {

			/*Skip pre filtered campaigns*/
			if(adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag == 1) {
				continue;
			}
			domain_found=0;
			strncpy(processing_string, rt_response_params[i].bid_response_params.landing_page_tld, MAX_DOMAIN_NAME_LENGTH);
			processing_string[MAX_DOMAIN_NAME_LENGTH] = '\0';

			
			len = strlen(processing_string);
			if (len == 0) {
				//If deal level while list is enable . filter the campaign as there is no landing page
				if ( IS_DEAL_LEVEL_FEATURE_FLAG_SET( &(adcampaigns[rt_response_params[i].campaign_index]), APPLY_DEAL_WHITE_LIST) ){

					BLOCKLIST_DEBUG("\nDeal_Bloom:pub:%ld site:%ld:: No Landing Page in RTB Response, Filtering campaign_id:%u, %s:%d\n",
							pub_id, site_id, adcampaigns[rt_response_params[i].campaign_index].campaign_id, __FILE__, __LINE__);
					adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
					adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = DEAL_WHITE_LIST_FILTER;

					/*if(additional_parameters->adserver_config_params->stats_collection_enable == 1) {
						increment_stats_counters(libstats, RTB_DEAL_WHITE_LIST_FILTER_ID, adcampaigns[rt_response_params[i].campaign_index].campaign_id);
						}*/
				}
				else if(whitelist_enabled == 1){
					BLOCKLIST_DEBUG("\nWLF_Bloom:pub:%ld site:%ld:: No Landing Page in RTB Response, Filtering campaign_id:%u, %s:%d\n",
							pub_id, site_id, adcampaigns[rt_response_params[i].campaign_index].campaign_id, __FILE__, __LINE__);
					adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
					adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = LANDING_PAGE_FILTER;
				}
				//continue with next campaign
				continue;
			}

			if (processing_string[len -1 ] == '/') {
				// Use Case :- www.google.com/
				processing_string[len - 1] = '\0';
				len = len - 1;
			}

			//If deal level white list is enable no need to check site level white list or publisher block list.

			if ( IS_DEAL_LEVEL_FEATURE_FLAG_SET( &(adcampaigns[rt_response_params[i].campaign_index]), APPLY_DEAL_WHITE_LIST) ){

				if (!deal_bloom.bloom_filter_0[0] && !deal_bloom.bloom_filter_s[0]){
					//In case deal domain bloom is not present, filter the deal.
					BLOCKLIST_DEBUG("\nDeal_Bloom:pub:%ld site:%ld:: bloom is NULL, Filtering campaign_id:%u, %s:%d\n",
							pub_id, site_id, adcampaigns[rt_response_params[i].campaign_index].campaign_id, __FILE__, __LINE__);
					adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
					adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = DEAL_WHITE_LIST_FILTER;

					/*if(additional_parameters->adserver_config_params->stats_collection_enable == 1) {
						increment_stats_counters(libstats, RTB_DEAL_WHITE_LIST_FILTER_ID, adcampaigns[rt_response_params[i].campaign_index].campaign_id);
						}*/
					continue;
				}

				// tld of non zero length found
				domain_found = substring_multi_concat_bloom_search( adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->dsp_interested_deal->parent_deal_params->deal_meta_id, 
						processing_string, &deal_bloom);
				if (domain_found != 1){

					BLOCKLIST_DEBUG("\nDeal_Bloom:pub:%ld site:%ld:: landing page is not whitelisted, Filtering campaign_id:%u, %s:%d\n",
							pub_id, site_id, adcampaigns[rt_response_params[i].campaign_index].campaign_id, __FILE__, __LINE__);
					adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
					adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = DEAL_WHITE_LIST_FILTER;

					/*if(additional_parameters->adserver_config_params->stats_collection_enable == 1) {
						increment_stats_counters(libstats, RTB_DEAL_WHITE_LIST_FILTER_ID, adcampaigns[rt_response_params[i].campaign_index].campaign_id);
						}*/
				}else{
					//TODO add code for allowing deal due to whitelist
					adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->validation_check_pass_flag |= PASSED_DEAL_WHITE_LIST_VALIDATION;
					//skip UCAF if deal passed
					rt_response_params[i].skip_UCAF = 1;

					BLOCKLIST_DEBUG("\nDeal_Bloom:pub:%ld site:%ld:: %s is whitelisted, Filtering campaign_id:%u, %s:%d\n",
							pub_id, site_id, processing_string, adcampaigns[rt_response_params[i].campaign_index].campaign_id, __FILE__, __LINE__);
				}
				//Incase deal white list need not check site level white/block list and advertiser category filter
				continue;

			}else if((lpf_bloom.bloom_filter_0[0] || lpf_bloom.bloom_filter_s[0]) || 
						g_lpf_bloom.bloom_filter_0[0] || 
						(url_bloom_count>0 &&
						additional_parameters->pubsite_default_settings.url_block_list_enabled)) {

				if(whitelist_enabled == 0 && 	g_lpf_bloom.bloom_filter_0[0]){
					//First apply landing page filter as per domain blocklist
				  domain_found = substring_multi_bloom_search(processing_string, &g_lpf_bloom);
				}
				// tld of non zero length found
				if(domain_found == 0 && (lpf_bloom.bloom_filter_0[0] || lpf_bloom.bloom_filter_s[0])) {
				  domain_found = substring_multi_bloom_search(processing_string, &lpf_bloom);
				}


				if(domain_found==0 && url_bloom_count>0 &&
					additional_parameters->pubsite_default_settings.url_block_list_enabled) {

					char_pos=(rt_response_params[i].bid_response_params.landing_page_url[0]==0)?
					  rt_response_params[i].bid_response_params.landing_page_tld : 
					  rt_response_params[i].bid_response_params.landing_page_url;

					len=get_actual_url_start_pos(char_pos);
					strncpy(processing_url_string, char_pos+len, MAX_DOMAIN_NAME_LENGTH);

					processing_url_string[MAX_DOMAIN_NAME_LENGTH] = '\0';
					char_pos=strchr(processing_url_string, '?');

					if(NULL != char_pos)
					  *char_pos=0;

					domain_found=evaluate_url_filter(
						processing_url_string,
						(const BLOOM **)pub_site_url_bloom,
						url_bloom_count,
						additional_parameters->pubsite_default_settings.url_block_list_enabled,//this param used ad depth
						'/'
						);
				}	

				if((1 == whitelist_enabled && 0 == domain_found )
					|| (0 == whitelist_enabled && 1 == domain_found) ){

				  adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
				  adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering=LANDING_PAGE_FILTER;
	
					LOG_WARNING(WARN_REASON_FOR_FILTERING,
					  MOD_DEFAULT,pub_id,site_id,"DOMAIN_BLOCK_WHITE_LIST_FILTER",processing_string);
				 
					if(additional_parameters->adserver_config_params->stats_collection_enable == 1) {
						increment_stats_counters(libstats, RTB_LANDING_PAGE_FILTER_ID, adcampaigns[rt_response_params[i].campaign_index].campaign_id);
				  }
				  continue;
				}

			}else if(whitelist_enabled == 1){
				adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
				adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = LANDING_PAGE_FILTER;
				llog_write(L_DEBUG, "\nERROR: White list domain filter is NULL for :pub:%ld site:%ld",
						pub_id, site_id);
				continue;
			}
			//reaches here only if campaign remains un-filtered

			// domain not found in domain blocklist OR advertiser domain whitelist
		}

		for(i=0; i<MAX_ALLOWED_BLOOMS ; i++){
			if(pub_site_url_bloom[i]!=NULL)
				memcached_release_object_reference((char**)&pub_site_url_bloom[i]);
		}
		destroy_multi_bloom(&lpf_bloom);
		destroy_multi_bloom(&g_lpf_bloom);
		destroy_multi_bloom(&deal_bloom);

	return ADS_ERROR_SUCCESS;
}


int filter_landing_page_with_pm_as_bidder(
		const char* url_blocklist_in,
		long pub_id,
		long site_id,
		rt_response_params_t* rt_response_params,
		int rt_request_count,
		const ad_server_additional_params_t* additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		cache_handle_t* cache_handle,
		db_connection_t* kadserver_dbconn,
		libstat_counters_t* libstats
		)
{
	int i = 0;
	char *processing_string, *ptr;
	int j, len, subdomain_count;
	// these params are not used ;)
	(void) cache_handle;
	(void) kadserver_dbconn;

	if (url_blocklist_in == NULL || url_blocklist_in[0] == '\0') {
		return ADS_ERROR_SUCCESS;
	}

	if (rt_request_count > 0) {

		for (i = 0; i < rt_request_count; i++) {

			// Skip pre filtered campaigns or responses which don't have landing page tld
			if (adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag == 1 && 
					rt_response_params[i].bid_response_params.landing_page_tld[0] == '\0') {
				continue;
			}

			subdomain_count = char_counter(rt_response_params[i].bid_response_params.landing_page_tld, SUBDOMAIN_DELIMITER);
			processing_string = rt_response_params[i].bid_response_params.landing_page_tld;
			for(j = 1; j <= subdomain_count; j++) {
				if ((ptr = strstr(url_blocklist_in, processing_string))) {
					len = strlen(processing_string);
					if ((ptr == url_blocklist_in || *(ptr - 1) == URL_LIST_SEPARATOR) && (*(ptr + len) == '\0' || *(ptr + len) == URL_LIST_SEPARATOR)){
						/* domain found in the domain blocklist */
						adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
						adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = LANDING_PAGE_FILTER;
#ifdef BIDDER_DEBUG
						llog_write(L_DEBUG, "\nFiltering landing page: %s, %u, pId:%ld, sId:%ld requestId: %s::%s.%d\n ",
								rt_response_params[i].bid_response_params.landing_page_tld,
								adcampaigns[rt_response_params[i].campaign_index].campaign_id,pub_id,site_id,
								rt_response_params[i].bid_response_params.request_id, __FILE__, __LINE__);
#else
						(void)pub_id;
						(void)site_id;
#endif
						if(additional_parameters->adserver_config_params->stats_collection_enable == 1) {
							increment_stats_counters(libstats, RTB_LANDING_PAGE_FILTER_ID, adcampaigns[rt_response_params[i].campaign_index].campaign_id);
						}
						break;
					}
				}
				else {
					if (j == subdomain_count) {
						break;
					}
					processing_string = strchr(processing_string, SUBDOMAIN_DELIMITER);
					processing_string++;
				}
			}
		}
	}
	return ADS_ERROR_SUCCESS;
}

static int binary_search(
                const char* needle,
                const publisher_site_top_level_domain_name_t* haystack,
                int left,
                int right,
                const int is_sitecode_present,
								const int is_app_store_url
                )
{
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "needle = %s %s:%d\n", needle, __FILE__, __LINE__);
#endif
	int middle, tmp_middle;
	unsigned long crc_32_needle = calculate_crc ((unsigned char *)needle, strlen(needle));

#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "crc32 of needle = %lu\n", crc_32_needle);
#endif

	if(crc_32_needle > haystack[right].crc_32) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
		llog_write(L_DEBUG, "\nExiting from binary search as crc_32 is not present in current list\n");
#endif
		return -1;
	}

	while (left <= right) {
		middle = (left + right)/2;
		//result = strcmp(needle, haystack[middle].domain_name); 
		//result = crc_32_needle - haystack[middle].crc_32;
		if (crc_32_needle < haystack[middle].crc_32) {
			right = middle - 1;
		} else if (crc_32_needle > haystack[middle].crc_32) {
			left = middle + 1;
		} else {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
			llog_write(L_DEBUG, "\nBSearch CRC match, needle = %s, crc_32_needle = %lu, %s:%d\n", needle,  crc_32_needle, __FILE__, __LINE__);
#endif
												if (is_app_store_url) {
														return middle;
												}
                        /* CrC match occurred, Now validate the domain name by traversing up and down until the domain_name matches */
                        /* First check if we are already at the right place */
                        if (!(strncmp(needle, haystack[middle].domain_name, strlen(haystack[middle].domain_name)))) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				llog_write(L_DEBUG, "Both CRC: %lu and domain_name: %s\n", crc_32_needle, needle);
#endif
				return middle;
			}
			//Lets check if the match is made using the site code.
			if (is_sitecode_present) {
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
				llog_write(L_DEBUG, "Both CRC: %lu and site code: %s\n", crc_32_needle, needle);
#endif
				return middle;
			}

			/* So we were not? , so lets move up and down to find */

			tmp_middle = middle;
			/* Check upwards first */
			while (tmp_middle >= left && crc_32_needle == haystack[tmp_middle].crc_32) {
				if (!(strncmp(needle, haystack[tmp_middle].domain_name, strlen(haystack[tmp_middle].domain_name)))) {
					/* Found the Match */
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
					llog_write(L_DEBUG, "Both CRC: %lu and domain_name : %s\n", crc_32_needle, needle);
#endif
					return tmp_middle;
				}
				tmp_middle--;
			}

			middle +=1; /* Since We have already covered the middle case */

			/* Unfortunatly we couldnt find it upwards so find it till the right(downwards) */
			while (middle <= right && crc_32_needle == haystack[middle].crc_32) {
				if (!(strncmp(needle, haystack[middle].domain_name, strlen(haystack[middle].domain_name)))) {
					/* Found the Match */
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
					llog_write(L_DEBUG, "Both CRC: %lu and domain_name: %s\n", crc_32_needle, needle);
#endif
					return middle;
				}
				middle++;
			}
			/* if we reached here that means that the crc matched but the domain name did not match. Hope We NEVER REACH HERE!  */
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
			llog_write(L_DEBUG, "\nINFO: CRC matched but URL did not match\n");
#endif
			return -1;

		}
	}
#ifdef PMP_FLOOR_RULES_FUNCTIONAL_TESTING
	llog_write(L_DEBUG, "\nNot Found the CRC\n");
#endif
	return -1;
}

static int substring_binary_search(
                char* processing_string,
                publisher_site_top_level_domain_name_t** whitelist, 
                int left,
                int *right,
                const int is_sitecode_present,
		int *obj_index,
		const int is_app_store_url
                )
{
	int subdomain_levels = 0;
	int index = -1;
	int i, j;
	char subdomain_delimiter = '.';
	(*obj_index) = -1;
	char *temp_processing_string = processing_string;

	subdomain_levels = char_counter(processing_string, subdomain_delimiter);
#ifdef DEBUG
	llog_write(L_DEBUG, "\nTLD = %s, subdomain_levels = %d %s:%d\n", processing_string, subdomain_levels, __FILE__, __LINE__);
#endif

	// For sitecode, subdomain levels are not present(to take care of atleast one iteration)
	if(is_sitecode_present == 0) {
		subdomain_levels = subdomain_levels - 1;
	}

//App store URL is considered at high priority for crc32 check
//setting subdomain_levels to 0, complete app url match
	if (is_app_store_url == 1) {
			subdomain_levels = 0;
	}
	// for a.b.c.com, we want to search for a.b.c.com, b.c.com and c.com	
	for(j = 0; j < MAX_PUB_AGG_CACHE_OBJ ; j++) {
		   
	    if(whitelist[j] != NULL ) {
		
		processing_string = temp_processing_string;
		for (i=0; i<=subdomain_levels; i++) {
		    index = binary_search(processing_string, whitelist[j], left, right[j] - 1, is_sitecode_present, is_app_store_url);
		    if (index != -1 || i == subdomain_levels) {
			// We have found the domain or we have made all the searches 
			// obj_index stores the index of the object in object array for successful search
			(*obj_index) = j;
			break;
		    }
#ifdef DEBUG
				llog_write(L_DEBUG, "\nMatch didn't happen. Searching for parent TLD %s:%d\n", __FILE__, __LINE__);
#endif
				// Above ensures that strchr will never return NULL
				processing_string = strchr(processing_string, subdomain_delimiter);
				processing_string++;
			}
			// We can skip further searches as we have already found the domain
			if(index != -1) {
				break;
			}

		}

	}

#ifdef DEBUG
	llog_write(L_DEBUG,"\nIndex, before returning=%d\n",index);
#endif
	return index;


}

/* function accepts: : pub_id, site_id, domain_name, cache_handle, db_conn
 * returns: 0:domain found in whitelist/1:domain not found in whitelist*/
int top_level_domain_whitelist(
		long pub_id,
		long site_id,
		const char *domain_kadpageurl,
		const char *domain_pageurl,
		cache_handle_t* cache_handle,
		db_connection_t* kadserver_dbconn,
		ad_server_additional_params_t *additional_params,
		const int is_sitecode_present,
		const char *app_entity) {
	publisher_site_top_level_domain_name_t *publisher_site_top_level_domain_name[MAX_PUB_AGG_CACHE_OBJ] = {NULL};
	int retval = 0;
	int publisher_site_tld_whitelist_length[MAX_PUB_AGG_CACHE_OBJ] = {0};
	int index = -1;
	char processing_string[MAX_DOMAIN_NAME_LENGTH + 1];
	processing_string[0] = '\0';
	int len = 0;
	int i;
	int obj_index = -1;
	int is_app_store_url = -1;

	/*get the value from cache in "publisher_site_top_level_domain_name"*/
	/*function fetches crc32, tld, first 4 chars from cache*/
	retval = cache_get_publisher_site_tld_whitelist(pub_id,
			site_id,
			publisher_site_top_level_domain_name,
			cache_handle,
			kadserver_dbconn,
			publisher_site_tld_whitelist_length);

	if (retval != ADS_ERROR_SUCCESS) {
		//ignoring no data case
		if(retval != ADS_ERROR_NOTHING) {
			llog_write(L_DEBUG, "\nError in getting publisher_site_tld_whitelist pubid: %ld site_id: %ld", pub_id, site_id);
			return retval;
		}
	}
	/*NO data found for pub and site : Give impression to passback network*/
	do {
		if((publisher_site_tld_whitelist_length[0] == 0)||
				(NULL == publisher_site_top_level_domain_name[0])) {
#ifdef DEBUG
			llog_write(L_DEBUG,"\nNo Domain TLD's uploaded for pub_id:%ld site_id:%ld",pub_id, site_id);
			llog_write(L_DEBUG,"\nGot non-whitelisted TLD\nTLD ID=%d\tpassback flag=%d,retval=%d",
					additional_params->tld_id,additional_params->passback_flag,retval);
#endif
			index = -1;
			break;
		}
		if (app_entity != NULL && app_entity[0] != '\0') {
			is_app_store_url = 1;
			strncpy(processing_string, app_entity, MAX_DOMAIN_NAME_LENGTH);
			processing_string[MAX_DOMAIN_NAME_LENGTH] = '\0';
			index = substring_binary_search(processing_string, publisher_site_top_level_domain_name, 0, publisher_site_tld_whitelist_length,is_sitecode_present, &obj_index, is_app_store_url);
			if (-1 != index) {
				// We got it so not doing passback.
#ifdef DEBUG
				llog_write(L_DEBUG,"\nGot  whitelisted app_entity TLD ID=%s\n",app_entity);
#endif
				break;
			}
		}
		is_app_store_url = 0;
		if (domain_kadpageurl[0] != '\0') {
			strncpy(processing_string, domain_kadpageurl, MAX_DOMAIN_NAME_LENGTH);
			processing_string[MAX_DOMAIN_NAME_LENGTH] = '\0';
			len=strlen(processing_string);
			if (processing_string[len -1 ] == '/') {
				// Use Case :- www.google.com/
				processing_string[len - 1] = '\0';
				len = len - 1;
			}

			/*
			 * check if the domain is whitelisted in the
			 * list of tlds (for pub,site) otained
			 * from cache/db
			 */
			index = substring_binary_search(processing_string, publisher_site_top_level_domain_name, 0, publisher_site_tld_whitelist_length,is_sitecode_present, &obj_index, is_app_store_url);

			if (-1 != index){
#ifdef DEBUG
				llog_write(L_DEBUG,"\n****************Got WHITELISTED TLD from KADPAGEURL\nTLD ID=%d\tpassback flag =%d\tindex=%d",
						additional_params->tld_id, additional_params->passback_flag, index);
#endif
				break;
			}
		}
		if (domain_pageurl[0] != '\0') {
			strncpy(processing_string, domain_pageurl, MAX_DOMAIN_NAME_LENGTH);
			processing_string[MAX_DOMAIN_NAME_LENGTH] = '\0';
			len=strlen(processing_string);
			if (processing_string[len -1 ] == '/') {
				// Use Case :- www.google.com/
				processing_string[len - 1] = '\0';
				len = len - 1;
			}

			/*
			 * check if the domain is whitelisted in the
			 * list of tlds (for pub,site) otained
			 * from cache/db
			 */
			index = substring_binary_search(processing_string, publisher_site_top_level_domain_name, 0, publisher_site_tld_whitelist_length,is_sitecode_present, &obj_index, is_app_store_url);
			if (-1 != index) {
				/*domain not found in whitw listed tlds*/
#ifdef DEBUG
				llog_write(L_DEBUG,"\n****************Got WHITELISTED TLD from PAGEURL\nTLD ID=%d\tpassback flag =%d\tindex=%d",
						additional_params->tld_id, additional_params->passback_flag, index);
#endif
			}
		}

	}while(0);
	if (-1 != index) {
		additional_params->tld_id = publisher_site_top_level_domain_name[obj_index][index].top_level_domain_id;
		additional_params->passback_flag = NOT_DOING_PASSBACK;
		additional_params->application_profile_id = publisher_site_top_level_domain_name[obj_index][index].application_profile_id;
		additional_params->platform_id = publisher_site_top_level_domain_name[obj_index][index].platform_id;
	} else {
		additional_params->tld_id = 0;
		additional_params->passback_flag = PASSBACK_NON_WHITELISTED_URL;
#ifdef DEBUG
		llog_write(L_DEBUG,"\nGot non-whitelisted TLD from PAGEURL, TLD ID=%d \t passback flag =%d",
				additional_params->tld_id,additional_params->passback_flag);
#endif
	}
	for(i = 0; i < MAX_PUB_AGG_CACHE_OBJ; i++) {
		if(publisher_site_top_level_domain_name[i] != NULL) {
			memcached_release_object_reference((char**)&publisher_site_top_level_domain_name[i]);
		}
	}

	return retval;
}

static int filter_adv_domains(char *advertiser_domain,
		ad_server_req_param_t *in_req_params)
{
	int subdomain_count = 0;
	int i = 0;
	char *processing_string = NULL;
	void *id_found = NULL;

	subdomain_count = char_counter(advertiser_domain, SUBDOMAIN_DELIMITER);
	processing_string = advertiser_domain;

	for (i = 1; i <= subdomain_count; ++i){
		id_found = bsearch(processing_string, in_req_params->blk_adv_dom[0], in_req_params->blk_adv_dom_count, MAX_ADV_DOM_LEN + 1, compare_string);	
		if(NULL != id_found) {
#ifdef OTF_BLOCKLIST
			llog_write(L_DEBUG, "\nLPU found in OTF blocklist domains, lpu=%s %s:%d\n", advertiser_domain, __FILE__, __LINE__);
#endif
			return 1;
		}

		processing_string = strchr(processing_string, SUBDOMAIN_DELIMITER);
		processing_string++;
	}
	return 0;
}

int filter_advertiser_domain_category(db_connection_t* dbconn,
		cache_handle_t* cache_handle,
		const ad_server_additional_params_t* additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		libstat_counters_t* libstats,
		ad_server_req_param_t *in_req_params,
		rt_response_params_t* rt_response_params,
		int rt_request_count,
		int pub_id,
		int site_id
		)
{
	int idx, i = 0;
	char *processing_string_ptr = NULL;
	int len = 0;
	int domain_found = 0;
	void *id_found = NULL;
	long advertiser_id = 1,domain_id = 1;
	char iab_sub_cat_str[MAX_PUB_TO_IAB_CAT_MAPPING][MAX_IAB_CAT_LEN+1];
	int iab_sub_cat_int[MAX_PUB_TO_IAB_CAT_MAPPING];

	int *category_blocklist = NULL;
	long *advertiser_blocklist = NULL;
	int cat_blk_cnt = 0;
	int adv_blk_cnt = 0;

	int block_advt_info = additional_parameters->pubsite_default_settings.pass_n_block_advt_info_enabled;
	int block_uncategorized_advt = additional_parameters->pubsite_default_settings.filter_uncategorized_advertisers_enabled;

	for(idx = 0; idx < MAX_PUB_TO_IAB_CAT_MAPPING; idx++){
		iab_sub_cat_str[idx][0] = '\0';
		iab_sub_cat_int[idx] = 0;
	}

	/* Return if both the filters are off for this pub/site */
	if (!block_uncategorized_advt && !block_advt_info)
		return ADS_ERROR_SUCCESS;

	cache_get_pub_site_domain_category_blocklist(dbconn,
			cache_handle,
			&category_blocklist,
			&cat_blk_cnt,
			pub_id,
			site_id);

	cache_get_pub_site_domain_advertiser_blocklist(dbconn,
			cache_handle,
			&advertiser_blocklist,
			&adv_blk_cnt,
			pub_id,
			site_id);

	for (i=0; i < rt_request_count; i++) {
		if(1 == adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag) {
			continue;
		}

		processing_string_ptr = rt_response_params[i].bid_response_params.landing_page_tld;
		len = strlen(processing_string_ptr);
		if (0 == len){
			if ((block_uncategorized_advt) && (1 != rt_response_params[i].skip_UCAF)) {
				BLOCKLIST_DEBUG("\nCATEGORIZED_ADVERTISER_TRIE:: pub:%d site:%d:: No Landing Page in RTB Response,"
						" Filtering campaign_id:%u, %s:%d\n", pub_id, site_id,
						adcampaigns[rt_response_params[i].campaign_index].campaign_id, __FILE__, __LINE__);

				adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
				adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = UNCATEGORIZED_ADVERTISER_FILTER;

				if(additional_parameters->adserver_config_params->stats_collection_enable == 1) {
					increment_stats_counters(libstats, RTB_ADVERTISER_DOMAIN_FILTER_ID, adcampaigns[rt_response_params[i].campaign_index].campaign_id);
				}
			}
			continue;
		}
		if ('/' == processing_string_ptr[len-1]){
			/* Use Case :- 'www.google.com/' */
			processing_string_ptr[len-1] = '\0';
			len--;
		}

		id_found = NULL;

		/* call to khash to get advertiser/category details. */
		domain_found = get_acd_str_for_domain(processing_string_ptr,
				&advertiser_id,
				&domain_id,
				iab_sub_cat_str[0],
				iab_sub_cat_str[1],
				iab_sub_cat_str[2],
				iab_sub_cat_str[3],
				iab_sub_cat_str[4],
				iab_sub_cat_str[5],
				iab_sub_cat_int);

#ifdef DEBUG_BLOCKLIST
		/* Debug log for printing domain category info */
		if (domain_found) {
			DEBUG_LOG("\nCATEGORIZED_ADVERTISER::Domain:'%s' found in khash, pub:%d site:%d, domain_id:%ld, advertiser_id:%ld, IAM_cat_main:%s, IAB_cat_sub:%s IAB_cat_main_int:%d, IAB_cat_sub_int:%d",
					processing_string_ptr, pub_id, site_id, domain_id, advertiser_id, iab_sub_cat_str[1], iab_sub_cat_str[0], iab_sub_cat_int[1], iab_sub_cat_int[0]);
		} else {
			DEBUG_LOG("\nCATEGORIZED_ADVERTISER::Domain:'%s' not found in khash, pub:%d site:%d, skip_UCAF:%d",
					processing_string_ptr, pub_id, site_id, rt_response_params[i].skip_UCAF);
		}
#endif
		//Apply UnCategorized Advertiser Filter
		if (((0 == domain_found) || (0 == strcmp(iab_sub_cat_str[1], "IAB24")) || advertiser_id <= 1) &&
				(block_uncategorized_advt) &&
				(1 != rt_response_params[i].skip_UCAF)) {
			// domain not found in the domain whitelist
			BLOCKLIST_DEBUG("\nCATEGORIZED_ADVERTISER:: pub:%d site:%d:: No match for %s %s:%d\n",
					pub_id, site_id, processing_string_ptr, __FILE__, __LINE__);
			adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
			adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = UNCATEGORIZED_ADVERTISER_FILTER;

			LOG_WARNING(FILTER_ADV_DOM,MOD_DEFAULT,
					processing_string_ptr,
					adcampaigns[rt_response_params[i].campaign_index].campaign_id,
					pub_id,
					site_id,
					rt_response_params[i].bid_response_params.request_id);

			if(1 == additional_parameters->adserver_config_params->stats_collection_enable) {
				increment_stats_counters(libstats, RTB_ADVERTISER_DOMAIN_FILTER_ID, adcampaigns[rt_response_params[i].campaign_index].campaign_id);
			}
		}
		/* Apply Advertiser Info Filter */
		else if (block_advt_info) {
			if (0 != domain_found) {
				/* Check if domain_id is present in blocked domain_id list */
				if((1 != domain_id) && (in_req_params->blk_domain_id_count > 0)){
					id_found = bsearch(&domain_id, in_req_params->blk_domain_id,
							in_req_params->blk_domain_id_count, sizeof(long), compare_long);
					if(NULL != id_found) {
						DEBUG_LOG("CATEGORIZED_ADVERTISER::pub:%d site:%d:: domain_id:%ld found in Req blocklist", pub_id, site_id, domain_id);
						goto SET_FILTER_STATUS;
					}
				}

				/* Check if advertiser_id is present in blocked advertiser_id list */
				if(1 != advertiser_id){
					/* Check against list received in Ad request */
					if(in_req_params->blk_advt_id_count > 0){
						id_found = bsearch(&advertiser_id, in_req_params->blk_advt_id,
								in_req_params->blk_advt_id_count, sizeof(long), compare_long);
						if(NULL != id_found) {
							DEBUG_LOG("CATEGORIZED_ADVERTISER::pub:%d site:%d:: advertiser_id:%ld found in Req blocklist", pub_id, site_id, advertiser_id);
							goto SET_FILTER_STATUS;
						}
					}

					/* Check against list configured in DB */
					if(NULL != advertiser_blocklist){
						id_found = bsearch(&advertiser_id, advertiser_blocklist,
								adv_blk_cnt, sizeof(long), compare_long);
						if(NULL != id_found) {
							DEBUG_LOG("CATEGORIZED_ADVERTISER::pub:%d site:%d:: advertiser_id:%ld found in DB blocklist", pub_id, site_id, advertiser_id);
							goto SET_FILTER_STATUS;
						}
					}
				}

				/* Check if iab_cat_id is present in blocked iab_cat_id list */
				for(idx = 0; idx < MAX_PUB_TO_IAB_CAT_MAPPING; idx++){
					/* Check against list received in Ad request */
					if((in_req_params->blk_cat_id_count > 0) && (0 != iab_sub_cat_str[idx][0])){
						id_found = bsearch(iab_sub_cat_str[idx], in_req_params->blk_cat_id[0],
								in_req_params->blk_cat_id_count, MAX_IAB_CAT_LEN+1, compare_string);
						if(NULL != id_found) {
							DEBUG_LOG("CATEGORIZED_ADVERTISER::pub:%d site:%d:: category:'%s' found in req blocklist", pub_id, site_id, iab_sub_cat_str[idx]);
							goto SET_FILTER_STATUS;
						}
					}
					/* Check against list configured in DB */
					if((NULL != category_blocklist) && (0 != iab_sub_cat_int[idx])){
						id_found = bsearch(&iab_sub_cat_int[idx], category_blocklist,
								cat_blk_cnt, sizeof(int), compare_int);
						if(NULL != id_found) {
							DEBUG_LOG("CATEGORIZED_ADVERTISER::pub:%d site:%d:: category:%d found in DB blocklist", pub_id, site_id, iab_sub_cat_int[idx]);
							goto SET_FILTER_STATUS;
						}
					}
				}
			}

			/* blocking advertiser domain tlds */
			if(in_req_params->blk_adv_dom_count > 0){
				domain_found = filter_adv_domains(processing_string_ptr, in_req_params);
				if(1 == domain_found){
#ifdef OTF_BLOCKLIST
					llog_write(L_DEBUG, "\nBlocked due to OTF Blocklist lpu : %s %s:%d\n",
							processing_string_ptr, __FILE__, __LINE__);
#endif
					goto SET_FILTER_STATUS;
				}
			}
		}

		//skip the filter & continue with next campaign
		continue;

SET_FILTER_STATUS:
		adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1;
		adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = FILTER_ADVT_DOMAIN_CATEGORY_ID;
		LOG_WARNING(FILTER_ACD_IDS,MOD_FILTER,
				processing_string_ptr,
				adcampaigns[rt_response_params[i].campaign_index].campaign_id,
				pub_id,
				site_id,
				rt_response_params[i].bid_response_params.request_id);
	}

	if(NULL != category_blocklist){
		memcached_release_object_reference((char**)&category_blocklist);
	}
	if(NULL != advertiser_blocklist){
		memcached_release_object_reference((char**)&advertiser_blocklist);
	}
	return ADS_ERROR_SUCCESS;
}

#define BLOCK_BUYER(buyer_blocklist, filtering_reason, block_level) \
		if(NULL != buyer_blocklist && buyer_blocklist->n_elements > 0 && NULL != buyer_blocklist->buyers){ \
			void *buyerid_found = NULL; \
			buyerid_found = bsearch(&rt_response_params[i].bid_response_params.pubmatic_dsp_buyer_id, \
					buyer_blocklist->buyers, \
					buyer_blocklist->n_elements, \
					sizeof(int), \
					compare_int); \
			if(NULL != buyerid_found) { \
				DEBUG_LOG("BUYER_BLOCKLIST::pub:%ld, camp_id:%d, buyer_id:%d found in %s", pub_id, adcampaigns[rt_response_params[i].campaign_index].campaign_id, rt_response_params[i].bid_response_params.pubmatic_dsp_buyer_id, block_level); \
				adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag = 1; \
				adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->reason_for_filtering = filtering_reason; \
				continue; \
			} \
		}


int apply_buyer_blocklist(db_connection_t* dbconn,
		cache_handle_t* cache_handle,
		const fte_additional_params_t *fte_additional_parameters,
		publisher_site_ad_campaign_list_t* adcampaigns,
		rt_response_params_t* rt_response_params,
		int rt_response_count,
		long pub_id) {

	int i, is_pub_channel_partner = 0;

	/* Read/refer global blocklists for blocking buyer_ids */
	buyer_block_list_t *global_buyer_blocklist = g_global_buyer_blocklist[g_cur_global_buyer_blocklist_idx];
	buyer_block_list_t *channel_partner_buyer_blocklist = g_channel_partner_buyer_blocklist[g_cur_channel_partner_buyer_blocklist_idx];
	buyer_block_list_t *pub_buyer_blocklist = NULL;

	/* Decide if publisher is channel partner */
	if (1 == fte_additional_parameters->publisher_level_settings.is_aggregator &&
			1 == fte_additional_parameters->publisher_level_settings.acl_aggregator_flag) {
		is_pub_channel_partner = 1;
		DEBUG_LOG("BUYER_BLOCKLIST::pub:%ld is channel partner", pub_id);
	}

	/* Read pub level buyer blocklist */
	cache_get_buyer_blocklist(dbconn, cache_handle, &pub_buyer_blocklist, pub_id);

	for (i=0; i < rt_response_count; i++) {
		/* Skip already filtered campaigns */
		if(1 == adcampaigns[rt_response_params[i].campaign_index].ad_campaign_list_setings->filtered_flag) {
			continue;
		}

		/* Apply global buyer blocklist */
		BLOCK_BUYER(global_buyer_blocklist, GLOBAL_BUYER_BLOCKLIST_FILTER, "Global Buyer Blocklist")

		/* Apply channel partner buyer blocklist */
		if(1 == is_pub_channel_partner) {
			BLOCK_BUYER(channel_partner_buyer_blocklist, CHANNEL_PARTNER_BUYER_BLOCKLIST_FILTER, "Channel Partner Buyer Blocklist")
		}

		/* Apply pub level buyer blocklist */
		BLOCK_BUYER(pub_buyer_blocklist, PUB_LEVEL_BUYER_BLOCKLIST_FILTER, "Pub Level Buyer Blocklist")

		/* Control reaches here when buyer_id not found in any blocklist */
		DEBUG_LOG("NOT_FOUND:BUYER_BLOCKLIST::pub:%ld, camp_id:%d, buyer_id:%d not found in any list", pub_id, adcampaigns[rt_response_params[i].campaign_index].campaign_id, rt_response_params[i].bid_response_params.pubmatic_dsp_buyer_id);
	}

	if (NULL != pub_buyer_blocklist) {
		if (NULL != pub_buyer_blocklist->buyers) {
			memcached_release_object_reference((char**)&(pub_buyer_blocklist->buyers));
		}
		memcached_release_object_reference((char**)&pub_buyer_blocklist);
	}

	return ADS_ERROR_SUCCESS;
}
