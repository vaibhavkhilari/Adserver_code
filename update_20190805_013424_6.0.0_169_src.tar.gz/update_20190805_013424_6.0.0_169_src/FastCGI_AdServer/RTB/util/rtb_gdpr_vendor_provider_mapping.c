/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include "rtb_gdpr_vendor_provider_mapping.h"
#include "gdpr_compliance.h"
#include "gdpr_consent_parser.h"

#define ARR_END_STRING      "]"

/* GDPR IAB vendorIds to EB providerIds mapping */
extern gdpr_vendor_provider_mapping_t *g_gdpr_vendor_provider_map[2];
extern unsigned int g_cur_ref_vendor_provider_map;

int append_static_provider_list_to_cplist(
		gdpr_vendor_provider_mapping_t *vendor_provider_map,
		ad_server_req_param_t *in_req_params) {

	int static_written = 0, trans_written = 0, idx, overflow_flag = 0;

	/* Copy incoming request cplist into dynamic cplist, for logging purpose */
	if ('\0' != in_req_params->eb_cp_list_int[0]) {
		snprintf(in_req_params->dynamic_eb_cp_list_int,
				MAX_CP_LIST_STRING_PARAM_LEN + 1,
				"%s",
				in_req_params->eb_cp_list_int);
	}

	/* Copy incoming request cplist into translated cplist, we will append static cplist to it */
	if ('\0' != in_req_params->eb_cp_list_str[0]) {
		trans_written += snprintf(in_req_params->translated_eb_cp_list_str + trans_written,
				MAX_CP_LIST_STRING_PARAM_LEN - trans_written,
				"%s",
				in_req_params->eb_cp_list_str);

		/* Remove ] from cplist, we will add it after appending static provider list */
		if (']' == in_req_params->translated_eb_cp_list_str[trans_written - 1]) {
			in_req_params->translated_eb_cp_list_str[trans_written - 1] = '\0';
			trans_written--;
		}
	}

	for (idx = 0; idx < vendor_provider_map->nelements; idx++) {
		/* If the vendor_id is set to -1, this providerId to be added by default(static list) */
		if (-1 == vendor_provider_map->vp_map[idx].iab_vendor_id) {
			/* Prepare static provider list(Integers) which will be used for logging */
			static_written += snprintf(in_req_params->static_eb_cp_list_int + static_written,
					MAX_CP_LIST_STRING_PARAM_LEN - static_written,
					(static_written == 0 ? "[%d" : ",%d"),
					vendor_provider_map->vp_map[idx].eb_provider_id);
			if ((MAX_CP_LIST_STRING_PARAM_LEN - 3) <= static_written) {
				overflow_flag = 1;
				break;
			}
			DEBUG_LOG("Google GDPR:EB_PROVIDER_LIST:Adding providerId[%d] by default",
					vendor_provider_map->vp_map[idx].eb_provider_id);

			/* Check is consent given for this providerID */
			gdpr_consent_status_t consent_status = GDPR_CONSENT_NOT_GIVEN;
			consent_status = check_eb_consented_provider_list(in_req_params->gdpr_req_params.eb_cp_list,
					in_req_params->gdpr_req_params.eb_cp_count,
					vendor_provider_map->vp_map[idx].eb_provider_id);

			if (GDPR_CONSENT_NOT_GIVEN == consent_status) {
				/* Append this providerID to translated provider list(Strings) which will be used in RTB requests */
				trans_written += snprintf(in_req_params->translated_eb_cp_list_str + trans_written,
						MAX_CP_LIST_STRING_PARAM_LEN - trans_written,
						(trans_written == 0 ? "[\"%d\"" : ",\"%d\""),
						vendor_provider_map->vp_map[idx].eb_provider_id);
				if ((MAX_CP_LIST_STRING_PARAM_LEN - 3) <= trans_written) {
					overflow_flag = 1;
					break;
				}
				DEBUG_LOG("Google GDPR:EB_PROVIDER_LIST:Adding providerId[%d]",
						vendor_provider_map->vp_map[idx].eb_provider_id);
			}
		}
	}

	/* If buffer overflow has happened, we need to truncate all lists and return error */
	if (1 == overflow_flag) {
		GDPR_LOG_ERROR("eb_cp_list buffer overflow happened, clearing it");
		in_req_params->static_eb_cp_list_int[0] = '\0';
		in_req_params->dynamic_eb_cp_list_int[0] = '\0';
		in_req_params->translated_eb_cp_list_str[0] = '\0';
		return ADS_ERROR_INTERNAL;
	}

	/* End the providerId list with ]. No need to do buffer overflow check, we had already considered space for this 1 byte */
	if (0 != static_written) {
		snprintf(in_req_params->static_eb_cp_list_int + static_written, MAX_CP_LIST_STRING_PARAM_LEN - static_written, ARR_END_STRING);
	}
	if (0 != trans_written) {
		snprintf(in_req_params->translated_eb_cp_list_str + trans_written, MAX_CP_LIST_STRING_PARAM_LEN - trans_written, ARR_END_STRING);
	}

	return ADS_ERROR_SUCCESS;

}

int translate_consent_str_to_provider_list(
		gdpr_vendor_provider_mapping_t *vendor_provider_map,
		ad_server_req_param_t *in_req_params,
		fte_additional_params_t *fte_additional_parameters) {

	int static_written = 0, dyn_written = 0, trans_written = 0, idx, overflow_flag = 0;
	for (idx = 0; idx < vendor_provider_map->nelements; idx++) {
		/* If the vendor_id is set to -1, this providerId to be added by default(static list) */
		if (-1 == vendor_provider_map->vp_map[idx].iab_vendor_id) {
			/* Prepare static provider list(Integers) which will be used in logging */
			static_written += snprintf(in_req_params->static_eb_cp_list_int + static_written,
					MAX_CP_LIST_STRING_PARAM_LEN - static_written,
					(static_written == 0 ? "[%d" : ",%d"),
					vendor_provider_map->vp_map[idx].eb_provider_id);
			if ((MAX_CP_LIST_STRING_PARAM_LEN - 3) <= static_written) {
				overflow_flag = 1;
				break;
			}
			/* Prepare translated provider list(Strings) which will be used in RTB requests */
			trans_written += snprintf(in_req_params->translated_eb_cp_list_str + trans_written,
					MAX_CP_LIST_STRING_PARAM_LEN - trans_written,
					(trans_written == 0 ? "[\"%d\"" : ",\"%d\""),
					vendor_provider_map->vp_map[idx].eb_provider_id);
			if ((MAX_CP_LIST_STRING_PARAM_LEN - 3) <= trans_written) {
				overflow_flag = 1;
				break;
			}
			DEBUG_LOG("IAB GDPR:EB_PROVIDER_LIST:Adding providerId[%d] by default, vendorId is [%d] and PurposeId is [%d]",
					vendor_provider_map->vp_map[idx].eb_provider_id,
					vendor_provider_map->vp_map[idx].iab_vendor_id,
					vendor_provider_map->vp_map[idx].purpose_id_list);
		} else { /* We need to check consent for this vendor and then include providerId in list */
			gdpr_consent_status_t consent_status = GDPR_CONSENT_NOT_GIVEN;
			consent_status = check_consent_for_vendor(
					(const gdpr_consent_object_t *)&(fte_additional_parameters->parsed_consent_obj),
					vendor_provider_map->vp_map[idx].iab_vendor_id,
					vendor_provider_map->vp_map[idx].purpose_id_list);

			if (GDPR_CONSENT_GIVEN == consent_status) {
				/* Prepare dynamic provider list(Integers) which will be used in logging */
				dyn_written += snprintf(in_req_params->dynamic_eb_cp_list_int + dyn_written,
						MAX_CP_LIST_STRING_PARAM_LEN - dyn_written,
						(dyn_written == 0 ? "[%d" : ",%d"),
						vendor_provider_map->vp_map[idx].eb_provider_id);
				if ((MAX_CP_LIST_STRING_PARAM_LEN - 3) <= dyn_written) {
					overflow_flag = 1;
					break;
				}
				/* Prepare translated provider list(Strings) which will be used in RTB requests */
				trans_written += snprintf(in_req_params->translated_eb_cp_list_str + trans_written,
						MAX_CP_LIST_STRING_PARAM_LEN - trans_written,
						(trans_written == 0 ? "[\"%d\"" : ",\"%d\""),
						vendor_provider_map->vp_map[idx].eb_provider_id);
				if ((MAX_CP_LIST_STRING_PARAM_LEN - 3) <= trans_written) {
					overflow_flag = 1;
					break;
				}
				DEBUG_LOG("IAB GDPR:EB_PROVIDER_LIST:Adding providerId[%d] as consent found for vendorId[%d] and PurposeId[%d]",
						vendor_provider_map->vp_map[idx].eb_provider_id,
						vendor_provider_map->vp_map[idx].iab_vendor_id,
						vendor_provider_map->vp_map[idx].purpose_id_list);
			}
		}
	}

	/* If buffer overflow has happened, we need to truncate all lists and return error */
	if (1 == overflow_flag) {
		GDPR_LOG_ERROR("eb_cp_list buffer overflow happened, clearing it");
		in_req_params->static_eb_cp_list_int[0] = '\0';
		in_req_params->dynamic_eb_cp_list_int[0] = '\0';
		in_req_params->translated_eb_cp_list_str[0] = '\0';
		return ADS_ERROR_INTERNAL;
	}

	/* End the providerId list with ]. No need to do buffer overflow check, we had already considered space for this 1 byte */
	if (0 != static_written) {
		snprintf(in_req_params->static_eb_cp_list_int + static_written, MAX_CP_LIST_STRING_PARAM_LEN - static_written, ARR_END_STRING);
	}
	if (0 != dyn_written) {
		snprintf(in_req_params->dynamic_eb_cp_list_int + dyn_written, MAX_CP_LIST_STRING_PARAM_LEN - dyn_written, ARR_END_STRING);
	}
	if (0 != trans_written) {
		snprintf(in_req_params->translated_eb_cp_list_str + trans_written, MAX_CP_LIST_STRING_PARAM_LEN - trans_written, ARR_END_STRING);
	}

	return ADS_ERROR_SUCCESS;
}

int prepare_translated_eb_provider_id_list(
		ad_server_req_param_t *in_req_params,
		fte_additional_params_t *fte_additional_parameters) {

	if ('\0' != in_req_params->translated_eb_cp_list_str[0]) {
		DEBUG_LOG("Translated EB ProviderId list is already prepared for this impression. Hence skipping...");
		return ADS_ERROR_SUCCESS;
	}

	gdpr_vendor_provider_mapping_t *vendor_provider_map = g_gdpr_vendor_provider_map[g_cur_ref_vendor_provider_map];
	if (NULL == vendor_provider_map) {
		ERROR_LOG("gdpr vendor_provider_mapping table is empty.");
		return ADS_ERROR_SUCCESS;
	}

	if (GDPR_PROTO_IAB == in_req_params->gdpr_req_params.gdpr_protocol) {
		return translate_consent_str_to_provider_list(vendor_provider_map, in_req_params, fte_additional_parameters);
	} else if (GDPR_PROTO_GOOGLE_EB == in_req_params->gdpr_req_params.gdpr_protocol) {
		return append_static_provider_list_to_cplist(vendor_provider_map, in_req_params);
	}

	return ADS_ERROR_SUCCESS;
}

