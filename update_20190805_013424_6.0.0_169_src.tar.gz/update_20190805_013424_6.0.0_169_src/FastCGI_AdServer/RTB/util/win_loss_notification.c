/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <error.h>
#include <string.h>
#include "ad_server_types.h"
#include "rt_types.h"
#include "rtb_util.h"
#include "win_loss_notification.h"
#include "string_util.h"

#undef APPEND_STRING
#define APPEND_STRING(campaign_info, bytes_written, char_ptr, space_left, format, ...)         \
        do { \
                bytes_written = snprintf(char_ptr, space_left, format, ##__VA_ARGS__);          				  \
                if (bytes_written >= space_left) {                                                                                 \
                        llog_write(L_DEBUG, "\nWLN ERROR buffer overflow while creating win-loss info str %s:%d\n", __FILE__, __LINE__);   \
                        campaign_info->bids_set = 0;								  \
                        return 0;                                                                                		 \
                }       \
                space_left -= bytes_written;                                                                                            \
                char_ptr += bytes_written; \
        } while(0);

/*Fuction to free hash table*/
int free_winloss_hash_table(hash_table_t *hash_table) {
        //Free existing hash table
        campaign_info_t *campaign_info = hash_table->campaign_info;
        if ( campaign_info != NULL ) {
                free(campaign_info);
                campaign_info = NULL;
        }
	hash_table->campaign_info = NULL;
	WLN_DEBUGLOG("Hash Table freed");
	return WLN_SUCCESS;
}

/* Function to initialize realtime win-loss hash table */
int init_winloss_hash_table(hash_table_t *hash_table) {
	campaign_info_t *campaign_info = NULL;
	campaign_info = (campaign_info_t *)malloc(sizeof(campaign_info_t)*INITIAL_HASH_TABLE_LEN);
	if ( campaign_info == NULL ) {
		WLN_ERRORLOG("Malloc Failed");
		return WLN_NO_MEMORY;
	}
 	hash_table->hash_table_size = INITIAL_HASH_TABLE_LEN;
	hash_table->no_of_campaigns = 0;	
	memset(campaign_info, 0, sizeof(campaign_info_t)*(hash_table->hash_table_size));
 	hash_table->campaign_info = campaign_info;
	WLN_DEBUGLOG("Hash Table Initialised. Size %d",hash_table->hash_table_size);
	return WLN_SUCCESS;
}

/* Fuction to expand realtime win-loss hash table if its full or almost full */
int expand_winloss_hash_table(hash_table_t *hash_table) {
	campaign_info_t *campaign_info = NULL;
	//First free existing table
	free_winloss_hash_table(hash_table);
	//Malloc hash table with extended size
	campaign_info = (campaign_info_t *) malloc(sizeof(campaign_info_t)*((int)(hash_table->hash_table_size * HASH_TABLE_REALLOC_FACTOR)));
	if ( campaign_info == NULL ) {
		WLN_ERRORLOG("Malloc Failed");
		return WLN_NO_MEMORY;
	}
 	hash_table->hash_table_size = (int)(hash_table->hash_table_size * HASH_TABLE_REALLOC_FACTOR);
	hash_table->no_of_campaigns = 0;	
	memset(campaign_info, 0, sizeof(campaign_info_t)*(hash_table->hash_table_size));
 	hash_table->campaign_info = campaign_info;
	WLN_DEBUGLOG("Hash Table Expanded. New size %d",hash_table->hash_table_size);
	return WLN_SUCCESS;
}

/* Function to return hash index from key */
static int get_hash(int camp_id, int max_limit) {
	return camp_id % max_limit; 
}

/*Function to return address of campaign_info structure of given campaign from the hash table*/
static campaign_info_t * get_campaign_info(const hash_table_t *hash_table, int camp_id) {
	campaign_info_t *campaign_info = hash_table->campaign_info;
	int end = hash_table->hash_table_size;
	const int hash_key = get_hash(camp_id, hash_table->hash_table_size);	//Get hash key from campaign id
	int campaign_index = hash_key; 						//Index of this campaign in camp array

	if ( hash_key < 0 || hash_key >= hash_table->hash_table_size ) {
		WLN_ERRORLOG("Invalid hash-key:%d obtained for campaign id:%d", hash_key, camp_id);
		return NULL;
	}
       
	if ( campaign_info == NULL ) {	//Very unlikely
		WLN_ERRORLOG("Winloss hash table found NULL");
		return NULL;
	}
 
	if ( campaign_info[campaign_index].campaign_id == 0 ) {		//Empty Location
		WLN_DEBUGLOG("Campaign %d not found in hash table",camp_id);
		return NULL;
	}
	if ( campaign_info[campaign_index].campaign_id != camp_id ) {
		WLN_DEBUGLOG("Collision occured!!!");
		//Start linear probing
		for ( ; campaign_index < end; campaign_index++ ) {
			if ( campaign_info[campaign_index].campaign_id == camp_id ) {
				WLN_DEBUGLOG("Campaign found in bucket %d", campaign_index);
				break;
			}
		}
		//Reached end.. start from top
		if ( campaign_index == end ) {
			WLN_DEBUGLOG("Starting from top");
			for ( campaign_index = 0; campaign_index < hash_key; campaign_index++ ) {
				if ( campaign_info[campaign_index].campaign_id == camp_id ) {
					WLN_DEBUGLOG("Campaign found in bucket %d", campaign_index);
					break;
				}
			}
		}
		if ( campaign_index == hash_key ) {
			WLN_DEBUGLOG("Hash table is full..Campaign %d not found in hash table",camp_id);
			return NULL;
		}
	}
	//Reached here means found bucket
	return &campaign_info[campaign_index];
}

/*
 * Function to write win-loss info JSON for given campaign
 * Clears campaign's data from hash table
 * Returns number of bytes written
 * Takes parameters as dest string, max len, campaign id and hash table
 * NOTE: Pointer dest is passed by value and hence wont get incremented here, plus dest will not be '\0' terminated
 */
int get_winloss_info_str(char *dest, int max_len, int camp_id, const hash_table_t *hash_table) {
	char *post_temp_ptr = NULL;
	int bytes_written = 0, space_left = max_len, bids_set = 0, bid_index = 0;
	campaign_info_t *campaign_info = get_campaign_info(hash_table, camp_id);    //get campaign info struct from hash table
	if ( campaign_info == NULL ) {
		WLN_DEBUGLOG("No data found in hash table for campaign %d", camp_id);
		return bytes_written;
	}
	bids_set = campaign_info->bids_set;

	if ( bids_set <= 0 || bids_set > MAX_BIDS_LIMIT ) {
		WLN_DEBUGLOG("No data found in hash table for campaign %d", camp_id);
		return bytes_written;
	}
	post_temp_ptr = dest;

	APPEND_STRING( campaign_info, bytes_written, post_temp_ptr, space_left, "%s:{%s:\"%s\",%s:\"%s\",%s:%g,%s:%d,%s:[",
									WLN_NOTIFICATION_STR,
									WLN_REQUEST_ID, campaign_info->request_id, 
									WLN_BID_CURRENCY, campaign_info->bid_currency_code, 
									WLN_WINNING_BID, campaign_info->winning_bid, 
									WLN_CLIENT_ACTION_CHECK, campaign_info->client_auction_enabled,
									WLN_BID_INFO_STR );


	for ( bid_index = 0; bid_index < bids_set; bid_index++ ) {
		APPEND_STRING(campaign_info, bytes_written, post_temp_ptr, space_left, "{%s:\"%s\",%s:%d},", 
										WLN_BID_ID, campaign_info->bid_id[bid_index], 
										WLN_STATUS, campaign_info->reasons[bid_index]);
	}
	//remove last comma
	post_temp_ptr--;
	//close array and json
	APPEND_STRING(campaign_info, bytes_written, post_temp_ptr, space_left, "]}");

	//Now that the data has been consumed, clear all the data
	campaign_info->bids_set = 0;

	bytes_written=(post_temp_ptr)-(dest);
	WLN_DEBUGLOG("Win loss json size:%d",bytes_written);
	return bytes_written;
}

/* Function to add given campaigns info into hash table */
static int add_campaign_info( hash_table_t *hash_table, int camp_id, const char *request_id, int reason_for_filtering, 
			const char* bid_id, double winning_bid, int client_auction_enabled, const char* bid_currency_code) {

	campaign_info_t *campaign_info = hash_table->campaign_info;
	int end = hash_table->hash_table_size;
	int bid_index = 0;							//Index of next empty bid location (i.e number of bids set)
	const int hash_key = get_hash(camp_id, hash_table->hash_table_size);	//Get hash key from campaign id
	int campaign_index = hash_key; 						//Index of this campaigns in camp array
 
	if ( hash_key < 0 || hash_key >= hash_table->hash_table_size ) {
		WLN_ERRORLOG("Invalid hash-key:%d obtained for campaign id:%d", hash_key, camp_id);
		return WLN_INVALID_HASHKEY;
	}

	if ( campaign_info == NULL ) {	//Very unlikely
		WLN_ERRORLOG("Winloss hash table found NULL");
		return WLN_ERROR;
	}

	if ( campaign_info[campaign_index].campaign_id == 0 ) {		//Empty Location
		hash_table->no_of_campaigns++;				//Increase campaign count
		campaign_info[campaign_index].campaign_id = camp_id;	//Mark Postion occupied
	}
	else if ( campaign_info[campaign_index].campaign_id != camp_id ) {	//Collision
		WLN_DEBUGLOG("Collision occured for campaign %d, hash key %d",camp_id,hash_key);
		//Start linear probing
		for ( ; campaign_index < end; campaign_index++ ) {
		//Search for same Campaign id or empty location
			if ( campaign_info[campaign_index].campaign_id == camp_id ) { 
				WLN_DEBUGLOG("Found Campaign bucket at %d index",campaign_index);
				break;
			} else if ( campaign_info[campaign_index].campaign_id == 0 ) {
				WLN_DEBUGLOG("Found empty bucket at %d index.. occupying it",campaign_index);
				hash_table->no_of_campaigns++;		//Mark Postion occupied	
 				campaign_info[campaign_index].campaign_id = camp_id;
				break;
			}
   		}
		//Reached end.. start from top
		if ( campaign_index == end ) {
			WLN_DEBUGLOG("Reached end of hash table..Starting from top");
			for ( campaign_index = 0; campaign_index < hash_key; campaign_index++ ) {
				if ( campaign_info[campaign_index].campaign_id == camp_id ) { 
					WLN_DEBUGLOG("Found Campaign bucket at %d index",campaign_index);
					break;
				} else if ( campaign_info[campaign_index].campaign_id == 0 ) {
					WLN_DEBUGLOG("Found empty bucket at %d index.. occupying it",campaign_index);
					hash_table->no_of_campaigns++;		//Mark Postion occupied	
 					campaign_info[campaign_index].campaign_id = camp_id;
					break;
				}
 			}
		}
		if ( campaign_index == hash_key ) {
 			WLN_DEBUGLOG("HASH TABLE IS FULL!!!");
			return WLN_HASH_TABLE_FULL;
 		}
	}
	//Reached here means found bucket
	bid_index = campaign_info[campaign_index].bids_set;	//get index of next empty bid location (i.e. number of bids set)
	if ( bid_index == MAX_BIDS_LIMIT ) {
		WLN_DEBUGLOG("Bids capacity reached for campaign %d", campaign_info[campaign_index].campaign_id);
		return WLN_BIDS_OVERFLOW;
	}
	nstrcpy( campaign_info[campaign_index].bid_id[bid_index] , bid_id, MAX_TRANSACTION_ID_SIZE );
	campaign_info[campaign_index].reasons[bid_index] = reason_for_filtering;
	campaign_info[campaign_index].bids_set++;
	
	if ( bid_index == 0) {			//In case of multibid, copy common information only once
		nstrcpy( campaign_info[campaign_index].request_id, request_id, MAX_UNIQUE_ID_LEN);
		nstrcpy( campaign_info[campaign_index].bid_currency_code, bid_currency_code, MAX_CURRENCY_CODE_SIZE);
		campaign_info[campaign_index].winning_bid = winning_bid;
		campaign_info[campaign_index].client_auction_enabled = client_auction_enabled;
	}
	return WLN_SUCCESS;
}

/* Function to return mapped winloss reason for filtering from adserver reason for filtering */
static int get_winloss_reason_for_filtering( int adserver_reason_for_filtering ) { 
	
	int winloss_reason_for_filtering = WLN_UNFILTERED;
	switch ( adserver_reason_for_filtering ) {
		case FILTER_TIMED_OUT: 
					winloss_reason_for_filtering = WLN_TIMEOUT;
					break;

		case RTB_INCOMPLETE_RESPONSE_FILTER:
					winloss_reason_for_filtering = WLN_INCOMPLETE_RESPONSE;
					break;

		case FILTER_ABNORMAL_ECPM:
					winloss_reason_for_filtering =  WLN_INVALID_BID;
					break;

		case FILTER_LOW_BID:	
					winloss_reason_for_filtering = WLN_OUTBID;
					break;

		case LANDING_PAGE_FILTER:
		case DEAL_WHITE_LIST_FILTER:
		case DSP_BLOCKLIST_FILTER:
		case UNCATEGORIZED_ADVERTISER_FILTER: 
					winloss_reason_for_filtering = WLN_ADV_DOMAIN_BLOCKED;	
					break;

		case FILTER_BIDS_WITHOUT_LANDING_PAGE_URL:
					winloss_reason_for_filtering = WLN_ADV_DOMAIN_MISSING;
					break;

		case FILTER_CREATIVE_ID_NOT_AVAILABLE:
					winloss_reason_for_filtering = WLN_MISSING_CREATIVE_ID;
					break;	
	
		case FILTER_CREATIVE_ID_BLOCKED:
		case FILTER_RM_CREATIVE_ATTR_BLOCKED:	
		case FILTER_RM_CRTYPE_BLOCKED:
		case FILTER_RM_BLOCKLIST_STRICT_CHECK:
					winloss_reason_for_filtering = WLN_CREATIVE_FILTER;
					break;

		case FILTER_BID_PRICE_DECRYPTION_FAILURE:
					winloss_reason_for_filtering = WLN_BID_DECRYPTION_FAILED;
					break;

		case USER_LEVEL_FLOOR_FILTER:
		case PMP_FLOOR_FILTER:
		case F1_FILTER:
					winloss_reason_for_filtering = WLN_FLOOR_FILTER;
					break;

		case FILTER_REQUEST_ID_MISMATCH:
					winloss_reason_for_filtering = WLN_REQUEST_ID_MISMATCH;
					break;

		case FILTER_UNSECURE_CAMPAIGN:
		case FILTER_TYPE_UNSECURE_RESPONSE:
					winloss_reason_for_filtering = WLN_UNSECURE_CREATIVE;
					break;

		case FILTER_INVALID_CURRENCY_CODE:
					winloss_reason_for_filtering = WLN_INVALID_CURRENCY_CODE;
					break;

		case FILTER_MAX_CREATIVE_SIZE:
					winloss_reason_for_filtering = WLN_MAX_CREATIVE_SIZE;
					break;
		
		case FILTER_ADVT_DOMAIN_CATEGORY_ID:
					winloss_reason_for_filtering = WLN_ACD_FILTER;
					break;

		case FILTER_ZERO_BID:
					winloss_reason_for_filtering = WLN_ZERO_BID;
					break;
	}
	if ( winloss_reason_for_filtering == WLN_UNFILTERED) {
		WLN_DEBUGLOG("Campaign is unfiltered")
	}
	return winloss_reason_for_filtering;
}

/* Function to return bid of winning campaign or network */
static double get_winning_bid( 
		const fte_additional_params_t *fte_additional_parameters,
		const int selected_campaign,
		const selected_campaign_attribute_t* selected_camp,
		const double bidding_ecpm
	) {
		(void) fte_additional_parameters;
		double winning_bid = -1.0;
		if ( selected_campaign >= 0) {	//A campaign has won
			winning_bid =  selected_camp->campaign_price > selected_camp->winning_dynamic_cpm 
					? selected_camp->campaign_price : selected_camp->winning_dynamic_cpm;
		} else 	{	//Network has won
			winning_bid = bidding_ecpm;
		}
		return winning_bid;
}

void print_post_filter_table(
		const rt_response_params_t *rt_response_params, const selected_campaign_attribute_t* selected_camp, 
		const publisher_site_ad_campaign_list_t *adcampaigns, const int rt_response_count,
		const rt_request_params_t *rt_request_params, double winning_bid) {
	(void) selected_camp;
#define DEBUG_BUFFER_SIZE 2047
	char debug_buffer[DEBUG_BUFFER_SIZE + 1];
	char *buffer_ptr = debug_buffer;
	int campaign_index = 0, bytes_written = 0, space_left = DEBUG_BUFFER_SIZE;
	ad_server_req_param_t *req_params = rt_request_params->in_server_req_params;
	debug_buffer[0] = debug_buffer[DEBUG_BUFFER_SIZE] = '\0';

	if ( !req_params ) return;
	
	for ( campaign_index = 0; campaign_index < rt_response_count; campaign_index++) {
		bytes_written = snprintf(buffer_ptr, space_left, ";C:%ld,RF:%d,REQID:%s",rt_response_params[campaign_index].campaign_id, 
			adcampaigns[rt_response_params[campaign_index].campaign_index].ad_campaign_list_setings->reason_for_filtering, rt_request_params->request_url_params.request_id[rt_response_params[campaign_index].rt_req_id_index]);
		if ( bytes_written >= space_left) break;
		space_left -= bytes_written; buffer_ptr += bytes_written;
	}

	llog_write(L_DEBUG,"\nPost Filters: P:%ld,S:%ld,A:%ld, WB:%lf %s",req_params->publisher_id, req_params->site_id, 
	    	req_params->ad_id, winning_bid, debug_buffer);
}

/* Function to update realtime win-loss hash table for all the rtb campaigns associated with this impression */
int update_rtb_winloss_information(
		const fte_additional_params_t *fte_additional_parameters,
		const ad_server_additional_params_t* additional_params, 
		const publisher_site_ad_campaign_list_t *adcampaigns,
		const rt_request_params_t *rt_request_params,
		const int rt_response_count,
		const rt_response_params_t *rt_response_params,
		const selected_campaign_attribute_t* selected_camp,
		hash_table_t *hash_table,
		const int selected_campaign,
		const double bidding_ecpm
	) {

	int winning_rtb_camp_response_index = -1;
	int campaign_index = 0;
	double winning_bid = 0.0;
	int client_auction_enabled = 0;
	int winloss_reason_for_filtering = 0;	//Reason for filtering as per win-loss reason for filtering standard
	int retval = 0;
	int winloss_currency_id = USD_CURRENCY_ID;

	if ( selected_campaign != -1 ) {
		winning_rtb_camp_response_index = adcampaigns[selected_campaign].ad_campaign_list_setings->rtb_campaign_response_index;
	}

	client_auction_enabled = ( additional_params->pubsite_default_settings.client_auction_enabled == 1 || 
				   fte_additional_parameters->publisher_level_settings.client_auction_enabled == 1);

	winning_bid = get_winning_bid( fte_additional_parameters, selected_campaign, selected_camp, bidding_ecpm);

	if ( winning_bid < 0 || winning_bid > REALTIME_CAMPAIGN_MAX_BID ) {
		WLN_ERRORLOG("Invalid winning bid %lf obtained.. returning", winning_bid );
		return WLN_ERROR;
	}

	if ( additional_params->adserver_config_params->rtb_debug_flag >= 1 && rt_response_count > 0 ) {
		print_post_filter_table(rt_response_params, selected_camp, adcampaigns, rt_response_count, rt_request_params, winning_bid);
	}

	for ( campaign_index = 0; campaign_index < rt_response_count; campaign_index++) {
		//Get win-loss reason for filtering from adserver reason for filtering
		if ( rt_response_params[campaign_index].send_winloss_info != 1 ) {
			continue;
		}
		if ( campaign_index == winning_rtb_camp_response_index) { //this is winning rtb campaign
			winloss_reason_for_filtering = WLN_WON_ACTION;
		} else {
			winloss_reason_for_filtering = 	get_winloss_reason_for_filtering( 
							adcampaigns[rt_response_params[campaign_index].campaign_index].ad_campaign_list_setings->reason_for_filtering);
	
			if ( winloss_reason_for_filtering == WLN_ZERO_BID ) {
				//Dont send win-loss notification in case of zero bid
				continue;
			}	
			if ( winloss_reason_for_filtering == WLN_UNFILTERED ) { //campaign is unfiltered
			//if Campaign is unfiltered and its fp is greater than winning bid, send loss notification as floor filter
				if ( adcampaigns[rt_response_params[campaign_index].campaign_index].campaign_price > winning_bid ) {
					winloss_reason_for_filtering = WLN_FLOOR_FILTER;
					WLN_DEBUGLOG("Unfiltered campaign's(%ld) fp(%f) is greater than winning bid(%f)",
						rt_response_params[campaign_index].campaign_id, 
						adcampaigns[rt_response_params[campaign_index].campaign_index].campaign_price, winning_bid);
				} else {
					winloss_reason_for_filtering = WLN_OUTBID;
				}
			}
		}

		// if DSP bids with invalid currency code then send winloss notification in DSPs configured currency.
		winloss_currency_id = ( IS_INVALID_CURRENCY_ID(rt_response_params[campaign_index].currency_id, fte_additional_parameters->currency_count) 
			? adcampaigns[rt_response_params[campaign_index].campaign_index].dsp_currency_id : rt_response_params[campaign_index].currency_id );
		
		retval = add_campaign_info ( 	hash_table, 
						rt_response_params[campaign_index].campaign_id, 
						rt_request_params->request_url_params.request_id[rt_response_params[campaign_index].rt_req_id_index], 
						winloss_reason_for_filtering,
						rt_response_params[campaign_index].bid_response_params.transaction_id, 
						CONVERT_USD_TO_NATIVE_CURRENCY(winning_bid,
							winloss_currency_id,
							fte_additional_parameters->currency_xrate_map,
							fte_additional_parameters->currency_count),
						client_auction_enabled,
						GET_CURRENCY_CODE_FROM_ID(winloss_currency_id,
							fte_additional_parameters->currency_xrate_map,
							fte_additional_parameters->currency_count));

		if ( retval != WLN_SUCCESS ) {
			WLN_ERRORLOG("Failed to add campaign info to winloss hash table, errorcode:%d",retval);
			if ( retval == WLN_HASH_TABLE_FULL ) { //Hash table capacity reached
				expand_winloss_hash_table(hash_table);
			}
		}
	}
	/*Try to maintain some free space in hash table to reduce collisions..
	  Realloc the hash table if its almost full */
	if ( hash_table->no_of_campaigns > hash_table->hash_table_size*MAX_ALLOWED_HASH_TABLE_USE ) {
		WLN_DEBUGLOG("Hash table is almost full.. Usage (%d) out of (%d), exapnding...", 
			     hash_table->no_of_campaigns, hash_table->hash_table_size);
		expand_winloss_hash_table(hash_table);	
	}
	return WLN_SUCCESS;
}
