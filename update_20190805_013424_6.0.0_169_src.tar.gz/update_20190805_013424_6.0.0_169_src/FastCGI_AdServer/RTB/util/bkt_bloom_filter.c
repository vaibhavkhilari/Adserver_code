/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include<limits.h>
#include<stdarg.h>
#include<stdio.h>
#include"bkt_bloom_filter.h"
#include<string.h>
#include"error.h"
#include"ad_server_types.h"

/* Binary search upper_bound function, which finds place in array where given element falls */
int bs_upper_bound(const char *element, const BKT_BLOOM *bkt_bloom_list[], int size) {
	int low = 0;
	int high = size;
	while (low < high) {
		int mid = (low + high) / 2;
		int res = strncmp(element, bkt_bloom_list[mid]->first_element, MAX_BKT_BLOOM_ELEMENT_LEN);
		if (res >= 0) {
			low = mid + 1;
		} else {
			high = mid;
		}
	}
	return low;
}

/* Creates new bkt_bloom, by allocating the memory and initializing it */
BKT_BLOOM *bkt_bloom_create(int nelements, size_t *memcache_obj_size) {
	BKT_BLOOM *bkt_bloom;
	/* Calculate size of bit array to be used in bkt_bloom filter.
	   We allocate 25% more than exact requirement, it helps in reducing false positives.
	   */
	const size_t size = BIT_ARRAY_SIZE_BITS(nelements);
	(*memcache_obj_size) = 0;

	if (nelements <= 0) {
		ERROR_LOG("Invalid nelements: %d", nelements);
		return NULL;
	}

	/* one time memory allocation */
	(*memcache_obj_size) = sizeof(BKT_BLOOM) + BIT_ARRAY_SIZE_BYTES(size) + 1;
	if (!(bkt_bloom=(BKT_BLOOM *)malloc(*memcache_obj_size))) {
		ERROR_LOG("Malloc failed.");
		return NULL;
	}

	/* clear the memory */
	memset(bkt_bloom, 0, (*memcache_obj_size));

	bkt_bloom->bit_array_size = size;
	bkt_bloom->nelements = nelements;
	bkt_bloom->first_element[0] = '\0';

	return bkt_bloom;
}

/* Destroy bkt_bloom and free memory allocated for it */
int bkt_bloom_destroy(BKT_BLOOM **bkt_bloom) {
	/* Free bkt_bloom, if not freed already */
	if ((bkt_bloom) && (*bkt_bloom)) {
		free(*bkt_bloom);
		*bkt_bloom = NULL;
	}
	return 0;
}

/* Add element into bkt_bloom */
int bkt_bloom_add(BKT_BLOOM *bkt_bloom, const char *ele) {
	int i,j;
	word64 res[3];
	unsigned char* bit_array = (unsigned char*)&((bkt_bloom)[1]);

	BLOCKLIST_DEBUG("\nAdding to bkt_bloom:'%s' %s:%d", ele, __FILE__, __LINE__);
	tiger((byte*)ele, strlen(ele), res);
	for (i=0; i<3; i++) {
		for (j=(BIT_LIMIT-BIT_COUNT); j>=0; j-=SKIPED_BITS) {
			BLOCKLIST_DEBUG("%ld_",((word32)((res[i]>>j)&BIT_CHUNK)) % bkt_bloom->bit_array_size);
			SETBIT(bit_array, ((word32)((res[i]>>j)&BIT_CHUNK)) % bkt_bloom->bit_array_size);
		}
	}
	BLOCKLIST_DEBUG("\n");
	return 0;
}

/* Check if element is in bkt_bloom or not.
 *
 * Note- We are not making NULL check for bkt_bloom_list,
 * it's callers responsibilty to NULL check before calling this function
 * */
int bkt_bloom_check(const char *ele, const BKT_BLOOM *bkt_bloom_list[], int bkt_bloom_count) {
	int i,j;
	word64 res[3];
	const BKT_BLOOM *bkt_bloom = NULL;
	/* Initialize blm_index to 1, so if there is only one bloom in array,
	 * we can lookup in 0th bloom directly (blm_index-1) */
	int blm_index = 1;

	if (1 != bkt_bloom_count) {
		/* Get the index for exact bloom from bkt_bloom array where element may be present */
		blm_index = bs_upper_bound(ele, bkt_bloom_list, bkt_bloom_count);
		/* If index returned is less than equal to 0, the element is not present in any bloom */
		if ((blm_index <= 0) || (blm_index > bkt_bloom_count)) {
			return 0;
		}
	}

	/* point to exact bloom in array where element may be present */
	bkt_bloom = bkt_bloom_list[blm_index - 1];
	unsigned char* bit_array = (unsigned char*)&((bkt_bloom)[1]);
	BLOCKLIST_DEBUG("\nChecking in bkt_bloom:'%s' %s:%d", ele, __FILE__, __LINE__);

	if (!bit_array) {
		/* Serious Issue, ideally bit_array should not be NULL */
		LOG_FATAL(BLOOM_CHECK_FAILED, MOD_RTB_DEBUG, ele);
		return 0;
	}

	tiger((byte*)ele, strlen(ele), res);
	for (i=0; i<3; i++) {
		for (j=(BIT_LIMIT-BIT_COUNT); j>=0; j-=SKIPED_BITS) {
			BLOCKLIST_DEBUG("%ld_",((word32)((res[i]>>j)&BIT_CHUNK)) % bkt_bloom->bit_array_size);
			if (!(GETBIT(bit_array, ((word32)((res[i]>>j)&BIT_CHUNK)) % bkt_bloom->bit_array_size))) {
				BLOCKLIST_DEBUG("\nBkt_bloom:: No match for '%s'\n", ele);
				return 0;
			}
		}
	}
	BLOCKLIST_DEBUG("\nBkt_bloom:: match found for '%s'\n", ele);
	return 1;
}

/* Check if domain is in bkt_bloom or not, iterate for each level.
 * If domain is a.b.c.com; check for 'a.b.c.com', 'b.c.com' and 'c.com'
 *
 * Note- We are not making NULL check for bkt_bloom_list,
 * it's callers responsibilty to NULL check before calling this function
 * */
int substring_bkt_bloom_check(
		const char* domain_to_be_searched,
		const BKT_BLOOM** bkt_bloom_list,
		int bkt_bloom_count
		) {
	int rc = NO_ASC_CONVERSION;
	char *domain_punycode = NULL;
	const char *processing_string = domain_to_be_searched;
	int subdomain_levels = 0;
	int domain_found = 0;
	int i;
	char subdomain_delimiter = '.';

	/* left trim 'www.' from domain, if present */
	if (0 == (strncmp(domain_to_be_searched, WWW_STR, WWW_STR_LEN))) {
		processing_string = domain_to_be_searched + WWW_STR_LEN;
	}

	/* Convert domain (if any unicode present in it) to puny code */
	rc = convert_unicode_domain_to_punycode(processing_string, &domain_punycode);
	BLOCKLIST_DEBUG("\nI18:TLDs:: Unicode:%s Punycode:%s, rc:%d\n", processing_string, domain_punycode, rc);
	if ((ASC_CONVERT_SUCCESS == rc) && (NULL != domain_punycode)) {
		processing_string = domain_punycode;
	}

	subdomain_levels = char_counter(processing_string, subdomain_delimiter);

	/* If domain is a.b.c.com; check for 'a.b.c.com', 'b.c.com' and 'c.com' */
	for (i=1; i<=subdomain_levels; i++) {
		if (bkt_bloom_check(processing_string, bkt_bloom_list, bkt_bloom_count)) {
			domain_found = 1;
			break;
		}
		/* The loop ensures that strchr will never return NULL, so no check required */
		processing_string = strchr(processing_string, subdomain_delimiter);
		processing_string++;
	}

	/* free out the memory allocated by domain_punycode */
	if (NULL != domain_punycode) {
		free(domain_punycode);
		domain_punycode = NULL;
	}

	return domain_found;
}

/* Check if substr_domain is in bkt_bloom or not, iterate for each level.
 * If element to check is 123_a.b.c.com; check for '123_a.b.c.com', '123_b.c.com' and '123_c.com'
 *
 * Note- We are not making NULL check for bkt_bloom_list,
 * it's callers responsibilty to NULL check before calling this function
 * */
int substr_domain_bkt_bloom_check(
		const char *substr,
		const char* domain_to_be_searched,
		const BKT_BLOOM** bkt_bloom_list,
		int bkt_bloom_count
		) {
	int rc = NO_ASC_CONVERSION;
	char *domain_punycode = NULL;
	const char *processing_string = domain_to_be_searched;
	char str_to_search[MAX_DOMAIN_NAME_LENGTH + 1];
	int subdomain_levels = 0;
	int domain_found = 0;
	int i;
	char subdomain_delimiter = '.';

	/* left trim 'www.' from domain, if present */
	if (0 == (strncmp(domain_to_be_searched, WWW_STR, WWW_STR_LEN))) {
		processing_string = domain_to_be_searched + WWW_STR_LEN;
	}

	/* Convert domain (if any unicode present in it) to puny code */
	rc = convert_unicode_domain_to_punycode(processing_string, &domain_punycode);
	BLOCKLIST_DEBUG("\nI18:TLDs:: Unicode:%s Punycode:%s, rc:%d\n", processing_string, domain_punycode, rc);
	if ((ASC_CONVERT_SUCCESS == rc) && (NULL != domain_punycode)) {
		processing_string = domain_punycode;
	}

	subdomain_levels = char_counter(processing_string, subdomain_delimiter);

	/* If domain is a.b.c.com; check for 'a.b.c.com', 'b.c.com' and 'c.com' */
	for (i=1; i<=subdomain_levels; i++) {
		snprintf(str_to_search, MAX_DOMAIN_NAME_LENGTH, "%s_%s", substr, processing_string);
		if (bkt_bloom_check(str_to_search, bkt_bloom_list, bkt_bloom_count)) {
			domain_found = 1;
			break;
		}
		/* The loop ensures that strchr will never return NULL, so no check required */
		processing_string = strchr(processing_string, subdomain_delimiter);
		processing_string++;
	}

	/* free out the memory allocated by domain_punycode */
	if (NULL != domain_punycode) {
		free(domain_punycode);
		domain_punycode = NULL;
	}

	return domain_found;
}

/* Build bkt_bloom by creating it and adding elements one by one to it */
int build_bkt_bloom(const char *list,
		int ele_count,
		BKT_BLOOM** bkt_bloom_list,
		size_t *ret_size,
		int max_element_size) {
	int i=0, j=0, k=0;
	BKT_BLOOM* bkt_bloom = NULL;
	size_t memcache_obj_size = 0;
	int cur_ele=0;

	for (i=0; i<MAX_ALLOWED_BKT_BLOOMS && cur_ele<ele_count; i++) {
		if ((bkt_bloom = bkt_bloom_create(((ele_count-cur_ele)>MAX_ALLOWED_ELEMENT_PER_BKT_BLOOM) ?
					MAX_ALLOWED_ELEMENT_PER_BKT_BLOOM:(ele_count-cur_ele),
					&memcache_obj_size))) {
			snprintf(bkt_bloom->first_element, MAX_BKT_BLOOM_ELEMENT_LEN, "%s", &list[(max_element_size+1)*cur_ele]);
			bkt_bloom->first_element[MAX_BKT_BLOOM_ELEMENT_LEN] = '\0';
			INFO_LOG("Adding Bkt_bloom[%d] = '%s'", i, bkt_bloom->first_element);
			for (j=0; j<MAX_ALLOWED_ELEMENT_PER_BKT_BLOOM && cur_ele<ele_count; j++, cur_ele++) {
				/* pointing k to next element in list */
				k = (max_element_size+1)*cur_ele;
				bkt_bloom_add(bkt_bloom, &list[k]);
				BLOCKLIST_DEBUG("Bkt_bloom: Added '%s' %s:%d\n", &list[k], __FILE__, __LINE__);
			}
			bkt_bloom_list[i] = bkt_bloom;
			ret_size[i] = memcache_obj_size;
		} else {
			break;
		}
	}

	if ((i<MAX_ALLOWED_BKT_BLOOMS) && (cur_ele<ele_count)) {
		ERROR_LOG("Bkt_bloom creation failed.");
		/* Do Cleanup, as bkt_bloom creation failed */
		while (i>=0) {
			if (bkt_bloom_list[i]) {
				free(bkt_bloom_list[i]);
			}
			bkt_bloom_list[i] = NULL;
			ret_size[i] = 0;
			i--;
		}
		return ADS_ERROR_NOMEMORY;
	} else {
		/* Add safegaurds for remaining blooms in bkt_bloom array */
		while (i<MAX_ALLOWED_BKT_BLOOMS) {
			bkt_bloom_list[i] = NULL;
			ret_size[i] = 0;
			i++;
		}
		/* If we have received elements which exceeds the bkt_bloom limit, log it as error */
		if (cur_ele < ele_count) {
			ERROR_LOG("Element Count[%d] exceeds bkt_bloom limit:[%d]", ele_count, MAX_TOTAL_BKT_BLOOM_ELEMENTS_LIMIT);
		}
	}
	return ADS_ERROR_SUCCESS;
}

BKT_BLOOM_ARRAY *bkt_bloom_array_create() {
	BKT_BLOOM_ARRAY *tmp_bkt_bloom_array = NULL;
	int j;

	/* Allocate memory for bkt_bloom_array */
	tmp_bkt_bloom_array = (BKT_BLOOM_ARRAY *) malloc (sizeof(BKT_BLOOM_ARRAY));
	if (NULL == tmp_bkt_bloom_array) {
		ERROR_LOG("Malloc failed.");
		return NULL;
	}

	/* Initialize bkt_bloom_array with NULL */
	for (j=0; j<MAX_ALLOWED_BKT_BLOOMS; j++) {
		tmp_bkt_bloom_array->bkt_bloom[j] = NULL;
	}
	/* Initialize bkt_bloom_count to 0 */
	tmp_bkt_bloom_array->bkt_bloom_count = 0;

	return tmp_bkt_bloom_array;
}

int bkt_bloom_array_destroy(BKT_BLOOM_ARRAY **bkt_bloom_array) {
	/* Check if bkt_bloom_array is already freed */
	if (NULL == (*bkt_bloom_array)) {
		return ADS_ERROR_SUCCESS;
	}

	/* bkt_bloom_array cleanup */
	int j;
	/* Free memory taken by bkt bloom and assign it NULL */
	for (j=0; j<MAX_ALLOWED_BKT_BLOOMS && (*bkt_bloom_array)->bkt_bloom[j]!= NULL; j++) {
		bkt_bloom_destroy(&(*bkt_bloom_array)->bkt_bloom[j]);
	}
	free((*bkt_bloom_array));
	(*bkt_bloom_array) = NULL;
	return ADS_ERROR_SUCCESS;
}

