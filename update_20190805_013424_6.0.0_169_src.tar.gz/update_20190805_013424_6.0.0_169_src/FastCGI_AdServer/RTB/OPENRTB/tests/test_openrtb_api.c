#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <typedefs.h>
#include <ad_server_types.h>
#include <rtb_util.h>
#include <rt_campaign_config.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "openrtb.h"
#include "error.h"
#include "db_error.h"
#include "db_connection.h"
#include "cache_libmemcached.h"
#include "openrtb_api_mock_functions.h"

int gbl_log_level = L_DEBUG;
int g_min_payload_for_compression;

/* Currently, no test cases cover code for proxies.  Just adding to resolve
 * library dependencies without importing too many additional dependencies.
 * When proxies are added this can be removed and many additional
 * dependencies will need to be added.
 */
char* g_gopro_url;

static void test_add_ip_in_openrtb_device_ipv4(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int ip_masking_enabled = 0;
	int has_device_param=0;
	char *remote_ip="172.16..63";
	char *masked_ip="172.16.4.0";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	will_return(__wrap_is_ipv4_address,1);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 1);
	expect_string(__wrap_add_ip_in_json, ip, remote_ip);
	add_ip_in_openrtb_device(&post_data,&in_request_params,ip_masking_enabled,has_device_param);
	(void) state;
}

static void test_add_ip_in_openrtb_device_ipv4_private(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int has_device_param=0;
	int ip_masking_enabled = 1;
	char *remote_ip="172.16..63";
	char *masked_ip="172.16.4.0";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	will_return(__wrap_is_ipv4_address,1);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 1);
	expect_string(__wrap_add_ip_in_json, ip, masked_ip);
	add_ip_in_openrtb_device(&post_data,&in_request_params, ip_masking_enabled, has_device_param);
	(void) state;
}

static void test_add_ip_in_openrtb_device_ipv6(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int has_device_param=0;
	int ip_masking_enabled = 0;
	char *remote_ip="2001:0db8:85a3:0000:7890:0000:0370:7334";
	char *masked_ip="2001:0db8:85a3::";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	will_return(__wrap_is_ipv4_address,0);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 0);
	expect_string(__wrap_add_ip_in_json, ip, remote_ip);
	add_ip_in_openrtb_device(&post_data, &in_request_params, ip_masking_enabled, has_device_param);
	(void) state;
}

static void test_add_ip_in_openrtb_device_ipv6_private(void **state){

	char* post_data;
	rt_request_params_t in_request_params;
	ad_server_req_gen_param_t ad_server_req_gen_params;
	int has_device_param=0;
	int ip_masking_enabled = 1;
	char *remote_ip="2001:0db8:85a3:0000:7890:0000:0370:7334";
	char *masked_ip="2001:0db8:85a3::";
	in_request_params.ad_server_req_gen_params=&ad_server_req_gen_params;
	strcpy(in_request_params.ad_server_req_gen_params->remote_ip_addr, remote_ip);
	strcpy(in_request_params.ad_server_req_gen_params->masked_ip_addr, masked_ip);
	will_return(__wrap_is_ipv4_address,0);
	expect_value(__wrap_add_ip_in_json, is_ipv4, 0);
	expect_string(__wrap_add_ip_in_json, ip, masked_ip);
	add_ip_in_openrtb_device(&post_data, &in_request_params, ip_masking_enabled, has_device_param);
	(void) state;
}


int main(){
    const struct CMUnitTest tests[] = { 
        cmocka_unit_test(test_add_ip_in_openrtb_device_ipv4),
		cmocka_unit_test(test_add_ip_in_openrtb_device_ipv4_private),
		cmocka_unit_test(test_add_ip_in_openrtb_device_ipv6),
		cmocka_unit_test(test_add_ip_in_openrtb_device_ipv6_private)

    };  
     return cmocka_run_group_tests(tests, NULL, NULL);
}

