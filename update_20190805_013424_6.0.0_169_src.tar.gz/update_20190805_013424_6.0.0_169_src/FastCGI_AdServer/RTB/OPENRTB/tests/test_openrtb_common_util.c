#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <typedefs.h>
#include <ad_server_types.h>
#include <rtb_util.h>
#include <rt_campaign_config.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include "openrtb.h"
#include "error.h"
#include "db_error.h"
#include "db_connection.h"
#include "cache_libmemcached.h"
#include "json.h"
#include "json_util.h"
#include "json_object_private.h"

#define TOT_ADD_PROTOCOL_INJSON_INPUT 2
uint8_t g_min_payload_for_compression = 0;
int gbl_log_level = L_DEBUG;
void __wrap_print_formatted_string(){
}
void __wrap_get_alpha3_from_alpha2(){
}

int __wrap_prepare_translated_eb_provider_id_list() {
	return 0;
}

int is_valid_json(char *str){
	int valid_json = 1;
	struct json_object *json_obj = NULL;
	json_obj = json_tokener_parse(str);
	if ((json_obj == NULL) || (is_error(json_obj))) {
		printf("ERROR: Logger json string is invalid(non-parsable):%s\n", str);
		valid_json = 0;
	}
	if ((json_obj != NULL) && (!is_error(json_obj))) {
		json_object_put(json_obj);
		json_obj = NULL;
	}
	return valid_json;
}

typedef struct test_replace_native_img_icon_asset_type_inputs_t {
	char native_req_obj[MAX_NATIVE_ASSET_LEN];
	char native_req_obj_after_replace[MAX_NATIVE_ASSET_LEN];
}test_replace_native_img_icon_asset_type_inputs;

static void test_replace_native_img_icon_asset_type__all_testcases(void **state){
	int i;
	test_replace_native_img_icon_asset_type_inputs inputs[] = {
		/* Test Input 1 */
		{
			"{ \"native\": { \"ver\": \"1.1\", \"context\": 2, \"contextsubtype\": 20, \"plcmttype\": 11, \"plcmtcnt\": 1, \"assets\": [{ \"id\": 123, \"required\": 1, \"title\": { \"len\": 140 } }, { \"id\": 128, \"required\": 0, \"img\": { \"wmin\": 836, \"hmin\": 627, \"type\": 3 } }, { \"id\": 124, \"required\": 1, \"img\": { \"wmin\": 50, \"hmin\": 50, \"type\" : 1 } }, { \"id\": 126, \"required\": 1, \"data\": { \"type\": 1, \"len\": 25 } }, { \"id\": 127, \"required\": 1, \"data\": { \"type\": 2, \"len\": 140 } } ] } }",
			"{ \"native\": { \"ver\": \"1.1\", \"context\": 2, \"contextsubtype\": 20, \"plcmttype\": 11, \"plcmtcnt\": 1, \"assets\": [{ \"id\": 123, \"required\": 1, \"title\": { \"len\": 140 } }, { \"id\": 128, \"required\": 0, \"img\": { \"wmin\": 836, \"hmin\": 627, \"type\": 3 } }, { \"id\": 124, \"required\": 1, \"img\": { \"wmin\": 50, \"hmin\": 50, \"type\" : 2 } }, { \"id\": 126, \"required\": 1, \"data\": { \"type\": 1, \"len\": 25 } }, { \"id\": 127, \"required\": 1, \"data\": { \"type\": 2, \"len\": 140 } } ] } }"
		},

		/* Test Input 2 */
		{
			"{ \"native\": { \"assets\": [{ \"id\": 1, \"required\": 1, \"title\": { \"len\": 30 } }, { \"id\": 2, \"required\": 0, \"data\": { \"type\": 3, \"len\": 5 } }, { \"id\": 3, \"required\": 1, \"img\"  :   { \"type\"  :  1, \"w\": 64, \"h\": 64, \"mimes\": [ \"image/png\" ] } }, { \"id\": 4, \"required\": 0, \"data\": { \"type\": 2, \"len\": 10 } } ] } }",
			"{ \"native\": { \"assets\": [{ \"id\": 1, \"required\": 1, \"title\": { \"len\": 30 } }, { \"id\": 2, \"required\": 0, \"data\": { \"type\": 3, \"len\": 5 } }, { \"id\": 3, \"required\": 1, \"img\"  :   { \"type\"  :  2, \"w\": 64, \"h\": 64, \"mimes\": [ \"image/png\" ] } }, { \"id\": 4, \"required\": 0, \"data\": { \"type\": 2, \"len\": 10 } } ] } }"
		},

		/* Test Input 3 */
		{
			"{ \"native\": { \"assets\": [{ \"id\": \"img\", \"required\": 1, \"title\": { \"len\": 30 } }, { \"id\": 2, \"required\": 0, \"data\": { \"type\": 3, \"len\": 5 } }, { \"id\": 3, \"required\": \"img\", \"img\"  :   { \"type\"  :  1, \"w\": 64, \"h\": 64, \"mimes\": [ \"image/png\" ] } }, { \"id\": 4, \"required\": \"img\", \"data\": { \"type\": 1, \"len\": 10 } } ] } }",
			"{ \"native\": { \"assets\": [{ \"id\": \"img\", \"required\": 1, \"title\": { \"len\": 30 } }, { \"id\": 2, \"required\": 0, \"data\": { \"type\": 3, \"len\": 5 } }, { \"id\": 3, \"required\": \"img\", \"img\"  :   { \"type\"  :  2, \"w\": 64, \"h\": 64, \"mimes\": [ \"image/png\" ] } }, { \"id\": 4, \"required\": \"img\", \"data\": { \"type\": 1, \"len\": 10 } } ] } }"
		},

	};

	for (i=0; i<(int)((sizeof(inputs)/sizeof(test_replace_native_img_icon_asset_type_inputs))); i++) {
		replace_native_img_icon_asset_type(inputs[i].native_req_obj);
		assert_string_equal(inputs[i].native_req_obj, inputs[i].native_req_obj_after_replace);
		assert_int_equal(is_valid_json(inputs[i].native_req_obj), 1);
	}
	(void) state;
}

typedef struct{
	int send_origin_pubid_enabled;
	ad_server_req_param_t req_params;
	char company_name[256] ;
	rt_request_url_params_mask_t rt_request_url_params_mask;
	int is_prefix_comma;
	char exp_post_data[100000];
}test_create_publisher_str;

test_create_publisher_str test_create_publisher_obj[]={
	{	//0
		.send_origin_pubid_enabled = 0,
		.req_params.publisher_id = 100,
		.req_params.orig_publisher_id = "opid100",
		.company_name = "abc",
		.rt_request_url_params_mask.send_publisher_name = 1,
		.is_prefix_comma = 1,
		//expected output
		.exp_post_data = ",\"publisher\":{\"id\":\"100\",\"name\":\"abc\"}"
	},
	{	//1
		.send_origin_pubid_enabled = 1,
		.req_params.publisher_id = 100,
		.req_params.orig_publisher_id = "opid100",
		.company_name = "abc",
		.rt_request_url_params_mask.send_publisher_name = 1,
		.is_prefix_comma = 1,
		//expected output
		.exp_post_data = ",\"publisher\":{\"id\":\"opid100\"}"
	},
	{	//2
		.send_origin_pubid_enabled = 0,
		.req_params.publisher_id = 100,
		.req_params.orig_publisher_id = "",
		.company_name = "abc",
		.rt_request_url_params_mask.send_publisher_name = 1,
		.is_prefix_comma = 1,
		//expected output
		.exp_post_data = ",\"publisher\":{\"id\":\"100\",\"name\":\"abc\"}"
	},
	{	//3
		.send_origin_pubid_enabled = 0,
		.req_params.publisher_id = 100,
		.req_params.orig_publisher_id = "opid100",
		.company_name = "abc",
		.rt_request_url_params_mask.send_publisher_name = 1,
		.is_prefix_comma = 0,
		//expected output
		.exp_post_data = "\"publisher\":{\"id\":\"100\",\"name\":\"abc\"}"
	},
	{	//4
		.send_origin_pubid_enabled = 1,
		.req_params.publisher_id = 100,
		.req_params.orig_publisher_id = "opid100",
		.company_name = "abc",
		.rt_request_url_params_mask.send_publisher_name = 1,
		.is_prefix_comma = 0,
		//expected output
		.exp_post_data = "\"publisher\":{\"id\":\"opid100\"}"
	},
	{	//5
		.send_origin_pubid_enabled = 0,
		.req_params.publisher_id = 100,
		.req_params.orig_publisher_id = "",
		.company_name = "abc",
		.rt_request_url_params_mask.send_publisher_name = 1,
		.is_prefix_comma = 0,
		//expected output
		.exp_post_data = "\"publisher\":{\"id\":\"100\",\"name\":\"abc\"}"
	},

};
/*
 * Testcase create_source_object_v23 3: when MLA flag is Invalid
 */

static void test_add_publisherobj_injson(void **state){

	char *post_data;
	char *tmp_post_data = NULL;
	rt_request_params_t  in_request_params;

	post_data = (char*)malloc(sizeof(char)*200);
	if ( post_data == NULL ){
		printf("test_add_publisherobj_injson: Unable to allocate memory\n");
		return;
	}
	in_request_params.fte_additional_params = (fte_additional_params_t*)malloc(sizeof(fte_additional_params_t));
	
	int itemCount = sizeof(test_create_publisher_obj)/sizeof(test_create_publisher_str);
	int i = 0;
	for( i = 0; i< itemCount; i++){
		post_data[0] = '\0';
		tmp_post_data = post_data;		
		in_request_params.fte_additional_params = (fte_additional_params_t*)malloc(sizeof(fte_additional_params_t));
		if (NULL == in_request_params.fte_additional_params){
			printf("Error:unable to allocate memory\n");
			return;
		}
		strcpy(in_request_params.fte_additional_params->publisher_level_settings.company_name,test_create_publisher_obj[i].company_name);
		add_publisherobj_injson(&tmp_post_data,
								test_create_publisher_obj[i].send_origin_pubid_enabled,
								&test_create_publisher_obj[i].req_params,
								&in_request_params,
								&test_create_publisher_obj[i].rt_request_url_params_mask,
								test_create_publisher_obj[i].is_prefix_comma);
		assert_memory_equal(post_data,test_create_publisher_obj[i]. exp_post_data, strlen(test_create_publisher_obj[i].exp_post_data));
	}
}

typedef struct test_protocol_input{
	char post_data[5024];
	char field_name[50];
	char value[10];
	int add_comma;
}test_protocol_input_t;

test_protocol_input_t protocol_input[TOT_ADD_PROTOCOL_INJSON_INPUT] =
{{"\"pid\":1,\"imp\":[{\"id\":\"1\",\"tagid\":\"26281\",\"video\":{\"mimes\":[\"video/mp4\",\"application/x-shockwave-flash\",\"video/x-flv\",\"video/3gpp\",\"video/quicktime\",\"video/mpeg\",\"application/x-mpegURL\"],\"linearity\":1,\"minduration\":5,\"maxduration\":30,\"protocol\":2,\"startdelay\":0,\"maxbitrate\":1500,\"playbackmethod\":[1,5],\"api\":[1,2,3,4,5,6],\"h\":99,\"w\":11,\"ext\":{", "\"protocols\":[", "101001000", 0},
	{"\"pid\":1,\"imp\":[{\"id\":\"1\",\"tagid\":\"26281\",\"video\":{\"mimes\":[\"video/mp4\",\"application/x-shockwave-flash\",\"video/x-flv\",\"video/3gpp\",\"video/quicktime\",\"video/mpeg\",\"application/x-mpegURL\"],\"linearity\":1,\"minduration\":5,\"maxduration\":30,\"protocol\":2,\"startdelay\":0,\"maxbitrate\":1500,\"playbackmethod\":[1,5],\"api\":[1,2,3,4,5,6],\"h\":99,\"w\":11","\"protocols\":[", "101001000", 1}};

char test_protocol_output[TOT_ADD_PROTOCOL_INJSON_INPUT][5024] =
{"\"pid\":1,\"imp\":[{\"id\":\"1\",\"tagid\":\"26281\",\"video\":{\"mimes\":[\"video/mp4\",\"application/x-shockwave-flash\",\"video/x-flv\",\"video/3gpp\",\"video/quicktime\",\"video/mpeg\",\"application/x-mpegURL\"],\"linearity\":1,\"minduration\":5,\"maxduration\":30,\"protocol\":2,\"startdelay\":0,\"maxbitrate\":1500,\"playbackmethod\":[1,5],\"api\":[1,2,3,4,5,6],\"h\":99,\"w\":11,\"ext\":{\"protocols\":[2,5]"
	,
  "\"pid\":1,\"imp\":[{\"id\":\"1\",\"tagid\":\"26281\",\"video\":{\"mimes\":[\"video/mp4\",\"application/x-shockwave-flash\",\"video/x-flv\",\"video/3gpp\",\"video/quicktime\",\"video/mpeg\",\"application/x-mpegURL\"],\"linearity\":1,\"minduration\":5,\"maxduration\":30,\"protocol\":2,\"startdelay\":0,\"maxbitrate\":1500,\"playbackmethod\":[1,5],\"api\":[1,2,3,4,5,6],\"h\":99,\"w\":11,\"protocols\":[2,5]"};


static void test_add_protocols_injson(void **state) {
	int input_cnt = TOT_ADD_PROTOCOL_INJSON_INPUT;
	int i =0;
	for(i =0 ;i<input_cnt; i++) {
		int len = 0;
		char *post_data = NULL;
		post_data = (char *)malloc(5024*sizeof(char));
		char *ptr = post_data;
		len = strlen(protocol_input[i].post_data);
		memcpy(post_data, protocol_input[i].post_data, len);
		post_data +=  len;
		video_append_protocols(&post_data,
				protocol_input[i].field_name,
				protocol_input[i].value, protocol_input[i].add_comma);
		assert_string_equal(test_protocol_output[i], ptr);
		free(*post_data);
		ptr = NULL;
		post_data = NULL;
	}
	(void) state;
}

typedef struct test_gdpr_object_creation_decision_inputs {
	int is_gdpr_req;
	int is_req_from_gdpr_country;
	int gdpr_proto;
	int dont_pass_iab_consent_obj;
	int expt_add_gdpr_ext;
	int expt_add_iab_consent;
	int expt_add_eb_cplist;
} test_gdpr_object_creation_decision_inputs_t;

void test_gdpr_object_creation_decision(test_gdpr_object_creation_decision_inputs_t *input) {
	ad_server_req_param_t req_params;
	fte_additional_params_t fte_additional_params;
	int add_gdpr_ext = 0;
	int add_iab_gdpr_consent = 0;
	int add_eb_provider_list = 0;
	char *eb_provider_list = "";

	req_params.gdpr_req_params.is_gdpr_req = input->is_gdpr_req;
	req_params.gdpr_req_params.is_req_from_gdpr_country = input->is_req_from_gdpr_country;
	req_params.gdpr_req_params.gdpr_protocol = input->gdpr_proto;
	strcpy(req_params.eb_cp_list_str, "1,2,3,4");
	strcpy(req_params.translated_eb_cp_list_str, "1,2,3,4");

	gdpr_object_creation_decision(&req_params,
			&fte_additional_params,
			input->dont_pass_iab_consent_obj,
			&add_gdpr_ext,
			&add_iab_gdpr_consent,
			&add_eb_provider_list,
			&eb_provider_list);

	assert_int_equal(add_gdpr_ext, input->expt_add_gdpr_ext);
	assert_int_equal(add_iab_gdpr_consent, input->expt_add_iab_consent);
	assert_int_equal(add_eb_provider_list, input->expt_add_eb_cplist);
	if(1 == input->expt_add_eb_cplist) {
		assert_string_equal(eb_provider_list, "1,2,3,4");
	} else {
		assert_string_equal(eb_provider_list, "");
	}
}

static void test_gdpr_object_creation_decision__all_testcases(void **state) {
	int i;
	test_gdpr_object_creation_decision_inputs_t inputs[]={
		// Postive Testcases
		// is_gdpr,is_gdpr_country,gdpr_proto,dont_pass_flag,add_gdpr_ext,add_cns,add_cplist
		{0,0,0,0,0,0,0}, //Non GDPR request, dont_pass flag 0
		{0,0,0,1,0,0,0}, //Non GDPR request, dont_pass flag 1
		{0,0,0,2,0,0,0}, //Non GDPR request, dont_pass flag 2

		{1,0,0,0,1,1,1}, //GDPR request(IAB), dont_pass flag 0
		{1,0,0,1,0,0,0}, //GDPR request(IAB), dont_pass flag 1
		{1,0,0,2,1,0,1}, //GDPR request(IAB), dont_pass flag 2

		{1,0,1,0,1,1,1}, //GDPR request(EB), dont_pass flag 0
		{1,0,1,1,1,0,1}, //GDPR request(EB), dont_pass flag 1
		{1,0,1,2,1,0,1}, //GDPR request(EB), dont_pass flag 2

		{0,1,0,0,0,0,0}, //GDPR region request(IAB), dont_pass flag 0
		{0,1,0,1,0,0,0}, //GDPR region request(IAB), dont_pass flag 1
		{0,1,0,2,1,0,1}, //GDPR region request(IAB), dont_pass flag 2

		{0,1,1,0,0,0,0}, //GDPR region request(EB), dont_pass flag 0
		{0,1,1,1,0,0,0}, //GDPR region request(EB), dont_pass flag 1
		{0,1,1,2,1,0,1}, //GDPR region request(EB), dont_pass flag 2
	};

	for(i=0;i<(int)((sizeof(inputs)/sizeof(test_gdpr_object_creation_decision_inputs_t)));i++){
		test_gdpr_object_creation_decision(&inputs[i]);
	}
	(void) state;
}

typedef struct test_ortb_ext_object{
	int has_ext_params;
	char post_data[MAX_EVENT_TRACKING_URI_SIZE + 1];
	rt_request_params_t in_request_params;
	ad_server_additional_params_t additional_parameter;
	publisher_site_ad_campaign_list_t adcampaign;
	const char *expected_post_data;
	int expected_has_ext_params;
}test_ortb_ext_object_t;

fte_additional_params_t test_fte_additional_params[] = {
	//Test case 1
	{
		.publisher_level_settings.ssp_name = "conatix",
		.currency_count = 40
	},
	//Test case 2
	{
		.publisher_level_settings.ssp_name = "conatix",
		.currency_count = 40
	},
	//Test case 3
	{
		.publisher_level_settings.ssp_name = "conatix",
		.currency_count = 40
	},
	//Test case 4 : ssp_name not set for publsiher
	{
		.currency_count = 40
	},
	//Test case 5
	{
		.publisher_level_settings.ssp_name = "conatix",
		.currency_count = 40
	},
	//Test case 6
	{
		.currency_count = 40
	},
	//Test case 7
	{
		.currency_count = 40
	},
	//Test case 8
	{
		.publisher_level_settings.ssp_name = "conatix",
		.currency_count = 40
	}

};

/*
 * NOTE : Value of currency_xrate_map used by openrtb_request_append_common_ext_object method is
 * e.g currency_xrate_map[DSP_CURRENCY_ID-1].precision_rate
 * where DSP_CURRENCY_ID = adcampaign.dsp_currency_id (which is set in test_ortb_ext_object_arr)
 * */
currency_xrate_map_t test_currency_xrate_map[] = {
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	},
	{
		.currency_id = 1,
		.precision_rate = 1.0,
		.inverse_rate = 1.0,
		.currency_code = "USD"
	}
};

test_ortb_ext_object_t test_ortb_ext_object_arr[] = {
	//Test Case 1 : All parameters are present and added to extension object
	{
		.has_ext_params = 0,
		.additional_parameter.soft_floor = 2.75,
		.adcampaign.dsp_currency_id = 2,
		.expected_post_data = "\"bidguidefloor\":2.750000,\"bidfloorcur\":\"USD\",\"ssp\":\"conatix\"",
		.expected_has_ext_params = 1
	},
	//Test case 2 : soft_floor is zero. bidguidefloor and bidfloorcur will not be added in ext object
	{
		.has_ext_params = 0,
		.additional_parameter.soft_floor = 0.0,
		.adcampaign.dsp_currency_id = 2,
		.expected_post_data = "\"ssp\":\"conatix\"",
		.expected_has_ext_params = 1
	},
	//Test case 3 : dsp_currency_id set to 1 i.e. USD_CURRENCY_ID. bidfloorcur will not be added in ext object
	{
		.has_ext_params = 0,
		.additional_parameter.soft_floor = 2.75,
		.adcampaign.dsp_currency_id = 1,
		.expected_post_data = "\"bidguidefloor\":2.750000,\"ssp\":\"conatix\"",
		.expected_has_ext_params = 1
	},
	//Test case 4 : ssp_name not set for publisher in test_fte_additional_params above. ssp will not be added in ext object
	{
		.has_ext_params = 0,
		.additional_parameter.soft_floor = 2.75,
		.adcampaign.dsp_currency_id = 2,
		.expected_post_data = "\"bidguidefloor\":2.750000,\"bidfloorcur\":\"USD\"",
		.expected_has_ext_params = 1
	},
	//Test case 5 : has_ext_params is set to 1, comma added at begining
	{
		.has_ext_params = 1,
		.additional_parameter.soft_floor = 2.75,
		.adcampaign.dsp_currency_id = 2,
		.expected_post_data = ",\"bidguidefloor\":2.750000,\"bidfloorcur\":\"USD\",\"ssp\":\"conatix\"",
		.expected_has_ext_params = 1
	},
	//Test case 6 : has_ext_params is set to 0, and all field are empty. Result-Empty post data with no camma.
	{
		.has_ext_params = 0,
		.additional_parameter.soft_floor = 0.0,
		.adcampaign.dsp_currency_id = 2,
		.expected_post_data = "",
		.expected_has_ext_params = 0
	},
	//Test case 7 : has_ext_params is set to 1, and all field are empty. Result-Empty post data with no camma.
	{
		.has_ext_params = 1,
		.additional_parameter.soft_floor = 0.0,
		.adcampaign.dsp_currency_id = 2,
		.expected_post_data = "",
		.expected_has_ext_params = 1
	},
	//Test case 8 : has_ext_params is set to 1. Comma added in post data.
	{
		.has_ext_params = 1,
		.additional_parameter.soft_floor = 0.0,
		.adcampaign.dsp_currency_id = 2,
		.expected_post_data = ",\"ssp\":\"conatix\"",
		.expected_has_ext_params = 1
	}
};

void test_openrtb_request_append_common_ext_object(void **state) {
	int i = 0;

	for (i=0; i<(int)((sizeof(test_ortb_ext_object_arr)/sizeof(test_ortb_ext_object_t))); i++) {
		int len = 0;
		char *post_data = NULL;
		post_data = (char *)malloc((MAX_EVENT_TRACKING_URI_SIZE + 1)*sizeof(char));
		char *ptr = post_data;
		len = strlen(test_ortb_ext_object_arr[i].post_data);
		memcpy(post_data, test_ortb_ext_object_arr[i].post_data, len);
		post_data +=  len;

		test_ortb_ext_object_arr[i].in_request_params.fte_additional_params = &(test_fte_additional_params[i]);
		test_ortb_ext_object_arr[i].in_request_params.fte_additional_params->currency_xrate_map = &(test_currency_xrate_map[i]);

		openrtb_request_append_common_ext_object(
				&post_data,
				&(test_ortb_ext_object_arr[i].in_request_params),
				&(test_ortb_ext_object_arr[i].additional_parameter),
				&(test_ortb_ext_object_arr[i].adcampaign),
				0,
				&(test_ortb_ext_object_arr[i].has_ext_params)
				);
		assert_int_equal(test_ortb_ext_object_arr[i].has_ext_params, test_ortb_ext_object_arr[i].expected_has_ext_params);
		assert_string_equal(ptr, test_ortb_ext_object_arr[i].expected_post_data);
		free(*post_data);
		ptr = NULL;
		post_data = NULL;
	}
	(void) state;
}

typedef struct test_schain_ext_object {
	int has_ext_params;
	char post_data[MAX_EVENT_TRACKING_URI_SIZE + 1];
	char pubmatic_asi[100];
	int send_sco_flag;
	int schain_cmpl;
	char schain_nodes[100];
	char schain_ver[100];
	int pub_id;
	char req_id[100];
	const char *expected_post_data;
	int expected_has_ext_params;
} test_schain_ext_object_t;

test_schain_ext_object_t test_schain_ext_object_arr[] = {
	/* Feature OFF testcases */
	{0,"","",1,0,"","",0,"","",0},
	{0,"","pubmatic.com",0,0,"","",0,"","",0},
	{1,"","",1,0,"","",0,"","",1},
	{1,"","pubmatic.com",0,0,"","",0,"","",1},
	{1,"xyz","",1,0,"","",0,"","xyz",1},
	{1,"abc","pubmatic.com",0,0,"","",0,"","abc",1},
	/* Positive test cases */
	/* SCO not recieved in request */
	{1,"","pubmatic.com",1,0,"","",12345,"ABCD-ABCD-ABCD-ABCD",",\"schain\":{\"complete\":0,\"ver\":\"1.0\",\"nodes\":[{\"asi\":\"pubmatic.com\",\"sid\":\"12345\",\"rid\":\"ABCD-ABCD-ABCD-ABCD\",\"hp\":1}]}",1},
	{0,"","pubmatic.com",1,0,"","",12345,"ABCD-ABCD-ABCD-ABCD","\"schain\":{\"complete\":0,\"ver\":\"1.0\",\"nodes\":[{\"asi\":\"pubmatic.com\",\"sid\":\"12345\",\"rid\":\"ABCD-ABCD-ABCD-ABCD\",\"hp\":1}]}",1},
	{0,"","pubmatic.com",1,1,"","",12345,"ABCD-ABCD-ABCD-ABCD","\"schain\":{\"complete\":1,\"ver\":\"1.0\",\"nodes\":[{\"asi\":\"pubmatic.com\",\"sid\":\"12345\",\"rid\":\"ABCD-ABCD-ABCD-ABCD\",\"hp\":1}]}",1},

	/* SCO recieved in request */
	{1, "", "pubmatic.com", 1, 0,
	"[{\"asi\":\"ssp1.com\",\"pid\":\"abcdef\",\"rid\":\"XYZ-ABCD-XYZ-ABCD\",\"hp\":0}","1.0",
	12345,
	"ABCD-ABCD-ABCD-ABCD",
	",\"schain\":{\"complete\":0,\"ver\":\"1.0\",\"nodes\":[{\"asi\":\"ssp1.com\",\"pid\":\"abcdef\",\"rid\":\"XYZ-ABCD-XYZ-ABCD\",\"hp\":0},{\"asi\":\"pubmatic.com\",\"sid\":\"12345\",\"rid\":\"ABCD-ABCD-ABCD-ABCD\",\"hp\":1}]}", 1},
	{0, "", "pubmatic.com", 1, 0,
	"[{\"asi\":\"ssp1.com\",\"sid\":\"abcdef\",\"rid\":\"XYZ-ABCD-XYZ-ABCD\"}","1.1",
	12345,
	"ABCD-ABCD-ABCD-ABCD",
	"\"schain\":{\"complete\":0,\"ver\":\"1.1\",\"nodes\":[{\"asi\":\"ssp1.com\",\"sid\":\"abcdef\",\"rid\":\"XYZ-ABCD-XYZ-ABCD\"},{\"asi\":\"pubmatic.com\",\"sid\":\"12345\",\"rid\":\"ABCD-ABCD-ABCD-ABCD\",\"hp\":1}]}", 1},
	{0, "", "pubmatic.com", 1, 1,
	"[{\"asi\":\"ssp1.com\",\"sid\":\"abcdef\",\"rid\":\"XYZ-ABCD-XYZ-ABCD\",\"hp\":1}","1.5",
	12345,
	"ABCD-ABCD-ABCD-ABCD",
	"\"schain\":{\"complete\":1,\"ver\":\"1.5\",\"nodes\":[{\"asi\":\"ssp1.com\",\"sid\":\"abcdef\",\"rid\":\"XYZ-ABCD-XYZ-ABCD\",\"hp\":1},{\"asi\":\"pubmatic.com\",\"sid\":\"12345\",\"rid\":\"ABCD-ABCD-ABCD-ABCD\",\"hp\":1}]}", 1},
};

void test_append_supply_chain_object(void **state) {
	(void) state;

	int i = 0;

	for (i=0; i<(int)((sizeof(test_schain_ext_object_arr)/sizeof(test_schain_ext_object_t))); i++) {
		int len = 0;
		char *post_data = NULL;
		post_data = (char *)malloc((MAX_EVENT_TRACKING_URI_SIZE + 1)*sizeof(char));
		char *ptr = post_data;
		len = strlen(test_schain_ext_object_arr[i].post_data);
		memcpy(post_data, test_schain_ext_object_arr[i].post_data, len);
		post_data +=  len;

		rt_request_params_t in_request_params;
		ad_server_req_param_t in_server_req_params;
		fte_additional_params_t fte_additional_params;

		in_request_params.fte_additional_params = &fte_additional_params;
		in_request_params.in_server_req_params = &in_server_req_params;

		strcpy(in_server_req_params.schain_pubmatic_asi, test_schain_ext_object_arr[i].pubmatic_asi);
		strcpy(in_server_req_params.schain_nodes_str, test_schain_ext_object_arr[i].schain_nodes);
		strcpy(in_server_req_params.schain_version, test_schain_ext_object_arr[i].schain_ver);
		in_server_req_params.publisher_id = test_schain_ext_object_arr[i].pub_id;
		in_server_req_params.schain_complete = test_schain_ext_object_arr[i].schain_cmpl;
		strcpy(in_request_params.request_url_params.request_id[0], test_schain_ext_object_arr[i].req_id);
		fte_additional_params.publisher_level_settings.send_supply_chain_object_in_rtb = test_schain_ext_object_arr[i].send_sco_flag;

		append_supply_chain_object(
				&post_data,
				&in_request_params,
				&(test_schain_ext_object_arr[i].has_ext_params)
				);
		assert_int_equal(test_schain_ext_object_arr[i].has_ext_params, test_schain_ext_object_arr[i].expected_has_ext_params);
		assert_string_equal(ptr, test_schain_ext_object_arr[i].expected_post_data);
		free(*post_data);
		ptr = NULL;
		post_data = NULL;
	}
}

int main(){
	const struct CMUnitTest tests[] = { 
		cmocka_unit_test(test_add_publisherobj_injson),
		cmocka_unit_test(test_replace_native_img_icon_asset_type__all_testcases),
		cmocka_unit_test(test_add_protocols_injson),
		cmocka_unit_test(test_gdpr_object_creation_decision__all_testcases),
		cmocka_unit_test(test_openrtb_request_append_common_ext_object),
		cmocka_unit_test(test_append_supply_chain_object),
	};  
	return cmocka_run_group_tests(tests, NULL, NULL);
}
