
/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#include <stdio.h>
#include <unistd.h>
#include <curl/curl.h>
#include <typedefs.h>
#include <rtb_util.h>
#include <ad_server_types.h>
#include <rt_campaign_config.h>
#include <zlib.h>
#include "campaign_data_provider_data.h"
#include "url_blocklist.h"
#include "cache_publisher_site_iframe_buster_tech.h"
#include "deal.h"
#include <error.h>
#include <errno.h>
#include <assert.h>
#include "platform.h"
#include "mobile_header.h"
#include "openrtb.h"
#include "default_adapter.h"
#include "libstats_util.h"
#include "video.h"
#include "string_util.h"
#include "log_fw.h"
#include "win_loss_notification.h"
#include "http_response_wrapper.h"
#include "platform.h"
#include "url_categorization.h"
#include "otf_block_list.h"
#include "json_wrapper.h"
#include "cache_badv_domain.h"
#include "deal_fast_targeting.h"

extern int g_rtb_ms_connection_timeout;
extern int g_rtb_ms_timeout;
extern int g_mob_nw_timeout;
extern int g_rtb_integral_enabled;

extern char* g_drproxy_url;
extern char* g_gopro_url;

extern int decode_url(const char* source, char* dest, int dest_size);
extern int is_ipv4_address(char *ip_address);
extern const char* get_header_value( const http_header_map_t* header_map, const char* key);

//ORTB version is 2.1
#define ORTB_VERSION 21

#define O_ID	"id"
#define O_TAGID "tagid"
#define O_AT	"at"
#define O_TMAX	"tmax"
#define O_IMP_STRING 	"\"imp\":["
#define O_IMP_STRING_END "]"
#define O_IMP_ID "id"
#define O_IMP_INTL "instl"
#define O_IMP_FLOOR "bidfloor"
#define O_IMP_CURRENCY "bidfloorcur"
#define O_BANNER_STRING "\"banner\":{"
#define O_NATIVE_STRING "\"native\":"
#define O_IMP_WD 	"w"
#define O_IMP_HT	"h"
#define O_MIN_WD 	"wmin"
#define O_MAX_WD	"wmax"
#define O_MIN_HT 	"hmin"
#define O_MAX_HT	"hmax"
#define O_IFRAME_BUSTER "\"iframebuster\":"
#define O_IMP_FOLDPOS	"pos"
#define O_IMP_TOPFRAME  "topframe"
#define O_EXPDIR	"\"expdir\":"
#define O_IMP_API	"api"
#define O_IMP_SEC "secure"
#define O_BADV_ARR	"\"badv\":"
#define O_BCAT_ARR	"\"bcat\":"
#define O_BATTR_ARR	"\"battr\":"
#define O_BANNER_API_ARR "\"api\":"
#define O_BANNER_DEFAULT_API	"\"api\":[3]"
#define O_SITE_STRING	"\"site\":{"
#define O_SITE_ID "id"
#define O_SITE_NAME "name"
#define O_SITE_PAGECAT_ARR "\"pagecat\":"
#define O_BSC	"\"bsc\":"
#define O_APP_ID  "id"
#define O_APP_STRING "\"app\":{"
#define O_APP_NAME  "name"
#define O_APP_VER    "ver"
#define O_APP_BUNDLE "bundle"
#define O_APP_DOMAIN "domain"
#define O_APP_PAID   "paid"
#define O_APP_STORE_URL "storeurl"
#define O_APP_CAT "\"cat\":"

#define O_APP_SECTIONCAT "\"sectioncat\":"
#define O_APP_PAGECAT "\"pagecat\":"
#define O_APP_KEYWORDS "keywords"
#define O_APP_PRIVACYPOLICY "privacypolicy"

#define O_APP_SITEID	"pmid"
#define O_IMP_EXT_START "\"ext\":{"
#define O_IMP_EXT_HBE_START "\"headerbidding\":{"
#define O_IMP_EXT_HBE_PRESENT "present"
#define O_IMP_EXT_HBE_END "}"
#define O_IMP_EXT_END "}"

#define O_CAT_STRING "\"cat\":{"
#define O_PRIVECY_POLICY "privacypolicy"
#define O_REFURL  "ref"
#define O_PUBLISHER_NAME "name"
#define O_SITE_SEC "sec"
#define O_CONTENT_STRING "\"content\":{"
#define O_CONTENT "\"content\":"
#define O_KEYWORDS "keywords"
#define O_DEVICE_STRING "\"device\":{"
#define O_DEVICE_DNT "dnt"
#define O_DEVICE_UA "ua"
#define O_DEVICE_OS "os"
#define O_DEVICE_DIDMD5 "didmd5"
#define O_DEVICE_DPIDSHA1 "dpidsha1"
#define O_DEVICE_DPIDMD5 "dpidmd5"
#define O_DEVICE_CARRIER "carrier"
#define O_DEVICE_FLASHVER "flashver"
#define O_DEVICE_LANG "language"
#define O_DEVICE_MAKE "make"
#define O_DEVICE_MODEL "model"
#define O_DEVICE_OS	"os"
#define O_DEVICE_OSV    "Osv"
#define O_DEVICE_OSV_LC    "osv"
#define O_FLASH_VER "flashver"
#define O_DEVICE_JS "js"
#define O_DEVICE_TYPE "devicetype"
#define O_DEVICE_CONTYPE "connectiontype"
#define O_USER_STRING	"\"user\":{"
#define O_USER_ID "id"
#define O_BUYER_ID "buyer_id"
#define O_USER_YOB "yob"
#define O_USER_GENDER "gender"
#define O_USER_KEYWORDS "keywords"
#define O_USER_CUSTOMDATA "customdata"
#define O_USER_REGION "region"
#define O_USER_COUNTRY "country"
#define O_USER_CITY "city"
#define O_USER_ZIP  "zip"
#define O_USER_TIMEZONE "tmz"
#define O_USER_ETHN "ethn"
#define O_USER_INCOME "inc"
#define O_USER_CARRIER_SPECIFIC_USER_ID "cuid"
#define O_USER_CARRIER_SPECIFIC_USER_ID_TYPE "cuidtype"
#define O_USER_CARRIER_SPECIFIC_USER_ID_TYPE_VERIZON 1
#define O_USER_DSP_UID_INFERRED	"infid"
#define O_GEO_STRING "\"geo\":{"
#define O_CITY "city"
#define O_METRO "metro"
#define O_COUNTRY "country"
#define O_REGION "region"
#define O_LAT	"lat"
#define O_LON	"lon"
#define O_ZIP	"zip"
#define O_GEO_TYPE "type"
#define GEO_FROM_GPS	1
#define GEO_FROM_IP 	2
#define GEO_FROM_USER 	3

#define O_EXT_STRING	"\"ext\":{"
#define O_EXT_UD	"ud"
#define O_EXT_TYPE	"type"
#define O_EXT_ADTRUTH 	"\"adtruth\":"
#define O_DEV_EXT_HASH  "hash"
#define O_DEV_EXT_FREQ "freq"
#define O_DEV_EXT_PLATFORM "pf"
#define O_XFF_HEADER	"xff"
#define O_SCREEN_RESOLUTION "res"
#define O_DEVICE_FREQ	"freq"
#define O_DEVICE_PLATFORM "pf"
#define O_DEVICE_LOC_CAT "\"cat\":"
#define O_DEVICE_LOC_BRAND "\"brand\":"
#define O_DEVICE_LOC_CAT_SRC "loccatsrc"
#define O_USER_EXT_GDPR "gdpr"
#define O_USER_EXT_CONSENT "consent"
#define O_GOOGLE_EB_CP_SETTINGS_STRING "\"consented_providers_settings\":{"
#define O_GOOGLE_EB_CP_LIST "consented_providers"

#define CONTYPE_WIFI     "wifi"
#define CONTYPE_CELLULAR "cellular"
#define WIFI_ID          2
#define CELLULAR_ID      3

#define INITIAL_STRING 		"{"
#define END_STRING 		"}"
#define ARR_END_STRING		"]"

#define MAX_DEVICE_IDS		11
#define MAX_ID_LENGTH		15
#define UNKNOWN_ID		"otherdeviceid"
#define ANDROID_ID_TYPE		3
#define UDID_TYPE			4
#define SHA1_HASH 			2
#define MD5_HASH			3
#define O_EXT_REGS       "\"regs\":{"
#define O_EXT_REGS_COPPA "coppa"

#define O_PMP_STRING		"\"pmp\":{"
#define O_PMP_DEALS_STRING	"\"deals\":["
#define O_PMP_PRIVATE_AUCTION	"private_auction"
#define OPEN_AUCTION		0
#define O_DEAL_ID		"id"
#define O_DEAL_BIDFLOOR		"bidfloor"
#define O_DEAL_AT		"at"
#define O_DEAL_WSEAT_ARR	"\"wseat\":["
#define O_DEAL_EXT_ARR	"\"ext\":{"
#define O_DEAL_GUARANTEED_ARR	"guaranteed"

#define START_INDEX		0

//Video Params
#define O_VIDEO_STRING		"\"video\":{"
#define O_VIDEO_MIMES		"\"mimes\":["
#define O_VIDEO_LINEARITY	"linearity"
#define O_VIDEO_MINDURATION  	"minduration"
#define O_VIDEO_MAXDURATION	"maxduration"
#define O_VIDEO_PROTOCOL	"protocol"	
#define O_VIDEO_EXT_PROTOCOLS	"\"protocols\":["
#define O_VIDEO_WIDTH		"w"
#define O_VIDEO_HEIGHT		"h"
#define O_VIDEO_STARTDELAY	"startdelay"
#define O_VIDEO_MINBITRATE	"minbitrate"
#define O_VIDEO_MAXBITRATE	"maxbitrate"
#define O_VIDEO_API		"\"api\":["
#define O_VIDEO_PLAYBACK_JSON_KEY "\"playbackmethod\":["
#define O_VIDEO_PLAYER_HEIGHT "h"
#define O_VIDEO_PLAYER_WIDTH  "w"
#define O_VIDEO_WINDOW_HEIGHT "wndh"
#define O_VIDEO_WINDOW_WIDTH  "wndw"
#define O_VIDEO_AD_HEIGHT     "adh"
#define O_VIDEO_AD_WIDTH      "adw"
#define O_VIDEO_WINDOW_PAGE_URL "wndurl"
#define O_VIDEO_WINDOW_REF_URL  "wndref"
#define O_VIDEO_IFRAME_DEPTH    "depth"
#define O_VIDEO_PLAYER_LOCATION	"ploc"
#define O_VIDEO_VISIBILITY		"pos"
#define O_VIDEO_ASPECT_RATIO		"ar"
#define O_VIDEO_PLAYER_STRETCHING_MODE	"sm"
#define O_VIDEO_LANGUAGE		"vcln"
#define O_VIDEO_SKIP		"skip"
#define O_VIDEO_SKIP_DELAY	"skipdelay"
#define O_VIDEO_NOSKIP_AD_LEN	"noskipadlen"
#define O_VIDEO_FULL_SCREEN_EXPANDABLE "fullscreenexpandable"

#define O_VIDEO_AUDIO_FLAG         "audio"

#define O_CAMPANIONAD_STRING	"\"companionad\":{"
#define O_VIDEO_BANNER_ARR	"\"banner\":[{"

#define O_IMP_DISPLAYMANAGER    "displaymanager"
#define O_IMP_DISPLAYMANAGERVER "displaymanagerver"

#define MAX_STARTDELAY_POS	4
enum openrtb_startdelay_pos { GEN_POST_ROLL = -2, GEN_MID_ROLL, PRE_ROLL};

static const int openrtb_startdelay_mapping[MAX_STARTDELAY_POS] = { PRE_ROLL, PRE_ROLL, GEN_MID_ROLL, GEN_POST_ROLL};
inline static int get_mapped_startdelay(int position) {
	return openrtb_startdelay_mapping[position];
}

#define MAX_MIMES_TYPES		12
static const char *mime_type_map[MAX_MIMES_TYPES] = {"video/mp4","application/x-shockwave-flash",
						    "video/x-ms-wmv","video/h264","video/webm", 
						    "application/javascript", "video/ogg", "video/x-flv",
								"video/3gpp","video/quicktime","video/mpeg","application/x-mpegURL"};

//Device indentifier array	
static const char device_id_map[MAX_DEVICE_IDS][MAX_ID_LENGTH] = {UNKNOWN_ID,"idfa","idfv","androidid","udid",
							      "openudid","secureudid","macaddress","odin1","androidadvid","adtruthid"};


//Convert pubmatic adfold id to openrtb adfold id
#define MAX_AD_POS 		4
enum openrtb_adpos_id {UNKNOWN_POS, ABOVE_THE_FOLD, PARTIAL_VISIBLE, BELOW_THE_FOLD};
//mapping of pubmatic rtb to openrtb. Index in array is pubmatic adfold id and value at that position is openrtb adfold id
static const int openrtb_adpos_mapping[MAX_AD_POS] = {UNKNOWN_POS, ABOVE_THE_FOLD, BELOW_THE_FOLD, ABOVE_THE_FOLD};

inline static int get_openrtb_foldpos(int pubmatic_adpos) {	
	return openrtb_adpos_mapping[pubmatic_adpos];
}

#define NEED_TO_PASS_EXCLUDE_LIST(BLOCKED_LIST, REQ_PARAMS)     ({                      \
        ( (BLOCKED_LIST) != NULL &&                                                                  \
          (((BLOCKED_LIST)->json_blocked_creative_attributes_len > 0 ) ||                  	     \
	   ((BLOCKED_LIST)->json_blocked_iab_advt_categories_len > 0 ) ||			     \
           ((BLOCKED_LIST)->json_blocked_advt_categories_len > 0) ||                             \
           ((BLOCKED_LIST)->json_url_blockedlist_len > 0) ||                                         \
           ((REQ_PARAMS)->blocked_creative_attr[0] != '\0'))                                         \
        );                                                                                           \
})

#define RICH_MEDIA_UNKNOW_AD_EXPANSION_DIR_ID 0
#define MAX_AD_EXPANDION_DIR_STR_LEN 5

//Static pre declarations
static int create_device_geo_object(char **post_data,
									rt_request_params_t *in_request_params,
									ad_server_additional_params_t *additional_parameter,
									bool lat_lon_masking_enabled,
									int is_mob_impression,
									int has_device_params);

static int create_user_geo_object(char **post_data,
									const rt_request_params_t *in_request_params,
									ad_server_additional_params_t *additional_parameter,
									bool lat_lon_masking_enabled,
									//int is_mob_impression,
									int has_user_params);



/* 
 * Function to create OpenRTB PMP Object
 * Returns number of bytes written
 */

static int create_pmp_object( char **post_data, publisher_site_ad_campaign_list_t *adcampaigns,
                              const rt_request_url_params_mask_t * rt_request_url_params_mask1,
                              fte_additional_params_t *fte_additional_parameters ) {
	char *post_temp_ptr = NULL;
	int i = 0, j = 0, wseat_count = 0;
	int bytes_written = 0;
	dsp_buyer_t **applicable_dsp_buyers = NULL;
	//deal_params_t *prev_applicable_deal = NULL;
	int counter = 0;
	post_temp_ptr = *post_data;
	applicable_dsp_buyers = adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers;
	

	/*PMP OBJECT START*/
	json_append_value_string(&post_temp_ptr, O_PMP_STRING, DONT_ADD_COMMA);
	json_append_int(&post_temp_ptr, O_PMP_PRIVATE_AUCTION, OPEN_AUCTION, DONT_ADD_COMMA, DONT_ADD_QUOTE);
		/*PMP DEAL OBJECT START*/
	json_append_value_string(&post_temp_ptr, O_PMP_DEALS_STRING, ADD_COMMA);
	for (i = 0; i < adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers_count && counter < fte_additional_parameters->publisher_level_settings.max_deal_count_in_bidreq; i++) {

                /*Check deal_type, it can be either 1 (for ATOM/pub connect) or 0 (for PMP deal) 
                * if deal_type != 0 skip till ATOM integration is done
                */

		if (applicable_dsp_buyers[i]->parent_deal_params->deal_type != PMP_DEAL) {
			continue;
		}
	/*	if (rt_request_url_params_mask1->buyer_id_passing_enable_flag == 0) {
                	if (    prev_applicable_deal == NULL || prev_applicable_deal != applicable_dsp_buyers[i]->parent_deal_params) {
                                prev_applicable_deal = applicable_dsp_buyers[i]->parent_deal_params;
                        }
                        else {
                                //Skip adding duplicate Deal objects.
                                continue;
                        }
			
                }
		*/

		if (applicable_dsp_buyers[i]->in_rtb_request == ADDED_IN_RTB_REQUEST){
				continue;
		}

		__sync_fetch_and_add(&( (deal_stats_t*)applicable_dsp_buyers[i]->parent_deal_params->p_stats)->sent_to_dsp, 1 ) ;

		json_append_value_string(&post_temp_ptr, INITIAL_STRING, counter != START_INDEX); //for first element, dont add comma
		json_append_string(&post_temp_ptr, O_DEAL_ID, applicable_dsp_buyers[i]->parent_deal_params->pub_deal_id, DONT_ADD_COMMA);
		json_append_double(&post_temp_ptr, O_DEAL_BIDFLOOR, CONVERT_USD_TO_NATIVE_CURRENCY(applicable_dsp_buyers[i]->deal_ecpm_usd,
					adcampaigns->dsp_currency_id,
					fte_additional_parameters->currency_xrate_map,
					fte_additional_parameters->currency_count),
				ADD_COMMA, DONT_ADD_QUOTE);
		
		if (rt_request_url_params_mask1->buyer_id_passing_enable_flag == 1) {

			if (applicable_dsp_buyers[i]->dsp_buyer_id != DEFAULT_DSP_BUYER_ID ){
				json_append_value_string(&post_temp_ptr, O_DEAL_WSEAT_ARR, ADD_COMMA);
				wseat_count = 0;	
				json_append_value_int(&post_temp_ptr, applicable_dsp_buyers[i]->dsp_buyer_id, wseat_count!= START_INDEX, ADD_QUOTE);
				wseat_count++;
			}
			for (j = i + 1 ; j < adcampaigns->ad_campaign_list_setings->applicable_dsp_buyers_count; j++){

				if (applicable_dsp_buyers[i]->in_rtb_request == ADDED_IN_RTB_REQUEST){
					continue;
				}

				if (strncmp(applicable_dsp_buyers[i]->parent_deal_params->pub_deal_id, applicable_dsp_buyers[j]->parent_deal_params->pub_deal_id, MAX_DEAL_ID_LEN) != 0){
					break;
				}
				if (applicable_dsp_buyers[i]->parent_deal_params == applicable_dsp_buyers[j]->parent_deal_params || 
						(applicable_dsp_buyers[i]->deal_ecpm_usd == applicable_dsp_buyers[j]->deal_ecpm_usd &&
						applicable_dsp_buyers[i]->parent_deal_params->auction_id == applicable_dsp_buyers[j]->parent_deal_params->auction_id)){
					if (applicable_dsp_buyers[i]->dsp_buyer_id != DEFAULT_DSP_BUYER_ID && 
							applicable_dsp_buyers[j]->dsp_buyer_id != DEFAULT_DSP_BUYER_ID) {	
						json_append_value_int(&post_temp_ptr, applicable_dsp_buyers[j]->dsp_buyer_id, wseat_count!= START_INDEX, ADD_QUOTE);
						wseat_count++;
					}
					applicable_dsp_buyers[j]->in_rtb_request = ADDED_IN_RTB_REQUEST;
				}
			}

			if (applicable_dsp_buyers[i]->dsp_buyer_id != DEFAULT_DSP_BUYER_ID ){
				json_append_value_string(&post_temp_ptr, ARR_END_STRING, DONT_ADD_COMMA);
			}
		}
		json_append_int(&post_temp_ptr, O_DEAL_AT, applicable_dsp_buyers[i]->parent_deal_params->auction_id, 
				ADD_COMMA, DONT_ADD_QUOTE);

		if( applicable_dsp_buyers[i]->parent_deal_params->deal_channel_type_id == DEAL_CHANNEL_TYPE_PMPG )
		{
						json_append_value_string(&post_temp_ptr, O_DEAL_EXT_ARR, ADD_COMMA);

						json_append_int(&post_temp_ptr, O_DEAL_GUARANTEED_ARR, 1, 
														DONT_ADD_COMMA, DONT_ADD_QUOTE);

						json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);//O_DEAL_EXT_ARR end
		}

		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);

		counter++;
	}
		/*PMP DEAL OBJECT END*/
	json_append_value_string(&post_temp_ptr, ARR_END_STRING, DONT_ADD_COMMA);
	/*PMP OBJECT END*/
	json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
	bytes_written=(post_temp_ptr)-(*post_data);
	OPENRTB_DEBUG("PMP Object size:%d",bytes_written);
	(*post_data)=post_temp_ptr;

	// Add stats for alert in case when number of deal passed to campaign has reached to fte_additional_parameters->publisher_level_settings.max_deal_count_in_bidreq
        if ( counter >= fte_additional_parameters->publisher_level_settings.max_deal_count_in_bidreq){
           	increment_stats_counters(&(fte_additional_parameters->libstat_counters[0]), 
					RTB_MAX_DEAL_VIOLATION_COUNT_ID, adcampaigns->campaign_id);
                //llog_write(L_DEBUG, "\nALERT: fte_additional_parameters->publisher_level_settings.max_deal_count_in_bidreq limit hit for ad_id:%lu, campaign_id:%u, dsp_id:%u\n",
				LOG_CRITICAL(MAX_DEAL_OBJ_LIMIT_HIT,MOD_DEFAULT,
                                adcampaigns->ad_id, adcampaigns->campaign_id, adcampaigns->dp_id);
        }
	return bytes_written;
}


/*
 * Function to create openrtb video request object 
 */
static void create_video_object( char **post_data,  ad_server_req_param_t*  in_request_params, memcached_blocklist_t *blocked_list,
				 const rt_request_url_params_mask_t * rt_request_url_params_mask1, 
				 const ad_server_req_param_t* req_params, char **temp_ptr) {

	(void) rt_request_url_params_mask1;
	char* post_temp_ptr = (*post_data);
	int bytes_written = 0 , i = 0;
	int has_video_ext = 0;
	 video_param_t *video_params = &in_request_params->video_params;


	/* VIDEO OBJECT START*/
	json_append_value_string(&post_temp_ptr, O_VIDEO_STRING, ADD_COMMA);

        if(video_params->stream_format[0] == FLAG_SET){
                json_append_value_string( &post_temp_ptr, O_VIDEO_MIMES, DONT_ADD_COMMA);
                for(i=1; i<=MAX_STREAM_FORMAT_ID; i++){
                        if(video_params->stream_format[i] == FLAG_SET){
                                post_temp_ptr += sprintf(post_temp_ptr, "\"%s\",", mime_type_map[i - 1] );
                                //-1 is used since streamFmt in PubMatic RTB starts from 1 whereas map starts from 0
                        }
                }
                post_temp_ptr--;
                memcpy(post_temp_ptr, ARR_END_STRING , 1);
                post_temp_ptr += 1;
        }
	else{
		json_append_value_string( &post_temp_ptr, O_VIDEO_MIMES, DONT_ADD_COMMA);
		//no mime type found.. send all possible since it is required field in OpenRTB
                for ( i = 0; i < MAX_MIMES_TYPES; i++ ) {
                        bytes_written = sprintf(post_temp_ptr, "\"%s\",", mime_type_map[i] );
                        post_temp_ptr += bytes_written;
                }
                post_temp_ptr--;
                memcpy(post_temp_ptr, ARR_END_STRING, 1);
                post_temp_ptr += 1;
	}

	if( video_params->type != VIDEO_AD_TYPE_LINEAR && video_params->type != VIDEO_AD_TYPE_OVERLAY ){
		//if type not found then send it as LINEAR as it is mandatory in OpenRTB
		json_append_int(&post_temp_ptr, O_VIDEO_LINEARITY, VIDEO_AD_TYPE_LINEAR, ADD_COMMA, DONT_ADD_QUOTE);
	} else {
		json_append_int(&post_temp_ptr, O_VIDEO_LINEARITY, video_params->type, ADD_COMMA, DONT_ADD_QUOTE);
	}
       
	json_append_int(&post_temp_ptr, O_VIDEO_MINDURATION, video_params->min_length, ADD_COMMA, DONT_ADD_QUOTE);
	json_append_int(&post_temp_ptr, O_VIDEO_MAXDURATION, video_params->max_length, ADD_COMMA, DONT_ADD_QUOTE);

	//VAST 2.0 as it is mandatory in OpenRTB
	json_append_int(&post_temp_ptr, O_VIDEO_PROTOCOL, video_params->ad_format_version, ADD_COMMA, DONT_ADD_QUOTE);
	
	if( video_params->position >= MIN_VIDEO_POSITION_VALUE && video_params->position <= MAX_VIDEO_POSITION_VALUE ){
		json_append_int(&post_temp_ptr, O_VIDEO_STARTDELAY, get_mapped_startdelay(video_params->position), ADD_COMMA, DONT_ADD_QUOTE);
       	}

        if (NEED_TO_PASS_EXCLUDE_LIST(blocked_list, req_params)) {
		if ( req_params->blocked_creative_attr[0] != '\0' ) {
			json_append_value_string(&post_temp_ptr, O_BATTR_ARR, ADD_COMMA);
			memcpy(post_temp_ptr, req_params->blocked_creative_attr, req_params->battr_len);
			post_temp_ptr += req_params->battr_len;

		} else if ( blocked_list->json_blocked_creative_attributes_len > 0 ) {
                        json_append_value_string(&post_temp_ptr, O_BATTR_ARR, ADD_COMMA);
                        memcpy(post_temp_ptr, *temp_ptr, blocked_list->json_blocked_creative_attributes_len);
                        post_temp_ptr += blocked_list->json_blocked_creative_attributes_len;
                }
                *temp_ptr += (blocked_list->json_blocked_creative_attributes_len + 4);
        }

	if ( video_params->min_bit_rate > 0) {
		json_append_int(&post_temp_ptr, O_VIDEO_MINBITRATE, video_params->min_bit_rate, ADD_COMMA, DONT_ADD_QUOTE);
	}
	if ( video_params->max_bit_rate > 0) {
		json_append_int(&post_temp_ptr, O_VIDEO_MAXBITRATE, video_params->max_bit_rate, ADD_COMMA, DONT_ADD_QUOTE);
	}
	
                //playback is optional
        if(video_params->playback[0] == FLAG_SET){

                json_append_value_string(&post_temp_ptr, O_VIDEO_PLAYBACK_JSON_KEY , ADD_COMMA);

                for(i=1; i<=MAX_VIDEO_PLAYBACK_ID; i++){
                	if(video_params->playback[i] == FLAG_SET){
                         	post_temp_ptr += sprintf(post_temp_ptr, "%d,", i);
                        }
                }
                post_temp_ptr--;
                memcpy(post_temp_ptr, ARR_END_STRING , 1);
               	post_temp_ptr += 1;

        }


	if( video_params->has_companion == 1 ) {
		/* VIDEO COMPANION OBJECT START*/
		json_append_value_string(&post_temp_ptr, O_CAMPANIONAD_STRING, ADD_COMMA);
			/* VIDEO COMPANIONAD BANNER OBJECT START*/
		json_append_value_string(&post_temp_ptr, O_VIDEO_BANNER_ARR, DONT_ADD_COMMA);

		if ( video_params->companion_width > 0 ) {
        		json_append_int(&post_temp_ptr, O_IMP_WD, video_params->companion_width, DONT_ADD_COMMA, DONT_ADD_QUOTE);
		}
		if ( video_params->companion_height > 0 ) {
        		json_append_int(&post_temp_ptr, O_IMP_HT, video_params->companion_height, ADD_COMMA, DONT_ADD_QUOTE);
		}
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		json_append_value_string(&post_temp_ptr, ARR_END_STRING, DONT_ADD_COMMA);
			/* VIDEO COMPANIONAD BANNER OBJECT END*/
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		/* VIDEO COMPANION OBJECT END*/
	}

	
	if(FLAG_SET == video_params->vid_api_array[0]){
		json_append_value_string(&post_temp_ptr, O_VIDEO_API , ADD_COMMA);
		for(i=1; i<=MAX_VAPI_FORMAT_ID; i++){
			if(FLAG_SET == video_params->vid_api_array[i]){
				post_temp_ptr += sprintf(post_temp_ptr, "%d,", i);
			}
		}
		post_temp_ptr--;
		memcpy(post_temp_ptr, ARR_END_STRING , 1);
		post_temp_ptr += 1;
	} else if ( API_VPAID_1_0 == video_params->vid_api || API_VPAID_2_0 == video_params->vid_api) {
		json_append_value_string(&post_temp_ptr, O_VIDEO_API , ADD_COMMA);
		post_temp_ptr += sprintf(post_temp_ptr, "%d,",video_params->vid_api);
		post_temp_ptr--;
		memcpy(post_temp_ptr, ARR_END_STRING , 1);
		post_temp_ptr += 1;

	}

        if(video_params->player_height > 0){
                json_append_int(&post_temp_ptr, O_VIDEO_PLAYER_HEIGHT, video_params->player_height, ADD_COMMA, DONT_ADD_QUOTE);
        }

        if(video_params->player_width > 0){
                json_append_int(&post_temp_ptr, O_VIDEO_PLAYER_WIDTH, video_params->player_width, ADD_COMMA, DONT_ADD_QUOTE);
        }

        if( in_request_params->s_fold_position_id > MIN_FOLD_POS_VALUE && in_request_params->s_fold_position_id <= MAX_FOLD_POS_VALUE ){
                json_append_int(&post_temp_ptr, O_VIDEO_VISIBILITY, get_openrtb_foldpos(in_request_params->s_fold_position_id), ADD_COMMA, DONT_ADD_QUOTE);
                has_video_ext = 1;

        }

	has_video_ext = 0;
	json_append_value_string(&post_temp_ptr, O_EXT_STRING, ADD_COMMA);

	/*
	 *  This will add protocols array to protocols field.
	 */
	if(FLAG_SET == video_params->vid_protocols_array[0]) {
		int retval = VIDEO_RETURN_SUCCESS;
		retval = video_append_protocols(&post_temp_ptr, O_VIDEO_EXT_PROTOCOLS,
				video_params->vid_protocols_array, DONT_ADD_COMMA);
		if(VIDEO_RETURN_SUCCESS == retval){
			has_video_ext = 1;
		}
		else{
			VIDEO_DEBUG("ERROR in appending protocols array to campaign buffer, protocols = %s", video_params->vid_protocols_array);
		}
	}

	if(video_params->window_height > 0){
		json_append_int(&post_temp_ptr, O_VIDEO_WINDOW_HEIGHT, video_params->window_height, has_video_ext, DONT_ADD_QUOTE);
		has_video_ext = 1;
	}

	if(video_params->window_width > 0){
		json_append_int(&post_temp_ptr, O_VIDEO_WINDOW_WIDTH, video_params->window_width, has_video_ext, DONT_ADD_QUOTE);
		has_video_ext = 1;
	}

	if(video_params->video_ad_height > 0){
		json_append_int(&post_temp_ptr, O_VIDEO_AD_HEIGHT, video_params->video_ad_height, has_video_ext, DONT_ADD_QUOTE);
		has_video_ext = 1;
	}

	if(video_params->video_ad_width > 0){
		json_append_int(&post_temp_ptr, O_VIDEO_AD_WIDTH, video_params->video_ad_width, has_video_ext, DONT_ADD_QUOTE);
		has_video_ext = 1;
	}

	if(in_request_params->iframe_depth >= 0){
		json_append_int(&post_temp_ptr, O_VIDEO_IFRAME_DEPTH, in_request_params->iframe_depth, has_video_ext, DONT_ADD_QUOTE);
		has_video_ext = 1;
	}

	if(video_params->video_page_url[0] != '\0'){
		json_append_escaped_string(&post_temp_ptr, O_VIDEO_WINDOW_PAGE_URL, video_params->video_page_url, has_video_ext, MAX_PAGE_URL_SIZE);
		has_video_ext = 1;
	}

	if(video_params->video_ref_url[0] != '\0'){
		json_append_escaped_string(&post_temp_ptr, O_VIDEO_WINDOW_REF_URL, video_params->video_ref_url, has_video_ext, MAX_PAGE_URL_SIZE);
		has_video_ext = 1;
	}

        if( in_request_params->ad_position != NULL && in_request_params->ad_position[0] != '\0' ){
		json_append_string(&post_temp_ptr, O_VIDEO_PLAYER_LOCATION, in_request_params->ad_position, has_video_ext);
		has_video_ext = 1;

        }

        if( video_params->aspect_ratio[0] != '\0' ){
                json_append_string(&post_temp_ptr, O_VIDEO_ASPECT_RATIO, video_params->aspect_ratio, has_video_ext);
                has_video_ext = 1;
        }

        if( video_params->player_stretching_mode > 0 ){
		json_append_int(&post_temp_ptr, O_VIDEO_PLAYER_STRETCHING_MODE, video_params->player_stretching_mode, has_video_ext, DONT_ADD_QUOTE);
		has_video_ext = 1;

        }

        if( video_params->language[0] != '\0' ){
                json_append_string(&post_temp_ptr, O_VIDEO_LANGUAGE, video_params->language, has_video_ext);
                has_video_ext = 1;
        }

	if( video_params->skip == 1 ) {
		json_append_int(&post_temp_ptr, O_VIDEO_SKIP, video_params->skip, has_video_ext, DONT_ADD_QUOTE);
		has_video_ext = 1;
		json_append_int(&post_temp_ptr, O_VIDEO_SKIP_DELAY, video_params->skip_delay, has_video_ext, DONT_ADD_QUOTE);
		json_append_int(&post_temp_ptr, O_VIDEO_NOSKIP_AD_LEN, video_params->noskip_ad_len, has_video_ext, DONT_ADD_QUOTE);
	}

	if(video_params->full_screen_expandable >= 0){
		json_append_int(&post_temp_ptr, O_VIDEO_FULL_SCREEN_EXPANDABLE, video_params->full_screen_expandable, has_video_ext, DONT_ADD_QUOTE);
		has_video_ext = 1;
	}

	if( video_params->audio == TRUE ){
		json_append_int(&post_temp_ptr, O_VIDEO_AUDIO_FLAG, TRUE, has_video_ext, DONT_ADD_QUOTE);
		has_video_ext = 1;
	}

	if (has_video_ext == 0) {
		post_temp_ptr -= sizeof(O_EXT_STRING); //sizeof returns strlen +1, +1 is added to remove last comma
	} else {
		/*EXT OBJECT END*/
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
	}

	json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
	(*post_data)=post_temp_ptr;
	return;	
}


/* create_imp_ext_object
 * ---------------------
 * Create the Extension Object for the Impression Object in the OpenRTB 2.3
 * Bid Request.
 * Inputs/Outputs:
 * - post_data (inout): Pointer to the current position in the Bid Request
 *   object
 * - additional_params (in)
 * Returns: ADS Error Code
 *
 * XXX: This function appends a comma before appending the ext object
 */
static int create_imp_ext_object(
	char** post_data,
	const ad_server_additional_params_t* additional_params,
	const rt_request_params_t* in_request_params,
	const rt_request_url_params_mask_t* rt_request_url_params_mask1
) {
	int rv =
		NULL != post_data &&
		NULL != additional_params;
	if (!rv) {
		llog_write(L_DEBUG, "ERROR:openrtb:2.3:Invalid arguments:%s:%d\n", __FILE__, __LINE__);
		return ADS_ERROR_INVALID_ARGS;
	}

	const int IMP_EXT_TRUE = 1, IMP_EXT_FALSE = 0;
	int append_imp_ext_object = IMP_EXT_FALSE;
	char* post_temp_ptr = *post_data;

	/* Start .imp.ext object */
	json_append_value_string(&post_temp_ptr, O_IMP_EXT_START, ADD_COMMA);


	//add secure flag 
	if (rt_request_url_params_mask1->use_secure_params == 1 &&
			in_request_params->fte_additional_params->is_https_request_flag == 1) {
		int should_add_comma =
			IMP_EXT_TRUE == append_imp_ext_object ? ADD_COMMA : DONT_ADD_COMMA;

		json_append_int(&post_temp_ptr, O_IMP_SEC, in_request_params->fte_additional_params->is_https_request_flag,
				should_add_comma, DONT_ADD_QUOTE);
		append_imp_ext_object = IMP_EXT_TRUE;
	}


	if (IS_NATIVE_REQUEST) {
		int should_add_comma =
			IMP_EXT_TRUE == append_imp_ext_object ? ADD_COMMA : DONT_ADD_COMMA;

		// TODO: Get this reviewed
		json_append_value_string(&post_temp_ptr, O_NATIVE_STRING, should_add_comma);
		if (NEED_TO_CHANGE_NATIVE_IMAGE_TYPE(rt_request_url_params_mask1, additional_params)) {
			OPENRTB_DEBUG("Changing Native img icon asset to logo.");
			char *native_obj = strdup(in_request_params->in_server_req_params->native_asset);
			if (NULL != native_obj) {
				replace_native_img_icon_asset_type(native_obj);
				json_append_value_string(&post_temp_ptr, native_obj, DONT_ADD_COMMA);
				free(native_obj);
			} else {
				OPENRTB_ERROR("Failed to change Native img icon asset to logo.");
				json_append_value_string(&post_temp_ptr, in_request_params->in_server_req_params->native_asset, DONT_ADD_COMMA);
			}
		} else {
			json_append_value_string(&post_temp_ptr, in_request_params->in_server_req_params->native_asset, DONT_ADD_COMMA);
		}

		append_imp_ext_object = IMP_EXT_TRUE;
	}


	/* Append .imp.ext.headerbidding (Header Bidding Extention) Object */
	if (1 == in_request_params->in_server_req_params->site_ad->multi_level_auction_enabled){
		int should_add_comma =
			IMP_EXT_TRUE == append_imp_ext_object ? ADD_COMMA : DONT_ADD_COMMA;

		// Start .imp.ext.headerbidding (Header Bidding Extention) Object 
		json_append_value_string(&post_temp_ptr, O_IMP_EXT_HBE_START, should_add_comma);

		// Append .imp.ext.headerbidding.present 
		json_append_int(
			&post_temp_ptr,
			O_IMP_EXT_HBE_PRESENT,
			in_request_params->in_server_req_params->site_ad->multi_level_auction_enabled,
			DONT_ADD_COMMA,
			DONT_ADD_QUOTE
		);

		// End .imp.ext.headerbidding (Header Bidding Extention) Object 
		json_append_value_string(&post_temp_ptr, O_IMP_EXT_HBE_END, DONT_ADD_COMMA);

		append_imp_ext_object = IMP_EXT_TRUE;
	}

	/* End .imp.ext object */
	json_append_value_string(&post_temp_ptr, O_IMP_EXT_END, DONT_ADD_COMMA);

	if (IMP_EXT_TRUE == append_imp_ext_object) {
		*post_data = post_temp_ptr;
	}
	return ADS_ERROR_SUCCESS;
}


/*
 * Function to create openrtb request json object
 * Return value: Length of the post data
 */

void add_ip_in_openrtb_device(char** post_data,
			rt_request_params_t *in_request_params,
			bool ip_masking_enabled,
			int has_device_params
){
	char* post_temp_ptr=(*post_data);
	int is_ipv4 = is_ipv4_address(in_request_params->ad_server_req_gen_params->remote_ip_addr);
	if(1 == ip_masking_enabled){
		//If ip address is ipv4 pass in ip else in ipv6
		add_ip_in_json(&post_temp_ptr, is_ipv4, in_request_params->ad_server_req_gen_params->masked_ip_addr, has_device_params);
	}
	else{
		add_ip_in_json(&post_temp_ptr, is_ipv4, in_request_params->ad_server_req_gen_params->remote_ip_addr, has_device_params);
	}
	(*post_data)=post_temp_ptr;
	return;
}


static int get_openrtb_request_object(char* post_data,
                           campaign_data_provider_data_ops_params_t *cmpg_dp_params,
                           rt_request_params_t *in_request_params,
                           const rt_request_url_params_mask_t * rt_request_url_params_mask1,
                           ad_server_additional_params_t *additional_parameter,
                           publisher_site_ad_campaign_list_t *adcampaign,
			   publisher_site_t *site,
			   rt_response_params_t *out_response_params,
			   const char * badv_domain_json) {

	(void) out_response_params;
	char* post_temp_ptr=post_data;
	publisher_site_ad_rich_media_params_t *pub_site_rich_media_params = in_request_params->pub_site_rich_media_params;
	memcached_blocklist_t *blocked_list;
	integral_data_t *integral_data;
	//temp geo parameters
	char* temp_ptr = NULL;
	char tmp_ref_url[MAX_URL_LENGTH];     //to store decode refurl
	int dpid_type = 0;
	int has_user_params = 0;
	int has_device_params = 0;
	int has_ext_params = 0;
	int has_app_params = 0;
	int bytes_written = 0;
	bool ip_masking_enabled = adcampaign->ad_campaign_list_setings->ip_masking_enabled;
	//To avoid unused variable warning
	(void)cmpg_dp_params;

	tmp_ref_url[0] = '\0';

	mobile_param_stats_t* mobile_param_flags = &(additional_parameter->mobile_param_flags);
	(void)mobile_param_flags;
	int enable_app_geo_mstats_flag =	additional_parameter->enable_app_geo_mstats_flag;
	//float lat = 0.0, lon = 0.0, count = 0;
	const ad_server_req_param_t* req_params = in_request_params->in_server_req_params;

	int is_mob_impression = 0;
        if (
                in_request_params->in_server_req_params->is_mobile_device == MOBILE_INVENTORY
                ||
                in_request_params->in_server_req_params->mobile_request_type == ADS_MOB_WEB_REQUEST
                ||
                in_request_params->in_server_req_params->mobile_request_type == ADS_MOB_APP_REQUEST
        ) {
			is_mob_impression = 1;
		}


	integral_data=&(in_request_params->fte_additional_params->integral_data);
	blocked_list = pub_site_rich_media_params->blocked_list; 
	temp_ptr = (blocked_list != NULL)? (blocked_list->json_url_blocked_list + 4): NULL;

	json_append_value_string(&post_temp_ptr, INITIAL_STRING, DONT_ADD_COMMA);

	in_request_params->replace_info[RT_REQUEST_ID].start = post_temp_ptr;
	json_append_string(&post_temp_ptr, O_ID, in_request_params->request_url_params.request_id[0], DONT_ADD_COMMA);
	in_request_params->replace_info[RT_REQUEST_ID].end = post_temp_ptr;

	//add auction type. No need to pass if auction type is second price (default)
	double mu;
	mu = (rt_request_url_params_mask1->second_price_auction == 0) ? 1.0 :
		Get_mu(in_request_params->in_server_req_params->publisher_id, IS_PUBLISHER_FPMLA(in_request_params->fte_additional_params->publisher_auction_type)?1:0, adcampaign->campaign_id);

	if (in_request_params->fte_additional_params->pricing_global_params.mu_threshold <= mu && mu <= 1) {
		json_append_int(&post_temp_ptr, O_AT, AUCTION_TYPE_FIRST_PRICE, ADD_COMMA, DONT_ADD_QUOTE);
		out_response_params->open_auction_type = AUCTION_TYPE_FIRST_PRICE;
	}
	else {
		out_response_params->open_auction_type = AUCTION_TYPE_SECOND_PRICE;
	}

	if ((1 == in_request_params->fte_additional_params->publisher_level_settings.tmax_enabled) &&
		(1 == adcampaign->db_flag_settings.send_tmax_in_request)) {
		json_append_int(&post_temp_ptr, O_TMAX, additional_parameter->rtb_timeout, ADD_COMMA, DONT_ADD_QUOTE);
	}

	/*IMP ARRAY START*/
	json_append_value_string(&post_temp_ptr, O_IMP_STRING, ADD_COMMA);

		/*IMP OBJ START*/
	json_append_value_string(&post_temp_ptr, INITIAL_STRING, DONT_ADD_COMMA);
	
	json_append_string(&post_temp_ptr, O_IMP_ID, DEFAULT_IMP_ID, DONT_ADD_COMMA);
	if((int)in_request_params->in_server_req_params->intl == 1) { //if not default value, send to DSP
		json_append_int(&post_temp_ptr, O_IMP_INTL, (int)in_request_params->in_server_req_params->intl, ADD_COMMA,	DONT_ADD_QUOTE);
	}
	json_append_int(&post_temp_ptr, O_TAGID, (int)in_request_params->in_server_req_params->ad_id, ADD_COMMA, ADD_QUOTE);
	
	/* Append displaymanager and displaymanagerver */
		
	if ('\0' != in_request_params->in_server_req_params->displaymanager[0]) {
		json_append_escaped_string(&post_temp_ptr, O_IMP_DISPLAYMANAGER, in_request_params->in_server_req_params->displaymanager, ADD_QUOTE,DEFAULT_LEN_64);
	}

	if ('\0' != in_request_params->in_server_req_params->displaymanagerver[0]) {
		json_append_escaped_string(&post_temp_ptr, O_IMP_DISPLAYMANAGERVER,	in_request_params->in_server_req_params->displaymanagerver,	ADD_QUOTE,DEFAULT_LEN_64);
	}
	

	//if DSP hardfloor flag(send_hardfloor) is enabled, send hardfloor to DSP
	//P1-dynamic hardfloor, P2-hardfloor from DB, P3- don't send
	if(rt_request_url_params_mask1->send_hardfloor == 1) {
		if(adcampaign->ad_campaign_list_setings->camp_rtb_floor > 0.0000 &&	adcampaign->ad_campaign_list_setings->camp_rtb_floor < 999) {
			json_append_double(&post_temp_ptr, O_IMP_FLOOR,
					CONVERT_USD_TO_NATIVE_CURRENCY(adcampaign->ad_campaign_list_setings->camp_rtb_floor,
					adcampaign->dsp_currency_id,
					in_request_params->fte_additional_params->currency_xrate_map,
					in_request_params->fte_additional_params->currency_count),
					ADD_COMMA, DONT_ADD_QUOTE);
			//Send the currency with hard floor
			if (adcampaign->dsp_currency_id != USD_CURRENCY_ID) {
				json_append_string(&post_temp_ptr, O_IMP_CURRENCY, GET_CURRENCY_CODE_FROM_ID(adcampaign->dsp_currency_id,
							in_request_params->fte_additional_params->currency_xrate_map,
							in_request_params->fte_additional_params->currency_count), 1);
			}
		}
	}
	if ( req_params->rich_media_technologies[0] != '\0' ) {
		json_append_value_string(&post_temp_ptr, O_IFRAME_BUSTER, ADD_COMMA);
		json_append_value_string(&post_temp_ptr, req_params->rich_media_technologies, DONT_ADD_COMMA);
	}
			/*BANNER START*/

	if ( in_request_params->in_server_req_params->oper_id !=SERV_ADS_VIDEO_OPER ) {
	json_append_value_string(&post_temp_ptr, O_BANNER_STRING, ADD_COMMA);
	if (IS_NATIVE_REQUEST) {
		json_append_int(&post_temp_ptr, O_IMP_WD, 0, DONT_ADD_COMMA, DONT_ADD_QUOTE);
		json_append_int(&post_temp_ptr, O_IMP_HT, 0, ADD_COMMA, DONT_ADD_QUOTE);
		//Bug fix.. even though we are not sending battr, skip pointer by 4 as entire blocklist object is serialized
		if (NEED_TO_PASS_EXCLUDE_LIST(blocked_list, req_params)) {
			temp_ptr += (blocked_list->json_blocked_creative_attributes_len + 4);
		}
	} else {
	in_request_params->replace_info[RT_AD_SIZE].start = post_temp_ptr;
	json_append_int(&post_temp_ptr, O_IMP_WD, in_request_params->in_server_req_params->ad_width, DONT_ADD_COMMA, DONT_ADD_QUOTE);
	json_append_int(&post_temp_ptr, O_IMP_HT, in_request_params->in_server_req_params->ad_height, ADD_COMMA, DONT_ADD_QUOTE);
	in_request_params->replace_info[RT_AD_SIZE].end = post_temp_ptr;

	//fold position
	if ((in_request_params->in_server_req_params->s_fold_position_id > MIN_FOLD_POS_VALUE) &&
            (in_request_params->in_server_req_params->s_fold_position_id <= MAX_FOLD_POS_VALUE)) {
		json_append_int(&post_temp_ptr, O_IMP_FOLDPOS,get_openrtb_foldpos(in_request_params->in_server_req_params->s_fold_position_id),
				ADD_COMMA, DONT_ADD_QUOTE);
	}

	if ( in_request_params->in_server_req_params->inIframe == 1 ) {
		json_append_int(&post_temp_ptr, O_IMP_TOPFRAME, 0, ADD_COMMA, DONT_ADD_QUOTE);
	} else {
		json_append_int(&post_temp_ptr, O_IMP_TOPFRAME, 1, ADD_COMMA, DONT_ADD_QUOTE);
	}

	if ( req_params->ad_expansion_direction[0] != '\0' ) {
		json_append_value_string(&post_temp_ptr, O_EXPDIR, ADD_COMMA);
		json_append_value_string(&post_temp_ptr, req_params->ad_expansion_direction, DONT_ADD_COMMA);
	}
	

	if (NEED_TO_PASS_EXCLUDE_LIST(blocked_list, req_params)) {
		if ( req_params->blocked_creative_attr[0] != '\0' ) {
			json_append_value_string(&post_temp_ptr, O_BATTR_ARR, ADD_COMMA);
			memcpy(post_temp_ptr, req_params->blocked_creative_attr, req_params->battr_len);
			post_temp_ptr += req_params->battr_len;
                } else if ( blocked_list->json_blocked_creative_attributes_len > 0 ) {
			json_append_value_string(&post_temp_ptr, O_BATTR_ARR, ADD_COMMA);
                      	memcpy(post_temp_ptr, temp_ptr, blocked_list->json_blocked_creative_attributes_len);
                      	post_temp_ptr += blocked_list->json_blocked_creative_attributes_len;
               	}
            	temp_ptr += (blocked_list->json_blocked_creative_attributes_len + 4);
	}
	
	if (in_request_params->in_server_req_params->mobile_request_type == ADS_MOB_APP_REQUEST) {
		if (in_request_params->in_server_req_params->mobile_data.application_api[0] != '\0') {
			json_append_value_string(&post_temp_ptr, O_BANNER_API_ARR, ADD_COMMA);
			memcpy(post_temp_ptr, in_request_params->in_server_req_params->mobile_data.application_api, strlen(in_request_params->in_server_req_params->mobile_data.application_api));
			post_temp_ptr += strlen(in_request_params->in_server_req_params->mobile_data.application_api);
		}
	}
	/*BANNER EXT START*/
	has_ext_params = 0;
	json_append_value_string(&post_temp_ptr, O_EXT_STRING, ADD_COMMA);

	if((in_request_params->in_server_req_params->ad_size_limit.wmin>0) &&
	   (in_request_params->in_server_req_params->ad_size_limit.wmax>0) &&
	   (in_request_params->in_server_req_params->ad_size_limit.hmin>0) &&
	   (in_request_params->in_server_req_params->ad_size_limit.hmax>0)){
	  json_append_int(&post_temp_ptr, O_MIN_WD, in_request_params->in_server_req_params->ad_size_limit.wmin, has_ext_params, DONT_ADD_QUOTE);
	  has_ext_params = 1;
	  json_append_int(&post_temp_ptr, O_MIN_HT, in_request_params->in_server_req_params->ad_size_limit.hmin, has_ext_params, DONT_ADD_QUOTE);
	  json_append_int(&post_temp_ptr, O_MAX_WD, in_request_params->in_server_req_params->ad_size_limit.wmax, has_ext_params, DONT_ADD_QUOTE);
	  json_append_int(&post_temp_ptr, O_MAX_HT, in_request_params->in_server_req_params->ad_size_limit.hmax, has_ext_params, DONT_ADD_QUOTE);
	}

	if (has_ext_params == 0) {
	  post_temp_ptr -= sizeof(O_EXT_STRING); //sizeof returns strlen +1, +1 is added to remove last comma
	} else {
	  /*SITE EXT OBJECT END*/
	  json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
	}
	/*BANNER EXT END*/
	}
	json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
	/*BANNER END*/
	}
	else {	// Impression is Video. Create video object
		create_video_object(&post_temp_ptr, in_request_params->in_server_req_params,
				    blocked_list, rt_request_url_params_mask1, req_params, &temp_ptr);
	}

	/* Append .imp.ext object */
	create_imp_ext_object(
		&post_temp_ptr,
		additional_parameter,
		in_request_params,
		rt_request_url_params_mask1
	);

	json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
	/*IMP OBJ END*/

	json_append_value_string(&post_temp_ptr, O_IMP_STRING_END, DONT_ADD_COMMA);	
	/*IMP ARRAY END*/

	if (in_request_params->in_server_req_params->mobile_request_type != ADS_MOB_APP_REQUEST) {
		/*SITE OBJ START*/
		json_append_value_string(&post_temp_ptr, O_SITE_STRING, ADD_COMMA);

		if (NEED_TO_PASS_GRANULAR_SITE_ID(rt_request_url_params_mask1, additional_parameter)) {
			json_append_string(&post_temp_ptr, O_SITE_ID, additional_parameter->granular_site_id, DONT_ADD_COMMA);
		}
		else {
			json_append_int(&post_temp_ptr, O_SITE_ID,(int)in_request_params->in_server_req_params->site_id, DONT_ADD_COMMA, ADD_QUOTE);
		}

		/*Precedence of IAB categories for impressions(other than mobile). 
		  1. If IAB category is coming from impression then send it to DSP in RTB request.
		  2. Check into DB for IAB categories.
		*/
		if ( req_params->pubsite_iab_category[0] != '\0' ) {
		  json_append_value_string(&post_temp_ptr, O_APP_CAT, ADD_COMMA);
		  json_append_value_string(&post_temp_ptr, req_params->pubsite_iab_category,DONT_ADD_COMMA);
		}
		else if(site->iab_vertical_count >0){
		  char iab_categories[MAX_LENGTH_SITE_IAB_VERTICALS];
		  iab_categories[0]='\0';
		  copy_iab_cat_from_db_in_json(iab_categories,site);
		  json_append_value_string(&post_temp_ptr, O_APP_CAT, ADD_COMMA);
		  json_append_value_string(&post_temp_ptr, iab_categories,DONT_ADD_COMMA);
		}
		
		if ( (rt_request_url_params_mask1->enabled_ias_services & PAGE_CAT_MAP)  && integral_data->page_categories[0] != '\0') {
			json_append_fixed_value_string(&post_temp_ptr, O_SITE_PAGECAT_ARR, sizeof(O_SITE_PAGECAT_ARR) - 1, ADD_COMMA);
			json_append_fixed_value_string(&post_temp_ptr, integral_data->page_categories, 
							integral_data->page_cat_len, DONT_ADD_COMMA);
		}

		//ADD O_PAGEURL and O_SITE_DOMAIN 
		add_site_pagedomain_in_json(&post_temp_ptr, adcampaign,
				&(additional_parameter->pubsite_default_settings),
				additional_parameter->pubsite_default_params.anonymized_pageurl,
				in_request_params->in_server_req_params);


		/* If Publisher has given overridding Referrer URL then override Referrer URL which has been received as params with it.*/
		if (additional_parameter->pubsite_default_settings.override_referrer_url == 1 &&
                    additional_parameter->pubsite_default_params.overriding_referrer_url[0] != '\0' &&
										(adcampaign->force_pageurl_transparency == 0 ||
					          additional_parameter->pubsite_default_settings.force_pageurl_transparency == 0)) {
			decode_url(additional_parameter->pubsite_default_params.overriding_referrer_url, tmp_ref_url, MAX_URL_LENGTH);
			json_append_string(&post_temp_ptr, O_REFURL, tmp_ref_url, ADD_COMMA);
		} else if (in_request_params->ad_server_req_gen_params->referer_url[0] != '\0') {
			decode_url(in_request_params->ad_server_req_gen_params->referer_url, tmp_ref_url, MAX_URL_LENGTH);
			json_append_escaped_string(&post_temp_ptr, O_REFURL, tmp_ref_url, ADD_COMMA, MAX_URL_LENGTH);
		}

		/*PUB OBJ START*/
		add_publisherobj_injson(&post_temp_ptr,
								adcampaign->ad_campaign_list_setings->psc.send_origin_pubid_enabled,
								in_request_params->in_server_req_params,
								in_request_params,
								rt_request_url_params_mask1,
				ADD_COMMA); // ASD-6003: Added ADD_COMMA as per the current logic; currently it assumes that some field will always be added
		/*PUB OBJ END*/

		/*CONTENT OBJ START*/
		if(req_params->content_obj_str[0] != '\0'){
			json_append_value_string(&post_temp_ptr, O_CONTENT, ADD_COMMA);
			// content_obj_str will come encapsulated in curly brackets {...}, so we dont need to add
			// extra curly brackets. Simply append the string as it is.
			json_append_value_string(&post_temp_ptr, req_params->content_obj_str, DONT_ADD_COMMA);
		}
		/*CONTENT OBJ END*/

			/*SITE EXT START*/
        	has_ext_params = 0;
        	json_append_value_string(&post_temp_ptr, O_EXT_STRING, ADD_COMMA);

		if ( rt_request_url_params_mask1->use_secure_params == 1 &&
        		in_request_params->fte_additional_params->is_https_request_flag == 1) {
			json_append_int(&post_temp_ptr, O_SITE_SEC, in_request_params->fte_additional_params->is_https_request_flag,
                                has_ext_params, DONT_ADD_QUOTE);
			has_ext_params = 1;
		}
		if ( ( rt_request_url_params_mask1->enabled_ias_services & BSC_MAP )  && integral_data->brand_safety_score[0] != '\0') {
                        json_append_fixed_value_string(&post_temp_ptr, O_BSC, sizeof(O_BSC) - 1, has_ext_params);
                        json_append_fixed_value_string(&post_temp_ptr, integral_data->brand_safety_score, 
							integral_data->bsc_len, DONT_ADD_COMMA);
			has_ext_params = 1;
                }

		if (has_ext_params == 0) {
			post_temp_ptr -= sizeof(O_EXT_STRING); //sizeof returns strlen +1, +1 is added to remove last comma
		} else {
			/*SITE EXT OBJECT END*/
			json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		}
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		/*SITE OBJ END*/

	} else { /*Reqest is from mobile APP. create APP object instead of site*/
		/*APP Object Start*/
		json_append_value_string(&post_temp_ptr, O_APP_STRING, ADD_COMMA);

		//application id based on pass-asis
		const char * app_id = NULL;
		if(1 == in_request_params->fte_additional_params->publisher_level_settings.is_mobile_params_pass_asis) {
			app_id = in_request_params->in_server_req_params->mobile_data.application_id_orig;
			if('\0' == app_id[0]) {
				app_id = in_request_params->in_server_req_params->mobile_data.application_id;
			}
			if ( app_id[0] != '\0' ) {
				json_append_string(&post_temp_ptr, O_APP_ID, app_id, has_app_params);
				has_app_params = 1;
			}
		} else {
			app_id = in_request_params->in_server_req_params->mobile_data.application_id;
			if ( app_id[0] != '\0' ) {
				json_append_string(&post_temp_ptr, O_APP_ID, app_id, has_app_params);
				has_app_params = 1;
				if((1 == enable_app_geo_mstats_flag) && 
						(0 ==	strcasecmp(in_request_params->in_server_req_params->mobile_data.application_id,
										   in_request_params->in_server_req_params->mobile_data.application_id_orig))) {

					SET_MOBILE_PARAM_FLAG(app_counter, appidmrq);
				}
			}
		}

		if ( in_request_params->in_server_req_params->mobile_data.application_name[0] != '\0' ) {
			json_append_string(&post_temp_ptr, O_APP_NAME, in_request_params->in_server_req_params->mobile_data.application_name, 
					   has_app_params);
			has_app_params = 1;
		}

		if ( in_request_params->in_server_req_params->mobile_data.application_version[0] != '\0') {
			json_append_string(&post_temp_ptr, O_APP_VER, in_request_params->in_server_req_params->mobile_data.application_version,
					  has_app_params);
			has_app_params = 1;
		}

    if ( PLATFORM_MOBILE_APP_IOS == in_request_params->in_server_req_params->site_ad->platform_id
				&& '\0' != in_request_params->in_server_req_params->mobile_data.application_id[0]) {
			json_append_string(&post_temp_ptr, O_APP_BUNDLE, in_request_params->in_server_req_params->mobile_data.application_id,
					has_app_params);
			has_app_params = 1;
			if((1 == enable_app_geo_mstats_flag) && 
					(0 == strcasecmp(req_params->mobile_data.application_id, req_params->mobile_data.application_id_orig))) {
				SET_MOBILE_PARAM_FLAG(app_counter, bundlemrq);
			}

		} else if ( PLATFORM_MOBILE_APP_ANDROID == in_request_params->in_server_req_params->site_ad->platform_id
				&& '\0' != in_request_params->in_server_req_params->mobile_data.application_bundle[0]) {
			json_append_escaped_string(&post_temp_ptr, O_APP_BUNDLE, in_request_params->in_server_req_params->mobile_data.application_bundle,
					has_app_params, MAX_APPLICATION_BUNDLE_LEN);
			has_app_params = 1;
			if((1 == enable_app_geo_mstats_flag) &&
					(0 == strcasecmp(in_request_params->in_server_req_params->mobile_data.application_bundle,
													 in_request_params->in_server_req_params->mobile_data.application_bundle_orig))) {
				SET_MOBILE_PARAM_FLAG(app_counter, bundlemrq);
			}
		}

		/* MPS-158 Checking if app domain present in request send if present else get from DB */
		if( in_request_params->in_server_req_params->mobile_data.app_domain[0] != '\0'
			&& ( 1 == in_request_params->fte_additional_params->publisher_level_settings.is_mobile_params_pass_asis
				 || 1 == additional_parameter->pubsite_default_settings.realtime_domain_enabled)
		) {
		    json_append_escaped_string(&post_temp_ptr, O_APP_DOMAIN,
						in_request_params->in_server_req_params->mobile_data.app_domain,
						has_app_params, MAX_DOMAIN_NAME_LENGTH);
		        has_app_params = 1;
		    
		} else if( 1 != in_request_params->fte_additional_params->publisher_level_settings.is_mobile_params_pass_asis
				   && in_request_params->fte_additional_params->site_url[0] != '\0' ) {
			json_append_string(&post_temp_ptr, O_APP_DOMAIN, in_request_params->fte_additional_params->site_url, has_app_params);
			has_app_params = 1;
		}
		/*Precedence of IAB categories for mobile impressions.
		  1. If IAB category is coming from impression then send it to DSP in RTB request.
		  2. If IAB category is coming from App Store then send it to DSP in RTB request.
		  3. Check into DB for IAB categories.
		*/

		if ( in_request_params->in_server_req_params->pubsite_iab_category[0] != '\0' ) {
		  json_append_value_string(&post_temp_ptr, O_APP_CAT, has_app_params);
		  json_append_value_string(&post_temp_ptr, in_request_params->in_server_req_params->pubsite_iab_category, DONT_ADD_COMMA);
		  has_app_params = 1;
		}
		else if (1 != in_request_params->fte_additional_params->publisher_level_settings.is_mobile_params_pass_asis
				 && in_request_params->in_server_req_params->mobile_data.iab_category[0] != '\0' ) {
		  json_append_value_string(&post_temp_ptr, O_APP_CAT, has_app_params);
		  json_append_value_string(&post_temp_ptr, in_request_params->in_server_req_params->mobile_data.iab_category, DONT_ADD_COMMA);
		  has_app_params = 1;
		}
		else if(1 != in_request_params->fte_additional_params->publisher_level_settings.is_mobile_params_pass_asis) {
		  char iab_categories[MAX_LENGTH_SITE_IAB_VERTICALS];
		  iab_categories[0]='\0';
		  copy_iab_cat_from_db_in_json(iab_categories,site);
		  json_append_value_string(&post_temp_ptr, O_APP_CAT, has_app_params);
		  json_append_value_string(&post_temp_ptr, iab_categories, DONT_ADD_COMMA);
		  has_app_params = 1;
		}
		
if (1 == in_request_params->fte_additional_params->publisher_level_settings.is_mobile_params_pass_asis) {
	// add sectioncat
    	if ('\0' !=	in_request_params->in_server_req_params->mobile_data.app_sectioncat[0]) {
		json_append_value_string (&post_temp_ptr, O_APP_SECTIONCAT, has_app_params);
		json_append_value_string (&post_temp_ptr, in_request_params->in_server_req_params->mobile_data.app_sectioncat, DONT_ADD_COMMA);
		has_app_params = 1;
      	}
    	// add pagecat
    	if ('\0' !=	in_request_params->in_server_req_params->mobile_data.app_pagecat[0]) {
		json_append_value_string (&post_temp_ptr, O_APP_PAGECAT, has_app_params);
		json_append_value_string (&post_temp_ptr,in_request_params->in_server_req_params->mobile_data.app_pagecat, DONT_ADD_COMMA);
		has_app_params = 1;
      	}

	// add keywords
    	if ('\0' !=	in_request_params->in_server_req_params->mobile_data.keywords[0]) {
		json_append_escaped_string (&post_temp_ptr, O_APP_KEYWORDS,in_request_params->in_server_req_params->mobile_data.keywords, has_app_params, DEFAULT_LEN_256);
		has_app_params = 1;
      }

    	//  add privacypolicy
    	if (0 == in_request_params->in_server_req_params->mobile_data.privacypolicy
		|| 1 == in_request_params->in_server_req_params->mobile_data.privacypolicy) {
		json_append_int (&post_temp_ptr, O_APP_PRIVACYPOLICY, in_request_params->in_server_req_params->mobile_data.privacypolicy, has_app_params, DONT_ADD_QUOTE);
		has_app_params = 1;
      	}
  }



		if (in_request_params->in_server_req_params->mobile_data.is_paid_application != -1) {
			json_append_int(&post_temp_ptr, O_APP_PAID, in_request_params->in_server_req_params->mobile_data.is_paid_application,
					has_app_params, DONT_ADD_QUOTE);
			has_app_params = 1;	
		}

		if (in_request_params->in_server_req_params->mobile_data.store_url[0] != '\0') {
			json_append_string(&post_temp_ptr, O_APP_STORE_URL, in_request_params->in_server_req_params->mobile_data.store_url,has_app_params);
			has_app_params = 1;
			if((1 == enable_app_geo_mstats_flag) && 
					(0 == strcasecmp(in_request_params->in_server_req_params->mobile_data.store_url,
													 in_request_params->in_server_req_params->mobile_data.store_url_orig))) {
				SET_MOBILE_PARAM_FLAG(app_counter, storeurlmrq);
			}
		}
		/*PUB OBJ START*/
		add_publisherobj_injson(&post_temp_ptr,
								adcampaign->ad_campaign_list_setings->psc.send_origin_pubid_enabled,
								in_request_params->in_server_req_params,
								in_request_params,
								rt_request_url_params_mask1,
				has_app_params); //comma before publisher object should be added only when one of the above field is appended
		/*PUB OBJ END*/

		/*CONTENT OBJ START*/
		if(req_params->content_obj_str[0] != '\0'){
			json_append_value_string(&post_temp_ptr, O_CONTENT, ADD_COMMA);
			// content_obj_str will come encapsulated in curly brackets {...}, so we dont need to add
			// extra curly brackets. Simply append the string as it is.
			json_append_value_string(&post_temp_ptr, req_params->content_obj_str, DONT_ADD_COMMA);
		}
		/*CONTENT OBJ END*/

			/*APP EXT START*/
		json_append_value_string(&post_temp_ptr, O_EXT_STRING, ADD_COMMA);
		json_append_int(&post_temp_ptr, O_APP_SITEID, (int)in_request_params->in_server_req_params->site_id, DONT_ADD_COMMA, ADD_QUOTE);
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
			/*APP EXT END*/
		
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		/*App Object End*/
	}

	/*DEVICE OBJ START*/
	json_append_value_string(&post_temp_ptr, O_DEVICE_STRING, ADD_COMMA);
	if (additional_parameter->pubsite_default_settings.is_ip_address_blocked == 0 && 
	    in_request_params->ad_server_req_gen_params->remote_ip_addr[0] != '\0') {
		add_ip_in_openrtb_device(&post_temp_ptr, in_request_params, ip_masking_enabled, has_device_params);
	  has_device_params = 1;
	}

	if (in_request_params->in_server_req_params->is_coppa_compliant == 1) {
		json_append_int(&post_temp_ptr, O_DEVICE_DNT, in_request_params->in_server_req_params->is_coppa_compliant, 
				has_device_params, DONT_ADD_QUOTE);
		has_device_params = 1;
	}
	if (in_request_params->ad_server_req_gen_params->browser[0] != '\0') {
		json_append_escaped_string(&post_temp_ptr, O_DEVICE_UA, in_request_params->ad_server_req_gen_params->browser, has_device_params, MAX_BROWSER_NAME_LEN);
		has_device_params = 1;
	}
	if (additional_parameter->isp_name[0] != '\0') {
	      //json_append_string(&post_temp_ptr,O_DEVICE_CARRIER,in_request_params->in_server_req_params->mobile_carrier, has_device_params);
		json_append_string(&post_temp_ptr, O_DEVICE_CARRIER, additional_parameter->isp_name, has_device_params);
		has_device_params = 1;
	}

	if ('\0' != in_request_params->in_server_req_params->device_obj.flashver[0]) {
		json_append_escaped_string(&post_temp_ptr, O_DEVICE_FLASHVER, in_request_params->in_server_req_params->device_obj.flashver, has_device_params, DEFAULT_LEN_64);
		has_device_params = 1;
	}

	if (in_request_params->ad_server_req_gen_params->accept_lang[0] != '\0') {
		json_append_escaped_string(&post_temp_ptr, O_DEVICE_LANG, in_request_params->ad_server_req_gen_params->accept_lang, 
					has_device_params, MAX_ACCEPT_LANGUAGE_NAME_LEN);
		has_device_params = 1;
	}
	if(in_request_params->in_server_req_params->mobile_device_make[0] != '\0') {
		json_append_string(&post_temp_ptr, O_DEVICE_MAKE,
				  in_request_params->in_server_req_params->mobile_device_make, has_device_params);
		has_device_params = 1;
	}
	if (in_request_params->in_server_req_params->mobile_device_model[0] != '\0') {
		json_append_string(&post_temp_ptr, O_DEVICE_MODEL,
				  in_request_params->in_server_req_params->mobile_device_model, has_device_params);
		has_device_params = 1;
	}
	if (in_request_params->in_server_req_params->mobile_device_os[0] != '\0') {
		json_append_string(&post_temp_ptr, O_DEVICE_OS, in_request_params->in_server_req_params->mobile_device_os, has_device_params);
		has_device_params = 1;
	}
	if (in_request_params->in_server_req_params->mobile_device_os_version[0] != '\0') {
		json_append_string(&post_temp_ptr, O_DEVICE_OSV,
				  in_request_params->in_server_req_params->mobile_device_os_version, has_device_params);
		has_device_params = 1;
		//Send both Osv and osv parameter for backward compatibility
		json_append_string(&post_temp_ptr, O_DEVICE_OSV_LC,
				  in_request_params->in_server_req_params->mobile_device_os_version, has_device_params);
		has_device_params = 1;
	}
	if (in_request_params->in_server_req_params->js_enabled != -1) {
		json_append_int(&post_temp_ptr, O_DEVICE_JS,
				in_request_params->in_server_req_params->js_enabled, has_device_params, DONT_ADD_QUOTE);
		has_device_params = 1;
		if ((1 == enable_app_geo_mstats_flag) &&
				(in_request_params->in_server_req_params->js_enabled == in_request_params->in_server_req_params->js_enabled_orig)) {
			SET_MOBILE_PARAM_FLAG(device_counter, jsmrq);
		}
	}

	if (1 == in_request_params->fte_additional_params->publisher_level_settings.is_mobile_params_pass_asis &&
			-1 != in_request_params->in_server_req_params->connectiontype) {
		json_append_int(&post_temp_ptr, O_DEVICE_CONTYPE, in_request_params->in_server_req_params->connectiontype, has_device_params, DONT_ADD_QUOTE);
		has_device_params = 1;
	} else	if(in_request_params->in_server_req_params->mobile_nettype[0] != '\0'){
		if ( strcasestr(in_request_params->in_server_req_params->mobile_nettype, CONTYPE_WIFI) != NULL) {
			json_append_int(&post_temp_ptr, O_DEVICE_CONTYPE, WIFI_ID, has_device_params, DONT_ADD_QUOTE);
			has_device_params = 1;
		} else if (strcasestr(in_request_params->in_server_req_params->mobile_nettype, CONTYPE_CELLULAR) != NULL) {
			json_append_int(&post_temp_ptr, O_DEVICE_CONTYPE, CELLULAR_ID, has_device_params, DONT_ADD_QUOTE);
			has_device_params = 1;
		}
	}

	if(in_request_params->in_server_req_params->is_tablet == 1) {
		json_append_int(&post_temp_ptr, O_DEVICE_TYPE, DEVICE_TYPE_TABLET, has_device_params, DONT_ADD_QUOTE);
		has_device_params = 1;
	}else if(in_request_params->in_server_req_params->device_type != -1) {
		json_append_int(&post_temp_ptr, O_DEVICE_TYPE, in_request_params->in_server_req_params->device_type,
				has_device_params, DONT_ADD_QUOTE);
		has_device_params = 1;
	}  else if (is_mob_impression == 0 && req_params->site_ad != NULL &&
		req_params->site_ad->platform_id == DESKTOP_WEB_PLATFORM) {
		json_append_int(&post_temp_ptr, O_DEVICE_TYPE, DEVICE_TYPE_PERSONAL_COMPUTER, has_device_params, DONT_ADD_QUOTE);
		has_device_params = 1; 
	}

    if ( in_request_params->in_server_req_params->platform_specific_id[0] != '\0'
         &&
         in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE
             &&
             in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE
       ) {

        dpid_type = atoi(in_request_params->in_server_req_params->udid_type);
        if ( dpid_type < 0 || dpid_type >= MAX_DEVICE_IDS ) {
            OPENRTB_DEBUG("Invalid dpid type");
            dpid_type = 0;
        }
		if ( dpid_type == ANDROID_ID_TYPE || dpid_type == UDID_TYPE ) {
			if ( in_request_params->in_server_req_params->udid_hash == SHA1_HASH ) {
				json_append_string(&post_temp_ptr, O_DEVICE_DPIDSHA1, in_request_params->in_server_req_params->platform_specific_id, has_device_params);
				has_device_params = 1;
				if(1 == enable_app_geo_mstats_flag) {
					if(0 == strcasecmp(in_request_params->in_server_req_params->platform_specific_id,
								in_request_params->in_server_req_params->device_id_udid_orig)){

						SET_MOBILE_PARAM_FLAG(device_counter, udidmrq);
					}
					if(0 == strcasecmp(in_request_params->in_server_req_params->platform_specific_id,
								in_request_params->in_server_req_params->device_id_dpid_orig)){

						SET_MOBILE_PARAM_FLAG(device_counter, dpidmrq);
					}
				}
				// added_dpid = 1;
			} else if ( in_request_params->in_server_req_params->udid_hash == MD5_HASH ) {
				json_append_string(&post_temp_ptr, O_DEVICE_DPIDMD5, in_request_params->in_server_req_params->platform_specific_id, has_device_params);
				has_device_params = 1;
				if (1 == enable_app_geo_mstats_flag) {
					if(0 == strcasecmp(in_request_params->in_server_req_params->platform_specific_id,
								in_request_params->in_server_req_params->device_id_udid_orig)){
						SET_MOBILE_PARAM_FLAG(device_counter, udidmrq);
					}
					if(0 ==	strcasecmp(in_request_params->in_server_req_params->platform_specific_id,
								in_request_params->in_server_req_params->device_id_dpid_orig)){
						SET_MOBILE_PARAM_FLAG(device_counter, dpidmrq);
					}
				}
				// added_dpid = 1;
			}
		}
	}

	if(1 ==	in_request_params->fte_additional_params->publisher_level_settings.is_mobile_params_pass_asis) {
		int is_pa_geo = 0;
		has_device_params = create_geo_object_pass_asis(&post_temp_ptr, &is_pa_geo, ORTB_VERSION,
					&(req_params->device_obj.geo),
					&(additional_parameter->gd),
					req_params->is_coppa_compliant,
					adcampaign->ad_campaign_list_setings->lat_lon_masking_enabled,
					has_device_params);
		if(1 == is_pa_geo) SET_MOBILE_PARAM_FLAG(device_counter, PA_dgeo);
	} else {
		has_device_params = create_device_geo_object(&post_temp_ptr,
					in_request_params,
					additional_parameter,
					adcampaign->ad_campaign_list_setings->lat_lon_masking_enabled,
					is_mob_impression,
					has_device_params);
	}

	/*DEVICE EXT OBJECT START*/
        has_ext_params = 0;
        json_append_value_string(&post_temp_ptr, O_EXT_STRING, has_device_params);
	if ( /* added_dpid != 1
		  && */
	     in_request_params->in_server_req_params->platform_specific_id[0] != '\0' 
	     &&             
	     in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE
             &&
             in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE	
	   ) {

		dpid_type=atoi(in_request_params->in_server_req_params->udid_type);
		if ( dpid_type < 0 || dpid_type >= MAX_DEVICE_IDS ) {
			OPENRTB_DEBUG("Invalid dpid type");
			dpid_type = 0;
		}
		json_append_string(&post_temp_ptr, device_id_map[dpid_type], in_request_params->in_server_req_params->platform_specific_id, 
				   has_ext_params);
		has_ext_params = 1;

		if((1 == enable_app_geo_mstats_flag) && (0 == strcasecmp(in_request_params->in_server_req_params->platform_specific_id,
					in_request_params->in_server_req_params->device_id_udid_orig))){
			SET_MOBILE_PARAM_FLAG(device_counter, udidmrq);
		}

		if((1 == enable_app_geo_mstats_flag) && (0 ==	strcasecmp(in_request_params->in_server_req_params->platform_specific_id,
					in_request_params->in_server_req_params->device_id_dpid_orig))){
			SET_MOBILE_PARAM_FLAG(device_counter, dpidmrq);
		}

		if (in_request_params->in_server_req_params->udid_hash >= 0 && in_request_params->in_server_req_params->udid_hash < 4) {
			json_append_int(&post_temp_ptr, O_DEV_EXT_HASH, in_request_params->in_server_req_params->udid_hash, has_ext_params, DONT_ADD_QUOTE);
			has_ext_params = 1;
		}
	}
        if ( (in_request_params->in_server_req_params->adtruth_data.adtruth_rtb_json[0] != '\0') &&
                        (rt_request_url_params_mask1->use_adtruth_id == 1 ) &&
                        (in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE) &&
                        (in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE) ) {
			/* DEVICE ADTRUTH OBJECT START */
                json_append_value_string(&post_temp_ptr, O_EXT_ADTRUTH, has_ext_params);
                json_append_value_string(&post_temp_ptr, 
					in_request_params->in_server_req_params->adtruth_data.adtruth_rtb_json, DONT_ADD_COMMA);
								adcampaign->ad_campaign_list_setings->adtruth_id_used=1;
		has_ext_params = 1;
			/* DEVICE ADTRUTH OBJECT END */
        }
        // Get the x_forwarded_for header's value
	if(((1 == additional_parameter->pub_country_level_privacy_flag) || 
		(1 == ip_masking_enabled)) &&
		(additional_parameter->masked_xff[0]!='\0')){
	  json_append_string(&post_temp_ptr, O_XFF_HEADER,additional_parameter->masked_xff, has_ext_params);
	  has_ext_params = 1;
	}
	else{
	  const char* xff_header = get_header_value(&(additional_parameter->header_map), "HTTP_X_FORWARDED_FOR");
	  if ( xff_header != NULL && xff_header[0] != '\0' ) {
	    json_append_string(&post_temp_ptr, O_XFF_HEADER, xff_header, has_ext_params);
	    has_ext_params = 1;
	  }
	}
	if ( in_request_params->in_server_req_params->screen_resolution[0]!= '\0' ) {
		json_append_string(&post_temp_ptr, O_SCREEN_RESOLUTION, 
				in_request_params->in_server_req_params->screen_resolution, has_ext_params);
                has_ext_params = 1;
	}
	if ( rt_request_url_params_mask1->frequency == 1) {
		json_append_int(&post_temp_ptr, O_DEVICE_FREQ, 
		get_frequency( adcampaign->campaign_id, in_request_params->fte_additional_params), has_ext_params, DONT_ADD_QUOTE);
		has_ext_params = 1;	
	}
	if( in_request_params->in_server_req_params->platform_id != MOBILE_APP_PLATFORM) {
		if (1 == in_request_params->in_server_req_params->isapp) {
			json_append_int(&post_temp_ptr, O_DEVICE_PLATFORM, in_request_params->in_server_req_params->site_ad->platform_id, 
					has_ext_params, DONT_ADD_QUOTE);
		} else {
			json_append_int(&post_temp_ptr, O_DEVICE_PLATFORM, in_request_params->in_server_req_params->platform_id, 
					has_ext_params, DONT_ADD_QUOTE);
		}
		has_ext_params = 1;	
	} else if (in_request_params->in_server_req_params->site_ad != NULL) {
		json_append_int(&post_temp_ptr, O_DEVICE_PLATFORM, in_request_params->in_server_req_params->site_ad->platform_id, 
				has_ext_params, DONT_ADD_QUOTE);
		has_ext_params = 1;	
	}

	if (in_request_params->in_server_req_params->loc_category[0] != '\0') {
			json_append_value_string(&post_temp_ptr, O_DEVICE_LOC_CAT, has_ext_params);
			json_append_value_string(&post_temp_ptr, in_request_params->in_server_req_params->loc_category, DONT_ADD_COMMA);
			has_ext_params = 1;
	}

	if (in_request_params->in_server_req_params->loc_brand[0] != '\0') {
			json_append_value_string(&post_temp_ptr, O_DEVICE_LOC_BRAND, has_ext_params);
			json_append_value_string(&post_temp_ptr, in_request_params->in_server_req_params->loc_brand, DONT_ADD_COMMA);
			has_ext_params = 1;
	}

	if (in_request_params->in_server_req_params->loc_cat_src != -1) {
			json_append_int(&post_temp_ptr, O_DEVICE_LOC_CAT_SRC, in_request_params->in_server_req_params->loc_cat_src, 
				has_ext_params, DONT_ADD_QUOTE);
			has_ext_params = 1;	
	}

	if (has_ext_params == 0) {
                //if no ext parameter found, do not send empty ext object "ext{}"
                post_temp_ptr -= strlen(O_EXT_STRING);
                if (has_device_params == 1) { //have some device params before it. so remove last comma
                        post_temp_ptr -= 1;
                }
        } else {
		/*DEVICE EXT OBJECT END*/
                json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
                has_device_params = 1; //since ext object is nested in device object
        }

	json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
	/*DEVICE OBJ END*/ 	

	if(
          	in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE
                &&
                in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE
       	  ) {
	/*USER OBJECT START*/
		json_append_value_string(&post_temp_ptr,O_USER_STRING,ADD_COMMA);
                if (in_request_params->ad_server_req_gen_params->user_guid[0] != '\0') {
                        json_append_string(&post_temp_ptr, O_USER_ID, in_request_params->ad_server_req_gen_params->user_guid, has_user_params);
                        has_user_params = 1;
                }
		if (in_request_params->in_server_req_params->year_of_birth[0] != '\0') {
			json_append_int(&post_temp_ptr, O_USER_YOB, atoi(in_request_params->in_server_req_params->year_of_birth), 
					has_user_params, DONT_ADD_QUOTE);
			has_user_params = 1;
		}
		if (in_request_params->in_server_req_params->gender[0] != '\0') {
			strtoupper(in_request_params->in_server_req_params->gender, MAX_GENDER_LEN);
			json_append_string(&post_temp_ptr, O_USER_GENDER, in_request_params->in_server_req_params->gender, has_user_params);
			has_user_params = 1;
		}
		if (in_request_params->in_server_req_params->keywords[0] != '\0') {
			json_append_string(&post_temp_ptr, O_USER_KEYWORDS, in_request_params->in_server_req_params->keywords, has_user_params);
			has_user_params = 1;
		}
                if ( (rt_request_url_params_mask1->cookie == 1 ) && (in_request_params->request_url_params.cookie[0] != '\0') &&
                     (in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE) ) {
                        json_append_string(&post_temp_ptr, O_USER_CUSTOMDATA, in_request_params->request_url_params.cookie, has_user_params);
			has_user_params = 1;
                }	

		if(1 ==	in_request_params->fte_additional_params->publisher_level_settings.is_mobile_params_pass_asis) {
			int is_pa_geo = 0;
			has_user_params = create_geo_object_pass_asis(&post_temp_ptr, &is_pa_geo, ORTB_VERSION,
						&(req_params->user_obj.geo),
						NULL, //No IP infered GEO in user.geo
						req_params->is_coppa_compliant,
						adcampaign->ad_campaign_list_setings->lat_lon_masking_enabled,
						has_user_params);
			if(1 == is_pa_geo) SET_MOBILE_PARAM_FLAG(user_counter, PA_ugeo);
		} else {
			has_user_params = create_user_geo_object(&post_temp_ptr,
						in_request_params,
						additional_parameter,
						adcampaign->ad_campaign_list_setings->lat_lon_masking_enabled,
						has_user_params);
		}

		//OPENRTB 3.0 : Add consumer identifier - eids object:
		create_3_x_consumer_identifier_object(&post_temp_ptr, req_params, adcampaign, &has_user_params);


		has_ext_params = 0;
			/*USER EXT OBEJCT START*/
		json_append_value_string(&post_temp_ptr, O_EXT_STRING, has_user_params);
		if ( (rt_request_url_params_mask1->timezone == 1) && (in_request_params->in_server_req_params->timezone[0] != '\0')) {
			json_append_string(&post_temp_ptr, O_USER_TIMEZONE, in_request_params->in_server_req_params->timezone, has_ext_params);
			has_ext_params = 1;
		}

		if ( (in_request_params->in_server_req_params->ethnicity[0] != '\0') &&
			(in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE) &&
			(in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE) ) {
			json_append_string(&post_temp_ptr, O_USER_ETHN, in_request_params->in_server_req_params->ethnicity, has_ext_params);
			has_ext_params = 1;
		}

		if ( (in_request_params->in_server_req_params->income[0] != '\0') &&
			(in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE) &&
			(in_request_params->ad_server_req_gen_params->dnt_opt_out == HTTP_DO_NOT_TRACK_FALSE) ) {
			json_append_string(&post_temp_ptr, O_USER_INCOME, in_request_params->in_server_req_params->income, has_ext_params);
			has_ext_params = 1;
		}

		/* Reset all gdpr object creation flags */
		int add_gdpr_ext = 0;
		int add_iab_gdpr_consent = 0;
		int add_eb_provider_list = 0;
		char *eb_provider_list = NULL;

		/* take decision, whether we want to send gdpr singal in RTB request */
		gdpr_object_creation_decision(in_request_params->in_server_req_params,
				in_request_params->fte_additional_params,
				adcampaign->ad_campaign_gdpr_settings.dont_pass_iab_consent_obj,
				&add_gdpr_ext,
				&add_iab_gdpr_consent,
				&add_eb_provider_list,
				&eb_provider_list);

		/* Add gdpr signal in RTB request */
		if (1 == add_gdpr_ext) {
			json_append_int(&post_temp_ptr, O_USER_EXT_GDPR, req_params->gdpr, has_ext_params, DONT_ADD_QUOTE);
			has_ext_params = 1;
		}

		/* Add gdpr consent string in RTB request */
		if (1 == add_iab_gdpr_consent && '\0' != req_params->consent[0]) {
			json_append_string(&post_temp_ptr, O_USER_EXT_CONSENT, req_params->consent, has_ext_params);
			has_ext_params = 1;
		}

		/* Append google EB consented provider list */
		if (1 == add_eb_provider_list && NULL != eb_provider_list && '\0' != eb_provider_list[0]) {
			json_append_value_string(&post_temp_ptr, O_GOOGLE_EB_CP_SETTINGS_STRING, has_ext_params);
			json_append_object(&post_temp_ptr, O_GOOGLE_EB_CP_LIST, eb_provider_list, 0);
			json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
			has_ext_params = 1;
		}

		if ( rt_request_url_params_mask1->send_is_dspuid_inferred == 1 &&
																			in_request_params->in_server_req_params->kadpubuid != NULL) {
			//O_USER_DSP_UID_INFERRED
			json_append_int(&post_temp_ptr, O_USER_DSP_UID_INFERRED, rt_request_url_params_mask1->send_is_dspuid_inferred, has_ext_params, DONT_ADD_QUOTE);
			has_ext_params = 1;
		}

		if(in_request_params->in_server_req_params->verizon_id[0] != '\0')
		{
			json_append_escaped_string(&post_temp_ptr, O_USER_CARRIER_SPECIFIC_USER_ID, in_request_params->in_server_req_params->verizon_id, has_ext_params, MAX_HASHED_DEVICE_ID_LEN);
	  		has_ext_params = 1;
	  		json_append_int(&post_temp_ptr, O_USER_CARRIER_SPECIFIC_USER_ID_TYPE, O_USER_CARRIER_SPECIFIC_USER_ID_TYPE_VERIZON, has_ext_params, DONT_ADD_QUOTE);
	  		has_ext_params = 1;

		}
		create_2_x_consumer_identifier_ext(&post_temp_ptr, req_params, adcampaign, &has_ext_params);


		if (has_ext_params == 0) {
			post_temp_ptr -= ( sizeof(O_EXT_STRING) - 1 );
			if (has_user_params == 1) { //have some user params before it. so remove last comma
				post_temp_ptr -= 1;
			}
		} else {
			json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
			/*USER EXT OBEJCT END*/
			has_user_params = 1; //since ext object is nested in user object
		}

		if (has_user_params == 0) {
			//if no user parameter found, do not send empty user object "user{}"
	                post_temp_ptr -= strlen(O_USER_STRING) + 1; //added +1 to remove preceding comma
		} else {
		/*USER OBJECT END*/
			json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		}
	}

	/* OTF BLocklist : Blocked adveriser domains to replace blocked urls from DB(if present)  */
	int otf_adv_dom_present = 0;
	int otf_cat_id_present  = 0;
	int otf_blocklist_enabled = 0;
  //otf_blocklist_enabled=0:disabled
	//otf_blocklist_enabled=1:otf blocked domain list
	//otf_blocklist_enabled=2:db blocked domain list

	otf_blocklist_enabled = additional_parameter->pubsite_default_settings.pass_n_block_advt_info_enabled;
	
	if(otf_blocklist_enabled == 1 && in_request_params->in_server_req_params->blk_adv_dom_count > 0  && in_request_params->in_server_req_params->blk_adv_dom_json[0] != '\0') {
	    otf_adv_dom_present = 1;
	} 

	if(otf_blocklist_enabled != 0 && in_request_params->in_server_req_params->blk_cat_id_count > 0  && in_request_params->in_server_req_params->blk_cat_id_json[0] != '\0') {
	    otf_cat_id_present = 1;	    
	}

	if(otf_cat_id_present == 1) {
	    json_append_value_string(&post_temp_ptr, O_BCAT_ARR, ADD_COMMA);
	    memcpy(post_temp_ptr, in_request_params->in_server_req_params->blk_cat_id_json, in_request_params->in_server_req_params->blk_cat_id_json_length);
	    post_temp_ptr += in_request_params->in_server_req_params->blk_cat_id_json_length;	    
	}

	if(otf_adv_dom_present == 1) {
		json_append_value_string(&post_temp_ptr, O_BADV_ARR, ADD_COMMA);
		memcpy(post_temp_ptr, in_request_params->in_server_req_params->blk_adv_dom_json , in_request_params->in_server_req_params->blk_adv_dom_json_length);
		post_temp_ptr += in_request_params->in_server_req_params->blk_adv_dom_json_length;	    
	}
	else if ( badv_domain_json != NULL && badv_domain_json[0] !='\0' ){
		json_append_value_string(&post_temp_ptr, O_BADV_ARR, ADD_COMMA);
		int len=strlen(badv_domain_json);
		memcpy(post_temp_ptr, badv_domain_json , len);
		post_temp_ptr += len;
		otf_adv_dom_present=1;
	}

	if (NEED_TO_PASS_EXCLUDE_LIST(blocked_list, req_params)) {
		temp_ptr += (blocked_list->json_blocked_advt_categories_len + 4);
		if ( blocked_list->json_blocked_iab_advt_categories_len > 0 && otf_cat_id_present != 1 ) {
			json_append_value_string(&post_temp_ptr, O_BCAT_ARR, ADD_COMMA);	
			memcpy(post_temp_ptr, temp_ptr, blocked_list->json_blocked_iab_advt_categories_len);
			post_temp_ptr += blocked_list->json_blocked_iab_advt_categories_len;
		}
		temp_ptr += (blocked_list->json_blocked_iab_advt_categories_len + 4);

		if ( otf_adv_dom_present == 0 && blocked_list->json_url_blockedlist_len > 0 ) {
			json_append_value_string(&post_temp_ptr, O_BADV_ARR, ADD_COMMA);
			memcpy(post_temp_ptr, temp_ptr, blocked_list->json_url_blockedlist_len);
			post_temp_ptr += blocked_list->json_url_blockedlist_len;
		}
	}

	/*EXT OBJECT START*/
	has_ext_params = 0;
	json_append_value_string(&post_temp_ptr, O_EXT_STRING, ADD_COMMA);

	if (CAMPAIGN_HAS_DEALS(adcampaign, rt_request_url_params_mask1)) {
		if ( has_ext_params == 1 ) {
			memcpy(post_temp_ptr,",",1);
			post_temp_ptr++;
		}
		/*PMP AND DEAL OBJECT*/
		bytes_written = create_pmp_object(&post_temp_ptr, adcampaign, rt_request_url_params_mask1,
				in_request_params->fte_additional_params);
		has_ext_params = ( bytes_written > 0 ) ? 1 : 0;
	}

	/* OLD Native Protocol Implementation
		if (IS_NATIVE_REQUEST) {
		#ifdef NATIVE_DEBUG
        llog_write(L_DEBUG,"\nMB_NATIVE Adding Native object to openRTB request %s:%d\n",__FILE__,__LINE__);
		#endif
		
		native_params_t *native_params = &(in_request_params->in_server_req_params->in_native_params);
		if (has_ext_params == 1) {
			memcpy(post_temp_ptr,",",1);
			post_temp_ptr++;
		}

		json_append_value_string(&post_temp_ptr, NATIVE_PARAMS_STRING, DONT_ADD_COMMA);
		json_append_string(&post_temp_ptr, NATIVE_API_VER, native_params->api_ver, DONT_ADD_COMMA);
		json_append_array(&post_temp_ptr, NATIVE_ADM_SUPPORT, native_params->parsed_admsupport, ADD_COMMA);
		if (native_params->cover_img_selected == 1 && native_params->imgratio[0] != '\0') {
			json_append_string(&post_temp_ptr, NATIVE_IMG_RATIO, native_params->imgratio, ADD_COMMA);
		}

		if (native_params->seq_num != -1) {
			json_append_int(&post_temp_ptr, NATIVE_SEQ_NUM, native_params->seq_num, ADD_COMMA, DONT_ADD_QUOTE);
		}

		if (native_params->icon_img_selected == 1 && native_params->icon_size[0] != '\0') {
			json_append_string(&post_temp_ptr, NATIVE_ICON_SIZE, native_params->icon_size, ADD_COMMA);
		}

		if (native_params->cover_img_selected == 1 && native_params->img_size[0] != '\0') {
			json_append_string(&post_temp_ptr, NATIVE_IMAGE_SIZE, native_params->img_size, ADD_COMMA);
		}

		if (native_params->title_selected == 1 && native_params->title_len != -1) {
			json_append_int(&post_temp_ptr, NATIVE_TITLE_LEN, native_params->title_len, ADD_COMMA, DONT_ADD_QUOTE);
		}

		if (native_params->desc_selected == 1 && native_params->desc_len != -1) {
			json_append_int(&post_temp_ptr, NATIVE_DESC_LEN, native_params->desc_len, ADD_COMMA, DONT_ADD_QUOTE);
		}

		if (native_params->cta_selected == 1 && native_params->cta_len != -1) {
			json_append_int(&post_temp_ptr, NATIVE_CTA_LEN, native_params->cta_len, ADD_COMMA, DONT_ADD_QUOTE);
		}
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		has_ext_params = 1;
	}
*/
	openrtb_request_append_common_ext_object( &post_temp_ptr, in_request_params, additional_parameter, adcampaign, rt_request_url_params_mask1->protocol, &has_ext_params);
	
	if (in_request_params->in_server_req_params->is_coppa_compliant == 1) {
                json_append_value_string(&post_temp_ptr, O_EXT_REGS, has_ext_params);
                json_append_int(&post_temp_ptr, O_EXT_REGS_COPPA, in_request_params->in_server_req_params->is_coppa_compliant,
                                DONT_ADD_COMMA, DONT_ADD_QUOTE);
                json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
                has_ext_params = 1;
        }

	if ( rt_request_url_params_mask1->send_winloss_info == 1 ) {
		if ( has_ext_params == 1 ) {
			memcpy(post_temp_ptr,",",1);
			post_temp_ptr++;
		}
		bytes_written = get_winloss_info_str(post_temp_ptr, MAX_WINLOSS_STR_LEN, adcampaign->campaign_id, 
						    &(in_request_params->fte_additional_params->hash_table));	
		if ( (bytes_written == 0) && (has_ext_params == 1) ) {
			post_temp_ptr--;		//remove the comma added
		}
		if ( bytes_written > 0 ) {
			post_temp_ptr += bytes_written; //increase pointer as it was passed by value
			has_ext_params = 1;	
		}
	}
			
        if (has_ext_params == 0) {
                //if no ext parameter found, do not send empty ext object "ext{}"
                post_temp_ptr -= strlen(O_EXT_STRING) + 1; //+1 is added to remove last comma
        } else {
        /*EXT OBJECT END*/
                json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
        }

	json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
        return post_temp_ptr-post_data;
}

static struct curl_slist* rtb_req_proxy_get_headers(
	struct curl_slist** header_list,
	int* size_header_list,
	uint8_t compressed_request,
	char *x_purl_buff
) {
	struct curl_slist *result = NULL;
	header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "Expect:");
	header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "x-openrtb-version: 2.1");
	header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "Content-Type: application/json");

	if( compressed_request )
	{
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], "Content-Encoding: gzip");
	}

	result = header_list[*size_header_list] ;
	
	(*size_header_list)++;
#ifdef DEBUG
	if( x_purl_buff[0] != '\0' )
	{
		ERROR_LOG("proxy: hdr: %s, data = %s, next = %p, size_of_header_lists = %d\n", x_purl_buff, result->data, result->next, *size_header_list);
	}
#else
	(void) x_purl_buff;
#endif
	return result;
}


int openrtb_bidding_create_request( void *in_request_params_x,
				    int request_count,
				    void *out_response_params_x, 
				    long campaign_id,
				    void *site_x,
				    cache_handle_t *cache_handle,
				    db_connection_t *dbconn,
				    const void * rt_request_url_params_mask1_x,
				    void *additional_parameter_x,
				    void *cmpg_dp_params_x,
				    char *request_url_with_mandatory_params,
				    char* post_data,
				    char* campaign_cookie,
				    void *adcampaign_x,
				    void *header_list_x,
				    int *size_header_list,
				    void* adcampaign_list_x,
				    const int nelements,
				    const int current_index,
				    void *p_buffer_tracker_x
                ) {
	(void) adcampaign_list_x;
	(void) nelements;
	(void) current_index;
	rt_request_params_t *in_request_params = (rt_request_params_t *) in_request_params_x;
	rt_response_params_t *out_response_params = (rt_response_params_t *) out_response_params_x;
	publisher_site_t *site = (publisher_site_t *)site_x;
	buffer_tracker_t *p_buffer_tracker = (buffer_tracker_t*)p_buffer_tracker_x ;
	const rt_request_url_params_mask_t * rt_request_url_params_mask1 =
                (rt_request_url_params_mask_t *) rt_request_url_params_mask1_x;
	ad_server_additional_params_t *additional_parameter = (ad_server_additional_params_t *)additional_parameter_x;
	campaign_data_provider_data_ops_params_t *cmpg_dp_params = (campaign_data_provider_data_ops_params_t *)cmpg_dp_params_x;
	publisher_site_ad_campaign_list_t *adcampaign = (publisher_site_ad_campaign_list_t *)adcampaign_x;
	struct curl_slist **header_list = (struct curl_slist**) header_list_x;

	//int retval=0;
	CURLcode curl_retval=CURLE_OK;	
	//int len_brand=0;
	char* temp_ptr;
	int post_data_len;
	memcached_blocklist_t *blocked_list = NULL;
    	int rtb_debug_flag = additional_parameter->adserver_config_params->rtb_debug_flag;
	post_data[0] = post_data[MAX_POST_DATA_LEN] = '\0';
	//gettimeofday(&tv1, NULL);	
	//out_response_params->curl_handle = curl_easy_init();

	//To avoid unused variable warning
        (void)cache_handle;
        (void)dbconn;
	(void)request_url_with_mandatory_params;

	if ( rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB) {
      		llog_write(L_DEBUG,"\nCREATING OPENRTB REQUEST FOR CAMPAIGN :%ld",campaign_id);
	}

	if(in_request_params->fte_additional_params->curl_handle_cache[request_count] ==  NULL) {
		//assert(0);
		in_request_params->fte_additional_params->curl_handle_cache[request_count] = curl_easy_init();
		if(in_request_params->fte_additional_params->curl_handle_cache[request_count] == NULL) {
			// curl easy init failed :(
			llog_write(L_DEBUG,"\nERROR: Curl easy handle failed %s:%d\n",__FILE__,__LINE__);
			return(RTB_ERROR);
		}
	}

	//create request url
	if (rt_request_url_params_mask1->use_drproxy == 1) {
	nstrcpy(out_response_params->bid_response_params.request_url, g_drproxy_url, MAX_REQUEST_URL_SIZE);
	} else if (1 == rt_request_url_params_mask1->use_gopro) {
		nstrcpy(out_response_params->bid_response_params.request_url,
				g_gopro_url, MAX_REQUEST_URL_SIZE);
	} else {
	nstrcpy(out_response_params->bid_response_params.request_url,rt_request_url_params_mask1->ad_nw_url,MAX_REQUEST_URL_SIZE);
	}
	
	if ( rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB) {
		llog_write(L_DEBUG,"\nOPENRTB: Request URL is '%s', cId:%ld", out_response_params->bid_response_params.request_url, campaign_id);
	}

	//Use ${AUCTION_CLICKTRACK_URL} as clicktrack keyword
	strcpy(out_response_params->bid_response_params.clicktrack_keyword, OPENRTB_CLICKTRACK_KEYWORD);
	//Use Standard ${AUCTION_PRICE} as second price macro
	strcpy(out_response_params->bid_response_params.second_price_macro, OPENRTB_SECOND_PRICE_MACRO);

	if ( (rt_request_url_params_mask1->cookie == 1) && (in_request_params->request_url_params.cookie[0] != '\0') &&
             (in_request_params->ad_server_req_gen_params->pubmatic_opt_out == PUBMATIC_OPT_OUT_FALSE)  ) {
                // store this cookie for logging purposes
                strncpy(campaign_cookie, in_request_params->request_url_params.cookie, MAX_COOKIE_SIZE);
                campaign_cookie[MAX_COOKIE_SIZE] = '\0';
        }
	
	//Caching the easy handles
	/* Call curl functions now */
	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
			CURLOPT_URL, 
			out_response_params->bid_response_params.request_url);

	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}
	// Whether to use this or use curl_easy_reset?
	//curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
	//		CURLOPT_HTTPGET, 
	//		1L);

   	if(curl_retval != CURLE_OK ){
 	 	return(RTB_ERROR);
   	}

	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
			CURLOPT_WRITEFUNCTION,
			default_process_response);

	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}

	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
			CURLOPT_WRITEDATA, 
			(void *)&(out_response_params->bid_response_params));

	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}

	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],
			CURLOPT_NOSIGNAL, 1);

	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}


	blocked_list = in_request_params->pub_site_rich_media_params->blocked_list;
    if (	blocked_list != NULL &&
			blocked_list->json_total_len > 12)
	{
            temp_ptr = blocked_list->json_url_blocked_list;
            //temp_ptr=deserialize_int(temp_ptr,&len_brand);
		//temp_ptr+=len_brand;
            temp_ptr = deserialize_int((unsigned char *)temp_ptr, &blocked_list->json_blocked_creative_attributes_len);
            temp_ptr += blocked_list->json_blocked_creative_attributes_len;
            temp_ptr = deserialize_int((unsigned char *)temp_ptr, &blocked_list->json_blocked_advt_categories_len);
            temp_ptr += blocked_list->json_blocked_advt_categories_len;
	    temp_ptr = deserialize_int((unsigned char *)temp_ptr, &blocked_list->json_blocked_iab_advt_categories_len);
            temp_ptr +=  blocked_list->json_blocked_iab_advt_categories_len;
            temp_ptr = deserialize_int((unsigned char *)temp_ptr, &blocked_list->json_url_blockedlist_len);
	}
	else if (blocked_list != NULL)
	{
            blocked_list->json_blocked_creative_attributes_len = 0;
            blocked_list->json_blocked_advt_categories_len = 0;
	    blocked_list->json_blocked_iab_advt_categories_len = 0;
	    blocked_list->json_url_blockedlist_len = 0;
	}

#ifdef FUNCTIONAL_TESTING
		if (blocked_list != NULL)
		{
			llog_write(L_DEBUG,"\nlen_creative_attributes=%d len_advt_categories=%d len_advt_iab_categories=%d len_url=%d allowed_creative_attributes=%d %s:%d\n",
        	                blocked_list->json_blocked_creative_attributes_len,
                	        blocked_list->json_blocked_advt_categories_len,
				blocked_list->json_blocked_iab_advt_categories_len,
                        	blocked_list->json_url_blockedlist_len,
	                        blocked_list->json_allowed_creative_attributes_list_len,
				__FILE__,
				__LINE__);
		}
#endif

		//Update domain_blocklist at site_campaign level
		const char *badv_domain_json=NULL;
		if(in_request_params->fte_additional_params->publisher_level_settings.badv_domain_feedback_enabled && adcampaign->max_badv_count > 0){
			badv_domain_json=cache_get_badv_domain_json( cache_handle,
					dbconn,
					in_request_params->in_server_req_params->publisher_id, 
					in_request_params->in_server_req_params->site_id,
					adcampaign->campaign_id);
		}

		post_data_len=get_openrtb_request_object(post_data,
				cmpg_dp_params,
				in_request_params,
				rt_request_url_params_mask1,
				additional_parameter,
				adcampaign,
				site,
				out_response_params,
				badv_domain_json );

		memcached_release_object_reference((char**)&badv_domain_json);

		if (rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB) {
			fprintf(stderr,"\n cid: %u post_data_len=%d and post_data = ", adcampaign->campaign_id, post_data_len);
			fprintf(stderr,"%.*s\n",(int)post_data_len,post_data);
		}

		post_data[post_data_len]='\0';
#ifdef RTB_JSON_TESTING
		validate_json(post_data);
#endif

		if( post_data_len > MAX_POST_DATA_LEN*0.8 ) {
						LOG_FATAL( CAPACITY_REACHED, MOD_DEFAULT, "Bid request JSON holding buffer used > 80%");
		}

	if( in_request_params->in_server_req_params->wakanda_enabled )
	{
		dsp_message_t *dsp_msg = (dsp_message_t*)malloc( sizeof(dsp_message_t) ) ;
		dsp_msg->message = strndup( post_data, post_data_len ) ;
		dsp_msg->message_len = post_data_len ;
		dsp_msg->campaignid = adcampaign->campaign_id ;
		dsp_msg->next = in_request_params->fte_additional_params->dsp_req ;

		in_request_params->fte_additional_params->dsp_req = dsp_msg ;
	}

	uint8_t *compressed_buf = NULL ;
  
	if( rt_request_url_params_mask1->bidrequest_compress )
	{
		compressed_buf = try_compression( post_data, &post_data_len, adcampaign->campaign_id,
				( rtb_debug_flag == DEBUG_RTB || rtb_debug_flag == DEBUG_OPENRTB ) ) ;

		if( compressed_buf )
		{
			if( registerBuffer( p_buffer_tracker, compressed_buf ) == 0 )
			{
				return(RTB_ERROR);
			}
		}
	}

	curl_retval =  curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count], CURLOPT_POSTFIELDSIZE, post_data_len);
	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}
	curl_retval =  curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count], CURLOPT_POSTFIELDS,  ( compressed_buf ) ? ( (char*)compressed_buf ) : ( post_data ) );
	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}
      	
	char x_purl_buff[1024];
	x_purl_buff[0] = '\0' ;
	int use_proxy = 1 == rt_request_url_params_mask1->use_drproxy ||
			1 == rt_request_url_params_mask1->use_gopro;
	if (use_proxy) {
		char header[32];
		int n = snprintf(header, 32, "X-cid: %u", adcampaign->campaign_id);
		if (32 <= n) {
			ERROR_LOG("String buffer overflow while writing X-cid.  Buffer length required = %d", n);
		}
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], header);

		snprintf(x_purl_buff, sizeof(x_purl_buff), "X-purl: %s", rt_request_url_params_mask1->ad_nw_url);
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list], x_purl_buff);

		snprintf(header, sizeof(header) -1,REQ_ADSERVER_TIMEOUT_HEADER_TEMPLATE, additional_parameter->rtb_timeout);
		header[sizeof(header) -1] = '\0';
		
		header_list[*size_header_list] = curl_slist_append(header_list[*size_header_list],header);
	} 

	struct curl_slist *hdr = rtb_req_proxy_get_headers(
                  header_list,
                  size_header_list, ( compressed_buf != NULL ), x_purl_buff
                  ); 
	
	curl_retval =  curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],CURLOPT_HTTPHEADER, hdr);

	
	if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
	}


	if( rt_request_url_params_mask1->bidresponse_compress )
	{
		curl_retval = set_response_compress_flags( in_request_params->fte_additional_params->curl_handle_cache[request_count] ) ;
		
		if(curl_retval != CURLE_OK ){
		return(RTB_ERROR);
		}
	}

	curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count], CURLOPT_HEADERFUNCTION, openrtb_process_header);      
	if(curl_retval != CURLE_OK ){
              	return(RTB_ERROR);
       	}

        curl_retval = curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count], CURLOPT_HEADERDATA, (void *)&(out_response_params->bid_response_params));
        if(curl_retval != CURLE_OK ){
            	return(RTB_ERROR);
       	}
	
	// remove
	/* Keeping high versose level for testing and debugging */
#ifdef FUNCTIONAL_TESTING_LOGGER_CURL
	curl_easy_setopt(in_request_params->fte_additional_params->curl_handle_cache[request_count],CURLOPT_VERBOSE, 1);
#endif

	/* we are done with setting up the request */
	return(RTB_SUCCESS);
}


static int create_device_geo_object(char **post_data,
		rt_request_params_t *in_request_params,
		ad_server_additional_params_t *additional_parameter,
		bool lat_lon_masking_enabled,
		int is_mob_impression,
		int has_device_params)
{
	char* post_temp_ptr=(*post_data);
	//temp geo parameters
	char *country = NULL;
	char *state = NULL;
	char *city = NULL;
	float *latitude = NULL;
	float *longitude = NULL;
	int *dma = NULL;
	char *postal_code = NULL;
	int has_geo_params = 0;
	int loc_info_sent = 0;
	int enable_app_geo_mstats_flag =    additional_parameter->enable_app_geo_mstats_flag;
	//bool lat_lon_masking_enabled =  adcampaign->ad_campaign_list_setings->lat_lon_masking_enabled;
	mobile_param_stats_t* mobile_param_flags = &(additional_parameter->mobile_param_flags);
	float lat = 0.0, lon = 0.0, count = 0; 
	const ad_server_req_param_t* req_params = in_request_params->in_server_req_params;


	if (in_request_params->ad_server_req_gen_params->remote_ip_addr != NULL && in_request_params->ad_server_req_gen_params->remote_ip_addr[0] != '\0') {
		country = additional_parameter->gd.iso_country_code;
		state = additional_parameter->gd.region_code;
		city = additional_parameter->gd.city;
		latitude = &(additional_parameter->gd.latitude);
		longitude =  &(additional_parameter->gd.longitude);
		dma = &(additional_parameter->gd.dma_code);
		postal_code = additional_parameter->gd.postal_code;
	}

	if (false == (( is_mob_impression != 1 
					&&
					country != NULL && country[0] != '\0' && state != NULL && city != NULL 
				  )
				|| ( is_mob_impression == 1 )
				)
	   ) {
		return has_device_params;
	}

	if (in_request_params->in_server_req_params->mobile_device_location[0] != '\0') {
		//Publisher passed Mobile Device location.
		count = sscanf(in_request_params->in_server_req_params->mobile_device_location,"%f,%f",&lat,&lon);
	}

	/* DEVICE GEO OBJECT START*/
	json_append_value_string(&post_temp_ptr, O_GEO_STRING, has_device_params);
	//Country
	if (country != NULL && country[0] != '\0') {
		if ( in_request_params->rt_custom_params.maxmind_country_code != NULL ) { //alpha3 code
			json_append_string(&post_temp_ptr, O_COUNTRY, in_request_params->rt_custom_params.maxmind_country_code, has_geo_params);
		} else {
			json_append_string(&post_temp_ptr, O_COUNTRY, country, has_geo_params);
		}
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->device_obj.geo.country[0]) &&
				(0 == strcasecmp(country, req_params->device_obj.geo.country))) {
			SET_MOBILE_PARAM_FLAG(device_counter, dcountrymrq);
		}

	}
	//State
	if (state != NULL && state[0] != '\0') {
		json_append_string(&post_temp_ptr, O_REGION, state, has_geo_params);
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->device_obj.geo.state[0]) &&
				(0 == strcasecmp(state, req_params->device_obj.geo.state))) {
			SET_MOBILE_PARAM_FLAG(device_counter, dstatemrq);
		}

	}
	//City
	if (city != NULL && city[0] != '\0') {
		json_append_string(&post_temp_ptr, O_CITY, city, has_geo_params);
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->device_obj.geo.city[0]) &&
				(0 == strcasecmp(city, req_params->device_obj.geo.city))) {
			SET_MOBILE_PARAM_FLAG(device_counter, dcitymrq);
		}
	}
	//dma
	if ( dma != NULL && (*dma != 0) ) {
		json_append_int(&post_temp_ptr, O_METRO, *dma, has_geo_params, ADD_QUOTE);
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->device_obj.geo.dma[0])) {
			if (atoi(req_params->device_obj.geo.dma) == *dma) {
				SET_MOBILE_PARAM_FLAG(device_counter, ddmamrq);
			}
		}
	}

	if ( count == 2 ) { //Publisher passed loc
		if ( in_request_params->in_server_req_params->loc_source == 1 
				|| 
				in_request_params->in_server_req_params->loc_source == 2
		   ) { // if loc_source is 1 OR 2
			if(1 == lat_lon_masking_enabled){
				json_append_double_truncated(&post_temp_ptr, O_LAT, lat, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
				json_append_double_truncated(&post_temp_ptr, O_LON, lon, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
			}
			else{
				json_append_double(&post_temp_ptr, O_LAT, lat, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
				json_append_double(&post_temp_ptr, O_LON, lon, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
			}

			/*
			 * Here we caompre with device.geo's lat/lon
			 */
			if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->device_obj.geo.location[0]) &&
					(0 == strcasecmp(req_params->mobile_device_location, req_params->device_obj.geo.location))){
				SET_MOBILE_PARAM_FLAG(device_counter, dlocmrq);
			}

			json_append_int(&post_temp_ptr, O_GEO_TYPE, in_request_params->in_server_req_params->loc_source, has_geo_params, DONT_ADD_QUOTE);
			has_geo_params = 1;
			if ((1 == enable_app_geo_mstats_flag) && (req_params->device_obj.geo.loc_source == req_params->loc_source)){
				SET_MOBILE_PARAM_FLAG(device_counter, dloc_sourcemrq);
			}
		}
	} else if (is_mob_impression != 1) {
		if(latitude && IS_VALID_LATITUDE(*latitude)) {
			if(1 == lat_lon_masking_enabled){
				json_append_double_truncated(&post_temp_ptr, O_LAT, *latitude, has_geo_params, DONT_ADD_QUOTE);
			}
			else{
				json_append_double(&post_temp_ptr, O_LAT, *latitude, has_geo_params, DONT_ADD_QUOTE);
			}
			has_geo_params = 1;
			loc_info_sent = 1;
		}
		if(longitude && IS_VALID_LONGITUDE(*longitude)) {
			if(1 == lat_lon_masking_enabled){
				json_append_double_truncated(&post_temp_ptr, O_LON, *longitude, has_geo_params, DONT_ADD_QUOTE);
			}
			else{
				json_append_double(&post_temp_ptr, O_LON, *longitude, has_geo_params, DONT_ADD_QUOTE);
			} 
			has_geo_params = 1;
			loc_info_sent = 1; 
		}
		if (loc_info_sent == 1) {
			json_append_int(&post_temp_ptr, O_GEO_TYPE, GEO_SOURCE_IP_ADDRESS, has_geo_params, DONT_ADD_QUOTE);
			has_geo_params = 1;
		}
	}
	if (postal_code != NULL && postal_code[0] != '\0') {
		json_append_string(&post_temp_ptr, O_ZIP, postal_code, has_geo_params);
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->device_obj.geo.zip_code[0]) &&
				(0 == strcasecmp(postal_code, req_params->device_obj.geo.zip_code))){
			SET_MOBILE_PARAM_FLAG(device_counter, dzipmrq);
		}
	}

	if (has_geo_params == 0) {
		post_temp_ptr -= strlen(O_GEO_STRING);
		if (has_device_params == 1) { //have some device params before it. so remove last comma
			post_temp_ptr -= 1;
		}
	} else {
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		has_device_params = 1; //since geo object is nested in device object
	}

	/*DEVICE GEO OBJECT END*/
	(*post_data)=post_temp_ptr;
	return has_device_params;
}

static int create_user_geo_object(char **post_data,
		const rt_request_params_t *in_request_params,
		ad_server_additional_params_t *additional_parameter,
		bool lat_lon_masking_enabled,
		//int is_mob_impression,
		int has_user_params)
{
	char* post_temp_ptr=(*post_data);

	int has_geo_params = 0;
	int enable_app_geo_mstats_flag =    additional_parameter->enable_app_geo_mstats_flag;
	mobile_param_stats_t* mobile_param_flags = &(additional_parameter->mobile_param_flags);
	float lat = 0.0, lon = 0.0, count = 0; 
	const ad_server_req_param_t* req_params = in_request_params->in_server_req_params;

	if (in_request_params->in_server_req_params->mobile_device_location[0] != '\0') {
		//Publisher passed Mobile Device location.
		count = sscanf(in_request_params->in_server_req_params->mobile_device_location,"%f,%f",&lat,&lon);
	}

	/*USER GEO START*/
	json_append_value_string(&post_temp_ptr, O_GEO_STRING, has_user_params);

	//Publisher Passed Mobile Device location.
	if ( count == 2 ) {
		if ( in_request_params->in_server_req_params->loc_source == 0
				||
				in_request_params->in_server_req_params->loc_source == 1 //Kept for backward compatibility, remove later
				||
				in_request_params->in_server_req_params->loc_source == 3
		   ) {
			if(1 == lat_lon_masking_enabled){
				json_append_double_truncated(&post_temp_ptr, O_LAT, lat, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
				json_append_double_truncated(&post_temp_ptr, O_LON, lon, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
			}
			else{
				json_append_double(&post_temp_ptr, O_LAT, lat, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
				json_append_double(&post_temp_ptr, O_LON, lon, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
			}

			/*
			 * Here We are comparing lat lon with user's lat/lon
			 */
			if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->user_obj.geo.location[0]) &&
					(0 == strcasecmp(req_params->mobile_device_location, req_params->user_obj.geo.location))) {
				SET_MOBILE_PARAM_FLAG(user_counter, ulocmrq);
			}

			if (in_request_params->in_server_req_params->loc_source != 0) {
				json_append_int(&post_temp_ptr, O_GEO_TYPE, in_request_params->in_server_req_params->loc_source, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
				if ((1 == enable_app_geo_mstats_flag) && (req_params->user_obj.geo.loc_source == req_params->loc_source)) {
					SET_MOBILE_PARAM_FLAG(user_counter, uloc_sourcemrq);
				}
			}

		}
	}
	if (in_request_params->in_server_req_params->country[0] != '\0') {
		if ( in_request_params->rt_custom_params.publisher_country_code != NULL ) {
			json_append_string(&post_temp_ptr, O_USER_COUNTRY, in_request_params->rt_custom_params.publisher_country_code, has_geo_params);
		} else {
			json_append_string(&post_temp_ptr, O_USER_COUNTRY, in_request_params->in_server_req_params->country, has_geo_params);
		}
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->user_obj.geo.country[0]) &&
				(0 == strcasecmp(req_params->country, req_params->user_obj.geo.country))){
			SET_MOBILE_PARAM_FLAG(user_counter, ucountrymrq);
		}
	}
	if (in_request_params->in_server_req_params->state[0] != '\0'){
		json_append_string(&post_temp_ptr, O_USER_REGION, in_request_params->in_server_req_params->state, has_geo_params);
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->user_obj.geo.state[0]) &&
				(0 == strcasecmp(req_params->state, req_params->user_obj.geo.state))){
			SET_MOBILE_PARAM_FLAG(user_counter, ustatemrq);
		}
	}

	if (in_request_params->in_server_req_params->city[0] != '\0'){
		json_append_string(&post_temp_ptr, O_USER_CITY, in_request_params->in_server_req_params->city, has_geo_params);
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->user_obj.geo.city[0]) &&
				(0 == strcasecmp(req_params->city, req_params->user_obj.geo.city))){
			SET_MOBILE_PARAM_FLAG(user_counter, ucitymrq);
		}
	}

	if (in_request_params->in_server_req_params->zip_code[0] != '\0'){
		json_append_string(&post_temp_ptr, O_USER_ZIP, in_request_params->in_server_req_params->zip_code, has_geo_params);
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->user_obj.geo.zip_code[0]) &&
				(0 == strcasecmp(req_params->zip_code, req_params->user_obj.geo.zip_code))){
			SET_MOBILE_PARAM_FLAG(user_counter, uzipmrq);
		}
	}

	if(in_request_params->in_server_req_params->dma[0] != '\0'){
		int dma_code = 0;
		dma_code = atoi(in_request_params->in_server_req_params->dma);
		json_append_int(&post_temp_ptr, O_METRO, dma_code, has_geo_params, ADD_QUOTE);
		has_geo_params = 1;
		if ((1 == enable_app_geo_mstats_flag) && ('\0' != req_params->user_obj.geo.dma[0]) &&
				(0 == strcasecmp(req_params->dma, req_params->user_obj.geo.dma))){
			SET_MOBILE_PARAM_FLAG(user_counter, udmamrq);
		}
	}

	if (has_geo_params == 0) {
		//if no geo parameter found, do not send empty geo object "geo{}"
		post_temp_ptr -= strlen(O_GEO_STRING);
		if (has_user_params == 1) { //have some user params before it. so remove last comma
			post_temp_ptr -= 1;
		}
	} else {
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		has_user_params = 1; //since geo object is nested in user object
	}

	(*post_data)=post_temp_ptr;
	return has_user_params;
}

#ifdef UNIT_TEST
int ut_create_pmp_object( char **post_data, publisher_site_ad_campaign_list_t *adcampaigns,
								const rt_request_url_params_mask_t * rt_request_url_params_mask1,
								fte_additional_params_t *fte_additional_parameters ) {
				return create_pmp_object( post_data, adcampaigns,
												rt_request_url_params_mask1,
												fte_additional_parameters ) ;
}
#endif


