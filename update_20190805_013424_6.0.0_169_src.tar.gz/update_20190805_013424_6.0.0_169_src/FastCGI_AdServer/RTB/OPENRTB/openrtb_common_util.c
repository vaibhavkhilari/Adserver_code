	/*
	 PubMatic Inc. ("PubMatic") CONFIDENTIAL
	 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/
#include <errno.h>
#include <sys/syscall.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>     
#include <stdio.h>
#include <rtb_util.h>
#include <ad_server_types.h>
#include <zlib.h>
#include "openrtb.h"
#include "string_util.h"
#include "http_response_wrapper.h"
#include "json_wrapper.h"
#include "rtb_gdpr_vendor_provider_mapping.h"

typedef enum _ortb_version {
	ORTB_2_0 = 20,
	ORTB_2_1 = 21,
	ORTB_2_3 = 23,
	ORTB_2_5 = 25,
	ORTB_3_0 = 30,
} ortb_version_t;

#define INITIAL_STRING      "{"
#define END_STRING     "}"
#define ARR_START_STRING      "["
#define ARR_END_STRING      "]"


#define O_DEVICE_IP "ip"
#define O_DEVICE_IPV6 "ipv6"
#define O_PAGEURL "page"
#define O_SITE_DOMAIN "domain"
#define ADD_COMMA 1

/* This is Native image icon asset related fix: ASD-4222 */
#define NATIVE_IMG_OBJ_STR "\"img\""
#define NATIVE_IMG_OBJ_STR_LEN 5
#define NATIVE_TYPE_ATTR_STR "\"type\""
#define NATIVE_TYPE_ATTR_STR_LEN 6
#define NATIVE_IMG_TYPE_ICON '1'
#define NATIVE_IMG_TYPE_LOGO '2'

#define DONT_ADD_COMMA 0
#define ADD_QUOTE 	1
#define O_PUBLISHER_STRING "\"publisher\":{"
#define O_PUBLISHER_ID "id"
#define O_PUBLISHER_COMPANY_NAME "name"

/* Consumer Identifier Object */
#define O_EIDS_STRING "\"eids\":["
#define O_EID_SOURCE "source"
#define O_UIDS_STRING "\"uids\":["
#define O_EID_UIDS_ID "id"
#define O_EID_UIDS_ATYPE "atype"
#define O_DIGITRUST_SOURCE_2X "\"digitrust\":{"
#define O_TTD_SOURCE_X "adserver.org"
#define EXT_TTD_EID_2x3x "\"ext\":{\"rtiPartner\":\"TDID\"}"
#define O_BIDFLOOR_CURRENCY "bidfloorcur"
#define O_SSP_NAME "ssp"

/* Supply Chain Object */
#define O_SCO_SUPPLY_CHAIN_OBJ "\"schain\":{"
#define O_SCO_VERSION "ver"
#define O_SCO_DEFAULT_VERSION "1.0"
#define O_SCO_COMPLETE "complete"
#define O_SCO_NODES_ARRAY ",\"nodes\":"
#define O_SCO_ASI "asi"
#define O_SCO_SID "sid"
#define O_SCO_RID "rid"
#define O_SCO_HP "hp"
#define O_SCO_HP_VALUE 1

extern int g_min_payload_for_compression ;

/*
 * Function to parse response header and get response code
 * Response code 204 indicates Zero Bid
 */
size_t openrtb_process_header(
		void* header_data,
		size_t size,
		size_t nmemb,
		void* bid_response_params_ptr
		) {
	size_t realsize = size * nmemb;
	char* buf = strndup( header_data, realsize ) ;
	rt_bid_response_params_t* bid_response_params = (rt_bid_response_params_t*)bid_response_params_ptr;
	char *ptr_temp = NULL;
	OPENRTB_DEBUG("Parsing response header. Header received: %s",buf);

	if (bid_response_params->http_response_code == -1) {
		long temp_status_code = strtol(buf + sizeof("HTTP/x.x")- 1, NULL, 10);
		bid_response_params->http_response_code = (int) temp_status_code;
		bid_response_params->req_processed = 1;
		OPENRTB_DEBUG("HTTP status code:%d",bid_response_params->http_response_code);
		if ( ! bid_response_params->stamp_after_api_call.tv_sec && ! bid_response_params->stamp_after_api_call.tv_usec )
			gettimeofday(&bid_response_params->stamp_after_api_call, NULL);
	}


	if( 1 != bid_response_params->gzipped &&
	    (ptr_temp = strcasestr( buf, RES_CONTENT_ENCODING_HEADER ) )){

		ptr_temp = strchr(ptr_temp + (sizeof(RES_CONTENT_ENCODING_HEADER) - 1) , ':');
		if (ptr_temp && '\0' != ptr_temp[1] ){
			char encoding[32] ;
			
			encoding[0] = '\0';
			ptr_temp++;

			sscanf( ptr_temp, "%s", encoding ) ;
			if( !strcasecmp( encoding, COMPRESSION_GZIP) ){
				OPENRTB_DEBUG("Compressed response encoding is \"%s\"", encoding ) ;
				bid_response_params->gzipped = 1 ;
			}
		}
	}else if( -1 == bid_response_params->flexidrproxy_dsp_status_code &&
		  (ptr_temp = strcasestr( buf, RES_DSP_STATUS_HEADER) )){
			
		ptr_temp = strchr(ptr_temp + (sizeof(RES_DSP_STATUS_HEADER) - 1) , ':');
		
		if (ptr_temp &&  '\0' != ptr_temp[1] ){
			ptr_temp++;
			bid_response_params->flexidrproxy_dsp_status_code = atoi(ptr_temp);
		}

	}
	OPENRTB_DEBUG("openrtb header :%s\n",buf ) ;	
	free(buf) ;

	return realsize;
}

void add_ip_in_json(char** post_data, int is_ipv4, char* ip, int add_comma){
	char* post_temp_ptr=(*post_data);	
	if(1 == is_ipv4){
		json_append_string(&post_temp_ptr, O_DEVICE_IP, ip, add_comma);
	}
	else{
		json_append_string(&post_temp_ptr, O_DEVICE_IPV6, ip, add_comma);
	}
	(*post_data)=post_temp_ptr;
	return;
}

/*
 * page url passing logic:
 * If url hiding is enabled as per publisher/site level settings and force_pageurl_transparency is disabled for pub/camapign,
 * then we pass the default url as configured in the DB.
 * If there is no default url(or null/empty url) in DB then we don't pass the url.
 * If url hiding is disabled as per publisher/site level settings, then we pass the pageurl from the adtag if
 * it is provided else we pass on the actual pageurl we get from showad.js script.
 */
void add_site_pagedomain_in_json(char** post_data, const publisher_site_ad_campaign_list_t *adcampaign, 
		const publisher_site_default_settings_t *pubsite_default_settings, const char* anonymized_pageurl, 
		const ad_server_req_param_t *in_server_req_params) {
	char* post_temp_ptr=(*post_data);

	if (pubsite_default_settings->url_hiding_enabled == 1
			&&
			(adcampaign->force_pageurl_transparency == DEFAULT_PAGEURL ||
			 pubsite_default_settings->force_pageurl_transparency == DEFAULT_PAGEURL)) {
		//pass anonymized page url/domain from DB
		if (anonymized_pageurl != NULL && anonymized_pageurl[0] != '\0') {
			json_append_escaped_string(&post_temp_ptr, O_PAGEURL,
					anonymized_pageurl,
					ADD_COMMA, MAX_PAGE_URL_SIZE);
		}
		if(in_server_req_params->anonymized_sitedomain 
				&&
				in_server_req_params->anonymized_sitedomain[0] != '\0') {
			json_append_escaped_string(&post_temp_ptr, O_SITE_DOMAIN,
					in_server_req_params->anonymized_sitedomain,
					ADD_COMMA, MAX_DOMAIN_NAME_LENGTH);
		}
	} else {
		//pass actual page url/domain
		if (
				in_server_req_params->decoded_final_extracted_url
				&&
				in_server_req_params->decoded_final_extracted_url[0] != '\0') {
			json_append_escaped_string(&post_temp_ptr, O_PAGEURL,
					in_server_req_params->decoded_final_extracted_url,
					ADD_COMMA, MAX_PAGE_URL_SIZE);
		}
		if (
				in_server_req_params->decoded_final_extracted_domain
				&&
				in_server_req_params->decoded_final_extracted_domain[0] != '\0') {
			json_append_escaped_string(&post_temp_ptr,
					O_SITE_DOMAIN,
					in_server_req_params->decoded_final_extracted_domain,
					ADD_COMMA, MAX_DOMAIN_NAME_LENGTH);
		}
	}

	(*post_data)=post_temp_ptr;
	return;
}

/*
 * Native object may contain zero or more 'img' objects.
 * if 'img' object has 'type' attribute and it's value is '1', change it to '2'
 */
void replace_native_img_icon_asset_type(char *native_obj) {
	char *ptr = native_obj;

	/* Find "img" string in native object string */
	while ((ptr = strstr(ptr, NATIVE_IMG_OBJ_STR)) != NULL) {
		ptr += NATIVE_IMG_OBJ_STR_LEN;

		/* Confirm that, found string is object */
		while (' ' == *ptr) { ptr++; }
		if (':' != *ptr) { continue; }

		/* Find "type" string */
		while ('}' != *ptr && '\0' != *ptr) {
			if (!(strncmp(ptr, NATIVE_TYPE_ATTR_STR, NATIVE_TYPE_ATTR_STR_LEN))) {
				ptr += NATIVE_TYPE_ATTR_STR_LEN;
				while ('\0' != *ptr) {
					if ((' ' == *ptr) || (':' == *ptr)) {
						ptr++;
						continue;
					}

					/* If type value is "1", replace it with "2" */
					if (NATIVE_IMG_TYPE_ICON == *ptr) {
						*ptr = NATIVE_IMG_TYPE_LOGO;
					}
					break;
				}
				break;
			} else {
				ptr++;
			}
		}

	}
}
/*
  Add publisher id object in json request 
  
*/
void add_publisherobj_injson(char **post_data,
							 const int send_origin_pubid_enabled,
							 const ad_server_req_param_t* req_params,
							 const rt_request_params_t*  in_request_params,	
							 const rt_request_url_params_mask_t* rt_request_url_params_mask,
							 int is_prefix_comma){

	if(1 == is_prefix_comma) {
		json_append_value_string(post_data, O_PUBLISHER_STRING, ADD_COMMA);
	} else {
		json_append_value_string(post_data, O_PUBLISHER_STRING, DONT_ADD_COMMA);
	}
	if (1 != send_origin_pubid_enabled ||
			'\0' == req_params->orig_publisher_id[0]){
		json_append_int(post_data, O_PUBLISHER_ID, (int)req_params->publisher_id, DONT_ADD_COMMA, ADD_QUOTE);
	}else{
		json_append_string(post_data, O_PUBLISHER_ID,   req_params->orig_publisher_id, DONT_ADD_COMMA);
	}
	if (1 != send_origin_pubid_enabled && 
			1 == rt_request_url_params_mask->send_publisher_name && 
			'\0' != in_request_params->fte_additional_params->publisher_level_settings.company_name[0]){
		json_append_string(post_data, O_PUBLISHER_COMPANY_NAME, in_request_params->fte_additional_params->publisher_level_settings.company_name, ADD_COMMA);
	}
	json_append_value_string(post_data, END_STRING, DONT_ADD_COMMA);
}

uint8_t* try_compression( const char* post_data, int* p_post_data_len, unsigned int campaign_id, uint8_t debug )
{
        uint8_t compression_done = 0 ;

        uint64_t compressed_len = (uint64_t)(*p_post_data_len-1) ; 
        uint8_t *compressed_buffer = NULL ;
        int retval = Z_OK ;
        struct timespec starttime, endtime ;
        uint64_t difftime = 0 ;

        static uint64_t total_compress_time = 0 ;
        static uint64_t compress_count = 0 ;
        static time_t previous_print_sec = 0 ;

        if( *p_post_data_len < g_min_payload_for_compression )
	{
		if( debug )
		{
			llog_write(L_DEBUG, "\nCompression %s on request. Uncompressed len: %d, Payload less that minimum needed %d\n",
					( compression_done ) ? ( "done" ) : ( "not done" ),
					*p_post_data_len, g_min_payload_for_compression ) ;
		}
                return NULL ;
        }

        compressed_buffer = (uint8_t*)malloc(compressed_len) ;
        
        uint64_t uncompressed_len = (uint64_t)(*p_post_data_len) ;

        clock_gettime(CLOCK_REALTIME, &starttime);

        z_stream stream ;

        stream.zalloc = Z_NULL;
        stream.zfree = Z_NULL;
        stream.opaque = (voidpf)0;
        
        stream.next_in = (Bytef*)post_data;
        stream.avail_in = (uInt)(*p_post_data_len);
        stream.next_out = (Bytef*)compressed_buffer;
        stream.avail_out = (uInt)compressed_len ;
 
        retval = deflateInit2( &stream, Z_DEFAULT_COMPRESSION, Z_DEFLATED, 31, 9, Z_DEFAULT_STRATEGY ) ;

        retval = deflate(&stream, Z_FINISH);

        if( retval == Z_STREAM_END )
        {
                compression_done = 1 ;
                compressed_len = stream.total_out;
                *p_post_data_len = compressed_len ;
        }
        else
	{
		llog_write(L_DEBUG,"\nCampaign: %u, Compression NOT done for request since deflate() failed with return code = %d %s:%d\n",
				campaign_id, retval, __FILE__,__LINE__);
        }

        retval = deflateEnd( &stream );
        
        clock_gettime(CLOCK_REALTIME, &endtime);

        difftime = ( endtime.tv_sec*1000000000uLL + endtime.tv_nsec ) - ( starttime.tv_sec*1000000000uLL + starttime.tv_nsec ) ;

        uint64_t avg_time = __sync_add_and_fetch( &total_compress_time, difftime )/__sync_add_and_fetch( &compress_count, 1 ) ;

        if( time(NULL) - previous_print_sec > 5 )
        {
                //print every 5 sec
                fprintf( stdout, "Average compression time: %lu microseconds\n", avg_time/1000 ) ;
                
                __sync_and_and_fetch( &total_compress_time, 0 ) ;
                __sync_and_and_fetch( &compress_count, 0 ) ;
                previous_print_sec = time(NULL) ;
                                
        }

	if( debug )
	{
		llog_write(L_DEBUG, "\nCampaign: %u, Compression %s for request. Uncompressed len: %lu, Compressed len: %lu, Zlib error code: %d, Time spent: %lu nanosec\n",
				campaign_id,
				( compression_done ) ? ( "done" ) : ( "not done" ),
				uncompressed_len, compressed_len, retval, difftime ) ;
	}

        if( compression_done == 0 )
        {
                free( compressed_buffer ) ;
                compressed_buffer = NULL ;
        }

        return compressed_buffer ;
}

uint8_t registerBuffer( buffer_tracker_t *p_buffer_tracker, uint8_t *buf )
{
	if( p_buffer_tracker->numBuffers >= sizeof(p_buffer_tracker->buffer_list)/sizeof(p_buffer_tracker->buffer_list[0] ) )
	{
		return 0 ;
	}

	p_buffer_tracker->buffer_list[p_buffer_tracker->numBuffers] = buf ;
	p_buffer_tracker->numBuffers++ ;

	return 1 ;
}

void clearBuffers( buffer_tracker_t *p_buffer_tracker )
{
        size_t i = 0 ;

        for( i = 0 ; i < p_buffer_tracker->numBuffers ; i++ )
        {
                free( p_buffer_tracker->buffer_list[i] ) ;
        }

	memset( p_buffer_tracker, 0, sizeof(buffer_tracker_t) ) ;
}

CURLcode set_response_compress_flags( CURL *easy_handle )
{
        CURLcode curl_retval=CURLE_OK;

        curl_retval = curl_easy_setopt(easy_handle, CURLOPT_ACCEPT_ENCODING, COMPRESSION_GZIP )  ; 
        if(curl_retval != CURLE_OK ){
                return curl_retval ;
        }    

        curl_retval = curl_easy_setopt(easy_handle, CURLOPT_HTTP_CONTENT_DECODING, 1 ) ;
        if(curl_retval != CURLE_OK ){
                return curl_retval;
        }

        return CURLE_OK ;
}

/*Common eid obj format for 2.x & 3.x */
void add_2x3x_common_consumer_id_object(char **post_data, 
		eid_t *cur_eid,
		int *has_eids_params) {
	int has_uids_params = 0, i = 0;
	char* post_temp_ptr = (*post_data);
	/*
	 * Collect { "source":"xyz", "uids":[{"id":"pqr", "atype":1},...] } json into cur_eid->uids_json_buf only once
	 * and append the collected json buff for all campaigns for this eid
	 */
	if ('\0' == cur_eid->uids_json_buf[0]) {
		char* uids_temp_ptr = (cur_eid->uids_json_buf);

		//add {	
		json_append_value_string(&uids_temp_ptr, INITIAL_STRING, DONT_ADD_COMMA);

		//add "source":"value"
		json_append_string(&uids_temp_ptr, O_EID_SOURCE,
				cur_eid->source, DONT_ADD_COMMA);
		/* UIDS OBJECT ARRAY START */
		//add "uids":[
		json_append_value_string(&uids_temp_ptr, O_UIDS_STRING, ADD_COMMA);

		//appned individual uids object in loop
		for (i=0; i<cur_eid->uid_count; i++) {
			//add { "id":"XYZ", "atype":1 }
			json_append_value_string(&uids_temp_ptr, INITIAL_STRING, has_uids_params);
			json_append_escaped_string(&uids_temp_ptr, O_EID_UIDS_ID, cur_eid->uids[i].id, DONT_ADD_COMMA, MAX_CUNSUMERID_UID_ID_LEN);
			if (cur_eid->uids[i].atype != -1){
				json_append_int(&uids_temp_ptr, O_EID_UIDS_ATYPE, cur_eid->uids[i].atype, ADD_COMMA, DONT_ADD_QUOTE);
			}
			//For TTD ad extention
			if(0 == strncasecmp(cur_eid->source, O_TTD_SOURCE_X, MAX_CONSUMERID_SOURCE_LEN)) {
				json_append_value_string(&uids_temp_ptr, EXT_TTD_EID_2x3x, ADD_COMMA);
			}
			json_append_value_string(&uids_temp_ptr, END_STRING, DONT_ADD_COMMA);
			has_uids_params = 1;
		}
		//add ]
		json_append_value_string(&uids_temp_ptr, ARR_END_STRING, DONT_ADD_COMMA);

		//add }
		json_append_value_string(&uids_temp_ptr, END_STRING, DONT_ADD_COMMA);

		//important to add null char at end of buffer
		*uids_temp_ptr = '\0';
	}

	//Append collected uids json
	if ('\0' != cur_eid->uids_json_buf[0])
		json_append_value_string(&post_temp_ptr, cur_eid->uids_json_buf, *has_eids_params);

	*has_eids_params = 1;
	(*post_data)=post_temp_ptr;

}


/* OpenRTB 2.X Add Consumer Identifier in "user.ext" */
int create_2_x_consumer_identifier_ext(
		char **post_data,
		const ad_server_req_param_t* req_params,
		const publisher_site_ad_campaign_list_t *adcampaign,
		int *has_ext_params) {

	char* post_temp_ptr = (*post_data);
	consumer_identifier_t *req_eid_obj = req_params->req_eid_obj;
	eid_t *digitrust_eid_ptr = NULL;
	int *eids_index_array = adcampaign->ad_campaign_list_setings->eids_index_array;
	if(-1 == eids_index_array[0] || NULL == req_eid_obj || NULL == req_eid_obj->eids){
		DEBUG_LOG("OPENRTB 2.X No eid index present or req_eid_obj is NULL");
		return -1;
	}
	int index = 0, eid_index = 0, has_eids_params = 0;

	while(-1 != eids_index_array[index]) {
		eid_index = eids_index_array[index];
		if(req_eid_obj->eid_count < eid_index){
			//Code Should not reach here, it is handled earlier
			ERROR_LOG("\nERROR:Request eids is NULL");
			return -1;
		}

		eid_t *cur_eid = &(req_eid_obj->eids[eid_index]);

		/*
		 * If partner/source is configured for oRTB 3.0 then it would have added to user.eids array
		 * If its not configured for oRTB 3.0 then add it as extension here
		 */
		if (//OPENRTB3_0 != cur_eid->ortb_version_format_touse &&
				'\0' != cur_eid->source[0] &&
				0 < cur_eid->uid_count) {
			/* since DigiTrust is having different source IS for 2.X and 3.0 And we
			 * are supporting 3.0 on receiving and passing in 2.X format to DSPs, we need to 
			 * use 2.X specific source id DigiTrust 2.X id = digitrust AND 3.0 = digitru.st, 
			 * we are hard coding conversion of 3.0 id to 2.X id below
			 */ 
			if(0 == strncasecmp(cur_eid->source, DIGITRUST_SOURCE_3X, MAX_CONSUMERID_SOURCE_LEN)) {
				digitrust_eid_ptr = cur_eid;
			}
			else {
				/*Add "eids": key only once only if there any uid to be added as per oRTB 3.0*/
				if (0 == has_eids_params) {
					/* EIDS OBJECT ARRAY START*/
					//add "eids":[\{
					json_append_value_string(&post_temp_ptr, O_EIDS_STRING, *has_ext_params);
				}
				add_2x3x_common_consumer_id_object(&post_temp_ptr, cur_eid, &has_eids_params);
				*has_ext_params = 1;
			}
		}
		index++;
	}

	if (1 == has_eids_params)
		json_append_value_string(&post_temp_ptr, ARR_END_STRING, DONT_ADD_COMMA);
	/* EIDS OBJECT ARRAY END */

	/*
	 * add source as key & prepolulated json of ids as value ( eg. "digitrust":{"id":"xyz"} )
	 * ONLY ONE ID WILL BE PASSED HERE DUE LIMITATION OF 2.X SPECS 
	 */
	if (digitrust_eid_ptr != NULL) {
		json_append_value_string(&post_temp_ptr, O_DIGITRUST_SOURCE_2X, *has_ext_params);
		//Only one uid is supported for digitrust in 2.x hence use uid[0].
		json_append_escaped_string(&post_temp_ptr, O_EID_UIDS_ID, digitrust_eid_ptr->uids[0].id, DONT_ADD_COMMA, MAX_CUNSUMERID_UID_ID_LEN);
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		*has_ext_params = 1;

	}

	(*post_data)=post_temp_ptr;
	return 0;
}


/* OpenRTB 3.0 Add Consumer Identifier in "user.eids" array */
int create_3_x_consumer_identifier_object(
		char **post_data,
		const ad_server_req_param_t* req_params,
		const publisher_site_ad_campaign_list_t *adcampaign,
		int *has_user_params) {
	int need_consumer_id_2_x_extension = 0;
	char* post_temp_ptr = (*post_data);
	consumer_identifier_t *req_eid_obj = req_params->req_eid_obj;
	int *eids_index_array = adcampaign->ad_campaign_list_setings->eids_index_array;
	if(-1 == eids_index_array[0] || NULL == req_eid_obj || NULL == req_eid_obj->eids){
		DEBUG_LOG("EID:OPENRTB 3.0 No eid index present or req_eid_obj is NULL : eids_index_array:%d req_eid_obj:%d", eids_index_array[0], (NULL == req_eid_obj));
		return -1;
	}

	int index = 0, eid_index = 0, has_eids_params = 0;
	while(-1 != eids_index_array[index]){
		eid_index = eids_index_array[index];
		if(req_eid_obj->eid_count < eid_index){
			//Code Should not reach here, it is handled earlier
			ERROR_LOG("\nEID:ERROR:Request eids is NULL");
			return -1;
		}
		eid_t *cur_eid = &(req_eid_obj->eids[eid_index]);



		/*
		 * Skip entry of uid in "eids" array if partner/source is not configured for oRTB 3.0 
		 * Add this consumer id as extension to "user" object
		 */
		/* if (OPENRTB3_0 > cur_eid->ortb_version_format_touse) {
		   DEBUG_LOG("EID:OPENRTB 3.0: Ignoring source:%s in eids, Its being added under user.ext because its configured for oRTB version %d i.e. 2.X", cur_eid->source, cur_eid->ortb_version_format_touse);
		   need_consumer_id_2_x_extension = 1;
		   index++;
		   continue;
		   }*/

		/*Add "eids": key only once only if there any uid to be added as per oRTB 3.0*/
		if (0 == has_eids_params) {
			/* EIDS OBJECT ARRAY START*/
			//add "eids":[
			json_append_value_string(&post_temp_ptr, O_EIDS_STRING, *has_user_params);
		}
		add_2x3x_common_consumer_id_object(&post_temp_ptr, cur_eid, &has_eids_params);
		*has_user_params = 1;
		index++;
	}
	if (1 == has_eids_params)
		json_append_value_string(&post_temp_ptr, ARR_END_STRING, DONT_ADD_COMMA);
	/* EIDS OBJECT ARRAY END */

	(*post_data)=post_temp_ptr;
	return need_consumer_id_2_x_extension;
}

//Create GEO Object for pass asis feature
//used in both 2.1 and 2.3
#define O_GEO_STRING "\"geo\":{"
#define O_CITY "city"
#define O_METRO "metro"
#define O_COUNTRY "country"
#define O_REGION "region"
#define O_LAT	"lat"
#define O_LON	"lon"
#define O_ZIP	"zip"
#define O_GEO_TYPE "type"
#define O_UTCOFFSET "utcoffset"
#define MAX_UTC_OFFSET (12*60)

#define O_ACCURACY "accuracy"
#define O_LASTFIX  "lastfix"
#define O_IPSERVICE "ipservice"

extern const char * get_alpha3_from_alpha2(const char *country);

int create_geo_object_pass_asis(char **post_data,
			int *is_pa_geo,
			int ortb_version,	//ORTB Version - few fields will be droped for lower versions
			const geo_obj_info_t *geo,	//Request geo fields
			const geo_data_t *gd, 	//IP inferred geo fields
			int is_coppa_compliant,
			bool lat_lon_masking_enabled,
			int has_parent_params)
{
	char* post_temp_ptr=(*post_data);
	//temp geo parameters
	const char *country = NULL;
	const char *state = NULL;
	const char *city = NULL;
	float latitude = INVALID_LAT_LONG;
	float longitude = INVALID_LAT_LONG;
	int loc_source = 0;
	int dma = 0;
 	int utcoffset = (-1*(MAX_UTC_OFFSET+1)); //for now set it to invalid offset to avoid when not present
	const char *postal_code = NULL;
	int has_geo_params = 0;

	float temp_lat = 0.0, temp_lon = 0.0, count = 0;
	int accuracy = -1, lastfix = -1, ipservice = -1;
	if (geo->location[0] != '\0') {
		//Publisher passed location.
		count = sscanf(geo->location,"%f,%f", &temp_lat, &temp_lon);
	}

	*is_pa_geo = 0; //assume not a pass asis

	if(2 == count) { //geo object found in the request with valid location
		*is_pa_geo = 1; //geo will be passed asis
		latitude = temp_lat;
		longitude =  temp_lon;
		loc_source = geo->loc_source;
		state = geo->state;
		city = geo->city;
		dma = atoi(geo->dma);
		postal_code = geo->zip_code;
		utcoffset = geo->utcoffset;
		country = geo->country;
		accuracy = geo->accuracy;
		lastfix = geo->lastfix;
	} else if(NULL != gd) {
		*is_pa_geo = 0;
		latitude = gd->latitude;
		longitude =  gd->longitude;
		loc_source = GEO_SOURCE_IP_ADDRESS;
		state = gd->region_code;
		city = gd->city;
		dma = gd->dma_code;
		postal_code = gd->postal_code;
		//utcoffset = TODO: need to check how to get utcoffset in case of ip inferred geo
		if (gd->iso_country_code != NULL && gd->iso_country_code[0] != '\0' ) {
			country = (char *)get_alpha3_from_alpha2(gd->iso_country_code);
		}
		ipservice = IPLS_DIGITAL_ELEMENT;
	}

	/* GEO OBJECT START*/
	json_append_value_string(&post_temp_ptr, O_GEO_STRING, has_parent_params);

	if(0 == is_coppa_compliant) { //Supress location, city, metro, zipcode for coppa
		//Lat,Lon
		if(IS_VALID_LATITUDE(latitude) && IS_VALID_LONGITUDE(longitude)) {
			if(1 == lat_lon_masking_enabled){
				json_append_double_truncated(&post_temp_ptr, O_LAT, latitude, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
				json_append_double_truncated(&post_temp_ptr, O_LON, longitude, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
			}
			else{
				json_append_double(&post_temp_ptr, O_LAT, latitude, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
				json_append_double(&post_temp_ptr, O_LON, longitude, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
			}
			//loc_source
			if(GEO_SOURCE_GPS_OR_LOCATION <= loc_source && loc_source <= GEO_SOURCE_USER_PROVIDED) {
				json_append_int(&post_temp_ptr, O_GEO_TYPE, loc_source, has_geo_params, DONT_ADD_QUOTE);
				has_geo_params = 1;
			}
		} else {
			llog_write(L_DEBUG, "MPA: Invalid location lat,lon=%.6f,%.6f", latitude, longitude);
		}
		//City
		if (city != NULL && city[0] != '\0') {
			json_append_string(&post_temp_ptr, O_CITY, city, has_geo_params);
			has_geo_params = 1;
		}
		//dma
		if ( dma > 0)  {
			json_append_int(&post_temp_ptr, O_METRO, dma, has_geo_params, ADD_QUOTE);
			has_geo_params = 1;
		}
		//zipcode
		if (postal_code != NULL && postal_code[0] != '\0') {
			json_append_string(&post_temp_ptr, O_ZIP, postal_code, has_geo_params);
			has_geo_params = 1;
		}
	}
	//Country
	if (country != NULL && country[0] != '\0') {
		json_append_string(&post_temp_ptr, O_COUNTRY, country, has_geo_params);
		has_geo_params = 1;
	}
	//State
	if (state != NULL && state[0] != '\0') {
		json_append_string(&post_temp_ptr, O_REGION, state, has_geo_params);
		has_geo_params = 1;
	}
	//utc-offset
	if (ortb_version >= ORTB_2_3 && utcoffset >= (-1*MAX_UTC_OFFSET) && utcoffset <= MAX_UTC_OFFSET) {
		json_append_int(&post_temp_ptr, O_UTCOFFSET, utcoffset, has_geo_params, DONT_ADD_QUOTE);
		has_geo_params = 1;
	}

	// accuracy
        if (0 < accuracy) {
                json_append_int(&post_temp_ptr, O_ACCURACY, accuracy, has_geo_params, DONT_ADD_QUOTE);
                has_geo_params = 1;
        }

        // lastfix
        if (-1 != lastfix) {
                json_append_int(&post_temp_ptr, O_LASTFIX, lastfix, has_geo_params, DONT_ADD_QUOTE);
                has_geo_params = 1;
        }

        // ipservice
        if (-1 != ipservice) {
                json_append_int(&post_temp_ptr, O_IPSERVICE, ipservice, has_geo_params, DONT_ADD_QUOTE);
                has_geo_params = 1;
        }

	if (has_geo_params == 0) {
		post_temp_ptr -= strlen(O_GEO_STRING);
		if (has_parent_params == 1) { //have some parent params before it. so remove last comma
			post_temp_ptr -= 1;
		}
	} else {
		json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);
		has_parent_params = 1; //since geo object is nested in parent object
	}

	/*GEO OBJECT END*/
	(*post_data)=post_temp_ptr;
	return has_parent_params;
}

int video_append_protocols(char **buff, const char *field_name, const char *value, int add_comma){
	int index;
	int bytes_written = 0;
	if(NULL == buff || NULL ==  *buff || NULL == value) {
		return VIDEO_RETURN_ERROR;
	}
	json_append_value_string(buff, field_name, add_comma);
	for(index = 1; index <= MAX_PROTOCOL_TYPE_VALUE; index++) {
		if(FLAG_SET == value[index]) {
			bytes_written = sprintf(*buff, "%d,", index);
			*buff += bytes_written;
		}
	}
	if(bytes_written > 0){
		(*buff)--;
	}
	memcpy(*buff, ARR_END_STRING, sizeof(ARR_END_STRING)-1);
	*buff += sizeof(ARR_END_STRING)-1;
	return VIDEO_RETURN_SUCCESS;
}

void gdpr_object_creation_decision(ad_server_req_param_t* req_params,
		fte_additional_params_t *fte_additional_params,
		int dont_pass_iab_consent_obj,
		int *add_gdpr_ext,
		int *add_iab_gdpr_consent,
		int *add_eb_provider_list,
		char **eb_provider_list) {

	if ((0 == req_params->gdpr_req_params.is_gdpr_req) && (0 == req_params->gdpr_req_params.is_req_from_gdpr_country)) {
		return;
	}

	if ((1 == req_params->gdpr_req_params.is_gdpr_req) &&
		(0 == dont_pass_iab_consent_obj)) {
		(*add_gdpr_ext) = 1;
		(*add_iab_gdpr_consent) = 1;
		(*add_eb_provider_list) = 1;
		(*eb_provider_list) = req_params->eb_cp_list_str;
	} else if ((1 == req_params->gdpr_req_params.is_gdpr_req) &&
		(1 == dont_pass_iab_consent_obj) &&
		(GDPR_PROTO_GOOGLE_EB == req_params->gdpr_req_params.gdpr_protocol)) {
		(*add_gdpr_ext) = 1;
		(*add_iab_gdpr_consent) = 0;
		(*add_eb_provider_list) = 1;
		(*eb_provider_list) = req_params->eb_cp_list_str;
	} else if ((1 == req_params->gdpr_req_params.is_gdpr_req || 1 == req_params->gdpr_req_params.is_req_from_gdpr_country) &&
		(2 == dont_pass_iab_consent_obj)) {
		(*add_gdpr_ext) = 1;
		(*add_iab_gdpr_consent) = 0;
		(*add_eb_provider_list) = 1;
		prepare_translated_eb_provider_id_list(req_params, fte_additional_params);
		(*eb_provider_list) = req_params->translated_eb_cp_list_str;
		req_params->gdpr_req_params.log_gdpr_info = 1;
	}
}

void append_supply_chain_object(char **post_data,
		rt_request_params_t* in_request_params,
		int *has_ext_params) {
	char* post_temp_ptr = (*post_data);
	ad_server_req_param_t *req_params = in_request_params->in_server_req_params;
	/* Check if this feature is OFF at global or pub level, empty ASI denotes feature OFF */
	if (0 == in_request_params->fte_additional_params->publisher_level_settings.send_supply_chain_object_in_rtb ||
		'\0' == req_params->schain_pubmatic_asi[0]) {
		return;
	}

	json_append_value_string(&post_temp_ptr, O_SCO_SUPPLY_CHAIN_OBJ, *has_ext_params);
	json_append_int(&post_temp_ptr, O_SCO_COMPLETE, req_params->schain_complete, DONT_ADD_COMMA, DONT_ADD_QUOTE);
	/* Add Schain object version, add default (1.0) if not receievd in request */
	if ('\0' == req_params->schain_version[0]) {
		json_append_string(&post_temp_ptr, O_SCO_VERSION, O_SCO_DEFAULT_VERSION, ADD_COMMA);
	} else {
		json_append_string(&post_temp_ptr, O_SCO_VERSION, req_params->schain_version, ADD_COMMA);
	}
	json_append_value_string(&post_temp_ptr, O_SCO_NODES_ARRAY, DONT_ADD_COMMA);
	/* If supply chain nodes array received in request, append PubMatic node */
	if('\0' != req_params->schain_nodes_str[0]) {
		json_append_value_string(&post_temp_ptr, req_params->schain_nodes_str, DONT_ADD_COMMA);
		json_append_value_string(&post_temp_ptr, INITIAL_STRING, ADD_COMMA);
	} else {
	/* If supply chain nodes array not received in request, create new nodes array with PubMatic node */
		json_append_value_string(&post_temp_ptr, ARR_START_STRING, DONT_ADD_COMMA);
		json_append_value_string(&post_temp_ptr, INITIAL_STRING, DONT_ADD_COMMA);
	}
	json_append_string(&post_temp_ptr, O_SCO_ASI, req_params->schain_pubmatic_asi, DONT_ADD_COMMA);
	json_append_int(&post_temp_ptr, O_SCO_SID, req_params->publisher_id, ADD_COMMA, ADD_QUOTE);

	/* Save pointers of 'rid' field, which will be used in MUX for replacing with respective requestID */
	in_request_params->replace_info[RT_SCO_REQUEST_ID].start = post_temp_ptr;
	json_append_string(&post_temp_ptr, O_SCO_RID, in_request_params->request_url_params.request_id[0], ADD_COMMA);
	in_request_params->replace_info[RT_SCO_REQUEST_ID].end = post_temp_ptr;

	/* Add 'hp' with value 1 always */
	json_append_int(&post_temp_ptr, O_SCO_HP, O_SCO_HP_VALUE, ADD_COMMA, DONT_ADD_QUOTE);
	json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);

	json_append_value_string(&post_temp_ptr, ARR_END_STRING, DONT_ADD_COMMA);
	json_append_value_string(&post_temp_ptr, END_STRING, DONT_ADD_COMMA);

	(*post_data)=post_temp_ptr;
	*has_ext_params = 1;
}

void openrtb_request_append_common_ext_object(char **post_data, rt_request_params_t*  in_request_params, const ad_server_additional_params_t *additional_parameter, const publisher_site_ad_campaign_list_t *adcampaign, int protocol, int *has_ext_params){

	char* post_temp_ptr = (*post_data);

	if (additional_parameter->soft_floor > 0.0000) {
		json_append_double(&post_temp_ptr, BID_GUIDE_FLOOR_STRING, CONVERT_USD_TO_NATIVE_CURRENCY(additional_parameter->soft_floor,
					adcampaign->dsp_currency_id,
					in_request_params->fte_additional_params->currency_xrate_map,
					in_request_params->fte_additional_params->currency_count),
				*has_ext_params, DONT_ADD_QUOTE);
		*post_temp_ptr = '\0';
		*has_ext_params = 1;

		//currency code of all other floors sent in ext
		if (adcampaign->dsp_currency_id != USD_CURRENCY_ID){
			json_append_string(&post_temp_ptr, O_BIDFLOOR_CURRENCY, GET_CURRENCY_CODE_FROM_ID(adcampaign->dsp_currency_id,
						in_request_params->fte_additional_params->currency_xrate_map,
						in_request_params->fte_additional_params->currency_count),
					*has_ext_params);
		*post_temp_ptr = '\0';
		}
	}

	if ('\0' != in_request_params->fte_additional_params->publisher_level_settings.ssp_name[0]){
		json_append_string(&post_temp_ptr, O_SSP_NAME, in_request_params->fte_additional_params->publisher_level_settings.ssp_name, *has_ext_params);
		*post_temp_ptr = '\0';
		*has_ext_params = 1;
	}
	/* Add Supply chain object in req.ext only for OpenRTB 2.1 and 2.3*/
	if (OPENRTB == protocol || OPENRTB2_3 == protocol) {
		append_supply_chain_object(&post_temp_ptr, in_request_params, has_ext_params);
	}

	(*post_data)=post_temp_ptr;
}
