<?php
/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


//set default timezone
date_default_timezone_set("America/Los_Angeles");

//next values in config_list will have operId = 9
$CONFIG_FILE="/SCRIPTS/BLOOM_FILTER_GENERATION/conf/url_config.ini";
$config_list="SET_CONFIG,URL_BLOOM_GENERATOR";

$config=parse_ini_file("$CONFIG_FILE",1);

$config_param=split(",",$config_list);

$has_db_connection=0;

$bloom_type_block_list=0;
$bloom_type_white_list=1;

//Exec script on server other than main DB, execute bin on main DB
//$master_db_user='mukulkedare';
//$master_db_host='10.0.12.63';
//$ssh_cmd='/usr/bin/ssh';

//read config.ini. config for select query will run on AdServer;
$SOURCE_HOST=$config[$config_param[0]]['adb.host.name'];
$SOURCE_KAD_DB=$config[$config_param[0]]['db.kad.dsn.name'];
$SOURCE_ADF_DB=$config[$config_param[0]]['db.adf.dsn.name'];
$SOURCE_USERNAME=$config[$config_param[0]]['db.dsn.user.name'];
$SOURCE_PASSWORD=$config[$config_param[0]]['db.dsn.user.password'];

$SOURCE_HOST_MAINDB=$config[$config_param[0]]['db.host.name'];


$BLOOM_BASE_DIR=$config[$config_param[0]]['bloom.base.dir'];
$FILTER_GENERATOR_BIN=$BLOOM_BASE_DIR."/".$config[$config_param[0]]['filter.generator.bin'];
$LAST_INSTANCE_CHECK_FILE=$BLOOM_BASE_DIR."/.".$config[$config_param[0]]['last.instance.check.file'];
$REPORT_FILE=$BLOOM_BASE_DIR."/".$config[$config_param[0]]['report.file'];
$TIME_INTERVAL="'".$config[$config_param[0]]['time.interval']."'";
$HOUR_INTERVAL=$config[$config_param[0]]['hour.interval'];

function send_report($file,$bloom_base_dir)
{
	global $config_param;

	$contents = ob_get_flush();
	file_put_contents($file,$contents);

	$subject = "BLOOM_".$config_param[1]."_GENERATOR";

	# Send the report via mail
	exec("php $bloom_base_dir/send_mail/sendmail.php $file $subject",$out,$ret);
	if($ret!=0) 
	{
		echo "\nERROR: Failed send mail cmd\n";
	}
	exit;
}

function cleanup_and_report($file,$bloom_base_dir,$pid_file)
{
	if(file_exists($pid_file))
	{
		unlink($pid_file);
	}
	send_report($file,$bloom_base_dir);
}

function remove_deleted_bloom($filter_type,$con, $DB_NAME, $select_removed_query,$delete_query,$select_mod_query_wl,$select_mod_query_bl,$cmd_update)
{
	$result=mysql_select_db($DB_NAME,$con);
	if(!$result)
	{
		echo "\nERROR::$filter_type: $DB_NAME Main DB Selection Failed\n".mysql_error()."\n";
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
	}
	//echo "\n$bloom_type_white_list"	;
	$select_removed_query=str_replace("BLOOM_TYPE_WHITE_LIST", 1, $select_removed_query);
	$select_removed_query=str_replace("BLOOM_TYPE_BLOCK_LIST", 0, $select_removed_query);
	$select_mod_query_wl=str_replace("BLOOM_TYPE_WHITE_LIST", 1, $select_mod_query_wl);
	$select_mod_query_bl=str_replace("BLOOM_TYPE_BLOCK_LIST", 0, $select_mod_query_bl);
	//echo "\n$filter_type:: Executing Query: $select_removed_query\n";
	$result=mysql_query($select_removed_query,$con);
	if(!$result) 
	{
		echo "\nERROR::$filter_type Query Execution Failed: $select_removed_query\n";
		cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
	}

	$p1='pub_id';
	$p2='site_id';
	$p3='bloom_type';
	$r1="PUBLISHER_ID";
	$r2="SITE_ID";
	$r3="BLOOM_TYPE";
	while($row = mysql_fetch_array($result))
	{
		//delete publisher site from bloom filter table
		$query=$delete_query;
		$query=str_replace($r1,$row[$p1],$query);
		$query=str_replace($r2,$row[$p2],$query);
		$query=str_replace($r3,$row[$p3],$query);
		//echo "\n$filter_type:: Executing Query: $query\n";
		$result_del=mysql_query($query,$con);
		if(!$result_del)
		{
			echo "\nERROR::$filter_type: Query Execution Failed: $query\n".mysql_error()."\n";
			cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
		}

		echo "\nDeleted $filter_type:: $p1:".$row[$p1]." $p2:".$row[$p2]." $p3:".$row[$p3]."\n";

		//update bloom filter of individual sites of this publishers... Set blocked_domain count-=blocked_domain_count_of_site_0
		if($row[$p2] == 0)
		{
			if($row[$p3]== $bloom_type_block_list ){
				$query=$select_mod_query_bl;
			}
			else{
				$query=$select_mod_query_wl;
			}

			$query=str_replace($r1,$row[$p1],$query);
			$query=str_replace($r3,$row[$p3],$query);
			$result_sites=mysql_query($query,$con);
			if(!$result_sites)
			{
				echo "\nERROR::$filter_type: Query Execution Failed: $query\n".mysql_error()."\n";
				cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
			}
			while($row_site = mysql_fetch_array($result_sites))
			{
				echo "\n$filter_type:: all $p2 change, $p1:".$row[$p1]." $p2:".$row_site[$p2]."\n";
				$cmd_update=$cmd_update." ".$row[$p1]." ".$row_site[$p2]." ".$row[$p3];
			}
			mysql_free_result($result_sites);
		}
	}
	mysql_free_result($result);
	return $cmd_update;
}




//check for last instance of the process
if(file_exists($LAST_INSTANCE_CHECK_FILE)) {
	exec("cat $LAST_INSTANCE_CHECK_FILE",$pid,$ret);
	if($ret!=0) {
		echo "\nERROR: Failed cat cmd\n";
		send_report($REPORT_FILE,$BLOOM_BASE_DIR);
	}
	echo "\npid in $LAST_INSTANCE_CHECK_FILE:$pid[0]\n";
	exec("ps $pid[0]",$out,$ret);
	if(count($out)>=2)
	{
		echo "\nERROR: Last Instance of bloom filter generator script is still running..., PID:$pid[0]\nExiting...\n";
		send_report($REPORT_FILE,$BLOOM_BASE_DIR);
	}
	else 
	{
		echo "\nINFO::pid file Exist, No last instance running, mypid:".getmypid()."\n";
		$pid_fd = fopen($LAST_INSTANCE_CHECK_FILE, 'w');
		if(!$pid_fd)
		{
			echo "\nERROR: Failed to open $LAST_INSTANCE_CHECK_FILE\n";
			send_report($REPORT_FILE,$BLOOM_BASE_DIR);
		}
		fwrite($pid_fd, getmypid());
		fclose($pid_fd);
	}
}
else
{
	echo "\nINFO::pid file does Not Exist, No last instance running, mypid:".getmypid()."\n";
	$pid_fd = fopen($LAST_INSTANCE_CHECK_FILE, 'w');
	if(!$pid_fd)
	{
		echo "\nERROR: Failed to open $LAST_INSTANCE_CHECK_FILE\n";
		send_report($REPORT_FILE,$BLOOM_BASE_DIR);
	}
	fwrite($pid_fd, getmypid());
	fclose($pid_fd);
}

//capture stdout
ob_start();

//connect to db
$source_con=mysql_connect($SOURCE_HOST,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con)
{
	echo "\nERROR::$config_param[$j]: $SOURCE_HOST:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
}

//connect to maindb
$source_con_maindb=mysql_connect($SOURCE_HOST_MAINDB,$SOURCE_USERNAME,$SOURCE_PASSWORD);
if(!$source_con_maindb)
{
        echo "\nERROR::$config_param[$j]: $SOURCE_HOST_MAINDB:$SOURCE_USERNAME:$SOURCE_PASSWORD, DB Connection Failed\n";
        cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
}

$has_db_connection = 1;
$found_updates = 0;
for($j=1;$j<count($config_param);$j++)
{
	echo "\n---".$config_param[$j]." start--".date("Y-m-d-H:i:s")."---\n";
	$cmd=$FILTER_GENERATOR_BIN." ".$j;
	$GSSBL_Flag = 0;

	switch($config_param[$j])
	{

		case "URL_BLOOM_GENERATOR":
		{
			$operId = 13;
			$cmd=$FILTER_GENERATOR_BIN." ".$operId;
			
			if($has_db_connection != 1) {
				echo "\nERROR::$config_param[$j]: No DB Connection\n";
				cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
			}
			//read config.ini
			$SELECT_WHITE_LIST_QUERY=$config[$config_param[$j]]['select.updated.pub.site.whitelist'];
			$SELECT_BLOCK_LIST_QUERY=$config[$config_param[$j]]['select.updated.pub.site.blocklist'];
			$SELECT_ALL_SITE_QUERY_WHITE_LIST=$config[$config_param[$j]]['select.all.sites.of.pub_whitelist'];
			$SELECT_ALL_SITE_QUERY_BLOCK_LIST=$config[$config_param[$j]]['select.all.sites.of.pub.blocklist'];
			$SELECT_REMOVED_QUERY=$config[$config_param[$j]]['select.complete.removed.pub.site'];
			$DELETE_QUERY=$config[$config_param[$j]]['delete.complete.removed.pub.site'];

			//use KomliAdServer
			$result=mysql_select_db($SOURCE_KAD_DB,$source_con);
			if(!$result)
			{
				echo "\nERROR::$config_param[$j]: $SOURCE_KAD_DB DB Selection Failed\n".mysql_error()."\n";
				cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
			}
			//Execution for white List
			$SELECT_QUERY=str_replace("HOUR_INTERVAL",$HOUR_INTERVAL,$SELECT_WHITE_LIST_QUERY);
			$SELECT_QUERY=str_replace("BLOOM_TYPE_WHITE_LIST",$bloom_type_white_list,$SELECT_QUERY);

			//echo "\n$config_param[$j]:: Executing Query: $SELECT_QUERY\n";

			$result=mysql_query($SELECT_QUERY,$source_con);
			if(!$result) 
			{
				echo "\nERROR::$config_param[$j]: Query Execution Failed: $SELECT_QUERY\n".mysql_error()."\n";
				cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
			}

			//sorted pub_id, site_id in ascending order, prev_pub_id check used to skip duplicates(in 0 & individual)
			$prev_pub_id=-1;
			while($row = mysql_fetch_array($result))
			{
				if($row['pub_id'] != $prev_pub_id)
				{
					echo "\n$config_param[$j]:: pub_id:".$row['pub_id']." site_id:".$row['site_id']." bloom_type:".$row['bloom_type']."\n";
					$cmd=$cmd." ".$row['pub_id']." ".$row['site_id']." ".$row['bloom_type'] ;
				}
				if($row['site_id'] == 0)
				{
					$query=$SELECT_ALL_SITE_QUERY_WHITE_LIST;
					$query=str_replace("PUBLISHER_ID",$row['pub_id'],$query);
					$query=str_replace("BLOOM_TYPE_WHITE_LIST",$row['bloom_type'],$query);
					$result_sites=mysql_query($query,$source_con);
					if(!$result_sites)
					{
						echo "\nERROR::$config_param[$j]: Query Execution Failed: $query\n".mysql_error()."\n";
						cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
					}

					while($row_site = mysql_fetch_array($result_sites))
					{
						echo "\n$config_param[$j]:: all site change, pub_id:".$row['pub_id']." site_id:".$row_site['site_id']."\n";
						$cmd=$cmd." ".$row['pub_id']." ".$row_site['site_id']." ".$row['bloom_type'];
					}
					mysql_free_result($result_sites);
					$prev_pub_id=$row['pub_id'];
				}
			}
			mysql_free_result($result);

			//ADDING IDs for BLOCKLIST
			$SELECT_QUERY=str_replace("HOUR_INTERVAL",$HOUR_INTERVAL,$SELECT_BLOCK_LIST_QUERY);
			$SELECT_QUERY=str_replace("BLOOM_TYPE_BLOCK_LIST",$bloom_type_block_list,$SELECT_QUERY);
			//echo "\n$config_param[$j]:: Executing Query: $SELECT_QUERY\n";
			$result=mysql_query($SELECT_QUERY,$source_con);
			if(!$result) 
			{
				echo "\nERROR::$config_param[$j]: Query Execution Failed: $SELECT_QUERY\n".mysql_error()."\n";
				cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
			}

			//sorted pub_id, site_id in ascending order, prev_pub_id check used to skip duplicates(in 0 & individual)
			$prev_pub_id=-1;
			while($row = mysql_fetch_array($result))
			{
				if($row['pub_id'] != $prev_pub_id)
				{
					echo "\n$config_param[$j]:: pub_id:".$row['pub_id']." site_id:".$row['site_id']." bloom_type:".$row['bloom_type']."\n";
					$cmd=$cmd." ".$row['pub_id']." ".$row['site_id']." ".$row['bloom_type'] ;
				}
				if($row['site_id'] == 0)
				{
					$query=$SELECT_ALL_SITE_QUERY_BLOCK_LIST;
					$query=str_replace("PUBLISHER_ID",$row['pub_id'],$query);
					$query=str_replace("BLOOM_TYPE_BLOCK_LIST",$row['bloom_type'],$query);
					$result_sites=mysql_query($query,$source_con);
					if(!$result_sites)
					{
						echo "\nERROR::$config_param[$j]: Query Execution Failed: $query\n".mysql_error()."\n";
						cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
					}

					while($row_site = mysql_fetch_array($result_sites))
					{
						echo "\n$config_param[$j]:: all site change, pub_id:".$row['pub_id']." site_id:".$row_site['site_id']."\n";
						$cmd=$cmd." ".$row['pub_id']." ".$row_site['site_id']." ".$row['bloom_type'];
					}
					mysql_free_result($result_sites);
					$prev_pub_id=$row['pub_id'];
				}
			}
			//Delete pub-sites from bloom filters table which are absent in blocklist table
			$cmd = remove_deleted_bloom($config_param[$j],$source_con_maindb, $SOURCE_KAD_DB, $SELECT_REMOVED_QUERY,$DELETE_QUERY,$SELECT_ALL_SITE_QUERY_BLOCK_LIST,$SELECT_ALL_SITE_QUERY_WHITE_LIST,$cmd);
			break;
		}


		default:
		{
			echo "\nERROR:: Invalid Filter\n";
			cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
		}
	}

	if($cmd == $FILTER_GENERATOR_BIN." ".$j) {
			echo "\n*** NO MODIFICATIONS IN $config_param[$j] ***\n";
			echo "\n---".$config_param[$j]." end--".date("Y-m-d-H:i:s")."---\n";
			continue;
	} else if($cmd == $FILTER_GENERATOR_BIN." ".$operId && $GSSBL_Flag != 1 ) {
    echo "\n*** NO MODIFICATIONS IN $config_param[$j] ***\n";
    echo "\n---".$config_param[$j]." end--".date("Y-m-d-H:i:s")."---\n";
    continue;
	}

	$found_updates = 1;	
	echo "\n$config_param[$j]:: Generation Command:\n$cmd\n";

	//Execute bin on main DB
	//$cmd = "$ssh_cmd $master_db_user@$master_db_host $cmd";
	//$cmd = "$ssh_cmd $master_db_user@$master_db_host date";

	//Execute Application
	exec($cmd,$output,$retval);
	if($retval!=0) 
	{
		echo "\nERROR::$config_param[$j]: Execution of $cmd Failed, retval:$retval\n";
	}

	echo "\n---".$config_param[$j]." end--".date("Y-m-d-H:i:s")."---\n";
}

if($source_con)
{
	mysql_close($source_con);
}
if($found_updates == 1) {
	cleanup_and_report($REPORT_FILE,$BLOOM_BASE_DIR,$LAST_INSTANCE_CHECK_FILE);
}
else {
	if(file_exists($LAST_INSTANCE_CHECK_FILE))
	{
		unlink($LAST_INSTANCE_CHECK_FILE);
		}
	}
?>
