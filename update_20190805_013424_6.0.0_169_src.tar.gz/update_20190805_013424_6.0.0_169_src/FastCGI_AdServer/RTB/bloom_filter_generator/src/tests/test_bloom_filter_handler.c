#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include <rt_types.h>
#include "bloom_filter.h"
#include "bkt_bloom_filter.h"
#include "bloom_filter_handler.h"

db_env_t g_dbenv;
char *g_odbc_kad_dsn_name = NULL;
char *g_odbc_adf_dsn_name = NULL;
char *g_odbc_bc_dsn_name = NULL;
char *g_odbc_ceaser_dsn_name = NULL;
char *g_odbc_local_adf_dsn_name = NULL;
char *g_odbc_rawdata_dsn_name = NULL;
char *g_odbc_master_dsn_name = NULL;
char *g_odbc_daa_optout_dsn_name = NULL;
char *g_odbc_ads_txt_dsn_name = NULL;
char *g_odbc_dsn_user_name = NULL;
char *g_odbc_dsn_user_password = NULL;
char *g_conf_bloom_dir = BLOOM_DIR;
int g_cur_arg_index; //Should be assigned some value before using it.
unsigned int g_max_bloom_thread_count;
int gbl_log_level = L_DEBUG;
void* generate_pub_geo_domain_list_filter(bloom_thread_param_t *thread_params,
	get_query_meta_t *query_meta, int oper_id);
void* generate_blocklist_landing_page_filter_new(bloom_thread_param_t *thread_params,
	get_query_meta_t *query_meta, int oper_id);
void* generate_pub_preferred_global_creative_blocklist_filter(bloom_thread_param_t *thread_params,
	get_query_meta_t *query_meta, int oper_id);

pthread_mutex_t bloom_db_conn_mutex;
typedef struct test_set_bloom_configuration_list_t{
	char check_property_name[50];
	char property_value[50];
	int is_num;
	int ret_val;
}test_set_bloom_configuration_list;

typedef struct test_set_bloom_configuration_inputs_t{
	char config_file_name[100];
	int parse_ret_val;
	test_set_bloom_configuration_list prop_list[12];
	int ret_val;
}test_set_bloom_configuration_inputs;

int __wrap_bloom_destroy(BLOOM **bloom){
	return mock_type(int);
}
int __wrap_pthread_mutex_lock(pthread_mutex_t *mutex){
	return mock_type(int);
}

int __wrap_pthread_mutex_unlock(pthread_mutex_t *mutex){
	return mock_type(int);
}

void __wrap_free_property_list(property_list_t **property_list){
}

int __wrap_get_bkt_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		get_query_meta_t* query_meta,
		BKT_BLOOM** bkt_bloom_filter_list,
		size_t *ret_size,
		int *element_count) {
	check_expected(sql_statement);
	if (SELECT_UNSIGNED_BIG == query_meta->type[0])
		query_meta->type[0] = SELECT_CHAR;
	check_expected(query_meta);
	memcpy(ret_size, mock_ptr_type(size_t *), sizeof(size_t)*MAX_ALLOWED_BLOOMS);
	(*element_count) = mock_type(int);
	return mock_type(int);
}

int __wrap_set_bkt_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		BKT_BLOOM** bkt_bloom_filter_list,
		size_t *ret_size,
		const int element_count) {
	check_expected(sql_statement);
	check_expected(ret_size);
	check_expected(element_count);
	return mock_type(int);
}

int __wrap_bkt_bloom_destroy(BKT_BLOOM **bkt_bloom) {
	return 0;
}

int __wrap_get_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		get_query_meta_t* query_meta,
		BLOOM** bloom_filter_list,
		size_t *ret_size,
		int *element_count){
	check_expected(sql_statement);
	if(query_meta->type[0] == SELECT_UNSIGNED_BIG)
		query_meta->type[0] = SELECT_CHAR;
	check_expected(query_meta);
	memcpy(ret_size, mock_ptr_type(size_t *), sizeof(size_t)*MAX_ALLOWED_BLOOMS);
	(*element_count) = mock_type(int);
	return mock_type(int);
}
int __wrap_get_config_properties(char *filename, property_list_t **conf_properties){
	check_expected(filename);
	return mock_type(int);
}
int __wrap_stat(const char *path, struct stat *buf){
	check_expected(path);
	struct stat *tmp = mock_ptr_type(struct stat *);
	buf->st_mode = tmp->st_mode;
	return mock_type(int);
}
int __wrap_mkdir(const char *path, __mode_t mode){
	check_expected(path);
	return mock_type(int);
}
struct tm *__wrap_localtime(const time_t *timep){
	return mock_ptr_type(struct tm *);
}
int __wrap_gettimeofday(struct timeval *tv, struct timezone *tz){
	tv->tv_sec = mock_type(int);
	tv->tv_usec = mock_type(int);
	return mock_type(int);
}
int __wrap_get_db_connection(db_connection_t *dbconn, db_env_t *dbenv, char *dsn_name, char *username, char *password){
	check_expected(dsn_name);
	check_expected(username);
	check_expected(password);
	return mock_type(int);
}
int __wrap_get_property_value(property_list_t *property_list, char *name, char **value){
	check_expected(name);
	(*value) = mock_ptr_type(char *);
	return mock_type(int);
}
int __wrap_get_pub_site_bloom_list(db_connection_t *dbconn,
		long pub_id,
		long site_id,
		int bloom_type,
		BLOOM** publisher_site_bloom_list,
		size_t *ret_size,
		int *url_count){
	check_expected(pub_id);
	check_expected(site_id);
	check_expected(bloom_type);
	memcpy(ret_size, mock_ptr_type(size_t *), sizeof(size_t)*MAX_ALLOWED_BLOOMS);
	(*url_count) = mock_type(int);
	return mock_type(int);
}
int __wrap_get_unique_creative_bloom(db_connection_t *dbconn, BLOOM** unq_creative_bloom, size_t *ret_size, int *count, const char *dbquery){
	check_expected(*count);
	check_expected(dbquery);
	(*unq_creative_bloom) = mock_type(BLOOM*);
	(*ret_size) = mock_type(int);
	return mock_type(int);
}
int __wrap_release_db_connection(db_connection_t *dbconn){
	return mock_type(int);
}
int __wrap_set_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		BLOOM** bloom_filter_list,
		const long pub_id,
		const long site_id,
		const int bloom_type,
		size_t *ret_size,
		const int element_count){
	check_expected(sql_statement);
	check_expected(pub_id);
	check_expected(site_id);
	check_expected(bloom_type);
	check_expected(ret_size);
	check_expected(element_count);
	return mock_type(int);
}
int __wrap_set_creative_bloom(db_connection_t *dbconn,
		BLOOM* creative_bloom, int active_count ,int id ,
		size_t *ret_size, int dsplevel, const char *dbquery){
	check_expected(active_count);
	check_expected(id);
	check_expected(*ret_size);
	check_expected(dsplevel);
	check_expected(dbquery);
	return mock_type(int);
}
int __wrap_set_pub_site_bloom_list(db_connection_t *dbconn,
		long pub_id,
		long site_id,
		BLOOM** publisher_site_bloom_list,
		size_t *ret_size,
		int url_count,
		int bloom_type){
	check_expected(pub_id);
	check_expected(site_id);
	check_expected(ret_size);
	check_expected(url_count);
	check_expected(bloom_type);
	return mock_type(int);
}
void __wrap_db_conn_print_error(SQLSMALLINT htype, SQLHANDLE hndl, SQLRETURN frc, int line, char *file){
}

SQLRETURN __wrap_SQLBindCol(
		SQLHSTMT       StatementHandle,
		SQLUSMALLINT   ColumnNumber,
		SQLSMALLINT    TargetType,
		SQLPOINTER     TargetValuePtr,
		SQLLEN         BufferLength,
		SQLLEN *       StrLen_or_Ind){
	check_expected(ColumnNumber);
	check_expected(TargetType);
	check_expected(BufferLength);
	memcpy(TargetValuePtr, mock_type(SQLPOINTER),1);
	memcpy(StrLen_or_Ind, mock_type(SQLLEN *),1);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLExecute(SQLHSTMT StatementHandle){
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFetch(SQLHSTMT StatementHandle){
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLBindParameter(
		SQLHSTMT        StatementHandle,
		SQLUSMALLINT    ParameterNumber,
		SQLSMALLINT     InputOutputType,
		SQLSMALLINT     ValueType,
		SQLSMALLINT     ParameterType,
		SQLULEN         ColumnSize,
		SQLSMALLINT     DecimalDigits,
		SQLPOINTER      ParameterValuePtr,
		SQLLEN          BufferLength,
		SQLLEN *        StrLen_or_IndPtr){
	check_expected(ParameterNumber);
	check_expected(InputOutputType);
	check_expected(ValueType);
	check_expected(ParameterType);
	check_expected(ColumnSize);
	check_expected(DecimalDigits);
	check_expected(BufferLength);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFreeHandle(SQLSMALLINT HandleType, SQLHANDLE Handle){
	check_expected(HandleType);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLAllocHandle(SQLSMALLINT HandleType,SQLHANDLE InputHandle,SQLHANDLE *OutputHandlePtr){
	check_expected(HandleType);
	memcpy(OutputHandlePtr, mock_type(SQLHANDLE *), sizeof(SQLHANDLE));
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLPrepare(SQLHSTMT StatementHandle, SQLCHAR *StatementText, SQLINTEGER TextLength){
	check_expected(StatementText);
	check_expected(TextLength);
	return mock_type(SQLRETURN);
}

void run_set_bloom_configuration_tests(test_set_bloom_configuration_inputs *input){
	int i=0,rv;
	char *emptyStr = "";
	char tmpStr[12][60];
	g_odbc_kad_dsn_name = emptyStr;
	g_odbc_adf_dsn_name = emptyStr;
	g_odbc_bc_dsn_name = emptyStr;
	g_odbc_ceaser_dsn_name = emptyStr;
	g_odbc_local_adf_dsn_name = emptyStr;
	g_odbc_rawdata_dsn_name = emptyStr;
	g_odbc_master_dsn_name = emptyStr;
	g_odbc_daa_optout_dsn_name = emptyStr;
	g_odbc_ads_txt_dsn_name = emptyStr;
	g_odbc_dsn_user_name = emptyStr;
	g_odbc_dsn_user_password = emptyStr;
	g_max_bloom_thread_count = 0;


	expect_string(__wrap_get_config_properties, filename, input->config_file_name);
	will_return(__wrap_get_config_properties, input->parse_ret_val);

	if(input->parse_ret_val == 0){
		for(i=0;i<(sizeof(input->prop_list)/sizeof(test_set_bloom_configuration_list));i++){
			expect_string(__wrap_get_property_value, name, input->prop_list[i].check_property_name);
			if(input->prop_list[i].is_num)
				sprintf(tmpStr[i],"%s",input->prop_list[i].property_value);
			else
				sprintf(tmpStr[i],"\"%s\"",input->prop_list[i].property_value);
			will_return(__wrap_get_property_value, cast_ptr_to_largest_integral_type(&tmpStr[i]));
			will_return(__wrap_get_property_value, input->prop_list[i].ret_val);
			if(input->prop_list[i].ret_val != 0)
				break;
		}
	}
	rv = set_bloom_configuration();
	assert_int_equal(rv, input->ret_val);

	assert_string_equal(g_odbc_kad_dsn_name, input->prop_list[0].property_value);
	assert_string_equal(g_odbc_adf_dsn_name, input->prop_list[1].property_value);
	assert_string_equal(g_odbc_bc_dsn_name, input->prop_list[2].property_value);
	assert_string_equal(g_odbc_local_adf_dsn_name, input->prop_list[3].property_value);
	assert_string_equal(g_odbc_rawdata_dsn_name, input->prop_list[4].property_value);
	assert_string_equal(g_odbc_master_dsn_name, input->prop_list[5].property_value);
	assert_string_equal(g_odbc_daa_optout_dsn_name, input->prop_list[6].property_value);
	assert_string_equal(g_odbc_ads_txt_dsn_name, input->prop_list[7].property_value);
	assert_string_equal(g_odbc_ceaser_dsn_name, input->prop_list[8].property_value);
	assert_string_equal(g_odbc_dsn_user_name, input->prop_list[9].property_value);
	assert_string_equal(g_odbc_dsn_user_password, input->prop_list[10].property_value);
	assert_int_equal(g_max_bloom_thread_count, (int)atoi(input->prop_list[11].property_value));
}

static void test_set_bloom_configuration__all_testcases(void **state)
{
	int i = 0;
	test_set_bloom_configuration_inputs inputs[] = {
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"local_adf_dsn",0,0},{RAWDATA_DSN_NAME,"rawdata_dsn",0,0},{MASTER_DSN_NAME,"master_dsn",0,0},{DAA_OPTOUT_DSN_NAME,"daa_optout_dsn",0,0},{ADS_TXT_DSN_NAME,"ads_txt_dsn",0,0},{CEASER_DSN_NAME,"ceaser_dsn",0,0},{DSN_USERNAME,"dsn_username",0,0},{DSN_PASSWORD,"dsn_password",0,0},{MAX_BLOOM_THREAD_COUNT,"5",1,0}},0},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"local_adf_dsn",0,0},{RAWDATA_DSN_NAME,"rawdata_dsn",0,0},{MASTER_DSN_NAME,"master_dsn",0,0},{DAA_OPTOUT_DSN_NAME,"daa_optout_dsn",0,0},{ADS_TXT_DSN_NAME,"ads_txt_dsn",0,0},{CEASER_DSN_NAME,"ceaser_dsn",0,0},{DSN_USERNAME,"dsn_username",0,0},{DSN_PASSWORD,"dsn_password",0,0},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"local_adf_dsn",0,0},{RAWDATA_DSN_NAME,"rawdata_dsn",0,0},{MASTER_DSN_NAME,"master_dsn",0,0},{DAA_OPTOUT_DSN_NAME,"daa_optout_dsn",0,0},{ADS_TXT_DSN_NAME,"ads_txt_dsn",0,0},{CEASER_DSN_NAME,"ceaser_dsn",0,0},{DSN_USERNAME,"dsn_username",0,0},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"local_adf_dsn",0,0},{RAWDATA_DSN_NAME,"rawdata_dsn",0,0},{MASTER_DSN_NAME,"master_dsn",0,0},{DAA_OPTOUT_DSN_NAME,"daa_optout_dsn",0,0},{ADS_TXT_DSN_NAME,"ads_txt_dsn",0,0},{CEASER_DSN_NAME,"ceaser_dsn",0,0},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"local_adf_dsn",0,0},{RAWDATA_DSN_NAME,"rawdata_dsn",0,0},{MASTER_DSN_NAME,"master_dsn",0,0},{DAA_OPTOUT_DSN_NAME,"daa_optout_dsn",0,0},{ADS_TXT_DSN_NAME,"ads_txt_dsn",0,0},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"local_adf_dsn",0,0},{RAWDATA_DSN_NAME,"rawdata_dsn",0,0},{MASTER_DSN_NAME,"master_dsn",0,0},{DAA_OPTOUT_DSN_NAME,"daa_optout_dsn",0,0},{ADS_TXT_DSN_NAME,"",0,-1},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"local_adf_dsn",0,0},{RAWDATA_DSN_NAME,"rawdata_dsn",0,0},{MASTER_DSN_NAME,"master_dsn",0,0},{DAA_OPTOUT_DSN_NAME,"",0,-1},{ADS_TXT_DSN_NAME,"",0,-1},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"local_adf_dsn",0,0},{RAWDATA_DSN_NAME,"rawdata_dsn",0,0},{MASTER_DSN_NAME,"",0,-1},{DAA_OPTOUT_DSN_NAME,"",0,-1},{ADS_TXT_DSN_NAME,"",0,-1},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"local_adf_dsn",0,0},{RAWDATA_DSN_NAME,"",0,-1},{MASTER_DSN_NAME,"",0,-1},{DAA_OPTOUT_DSN_NAME,"",0,-1},{ADS_TXT_DSN_NAME,"",0,-1},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"bc_dsn",0,0},{LOCAL_ADF_DSN_NAME,"",0,-1},{RAWDATA_DSN_NAME,"",0,-1},{MASTER_DSN_NAME,"",0,-1},{DAA_OPTOUT_DSN_NAME,"",0,-1},{ADS_TXT_DSN_NAME,"",0,-1},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"adf_dsn",0,0},{BC_DSN_NAME,"",0,-1},{LOCAL_ADF_DSN_NAME,"",0,-1},{RAWDATA_DSN_NAME,"",0,-1},{MASTER_DSN_NAME,"",0,-1},{DAA_OPTOUT_DSN_NAME,"",0,-1},{ADS_TXT_DSN_NAME,"",0,-1},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"kad_dsn",0,0},{ADF_DSN_NAME,"",0,-1},{BC_DSN_NAME,"",0,-1},{LOCAL_ADF_DSN_NAME,"",0,-1},{RAWDATA_DSN_NAME,"",0,-1},{MASTER_DSN_NAME,"",0,-1},{DAA_OPTOUT_DSN_NAME,"",0,-1},{ADS_TXT_DSN_NAME,"",0,-1},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,0,{{KAD_DSN_NAME,"",0,-1},{ADF_DSN_NAME,"",0,-1},{BC_DSN_NAME,"",0,-1},{LOCAL_ADF_DSN_NAME,"",0,-1},{RAWDATA_DSN_NAME,"",0,-1},{MASTER_DSN_NAME,"",0,-1},{DAA_OPTOUT_DSN_NAME,"",0,-1},{ADS_TXT_DSN_NAME,"",0,-1},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	{BLOOM_CONFIG_FILE_NAME,-1,{{KAD_DSN_NAME,"",0,-1},{ADF_DSN_NAME,"",0,-1},{BC_DSN_NAME,"",0,-1},{LOCAL_ADF_DSN_NAME,"",0,-1},{RAWDATA_DSN_NAME,"",0,-1},{MASTER_DSN_NAME,"",0,-1},{DAA_OPTOUT_DSN_NAME,"",0,-1},{ADS_TXT_DSN_NAME,"",0,-1},{CEASER_DSN_NAME,"",0,-1},{DSN_USERNAME,"",0,-1},{DSN_PASSWORD,"",0,-1},{MAX_BLOOM_THREAD_COUNT,"0",1,-1}},-1},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_set_bloom_configuration_inputs));i++){
		run_set_bloom_configuration_tests(&inputs[i]);
	}
}

static void test_free_bloom_configuration__all_testcases(void **state){
	g_odbc_kad_dsn_name = strdup("dummystr");
	g_odbc_adf_dsn_name = strdup("dummystr");
	g_odbc_bc_dsn_name = strdup("dummystr");
	g_odbc_ceaser_dsn_name = strdup("dummystr");
	g_odbc_local_adf_dsn_name = strdup("dummystr");
	g_odbc_rawdata_dsn_name = strdup("dummystr");
	g_odbc_master_dsn_name = strdup("dummystr");
	g_odbc_daa_optout_dsn_name = strdup("dummystr");
	g_odbc_ads_txt_dsn_name = strdup("dummystr");
	g_odbc_dsn_user_name = strdup("dummystr");
	g_odbc_dsn_user_password = strdup("dummystr");

	free_bloom_configuration();

	assert_ptr_equal(g_odbc_kad_dsn_name, NULL);
	assert_ptr_equal(g_odbc_adf_dsn_name, NULL);
	assert_ptr_equal(g_odbc_bc_dsn_name, NULL);
	assert_ptr_equal(g_odbc_ceaser_dsn_name, NULL);
	assert_ptr_equal(g_odbc_local_adf_dsn_name, NULL);
	assert_ptr_equal(g_odbc_rawdata_dsn_name, NULL);
	assert_ptr_equal(g_odbc_master_dsn_name, NULL);
	assert_ptr_equal(g_odbc_daa_optout_dsn_name, NULL);
	assert_ptr_equal(g_odbc_ads_txt_dsn_name, NULL);
	assert_ptr_equal(g_odbc_dsn_user_name, NULL);
	assert_ptr_equal(g_odbc_dsn_user_password, NULL);
}

typedef struct test_get_log_file_name_inputs_t{
	char exp_log_file_name[100];
	int year;
	int month;
	int day;
	char bloom_dir[50];
	char bloom_log_dir[50];
	long seconds;
	int stat_ret;
}test_get_log_file_name_inputs;

void test_get_log_file_name(test_get_log_file_name_inputs *input){
	struct tm t;
	char log_file_name[100];
	int START_YEAR = 1900, START_MONTH = 1;
	t.tm_year = input->year - START_YEAR;
	t.tm_mon = input->month - START_MONTH;
	t.tm_mday = input->day;
	struct stat st;
	g_conf_bloom_dir = input->bloom_dir;
	expect_string(__wrap_stat, path, input->bloom_log_dir);
	will_return(__wrap_stat, cast_ptr_to_largest_integral_type(&st));
	will_return(__wrap_stat, input->stat_ret);

	will_return(__wrap_gettimeofday, input->seconds); //seconds
	will_return(__wrap_gettimeofday, 0); //micro seconds
	will_return(__wrap_gettimeofday, 0); //return type

	will_return(__wrap_localtime, cast_ptr_to_largest_integral_type(&t));

	if(input->stat_ret != 0){
		expect_string(__wrap_mkdir, path, input->bloom_log_dir);
		will_return(__wrap_mkdir, 0);
	}

	get_log_file_name(log_file_name);
	assert_string_equal(log_file_name,input->exp_log_file_name);
}

static void test_get_log_file_name__all_testcases(void **state){
	int i;
	test_get_log_file_name_inputs inputs[]={
	{"mylogdir/logs/2017-11-10-123456.log",2017,11,10,"mylogdir","mylogdir/logs/",123456,0},
	{"mylogdir/logs/2017-11-10-123456.log",2017,11,10,"mylogdir/","mylogdir/logs/",123456,0},
	{"mylogdir/logs/2017-01-01-123456.log",2017,1,1,"mylogdir/","mylogdir/logs/",123456,0},
	{"mylogdir/logs/2017-10-04-12345.log",2017,10,4,"mylogdir","mylogdir/logs/",12345,0},
	{"mylogdir/logs/2017-01-01-123456.log",2017,1,1,"mylogdir/","mylogdir/logs/",123456,-1},
	{"mylogdir/logs/2017-01-01-123456.log",2017,1,1,"mylogdir","mylogdir/logs/",123456,-1},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_get_log_file_name_inputs));i++){
		test_get_log_file_name(&inputs[i]);
	}
}

typedef struct test_init_query_metadata_inputs_t{
	int operid;
	unsigned int nSelect;
	select_type_t type[MAX_BIND_COL];
	unsigned int max_elt_size;
}test_init_query_metadata_inputs;

void test_init_query_metadata(test_init_query_metadata_inputs *input){
	get_query_meta_t query_meta;
	int i;
	init_query_metadata(&query_meta, input->operid);

	assert_int_equal(query_meta.nSelect,input->nSelect);
	assert_int_equal(query_meta.max_elt_size,input->max_elt_size);
	for(i=0; i<input->nSelect; i++)
		assert_int_equal(query_meta.type[i],input->type[i]);
}

static void test_init_query_metadata__all_testcases(void **state){
	int i;
	test_init_query_metadata_inputs inputs[]={
	{BLOOM_PUBLISHER_SITE_DEAL_WHITELIST_FILTER, 2, {SELECT_INT,SELECT_CHAR_DOMAIN}, (2 * BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH)},
	{BLOOM_PUBLISHER_SITE_FLOOR_FILTER, 2, {SELECT_INT,SELECT_CHAR_DOMAIN}, (BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH + 20)},
	{GSS_BLOCKLIST_FILTER, 1, {SELECT_CHAR_DOMAIN}, MAX_BLACKWHITE_LIST_APPURL_LENGTH},
	{BLOOM_CREATIVE_ID_FILTER, 1, {SELECT_CHAR}, MAX_DSP_CREATIVE_LEN},
	{BLOOM_DAA_DEVICEID_OPTOUT_FILTER, 1, {SELECT_CHAR}, MAX_DAA_OPTOUT_DEVICEID_LEN},
	{BLOOM_DSP_APPURL_BLOCKLIST_FILTER, 1, {SELECT_CHAR_DOMAIN}, MAX_BLACKWHITE_LIST_APPURL_LENGTH},
	{BLOOM_DSP_APPURL_WHITELIST_FILTER, 1, {SELECT_CHAR_DOMAIN}, MAX_BLACKWHITE_LIST_APPURL_LENGTH},
	{BLOOM_BLOCKLIST_LANDING_PAGE_FILTER, 1, {SELECT_CHAR_DOMAIN}, BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH},
	{BLOOM_WHITELIST_LANDING_PAGE_FILTER, 1, {SELECT_CHAR_DOMAIN}, BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH},
	{BLOOM_DSP_BLOCKLIST_FILTER, 1, {SELECT_CHAR_DOMAIN}, BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH},
	{BLOOM_UNIQ_CREATV, 1, {SELECT_CHAR_DOMAIN}, BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH},
	{BLOOM_DSP_WHITELIST_FILTER, 1, {SELECT_CHAR_DOMAIN}, BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH},
	{BLOOM_URL_BLACK_WHITE_FILTER, 1, {SELECT_CHAR_DOMAIN}, BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH},
	{BLOOM_ADS_TXT_DOMAIN_LIST_FILTER, 1, {SELECT_CHAR_DOMAIN}, MAX_BLACKWHITE_LIST_APPURL_LENGTH},
	{BLOOM_APP_ADS_TXT_FILTER, 1, {SELECT_CHAR}, MAX_BLACKWHITE_LIST_APPURL_LENGTH},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_init_query_metadata_inputs));i++){
		test_init_query_metadata(&inputs[i]);
	}
}


typedef struct test_get_thread_configuration_inputs_t{
	int operid;
	int max_thread_count;
	int cur_ind;
	int argc;
	int batch_size;
	int thread_count;
	int ret_val;
}test_get_thread_configuration_inputs;

void test_get_thread_configuration(test_get_thread_configuration_inputs *input){
	int thread_count, rv;
	unsigned long batch_size;
	g_max_bloom_thread_count = input->max_thread_count;
	rv = get_thread_configuration(input->operid,input->argc,&batch_size,&thread_count);

	assert_int_equal(rv, input->ret_val);
	if(input->ret_val == 0){
		assert_int_equal(batch_size,input->batch_size);
		assert_int_equal(thread_count,input->thread_count);
		assert_int_equal(g_cur_arg_index,input->cur_ind);
	}
}

static void test_get_thread_configuration__all_testcases(void **state){
	int i;
	test_get_thread_configuration_inputs inputs[]={
	// Positive testcases
	{GSS_BLOCKLIST_FILTER, 5, 2, 1, 2, 1, ADS_ERROR_SUCCESS},
	{BLOOM_PUBLISHER_SITE_DEAL_WHITELIST_FILTER, 5, 2, 12, 2, 5, ADS_ERROR_SUCCESS},
	{BLOOM_PUBLISHER_SITE_FLOOR_FILTER, 6, 3, 13, 2, 5, ADS_ERROR_SUCCESS},
	{BLOOM_CREATIVE_ID_FILTER, 10, 2, 17, 3, 5, ADS_ERROR_SUCCESS},
	{BLOOM_DAA_DEVICEID_OPTOUT_FILTER, 20, 2, 16, 1, 14, ADS_ERROR_SUCCESS},
	{BLOOM_DSP_APPURL_BLOCKLIST_FILTER,5, 2, 12, 2, 5, ADS_ERROR_SUCCESS},
	{BLOOM_DSP_APPURL_WHITELIST_FILTER,7, 2, 18, 2, 7, ADS_ERROR_SUCCESS},
	{BLOOM_BLOCKLIST_LANDING_PAGE_FILTER,20, 2, 20, 2, 9, ADS_ERROR_SUCCESS},
	{BLOOM_WHITELIST_LANDING_PAGE_FILTER,8, 2, 18, 2, 8, ADS_ERROR_SUCCESS},
	{BLOOM_DSP_BLOCKLIST_FILTER,5, 2, 18, 2, 5, ADS_ERROR_SUCCESS},
	{BLOOM_UNIQ_CREATV,5, 2, 1, 2, 1, ADS_ERROR_SUCCESS},
	{BLOOM_DSP_WHITELIST_FILTER,6, 2, 18, 2, 6, ADS_ERROR_SUCCESS},
	{BLOOM_URL_BLACK_WHITE_FILTER,4, 2, 17, 3, 4, ADS_ERROR_SUCCESS},
	// Negative Testcases: not enough args
	{BLOOM_PUBLISHER_SITE_DEAL_WHITELIST_FILTER, 5, 2, 1, 2, 5, ADS_ERROR_INTERNAL},
	{BLOOM_PUBLISHER_SITE_FLOOR_FILTER, 6, 3, 1, 2, 5, ADS_ERROR_INTERNAL},
	{BLOOM_CREATIVE_ID_FILTER, 10, 2, 1, 3, 5, ADS_ERROR_INTERNAL},
	{BLOOM_DAA_DEVICEID_OPTOUT_FILTER, 20, 2, 1, 1, 14, ADS_ERROR_INTERNAL},
	{BLOOM_DSP_APPURL_BLOCKLIST_FILTER,5, 2, 1, 2, 5, ADS_ERROR_INTERNAL},
	{BLOOM_DSP_APPURL_WHITELIST_FILTER,7, 2, 1, 2, 7, ADS_ERROR_INTERNAL},
	{BLOOM_BLOCKLIST_LANDING_PAGE_FILTER,20, 2, 1, 2, 9, ADS_ERROR_INTERNAL},
	{BLOOM_WHITELIST_LANDING_PAGE_FILTER,8, 2, 1, 2, 8, ADS_ERROR_INTERNAL},
	{BLOOM_DSP_BLOCKLIST_FILTER,5, 2, 1, 2, 5, ADS_ERROR_INTERNAL},
	{BLOOM_DSP_WHITELIST_FILTER,6, 2, 1, 2, 6, ADS_ERROR_INTERNAL},
	{BLOOM_URL_BLACK_WHITE_FILTER,4, 1, 1, 3, 4, ADS_ERROR_INTERNAL},
	// Negative Testcases: odd number of args
	{BLOOM_PUBLISHER_SITE_DEAL_WHITELIST_FILTER, 5, 2, 11, 2, 5, ADS_ERROR_INTERNAL},
	{BLOOM_PUBLISHER_SITE_FLOOR_FILTER, 6, 3, 12, 2, 5, ADS_ERROR_INTERNAL},
	{BLOOM_CREATIVE_ID_FILTER, 10, 2, 15, 3, 5, ADS_ERROR_INTERNAL},
	{BLOOM_DSP_APPURL_BLOCKLIST_FILTER,5, 2, 11, 2, 5, ADS_ERROR_INTERNAL},
	{BLOOM_DSP_APPURL_WHITELIST_FILTER,7, 2, 11, 2, 7, ADS_ERROR_INTERNAL},
	{BLOOM_BLOCKLIST_LANDING_PAGE_FILTER,20, 2, 11, 2, 9, ADS_ERROR_INTERNAL},
	{BLOOM_WHITELIST_LANDING_PAGE_FILTER,8, 2, 11, 2, 8, ADS_ERROR_INTERNAL},
	{BLOOM_DSP_BLOCKLIST_FILTER,5, 2, 11, 2, 5, ADS_ERROR_INTERNAL},
	{BLOOM_DSP_WHITELIST_FILTER,6, 2, 11, 2, 6, ADS_ERROR_INTERNAL},
	{BLOOM_URL_BLACK_WHITE_FILTER,4, 2, 12, 3, 4, ADS_ERROR_INTERNAL},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_get_thread_configuration_inputs));i++){
		test_get_thread_configuration(&inputs[i]);
	}
}

typedef enum dsn_type_t{ KAD, ADF, BC, LOCAL_ADF, RAWDATA, MASTER, DAA, ADS_TXT, CEASER }dsn_type;
typedef struct test_db_conn_creds_t{
	dsn_type type;
	char dsn_name[50];
	int get_db_conn_ret;
	int rel_db_ret;
}test_db_conn_creds;

typedef struct test_get_set_bloom_inputs_t{
	size_t get_bloom_size[MAX_ALLOWED_BLOOMS];
	int get_bloom_ele_count;
	int get_bloom_ret;
	int set_bloom_ret;
	int iab_enabled;
	int iab_ret;
}test_get_set_bloom_input;

typedef struct test_generate_bloom_filter_inputs_t{
	int argc;
	char argv[10][10];
	int batch_size;
	int thread_id;
	char username[50];
	char password[50];
	test_db_conn_creds test_db_conn[3]; // Max 3 connections opened for any bloom generation
	int db_conn_count;
	test_get_set_bloom_input test_bloom_ip[3]; // We test max three loops (i.e pub site pair inputs)
	int bloom_loop_count;
	int ret_val;
}test_generate_bloom_filter_inputs;

int test_wrap_db_connection(test_generate_bloom_filter_inputs *input){
	int i;
	g_odbc_dsn_user_name = input->username;
	g_odbc_dsn_user_password = input->password;

	will_return(__wrap_pthread_mutex_lock, 0);
	will_return(__wrap_pthread_mutex_unlock, 0);

	for(i=0;i<input->db_conn_count;i++){
		switch(input->test_db_conn[i].type){
			case KAD:
				g_odbc_kad_dsn_name = input->test_db_conn[i].dsn_name;
				break;
			case ADF:
				g_odbc_adf_dsn_name = input->test_db_conn[i].dsn_name;
				break;
			case BC:
				g_odbc_bc_dsn_name = input->test_db_conn[i].dsn_name;
				break;
			case LOCAL_ADF:
				g_odbc_local_adf_dsn_name = input->test_db_conn[i].dsn_name;
				break;
			case RAWDATA:
				g_odbc_rawdata_dsn_name = input->test_db_conn[i].dsn_name;
				break;
			case MASTER:
				g_odbc_master_dsn_name = input->test_db_conn[i].dsn_name;
				break;
			case DAA:
				g_odbc_daa_optout_dsn_name = input->test_db_conn[i].dsn_name;
				break;
			case ADS_TXT:
				g_odbc_ads_txt_dsn_name = input->test_db_conn[i].dsn_name;
				break;
			case CEASER:
				g_odbc_ceaser_dsn_name = input->test_db_conn[i].dsn_name;
				break;
		}

		expect_string(__wrap_get_db_connection, dsn_name, input->test_db_conn[i].dsn_name);
		expect_string(__wrap_get_db_connection, username, input->username);
		expect_string(__wrap_get_db_connection, password, input->password);

		will_return(__wrap_get_db_connection, input->test_db_conn[i].get_db_conn_ret);
		if(input->test_db_conn[i].get_db_conn_ret == 0){
			will_return(__wrap_release_db_connection, input->test_db_conn[i].rel_db_ret);
		}
		else{
			return -1;
		}
	}
	return 0;
}

void test_wrap_get_bloom_filter(test_get_set_bloom_input *input, get_query_meta_t *get_query_meta, char *statement){
	expect_string(__wrap_get_bloom_filters, sql_statement, statement);
	expect_memory(__wrap_get_bloom_filters, query_meta, get_query_meta, sizeof(get_query_meta_t));
	will_return(__wrap_get_bloom_filters, cast_ptr_to_largest_integral_type(&input->get_bloom_size));
	will_return(__wrap_get_bloom_filters, input->get_bloom_ele_count);
	will_return(__wrap_get_bloom_filters, input->get_bloom_ret);
}

void test_wrap_set_bloom_filter(test_get_set_bloom_input *input, char *statement, int pub, int site, int operid){
	expect_string(__wrap_set_bloom_filters, sql_statement, statement);
	expect_value(__wrap_set_bloom_filters, pub_id, pub);
	expect_value(__wrap_set_bloom_filters, site_id, site);
	expect_value(__wrap_set_bloom_filters, bloom_type, operid);
	expect_memory(__wrap_set_bloom_filters, ret_size, &input->get_bloom_size, sizeof(input->get_bloom_size));
	expect_value(__wrap_set_bloom_filters, element_count, input->get_bloom_ele_count);

	will_return(__wrap_set_bloom_filters, input->set_bloom_ret);

}

void test_wrap_get_bkt_bloom_filter(test_get_set_bloom_input *input, get_query_meta_t *get_query_meta, char *statement){
	expect_string(__wrap_get_bkt_bloom_filters, sql_statement, statement);
	expect_memory(__wrap_get_bkt_bloom_filters, query_meta, get_query_meta, sizeof(get_query_meta_t));
	will_return(__wrap_get_bkt_bloom_filters, cast_ptr_to_largest_integral_type(&input->get_bloom_size));
	will_return(__wrap_get_bkt_bloom_filters, input->get_bloom_ele_count);
	will_return(__wrap_get_bkt_bloom_filters, input->get_bloom_ret);
}

void test_wrap_set_bkt_bloom_filter(test_get_set_bloom_input *input, char *statement){
	expect_string(__wrap_set_bkt_bloom_filters, sql_statement, statement);
	expect_memory(__wrap_set_bkt_bloom_filters, ret_size, &input->get_bloom_size, sizeof(input->get_bloom_size));
	expect_value(__wrap_set_bkt_bloom_filters, element_count, input->get_bloom_ele_count);

	will_return(__wrap_set_bkt_bloom_filters, input->set_bloom_ret);

}

void test_init_thread_param(test_generate_bloom_filter_inputs *input, bloom_thread_param_t *thread_params, char **argv_ptr){
	int i;
	thread_params->argc = input->argc;
	thread_params->batch_size = input->batch_size;
	thread_params->thread_id = input->thread_id;
	for(i=0;i<10;i++){
		argv_ptr[i] = input->argv[i];
	}

	thread_params->argv = argv_ptr;
}

void test_generate_blocklist_landing_page_filter_new(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long int pub, site;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			site = atoi(input->argv[(i*thread_params.batch_size)+3]);
			if(pub == 0){
				sprintf(tmp_get_query[i], GET_DB_GLOBAL_PUBLISHER_SITE_BLOCKLIST);
			}
			else{
				sprintf(tmp_get_query[i], GET_DB_PUBLISHER_SITE_BLOCKLIST_NEW, pub, site);
			}
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				if(pub == 0)
					sprintf(tmp_set_query[i], SET_DB_PUBLISHER_SITE_BLOCKLIST, (long int)(0), (long int)(0), input->test_bloom_ip[i].get_bloom_ele_count);
				else
					sprintf(tmp_set_query[i], SET_DB_PUBLISHER_SITE_BLOCKLIST, pub, site, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
			}
		}
	}
	generate_blocklist_landing_page_filter_new(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_blocklist_landing_page_filter_new__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{4,{"bin_name","1","12","12"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {CEASER, "ceaser_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","1","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {CEASER, "ceaser_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {CEASER, "ceaser_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {CEASER, "ceaser_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {CEASER, "ceaser_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {CEASER, "ceaser_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", -1, 0}, {CEASER, "ceaser_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_blocklist_landing_page_filter_new(&inputs[i]);
	}
}


void test_generate_blocklist_landing_page_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub, site;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			site = atoi(input->argv[(i*thread_params.batch_size)+3]);
			if(pub == 0){
				sprintf(tmp_get_query[i], GET_DB_GLOBAL_PUBLISHER_SITE_BLOCKLIST);
			}
			else{
				sprintf(tmp_get_query[i], GET_DB_PUBLISHER_SITE_BLOCKLIST, pub, site);
			}
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				if(pub == 0)
					sprintf(tmp_set_query[i], SET_DB_PUBLISHER_SITE_BLOCKLIST, (long)0, (long)0, input->test_bloom_ip[i].get_bloom_ele_count);
				else
					sprintf(tmp_set_query[i], SET_DB_PUBLISHER_SITE_BLOCKLIST, pub, site, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
			}
		}
	}
	generate_blocklist_landing_page_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_blocklist_landing_page_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{4,{"bin_name","1","12","12"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","1","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {BC, "bc_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","1","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", -1, 0}, {BC, "bc_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_blocklist_landing_page_filter(&inputs[i]);
	}
}

void test_generate_whitelist_landing_page_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub, site;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			site = atoi(input->argv[(i*thread_params.batch_size)+3]);
			sprintf(tmp_get_query[i], GET_DB_PUBLISHER_SITE_WHITELIST, pub, site);
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				sprintf(tmp_set_query[i], SET_DB_PUBLISHER_SITE_WHITELIST, pub, site, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
			}
		}
	}
	generate_whitelist_landing_page_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_whitelist_landing_page_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{4,{"bin_name","4","12","12"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{6,{"bin_name","4","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 5, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{6,{"bin_name","4","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","4","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","4","4","4","0","0"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", -1, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_whitelist_landing_page_filter(&inputs[i]);
	}
}

void test_generate_daa_deviceid_optout_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			sprintf(tmp_get_query[i], GET_DAA_DEVICE_OPTOUT_LIST, pub);
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				sprintf(tmp_set_query[i], SET_DAA_DEVICE_OPTOUT_LIST, pub, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], 0, 0, operid);
			}
		}
	}
	generate_daa_deviceid_optout_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_daa_deviceid_optout_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{3,{"bin_name","14","1"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {DAA, "daa_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{3,{"bin_name","14","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {DAA, "daa_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","14","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {DAA, "daa_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{4,{"bin_name","14","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {DAA, "daa_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{4,{"bin_name","14","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {DAA, "daa_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{4,{"bin_name","14","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {DAA, "daa_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{4,{"bin_name","14","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", -1, 0}, {DAA, "daa_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_daa_deviceid_optout_filter(&inputs[i]);
	}
}

void test_generate_dsp_blocklist_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub, site;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			site = atoi(input->argv[(i*thread_params.batch_size)+3]);
			sprintf(tmp_get_query[i], GET_DB_DSP_CAMPAIGN_BLOCKLIST, pub, site);
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				sprintf(tmp_set_query[i], SET_DB_DSP_CAMPAIGN_BLOCKLIST, pub, site, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
			}
		}
	}
	generate_dsp_blocklist_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_dsp_blocklist_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{4,{"bin_name","5","12","12"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","5","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{6,{"bin_name","5","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 5, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{6,{"bin_name","5","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","5","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","5","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", -1, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_dsp_blocklist_filter(&inputs[i]);
	}
}

void test_generate_dsp_whitelist_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub, site;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			site = atoi(input->argv[(i*thread_params.batch_size)+3]);
			sprintf(tmp_get_query[i], GET_DB_DSP_CAMPAIGN_WHITELIST, pub, site);
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				sprintf(tmp_set_query[i], SET_DB_DSP_CAMPAIGN_WHITELIST, pub, site, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
			}
		}
	}
	generate_dsp_whitelist_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_dsp_whitelist_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{4,{"bin_name","10","12","12"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","10","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{6,{"bin_name","10","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 5, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{6,{"bin_name","10","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","10","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","10","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", -1, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_dsp_whitelist_filter(&inputs[i]);
	}
}

void test_generate_dsp_appurl_blocklist_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub, site;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			site = atoi(input->argv[(i*thread_params.batch_size)+3]);
			sprintf(tmp_get_query[i], GET_DB_DSP_CAMPAIGN_APPURL_BLOCKLIST, pub, site);
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				sprintf(tmp_set_query[i], SET_DB_DSP_CAMPAIGN_APPURL_BLOCKLIST, pub, site, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
			}
		}
	}
	generate_dsp_appurl_blocklist_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_dsp_appurl_blocklist_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{4,{"bin_name","11","12","12"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","11","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{6,{"bin_name","11","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 5, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{6,{"bin_name","11","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","11","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","11","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", -1, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_dsp_appurl_blocklist_filter(&inputs[i]);
	}
}

void test_generate_dsp_appurl_whitelist_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub, site;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			site = atoi(input->argv[(i*thread_params.batch_size)+3]);
			sprintf(tmp_get_query[i], GET_DB_DSP_CAMPAIGN_APPURL_WHITELIST, pub, site);
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				sprintf(tmp_set_query[i], SET_DB_DSP_CAMPAIGN_APPURL_WHITELIST, pub, site, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
			}
		}
	}
	generate_dsp_appurl_whitelist_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_dsp_appurl_whitelist_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{4,{"bin_name","12","12","12"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","12","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{6,{"bin_name","12","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 5, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{6,{"bin_name","12","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","12","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{6,{"bin_name","12","4","4","0","0"}, 2, 123, "username","password",{{ADF, "adf_dsn_name", -1, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_dsp_appurl_whitelist_filter(&inputs[i]);
	}
}

typedef struct test_check_publisher_iab_status_inputs_t{
	int pubid;
	int iab_enabled;
	int ret_sql_prepare;
	int ret_sql_bind_param;
	int ret_sql_exec;
	int ret_sql_fetch;
	int ret_val;
}test_check_publisher_iab_status_inputs;

void test_mock_check_publisher_iab_status(test_check_publisher_iab_status_inputs *input, SQLHANDLE *tmp_handle){
	int tmp_int=0;
	expect_value(__wrap_SQLAllocHandle, HandleType, SQL_HANDLE_STMT);
	will_return(__wrap_SQLAllocHandle, cast_ptr_to_largest_integral_type(tmp_handle));
	will_return(__wrap_SQLAllocHandle, SQL_SUCCESS);

	expect_string(__wrap_SQLPrepare, StatementText, IS_PUBLISHER_IAB_ENABLED);
	expect_value(__wrap_SQLPrepare, TextLength, SQL_NTS);
	will_return(__wrap_SQLPrepare, input->ret_sql_prepare);

	if(input->ret_sql_prepare == SQL_SUCCESS){
		expect_value(__wrap_SQLBindParameter, ParameterNumber, 1);
		expect_value(__wrap_SQLBindParameter, InputOutputType, SQL_PARAM_INPUT);
		expect_value(__wrap_SQLBindParameter, ValueType, SQL_C_ULONG);
		expect_value(__wrap_SQLBindParameter, ParameterType, SQL_INTEGER);
		expect_value(__wrap_SQLBindParameter, ColumnSize, 0);
		expect_value(__wrap_SQLBindParameter, DecimalDigits, 0);
		expect_value(__wrap_SQLBindParameter, BufferLength, 0);
		will_return(__wrap_SQLBindParameter, input->ret_sql_bind_param);

		if(input->ret_sql_bind_param == SQL_SUCCESS){
			will_return(__wrap_SQLExecute, input->ret_sql_exec);

			if(input->ret_sql_exec == SQL_SUCCESS){
				expect_value(__wrap_SQLBindCol, ColumnNumber, 1);
				expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
				expect_value(__wrap_SQLBindCol, BufferLength, 0);
				will_return(__wrap_SQLBindCol, &input->iab_enabled);
				will_return(__wrap_SQLBindCol, &tmp_int);
				will_return(__wrap_SQLBindCol, SQL_SUCCESS);

				will_return(__wrap_SQLFetch, input->ret_sql_fetch);
				if(input->ret_sql_fetch != SQL_NO_DATA)
					will_return(__wrap_SQLFetch, SQL_NO_DATA);
			}
		}
	}
	expect_value(__wrap_SQLFreeHandle, HandleType, SQL_HANDLE_STMT);
	will_return(__wrap_SQLFreeHandle, SQL_SUCCESS);
}

static void test_check_publisher_iab_status__all_testcases(void **state){
	int i;
	test_check_publisher_iab_status_inputs inputs[]={
	// Positive Testcases
	{12345,0,SQL_SUCCESS,SQL_SUCCESS,SQL_SUCCESS,SQL_SUCCESS,ADS_ERROR_SUCCESS},
	{12345,1,SQL_SUCCESS,SQL_SUCCESS,SQL_SUCCESS,SQL_SUCCESS,ADS_ERROR_SUCCESS},
	{0,0,SQL_SUCCESS,SQL_SUCCESS,SQL_SUCCESS,SQL_SUCCESS,ADS_ERROR_SUCCESS},
	{0,1,SQL_SUCCESS,SQL_SUCCESS,SQL_SUCCESS,SQL_SUCCESS,ADS_ERROR_SUCCESS},
	// Negative Testcases
	{12345,0,SQL_SUCCESS,SQL_SUCCESS,SQL_SUCCESS,SQL_NO_DATA,ADS_ERROR_SUCCESS},
	{12345,0,SQL_SUCCESS,SQL_SUCCESS,SQL_ERROR,SQL_NO_DATA,ADS_ERROR_INTERNAL},
	{12345,0,SQL_SUCCESS,SQL_ERROR,SQL_ERROR,SQL_NO_DATA,ADS_ERROR_INTERNAL},
	{12345,0,SQL_ERROR,SQL_ERROR,SQL_ERROR,SQL_NO_DATA,ADS_ERROR_INTERNAL},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_check_publisher_iab_status_inputs));i++){
		int rv, is_iab_enabled=0;
		int tmp_int=0;
		SQLHANDLE tmp_handle = (SQLHANDLE) &tmp_int;
		db_connection_t dbconn;
		test_mock_check_publisher_iab_status(&inputs[i], &tmp_handle);
		rv = check_publisher_iab_status(&dbconn, inputs[i].pubid, &is_iab_enabled);
		assert_int_equal(rv, inputs[i].ret_val);
		assert_int_equal(is_iab_enabled, inputs[i].iab_enabled);
	}
}

void test_generate_publisher_site_floor_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	int tmp_int=0;
	SQLHANDLE tmp_handle = (SQLHANDLE) &tmp_int;
	char *argv_ptr[10];
	char tmp_get_query[3][1000]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][1000];
	int operid = atoi(input->argv[1]);
	long active_entity = atol(input->argv[2]);
	long pub, site;
	g_cur_arg_index = 3;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+3]);
			site = atoi(input->argv[(i*thread_params.batch_size)+4]);

			test_check_publisher_iab_status_inputs iab_input = {0,0,0,0,0,0,0};
			iab_input.pubid = pub;
			iab_input.iab_enabled = input->test_bloom_ip[i].iab_enabled;
			iab_input.ret_sql_exec = input->test_bloom_ip[i].iab_ret;
			test_mock_check_publisher_iab_status(&iab_input, &tmp_handle);
			if(input->test_bloom_ip[i].iab_ret == 0){
				int valid_act_ent = 0;
				char* ptr_query = NULL;
				switch(active_entity){
				case ADVERTISER_ID:
					ptr_query = GET_DB_PUBLISHER_SITE_FOR_ADVERTISER_FLOOR_FILTER;
					valid_act_ent = 1;
					break;
				case DOMAIN_ID:
					ptr_query = GET_DB_PUBLISHER_SITE_FOR_DOMAIN_FLOOR_FILTER;
					valid_act_ent = 1;
					break;
				case ADVERTISER_CATEGORIES:
					if(input->test_bloom_ip[i].iab_enabled)
						ptr_query = GET_DB_PUBLISHER_SITE_FOR_CATEGORY_FLOOR_FILTER_IAB_ENABLED;
					else
						ptr_query = GET_DB_PUBLISHER_SITE_FOR_CATEGORY_FLOOR_FILTER_IAB_DISABLED;
					valid_act_ent = 1;
					break;
				default:
					valid_act_ent = 0;
				}
				if(valid_act_ent){
					sprintf(tmp_get_query[i], ptr_query, pub, site);
					test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
					if(input->test_bloom_ip[i].get_bloom_ret == 0){
						sprintf(tmp_set_query[i], SET_DB_PUBLISHER_SITE_FLOOR_FILTER, pub, site, active_entity, input->test_bloom_ip[i].get_bloom_ele_count, input->test_bloom_ip[i].iab_enabled);
						test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
					}
				}
			}
		}
	}
	generate_publisher_site_floor_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_publisher_site_floor_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{5,{"bin_name","6","3","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{5,{"bin_name","6","3","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 1, 0}}, 1, 0},
	{5,{"bin_name","6","4","2","2"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{5,{"bin_name","6","4","2","2"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 1, 0}}, 1, 0},
	{7,{"bin_name","6","14","2","2","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, 0, 0, 0}}, 2, 0},
	{7,{"bin_name","6","14","3","3","4","4"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 1, 0}, {{1,2,3}, 3, 0, 0, 1, 0}}, 2, 0},
	//Negative Testcases
	{5,{"bin_name","6","33","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{5,{"bin_name","6","33","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 1, 0}}, 1, 0},
	{5,{"bin_name","6","3","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, -1, 0, 0}}, 1, -1},
	{5,{"bin_name","6","3","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, 0}}, 1, -1},
	{5,{"bin_name","6","3","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, -1}}, 1, 4},
	{5,{"bin_name","6","3","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", -1, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, -1}}, 1, -1},
	{5,{"bin_name","6","3","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", -1, 0}, {LOCAL_ADF, "localadf_dsn_name", -1, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, -1}}, 1, -1},
	{5,{"bin_name","6","3","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", -1, 0}, {ADF, "adf_dsn_name", -1, 0}, {LOCAL_ADF, "localadf_dsn_name", -1, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, -1}}, 1, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_publisher_site_floor_filter(&inputs[i]);
	}
}

void test_generate_publisher_site_deal_whitelist_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	int tmp_int=0;
	SQLHANDLE tmp_handle = (SQLHANDLE) &tmp_int;
	char *argv_ptr[10];
	char tmp_get_query[3][3000]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][3000];
	int operid = atoi(input->argv[1]);
	long pub, site;
	g_cur_arg_index = 3;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+3]);
			site = atoi(input->argv[(i*thread_params.batch_size)+4]);

			test_check_publisher_iab_status_inputs iab_input = {0,0,0,0,0,0,0};
			iab_input.pubid = pub;
			iab_input.iab_enabled = input->test_bloom_ip[i].iab_enabled;
			iab_input.ret_sql_exec = input->test_bloom_ip[i].iab_ret;
			test_mock_check_publisher_iab_status(&iab_input, &tmp_handle);
			if(input->test_bloom_ip[i].iab_ret == 0){
				sprintf(tmp_get_query[i], (input->test_bloom_ip[i].iab_enabled) ? GET_DB_PUBLISHER_SITE_DEAL_WHITELIST_FILTER_IAB_ENABLED : GET_DB_PUBLISHER_SITE_DEAL_WHITELIST_FILTER_IAB_DISABLED, pub, site, pub, site, pub, site);
				test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
				if(input->test_bloom_ip[i].get_bloom_ret == 0){
					sprintf(tmp_set_query[i], SET_DB_PUBLISHER_SITE_DEAL_WHITELIST_FILTER, pub, site, input->test_bloom_ip[i].get_bloom_ele_count, input->test_bloom_ip[i].iab_enabled);
					test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
				}
			}
		}
	}
	generate_publisher_site_deal_whitelist_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_publisher_site_deal_whitelist_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{4,{"bin_name","7","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","7","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 1, 0}}, 1, 0},
	{6,{"bin_name","7","2","2","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, 0, 0, 0}}, 2, 0},
	{6,{"bin_name","7","3","3","4","4"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, 0, 1, 0}, {{1,2,3}, 3, 0, 0, 1, 0}}, 2, 0},
	//Negative Testcases
	{4,{"bin_name","7","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, 0, -1, 0, 0}}, 1, -1},
	{4,{"bin_name","7","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, 0}}, 1, -1},
	{4,{"bin_name","7","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", 0, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, -1}}, 1, 4},
	{4,{"bin_name","7","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", 0, 0}, {LOCAL_ADF, "localadf_dsn_name", -1, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, -1}}, 1, -1},
	{4,{"bin_name","7","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADF, "adf_dsn_name", -1, 0}, {LOCAL_ADF, "localadf_dsn_name", -1, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, -1}}, 1, -1},
	{4,{"bin_name","7","1","1"}, 2, 123, "username","password",{{KAD, "kad_dsn_name", -1, 0}, {ADF, "adf_dsn_name", -1, 0}, {LOCAL_ADF, "localadf_dsn_name", -1, 0}}, 3,{{{1,2,3}, 3, -1, -1, 0, -1}}, 1, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_publisher_site_deal_whitelist_filter(&inputs[i]);
	}
}

void test_generate_creative_id_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub, site, bloom_type;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			site = atoi(input->argv[(i*thread_params.batch_size)+3]);
			bloom_type = atoi(input->argv[(i*thread_params.batch_size)+4]);
			get_query_meta.type[0] = SELECT_CHAR;
			sprintf(tmp_get_query[i], bloom_type ? GET_CRC64_CREATIVE_WHITE_LIST : GET_CRC64_CREATIVE_BLOCK_LIST, pub, site);
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				sprintf(tmp_set_query[i], bloom_type ? SET_CRC64_CREATIVE_WHITE_LIST : SET_CRC64_CREATIVE_BLOCK_LIST, pub, site, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i], pub, site, operid);
			}
		}
	}
	generate_creative_id_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

void test_generate_unique_creative_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub> inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			sprintf(tmp_get_query[i], GET_UNIQUE_CREATIVE_ID);
			test_wrap_get_bkt_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				sprintf(tmp_set_query[i], SET_UNIQUE_CREATIVE_ID_BLOOM, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bkt_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i]);
			}
		}
	}
	generate_unique_creative_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

void test_generate_url_black_white_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	int operid = atoi(input->argv[1]);
	long pub, site, bloom_t;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			site = atoi(input->argv[(i*thread_params.batch_size)+3]);
			bloom_t = atoi(input->argv[(i*thread_params.batch_size)+4]);

			expect_value(__wrap_get_pub_site_bloom_list, pub_id, pub);
			expect_value(__wrap_get_pub_site_bloom_list, site_id, site);
			expect_value(__wrap_get_pub_site_bloom_list, bloom_type, bloom_t);
			will_return(__wrap_get_pub_site_bloom_list, cast_ptr_to_largest_integral_type(&input->test_bloom_ip[i].get_bloom_size));
			will_return(__wrap_get_pub_site_bloom_list, input->test_bloom_ip[i].get_bloom_ele_count);
			will_return(__wrap_get_pub_site_bloom_list, input->test_bloom_ip[i].get_bloom_ret);

			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				expect_value(__wrap_set_pub_site_bloom_list, pub_id, pub);
				expect_value(__wrap_set_pub_site_bloom_list, site_id, site);
				expect_memory(__wrap_set_pub_site_bloom_list, ret_size, &input->test_bloom_ip[i].get_bloom_size, sizeof(input->test_bloom_ip[i].get_bloom_size));
				expect_value(__wrap_set_pub_site_bloom_list, url_count, input->test_bloom_ip[i].get_bloom_ele_count);
				expect_value(__wrap_set_pub_site_bloom_list, bloom_type, bloom_t);

				will_return(__wrap_set_pub_site_bloom_list, input->test_bloom_ip[i].set_bloom_ret);
				if(input->test_bloom_ip[i].set_bloom_ret != 0)
					break;
			}
			else
				break;
		}
	}
	generate_url_black_white_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}


static void test_generate_url_black_white_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{5,{"bin_name","13","22","33","0"}, 3, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{5,{"bin_name","13","22","33","1"}, 3, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{8,{"bin_name","13","22","33","0","44","55","1"}, 3, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{8,{"bin_name","13","22","33","0","44","55","1"}, 3, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{8,{"bin_name","13","22","33","0","44","55","1"}, 3, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{8,{"bin_name","13","22","33","0","44","55","1"}, 3, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, -1, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{8,{"bin_name","13","22","33","0","44","55","1"}, 3, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, -1, -1, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{8,{"bin_name","13","22","33","0","44","55","1"}, 3, 123, "username","password",{{KAD, "kad_dsn_name", -1, 0}}, 1,{{{1,2,3}, 3, -1, -1, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_url_black_white_filter(&inputs[i]);
	}
}
void test_generate_publisher_campaign_level_blocklist_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	int operid = atoi(input->argv[1]);
	long dsp, cmp, pub;
	g_cur_arg_index = 2;
	SQLCHAR sql_statement_get[MAX_SQL_QUERY_STR_LEN + 1];
	SQLCHAR sql_statement_set[MAX_SQL_QUERY_STR_LEN + 1];

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			dsp = atoi(input->argv[(i*thread_params.batch_size)+2]);
			cmp = atoi(input->argv[(i*thread_params.batch_size)+3]);
			pub = atoi(input->argv[(i*thread_params.batch_size)+4]);


			snprintf((char *) sql_statement_get, MAX_SQL_QUERY_STR_LEN, GET_DB_DSP_PUB_CAMPG_BLOCKLIST, dsp, cmp, pub);
			test_wrap_get_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, (char*)sql_statement_get);

			snprintf((char *) sql_statement_set, MAX_SQL_QUERY_STR_LEN, SET_DB_DSP_PUB_CAMPG_BLOCKLIST, dsp, cmp, pub, input->test_bloom_ip[i].get_bloom_ele_count);
			test_wrap_set_bloom_filter(&input->test_bloom_ip[i], (char*)sql_statement_set, dsp, cmp, atoi(input->argv[1]));
		}
	}
	generate_publisher_campaign_level_blocklist(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}
static void test_generate_publisher_campaign_level_blocklist__all_testcases (void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[] = {
	//Postive TC
	{8,{"bin_name","16","12","32311","1", "12","32311","1"}, 3, 1, "username","password",{{ADF, "kad_dsn_name", 0, 0}}, 1,{{{1,0,0}, 3, 0, 0, 0, 0}, {{1,0,0}, 3, 0, 0, 0, 0}}, 2, 0},
	{5,{"bin_name","16","22","3311","9"}, 3, 1, "username","password",{{ADF, "kad_dsn_name", 0, 0}}, 1,{{{1,0,0}, 3, 0, 0, 0, 0}}, 1, 0},
	////Negative TC
	{5,{"bin_name","16","22","0","0"}, 3, 1, "username","password",{{ADF, "kad_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{5,{"bin_name","16","22","3311","9", "-1"}, 3, 1, "username","password",{{ADF, "kad_dsn_name", 0, 0}}, 1,{{{1,0,0}, 3, 0, 0, 0, 0}}, 1, 0},
	{5,{"bin_name","16","4","4","0"}, 3, 1, "username","password",{{ADF, "adf_dsn_name", -1, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{5,{"bin_name","16","4","4","0"}, 3, 1, "username","password",{{ADF, "adf_dsn_name", -1, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},

	};
	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_publisher_campaign_level_blocklist_filter(&inputs[i]);
	}
}

void test_generate_ads_txt_domain_list_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub, blm_type;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if (0 == (test_wrap_db_connection(input))) {
		for (i=0; i<input->bloom_loop_count; i++) {
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			blm_type = atoi(input->argv[(i*thread_params.batch_size)+3]);

			switch (blm_type) {
				case GLOBAL_ADS_TXT_PRESENT_DOMAIN_LIST:
					sprintf(tmp_get_query[i], GET_GLOBAL_ADS_TXT_PRESENT_DOMAIN_LIST);
					pub = 0; /* For global domain list bloom, we use pub_id=0 and type=0 */
					break;
				case PUB_ADS_TXT_RESELLER_DOMAIN_LIST:
					sprintf(tmp_get_query[i], GET_PUB_ADS_TXT_RESELLER_DOMAIN_LIST, pub);
					break;
				case PUB_ADS_TXT_DIRECT_DOMAIN_LIST:
					sprintf(tmp_get_query[i], GET_PUB_ADS_TXT_DIRECT_DOMAIN_LIST, pub);
					break;
			}
			test_wrap_get_bkt_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if (0 == input->test_bloom_ip[i].get_bloom_ret) {
				sprintf(tmp_set_query[i], SET_ADS_TXT_DOMAIN_LIST_FILTER, pub, blm_type, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bkt_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i]);
			}
		}
	}
	generate_ads_txt_domain_list_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_ads_txt_domain_list_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
		//Positive testcases
		{3,{"bin_name","17","1"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
		{3,{"bin_name","17","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
		{4,{"bin_name","17","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, 0, 0, 0}}, 2, 0},
		//Negative Testcases
		{4,{"bin_name","17","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
		{4,{"bin_name","17","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
		{4,{"bin_name","17","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
		{4,{"bin_name","17","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", -1, 0}, {ADS_TXT, "ads_txt_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_ads_txt_domain_list_filter(&inputs[i]);
	}
}

void test_generate_app_ads_txt_bloom_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long pub, blm_type;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if (0 == (test_wrap_db_connection(input))) {
		for (i=0; i<input->bloom_loop_count; i++) {
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			blm_type = atoi(input->argv[(i*thread_params.batch_size)+3]);

			switch (blm_type) {
				case GLOBAL_ADS_TXT_PRESENT_DOMAIN_LIST:
					sprintf(tmp_get_query[i], GET_GLOBAL_APP_ADS_TXT_PRESENT_LIST);
					pub = 0; /* For global domain list bloom, we use pub_id=0 and type=0 */
					break;
				case PUB_ADS_TXT_RESELLER_DOMAIN_LIST:
					sprintf(tmp_get_query[i], GET_PUB_APP_ADS_TXT_RESELLER_LIST, pub);
					break;
				case PUB_ADS_TXT_DIRECT_DOMAIN_LIST:
					sprintf(tmp_get_query[i], GET_PUB_APP_ADS_TXT_DIRECT_LIST, pub);
					break;
			}
			test_wrap_get_bkt_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if (0 == input->test_bloom_ip[i].get_bloom_ret) {
				sprintf(tmp_set_query[i], SET_APP_ADS_TXT_BLOOM_FILTER, pub, blm_type, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bkt_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i]);
			}
		}
	}
	generate_app_ads_txt_bloom_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_app_ads_txt_bloom_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
		//Positive testcases
		{3,{"bin_name","21","1"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
		{3,{"bin_name","21","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
		{4,{"bin_name","21","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, 0, 0, 0}}, 2, 0},
		//Negative Testcases
		{4,{"bin_name","21","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
		{4,{"bin_name","21","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
		{4,{"bin_name","21","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", 0, 0}, {ADS_TXT, "ads_txt_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
		{4,{"bin_name","21","1","2"}, 1, 123, "username","password",{{KAD, "kad_dsn_name", -1, 0}, {ADS_TXT, "ads_txt_dsn_name", -1, 0}}, 2,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_app_ads_txt_bloom_filter(&inputs[i]);
	}
}



void test_generate_pub_geo_domain_list_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub> inputs
	char tmp_set_query[3][400];
	int operid = atoi(input->argv[1]);
	long int pub;
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if((test_wrap_db_connection(input)) == 0){
		for(i=0;i<input->bloom_loop_count;i++){
			pub = atoi(input->argv[(i*thread_params.batch_size)+2]);
			sprintf(tmp_get_query[i], GET_PUB_GEO_DOMAIN_BLOCKLIST_FILTER, pub);
			test_wrap_get_bkt_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query[i]);
			if(input->test_bloom_ip[i].get_bloom_ret == 0){
				sprintf(tmp_set_query[i], SET_PUB_GEO_DOMAIN_BLOCKLIST_FILTER, pub, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bkt_bloom_filter(&input->test_bloom_ip[i], tmp_set_query[i]);
			}
		}
	}
	generate_pub_geo_domain_list_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_pub_geo_domain_list_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
	//Positive testcases
	{3,{"bin_name","18","12"}, 1, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{3,{"bin_name","18","0"}, 1, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}}, 1, 0},
	{4,{"bin_name","18","4","0"}, 1, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 5, 0, 0, 0, 0}}, 2, 0},
	//Negative Testcases
	{4,{"bin_name","18","4","0"}, 1, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, 0, -1, 0, 0}}, 2, -1},
	{4,{"bin_name","18","4","0"}, 1, 123, "username","password",{{ADF, "adf_dsn_name", 0, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	{4,{"bin_name","18","4","0"}, 1, 123, "username","password",{{ADF, "adf_dsn_name", -1, 0}}, 1,{{{1,2,3}, 3, 0, 0, 0, 0}, {{1,2,3}, 3, -1, -1, 0, 0}}, 2, -1},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_pub_geo_domain_list_filter(&inputs[i]);
	}
}

/*
 * Here is the test case for global_creative_id_filter
 */
void test_generate_global_creative_id_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query[3][400];
	char tmp_get_query_bkt[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query_bkt[3][400];
	int operid = atoi(input->argv[1]);
	int single_or_both_bloom = atoi(input->argv[2]);
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if (0 == (test_wrap_db_connection(input))) {

		for (i=0; i<input->bloom_loop_count; i++) {

			sprintf(tmp_get_query_bkt[i], GET_GLOBAL_CREATIVE_ID_BLOCKLIST);

			test_wrap_get_bkt_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query_bkt[i]);
			if (0 == input->test_bloom_ip[i].get_bloom_ret) {
				sprintf(tmp_set_query_bkt[i], SET_GLOBAL_CREATIVE_ID_BLOCKLIST, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bkt_bloom_filter(&input->test_bloom_ip[i], tmp_set_query_bkt[i]);
			}
		}
	}
	generate_global_creative_id_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_global_creative_id_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
		//Positive testcases
		{3,{"bin_name","15","0"}, 1, 1111, "username","password",{{ADF, "adf_dsn_name", 0, 0},{BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 400, 500}}, 1, 0},
		//Negative Testcases
		{3,{"bin_name","15","1"}, 1, 2222, "username","password",{{ADF, "adf_dsn_name", 0, 0},{BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, -1, 0, 0, 0}}, 1, -1},
		{3,{"bin_name","15","1"}, 1, 3333, "username","password",{{ADF, "adf_dsn_name", 0, 0},{BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, -1, 0, 0}}, 1, -1},
		{3,{"bin_name","15","1"}, 1, 4444, "username","password",{{ADF, "adf_dsn_name", 0, 0},{BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, -1, -1, 0, 0}}, 1, -1},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_global_creative_id_filter(&inputs[i]);
	}
}

void test_generate_pub_preferred_global_creative_blocklist_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta;
	char *argv_ptr[10];
	char tmp_get_query_bkt[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query_bkt[3][400];
	int operid = atoi(input->argv[1]);
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if (0 == (test_wrap_db_connection(input))) {

		for (i=0; i<input->bloom_loop_count; i++) {

				sprintf(tmp_get_query_bkt[i], GET_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER);

				test_wrap_get_bkt_bloom_filter(&input->test_bloom_ip[i], &get_query_meta, tmp_get_query_bkt[i]);
				if (0 == input->test_bloom_ip[i].get_bloom_ret) {
					sprintf(tmp_set_query_bkt[i], SET_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER, input->test_bloom_ip[i].get_bloom_ele_count);
					test_wrap_set_bkt_bloom_filter(&input->test_bloom_ip[i], tmp_set_query_bkt[i]);
				}
		}
	}
	generate_pub_preferred_global_creative_blocklist_filter(&thread_params, &get_query_meta, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_pub_preferred_global_creative_blocklist_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
		//Positive testcases
		{3,{"bin_name","19","0"}, 1, 1111, "username","password",{{ADF, "adf_dsn_name", 0, 0},{BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 400, 500}}, 1, 0},
		//Negative Testcases
		{3,{"bin_name","19","0"}, 1, 2222, "username","password",{{ADF, "adf_dsn_name", 0, 0},{BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, -1, 0, 0, 0}}, 1, -1},
		{3,{"bin_name","19","0"}, 1, 3333, "username","password",{{ADF, "adf_dsn_name", 0, 0},{BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, -1, 0, 0}}, 1, -1},
		{3,{"bin_name","19","0"}, 1, 4444, "username","password",{{ADF, "adf_dsn_name", 0, 0},{BC, "bc_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, -1, -1, 0, 0}}, 1, -1},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_pub_preferred_global_creative_blocklist_filter(&inputs[i]);
	}
}

void test_generate_gss_domain_app_blocklist_filter(test_generate_bloom_filter_inputs *input){
	int i;
	bloom_thread_param_t thread_params;
	get_query_meta_t get_query_meta1;
	get_query_meta_t get_query_meta2;
	char *argv_ptr[10];
	char tmp_get_query1[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query1[3][400];
	char tmp_get_query2[3][400]; // Max 3 <pub site> pair inputs
	char tmp_set_query2[3][400];
	int operid = atoi(input->argv[1]);
	g_cur_arg_index = 2;

	test_init_thread_param(input, &thread_params, argv_ptr);
	if (0 == (test_wrap_db_connection(input))) {
		for (i=0; i<input->bloom_loop_count; i++) {
			sprintf(tmp_get_query1[i], GET_GSS_DOMAIN_BLOCKLIST);

			get_query_meta1.type[0] = SELECT_CHAR_DOMAIN;
			test_wrap_get_bkt_bloom_filter(&input->test_bloom_ip[i], &get_query_meta1, tmp_get_query1[i]);
			if(0 == input->test_bloom_ip[i].get_bloom_ret){
				sprintf(tmp_set_query1[i], SET_GSS_DOMAIN_BLOCKLIST, input->test_bloom_ip[i].get_bloom_ele_count);
				test_wrap_set_bkt_bloom_filter(&input->test_bloom_ip[i], tmp_set_query1[i]);

				if(0 == input->test_bloom_ip[i].set_bloom_ret) {
					sprintf(tmp_get_query2[i], GET_GSS_APP_BLOCKLIST);

					memcpy(&get_query_meta2, &get_query_meta1, sizeof(get_query_meta_t));
					get_query_meta2.type[0] = SELECT_CHAR;
					test_wrap_get_bkt_bloom_filter(&input->test_bloom_ip[i], &get_query_meta2, tmp_get_query2[i]);
					if (0 == input->test_bloom_ip[i].get_bloom_ret) {
						sprintf(tmp_set_query2[i], SET_GSS_APP_BLOCKLIST, input->test_bloom_ip[i].get_bloom_ele_count);
						test_wrap_set_bkt_bloom_filter(&input->test_bloom_ip[i], tmp_set_query2[i]);
					}
				}
			}
		}
	}
	generate_gss_domain_app_blocklist_filter(&thread_params, &get_query_meta1, operid);
	assert_int_equal(thread_params.ret_val,input->ret_val);
}

static void test_generate_gss_domain_app_blocklist_filter__all_testcases(void **state){
	int i;
	test_generate_bloom_filter_inputs inputs[]={
		//Positive testcases
		{2,{"bin_name","8"}, 1, 1111, "username","password",{{KAD, "kad_dsn_name", 0, 0},{ADF, "adf_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, 0, 400, 500}}, 1, 0},
		//Negative Testcases
		{2,{"bin_name","8"}, 1, 2222, "username","password",{{KAD, "kad_dsn_name", 0, 0},{ADF, "adf_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, -1, 0, 0, 0}}, 1, -1},
		{2,{"bin_name","8"}, 1, 3333, "username","password",{{KAD, "kad_dsn_name", 0, 0},{ADF, "adf_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, 0, -1, 0, 0}}, 1, -1},
		{2,{"bin_name","8"}, 1, 4444, "username","password",{{KAD, "kad_dsn_name", 0, 0},{ADF, "adf_dsn_name", 0, 0}}, 2,{{{1,2,3}, 3, -1, -1, 0, 0}}, 1, -1},
	};

	for(i=0;i<(sizeof(inputs)/sizeof(test_generate_bloom_filter_inputs));i++){
		test_generate_gss_domain_app_blocklist_filter(&inputs[i]);
	}
}

int main(){
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_set_bloom_configuration__all_testcases),
		cmocka_unit_test(test_free_bloom_configuration__all_testcases),
		cmocka_unit_test(test_get_log_file_name__all_testcases),
		cmocka_unit_test(test_init_query_metadata__all_testcases),
		cmocka_unit_test(test_get_thread_configuration__all_testcases),
		cmocka_unit_test(test_generate_blocklist_landing_page_filter__all_testcases),
		cmocka_unit_test(test_generate_whitelist_landing_page_filter__all_testcases),
		cmocka_unit_test(test_generate_daa_deviceid_optout_filter__all_testcases),
		cmocka_unit_test(test_generate_dsp_blocklist_filter__all_testcases),
		cmocka_unit_test(test_generate_dsp_whitelist_filter__all_testcases),
		cmocka_unit_test(test_generate_dsp_appurl_blocklist_filter__all_testcases),
		cmocka_unit_test(test_generate_dsp_appurl_whitelist_filter__all_testcases),
		cmocka_unit_test(test_check_publisher_iab_status__all_testcases),
		cmocka_unit_test(test_generate_publisher_site_floor_filter__all_testcases),
		cmocka_unit_test(test_generate_publisher_site_deal_whitelist_filter__all_testcases),
		cmocka_unit_test(test_generate_url_black_white_filter__all_testcases),
		cmocka_unit_test(test_generate_publisher_campaign_level_blocklist__all_testcases),
		cmocka_unit_test(test_generate_ads_txt_domain_list_filter__all_testcases),
		cmocka_unit_test(test_generate_pub_geo_domain_list_filter__all_testcases),
		cmocka_unit_test(test_generate_global_creative_id_filter__all_testcases),
		cmocka_unit_test(test_generate_pub_preferred_global_creative_blocklist_filter__all_testcases),
		cmocka_unit_test(test_generate_blocklist_landing_page_filter_new__all_testcases),
		cmocka_unit_test(test_generate_gss_domain_app_blocklist_filter__all_testcases),
		cmocka_unit_test(test_generate_app_ads_txt_bloom_filter__all_testcases),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
