#include <stdarg.h>
#include <stddef.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <setjmp.h>
#include <cmocka.h>
#include <string.h>
#include <stdio.h>
#include <error.h>
#include <ad_server_types.h>
#include <common_constants.h>
#include <rt_types.h>
#include "bloom_filter.h"
#include "bkt_bloom_filter.h"
#include "bloom_filter_handler.h"
int gbl_log_level = L_DEBUG;
SQLRETURN __wrap_SQLRowCount(
		SQLHSTMT   StatementHandle,
		SQLLEN *   RowCountPtr) {
	memcpy(RowCountPtr, mock_type(SQLLEN *),1);
	return mock_type(SQLRETURN);
}

int __wrap_convert_unicode_domain_to_punycode(const char *in_domain, char **out_domain) {
	check_expected(in_domain);
	char *tmp_str = mock_type(char*);
	(*out_domain) = (char*)malloc(strlen(tmp_str));
	strcpy((*out_domain), tmp_str);
	return mock_type(int);
}

void __wrap_strtolower(char *str, int max_len) {
}

int __wrap_build_bkt_bloom(const char *list,
		int ele_count,
		BKT_BLOOM** bkt_bloom_list,
		size_t *ret_size,
		int max_element_size) {
	check_expected(list);
	check_expected(ele_count);
	check_expected(max_element_size);
	size_t tmp = mock_type(size_t);
	ret_size[0] = tmp;
	bkt_bloom_list[0] = mock_type(BKT_BLOOM*);
	return mock_type(int);
}

void __wrap_db_conn_print_error(SQLSMALLINT htype, SQLHANDLE hndl, SQLRETURN frc, int line, char *file) {
}

SQLRETURN __wrap_SQLBindCol(
		SQLHSTMT       StatementHandle,
		SQLUSMALLINT   ColumnNumber,
		SQLSMALLINT    TargetType,
		SQLPOINTER     TargetValuePtr,
		SQLLEN         BufferLength,
		SQLLEN *       StrLen_or_Ind) {
	check_expected(ColumnNumber);
	check_expected(TargetType);
	check_expected(BufferLength);
	int sz = mock_type(int);
	char *tmp = mock_type(SQLPOINTER);
	memcpy(TargetValuePtr, tmp, sz);
	memcpy(StrLen_or_Ind, mock_type(SQLLEN *),1);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLExecute(SQLHSTMT StatementHandle) {
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFetch(SQLHSTMT StatementHandle) {
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLBindParameter(
		SQLHSTMT        StatementHandle,
		SQLUSMALLINT    ParameterNumber,
		SQLSMALLINT     InputOutputType,
		SQLSMALLINT     ValueType,
		SQLSMALLINT     ParameterType,
		SQLULEN         ColumnSize,
		SQLSMALLINT     DecimalDigits,
		SQLPOINTER      ParameterValuePtr,
		SQLLEN          BufferLength,
		SQLLEN *        StrLen_or_IndPtr) {
	check_expected(ParameterNumber);
	check_expected(InputOutputType);
	check_expected(ValueType);
	check_expected(ParameterType);
	check_expected(DecimalDigits);
	check_expected(BufferLength);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLFreeHandle(SQLSMALLINT HandleType, SQLHANDLE Handle) {
	return 0;
}

SQLRETURN __wrap_SQLAllocHandle(SQLSMALLINT HandleType,SQLHANDLE InputHandle,SQLHANDLE *OutputHandlePtr) {
	check_expected(HandleType);
	return mock_type(SQLRETURN);
}

SQLRETURN __wrap_SQLPrepare(SQLHSTMT StatementHandle, SQLCHAR *StatementText, SQLINTEGER TextLength) {
	check_expected(StatementText);
	check_expected(TextLength);
	return mock_type(SQLRETURN);
}

typedef struct test_get_bkt_bloom_filters_inputs_t {
	get_query_meta_t qmeta;
	char db_query[200];
	int ret_sql_prepare;
	int ret_sql_exec;
	char ele[100];
	char ele_to_add[100];
	int ret_build_bkt;
	int element_count;
	int ret_size;
	int ret_val;
} test_get_bkt_bloom_filters_inputs;

void test_get_bkt_bloom_filters(test_get_bkt_bloom_filters_inputs *input) {
	int ret_val;
	int is_domain = 0;
	int row_count = 1;
	db_connection_t dbconn;
	get_query_meta_t query_meta;
	size_t ret_list_size[MAX_ALLOWED_BKT_BLOOMS]={0};
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS]={0};
	BKT_BLOOM bkt_bloom;
	int element_count;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	char bind_input[10];

	int tmp_int=0;
	query_meta.nSelect = input->qmeta.nSelect;
	query_meta.type[0] = input->qmeta.type[0];
	query_meta.type[1] = input->qmeta.type[1];
	query_meta.max_elt_size = input->qmeta.max_elt_size;

	strcpy((char*)sql_statement, input->db_query);

	expect_value(__wrap_SQLAllocHandle, HandleType, SQL_HANDLE_STMT);
	will_return(__wrap_SQLAllocHandle, SQL_SUCCESS);

	expect_string(__wrap_SQLPrepare, StatementText, input->db_query);
	expect_value(__wrap_SQLPrepare, TextLength, SQL_NTS);
	will_return(__wrap_SQLPrepare, input->ret_sql_prepare);

	if (SQL_SUCCESS == input->ret_sql_prepare) {
		will_return(__wrap_SQLExecute, input->ret_sql_exec);

		if (SQL_SUCCESS == input->ret_sql_exec) {
			expect_value(__wrap_SQLBindCol, ColumnNumber, 1);
			switch (input->qmeta.type[0]) {
				case SELECT_INT:
					{
						int id = atoi(input->ele);
						strncpy(bind_input, (char*)&id, sizeof(int));
						expect_value(__wrap_SQLBindCol, TargetType, SQL_C_ULONG);
						expect_value(__wrap_SQLBindCol, BufferLength, 0);
						will_return(__wrap_SQLBindCol, sizeof(int));
						will_return(__wrap_SQLBindCol, bind_input);
						break;
					}
				case SELECT_CHAR_DOMAIN:
					{
						is_domain = 1;
					}
				case SELECT_CHAR:
					{
						expect_value(__wrap_SQLBindCol, TargetType, SQL_C_CHAR);
						expect_value(__wrap_SQLBindCol, BufferLength, input->qmeta.max_elt_size+1);
						will_return(__wrap_SQLBindCol, strlen(input->ele)+1);
						will_return(__wrap_SQLBindCol, input->ele);
						break;
					}
				case SELECT_UNSIGNED_BIG:
					{
						unsigned long long ucrid = atol(input->ele);
						strncpy(bind_input, (char*)&ucrid, sizeof(unsigned long long));
						expect_value(__wrap_SQLBindCol, TargetType, SQL_C_UBIGINT);
						expect_value(__wrap_SQLBindCol, BufferLength, 0);
						will_return(__wrap_SQLBindCol, sizeof(unsigned long long));
						will_return(__wrap_SQLBindCol, bind_input);
						break;
					}
			}

			will_return(__wrap_SQLBindCol, &tmp_int);
			will_return(__wrap_SQLBindCol, SQL_SUCCESS);

			will_return(__wrap_SQLRowCount, &row_count);
			will_return(__wrap_SQLRowCount, 0);

			will_return(__wrap_SQLFetch, 0);
			will_return(__wrap_SQLFetch, SQL_NO_DATA);

			if (is_domain) {
				expect_string(__wrap_convert_unicode_domain_to_punycode, in_domain, input->ele_to_add);
				will_return(__wrap_convert_unicode_domain_to_punycode, cast_ptr_to_largest_integral_type(input->ele_to_add));
				will_return(__wrap_convert_unicode_domain_to_punycode, 0);
			}

			expect_string(__wrap_build_bkt_bloom, list, input->ele_to_add);
			expect_value(__wrap_build_bkt_bloom, ele_count, 1);
			expect_value(__wrap_build_bkt_bloom, max_element_size, input->qmeta.max_elt_size);
			if (0 == input->ret_build_bkt) {
				will_return(__wrap_build_bkt_bloom, 1);
				will_return(__wrap_build_bkt_bloom, cast_ptr_to_largest_integral_type(&bkt_bloom));
			} else {
				will_return(__wrap_build_bkt_bloom, 0);
				will_return(__wrap_build_bkt_bloom, cast_ptr_to_largest_integral_type(NULL));
			}
			will_return(__wrap_build_bkt_bloom, input->ret_build_bkt);
		}
	}

	ret_val = get_bkt_bloom_filters(&dbconn,
			sql_statement,
			&query_meta,
			bloom_list,
			ret_list_size,
			&element_count);

	assert_int_equal(ret_val, input->ret_val);
	assert_int_equal(element_count, input->element_count);
	assert_int_equal(ret_list_size[0], input->ret_size);
}

static void test_get_bkt_bloom_filters__all_testcases(void **state) {
	int i;
	test_get_bkt_bloom_filters_inputs inputs[] = {
		/* qmeta,ret_sql_prep,ret_sql_exe,ele,ele_to_add,ret_bld_bkt,ele_count,ret_size,ret_val */
		/* Positive testcases */
		{{1,{SELECT_CHAR,0},100},"db_query1",0,0,"a.com","a.com",0,1,1,0}, /* select char */
		{{1,{SELECT_CHAR_DOMAIN,0},100},"db_query2",0,0,"a.com","a.com",0,1,1,0}, /* select domain */
		{{1,{SELECT_CHAR_DOMAIN,0},100},"db_query3",0,0,"www.a.com","a.com",0,1,1,0}, /* select domain */
		{{1,{SELECT_UNSIGNED_BIG,0},100},"db_query4",0,0,"1234","1234",0,1,1,0}, /* select ucrid */
		/* Negative testcases */
		{{1,{SELECT_CHAR,0},100},"db_query5",-1,0,"1234","1234",0,1,0,4}, /* SQLPrepare fails */
		{{1,{SELECT_CHAR,0},100},"db_query6",0,-1,"1234","1234",0,1,0,4}, /* SQLExecute fails */
		{{1,{SELECT_CHAR,0},100},"db_query7",0,0,"1234","1234",-1,1,0,-1}, /* build_bkt_bloom fails */
	};

	for (i=0; i<(sizeof(inputs)/sizeof(test_get_bkt_bloom_filters_inputs)); i++) {
		test_get_bkt_bloom_filters(&inputs[i]);
	}
}

typedef struct test_set_bkt_bloom_filters_inputs_t {
	char db_query[100];
	int is_bloom_null;
	int ret_sql_prepare;
	int ret_sql_bind;
	int ret_sql_exec;
	int ret_val;
} test_set_bkt_bloom_filters_inputs;

void test_set_bkt_bloom_filters(test_set_bkt_bloom_filters_inputs *input) {
	int ret_val;
	db_connection_t dbconn;
	SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS]={0};
	BKT_BLOOM bkt_bloom;
	bkt_bloom.nelements = 1;
	bkt_bloom.bit_array_size = 1;
	size_t ret_size[MAX_ALLOWED_BKT_BLOOMS]={0};

	strcpy((char*)sql_statement, input->db_query);

	if (!input->is_bloom_null) {
		bloom_list[0] = &bkt_bloom;
		ret_size[0] = 1;
		expect_value(__wrap_SQLAllocHandle, HandleType, SQL_HANDLE_STMT);
		will_return(__wrap_SQLAllocHandle, SQL_SUCCESS);

		expect_string(__wrap_SQLPrepare, StatementText, input->db_query);
		expect_value(__wrap_SQLPrepare, TextLength, SQL_NTS);
		will_return(__wrap_SQLPrepare, input->ret_sql_prepare);

		if (SQL_SUCCESS == input->ret_sql_prepare) {
			expect_value(__wrap_SQLBindParameter, ParameterNumber, 1);
			expect_value(__wrap_SQLBindParameter, InputOutputType, SQL_PARAM_INPUT);
			expect_value(__wrap_SQLBindParameter, ValueType, SQL_C_BINARY);
			expect_value(__wrap_SQLBindParameter, ParameterType, SQL_LONGVARBINARY);
			expect_value(__wrap_SQLBindParameter, DecimalDigits, 0);
			expect_value(__wrap_SQLBindParameter, BufferLength, 0);
			will_return(__wrap_SQLBindParameter, input->ret_sql_bind);
			if (SQL_SUCCESS == input->ret_sql_bind) {
				will_return(__wrap_SQLExecute, input->ret_sql_exec);
			}
		}
	}

	ret_val = set_bkt_bloom_filters(&dbconn, sql_statement, bloom_list, ret_size, 1);
	assert_int_equal(ret_val, input->ret_val);
}

static void test_set_bkt_bloom_filters__all_testcases(void **state) {
	int i;
	test_set_bkt_bloom_filters_inputs inputs[] = {
		/* db_query, is_null_blm,ret_sql_prep,ret_sql_bind,ret_sql_exe,ret_val */
		/* Positive testcases */
		{"db_query1",0,0,0,0,0}, /* success-valid bloom */
		{"db_query2",1,0,0,0,0}, /* success-null bloom  */
		/* Negative testcases */
		{"db_query3",0,-1,0,0,4}, /* SQLPrepare failed */
		{"db_query4",0,0,-1,0,4}, /* SQLBindParameter failed */
		{"db_query5",0,0,0,-1,4}, /* SQLExecute failed */
	};

	for (i=0; i<(sizeof(inputs)/sizeof(test_set_bkt_bloom_filters_inputs)); i++) {
		test_set_bkt_bloom_filters(&inputs[i]);
	}
}

int main() {
	const struct CMUnitTest tests[] = {
		cmocka_unit_test(test_get_bkt_bloom_filters__all_testcases),
		cmocka_unit_test(test_set_bkt_bloom_filters__all_testcases),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
