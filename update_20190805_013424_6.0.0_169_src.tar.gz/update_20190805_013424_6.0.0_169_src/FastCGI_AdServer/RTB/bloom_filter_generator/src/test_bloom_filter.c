/*
   PubMatic Inc. ("PubMatic") CONFIDENTIAL
   Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_bloom_filter_generator.h"
#include "error.h"
#include "bloom_filter.h"
#include "bkt_bloom_filter.h"
#include "property.h"
#include "config.h"
#include "floor_rules_types.h"
#include "rtb_brand_control_util.h"
#include "db_get_bloom_filters.h"
#include "db_get_bkt_bloom_filters.h"
#include <fcntl.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "bloom_filter_handler.h"


/*********************************************/
/*  Test Bloom Filter Binary configurations  */
/*********************************************/

char *g_odbc_kad_dsn_name = "LocalKomliAdServer";
char *g_odbc_adf_dsn_name = "AdFlex";
char *g_odbc_dsn_user_name = "kdbuser";
char *g_odbc_dsn_user_password = "KdBuSeR12!";

/*********************************************/
int gbl_log_level = INFO;
db_env_t g_dbenv;

typedef enum db_type_t{
	KAD_DB = 0,
	ADF_DB = 1
}db_conn_type;

typedef enum element_type_t{
	NOT_DOMAIN = 0,
	IS_DOMAIN = 1
}ele_type;

typedef int (*query_builder)(int, long *, char **);
typedef int (*bloom_check_handler)(db_connection_t *dbconn, const char *db_query, char *check_str, long *bloom_arg, ele_type type);

typedef struct test_bloom_filter_data_t{
	char *bloom_type;
	char *arg_names[4];
	int arg_count;
	char *db_query[3];
	int db_query_count;
	db_conn_type db_type;
	ele_type is_domain_ele;
	query_builder query_builder_fun;
	bloom_check_handler bloom_check_fun;
}test_bloom_filter_data;

/* Query Builder functions */
int whitelist_blacklist_query_builder(int oper_id, long *args, char **db_query);
int pub_camp_domain_query_builder(int oper_id, long *args, char **db_query);
int ads_txt_domain_bloom_query_builder(int oper_id, long *args, char **db_query);
int pub_geo_domain_bloom_query_builder(int oper_id, long *args, char **db_query);
int site_floor_actv_ent_query_builder(int oper_id, long *args, char **db_query);
int gssb_query_builder(int oper_id, long *args, char **db_query);
int global_creative_id_bloom_query_builder(int oper_id, long *args, char **db_query);

/* Bloom check handler functions */
int bkt_bloom_check_handler(db_connection_t *dbconn,
		const char *db_query,
		char *check_str,
		long *bloom_arg,
		ele_type type);
int multi_bloom_check_handler(db_connection_t *dbconn,
		const char *db_query,
		char *check_str,
		long *bloom_arg,
		ele_type type);

/* Bloom check data required for bloom check */
test_bloom_filter_data bloom_check_data[]={
	/* Guidelines for new entry in bloom check data
		 1. Bloom type string(name of bloom), explains type of bloom
		 2. Argument list which test bloom binary takes, (max 4 supported).
		 If it takes less than max arguments, keep other entries NULL, and keep proper count.
		 3. DB queries, which will be used to fetch the bloom from Database. (max 3 supported)
		 If bloom type have both blocklist and Whitelist support,
		 we can add two different DB queries for each respectively.
		 Otherwise we can add only one DB query and keep other entry NULL, also keep count=1
		 4. Which DB to use. Which means in what DB bloom is stored.
		 We have two options, either KAD(KomliAdServer) or ADF(AdFlex)
		 5. Is element to check 'domain'? keep value as either IS_DOMAIN or NOT_DOMAIN
		 6. Query Builder, function which is responsible for preparing the DB query.
		 You can use default behaviour by keeping it NULL.
		 Otherwise write your own implementation and pass it here (function pointer).
		 7. bloom check handler function, which is responsible for fetching the bloom filter from DB,
		 and checking given element in it and destroying bloom after use.
		 There are two variants implemented, (multi_bloom and bkt_bloom), use whichever suits your need.
		 You can also implement your own variant if needed and pass it here (function pointer).
		 */

	{"BLOOM_BLOCKLIST_LANDING_PAGE_FILTER", /* Bloom type - OperID 1 */
		{"PUB_ID", "SITE_ID", "to check: Domain", NULL}, 3, /* Argument details and count */
		{GET_PUB_SITE_DOMAIN_BLOCKLIST_BLOOM, NULL, NULL}, 1, /* DB Queries to read bloom and count */
		KAD_DB, /* DB to use */
		IS_DOMAIN, /* element to check is domain */
		NULL, /* Query Builder function */
		multi_bloom_check_handler}, /* DB get bloom filter function */

	{"BLOOM_CREATIVE_ID_FILTER", /* Bloom type - OperID 2 */
		{"PUB_ID", "SITE_ID", "BLK(0)/WHT(1) PREF", "to check: CreativeID"}, 4,
		{GET_PUB_SITE_CREATIVE_BLOCKLIST_BLOOM, GET_PUB_SITE_CREATIVE_WHITELIST_BLOOM, NULL}, 2,
		ADF_DB,
		NOT_DOMAIN,
		whitelist_blacklist_query_builder,
		multi_bloom_check_handler},

	/* This bloom is not live/in-use in production */
	{"BLOOM_ADVERTISER_DOMAIN_FILTER", /* Bloom type - OperID 3 */
		{"to check: CreativeID", NULL, NULL, NULL}, 1,
		{NULL, NULL, NULL}, 0, /* Not providing db_query means, this bloom check not supported */
		KAD_DB,
		IS_DOMAIN,
		NULL,
		multi_bloom_check_handler},

	{"BLOOM_WHITELIST_LANDING_PAGE_FILTER", /* Bloom type - OperID 4 */
		{"PUB_ID", "SITE_ID", "to check: Domain", NULL}, 3,
		{GET_PUB_SITE_DOMAIN_WHITELIST_BLOOM, NULL, NULL}, 1,
		KAD_DB,
		IS_DOMAIN,
		NULL,
		multi_bloom_check_handler},

	{"BLOOM_DSP_BLOCKLIST_FILTER", /* Bloom type - OperID 5 */
		{"DSP_ID", "CAMP_ID", "to check: Domain", NULL}, 3,
		{GET_DSP_CAMPAIGN_BLOCKLIST_BLOOM, NULL, NULL}, 1,
		ADF_DB,
		IS_DOMAIN,
		NULL,
		multi_bloom_check_handler},

	{"BLOOM_PUBLISHER_SITE_FLOOR_FILTER", /* Bloom type - OperID 6 */
		{"PUB_ID", "SITE_ID", "ACTV ENTITY[0-AdvId/1-AdvDom/2-AdvCat]","to check:"}, 4,
		{GET_PUB_SITE_FLR_RL_ADV_ID_BLOOM, GET_PUB_SITE_FLR_RL_ADV_DOM_BLOOM, GET_PUB_SITE_FLR_RL_ADV_CAT_BLOOM}, 3,
		KAD_DB,
		NOT_DOMAIN,
		site_floor_actv_ent_query_builder,
		multi_bloom_check_handler},

	{"BLOOM_PUBLISHER_SITE_DEAL_WHITELIST_FILTER", /* Bloom type - OperID 7 */
		{"PUB_ID", "SITE_ID", "to check:", NULL}, 3,
		{GET_PUB_SITE_DEAL_WHITELIST_BLOOM, NULL, NULL}, 1,
		KAD_DB,
		NOT_DOMAIN,
		NULL,
		multi_bloom_check_handler},

	{"GSS_BLOCKLIST_FILTER", /* Bloom type - OperID 8 */
		{"Blocklist to check[0-DOMAIN/1-APP]","to check: Domain", NULL, NULL}, 2,
		{GET_GSS_DOMAIN_BLOCKLIST_BLOOM, GET_GSS_APP_BLOCKLIST_BLOOM, NULL}, 2,
		ADF_DB,
		IS_DOMAIN,
		gssb_query_builder,
		bkt_bloom_check_handler},

	{"BLOOM_UNIQ_CREATV", /* Bloom type - OperID 9 */
		{"to check: CreativeID", NULL, NULL, NULL}, 1,
		{GET_GLOBAL_UNIQUE_CREATIVE_ID_BLOOM, NULL, NULL}, 0,
		ADF_DB,
		NOT_DOMAIN,
		NULL,
		bkt_bloom_check_handler},

	{"BLOOM_DSP_WHITELIST_FILTER", /* Bloom type - OperID 10 */
		{"DSP_ID", "CAMP_ID", "to check: Domain", NULL}, 3,
		{GET_DSP_CAMPAIGN_WHITELIST_BLOOM, NULL, NULL}, 1,
		ADF_DB,
		IS_DOMAIN,
		NULL,
		multi_bloom_check_handler},

	{"BLOOM_DSP_APPURL_BLOCKLIST_FILTER", /* Bloom type - OperID 11 */
		{"DSP_ID", "CAMP_ID", "to check: AppID/Bundle", NULL}, 3,
		{GET_DSP_CAMPAIGN_APPURL_BLOCKLIST_BLOOM, NULL, NULL}, 1,
		ADF_DB,
		NOT_DOMAIN,
		NULL,
		multi_bloom_check_handler},

	{"BLOOM_DSP_APPURL_WHITELIST_FILTER", /* Bloom type - OperID 12 */
		{"DSP_ID", "CAMP_ID", "to check: AppID/Bundle", NULL}, 3,
		{GET_DSP_CAMPAIGN_APPURL_WHITELIST_BLOOM, NULL, NULL}, 1,
		ADF_DB,
		IS_DOMAIN,
		NULL,
		multi_bloom_check_handler},

	{"BLOOM_URL_BLACK_WHITE_FILTER", /* Bloom type - OperID 13 */
		{"PUB_ID", "SITE_ID", "BLK(0)/WHT(1) PREF", "to check: Domain"}, 4,
		{NULL, NULL, NULL}, 0,
		KAD_DB,
		IS_DOMAIN,
		whitelist_blacklist_query_builder,
		multi_bloom_check_handler},

	{"BLOOM_DAA_DEVICEID_OPTOUT_FILTER", /* Bloom type - OperID 14 */
		{"hash_type[1-Raw/2-md5/3-sha1]", "to check: DeviceID", NULL, NULL}, 2,
		{GET_DAA_DEVICE_OPTOUT_BLOOM, NULL, NULL}, 1,
		KAD_DB,
		NOT_DOMAIN,
		NULL,
		multi_bloom_check_handler},

	{"BLOOM_GLOBAL_CREATIVE_ID_FILTER", /* Bloom type - OperID 15 */
		{"to check: Ucrid", NULL, NULL, NULL}, 1,
		{GET_GLOBAL_CREATIVE_ID_BLOCKLIST_BLOOM, NULL, NULL}, 1,
		ADF_DB,
		NOT_DOMAIN,
		NULL,
		bkt_bloom_check_handler},

	{"BLOOM_PUBLISHER_CAMPAIGN_DOMAIN_FILTER", /* Bloom type - OperID 16 */
		{"DSP_ID", "CAMP_ID", "PUB_ID", "to check:"}, 4,
		{GET_DSP_PUB_CAMPAIGN_BLOCKLIST_BLOOM, NULL, NULL}, 1,
		ADF_DB,
		IS_DOMAIN,
		pub_camp_domain_query_builder,
		multi_bloom_check_handler},

	{"BLOOM_ADS_TXT_DOMAIN_LIST_FILTER", /* Bloom type - OperID 17 */
		{"PUB_ID", "TYPE[0-global ADS.TXT domains/1-reseller pub/2-direct pub]", "to check:domain", NULL}, 3,
		{GET_ADS_TXT_DOMAIN_LIST_BLOOM, NULL, NULL}, 1,
		KAD_DB,
		IS_DOMAIN,
		ads_txt_domain_bloom_query_builder,
		bkt_bloom_check_handler},

	{"BLOOM_PUB_GEO_DOMAIN_BLOCKLIST_FILTER", /* Bloom type - OperID 18 */
		{"PUB_ID", "to check:geo_domain", NULL, NULL}, 2,
		{GET_PUB_GEO_DOMAIN_BLOCKLIST_BLOOM, NULL, NULL}, 1,
		ADF_DB,
		NOT_DOMAIN,
		pub_geo_domain_bloom_query_builder,
		bkt_bloom_check_handler},

	{"BLOOM_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_FILTER", /* Bloom type - OperID 19 */
		{"to check id_Ucris", NULL, NULL, NULL}, 1,
		{GET_PUB_PREFERRED_GLOBAL_CREATIVE_BLOCKLIST_BLOOM, NULL, NULL}, 1,
		ADF_DB,
		NOT_DOMAIN,
		NULL,
		bkt_bloom_check_handler},

	{"BLOOM_BLOCKLIST_LANDING_PAGE_FILTER_NEW", /* Bloom type - OperID 20 */
		{"to check: Landing Page Tld", NULL, NULL, NULL}, 1,
		{NULL, NULL, NULL}, 0, /* Not providing db_query means, this bloom check not supported */
		KAD_DB,
		IS_DOMAIN,
		NULL,
		multi_bloom_check_handler},

	{"BLOOM_APP_ADS_TXT_FILTER", /* Bloom type - OperID 21 */
		{"PUB_ID", "TYPE[0-global ADS.TXT domains/1-reseller pub/2-direct pub]", "to check:domain", NULL}, 3,
		{GET_APP_ADS_TXT_BLOOM, NULL, NULL}, 1,
		KAD_DB,
		NOT_DOMAIN,
		ads_txt_domain_bloom_query_builder,
		bkt_bloom_check_handler},

};
int total_bloom_filter_types = sizeof(bloom_check_data) / sizeof(test_bloom_filter_data);

int whitelist_blacklist_query_builder(int oper_id, long *args, char **db_query) {
	/* Validating range */
	long arg = args[2];
	if (arg < 0 || arg > 1) {
		printf("ERROR: Invalid argument, pass %s\n", bloom_check_data[oper_id].arg_names[2]);
		return ADS_ERROR_INTERNAL;
	}
	(*db_query) = bloom_check_data[oper_id].db_query[arg];
	return ADS_ERROR_SUCCESS;
}

int site_floor_actv_ent_query_builder(int oper_id, long *args, char **db_query) {
	/* Validating range */
	long arg = args[2];
	if (arg < 0 || arg > 2) {
		printf("ERROR: Invalid argument, pass %s\n", bloom_check_data[oper_id].arg_names[2]);
		return ADS_ERROR_INTERNAL;
	}
	(*db_query) = bloom_check_data[oper_id].db_query[arg];
	return ADS_ERROR_SUCCESS;
}

int gssb_query_builder(int oper_id, long *args, char **db_query) {
	/* Validating range */
	long arg = args[0];
	if (arg < 0 || arg > 1) {
		printf("ERROR: Invalid argument, pass %s\n", bloom_check_data[oper_id].arg_names[0]);
		return ADS_ERROR_INTERNAL;
	}
	(*db_query) = bloom_check_data[oper_id].db_query[arg];
	if (1 == arg) {
		bloom_check_data[oper_id].is_domain_ele = NOT_DOMAIN;
	}
	return ADS_ERROR_SUCCESS;
}

int pub_camp_domain_query_builder(int oper_id, long *args, char **db_query) {
	static char updated_query[MAX_SQL_QUERY_STR_LEN + 1];
	snprintf(updated_query, MAX_SQL_QUERY_STR_LEN, bloom_check_data[oper_id].db_query[0], args[2]);
	updated_query[MAX_SQL_QUERY_STR_LEN] = '\0';
	(*db_query) = updated_query;
	return ADS_ERROR_SUCCESS;
}

int ads_txt_domain_bloom_query_builder(int oper_id, long *args, char **db_query) {
	static char updated_query[MAX_SQL_QUERY_STR_LEN + 1];
	snprintf(updated_query, MAX_SQL_QUERY_STR_LEN, bloom_check_data[oper_id].db_query[0], args[0], args[1]);
	updated_query[MAX_SQL_QUERY_STR_LEN] = '\0';
	(*db_query) = updated_query;
	return ADS_ERROR_SUCCESS;
}

int pub_geo_domain_bloom_query_builder(int oper_id, long *args, char **db_query) {
	static char updated_query[MAX_SQL_QUERY_STR_LEN + 1];
	snprintf(updated_query, MAX_SQL_QUERY_STR_LEN, bloom_check_data[oper_id].db_query[0], args[0]);
	updated_query[MAX_SQL_QUERY_STR_LEN] = '\0';
	(*db_query) = updated_query;
	return ADS_ERROR_SUCCESS;
}

int global_creative_id_bloom_query_builder(int oper_id, long *args, char **db_query) {
	static char updated_query[MAX_SQL_QUERY_STR_LEN + 1];
	snprintf(updated_query, MAX_SQL_QUERY_STR_LEN, bloom_check_data[oper_id].db_query[0], args[0]);
	updated_query[MAX_SQL_QUERY_STR_LEN] = '\0';
	(*db_query) = updated_query;
	return ADS_ERROR_SUCCESS;
}

int multi_bloom_check_handler(db_connection_t *dbconn,
		const char *db_query,
		char *check_str,
		long *bloom_arg,
		ele_type type) {
	int index = 0;
	int found = 0;
	int bloom_count = 0;
	int ret_val = ADS_ERROR_INTERNAL;
	size_t ret_list_size[MAX_ALLOWED_BLOOMS]={0};
	BLOOM *bloom_list[MAX_ALLOWED_BLOOMS]={0};

	(void)bloom_arg;

	/* Execute DB query to get bloom filters */
	ret_val = db_get_bloom_filters(dbconn,
			db_query,
			bloom_list,
			&bloom_count,
			ret_list_size,
			bloom_arg[0],
			bloom_arg[1]);

	if (ADS_ERROR_SUCCESS != ret_val) {
		printf("\nERROR: db_get_bloom_filters failed for %s:%d\n", __FILE__, __LINE__);
		return ret_val;
	}

	/* if bloom_count is 0, it means bloom filter not present is DB */
	if (bloom_count <= 0) {
		printf("\nERROR: Bloom Filter is NOT present in DB\n");
	} else {
		for (index=0; index<bloom_count; index++) {
			if (IS_DOMAIN == type) {
				if ((found = substring_bloom_search(check_str, (const BLOOM *)bloom_list[index]))) break;
			} else {
				if ((found = bloom_check((const BLOOM *)bloom_list[index], check_str))) break;
			}
		}
	}

	/* Destroy the memory taken by bloom filter */
	for (index=0; index<bloom_count; index++) {
		bloom_destroy(&bloom_list[index]);
	}

	return found;
}

int bkt_bloom_check_handler(db_connection_t *dbconn,
		const char *db_query,
		char *check_str,
		long *bloom_arg,
		ele_type type) {
	int index = 0;
	int found = 0;
	int bloom_count = 0;
	int ret_val = ADS_ERROR_INTERNAL;
	size_t ret_list_size[MAX_ALLOWED_BKT_BLOOMS] = {0};
	BKT_BLOOM *bloom_list[MAX_ALLOWED_BKT_BLOOMS] = {0};
	char update_time[MAX_TIMESTAMP_SIZE_YYYYMMDD] = {0};

	(void)bloom_arg;

	/* Execute DB query to get bloom filters */
	ret_val = db_get_bkt_bloom_filters(dbconn,
			db_query,
			bloom_list,
			&bloom_count,
			ret_list_size,
			update_time);

	if (ADS_ERROR_SUCCESS != ret_val) {
		printf("\nERROR: db_get_bloom_filters failed for %s:%d\n", __FILE__, __LINE__);
		return ret_val;
	}

	/* if bloom_count is 0, it means bloom filter not present is DB */
	if (bloom_count <= 0) {
		printf("\nERROR: Bloom Filter is NOT present in DB\n");
	} else {
		if (IS_DOMAIN == type) {
			found = substring_bkt_bloom_check(check_str, (const BKT_BLOOM **)bloom_list, bloom_count);
		} else {
			found = bkt_bloom_check(check_str, (const BKT_BLOOM **)bloom_list, bloom_count);
		}
	}

	/* Destroy the memory taken by bloom filter */
	for (index=0; index<bloom_count; index++) {
		bkt_bloom_destroy(&bloom_list[index]);
	}

	return found;
}

int generic_bloom_check(int oper_id,
		int argc,
		char *argv[]) {
	db_connection_t dbconn;
	int ret_val = ADS_ERROR_INTERNAL, index;
	int found = 0;
	long bloom_arg[3] = {0};
	char *check_str = argv[2];
	char *db_query = bloom_check_data[oper_id].db_query[0];
	char *dsn_name = bloom_check_data[oper_id].db_type ? g_odbc_adf_dsn_name : g_odbc_kad_dsn_name;
	int arg_count = bloom_check_data[oper_id].arg_count;

	/* Argument count validation */
	if (NULL == db_query) {
		printf("This bloom is not supported by test binary\n");
		return ADS_ERROR_INTERNAL;
	}
	if (argc < (arg_count + 2)) {
		printf("ERROR: insufficient arguments passed\n");
		printf("Required Arguments: ");
		for (index=0; index<arg_count; index++) {
			printf("<%s> ", bloom_check_data[oper_id].arg_names[index]);
		}
		printf("\n\n");
		return ret_val;
	}

	/* Create DB connection */
	ret_val = get_db_connection(&dbconn, &g_dbenv, dsn_name,
			g_odbc_dsn_user_name, g_odbc_dsn_user_password);
	if (ADS_ERROR_SUCCESS != ret_val) {
		printf("ERROR:Connection to DB failed, dsn_name:%s %s:%s\n",
				dsn_name, g_odbc_dsn_user_name, g_odbc_dsn_user_password);
		return ret_val;
	}

	/* Parsing arguments */
	switch (arg_count) {
		case 1:
			bloom_arg[0] = 0;
			bloom_arg[1] = 0;
			bloom_arg[2] = 0;
			check_str = argv[2];
			break;

		case 2:
			bloom_arg[0] = atol(argv[2]);
			bloom_arg[1] = 0;
			bloom_arg[2] = 0;
			check_str = argv[3];
			break;

		case 3:
			bloom_arg[0] = atol(argv[2]);
			bloom_arg[1] = atol(argv[3]);
			bloom_arg[2] = 0;
			check_str = argv[4];
			break;

		case 4:
			bloom_arg[0] = atol(argv[2]);
			bloom_arg[1] = atol(argv[3]);
			bloom_arg[2] = atol(argv[4]);
			check_str = argv[5];
			break;

		default:
			printf("\nERROR: Configured arg_count is Invalid %s:%d\n", __FILE__, __LINE__);
			/* Release DB connection */
			release_db_connection(&dbconn);
			return ret_val;
	}

	/* Calling query builder if required */
	if (bloom_check_data[oper_id].query_builder_fun) {
		if (ADS_ERROR_SUCCESS != (ret_val = bloom_check_data[oper_id].query_builder_fun(oper_id, bloom_arg, &db_query))) {
			/* Release DB connection */
			release_db_connection(&dbconn);
			return ret_val;
		}
	}

	/* Print bloom arguments taken before proceeding to DB call */
	printf("\n********* Arguments Taken *********");
	printf("\nBLOOM TYPE: %s", bloom_check_data[oper_id].bloom_type);
	for (index=0; index<arg_count-1; index++) {
		printf("\n%s: %ld", bloom_check_data[oper_id].arg_names[index], bloom_arg[index]);
	}
	printf("\nSEARCHING: '%s'", check_str);
	printf("\n***********************************\n");

	/* Call bloom check handler function */
	if (bloom_check_data[oper_id].bloom_check_fun) {
		found = bloom_check_data[oper_id].bloom_check_fun(&dbconn,
				db_query,
				check_str,
				bloom_arg,
				bloom_check_data[oper_id].is_domain_ele);

		switch (found) {
			case 0: /* Check_str not found in bloom */
				printf("\nFAILURE --> '%s' NOT Found in bloom\n", check_str);
				break;
			case 1: /* Check_str found in bloom */
				printf("\nSUCCESS --> '%s' Found in bloom\n", check_str);
				break;
			default: /* 'Bloom check handler' function failed */
				printf("\nERROR: Bloom check handler failed. %s:%d\n", __FILE__, __LINE__);
				ret_val = ADS_ERROR_INTERNAL;
				break;
		}
	} else { /* Default implementation */
		printf("\nERROR: 'Bloom check handler' function not provided %s:%d\n", __FILE__, __LINE__);
		ret_val = ADS_ERROR_INTERNAL;
	}

	/* Release DB connection */
	release_db_connection(&dbconn);
	return ret_val;
}

/* Prints help banner */
void print_help(char *binary_name) {
	int bloom_index;
	int arg_index;
	for (bloom_index=0; bloom_index<total_bloom_filter_types; bloom_index++) {
		printf("For %s:\n\t%s <oper_id: %d> ", bloom_check_data[bloom_index].bloom_type, binary_name, bloom_index + 1);
		for (arg_index=0; arg_index<bloom_check_data[bloom_index].arg_count; arg_index++) {
			printf("<%s> ", bloom_check_data[bloom_index].arg_names[arg_index]);
		}
		printf("\n");
	}
}

int main(int argc, char *argv[]) {
	int ret_val = ADS_ERROR_SUCCESS;

	if ((1 == argc) || ((2 == argc) && (0 == (strcmp(argv[1], "-h"))))) {
		print_help(argv[0]);
		exit(0);
	}

	ret_val = init_db_env(&g_dbenv);
	if (ADS_ERROR_SUCCESS != ret_val) {
		printf("ERROR: DB Env initilization failed, %s:%d\n",__FILE__,__LINE__);
		return ret_val;
	}

	int oper_id = atoi(argv[1]) - 1;

	if (oper_id >= 0 && oper_id < total_bloom_filter_types) {
		ret_val = generic_bloom_check(oper_id, argc, argv);
	} else {
		printf("ERROR: Invalid OPER_ID passed, use -h option for help\n");
	}

	return ret_val;
}
