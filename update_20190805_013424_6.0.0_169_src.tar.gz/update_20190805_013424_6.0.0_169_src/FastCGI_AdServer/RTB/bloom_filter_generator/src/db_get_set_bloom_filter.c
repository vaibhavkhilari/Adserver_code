/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "db_connection.h"
#include "db_error.h"
#include "db_constants.h"
#include "db_rt_campaign_config.h"
#include "db_bloom_filter_generator.h"
#include "error.h"
#include "bloom_filter.h"

#define INITIAL_LIST_SIZE 20
#define MAX_ALLOWED_ELEMENT_PER_BLOOM 160000
#define MAX_BC_LIST_LIMIT (MAX_ALLOWED_ELEMENT_PER_BLOOM * MAX_ALLOWED_BLOOMS)


static int build_multi_blooms( char *list,
		int ele_count,
		BLOOM** bloom_list,
		size_t *ret_size,
		int max_element_size){
	int i=0, j=0, k=0;
	BLOOM* bloom = NULL;
	size_t memcache_obj_size = 0;
	int false_positive=0;
	int cur_ele=0;


	for( i=0; i<MAX_ALLOWED_BLOOMS && cur_ele<ele_count ;i++){
		if((bloom = bloom_create(
					((ele_count-cur_ele)>MAX_ALLOWED_ELEMENT_PER_BLOOM) ? MAX_ALLOWED_ELEMENT_PER_BLOOM:(ele_count-cur_ele), &memcache_obj_size))){
			for( j=0; j<MAX_ALLOWED_ELEMENT_PER_BLOOM && cur_ele<ele_count; j++, cur_ele++){
				//pointing k to first character of next element in list
				k = (max_element_size+1)*cur_ele;
				if(bloom_check(bloom, &list[k])){
					false_positive++;
					BLOCKLIST_DEBUG("BloomList: bloom_check,match for %s %s:%d\n", &list[k], __FILE__, __LINE__);
				}
				bloom_add(bloom, &list[k]);
				BLOCKLIST_DEBUG("BloomList: adding '%s' %s:%d\n", &list[k], __FILE__, __LINE__);
			}
			bloom_list[i]=bloom;
			ret_size[i]=memcache_obj_size;
		}else
			break;
	}
	if(i<MAX_ALLOWED_BLOOMS && cur_ele<ele_count){
		fprintf(stderr,"Error, Bloom creation failed:%d,%s\n",__LINE__,__FILE__);
		while(i>=0){
		  if(bloom_list[i]) free(bloom_list[i]);
		  bloom_list[i]=NULL;
		  ret_size[i]=0;
		  i--;
		}
		return ADS_ERROR_NOMEMORY;
	}else{
		while(i<MAX_ALLOWED_BLOOMS){
			bloom_list[i]=NULL;
			ret_size[i]=0;
			i++;
		}
		if(cur_ele < ele_count){
			fprintf(stderr,"Element Count exceeds Bloom limit:%d, elts:%d %s:%d\n",MAX_BC_LIST_LIMIT,ele_count,__FILE__,__LINE__);
		}
	}
	return ADS_ERROR_SUCCESS;
}


int get_bloom_filters(db_connection_t *dbconn,
				SQLCHAR sql_statement[],
				get_query_meta_t* query_meta,
				BLOOM** bloom_filter_list,
				size_t *ret_size,
				int *element_count) {

	/* Local variables */
	char *retvalue=NULL, *tmp_retvalue=NULL;
	int max_element_size = query_meta->max_elt_size;
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	/*SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLINTEGER s_pub_id=0;
	SQLLEN cb_s_pub_id=0;
	SQLINTEGER s_site_id=0;
	SQLLEN cb_s_site_id=0;*/

	//SQLCHAR s_domain_name[MAX_DOMAIN_NAME_LENGTH + 1]; 
	//SQLCHAR s_domain_name[BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH + 1];
	//SQLCHAR s_creative_id[MAX_DSP_CREATIVE_LEN + 1];
	SQLINTEGER s_id=0;
	SQLLEN cb_s_id=0;
	SQLCHAR s_element[max_element_size + 1];
	SQLLEN cb_s_element_len = SQL_NTS;
	SQLUBIGINT s_unsigned_big_id = 0;
	SQLLEN cb_s_unsigned_big_id = 0;

	int ret_val=ADS_ERROR_SUCCESS;
	int use_count = 0, actual_use_count = 0, is_domain = 0;
	int alloc_count = INITIAL_LIST_SIZE, index = 0;
	int i;
	(*ret_size) = 0;
	bloom_filter_list[0] = NULL;


	/*switch(bloom_type) {
		case BLOOM_BLOCKLIST_LANDING_PAGE_FILTER:
		case BLOOM_WHITELIST_LANDING_PAGE_FILTER:
			max_element_size = BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH;
			is_domain = 1;
			s_element = s_domain_name;
			break;
		case BLOOM_CREATIVE_ID_FILTER:
			max_element_size = MAX_DSP_CREATIVE_LEN;
			s_element = s_creative_id;
			break;
		default:
			fprintf(stderr, "\nERROR: Invalid bloom_filter_type:%d\n", bloom_type);
			return ADS_ERROR_SUCCESS;
	}*/

	fprintf(stderr,"\nGET_QUERY:%s\n", sql_statement);

	/* Allocate the statement handle */
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);


	/* Create a prepared statement */
	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		fprintf(stderr, "Error preparing statement:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );

		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		return ADS_ERROR_INTERNAL;
	}

	/* Bind parameters */
	/*sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );

		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		//fprintf(stderr, "%s: %d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}
	//Assigning the datacenter id to s_datacenter_id
	s_pub_id = pub_id;	

	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_s_site_id);
	if (sql_retval != SQL_SUCCESS) {
		printf("Error binding:\n");
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		// Free The SQL Statement Handle
		if (statement_handle != 0) {
			SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
		}
		//fprintf(stderr, "%s: %d\n", __FILE__, __LINE__);
		return ADS_ERROR_INTERNAL;
	}
	//Assigning the datacenter id to s_datacenter_id
	s_site_id = site_id;*/


	// Execute The SQL Statement
	sql_retval = SQLExecute(statement_handle);

	if (sql_retval == SQL_SUCCESS) {

		for (i=0; i<(int)query_meta->nSelect && i<MAX_BIND_COL; i++) {
			switch(query_meta->type[i]) {
				case SELECT_INT:
					SQLBindCol(statement_handle, i+1, SQL_C_ULONG, &s_id, 0, &cb_s_id);
					break;
				case SELECT_CHAR_DOMAIN:
					is_domain = 1;
				case SELECT_CHAR:
					SQLBindCol(statement_handle, i+1, SQL_C_CHAR, &s_element, (max_element_size+1), &cb_s_element_len);
					break;
				case SELECT_UNSIGNED_BIG:
					SQLBindCol(statement_handle, i+1, SQL_C_UBIGINT, &s_unsigned_big_id, 0, &cb_s_unsigned_big_id);
					break;
				default:
					ret_val= ADS_ERROR_INVALID_ARGS;
					goto done;
			}
		}

		SQLRowCount(statement_handle,(SQLLEN*)&alloc_count);
		//limiting it to process only limited rows
		alloc_count= (alloc_count<=0)?(INITIAL_LIST_SIZE):alloc_count;
		if(alloc_count>MAX_BC_LIST_LIMIT){
			fprintf(stderr,"WARNING:: DB entries Exceeds input Limit:ActualCount:%d, inputLimit:%d\n",alloc_count,MAX_BC_LIST_LIMIT);
			alloc_count=MAX_BC_LIST_LIMIT;
		}

		retvalue = (char *) malloc((max_element_size+1) * alloc_count);
		if (retvalue == NULL) {
			ret_val= ADS_ERROR_NOMEMORY;
			goto done;
		}
	while (sql_retval != SQL_NO_DATA) {
			sql_retval = SQLFetch(statement_handle);
			if (sql_retval != SQL_NO_DATA) {
				if(actual_use_count == alloc_count ){
					if(actual_use_count < MAX_BC_LIST_LIMIT) {
						alloc_count *= 2;
						if(alloc_count > MAX_BC_LIST_LIMIT)
							alloc_count = MAX_BC_LIST_LIMIT;
						tmp_retvalue = (char *) realloc(retvalue, (max_element_size+1) * alloc_count);
						if (tmp_retvalue == NULL) {
							ret_val = ADS_ERROR_NOMEMORY;
							goto done;
						}
						retvalue = tmp_retvalue;
					}else	{
						use_count++;
						continue;
					}
				}
				if(cb_s_element_len != SQL_NULL_DATA && cb_s_element_len != 0) {
					cb_s_element_len = (cb_s_element_len < max_element_size)? cb_s_element_len : max_element_size;
					char *actual_str_ptr = (char*)s_element;
					char *domain_punycode=NULL;
					if(is_domain) {
						if(strncmp((char*)s_element, WWW_STR, WWW_STR_LEN)==0)
							actual_str_ptr = (char*)s_element + WWW_STR_LEN;
						int rc=NO_ASC_CONVERSION;
						rc=convert_unicode_domain_to_punycode(actual_str_ptr, &domain_punycode);
						if((rc == ASC_CONVERT_SUCCESS) && (domain_punycode != NULL)){
							actual_str_ptr=domain_punycode;
						}
					}
					//pointing index to first character of next element in list
					index = (max_element_size+1)*actual_use_count;
					if (query_meta->nSelect > 1)
						snprintf(&retvalue[index], max_element_size, "%d_%s", s_id, actual_str_ptr);
					else if (SELECT_UNSIGNED_BIG == query_meta->type[0]){
						snprintf(&retvalue[index], max_element_size, "%llu", (unsigned long long)s_unsigned_big_id);
					}else{
						snprintf(&retvalue[index], max_element_size, "%s", actual_str_ptr);
					}

					retvalue[index + max_element_size]=0;
					if(NULL!= domain_punycode){
						free(domain_punycode);
						domain_punycode=NULL;
					}
					actual_use_count++;
					use_count++;
				}
			}
		}
	} else {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}

	*element_count=actual_use_count;

	ret_val = build_multi_blooms( retvalue,
			actual_use_count,
			bloom_filter_list,
			ret_size,
			max_element_size);

done:
	if (retvalue != NULL) {
		free(retvalue);
		retvalue = NULL;
	}
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	return ret_val;

}

//this function set the bloom structure in Database
//first bloom stores the information about total no. of blooms appended in last
int set_bloom_filters(db_connection_t *dbconn,
		SQLCHAR sql_statement[],
		BLOOM** bloom_filter_list,
		const long pub_id,
		const long site_id,
		const int bloom_type,
		size_t *ret_size,
		const int element_count) {
	/* Local variables */
	SQLHANDLE statement_handle = 0;
	SQLRETURN sql_retval = SQL_SUCCESS;
	/*SQLCHAR sql_statement[MAX_SQL_QUERY_STR_LEN + 1];
	SQLINTEGER s_pub_id=0;
	SQLLEN cb_s_pub_id=0;
	SQLINTEGER s_site_id=0;
	SQLLEN cb_s_site_id=0;
	SQLINTEGER s_element_count=0;
	SQLLEN cb_s_element_count=0;*/
	SQLCHAR *s_bit_array=NULL;
	SQLLEN cb_s_bit_array = 0; //BIT_ARRAY_SIZE_BYTES(bloom_filter_list->bit_array_size);

	int ret_val=ADS_ERROR_SUCCESS;

	if(bloom_filter_list == NULL || *bloom_filter_list== NULL) {
		fprintf(stderr,"INFO : No i/p BLOOM for pub_id:%ld site_id:%ld, %s:%d\n",pub_id,site_id,__FILE__,__LINE__);
		goto done;
	}

	int cur_bloom=0;
	//get the serialized bloom data in in one buffer.medium_bloom supports upto 16MB
	while( MAX_ALLOWED_BLOOMS>cur_bloom 
			&& bloom_filter_list[cur_bloom] != NULL 
			&& bloom_filter_list[cur_bloom]->nelements>0){
		cb_s_bit_array+= ret_size[cur_bloom];
		cur_bloom++;
	}
	s_bit_array=(SQLCHAR*)malloc(sizeof(char)*cb_s_bit_array);
	if(NULL== s_bit_array){
		ret_val=ADS_ERROR_NOMEMORY;
		goto done;
	}
	cur_bloom=0;
	size_t cur_pos=0;
	while( MAX_ALLOWED_BLOOMS>cur_bloom
			 && bloom_filter_list[cur_bloom]!= NULL
			 && bloom_filter_list[cur_bloom]->nelements>0){
		memcpy(s_bit_array+cur_pos, bloom_filter_list[cur_bloom],	ret_size[cur_bloom]);
		cur_pos+=ret_size[cur_bloom];
		cur_bloom++;
		//copy data in buffer
	}

	fprintf(stderr,"\nSET_QUERY:%s\n", sql_statement);
	
	SQLAllocHandle(SQL_HANDLE_STMT, dbconn->con_handle, &statement_handle);
	//strncpy((char *) sql_statement, db_query, MAX_SQL_QUERY_STR_LEN );
	//sql_statement[MAX_SQL_QUERY_STR_LEN] = '\0';

	sql_retval = SQLPrepare(statement_handle, sql_statement, SQL_NTS);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}

	/*sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_pub_id, 0, &cb_s_pub_id);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}
	s_pub_id = pub_id;	

	sql_retval = SQLBindParameter(statement_handle, 2, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_site_id, 0, &cb_s_site_id);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}
	s_site_id = site_id;*/


	sql_retval = SQLBindParameter(statement_handle, 1, SQL_PARAM_INPUT, SQL_C_BINARY,
			SQL_LONGVARBINARY, cb_s_bit_array, 0, 
			(unsigned char*)s_bit_array, 0, &cb_s_bit_array);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}//data already copied

	/*sql_retval = SQLBindParameter(statement_handle, 4, SQL_PARAM_INPUT, SQL_C_ULONG,
			SQL_INTEGER, 0, 0, &s_element_count, 0, &cb_s_element_count);
	if (sql_retval != SQL_SUCCESS) {
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle, sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}
	s_element_count=element_count;*/

	sql_retval = SQLExecute(statement_handle);
	if (sql_retval == SQL_SUCCESS) {
		fprintf(stderr, "\nBloomInsertSuccess:: OPCODE:%d : pub:%ld, site:%ld, elt_count:%d bloom_count:%d stored_bit_array_size_bytes:%d, %s:%d\n", bloom_type, pub_id, site_id, element_count, cur_bloom, (int)cb_s_bit_array, __FILE__, __LINE__);
	} 
	else {
		fprintf(stderr, "\nBloomInsertFailed:: OPCODE:%d : pub:%ld, site:%ld, elt_count:%d stored_bit_array_size_bytes:%d, %s:%d\n", bloom_type, pub_id, site_id, element_count, (int)cb_s_bit_array, __FILE__, __LINE__);
		db_conn_print_error((SQLSMALLINT)SQL_HANDLE_STMT,statement_handle,
				sql_retval,__LINE__,__FILE__ );
		ret_val= ADS_ERROR_INTERNAL;
		goto done;
	}

done:
	if (statement_handle != 0) {
		SQLFreeHandle(SQL_HANDLE_STMT, statement_handle);
	}
	if(NULL != s_bit_array)
		free(s_bit_array);

	return ret_val;
}
