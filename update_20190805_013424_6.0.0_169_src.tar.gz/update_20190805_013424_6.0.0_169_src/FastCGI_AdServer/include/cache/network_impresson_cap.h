/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __CACHE_NETWORK_IMPRESSON_CAP_H__
#define __CACHE_NETWORK_IMPRESSON_CAP_H__


/* this function gives list of eliminated network due to reaching impression cap on it,
Network list returned from this function should be released on complete use of it */
void get_network_impression_cap_elimination_list(network_elimination_list_t *elimination_list,
						int thread_id,
						cache_handle_t *cache);


/* this function adds new network_id in existing elimination list */
int add_network_into_impression_cap_elimination_list(int to_eliminate_network_id, 
						int thread_id,
						cache_handle_t *cache);

int remove_adnetwork_from_elimination_list(int remove_network_id,
                    int thread_id,
                    cache_handle_t *cache);

/* get the network impression cap settings from cache */
int cache_get_network_impression_capping(network_impression_cap_t **network_impression_caps,
		int *nelements,
		cache_handle_t *cache,
		db_connection_t *dbconn) ;

/* get the current network impression cap settings from cache */
int cache_get_current_network_impression_capping(network_impression_cap_t *network_impression_caps,
		int adserver_id,
		cache_handle_t *cache,
		db_connection_t *dbconn);

/* get the total of served impressions  */
int cache_get_network_impression_total(network_impression_total_t *network_impression_total,
		cache_handle_t *cache,
		db_connection_t *dbconn,
		unsigned long adserver_id);

int cache_get_network_impressions_estimate_change_flag(unsigned long *impre_estimate_flag, unsigned long adserver_id, unsigned long thread_id, cache_handle_t *cache);

/* this will set reestimate flag for all the thread which is signal for reestimate the impressions to serve */
int cache_set_network_impressions_estimate_change_flag(unsigned long impre_estimate_flag, unsigned long adserver_id, unsigned long thread_id, cache_handle_t *cache);

/* this fuction gives the number of impression to serve for a thread and campaign */
int cache_get_network_impressions_to_serve(unsigned long *impression_to_serve, unsigned long adserver_id, unsigned long thread_id, cache_handle_t *cache);

/* set to serve impression count */
int cache_set_network_impressions_to_serve(unsigned long total_impresssions_to_serve, unsigned long adserver_id, unsigned long thread_id, cache_handle_t *cache);

/* this will set budget completion time which will be used while reestimating the impressions */
int cache_set_network_estiamte_completion_time(long adserver_id, long thread_id, cache_handle_t *cache);

void cache_set_network_no_estimate_to_serve(unsigned long adserver_id, int least_thread_number, int top_thread_number, cache_handle_t *cache);

int cache_set_pacing_network_impression_toserver(unsigned long adserver_id,
            unsigned long network_impression_toserver, cache_handle_t *cache);

int cache_get_pacing_network_impression_toserver(unsigned long adserver_id,
        cache_handle_t *cache, unsigned long *network_impression_toserve);


int cache_get_network_dc_impression_total(datacenter_daily_impression_total_t *datacenter_daily_impression_total,
		cache_handle_t *cache, 	db_connection_t *dbconn, unsigned long adserver_id);


int cache_set_network_dc_impression_total(datacenter_daily_impression_total_t *datacenter_daily_impression_total,
		cache_handle_t *cache,
		unsigned long adserver_id);

#endif /* __CACHE_NETWORK_IMPRESSON_CAP_H__ */
