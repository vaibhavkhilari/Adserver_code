
#ifndef CACHE_CROSS_DEVICE_PARAMETER_CACHA_H
#define CACHE_CROSS_DEVICE_PARAMETER_CACHA_H
#include "cache_types.h"
#include "db_connection.h"
#include "rt_types.h"
#include "adserver_control_parameter_cache.h"

int cache_get_cross_device_vendor_list( cache_handle_t *cache_handle, db_connection_t *dbconn, cross_device_vendor_list_t *cross_device_vendor_list, int thread_id);

int populate_cross_device_vendor_list(cross_device_vendor_list_t *cross_device_vendor_list, char *cross_device_vendor_list_val);
#endif 
