/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef _INPC_ITEM_
#define _INPC_ITEM_

#define DEFAULT_MIN_ITEM_SIZE 8
#define DEFAULT_MAX_ITEM_SIZE (1<<20)
#define DEFAULT_PAGE_SIZE 1<<20
#define DEFAULT_ITEM_SIZE_GROW_FACTOR 1.25
#define INPC_MAX_KEY_SIZE 255
#define KEY_MARGIN 8

#define ITEM_UPDATE 1
#define ITEM_ADD 2

/** MAX_REFRESH_TIME
 *
 * Maximum time that a refresh (on expiry) operation is assumed to take
 * (in seconds)
 */
#define MAX_REFRESH_TIME 60

#define initialize_item(current, nxt, slab_id, item_size) {((mem_item_t*)current)->next = (mem_item_t*)nxt; ((mem_item_t*)current)->slab_id = slab_id; \
							((mem_item_t*)current)->lru_next = NULL; ((mem_item_t*)current)->lru_prev = NULL;}
#define should_page_be_allocated(slab_id) ((slabs.list[slab_id].free_item)_count == 0)
#define get_aligned_item_meta_size() (eight_byte_align(sizeof(mem_item_t)) + eight_byte_align(sizeof(unsigned long long)))
#define get_key(it) ((char*)((char*)it + (eight_byte_align(sizeof(mem_item_t)))))
#define get_value_ptr(it) (get_key(it) + (eight_byte_align(it->key_len)) + sizeof(unsigned long long)) //last 8 for refcount and flags.
#define get_expiry(cur) (cur->expiry)
#define get_value_length(cur) (cur->value_length)
#define increase_item_refcount(cur, count) (cur->ref_count += count)
#define get_refcount(it) (it->ref_count)

#define ITEM_CLAIMABLE 1
//#define ITEM_DELETED 2
#define ITEM_ACCESSED 4

#define get_ref_count_ptr(it) ((uint32_t*)(get_key(it)+eight_byte_align(it->key_len)))
#define get_flags_ptr(it) (get_ref_count_ptr(it) + 1)

#ifdef DEBUG_INPC_REFERENCE
#define INPC_REFERENCE_DEBUG(format, ...) fprintf(stderr, format, ##__VA_ARGS__)
#else
#define INPC_REFERENCE_DEBUG(format, ...)
#endif /* DEBUG_INPC_REFERENCE */

typedef struct {
	uint32_t min_item_size;
	uint32_t page_size;
	uint32_t actual_page_size;
	uint32_t max_item_size;
	float item_size_grow_factor;
}item_properties_t;

typedef struct mem_item {
	uint32_t expiry; 
	uint32_t value_length; 
	uint32_t lru_change_time;
	uint8_t key_len;
	uint8_t slab_id;
	uint8_t flags;
	uint8_t filler;
	struct mem_item* next;   
	struct mem_item* lru_next;
	struct mem_item* lru_prev;
}mem_item_t;

#endif
