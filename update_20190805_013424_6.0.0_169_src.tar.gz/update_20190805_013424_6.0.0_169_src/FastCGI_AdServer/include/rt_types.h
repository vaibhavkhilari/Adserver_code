/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __RT_TYPES_H__
#define __RT_TYPES_H__
#include <unistd.h>
#include <stdlib.h>
#include <curl/curl.h>
#include <ad_server_types.h>
#include <pthread.h>
#include "fte_types.h"
#include "fte_context_cache.h"
#include "../RTB/include/db/db_url_blocklist.h"
#include "dp_data_passing_generic.h"
#include "deal.h"
//#include "cookie_store_types.h"
#include "server_side_cookie_store.h"
//~suraj::PMB
#include "price_encryption.h"
#include "video.h"
#include "win_loss_notification.h"
#include "currency_conversion.h"
#include "impr.h"
#include "../FTE/include/ftealgos/bid_price_caching.h"
#include "mbf.h"
#include "pm_json.h"
//BIDDER REQUEST RESPONSE related Constants
#define MAX_NO_OF_BIDDER_CLUSTERS 4
#define MAX_NO_OF_DSP_PER_CLUSTER 20
#define MAX_BIDDER_RESPONSE_BUFFER_SIZE ((MAX_RESPONSE_BUFFER_SIZE + 12) * MAX_NO_OF_DSP_PER_CLUSTER)


#define MAX_USER_AGENT_SIZE 	32
#define MAX_TIME_ZONE_SIZE	64
#define MAX_IP_ADDRESS_SIZE	16
#define MAX_CATAGORY_SIZE	128
#define MAX_URL_SIZE		4096 //2048*2 i18
#define MAX_RTB_URL_SIZE	511
#define MAX_BIDDER_CLUSTER_URL_SIZE	63
#define MAX_CURRENCY_SIZE	6
#define MAX_COOKIE_SIZE		4096
#define MAX_RT_COOKIE_SIZE	4096
//#define MAX_TMP_BUFFER_SIZE     2048
#define MAX_ADTAG_SIZE		4096
#define MAX_SITE_URL_SIZE (512 + 1)
#define MAX_REF_URL_SIZE  1536 //512*3 i18
#define MAX_LANGUAGE_SIZE 64 
#define MAX_DOMAIN_NAME_LENGTH 768 //256*3
#define ADVERTISER_DOMAIN_TRUNCATED_DOMAIN_NAME_LENGTH 6 
#define BLOCKWHITE_LIST_TRUNCATED_DOMAIN_NAME_LENGTH 127
#define MAX_BLACKWHITE_LIST_APPURL_LENGTH 255
#define MAX_GEO_COUNTRY_CODE_LEN 10
#define TLD_WHITELIST_TRUNCATED_DOMAIN_NAME_LENGTH 3
#define FLOOR_RULE_TRUNCATED_DOMAIN_NAME_LENGTH    140
#define GLOBALBLOCKLIST_TRUNCATED_DOMAIN_NAME_LENGTH 140 
#define MAX_RULE_ID_LENGTH 20
#define MAX_DSP_CREATIVE_LEN 127 //maximum size of dsp_id and creative_id concatination...
#define MAX_DAA_OPTOUT_DEVICEID_LEN 41 //maximum size of {deviceid:40} + '\0' string...
#define MAX_UCRID_CREATIVE_LEN 25 // Maximum size of ucrid which is long long 
#define LONG_INT_DATA_LEN 10
#define MAX_SITEID_LEN 10 // Maximum Size for site id
#define MAX_DSP_PUB_CAMP_BLK_BLOOM_QUERY_SIZE 512 // Change Length When Query GET_DSP_PUB_CAMPAIGN_BLOCKLIST_BLOOM changes.

#define INVALID_TYPE (-1)
#define HTML_URL_TYPE 0
#define JS_URL_TYPE 1
#define CREATIVE_TAG_TYPE 2
#define VIDEO_CREATIVE_TAG_TYPE 3
#define XHTML_TYPE 5
#define NATIVE_CREATIVE_TYPE 6

#define FLOOR_TYPE_PUBLISHER_DYNAMIC_FLOOR  0
#define FLOOR_TYPE_USER_BASED_FLOOR         1
// Error code definition
#define RTB_SUCCESS 0
#define RTB_ERROR -1

/*Max MD5 Size*/
#define MAX_MD5_SIZE 33
//fold position def
#define MIN_FOLD_POS_VALUE 0
#define MAX_FOLD_POS_VALUE 3

//Below mentioned macros define max number of advertiser and dsp advertiser floors. 
//These values are related to limit mentioned in query in files db_publisher_site_advertiser_floor.c and db_publisher_site_dsp_advertiser_floor.c
#define RTB_MAX_ADVERTISER_FLOOR 100
#define RTB_MAX_DSP_ADVERTISER_FLOOR 100

#define MARK_UNINITIALIZED -1
#define DEFAULT_DSP_BUYER_ID 0

//Use of algo encryption/decryoption of bid_price/second_price
#define RTB_BID_PRICE_ENCRYPTION 0
#define RTB_SECOND_PRICE_ENCRYPTION 1

//increment count for response buffer from dsp
#define RESPONSE_BUFFER_INCREMENT_COUNT 5
//increment count for rt response array
#define RT_RESPONSE_INCREMENT_COUNT 5

//Maximum character to check in response buffer for '{'
#define MAX_CHARACTER_TO_CHECK  1

#define MAX_SITE_NAME_LEN 256

//rt_handle per-ad request handle for making curl multi requess

//type of RTB request-response protocol being used
#define PUBMATIC_RTB 0
#define OPENRTB 1
#define OPENRTB2_3 2
#define OPENRTB2_5 3
#define OPENRTB3_0 4

#define MAX_URLCAT_DATA_SIZE 255
#define MAX_BSC_SIZE	     255

#define ALPHA2_LEN	2

// Prebid fraud check
#define MAX_PREDICTION_ID_LEN 40 // e.g '66b9cede-0cff-4860-646f-20aa03f8afb2'
#define MAX_PREDICTION_RESULT_LEN 6  //'true' or 'false'
#define MAX_HTTP_RESP_CODE_LEN 100
#define MAX_CACHE_STATUS_LEN 5

// Native resp params specific 
#define MAX_NTV_TITLE_LEN 256
#define MAX_NTV_TEXT_LEN 1024
#define MAX_NTV_ICON_IMAGE_LEN 8192
#define MAX_NTV_MAIN_IMAGE_LEN 8192
#define MAX_NTV_CTATEXT_LEN 512
#define MAX_NTV_CLICK_LEN 8192
#define MAX_NTV_IMP_TRACK_LEN 8192
#define MAX_NTV_CLICK_TRACK_LEN 8192

#define MAX_AUDIENCE_IDS_IN_BID_REQ 5

//header to be sent to dmux about max time for which adserver can wait for response from DSP
#define REQ_ADSERVER_TIMEOUT_HEADER_TEMPLATE "X-adstimeout: %d"
/*
 * Control checks : mux_control_bitmap / multi_adsz_control_bitmap
 * 0 = NO CONTROL, mux/multi ad size RTB will be done as per the count set. (BitMap: 000)
 * 1 = MUX/MULTI_ADSIZE_ONLY_IF_USER_SYNCED (BitMap: 001)
 * 2 = MUX/MULTI_ADSIZE_ONLY_IF_DEVICE_ID (BitMap: 010)
 * 3 = MUX/MULTI_ADSIZE_IF_USER_SYNCED_AND_DEVICE_ID (BitMap: 011)
 * 4 = MUX/MULTI_ADSIZE_ONLY_IF_LAT_LONG (BitMap: 100)
 * 5 = MUX/MULTI_ADSIZE_IF_USER_SYNCED_AND_LAT_LONG (BitMap: 101)
 * 6 = MUX/MULTI_ADSIZE_IF_DEVICE_ID_AND_LAT_LONG (BitMap: 110)
 * 7 = MUX/MULTI_ADSIZE_IF_USER_SYNCED_AND_DEVICE_ID_AND_LAT_LONG (BitMap: 111)
 */
enum MB_CONTROL_FLAG {
	NO_CONTROL = 0,
	IS_COOKIED_USER = 1,
	HAS_DEVICE_ID = 2,
	HAS_LAT_LONG = 4,
	HAS_PM_UID = 8
};
//Below enum is to know what type of error was given by DSP behind flexidrporxy 
typedef enum flexidrproxy_dsp_status{
	FLEXIDRPROXY_DSP_UNKNOWN            = -1, //flexidrpoxy status unknown mostly it will happen if it doesn't go through drproxy
	FLEXIDRPROXY_DSP_OK                 = 0,  //DSP return within given time
	FLEXIDRPROXY_DSP_TIMEDOUT           = 1,  //DSP have timedout but flexidrpoxy return within given time
	FLEXIDRPROXY_DSP_MAX_ROUTINEREACHED = 2,  //DSP call was not made as max routine for given DSP reached
	FLEXIDRPROXY_DSP_ERROR              = 3   //DSp returned some error
}flexidrproxy_dsp_status_t;
#define IS_MUX_ENABLED_CAMPAIGN(TMP_MASK, DPSC_SETTINGS, CMP_COOKIE, IS_MOB, ADS_REQ, PM_UID) \
	((DPSC_SETTINGS) != NULL && \
	 (DPSC_SETTINGS)->one_adsz_mux_count > 0 && \
	 (TMP_MASK)->send_winloss_info == 0 && \
	 ((DPSC_SETTINGS)->mux_control_bitmap == \
		((((CMP_COOKIE)[0] != '\0') * ((DPSC_SETTINGS)->mux_control_bitmap & IS_COOKIED_USER)) + \
		 (((IS_MOB) && (ADS_REQ)->platform_specific_id[0] != '\0') * ((DPSC_SETTINGS)->mux_control_bitmap & HAS_DEVICE_ID)) + \
		 (((IS_MOB) && (ADS_REQ)->mobile_device_location[0] != '\0') * ((DPSC_SETTINGS)->mux_control_bitmap & HAS_LAT_LONG)) + \
		 ((PM_UID[0] != '\0') * ((DPSC_SETTINGS)->mux_control_bitmap & HAS_PM_UID)))))

#define IS_MULTI_ADSIZE_ENABLED_CAMPAIGN(TMP_MASK, DPSC_SETTINGS, CMP_COOKIE, \
		ADDITIONLA_PARAMS, MULTI_ADSIZE_COUNT, IS_MOB, ADS_REQ, PM_UID) \
((ADDITIONLA_PARAMS)->multi_adsize_disabled != 1 && \
 (MULTI_ADSIZE_COUNT) > 1 && \
 (DPSC_SETTINGS) != NULL && \
 (DPSC_SETTINGS)->multi_adsz_mux_count > 0 && \
 (TMP_MASK)->send_winloss_info == 0 && \
 ((DPSC_SETTINGS)->multi_adsz_control_bitmap == \
	((((CMP_COOKIE)[0] != '\0') * ((DPSC_SETTINGS)->multi_adsz_control_bitmap & IS_COOKIED_USER)) + \
	 (((IS_MOB) && (ADS_REQ)->platform_specific_id[0] != '\0') * ((DPSC_SETTINGS)->multi_adsz_control_bitmap & HAS_DEVICE_ID)) + \
	 (((IS_MOB) && (ADS_REQ)->mobile_device_location[0] != '\0') * ((DPSC_SETTINGS)->multi_adsz_control_bitmap & HAS_LAT_LONG)) + \
	 ((PM_UID[0] != '\0') * ((DPSC_SETTINGS)->multi_adsz_control_bitmap & HAS_PM_UID)))))

typedef struct rt_request_url_params_mask{
	//sagar
	char cluster_lb_url[MAX_BIDDER_CLUSTER_URL_SIZE + 1];
	int dsp_config_id;
	int bidder_cluster_id;
	int bidder_enabled;
	//~sagar
	char ad_nw_url[MAX_RTB_URL_SIZE + 1]; // realtime campaign URL
	char clicktrack_keyword[MAX_RTB_CLICKTRACK_KEYWORD_LEN + 1];  //clicktrack keyword
	int pub_url; //masks which indicate the respective field to be send or not
	int timezone;
	int user_ip;
	int catagory;
	//int keyword;
	int ref_url;
	int user_id;
	int cookie;
	int browser;
	int language;
	int screen_resolution;
	int ad_position;
	int frequency;
	int adtagtype;
	long campaign_id; // campaign id for internal processing
	int second_price_auction; //second price auction flag
	char second_price_macro[MAX_SECOND_PRICE_MACRO_SIZE + 1]; //second price macro 
	double second_price_margin;
	double minimum_clearing_price_margin;
	int adid;
	int use_in_iframe;
	int pubId;
	int siteId;
	int fold_position;
	int use_pmoptout;
	int use_creative_attributes ;
	int use_creative_categories ;
	int use_url_blocklist;
	// 0 ---> send defaulted impression, 1 ---> don't send defaulted impression
	int use_pmp_enabled;
	int use_secure_params;
	int use_mobile_params;
	int use_geo_params;
  int use_price_floor;
  int use_vertical_id;
  //int use_coppa_signalling;
  int bid_price_encryption_enabled;
  int second_price_encryption_enabled;
	int click_tracking_url_encoding_enabled;
	int pass_blank_click_tracking_url;
	int filter_defaulted_request;
	int filter_non_cookied_request;
	int filter_cookied_request;
	int use_rich_media_params;
	int skip_user_floor;
	int apply_normal_distribution;
	// Set to 1, when Deal id need to be pass for given campaign.
	int deal_id_passing_enable_flag;
	// Set to 1, when Buyer id need to pass for given campaign
	int buyer_id_passing_enable_flag;
	int supress_second_price_auction_on_same_campaign;
	int is_multibid; //if 1 dsp support multibid and if 0 dsp does not send multibid
	int send_secure_inventory;// Flag to indicate if dsp suppporting secure inventory or not
	int use_adtruth_id; // adtruth id
	int send_video_params; /* flag to indicate whethet dsp is video compatible */
	int send_winloss_info; //if set to 1, send win-loss info in next bid request
	int protocol;	//RTB protocol used. PubMatic RTB=0, OPENRTB = 1
	int supports_native_ad_format; /* flag to indicate whethet dsp is native compatible */
	int enabled_ias_services; //Bitmap for IAS services, bit 1: page cat, 2: brand safety
	int share_cookies_of; //Share cookies of this campaign if not found for original campaign
	int use_drproxy;

	/* use_gopro specifies whether we should use GoPro.
	 * This is NOT a DB attribute.  It is derived.
	 */
	int use_gopro;
	int send_hardfloor;
	int use_audio_params; /* flag to indicate whether dsp is audio compatible */
	int send_is_dspuid_inferred; //This flag is for DSP to inform that this uid is inferred one.

	// Throttle traffic to camp to keep it below ``campaign_throttle_percent``.
	double campaign_throttle_percent;
	// pixel_id: Id of pixel mapped to the campaign.
	long pixel_id;
	int server_side_cookie_expiry; // force server side cookie expiry to this value - minutes
	int att_bitmap; // 0 -> disabled, 1-> enabled, 2-> disabled for cookied user
	int max_multi_requests; //Count of maximum requests that can be made to DSP at a time.
	unsigned long feature_flag_bitmap; //Bitmap to store enabled/disabled status of multiple features at campaign level
	uint8_t bidrequest_compress ; //flag to indicate request compression 0 => disabled 1 => enabled
	uint8_t bidresponse_compress ; //flag to indicate response compression 0 => disabled 1 => enabled
	int video_placement_percent;//if 0 placement will not be send if 100 placement will be sent for all
	int send_publisher_name;//1-send publisher.company name as publisher name to DSP in request else no
	int digitrust_retargeting_enabled; //use this in conjunction with filter_non_cookied_request/filter_cookied_request. If set to 1 then make RTB call only when EITHER (filter_non_cookied_request=1 AND (dsp_uid is available OR digitrust id is available&enabled)) OR (filter_cookied_request=1 AND (dsp_uid is NOT available OR digitrust id is available&enabled))
	int remove_cookie_prefix_uid; // If enabled and DSP userid is like "uid:ABC-XXX" then userid sent to DSP will be "ABC-XXX" 
	uint32_t audience_dpids_in_bid_req[MAX_AUDIENCE_IDS_IN_BID_REQ] ;///data provider ids whose audience segments are to be sent to the DSP
	uint32_t audience_dpids_in_bid_req_count ;
}rt_request_url_params_mask_t;

/*
 * enum to keep bit positions corresponds to binary
 * valued columns from realtime_api_config table
 * NOTE: This avoids unncessary variable creation in
 * rt_request_url_params_mask_t.feature_flag_bitmap strucure variable
 */
typedef enum {
	CS_BIT_POS_RTB_PASS_GRANULAR_SITE_ID = 0,
	CS_BIT_POS_RTB_CHANGE_NATIVE_IMAGE_TYPE,
	CS_BIT_POS_RTB_REMOVE_COOKIE_PREFIX_UID,
	CS_BIT_POS_RTB_TRUNCATE_REFURL_IF_NONUTF8
} campaign_setting_flags_t;

typedef struct site_camp_sp_margin_map {
	int site_id;
	int campaign_id;
	double second_price_margin;
}site_camp_sp_margin_map_t;

typedef struct rt_request_url_params {
	char timezone[MAX_TIME_ZONE_SIZE + 1]; //Timezone 
	char catagory_list[(MAX_LUCID_CATEGORIES * (LUCID_CATEGORY_LEN + 1)) + MAX_LUCID_CATEGORIES + 1];
	char cookie[MAX_COOKIE_SIZE + 1];
	char  request_id[MAX_MUX_REQ_PER_CAM][MAX_UNIQUE_ID_LEN + 1]; //unique Id per rtb-request per camapign for single ad-request
	int max_rt_batch_count; //max rtb calls made to single dsp for sinle impression
}rt_request_url_params_t;

//TODO make it advertiser_category_id
typedef struct advertiser_category_id {
	int *list;
	int count;
}advertiser_category_id_t; 

/* OLD Native Protocol Implementation */
typedef struct native_response_params {
	char title[MAX_NTV_TITLE_LEN + 1];
	char text[MAX_NTV_TEXT_LEN + 1];
	char iconImg[MAX_NTV_ICON_IMAGE_LEN + 1];
	char mainImg[MAX_NTV_MAIN_IMAGE_LEN + 1];
	char ctatext[MAX_NTV_CTATEXT_LEN + 1];
	double rating;
	char clickUrl[MAX_NTV_CLICK_LEN + 1];
	char impTracker[MAX_NTV_IMP_TRACK_LEN + 1];
	char clickTracker[MAX_NTV_CLICK_TRACK_LEN + 1];
	int is_valid_native_response;
} native_response_params_t;


typedef struct rt_bid_response_params {
	char str_bid_id[MAX_BID_ID_LEN + 1];
	char request_url[MAX_REQUEST_URL_SIZE+ 1];
	char transaction_id[MAX_TRANSACTION_ID_SIZE + 1];
	char  request_id[MAX_UNIQUE_ID_LEN + 1];
  char ebid[WEB_SAFE_B64_ENCRYPTED_TEXT_SIZE + 5]; // ebid represent encrypted bid, which will be decoded n stored in ecpm only. 

  // url response can be of one type
  union {
	char js_url[MAX_RESPONSE_URL_SIZE + 1];
	char html_url[MAX_RESPONSE_URL_SIZE + 1];
 	char creative_tag[MAX_CREATIVE_TAG_SIZE + 1];
	char video_creative_tag[MAX_VIDEO_CREATIVE_TAG_LEN+1];
	char admarkup[MAX_CREATIVE_TAG_SIZE +1];
	char native_creative_json[MAX_NATIVE_CREATIVE_LEN + 1];
  }u_url;

	char cookie[MAX_COOKIE_SIZE + 1]; // change size & name of MAX_COOKIE_SIZE
	char clicktrack_keyword[MAX_RTB_CLICKTRACK_KEYWORD_LEN + 1];
	char second_price_macro[MAX_SECOND_PRICE_MACRO_SIZE + 1]; //second price macro
	char landing_page_url[MAX_RESPONSE_URL_SIZE + 1];
	char landing_page_tld[MAX_DOMAIN_NAME_LENGTH + 1];
	char creative_id[MAX_CREATIVE_ID_SIZE + 1];
	int creative_type;
	unsigned long long crc64_uniq_creative_id;
	char pub_deal_id[MAX_DEAL_ID_LEN + 1];
	char iurl[MAX_IURL_SIZE + 1];
	char dsp_campaign_id[MAX_DSP_CAMPAIGN_ID_LEN + 1];
	char rich_media_tech_name[MAX_RICH_MEDIA_TECH_ID_LEN + 1];
	char viewabilityvendors[MAX_VIEWABILITYVENDORS_LEN + 1];
	int creative_len;
	int type;
	int video_response_type;
	int bid_id;
	double ecpm;
	int req_processed;
	int response_buffer_length;
	char *response_buffer;
	int response_buffer_alloc_count;
	int response_complete;
	int landing_page_flag;
	int advertiser_id;
	int domain_id;
	int pubmatic_buyer_id;
	int dsp_buyer_id;
	int pubmatic_dsp_buyer_id;
	//char str_dsp_buyer_id[MAX_DSP_BUYER_ID_LEN + 1];
	int rich_media_ad_creative_attribute_id;
	//int rich_media_tech_id;
	advertiser_category_id_t advertiser_category_id;

	int http_response_code; //store response code from response header
	struct timeval  stamp_after_api_call;
	int dsp_selected_pc_campaign_id;
	uint8_t gzipped ;
	flexidrproxy_dsp_status_t flexidrproxy_dsp_status_code;// status code of DSP in case flexidrproxy is used default value will be -1 (unknown)
	
/* OLD Native Protocol Implementation
	native_response_params_t native_resp_params;
*/
}rt_bid_response_params_t;

typedef struct rt_response_params {
	long campaign_id;
	int campaign_index;
	int dp_id;
	int dsp_user_match_found;
	int digitrust_id_present;
	int skip_user_floor;
	int apply_normal_distribution;
	int bid_price_encryption_enabled;
	int second_price_encryption_enabled;
	int click_tracking_url_encoding_enabled;
	int pass_blank_click_tracking_url;
	bool is_multibid; // if true it is multi bid else single bid
	int child_index; // If dsp is sending multibid then child index will point to 2nd bid by dsp
	int supress_second_price_auction_on_same_campaign;
	int send_winloss_info; //if set to 1, send win-loss info in next bid request
	int protocol;   //RTB protocol used. PubMatic RTB=0, OPENRTB = 1
	int currency_id;
	int skip_UCAF; //if creative id is approved/whitelisted then skip Uncategorized Advertiser Filter
	int deal_no_bid_reason;
	int enabled_ias_services;
	rt_bid_response_params_t bid_response_params;
	int buyer_id_passing_enable_flag;
	int rt_req_id_index; //index of request id : rt_request_params->rt_request_url_params->request_id 
	int parent_index; //sore the index of base campaign object
	adsize_t* ad_dimensions_from_tag; //id,dimensions of ad-size being passed in RTB request
	int log_full_user_id; //Log full uid in logger json is its set to 1
	int open_auction_type; // auction type of open/non-pmp bid, 1=first price 2=second price
	int log_qps_logger;
}rt_response_params_t;

//Structure to store custom params related to RTB
typedef struct rt_custom_params {
	char *maxmind_country_code;				//alpha3 code
	char *publisher_country_code; 		//alpha3 code
	char alpha2_lang[ALPHA2_LEN + 1];	//alpha2 language parameter
	int utcoffset;										//offset from GMT in minutes
	char truncated_ip[MAX_IPSTR_LEN + 1];
	int int_con_type;
	char truncated_xff[MAX_LEN_XFF+1];
}rt_custom_params_t;


typedef struct rt_campaign_encryption_algo_details {
	long campaign_id;
  // identify which algo to be used for encryption/decryption. currently only HMAC_SHA256.
	char algorithm_name[MAX_ENCRYPTION_ALGO_NAME_LENGTH + 1]; 
  // key used for encryption/decryption.
  char encryption_key[MAX_ENCRYPTION_KEY_LENGTH + 1];
  // key used for authenticating data
  char integrity_key[MAX_INTEGRITY_KEY_LENGTH + 1];
}rt_campaign_encryption_algo_details_t;

typedef struct encoded_request_params{
	char encoded_ref_url[MAX_REF_URL_SIZE + 1];
	char encoded_catagory[MAX_CATAGORY_SIZE + 1];
	char encoded_language[MAX_LANGUAGE_SIZE + 1];
	char encoded_browser[MAX_BROWSER_NAME_LEN + 1];
}encoded_request_params_t;

/* structure for audience related parameters */
typedef struct audience_params{

	CURL *audience_curl_handle;
	void *user_segment_list_info;

}audience_params_t;



typedef struct integral_settings {
	int campaign_id;
	//long pub_id ;
	int enabled_ias_services;
	long int score_field;   // taken from DB
}integral_settings_t;


typedef struct bid_boost_settings {
        int campaign_id;
        //long pub_id ;
        double bid_boost_factor;
	int  disable_pubmatic_cut;
}bid_boost_settings_t;



typedef struct db_integral_settings {
	int campaign_id;
	long pub_id ;
	int enabled_send_pcat_service ; 
	int enabled_send_bsc_score_service ; 
	int enabled_bsc_filtering ;
	int bsc_score_field ; 
	int enabled_sam_filtering ; 
	int sam_score_field ;
}db_integral_settings_t;

#define MAX_ALLOWED_LEVELS 2

typedef struct integral_data {
	integral_settings_t *integral_settings;
	size_t number_of_settings;
        char page_categories[MAX_URLCAT_DATA_SIZE + 1];
	int page_cat_len;
	char brand_safety_score[MAX_BSC_SIZE + 1];
	int bsc_len;
	int fraud_level;
	int bsc_level;
	long int logger_score_field;  // pushed to logger
	varnish_stats_t *varnish_stats;
	int backend_server_id;	//Varnish server to which call for current page url will be made
	int cache_miss;
}integral_data_t;

typedef enum ads_txt_pub_auth_status_type{
	AUTH_CHECK_NOT_DONE = -1,
	NOT_AUTHORIZED = 0, /* Not authorized, publisher entry not present in ADS.TXT */
	DEFAULT_AUTHORIZED, /* Either publisher entry present in ADS.TXT, or domain doesn't have ADS.TXT */
	AUTHORIZED_RESELLER, /* publisher entry present in ADS.TXT as RESELLER */
	AUTHORIZED_DIRECT, /* publisher entry present in ADS.TXT as DIRECT */
	/* Add new ADS.TXT auth status type above this line */
	MAX_ADS_AUTH_STATUS_VAL
}ads_txt_pub_auth_status_type_t;

typedef enum fraud_check_status_type{
	REQ_NOT_MADE,
	REQ_TIMED_OUT,
	REQ_IS_FRAUD,
	REQ_IS_NOT_FRAUD,
	REQ_PARSE_ERR,
	REQ_SKIPPED
}fraud_check_status_type_t;

typedef enum fraud_check_varnish_cache_status {
	WOPS_VARNISH_CACHE_NOT_USED = -1,
	WOPS_VARNISH_CACHE_MISS = 0,
	WOPS_VARNISH_CACHE_HIT = 1
} fraud_check_varnish_cache_status_t;

typedef struct prebid_fraud_check_data {
	int is_fraud;
	fraud_check_status_type_t fraud_check_status;
	char prediction_id[MAX_PREDICTION_ID_LEN + 1];
	struct curl_slist *fraud_chk_hdr_list;
	prebid_fraud_check_stats_t prebid_fraud_stats;
	prebid_fraud_check_varnish_cache_stats_t *prebid_fraud_cache_stats;
	int varnish_backend_server_id;  /* Varnish server id to which WhiteOps call is made */
	fraud_check_varnish_cache_status_t cache_result;
	int varnish_cache_enabled; /* If caching enabled for Prebid calls */
	int varnish_cache_ttl; /* Cache expiry time in seconds */
}prebid_fraud_check_data_t;

struct deal_params;

#define MAX_CROSS_DEVICE_VENDOR_LIST_LEN 511
#define MAX_CROSS_DEVICE_VENDOR_LIST_COUNT 15
typedef struct cross_device_vendor {
	unsigned long dsp_id;
	unsigned long campg_id;
	char uid[MAX_COOKIE_SIZE + 1];
} cross_device_vendor_t;

typedef struct cross_device_vendor_list {
	cross_device_vendor_t vendor[MAX_CROSS_DEVICE_VENDOR_LIST_COUNT];
	unsigned int count;
} cross_device_vendor_list_t;

typedef struct ads_stats_time_info{
	struct timeval current_time;
	struct timeval last_updated_time;
}ads_stats_time_info_t;

typedef struct dsp_message
{
	unsigned long campaignid ;
	char *message ;
	size_t message_len ;
	struct dsp_message *next ;
} dsp_message_t ;

struct rtf_info {
	struct pairid rtf[MAX_REALTIME_CAMPAIGNS];
	int sz;
};

typedef struct qps_logging_params{
	pm_json_object_t *qps_logger_json_obj;
	pm_json_object_t *qps_cmpg_logger_array;
} qps_logging_params_t;

typedef struct fte_params {

	fte_handle_t fte_handle;
	/*max mind geoip data*/
	geo_data_t gd;
	geo_data_t gd_to_log;
	/* lucid category values tc0, tc1, tc2 respectively*/
	char category[MAX_LUCID_CATEGORIES][LUCID_CATEGORY_LEN + 1];
	//double campaign_price;
	publisher_settings_t publisher_settings;
	/* data from publisher_level_settings table */
	publisher_level_settings_t publisher_level_settings;
	dc_publisher_level_settings_t dc_publisher_level_settings;
	publisher_site_adflex_settings_t publisher_site_adflex_settings;
	db_connection_t *kadserver_dbconn;
	//stats server counters 	
	libstat_counters_t libstat_counters[MAX_STATS_CAMPAIGNS];
	libstats_badrq_counters_t libstat_badrq_counters[MAX_PUB_ID + 1];
	uint16_t impression_counter_per_thread;
	uint16_t invalid_impression_counter_per_thread;
	uint16_t impression_TPCNA_counter_per_thread;
	uint32_t rtb_skipped_requests;
	uint32_t adflex_margin_filtered_campaigns;
	uint16_t eliminated_und_networks;
	int debug_flag;
	site_category_list_t site_category_list;
	//
	rt_handle_t realtime_api_handle;
	easy_handle_to_campaign_id_map_t map;
	int u_fold_position_id; // system and user fold placement id 
	CURL* curl_handle_cache[MAX_REALTIME_REQUESTS];
	//sagar
	CURL* bidder_curl_handle[MAX_NO_OF_BIDDER_CLUSTERS];
	int bidder_curl_reinit_value[MAX_NO_OF_BIDDER_CLUSTERS];
	//~sagar
	//curl handle for audience server
	CURL* audience_curl_handle;
	// After "rtb_curl_handle_reinit_value" requests the curl easy handle will be reinitialized
	int curl_reinit_value[MAX_REALTIME_REQUESTS];
	logger_t* logger;//it is just a pointer to logger_premium or logger_regular based on premium_logging_enabled flag
	logger_t* logger_premium;
	logger_t* logger_regular;
	int log_written;
	fte_context_t ft_context;
	long int random_number; /*this will be generated in each thread and can be used throughout the thread*/
	double default_second_price_margin; // defualt value for second price margin
	int use_landing_page_filtered_campaigns_for_sp; // flag to indicate whether to skip or consider landing page filtered camapign for SP

	pub_site_camp_t pub_site_cam;
	pub_site_camp_t dc_pub_site_cam;
	//DP contextual params
	void *dp_config;
	void *dp_request_params;
	void *dp_resp_params;

	int is_https_request_flag;

	// optional parameters to be send to dsp
	double minimum_clearing_price;
	int   minimum_clearing_price_type;
	long vertical_id;

        int iab_vertical_count; 
        site_verticals_t* iab_verticals;
#ifdef AKAMAI_SIGNAL_COUNT_LOGS_ENABLED
	//per thread counter to log signals passed by AKAMAI in AdServer Requests
	int akamai_signal_counter;

#endif

	//audience information
	audience_params_t audience_params;

	/* Array of poniters pointing to Deal related params */
	struct deal_params **deals_params;
	/* Count of entries in the above array. */
	int deals_params_count;
	ad_server_req_param_t *in_server_req_params;
	// cookie-store(SPug) curl handle
	CURL* spug_curl_handle;
	// cookie-store(RPug) curl handle
	CURL* rpug_curl_handle;
	// cookie-store data (pubmaticuid, pmoo, rtb-cookies)
	cookie_store_data_t cookie_store_data;
	int cs_data_loaded;
	// cookie-store(FRPug) curl handle
	CURL* floor_rpug_curl_handle;

	// publisher_site_domain_name
	char site_url[MAX_SITE_NAME_LEN + 1];

	//Integral Integration
	CURL *integral_handle;
	integral_data_t integral_data;

	//Prebid fraud check Integration
	CURL *prebid_fraud_check_handle;
	prebid_fraud_check_data_t prebid_fraud_check_data;

	//Custom-made hash table to store win-loss information
	hash_table_t hash_table;
	currency_xrate_map_t *currency_xrate_map;
	int currency_count;
	currency_xrate_meta_t *currency_xrate_meta;
	int cp_algo_used;
	
	struct impr_info impr;
	int bid_throttle_bitmap;
	double impression_throttle_percent;
	int rtb_filtered_reason;
	int fraud_level;
	int bsc_level;	
			
	//TODO:MBR_SAGAR : DEPRECATE BID CACHING
	cached_bid_prices_t *cached_bids;
	bid_price_caching_stats_t cbp_stats;
	int pricing_algo;
	int pricing_algo_selection;
	struct pricing_2_0_global_params pricing_global_params;
	//~user bid price caching
	cross_device_vendor_list_t cross_device_vendor_list;
	ads_stats_time_info_t ads_stats_time_info;
	ads_txt_pub_auth_status_type_t ads_txt_pub_auth_status;
	ads_txt_pub_auth_status_type_t app_ads_txt_pub_auth_status;
	long unsigned int stat_update_interval;//after how many seconds stats must be pushed
	struct timeval next_pubstat_push_time;// after this few publisher stats will be pushed even if threshold not reached
	struct rtf_info cmpg_rtf;//RTB floor for all campaigns

	dsp_message_t *dsp_req ;
	dsp_message_t *dsp_resp ;
	gdpr_consent_object_t parsed_consent_obj;
	pub_camp_stats_map_t pub_camp_stats_map[MAX_REALTIME_REQUESTS + 1];
	int publisher_auction_type;
	qps_logging_params_t qps_logging_params;
  char *impression_string ;
	int logger_pmp_deals;
	struct cmpg_bid_thrtl_counters *btc;
	int n_btc;
}fte_additional_params_t;

typedef struct selected_campaign_attribute {
	int adcam_idx; // index of selected adcampaign
	char *creative_buff;
	bool valid_creative_buff; // default this will be true. if there is any issue with creativer buffer updating it will get set to false.
	char impression_tracker[IMG_SCRIPT_MAX_SIZE +1] ; /* IMAGE_SCRIPT */
	char event_tracker[MAX_EVENT_TRACKING_URI_SIZE + 1];
	char click_tracker[CLICK_URL_MAX_SIZE + 1] ;
	video_privacy_icon_context_t *privacy_icon_context;
	uint64_t feature_bit_set;
	char *publisher_adtracking_component;

	bool is_unique_creative; // default this will be false. if we found creative is unique, then only we set this flag for sending creative to NRT server
	int is_creative_truncated; //in case of big creative, log only first few chars of it and set this flag to 1
	char  winning_creative[MAX_LOGGABLE_CREATIVE_TAG_SIZE + 1] ;
	int   winning_creative_type;
	char  winning_creative_id[MAX_CREATIVE_ID_SIZE + 1];
	unsigned long long winning_crc64_uniq_creative_id;
	char  winning_landing_page_url[MAX_RESPONSE_URL_SIZE + 1];
	int campaign_supports_multiple_click_tracking_urls;

	/* structure which holds real time bidding related info (will be populated only for real time bidding campaigns */
	rt_response_params_t rt_response_params;

	int guaranteed_delivery_flag;
	int def_iframe;

	long ad_server_optimizer_id;
	int is_rtb;
	long dp_id;//valid only if Request is_rtb is FALSE
	long campaign_id;
	long creative_id; //must be long
	int width;
	int height;
	unsigned long ad_size_id;
	double predicted_ctr;
	double ecpm; //gross or paid(original) ... depends on network deprioritization flag
	double original_ecpm; //original paid ecpm
	double bid2pub_ecpm; //bid value submitted to API publisher
	int bid2pub_bit_field; //reason of bid2_pub != original_ecpm i.e. pay2pub
	long bidding_ecpm_adnw_id; //bidding network
	double bidding_ecpm; //bidding network ecpm
	double pbmt_ecpm;
	//for logging
	double second_price_margin;
	double min_pub_ecpm;
	int winning_seat_id;
	int winning_bid_id;
	char str_winning_bid_id[MAX_BID_ID_LEN + 1];
	int winning_rule_id;
	int winning_rule_priority;
	int winning_demand_priority_id;
	double winning_dynamic_cpm;
	double winning_floor;
	int winning_floor_application_flag;
	uint64_t winning_validation_check_pass_flag;
	struct dsp_buyer* winning_deal;
	char used_user_segment_list[MAX_USER_SEGMENT_LIST_SIZE + 1];	/* List to track used user segment from segment expression list */
	//zedo integration -  placeholder for getting the landing page url of the winning campaign in the handle_request function
	char landing_page_url[MAX_RESPONSE_URL_SIZE + 1];
	char landing_page_tld[MAX_DOMAIN_NAME_LENGTH + 1];
	int is_retargated;
	int adtruth_id_used;
	int append_privacy_compliance_script;
	int pricing_type;
	int skip_variable_floor;
	int rtb_multi_bid_count;
	int is_audience_targeted_campaign;
	int centralised_icap_enabled;/* 0 if disabled else 1*/
	int page_categories_used; //to check if page categories were sent to DSP.. for billing purpose
	long advertiser_id; //advertiser id corresponding to advertiser domain
	long domain_id; //used for domain id
	char iab_category_id[MAX_PUB_TO_IAB_CAT_MAPPING][MAX_IAB_CAT_LEN+1]; //for sub_cat1, pri_cat, sub2_cat,sub2_pri_cat,sub3_cat,sub3_pri_cat

	int click_support;
	unsigned long pixel_id;
	char unique_id[MAX_UNIQUE_ID_LEN];
	char user_guid[MAX_UNIQUE_ID_LEN];
	char browser[MAX_BROWSER_NAME_LEN];
	char remote_ip_addr[MAX_IPSTR_LEN];
	int network_impr_cap;

	int is_network_whose_adscript_is_available_at_runtime;
	char adserver_site_id[MAX_ADSERVER_SITE_ID_LEN + 1];// This uniquely identifies a site for a realtime network(say inmobi mobile network) = ad_active_account_t.adserver_site_id
	int index_realtime_network_fptr;

	/*Publisher click tracking support*/
	char pubclkurl[MAX_PUBLISHER_URL_LENGTH];

	int bitmap_third_p_pixel;/* bitmap containing all pixel added in above variable third_party_pixel*/
	int count_third_p_pixel; /* count of total Third party pixels dropped */
	int second_price_flag;
	double campaign_price;
	double pubmatic_adflex_cut_percentage; //pub_site_camp margin
	unsigned int psc_zero_margin_bitmap; //store db-psc bitmap value for winning campaign
	unsigned int used_zero_margin_bitmap; //Applied bit will be orred in this for logging purpos
	double applicable_tech_fee; //Its psc_pmp_tech_fee or psc_open_tech_fee if winning impr is marginable deal or open exchange respectively
	int should_apply_p2_at_layer;
	double product_ecpm;
	struct vecd *f2;	 //F2 array of values of winning campaign
	double f2_applied;	 //F2 applied value of winning campaign
	int mbf_algo_info; //MAP2 Status
	int mbf_source; //mbf source level - Buyer/Campaign/Site/Pub
	double map2_arm; //arm used to derive p2p in MAP2

	// floor reduction algo
	int recovery_pause;
	double recovery_amount;
	double pub_recovery;
	double dsp_recovery;
	int fra; //fra discount applied 

	double second_highest_price;
	int second_highest_bit_field;
	int second_highest_id;
	double tshv; //SHV value before applying f2.. called as 'then shv'

	int max_ctr_creative_id;
	decision_manager_price_point_t dm_floor;
	campaign_creatives_t *campaign_creatives;
	int ncreatives;
	struct pricing_2_0_params pricing_params;
	int send_ucrid_in_response; // ON, if DSP wants us to send UCrId in response to Publishers
}selected_campaign_attribute_t;

typedef struct selected_compaign_context{
	long publisher_id;
	long site_id;
	long ad_id;
	long ad_server_id;
	long indirect_ad_tag_id;
	long defaulted_adserver_id;
	int impr_cap;
	int is_blank;
	int blank_reason;
	/* Indirect Ad Tag Id for the defaulted network */
	unsigned long defaulted_net_indirect_ad_tag_id;
	
	int default_handled;
	int frequency;
	
	selected_campaign_attribute_t selected_campaign[MAX_ALLOWED_MULTIBID_RESPONSE];
	int nselected_campaign;
} selected_compaign_context_t;

void init_selected_campaign_context(selected_compaign_context_t *camp_cntx);

//MUX DEFINITIONS
#define MAX_REPLACE_PARAMS 3

typedef enum MUX_SUBSTITUTION {
	RT_REQUEST_ID = 0,
	RT_AD_SIZE,
	RT_SCO_REQUEST_ID /* Request ID in Supply Chain Object */
} rt_substitution;

typedef struct replace_info {
	char* start;
	char* end;
} replace_info_t;
//~MUX DEFINITIONS

typedef struct rt_request_params {
	rt_request_url_params_t request_url_params;
	ad_server_req_param_t *in_server_req_params;    
	ad_server_req_gen_param_t *ad_server_req_gen_params;
	fte_additional_params_t *fte_additional_params;
	encoded_request_params_t encoded_request_params;
	/* Rich Media related params. */
	publisher_site_ad_rich_media_params_t *pub_site_rich_media_params;
	rt_custom_params_t rt_custom_params;
	struct timeval stamp_before_api_cal_api_call ;
	int connection_timeout;
	replace_info_t replace_info[MAX_REPLACE_PARAMS]; //Keep pointer and length for mux substitutions, Here [0]: PUBMATIC_RTB, [1]:OPENRTB/OPENRTB2.3
}rt_request_params_t;

//definitions for request and response handlers. 
typedef int (*get_request_url) (
		rt_request_params_t *rt_request_params,
		const rt_request_url_params_mask_t *rt_request_url_mask,
		rt_response_params_t *out_response_params,
		ad_server_additional_params_t *additional_parameter,
		char *request_url_with_mandatory_params,
		char* campaign_cookie,
		publisher_site_ad_campaign_list_t *adcampaigns);

typedef int (*process_response) (
		void *response_buffer, size_t size, 
		size_t nmemb, void *response_url_params);

//structure for holding pointers to operations --> creating request and processing response
typedef struct rt_campaign_adapter {
	get_request_url rt_get_request_url;
	process_response rt_process_response; 
}rt_campaign_t;



//Map to hold campaign_id and corrosponding operations
typedef struct rt_campaign_adapter_map {
	long campaign_id;
	rt_campaign_t *rt_campaign_adapter;
}rt_campaign_adapter_map_t;


typedef struct campaign_site_blocking_params{
	long campaign_id;
	unsigned int blocking_percentage;
	struct drand48_data rcampaign_blocking_context;
	int found_flag;	
}campaign_site_blocking_params_t; 


typedef struct campaign_site_blocking_context{
	long campaign_id;
	struct drand48_data rcampaign_blocking_context;
}campaign_site_blocking_context_t; 


typedef enum floor_types{
	HARD_FLOOR = 0,
	PRICE_GOAL_FLOOR = 1,
	SOFT_FLOOR = 2
}floor_types_t;

typedef enum rtb_floor_types {
	NO_RTB_FLOOR = 0,
	BIDDING_ECPM = 1,
	DYNAMIC_FLOOR = 2,
	RULE_ENGINE_RTB_FLOOR = 4,
	F1_ML_RTB_FLOOR = 8,
	//ML based RTB Floor not found for publisher in json model
	F1_ML_RTB_FLOOR_NF = 16
}rtb_floor_types_t;

typedef struct publisher_site_dsp_floor_settings{
	unsigned int dsp_id;
	double floor_ecpm;
}publisher_site_dsp_floor_settings_t;

typedef struct publisher_site_advertiser_floor_settings{
	char domain_name[MAX_DOMAIN_NAME_LENGTH + 1];
	double floor_ecpm;
}publisher_site_advertiser_floor_settings_t;

typedef struct publisher_site_dsp_advertiser_floor_settings{
	unsigned int dsp_id;
	char domain_name[MAX_DOMAIN_NAME_LENGTH + 1];
	double floor_ecpm;
}publisher_site_dsp_advertiser_floor_settings_t;

typedef struct publisher_site_pmp_floor_settings{
	publisher_site_dsp_floor_settings_t *dsp_floor_list;
	unsigned int dsp_floor_list_count;
	publisher_site_advertiser_floor_settings_t *advertiser_floor_list;
	unsigned  int advertiser_floor_list_count;
	publisher_site_dsp_advertiser_floor_settings_t *dsp_advertiser_floor_list;
	unsigned int dsp_advertiser_floor_list_count;
}publisher_site_pmp_floor_settings_t;

typedef struct advertiser_domain_id {
	int domain_id;
	int advertiser_id;
	//char domain[MAX_DOMAIN_NAME_LENGTH + 1];
	char domain [ADVERTISER_DOMAIN_TRUNCATED_DOMAIN_NAME_LENGTH + 1]; // We need only 6 bytes for validation as we couldnt get rid of www. in this list
	unsigned int crc_32;
} advertiser_domain_id_t;

typedef struct advertiser_domain_category_id {
	int advertiser_id;
	int domain_id;
	int category_id;
} advertiser_domain_category_id_t;

typedef struct rt_dsp_buyer_map {
	int dsp_id;
	int dsp_buyer_id;
	int buyer_id;
} rt_dsp_buyer_map_t;

typedef struct pm_dsp_buyer_map {
	int buyer_id;
	int dsp_buyer_id;
	int log_full_user_id;
}pm_dsp_buyer_map_t;

typedef struct publisher_site_top_level_domain_name {
        unsigned int top_level_domain_id;
        char domain_name [TLD_WHITELIST_TRUNCATED_DOMAIN_NAME_LENGTH + 1]; // We need only 4 bytes(for validation) as we are "mostly" relying on crc_32
        unsigned int crc_32; //grabs the crc32 of the domain_name
        int application_profile_id;
        unsigned int platform_id;
} publisher_site_top_level_domain_name_t;


typedef struct pub_preferred_id_blocklist {
 int *attribute_id_list_ptr;
 int nelements;
}pub_preferred_id_blocklist_t;

//used for initializing realtime bidding datastructures
void rt_bidding_initialize(rt_response_params_t* in_response_params);
struct campaign_data_provider_data_ops_params;
//creates realtime request--> called per realtime campaign
int rt_bidding_create_request(void *in_request_params_x,
			      int request_count,
			      void *out_response_params_x,
			      long campaign_id,
			      void *site_x,
			      cache_handle_t *cache_handle,
			      db_connection_t *dbconn,
			      const void * rt_request_url_params_mask1_x,
			      void *additional_parameter_x, 
			      void *cmpg_dp_params,
			      char *request_url_with_mandatory_params, 
			      char* post_data,
			      char* campaign_cookie,
			      void *adcampaign,
			      void *header_list,
			      int *size_header_list,
			      void * adcampaigns_list,
			      int nelements,
			      int current_index,
			      void *p_buffer_tracker);

//							   encoded_request_params_t *encoded_request_params);

void init_rtb_custom_params( rt_request_params_t* in_request_params, const ad_server_additional_params_t* additional_parameter );
//to parse PubMatic RTB response
void default_parse_response (void *ptr_rt_response_params_x,
                             int *response_alloc_count,
                             int index,
                             void *additional_parameters_x,
                             int *rt_response_count, 
			     void *rt_request_params_x );
//adds an realtime request(easy handle) in multi-handle stack
//
//int rt_bidding_add_request(rt_handle_t *in_handle, rt_response_params_t *in_response_params);
int rt_bidding_add_request(rt_handle_t *in_handle, CURL*);

//blocking call to complete all requests
int rt_bidding_do_task(rt_handle_t *in_handle, int rtb_timeout, int use_epoll);

//cleaning up data structures and curl_easy requests
//
//int rt_bidding_cleanup(rt_handle_t *in_handle, rt_response_params_t *in_response_params, int handle_cnt);
int rt_bidding_cleanup(rt_handle_t *in_handle, CURL*[], int*, rt_response_params_t* rt_response_params, int rt_request_count, int handle_cnt);


int make_realtime_api_calls(
		publisher_site_ad_campaign_list_t** ptr_adcampaigns, 
		int* ptr_nelements,
		rt_request_params_t* rt_request_params, 
		rt_response_params_t** ptr_rt_response_params, 
		int *response_alloc_count,
		publisher_site_t *site,
		cache_handle_t *cache_handle, 
		ad_server_additional_params_t* additional_parameters,	
		fte_additional_params_t *fte_additional_parameters,
		double bidding_ecpm,
		ad_server_req_param_t *in_req_params, 
		ad_server_req_gen_param_t *in_gen_params,
		int *rt_requests_count,
		int *rt_response_count,
		int *filtered_rtb_campaigns,
		int is_mob_impression,
		publisher_site_ad_t *in_ad,
		char rtb_request_campaign_cookies[][MAX_COOKIE_SIZE + 1],
		campaign_data_provider_data_ops_params_t *cmpg_data_provider_data_params,
		int *cmpg_dp_data_params_idx
		);

int get_dsp_floor(publisher_site_pmp_floor_settings_t *publisher_site_pmp_floor_settings,
		unsigned int dsp_id,
		double *dsp_floor);

int get_advertiser_floor(publisher_site_pmp_floor_settings_t *publisher_site_pmp_floor_settings,
		const rt_bid_response_params_t* bid_response_params,
		double *advertiser_floor);

int get_dsp_advertiser_floor(publisher_site_pmp_floor_settings_t *publisher_site_pmp_floor_settings,
		unsigned int dsp_id,
		const rt_bid_response_params_t* bid_response_params,
		double *dsp_advertiser_floor);

int get_pmp_floors_data(long int publisher_id,
		long int site_id,
		const ad_server_additional_params_t *additional_parameters,
		const fte_additional_params_t *fte_additional_parameters,
		cache_handle_t *cache,
		db_connection_t *dbconn,
		publisher_site_pmp_floor_settings_t *publisher_site_pmp_floor_settings);

void free_pmp_floor_data(publisher_site_pmp_floor_settings_t *publisher_site_pmp_floor_settings);

int update_rtb_winloss_information(
                const fte_additional_params_t *fte_additional_parameters,
                const ad_server_additional_params_t* additional_params,
                const publisher_site_ad_campaign_list_t *adcampaigns,
                const rt_request_params_t *rt_request_params,
                const int rt_response_count,
                const rt_response_params_t *rt_response_params,
                const selected_campaign_attribute_t* selected_camp,
                hash_table_t *hash_table,
                const int selected_campaign,
                const double bidding_ecpm
        );

int print_formatted_string(char *dest, const char *src, const int max_length);

void init_fte_params(fte_additional_params_t *fte_additional_parameters);
#endif




