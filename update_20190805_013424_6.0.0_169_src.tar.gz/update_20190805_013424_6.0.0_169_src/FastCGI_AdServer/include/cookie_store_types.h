/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __COOKIE_STORE_TYPES_H_
#define __COOKIE_STORE_TYPES_H_

#include <time.h>

#define MAX_KRTBCOOKIES_ON_BROWSER 50 

// #define MAX_PIGGY_BACK_TAGS 4
// #define MAX_PIGGY_VAR_LEN 1024
#define MAX_USERID_LEN 40
#define MAX_PMOO_COOKIE_LEN 5

/*
 * VALUES related to campaign/network frequency data
 */

#define MAX_PENDING_WRITE 3
#define MAX_CAMP_FREQ 50
#define MAX_NET_FREQ 64
#define MAX_GENERATION_FAIL_RETRY 3
#define FREQ_READ_EXPIRY_TIME 1
#define DEFAULT_FREQ_WRITE_EXPIRY (60 * 60 * 24)

//opcodes for SPug server
#define UPDATE_PIGGYBACK_COOKIE	0
#define UPDATE_FREQ_CAMP	1
#define UPDATE_FREQ_NET		2

//request type
#define HTTP_REQ "http://"
#define HTTPS_REQ "https://"

typedef struct cs_user_floor_data {
	float	cs_user_floor_value;
	int	cs_default_site_flag;
} cs_user_floor_data_t;

typedef struct per_camp_freq_data {
	int	camp_id;
	int	count;
	time_t	expiry;
} per_camp_freq_data_t;

typedef struct camp_freq_data {
	int	no_of_camp;
	int	pending_writes;
	per_camp_freq_data_t	campaign_data[MAX_CAMP_FREQ];
} camp_freq_data_t;

typedef struct per_net_freq_data {
	int	net_id;
	int	count;
	time_t	expiry;
} per_net_freq_data_t;

typedef struct net_freq_data {
	int	no_of_net;
	int	siteid;
	int	pending_writes;
	per_net_freq_data_t	network_data[MAX_NET_FREQ];
} net_freq_data_t;


typedef struct cookie_rec {
	char *name;
	char *value;
}cookie_rec_t;

typedef struct cookie_details {
	cookie_rec_t *cookie_map;
	char* cookie;
	int alloc_count;
	int use_count;
}cookie_details_t;

typedef struct cookie_head {
	cookie_details_t *head;
	int alloc_count;
}cookie_head_t;

const char *getROCookie(FCGX_Request *req,  const int thread_id, const char *cookie_name);

#if 0
typedef struct piggyback_data_per_campaign {
	int	no_of_campaigns;/*number of campaigns configured for a DSP*/
	int	campaignid[MAX_PIGGY_BACK_TAGS];/*list of campaign id*/
	char	campaign_cookie[MAX_PIGGY_BACK_TAGS][MAX_PIGGY_VAR_LEN + 1];/*Actual piggyback rtb cookie*/
} piggyback_data_per_campaign_t;

typedef struct rtb_piggyback_cookies {
	int	no_of_dsps;/*number of DSPs with their piggyback cookie */
	int	dspid[MAX_KRTBCOOKIES_ON_BROWSER];/*list of dspid */
	piggyback_data_per_campaign_t dsp_cookie[MAX_KRTBCOOKIES_ON_BROWSER]; /*piggyback cookie including &KRTB& */
} rtb_piggyback_cookies_t;

typedef struct cookie_store_data {
	char			pubmatic_uid[MAX_USERID_LEN + 1];
	char			pmoo[MAX_PMOO_COOKIE_LEN + 1];
	rtb_piggyback_cookies_t rtb_piggyback_data;
	net_freq_data_t		net_freq_data;
	camp_freq_data_t	camp_freq_data;
	cs_user_floor_data_t	user_floor_data;
} cookie_store_data_t;
#endif

#endif /*__COOKIE_STORE_TYPES_H_*/
