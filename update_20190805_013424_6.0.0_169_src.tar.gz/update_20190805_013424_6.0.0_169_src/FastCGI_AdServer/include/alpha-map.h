/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


/* -*- Mode: C; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */
/*
 * libdatrie - Double-Array Trie Library
 * Copyright (C) 2006  Theppitak Karoonboonyanan <thep@linux.thai.net>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/*
 * alpha-map.h - map between character codes and trie alphabet
 * Created: 2006-08-19
 * Author:  Theppitak Karoonboonyanan <thep@linux.thai.net>
 */

#ifndef __ALPHA_MAP_H
#define __ALPHA_MAP_H

#include <stdio.h>

#include "typedefs.h"
#include "triedefs.h"

/**
 * @file alpha-map.h
 * @brief AlphaMap data type and functions
 */

/**
 * @brief AlphaMap data type
 */
typedef struct{
  AlphaChar *range_array;
  TrieIndex used_size;
  TrieIndex alloc_size;
}AlphaMap;

#define INTIAL_BOT_TRIE_ALPHAMAP_ALLOC_SIZE 10

AlphaMap *  alpha_map_new ();

AlphaMap *  alpha_map_clone (const AlphaMap *a_map);

void        alpha_map_free (AlphaMap *alpha_map);

int         alpha_map_add_range (AlphaMap  *alpha_map,
                                 AlphaChar  begin,
                                 AlphaChar  end);

int         alpha_char_strlen (const AlphaChar *str);

int         alpha_map_get_total_ranges (const AlphaMap *alpha_map);

AlphaChar    alpha_map_char_to_trie (const AlphaMap *alpha_map,
    AlphaChar       ac);

AlphaChar   alpha_map_trie_to_char (const AlphaMap *alpha_map,
    AlphaChar        tc);

AlphaChar *  alpha_map_char_to_trie_str (const AlphaMap  *alpha_map,
    const AlphaChar *str);

AlphaChar * alpha_map_trie_to_char_str (const AlphaMap  *alpha_map,
    const AlphaChar  *str);
#endif /* __ALPHA_MAP_H */


/*
vi:ts=4:ai:expandtab
*/
