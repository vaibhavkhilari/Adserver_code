/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __SITE__NETWORK_IMPRESSION_CAPPING_H__
#define __SITE_NETWORK_IMPRESSION_CAPPING_H__

#include "cache_types.h"
int reset_total_site_size_network_impressions_toserve(
                        unsigned long *impressions_tobe_served,
                        publisher_site_impression_cap_t *network_impression_caps,
                        publisher_site_impression_total_t *network_impression_total,
                        int site_id,
                        int size_id,
                        int thread_id,
                        cache_handle_t *cache,
						db_connection_t *dbconn,
						ad_server_additional_params_t *additional_params);

/* this fuction will check for impression capping settings and if its there it will check for estimate */
int check_site_network_impression_cap(ad_server_req_param_t *in_req_params,
        ad_server_req_gen_param_t *in_gen_params,
        publisher_site_ad_t *in_ad,
		network_elimination_list_t *elimination_list,
        cache_handle_t *cache_handle,
        db_connection_t *dbconn,
        unsigned long ptid,
        ad_server_additional_params_t *additional_params,
	selected_compaign_context_t *selected_camp_cntx, int selected_camp_idx,
        fte_additional_params_t *fte_additional_parameters);

/* this counts the impression for ggiven site */
//int mark_network_impression(int adserver_id, int site_id, int ad_size_id, int thread_id, cache_handle_t *cache_handle);

int mark_site_size_network_impression(int, int, int, int, cache_handle_t *);
int mark_site_size_network_centralized_icap(int adserver_id, int site_id,int ad_size_id,
                                            cache_handle_t *cache_handle, ad_server_additional_params_t *additional_params);

#endif
