/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __AD_SERVER_TYPE_HELPER_H__
#define __AD_SERVER_TYPE_HELPER_H__

#define MAX_ADSERVER_PUB_ID_LEN     256 //128*2 i18
#define MAX_ADSERVER_SITE_ID_LEN    256 //128*2 i18
/* This macro defines the max size of used segments list that tracks used  segments from expression during evaluation */
/* This should be in sync with MAX_SEGMENT_EXPR_SIZE */
#define MAX_USER_SEGMENT_LIST_SIZE 512
#define MAX_REALTIME_CAMPAIGNS 50

#define MAX_STATS_CAMPAIGNS 	(MAX_REALTIME_CAMPAIGNS*3)
#define MAX_REALTIME_REQUESTS (MAX_REALTIME_CAMPAIGNS*2) //max allowed RTB requests per impression
#define MAX_COOKIES_PER_DSP 15 //max allowed &KRTB& delimiters in KRTBCOOKIE
#define MAX_MUX_REQ_PER_CAM 5 //max allowed rtb requests per campaign for single ad impression
#define MAX_PUB_ID 20000
// reasons for filtering adnetworks
#define NOT_FILTERED  0
#define NW_LEVEL_ICAP_FILTER (NOT_FILTERED + 1)
#define NW_SITE_SIZE_ICAP_FILTER (NOT_FILTERED + 2)
#define NW_FREQUENCY_CAP_FILTER (NOT_FILTERED + 3)
#define NW_RETARGETING_FILTER (NOT_FILTERED + 4)
#define NW_DEFAULT_FILTER (NOT_FILTERED + 5)
#define NW_BOT_FILTER (NOT_FILTERED + 6)
#define NW_NCB_FILTER (NOT_FILTERED + 7)
#define NW_USER_LEVEL_DEPRIORITISATION_FILTER (NOT_FILTERED + 8)
#define NW_COPPA_FILTER (NOT_FILTERED + 9)
#define NW_IFRAME_DEFAULT_FILTER (NOT_FILTERED + 10)
#define NW_DEVICE_TYPE_FILTER (NOT_FILTERED + 11)
#define NW_INVENTORY_MISMATCH_FILTER (NOT_FILTERED + 12)
#define NW_MANDATORY_PARAMETER_MISSING_FILTER (NOT_FILTERED + 13)
#define NW_FORCED_ADNW_FILTER (NOT_FILTERED + 14) 
#define NW_DYNAMIC_FLOOR_FILTER (NOT_FILTERED + 15)

typedef struct ad_active_account {
	unsigned long ad_active_account_id;
	unsigned long publisher_adserver_account_id;
	char adserver_site_id[MAX_ADSERVER_SITE_ID_LEN + 1];
	unsigned long optimizer_option_id;
	unsigned long preference;
	/* 
	 * Depends upon depriritization enabled/disabled for active account:
	 * if deprioritize enabled ecpm = gross ecpm (calculated by considering default impressions)
	 * else  ecpm = original ecpm (calculated without considering default impressions)
	 */
	double ecpm;
	/*
	 * original i.e paid ecpm(calculated without default impressions)
	 */
	double original_ecpm;
	double pbmt_ecpm;		//-- PLEASE READ ABOVE NOTICE
	unsigned long priority;
	unsigned int use_adserver_site_id;
	char adserver_pub_id[MAX_ADSERVER_PUB_ID_LEN + 1];
	unsigned long adserver_id;
	unsigned long associated;
	long direct_indirect_flag;	
	long guaranteed_delivery_flag;
	int retargeting_settings;
	long pixel_id;
	long rest_of_the_world;
	long pm_one_network_type_id;
	int auto_reporting_flag;/*tells whether the indirect network is an INW network*/
	int credentials_available;/*INW network's credentials availablity flag*/
	int filtered_flag;
	int nt_impr_cap_flag; /* flag will be set if ad network has impression cap settings */
	int def_iframe; /* Flag for Ad Networks which defaults via iframe */
	char used_user_segment_list[MAX_USER_SEGMENT_LIST_SIZE + 1];	/* List to track used user segment from segment expression list */
	int ncb_filter_flag; /* Flag to AdNetworks which tells to elminate the network if this flag is on */
	int is_realtime_network;
	int supports_beacon_based_counting;
	int ad_type_id;
	int user_default_network_blocking_enabled;
	int exclude_for_inventory; /* Flag for exclusion of networks for desktop/mobile chanbel */
	int json_logging_enabled;
	int filter_bot_inventory;
	int is_coppa_compliant;
	int skip_mandatory_param_check; //flag will be set if we have to skip the Mandatory Param check for AdNetworks
	int reason_for_filtering;
	int centralised_icap_enabled; /* flag will be set if centralised icap enabled on network might not be usable in adserver_main*/
} ad_active_account_t; 

#endif /* AD_SERVER_TYPES_H */
