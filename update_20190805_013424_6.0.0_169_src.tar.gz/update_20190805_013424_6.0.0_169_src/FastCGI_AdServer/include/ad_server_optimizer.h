/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef AD_SERVER_OPTIMIZER_H
#define AD_SERVER_OPTIMIZER_H   

#include "ad_optimizer.h"
#include "google_optimizer.h"
#include "komli_optimizer.h"
#include "yahoo_optimizer.h"
#include "valueclick_optimizer.h"
#include "bluelithium_optimizer.h"
#include "bidvertiser_optimizer.h"
#include "adbrite_optimizer.h"
#include "burstmedia_optimizer.h"
#include "advertisingdotcom_optimizer.h"
#include "tribalfusion_optimizer.h"
#include "casale_optimizer.h"
#include "realtechnetwork_optimizer.h"
#include "adtegrity_optimizer.h"
#include "kitara_optimizer.h"
#include "cpx_interactive_optimizer.h"
#include "bannerconnect_optimizer.h"
#include "puntofox_optimizer.h"
#include "abcsearch_optimizer.h"
#include "indirectadnetwork_optimizer.h"
#include "google_premium_optimizer.h"
#include "lucidcampaign_optimizer.h"
#include "lucidcapitalonecampaign_optimizer.h"
#include "adflex_optimizer.h"
#include "mediamathproactivcampaign_optimizer.h"
#include "kontera_optimizer.h"
#include "widgetbucks_optimizer.h"
#include "pubmaticone_optimizer.h"
#include "adconion_pci_optimizer.h"
#include "zetanet_pci_optimizer.h"
#include "realmedia24by7_pci_optimizer.h"
#include "audiencescience_optimizer.h"
#include "foxaudience_pci_optimizer.h"
#include "turn_pci_optimizer.h"
#include "redux_pci_optimizer.h"
#include "inmobi_optimizer.h"
#include "jumptap_optimizer.h"
#include "mojiva_optimizer.h"
#include "mocean_optimizer.h"
#include "huntmads_optimizer.h"
#include "madvertise_optimizer.h"
#include "matomy_optimizer.h"
#include "adfonic_optimizer.h"
#include "4info_optimizer.h"
#include "tapit_optimizer.h"
#include "vdopia_optimizer.h"
#include "komli_optimizer.h"
#include "jiwire_optimizer.h"
#include "nexage_optimizer.h"
#include "addynamo_optimizer.h"
#include "pontiFlex_optimizer.h"
#include "mob_s2s_optimizer.h"
#include "guaranteed_adserving_optimizer.h"
#include "client_network_optimizer.h"
#define MAX_ADSERVERS 513

void parse_accept_lang_header(
    const char* header_value,
    char* buff
    );

#endif /* AD_SERVER_OPTIMIZER_H */
