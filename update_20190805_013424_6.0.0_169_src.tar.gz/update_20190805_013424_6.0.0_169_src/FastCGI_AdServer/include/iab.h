#ifndef _IAB_HEADERS_
#define _IAB_HEADERS_
/*This array contains all IAB categories sequentially, index of each entry+IAB_START_INDEX is pubmatic-id
of corresponding iab category/sub-category. For refernce, look into KomliAdServer.iab_categories table*/

struct pubmatic_iab_mapping_t{
	char iab_cat_str[MAX_IAB_CAT_LEN + 1];
	int pubmatic_iab_cat_id;
	int pubmatic_iab_sub_cat_id;
};

extern const struct pubmatic_iab_mapping_t pubmatic_iab_mapping[];
extern const int size_pubmatic_iab_mapping;

#endif
