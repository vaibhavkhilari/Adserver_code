/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef VIDEO_H
#define VIDEO_H

#include <stats.h>
#include <video_stats.h>
#include "db_connection.h"
#include "cache_libmemcached.h"

//RT request parameters
#define MAX_VIDEO_CREATIVE_TAG_LEN 1024*100 //TUSHAR: changed it to 100k
#define MAX_DEFAULT_VIDEO_CREATIVE_TAG_LEN 1024*35 //TUSHAR changed it to 35k
#define MIN_VIDEO_CREATIVE_TAG_LEN 1024*10 //TUSHAR: changed it to 10k
#define MAX_PRIVACY_COMPLIANCE_PARTNER_TAG_SIZE 1024

extern void logVidMessage(const char *format, ...);
#define VIDEO_ERROR(format, ...); logVidMessage("VIDEO_ERROR|"format "|%s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__);
#ifdef VIDEO_RT_INFO
	#define VIDEO_INFO(format, ...); logVidMessage("VIDEO_INFO|"format"|%s:%d\n" , ##__VA_ARGS__,__FILE__, __LINE__);
#else
	#define VIDEO_INFO(format, ...);
#endif

#ifdef VIDEO_RT_DEBUG
	#define VIDEO_DEBUG(format, ...); logVidMessage("VIDEO_DEBUG|"format"|%s:%d\n" , ##__VA_ARGS__,__FILE__, __LINE__);
#else
	#define VIDEO_DEBUG(format, ...);
#endif
#define MIN_STARTDELAY_VALUE -2
#define MAX_PAGE_URL_SIZE 4096 //(2048 + 1)*2 i18	
#define MIN_VIDEO_TYPE_VALUE      0
#define MIN_VIDEO_POSITION_VALUE  0
#define MAX_VIDEO_TYPE_VALUE      2
#define MAX_VIDEO_POSITION_VALUE  3
#define MAX_STREAM_FORMAT_ID 12
#define MAX_CREATIVE_TYPE_VAL 2
#define MAX_VAPI_FORMAT_ID 7
#define MAX_PROTOCOL_TYPE_VALUE 8
//video params
#define MAX_RESP_FORMAT_SIZE 10
#define MAX_VIDEO_PAGE_CONTEXT_INFO_LENGTH	1024
#define MAX_PROTOCOL_VERSION_LEN	6
#define MAX_VIDEO_PLAYBACK_ID  6
#define VIDEO_PLAYBACK_ALL  0
#define FLAG_SET '1'
#define FLAG_UNSET '0'
#define BIT_SET 1
#define BIT_UNSET 0
#define MAX_ASPECT_RATIO_LEN 5
#define MAX_LANGUAGE_LEN 2      //according to alpha-2/ISO 639-1 code

#define URL_RESPONSE_TYPE	0
#define VAST_CREATIVE		1
#define VAST_WRAPPER_CREATIVE 	2

#define MIME_TYPE_INDEX_FLASH 2
#define MIME_TYPE_INDEX_HTML5 6
#define VIDEO_RETURN_SUCCESS 0
#define VIDEO_RETURN_ERROR 1

typedef enum {
  PROTOCOL_VAST_INVALID = -1,
	PROTOCOL_VAST_1_0_INLINE,
	PROTOCOL_VAST_1_0,
	PROTOCOL_VAST_2_0,
	PROTOCOL_VAST_3_0,
	PROTOCOL_VAST_2_0_INLINE_ONLY,
	PROTOCOL_VAST_3_0_INLINE_ONLY,
	PROTOCOL_VAST_NOT_SUPPORTED,
	PROTOCOL_VAST_4_0_INLINE_ONLY,
	PROTOCOL_VAST_4_0,
	MAX_AD_FORMAT_VAL
} vast_protocol_version_t;

typedef enum {
	VAST_1_0 = 1,
	VAST_2_0,
	VAST_3_0,
	VAST_4_0
} vast_version_t;

//This is vast protocol version is same as provided by iab
typedef enum {
	IAB_VAST_1_0 = 1,
	IAB_VAST_2_0,
	IAB_VAST_3_0,
	IAB_VAST_1_0_WRAPPER,
	IAB_VAST_2_0_WRAPPER,
	IAB_VAST_3_0_WRAPPER,
	IAB_VAST_4_0,
	IAB_VAST_4_0_WRAPPER
} iab_vast_protocol_version_t;

typedef enum {
	MIME_TYPE_MP4 = 1,
	MIME_TYPE_X_FLASH,
	MIME_TYPE_X_WMV,
	MIME_TYPE_H264,
	MIME_TYPE_WEBM,
	MIME_TYPE_JS,
	MIME_TYPE_OGG,
	MIME_TYPE_X_FLV
} video_mime_type_t;
#define API_VPAID_1_0		1
#define API_VPAID_2_0		2
#define VIDEO_AD_TYPE_ANY	0
#define VIDEO_AD_TYPE_LINEAR	1
#define VIDEO_AD_TYPE_OVERLAY	2
#define VIDEO_AD_POSITION_ANY	0
#define NOT_SUPPORTED_BUT_VALID_API -999 

#define HDR_VDBG_SIZE 1024
#define COMMA_DELIMITER ","

enum VideoPlayer {
	VIDEO_PLAYER_FLASH = 0,
	VIDEO_PLAYER_HTML5
};
typedef enum PlacementSource{
	SOURCE_UNKNOWN = 0,
	FROM_DB ,
	FROM_REQUEST
}PlacementSource_e;
typedef struct video_param{
       
	 //VIDEO PARAMETERS
        //video is linear or overlay---default 0{0: 'any', 1: 'linear', 2: 'overlay'}
        int type;
        //video ad's position in the content----default 0{0: 'any', 1: 'pre-roll', 2: 'in-roll', 3: 'post-roll'}
        int position;
        //duration of video ad
        int min_length;
        int max_length;
        //is companion requested
        int has_companion;
        //companion ad width in pixels 
        int companion_width;
        //companion ad height in pixels 
        int companion_height;
        //min bitrate allowed for video stream
        int min_bit_rate;
        //max bitrate allowed for video stream
        int max_bit_rate;
        //video protocol version                
        char protocol_version[MAX_PROTOCOL_VERSION_LEN +1];
        int ad_format_version;
        int vid_api;
				int vid_protocol;
		
        int response_format;
        //partner dependent contextual info
        char page_contextual_info[MAX_VIDEO_PAGE_CONTEXT_INFO_LENGTH +1];      

	/*
		combination of playback values
		this array will be used as a character map in which each character will represent if playback id,which is equal to index of that character,
		is sent in request or not.
		for ex. '1' is set and '0' is unset,
		playback=1+3+5 in request
		then characters in this array will be 110101
		First character represents if any of the characters in remaining array is set
	*/
	char playback[MAX_VIDEO_PLAYBACK_ID +2];/* +1 for '\0' and +1 for first character flag*/ 

        //accepted video stream format---default 'ANY'---values stored as charMap,see comments for playback
        char stream_format[MAX_STREAM_FORMAT_ID+2];
				char vid_api_array[MAX_VAPI_FORMAT_ID + 2];
        //required video ad format or protocols
				char vid_protocols_array[MAX_PROTOCOL_TYPE_VALUE + 2];
	//video params for tubemogul requirement
	int window_height;  
	int window_width;
	int video_ad_height;     
	int video_ad_width;
	int player_height; //Video player  height. 
	int player_width;  //Video player  width. 
	int player_size;   //Video player size 1-small, 2-medium, 3-large; it is derived from player_width x player_height
	char video_page_url[MAX_PAGE_URL_SIZE + 1];
	char video_ref_url[MAX_PAGE_URL_SIZE + 1];
	int player_stretching_mode;
	char aspect_ratio[ MAX_ASPECT_RATIO_LEN + 1 ];
	char language[ MAX_LANGUAGE_LEN + 1 ];
	int skip;          //boolean indicating skippable inventory
	int skip_delay;    //offset in seconds after which user can skip the ad
	int noskip_ad_len; //max ad length which can be allowed to run without skip control in skippable inventory
	int full_screen_expandable; //ad is full screen expandable or not. 0:not expandable, 1:expandable 2:unknown
	int vc; //video client (flash, html5)

	int audio;   //Audio content/music context
	int is_inline_requested;
	int placement;//actual value passed in request(will reject invalid value if any)
	int startdelay;//actual value passed in request(will reject invalid value if any)
	PlacementSource_e placement_source;
 }video_param_t;
 
typedef struct video_privacy_icon_context {
	int width;
	int height;
	int x_position;
	int y_position;
	int duration; // in second
	int offset; // in second
	char flash_icon_url[MAX_PRIVACY_COMPLIANCE_PARTNER_TAG_SIZE + 1];
	char html_icon_url[MAX_PRIVACY_COMPLIANCE_PARTNER_TAG_SIZE + 1];
}video_privacy_icon_context_t;

typedef struct video_context {
	int is_api_req;
	int os_id;
	int is_creative_syncup_required;
	const char *hdr_origin;
	char hdr_vdbg[HDR_VDBG_SIZE+1];
	video_stats_t video_stats;
	audio_stats_t audio_stats;
	video_param_t *video_params;
	enum VideoPlayer video_player;
}video_context_t;

extern void set_video_context(video_context_t *video_context, video_param_t *video_params, const char *hdr_orig, int is_api_req);

enum VIDEO_PLAYER_SIZE { VIDEO_PLAYER_SMALL=1, VIDEO_PLAYER_MEDIUM, VIDEO_PLAYER_LARGE };
int derive_video_player_size(int width, int height);
void parse_and_set_bit(int *mimes, char *input_str, char *delm);
void set_protocols_array(char *protocols_array, int protocol);
void disable_vast4_support(char *protocols_array);

#endif /* VIDEO_H */
