/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


// NIKI :: url parsing API

#ifndef __PARSING_UTIL_H__
#define __PARSING_UTIL_H__   
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "error.h"
#include "stats.h"


typedef struct parsed_key_pair
{
	char *key;
	char *value;
}parsed_key_pair_t;

typedef struct parse_util_struct
{
	parsed_key_pair_t *parsed_key_pair;
	int capacity;
	char *processing_str;
	/* number of times collision occured in parsing util */
	uint32_t parse_util_collision_count;
}parse_util_struct_t;

int parse_initialise(parse_util_struct_t *parse_util_struct,const char *in_query_string);

int init_parsing_struct(parse_util_struct_t *parse_util_struct, int array_size);

int putParam(parse_util_struct_t *parse_util_struct, char *processing_str,int key_count, int val_count);


int getInt(parse_util_struct_t *parse_util_struct, char *var_name, int *found);
float getFloat(parse_util_struct_t *parse_util_struct, char *var_name, int *found);
char* getString(parse_util_struct_t *parse_util_struct, char *var_name);
double getDouble(parse_util_struct_t *parse_util_struct, char *var_name, int *found);
long getLong(parse_util_struct_t *parse_util_struct, char *var_name, int *found);

char* getParam(parse_util_struct_t *parse_util_struct, char *var_name);
void parse_remove(parse_util_struct_t *parse_util_struct);
int increment_collision_count(uint32_t *stats_counter);
void free_parse_util(parse_util_struct_t *parse_util_struct);

#endif
