/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __FTRACK_TRACKING_TSV_H__
#define __FTRACK_TRACKING_TSV_H__

#include <stdio.h>
#include <string.h>
#include "ad_server_types.h"
#include "ftrack_util.h"

int ftrack_record_click_tsv(
        ftrack_context_t *context,
	ad_clicked_params_t *click_params,
        long geo_id,
        char *unique_id,
        char *remote_ip_address,
        long timestamp);

int ftrack_add_ad_display_record_tsv(
        ftrack_context_t *context,
        ad_served_tracking_params_t *params,
        long geo_id,
        ad_server_req_gen_param_t *gen_params,
        char *page,
        long timestamp,
	int geo_dma_code);

int ftrack_record_zone_tsv(
		ftrack_context_t *context,
        ad_served_tracking_params_t *params,
        long geo_id,
        char *user_guid,
        char *page,
        char *remote_ip_address,
        long timestamp);

int ftrack_add_lucid_contextual_record_tsv(
		ftrack_context_t *context,
        long site_id,
        long context_id,
        long context_level,
        long timestamp);

int ftrack_add_activity_record_tsv(
		ftrack_context_t *context,
        long activity_id,
        char *activity_parameters);

int ftrack_add_blocked_pixel_records_tsv(
		ftrack_context_t *context,
        long pub_id,
        long spixel_id,
        long geo_id,
        char *page,
        char *pixel_id_list,
        long timestamp);
#endif
