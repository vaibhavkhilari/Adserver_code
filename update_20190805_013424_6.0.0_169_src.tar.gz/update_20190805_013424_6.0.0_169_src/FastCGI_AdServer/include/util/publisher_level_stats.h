#ifndef PUB_LEVEL_STATS_H
#define PUB_LEVEL_STATS_H

#include "stats.h"
#include "string.h"

typedef struct {
	int appid;		//app.id					aid
	int appidmrq;		//app.id					aid
	int name;		//app.name					name
	int bundle;		//app.bundle				bundle
	int bundlemrq;
	int PA_bundle;
	int domain;		//app.domain				appdomain
	int storeurl;	//app.storeurl				storeurl
	int PA_storeurl;	//app.storeurl				storeurl
	int storeurlmrq;	//app.storeurl				storeurl
	int cat;		//app.cat					cat
	int iabcat;		//app.cat					iabcat
	int sectioncat;	//app.seccat
	int pagecat;	//app.pagecat
	int ver;		//app.ver					ver
	int privacypolicy;	//app.privacypolicy
	int paid;		//app.paid					paid
	int api; 		//banner.api				api
} app_counter_t;

typedef struct {
	int ua;				//device.ua
	int loc; 			//devicei.geo.lat,geo.device.lon
	int loc_source;		//device.geo.type
	int dnt;			//device.dnt
	int lmt;			//device.lmt
	int pmoptout;		//device.pmoptout
	int ip;				//device.ip
	int ipv6;			//device.ipv6
	int devicetype;		//device.devicetype
	int make;
	int model;
	int os;
	int osv;
	int hwv;
	// h,w,ppi,pxratio
	int js;
	int jsmrq;
	//geofetch, flashver
	int language;		//device.language derived from browser
	int carrier;
	int mccmnc;
	int connectiontype; //device.connectiontype = nettype
	int udid;			//device.ifa etc.,						udid
	int dpid;
	int udidmrq;			//device.ifa etc.,						udid
	int dpidmrq;
	int udidtype;
	int udidhash;
	int device_id_ifa;
	int device_id_sha1;
	int device_id_md5;
	int device_id_mac_sha1;
	int device_id_mac_md5;
	int arr;			//ad_refresh_rate
	int ormma;
	int ado; 			//ad_orientation;
	int dvo; 			//device_orientation;
	int loccat;
	int locbrand;
	int dloc;
	int dlocmrq;
	int dloc_source;
	int dloc_sourcemrq;
	int dcity;
	int dcitymrq;
	int ddma;
	int ddmamrq;
	int dzip;
	int dzipmrq;
	int dstate;
	int dstatemrq;
	int dcountry;
	int dcountrymrq;
	int PA_dgeo;
} device_counter_t;

typedef struct {
	int uloc;
	int ulocmrq;
	int uloc_source;
	int uloc_sourcemrq;
	int ucity;
	int ucitymrq;
	int udma;
	int udmamrq;
	int uzip;
	int uzipmrq;
	int ustate;
	int ustatemrq;
	int ucountry;
	int ucountrymrq;
	int PA_ugeo;
} user_counter_t;

typedef struct {
	int ismob;
	int isapp;
	int iswapp;
	int isboth;

	int iswmob;
	int istab;
	int iswtab;
	int isweb;
	int isdbapp;
	int isbothgeosame;
	int iswappwv;   // WURFL APP WEB VIEW
	int iswjs;

	int PA_ispass;
	app_counter_t app_counter;
	device_counter_t device_counter;
	user_counter_t user_counter;
} mobile_param_stats_t;

typedef struct {
	int ismetric;
	int ismetview;
	int isinmobiview;
	int iseids;
	int impression;
} general_param_stats_t;

typedef struct {
	long pub_id;
	mobile_param_stats_t mobile_param_stats;
	general_param_stats_t general_param_stats;
} publisher_stats_t;

typedef struct pub_camp_stats_map {
    long camp_id;
    int eids;
    int cookied;
}pub_camp_stats_map_t;

typedef struct _pub_stats_table_t publisher_stats_table_t;
void free_pub_level_stats_table(publisher_stats_table_t *pub_level_stats_table);

publisher_stats_table_t * create_publisher_stats_table();
void increment_mobile_param_stats(mobile_param_stats_t *req_flags, long pub_id, publisher_stats_table_t *pub_stats_table);
void flush_publisher_stats_table(publisher_stats_table_t *pub_stats_table);
void increment_generic_param_stats(general_param_stats_t *req_flags, long pub_id, publisher_stats_table_t *pub_stats_table);

#define SET_MOBILE_PARAM_FLAG(object, key_name) (((mobile_param_flags->object.key_name)) = 1)
#define SET_MOBILE_TYPE_FLAG(key_name) (((mobile_param_flags->key_name)) = 1)


#define SET_GENERAL_PARAM_FLAG(object, key_name) (((general_param_flags->object.key_name)) = 1)
#define SET_GENERAL_TYPE_FLAG(key_name) (((general_param_flags->key_name)) = 1)

#endif
