/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __RTB_COOKIE_HANDLER_H_
#define __RTB_COOKIE_HANDLER_H_
#include "rt_types.h"
#include "error.h"
#include "fcgiapp.h"
#include "serversidestore_types.h"

/*===========================cookie handling RTB==========================
RTB per user cookie name is 'KRTBCOOKIE'
cookie format will be like this :
12-<cookie_string>&krtb32-<cookie_string>&krtb981-<cookie_string>
where ,
cookie value format is : {cam_id-<cookie_string>}
&krtb is used as a cookie_string delimmeter defined by RTB cookie handler.
=========================================================================*/

#define PIGGY_BACK_COOKIE_PREFIX "KRTBCOOKIE_"
#define NEW_PIGGY_BACK_COOKIE_PREFIX "R_"
#define PIGGY_BACK_COOKIE_NAME_NEW "R_%d"
#define PIGGY_BACK_COOKIE_NAME "KRTBCOOKIE_%d"
#define PIGGY_BACK_COOKIE_NAME_LEN 25
//#define MAX_PIGGY_BACK_TAGS 8
#define MAX_COOKIE_LEN 4096
#define PIGGY_BACK_COOKIE_DELETED_VALUE "-1"
#define CALL_COOKIESTORE_COOKIE "SSCS"
#define CALL_COOKIESTORE_COOKIE_TRUE "YES"

//kartik
//#define MAX_PIGGY_VAR_LEN 960
//~kartik
//#define MAX_PIGGY_VAR_LEN 1024
#define MAX_PIGGY_METACHARS_LEN 64
#define MAX_PIGGY_TAG_LEN 1024

#define KRTB_COOKIE_DELIM "&KRTB&"
//#define MAX_RTB_DSPS	40

//time period for RTB cookies
#define ZERO_SECOND		0

// #seconds in a day
#define ONE_DAY_SECONDS   (60 * 60 * 24)

typedef struct piggy_back_tags{
	long campaign_id;
	char tag[MAX_PIGGY_VAR_LEN + 1];
	int deleted_flag;
}piggy_back_tags_t;

/*to display piggy back elements*/
void display(piggy_back_tags_t *ptags, int nptags);

/*to construct cookie data using piggy back tags*/
int construct_cookie_using_tags(piggy_back_tags_t *ptags, int nptags, char *cookie_string);

/*parse cookie string to get tag's (key,val) pair*/
//int parse_token2(char *str,char *val1, char *val2, char *delim);

/*to construct piggy back list using cookie string*/
int get_cookie_piggy_back_tags(piggy_back_tags_t *ptags, int *nptags, const char *cookie_string);

char* get_piggy_back_cookie_pug(FCGX_Request req, int demand_partner_id);

/*to add/modify piggy back list using new tag from RTB call -- returns a ismodified flag*/
int update_piggy_back_tags(piggy_back_tags_t *ptags, int *nptags, int campaign_id,  int *ismodified, const char *tag);

/*to remove piggy back tag from list -- returns a ismodified flag*/
int remove_piggy_back_tags(piggy_back_tags_t *ptags, int *nptags, int campaign_id,  int *ismodified);

/*given campaign id get the tag from cookie*/
int get_piggy_back_tag(piggy_back_tags_t *ptags, int nptags, int campaign_id, int sibling_campaign_id, char *tag);

/*set piggy back cookie for a demand partner*/
int set_piggy_back_cookie(FCGX_Request request, int demand_partner_id, char * cookie_string, long int expiry_time);

/*get piggy back cookie contents for a demand partner*/
const char* get_piggy_back_cookie(FCGX_Request request, int demand_partner_id,int thread_id );

/*mark the user for deleting a specific DSPs cookie*/
void set_call_sscs_cookie(FCGX_Request request);

#endif
