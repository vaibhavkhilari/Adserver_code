/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef YAHOO_UTIL_H
#define YAHOO_UTIL_H   

#define SCRIPT_START_WITH_COMMENT "<script type=\"text/javascript\"><!--\n"
#define SCRIPT_END_WITH_COMMENT "//--></script>\n"
#define YAHOO_AD_SCRIPT \
	"<script type=\"text/javascript\" src=\"http://ypn-js.overture.com/partner/js/ypn.js\"> </script>\n"

#define YAHOO_AD_CLIENT  "ctxt_ad_partner="
#define YAHOO_AD_WIDTH  "ctxt_ad_width="
#define YAHOO_AD_HEIGHT  "ctxt_ad_height="
#define YAHOO_COLOR_BORDER  "ctxt_ad_bc="
#define YAHOO_COLOR_BG  "ctxt_ad_bg="
#define YAHOO_COLOR_LINK  "ctxt_ad_lc="
#define YAHOO_COLOR_URL  "ctxt_ad_uc="
#define YAHOO_COLOR_TEXT  "ctxt_ad_tc="
#define YAHOO_COLOR_CC  "ctxt_ad_cc="
#define YAHOO_PUBLISHER_ID  "pub-9650501864575984"
#define YAHOO_AD_CHANNEL  "ctxt_ad_section="
#define YAHOO_AD_PAGE_URL	"ctxt_ad_url="

#define YAHOO_AD_SCRIPT_MAX_SIZE	8192
#define YAHOO_TMP_BUFF_SIZE		2048
#define YAHOO_DEFAULT_PAGE_URL	"http://komli.com"

char *get_yahoo_adscript(char *client_id,
			int width,
			int height,
			char *bg_color,
			char *link_color,
			char *url_color,
			char *text_color,
			char *channel_id,
			int use_channel_flag,
			char *url);

char *get_yahoo_adscript_without_color(char *client_id,
			int width,
			int height,
			char *channel_id,
			int use_channel_flag,
			char *url);

#endif /* YAHOO_UTIL_H */
