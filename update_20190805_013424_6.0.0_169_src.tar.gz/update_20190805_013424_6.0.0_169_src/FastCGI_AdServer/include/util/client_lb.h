/*
	 PubMatic Inc. ("PubMatic") CONFIDENTIAL
	 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
*/


#ifndef __CLIENT_LB_H__
#define __CLIENT_LB_H__ 

#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "assert.h"
#include "error.h"


#define GOOD_HEALTH_SCORE 1500
#define AVG_HEALTH_SCORE 750
#define BAD_HEALTH_SCORE 500	/* should be greater than thread count */
#define RETRY_WAIT_PERIOD_SEC 300 /* health check time */

#define BACKEND_TIMEDOUT 1
#define BACKEND_SUCCESS 0

#define MAX_BACKEND_URL_LEN 1024 /* We are limiting the max len of backend url to 1024 */

typedef struct backend {
	unsigned int health_score; /* health score of Varnish backend machine */
	unsigned int last_down_timestamp; /* timestamp, when last time backend was down */
	char backend_url[MAX_BACKEND_URL_LEN + 1]; /* URL (http://IP:port/path) of backend */
	char *backend_host; /* Hostname in URL (IP:port) of backend */
	char *backend_path; /* Path in URL(/path) of backend */
} backend_t;

typedef struct backend_servers {
	unsigned int total_server_count; /* total servers under this backend unit */
	unsigned int up_server_count; /* current up server from this unit */
	backend_t* backend_list; /* list of backends */
} backend_servers_t;

int prepare_backend(backend_servers_t *backend_servers, const char *server_urls);
int get_server_id(backend_servers_t *backend_servers, const char *input_str, char* backend_url);
void update_server_health_score(backend_servers_t *backend_servers, int server_id, int status);

#ifdef CLIENTLB_DEBUG
#define CLIENTLB_DEBUGLOG(format, ...); fprintf(stderr, "\nCLIENTLB: " format " -> %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__);
#else
#define CLIENTLB_DEBUGLOG(format, ...);
#endif

#endif
