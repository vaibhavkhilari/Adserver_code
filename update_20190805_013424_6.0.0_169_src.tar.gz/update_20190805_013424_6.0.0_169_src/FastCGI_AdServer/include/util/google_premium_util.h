/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef GOOGLE_PREMIUMUTIL_H
#define GOOGLE_PREMIUMUTIL_H   

#define SCRIPT_START_WITH_COMMENT "<script type=\"text/javascript\"><!--\n"
#define SCRIPT_END_WITH_COMMENT "//--></script>\n"
#define GOOGLE_PREMIUM_AD_SCRIPT \
	"<script type=\"text/javascript\" src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\"> </script>\n"

#define GOOGLE_PREMIUM_AD_CLIENT	"google_ad_client="
#define GOOGLE_PREMIUM_AD_WIDTH  	"google_ad_width="
#define GOOGLE_PREMIUM_AD_HEIGHT  	"google_ad_height="
#define GOOGLE_PREMIUM_AD_FORMAT  	"google_ad_format="
#define GOOGLE_PREMIUM_AD_TYPE  	"google_ad_type="
#define GOOGLE_PREMIUM_COLOR_BORDER  	"google_color_border="
#define GOOGLE_PREMIUM_COLOR_LINK  	"google_color_link="
#define GOOGLE_PREMIUM_COLOR_TEXT  	"google_color_text="
#define GOOGLE_PREMIUM_AD_HOST  	"google_ad_host="
#define GOOGLE_PREMIUM_PUBLISHER_ID  	"pub-9650501864575984" /* This may change for premium */
#define GOOGLE_PREMIUM_AD_CHANNEL  	"google_ad_channel="
#define GOOGLE_PREMIUM_IMAGE_SIZE	"google_image_size="
#define GOOGLE_PREMIUM_COLOR_LINE	"google_color_line="
#define GOOGLE_PREMIUM_ADTEST		"google_ad_test="
#define GOOGLE_PREMIUM_COLOR_BG		"google_color_bg="

#define GOOGLE_PREMIUM_AD_SCRIPT_MAX_SIZE       8192
#define GOOGLE_PREMIUM_TMP_BUFF_SIZE            2048
char *get_google_premium_adscript(char *client_id,
			char *type,
			int width,
			int height,
			char *border_color,
			char *bg_color,
			char *link_color,
			char *text_color,
			int ad_host_flag,
			char *channel_id,
			int use_channel_flag);

char *get_google_premium_adscript_without_color(char *client_id,
			char *type,
			int width,
			int height,
			int ad_host_flag,
			char *channel_id,
			int use_channel_flag);

#endif /* GOOGLE_PREMIUM_UTIL_H */
