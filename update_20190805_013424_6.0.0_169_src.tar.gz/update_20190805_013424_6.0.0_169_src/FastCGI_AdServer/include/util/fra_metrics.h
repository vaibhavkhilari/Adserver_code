/*
PubMatic Inc. ("PubMatic") CONFIDENTIAL
Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.

NOTICE: All information contained herein is, and remains the property of
PubMatic. The intellectual and technical concepts contained herein are
proprietary to PubMatic and may be covered by U.S. and Foreign Patents,
patents in process, and are protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material is
strictly forbidden unless prior written permission is obtained from PubMatic.
Access to the source code contained herein is hereby forbidden to anyone
except current PubMatic employees, managers or contractors who have executed
Confidentiality and Non-disclosure agreements explicitly covering such access.

The copyright notice above does not evidence any actual or intended
publication or disclosure of this source code, which includes information
that is confidential and/or proprietary, and is a trade secret, of PubMatic.
ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, OR PUBLIC
DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN
CONSENT OF PubMatic IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE
LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE
AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
THAT IT MAY DESCRIBE, IN WHOLE OR IN PART. 
*/

#ifndef FRA_METRICS_H
#define FRA_METRICS_H

#include "error.h"
#include "db_connection.h"
#include "error_code.h"
#include "log_fw.h"

#include <assert.h>


#define FRA_METRICS_LIST_MAX_SIZE 100000
/* FRA_ECPM_PRECISION
 * 10 raised to 4
 * If you change ``FRA_ECPM_PRECISION``, you might want to change the
 * precision used for printing in ``fra_metrics_list_print``.
 */
#define FRA_ECPM_PRECISION 10000 


#define FRA_ECPM_INT_TO_DEC(x)  ((double) x / FRA_ECPM_PRECISION)
#define FRA_ECPM_DEC_TO_INT(x)  ((int)(x * FRA_ECPM_PRECISION))


/* Error Handeling
 * ===============
 */

#ifdef FRA_TEST
#define FRA_DEBUG(fmt, ...)  do { fprintf(stderr, "\nFRA_DEBUG::" fmt "  %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__); } while(0);
#else
#define FRA_DEBUG(fmt, ...)  do {  \
        char t[1024];  \
        t[0] = '\0';  \
        snprintf(t, 1023, fmt, ##__VA_ARGS__);  \
        t[1023] = '\0';  \
        elog(INFO, CODE_FRA_DEBUG, MOD_FRA_DEBUG, t, __FILE__, __LINE__);  \
} while (0);
#endif

#define FRA_ERROR(fmt, ...)  do { fprintf(stderr, "\nFRA_ERROR::" fmt "  %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__); } while(0);


/* Data Structures
 * ===============
 */

/* fra_metrics_list_key_t
 * ----------------------
 * This is the key used to access the FRA hash table.
 */
typedef struct fra_metrics_list_key {
        unsigned long pub_id;
        unsigned long camp_id;
} fra_metrics_list_key_t;

/* FRA Metrics List
 * ----------------
 * fra_metrics_t, fra_metrics_list_t
 *
 * Used to store all metrics used to guide the FRA recovery algorithm.
 * Data Structure: Hash Table with modulus hashing algorithm and linear
 * probing collision resolution.
 */
typedef struct fra_metrics {
        /* key
         * Key that is used to linear probe in the hash table
         */
        fra_metrics_list_key_t key;

        /* discount_sum
         * Sum of discounts made by FRA
         * The stored value must be divided by FRA_ECPM_PRECISION to get
         * the true bid value.
         */
        long int discount_sum;

        /* discount_impr_sum
         * Total impressions over with discounts were made by FRA
         */
        long int discount_impr_sum;

        /* recovery_sum
         * Sum of recovery made by RA
         * The stored value must be divided by FRA_ECPM_PRECISION to get
         * the true bid value.
         */
        long int recovery_sum;

        /* occupied
         * If key contains valid entry.  Need this instead of hash to avoid
         * race between generic thread, and FRA and RA threads.
         */
        int occupied;

        /* balance_recovery_mutex
         * Variable used to ensure mutual exclusion in the balance recovery
         * code (fra_balance_recovery).
         */
        int balance_recovery_mutex;
} fra_metrics_t;

typedef struct fra_metrics_list {
        fra_metrics_t metrics[FRA_METRICS_LIST_MAX_SIZE];

        /* size
         * Number of entries in the metrics list.
         * (Might be useful for optimisations.)
         */
        long int size;
} fra_metrics_list_t;


/* Function
 * ========
 */

// See the ``.c`` file for static function declarations.

/* fra_init
 * --------
 * Initialises internal data structures.
 * Call once at the start of the application.
 * Returns: ADS error code.
 */
int fra_init(void);

/* fra_refresh
 * -----------
 * Reads updates from DB.
 * Call once at start, and when DB changes are to be read.
 * Returns: ADS error code.
 */
int fra_refresh(const db_connection_t * kdb_conn);

int fra_db_fill_metrics_list(const db_connection_t * kas_conn);

/* fra_metrics_list_search_and_add_key
 * -----------------------------------
 * Add ``key`` to metrics list (if it doesn't already exist).
 * Returns: ADS error code.
 */
int fra_metrics_list_search_and_add_key(const fra_metrics_list_key_t * key);

/* fra_metrics_list_search_and_get
 * -------------------------------
 * Find a all metrics associated with ``key``.
 * Returns:
 *   Metrics that have ``occupied == 1`` (found)  OR
 *   NULL (not-found or error)
 */
fra_metrics_t * fra_metrics_list_search_and_get(const fra_metrics_list_key_t * key);

/* fra_metrics_list_search_and_get
 * -------------------------------
 * Print non-empty metrics (``occupied == 0``).
 */
void fra_metrics_list_print(void);

#endif  // FRA_METRICS_H
