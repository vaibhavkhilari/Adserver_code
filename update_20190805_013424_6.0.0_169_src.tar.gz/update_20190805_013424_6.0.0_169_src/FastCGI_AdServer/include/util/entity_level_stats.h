#ifndef ENTITY_STATS_H
#define ENTITY_STATS_H

#include "stats.h"
#include "string.h"
#include "video_stats.h"
#include "publisher_level_stats.h"

extern char *g_stats_datacenter_name;

typedef struct entity_stats_collection{
	stats_metric_t *entity_stats_metric;
	char key[STATS_KEY_MAX_SIZE];
	int len;
}entity_stats_collection_t;

typedef struct entity_stats{
	entity_stats_collection_t video_campaign_level_err;
	entity_stats_collection_t pub_camp_total_req;
	entity_stats_collection_t pub_camp_cookied_req;
	entity_stats_collection_t pub_camp_eids_req;
	entity_stats_collection_t pub_camp_cookied_eids_req;
}entity_stats_t;

#define VIDEO_CAMPAIGN_STAT_ERROR_CREATIVE "VIDEO:INV_CRTV:CAMP"
#define PUB_CAMP_TOTAL_REQ	"PC:TOTAL"
#define PUB_CAMP_COOKIED_REQ "PC:COOKIED"
#define PUB_CAMP_EIDS_REQ "PC:EIDS"
#define PUB_CAMP_EIDSCOOKIE_REQ "PC:EIDSCOOKIE"

#define INIT_ENTITY_STATS(entity_stat, metric_name) { \
					strcpy(entity_stat.name, metric_name); \
					entity_stat.count = 0; \
					}

#define INIT_ENTITY_STATS_COLLECTION(stats_collection, metric_name) { \
                    sprintf(stats_collection.key, "%s", metric_name); \
                    stats_collection.len = 0;\
		    stats_collection.entity_stats_metric = NULL; \
                    }

#define UPDATE_ENTITY_STAT_METRIC(stats_metric, stat_max_count) { \
		char stats_collection_buffer[STATS_KEY_MAX_SIZE + 10]; \
		stats_collection_buffer[0] = '\0'; \
                    if((int)stats_metric.count >= stat_max_count){ \
			sprintf(stats_collection_buffer,"%s:%s", stats_metric.name, \
				g_stats_datacenter_name); \
                        stats_add(stats_collection_buffer, stats_metric.count); \
                            stats_metric.count = 0; \
                        } \
                   }


void init_entity_stats(entity_stats_t *entity_stats);

int update_entity_stats(entity_stats_collection_t *entity_stats_collection, 
							int stats_collection_enable, 
							int stat_max_size, char *format, ...);

void add_pub_camp_stats(pub_camp_stats_map_t *pub_camp_stats_map, long pub_id, int stats_collection_enable,
				entity_stats_t *entity_stats);
#endif
