/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef FTRACK_UTIL_H
#define FTRACK_UTIL_H   
#include <stdio.h>
#include <time.h>
#define MAX_FTRACK_FILENAME	1024
#define MAX_RECORDS_IN_SINGLE_INSERT 1000
/* CREATE_SQL_FILES:1 to create sql files; CREATE_TSF:1 to create tsv files*/
#define CREATE_SQL_FILES 1
#define CREATE_TSF 1
#define UNKNOWN_IMPRESSION_ID "unknown_impression"

typedef struct ftrack_context {
	time_t	start_time;		/* Start time */
	time_t	track_time;		/* Current time for tracking */
	long	time_limit;		/* time limit for writing to the same file */
	char	track_file[MAX_FTRACK_FILENAME];	/* File name of the file to write */
	char	track_dir[MAX_FTRACK_FILENAME];	/* Track file directory */
	char	batch_dir[MAX_FTRACK_FILENAME];		/* Directory name to move the old file after time limit is over */
	int		file_desc;
	int 	adclick_record_counter; /* keep track of number of record in single insert */
	int 	adtrack_record_counter; /* keep track of number of record in single insert */
	int 	contextual_track_record_counter; /* keep track of number of record in single insert */
	int 	zone_track_record_counter; /* keep track of number of record in single insert */
	int 	pixel_blocked_record_counter; /* keep track of number of records in single insert */
	FILE	*fp;	/* FILE pointer of the file used for writing */
} ftrack_context_t;

typedef struct ftrack_unix_tstamp {
	time_t stamp;
	long lstamp;
} ftrack_unix_tstamp_t;

/* constants */
#define FTRACK_FHANDLE(a) a->fp

/* functions */
int init_ftrack_context(ftrack_context_t *ftrackcontext, long time_limit, char *write_filename, char *new_file_dir, char *old_file_dir);
long get_ftrack_tstamp(ftrack_unix_tstamp_t *out_stamp);
int ftrack_backup(ftrack_context_t *ftrackcontext, ftrack_unix_tstamp_t *ftrackunixtimestamp);
int free_ftrack_context(ftrack_context_t *ftrackcontext);
int __free_ftrack_context(ftrack_context_t *);
#endif /* FTRACK_UTIL_H */
