/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __HIMPA_EDGE_SIDE_RULE_ENGINE_UTIL_H_
#define __HIMPA_EDGE_SIDE_RULE_ENGINE_UTIL_H_

#include "ad_server_types.h"
#include "rt_types.h"
#include "error.h"
#include "errno.h"

#define HIMPA_USERBLOCK_COOKIE_NAME "HPAUSRBK_%d_%d"
#define HIMPA_TEMP_USERBLOCK_COUNTER_COOKIE_NAME "TEMPHPAUSRBKCNT_%d_%d"
#define ONE_DAY_SECONDS (((60 * 60) * 24) * 1)
#define PUBMATIC_DOMAIN "pubmatic.com"

#define MAX_HIMPA_COOKIE_LENGTH (30 + 1)
#define MAX_HIMPA_COOKIE_VALUE_LENGTH (10 + 1)

/*parse site and section ids from kadzone parameter in request params structure*/
int parse_ga_site_section_from_zone(char *zone, int *site_id, int *section_id);

/*wrapper function to apply edge server custom rules*/
int apply_edge_server_rules(FCGX_Request request, 
				cache_handle_t *cache_handle, 
				db_connection_t *dbconn, 
				const selected_compaign_context_t *selected_camp_cntx,
				ad_server_req_param_t *req_params,
				ad_server_req_gen_param_t *in_req_gen_params);

#endif /*__HIMPA_EDGE_SIDE_RULE_ENGINE_UTIL_H_*/

