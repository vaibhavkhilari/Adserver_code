/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */

/* 
 * File:   video_vast2.h
 * Author: Srinivas
 *
 * Created on 14 July, 2015, 10:48 AM
 */

#ifndef VIDEO_VAST2_H 
#define	VIDEO_VAST2_H

#include "vast.h"
#include "video_xml.h"
#include "string_util.h"
#include "ad_server_types.h"
#include "ad_server_main_utils.h"
#include "third_party_pixel.h"

#ifdef	__cplusplus
extern "C" {
#endif

//Validates if the creative given is a VAST XML or http URL
extern int validate_video_creative(const char * vid_creative, int is_inline_requested);

//Inject PM impression, PM events and PM extensions into given VAST
extern int inject_into_video_xml (video_xml_t *buf,
                           const char *src_xml, 
                           const char *impression_tracking_uri, 
                           const char* event_tracking_uri,
                           const char* click_tracking_uri,
                           const char *pm_ext_buf,
                           int video_events_bit_map, 
                           int is_skippable);

//prepares and appends pm api extension section into pm extensions buffer
extern int append_pm_api_extention_section(pm_ext_xml_t *buff, double ecpm, const char *winning_deal_id, long advertiser_id);

//Prepare VAST wrapper from given http URL
extern int form_vast_wrapper_response(video_xml_t * buff, const char *vastURI,
					const char *impression_tracking_uri, 
                                        const char *event_tracking_uri, 
                                        const char *click_tracking_uri, const char *pm_ext_buf,
					unsigned long ad_id, int major, int minor,
					int event_bits_map);

extern int set_puggixml_vast_context(vast_context_t *vast_context,
		int vast_version,
		int event_bit_map,
		enum VideoPlayer video_player,
		third_party_pixel_t* third_party_pixels,
		int nthird_party_pixel,
		const selected_campaign_attribute_t* selected_camp,
		int linearity,
		const ad_server_additional_params_t * additional_params);

#ifdef	__cplusplus
}
#endif

#endif	/* VIDEO_VAST2_H */

