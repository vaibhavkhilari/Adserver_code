/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef AD_SERVER_CLICK_TRACK_UTIL_H   
#define AD_SERVER_CLICK_TRACK_UTIL_H   

#include "ad_server_types.h"

/*adnetwork's supporting click track*/
#define ADTEGRITY_OPTIMIZER_ID 30
#define KITARA_OPTIMIZER_ID 157
#define CPX_INTERACTIVE_OPTIMIZER_ID 60
#define BANNERCONNECT_OPTIMIZER_ID 41
#define PUNTOFOX_OPTIMIZER_ID 178
#define LUCIDCAPITALONECAMPAIGN_OPTIMIZER_ID 219
#define MEDIAMATHPROACTIVCAMPAIGN_OPTIMIZER_ID 233
#define PUBLISHER_NETWORK 165
#define ADVERTISING_COM_FIXED 661
#define PUBLISHER_NETWORK_1 853
#define PUBLISHER_NETWORK_2 1067
#define DAILY_DEALS 1634
#define MASTERCARD 1636
#define APPLE_CERTIFIED 1635
#define PHOTOCENTER 1637
#define FASHION 1633

#define MAX_ADSERVERS_WITH_CLICK_TRACK_SUPPORT 16

int is_clicktrack_support_available(int adserver_id);

int get_click_url(char **url, char *query_string, char *key, const char *browser);

int decode_click_url(char **url, char *source);

#endif /* AD_SERVER_CLICK_TRACK_UTIL_H */
