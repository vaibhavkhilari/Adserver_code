/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __NATIVE_REQUEST_H__
#define __NATIVE_REQUEST_H__

#include "native_common.h"

// Native Request Keys
#define NATIVE_REQUEST_OBJECT_KEY                     "native"
#define NATIVE_VERSION_KEY                            "ver"
#define NATIVE_REQUEST_LAYOUT_KEY                     "layout"
#define NATIVE_REQUEST_ADUNIT_KEY                     "adunit"
#define NATIVE_REQUEST_PLACEMENT_COUNT_KEY            "plcmtcnt"
#define NATIVE_REQUEST_SEQUENCE_KEY                   "seq"
#define NATIVE_REQUEST_EXTENSION_KEY                  "ext"

// Native Request Assets Object Keys
#define NATIVE_REQUEST_ASSET_ARR_KEY                  "assets"
#define NATIVE_REQUEST_ASSET_ID_KEY                   "id"
#define NATIVE_REQUEST_ASSET_REQUIRED_KEY             "required"

// Native Request Assets Title Object Keys
#define NATIVE_REQUEST_ASSET_TITLE_KEY                 "title"
#define NATIVE_REQUEST_ASSET_TITLE_LEN_KEY             "len"

// Native Request Assets Image Object Keys
#define NATIVE_REQUEST_ASSET_IMAGE_KEY                  "img"
#define NATIVE_REQUEST_ASSET_IMAGE_TYPE_KEY             "type"
#define NATIVE_REQUEST_ASSET_IMAGE_WIDTH_KEY            "w"
#define NATIVE_REQUEST_ASSET_IMAGE_MIN_WIDTH_KEY        "wmin"
#define NATIVE_REQUEST_ASSET_IMAGE_HEIGHT_KEY           "h"
#define NATIVE_REQUEST_ASSET_IMAGE_MIN_HEIGHT_KEY       "hmin"
#define NATIVE_REQUEST_ASSET_IMAGE_MIMES_KEY            "mimes"

// Native Request Assets Data Object Keys
#define NATIVE_REQUEST_ASSET_DATA_KEY                   "data"
#define NATIVE_REQUEST_ASSET_DATA_TYPE_KEY              "type"
#define NATIVE_REQUEST_ASSET_DATA_LEN_KEY               "len"

// Native Request Assets Video Object Keys
#define NATIVE_REQUEST_ASSET_VIDEO_KEY                  "video"
#define NATIVE_REQUEST_ASSET_VIDEO_MIMES_KEY            "mimes"
#define NATIVE_REQUEST_ASSET_VIDEO_MIN_DURATION_KEY     "minduration"
#define NATIVE_REQUEST_ASSET_VIDEO_MAX_DURATION_KEY     "maxduration"
#define NATIVE_REQUEST_ASSET_VIDEO_PROTOCOL_KEY         "protocols"

// Native Request Key Max Length
#define NATIVE_VERSION_LEN                               7
#define NATIVE_REQUEST_ASSET_MIME_LEN                    100      


#define NATIVE_ASSET_IMAGE_TYPE_ICON                     1
#define NATIVE_ASSET_IMAGE_TYPE_LOGO                     2
#define NATIVE_ASSET_IMAGE_TYPE_MAIN                     3


#define NATIVE_ASSET_DATA_TYPE_SPONSORED                 1
#define NATIVE_ASSET_DATA_TYPE_DESCRIPTION               2
#define NATIVE_ASSET_DATA_TYPE_RATING                    3
#define NATIVE_ASSET_DATA_TYPE_LIKES                     4
#define NATIVE_ASSET_DATA_TYPE_DOWNLOADS                 5
#define NATIVE_ASSET_DATA_TYPE_PRICE                     6
#define NATIVE_ASSET_DATA_TYPE_SALES_PRICE               7
#define NATIVE_ASSET_DATA_TYPE_PHONE                     8
#define NATIVE_ASSET_DATA_TYPE_ADDRESS                   9
#define NATIVE_ASSET_DATA_TYPE_DESCRIPTION_2             10
#define NATIVE_ASSET_DATA_TYPE_DISPLAY_URL               11
#define NATIVE_ASSET_DATA_TYPE_CTA_TEXT                  12


//Object invalid reasons
#define NATIVE_ASSETS_TITLE_LEN_NOT_FOUND                21
#define NATIVE_ASSETS_DATA_TYPE_NOT_FOUND                22
#define NATIVE_ASSETS_VIDEO_MIMES_NOT_FOUND              23
#define NATIVE_ASSETS_VIDEO_MIN_DUR_NOT_FOUND            24
#define NATIVE_ASSETS_VIDEO_MAX_DUR_NOT_FOUND            25
#define NATIVE_ASSETS_VIDEO_PROTO_NOT_FOUND              26

#define MAX_NETWORK_NATIVE_ASSETS            15

// Native Request Object
typedef struct native_mime {
   char** mimes;
   int num_mimes;
} native_mime_t;

typedef struct native_request_title {
   int len;
//   extension_t ext;
} native_request_title_t;

typedef struct native_request_image {
   int type;
   int width;
   int min_width;
   int height;
   int min_height;
   native_mime_t mimes;
//   extension_t ext;
} native_request_image_t;

typedef struct native_request_video {
   native_mime_t mimes;
   int min_duration;
   int max_duration;
//   int *protocols;                               //commenting for now
//   extension_t ext;
} native_request_video_t;

typedef struct native_request_data {
   int type;
   int len;
//   extension_t ext;
} native_request_data_t;

typedef struct native_request_asset {
   int id;
   int required;
   int type;
   union {
      native_request_title_t title;
      native_request_image_t image;
      native_request_video_t video;
      native_request_data_t data;
   } native_asset;
//   extension_t ext;
} native_request_asset_t;

typedef struct native_request_assets_stats {
   int num_required_assets;
} native_request_assets_stats_t;

typedef struct native_request {
   char version[NATIVE_VERSION_LEN + 1];
   int layout;
   int adunit;
   int placement_count;
   int sequence;
   native_request_asset_t *asset_array;
	int num_assets;
//   extension_t parent_ext;
   native_request_assets_stats_t asset_stats;
   void (*free_native_request)(struct native_request *);
} native_request_t;

typedef struct network_native_asset {
   native_request_asset_t *native_asset; 
   int network_asset_id;
} network_native_asset_t;

typedef struct network_native_assets_mapping {
   network_native_asset_t assets[MAX_NETWORK_NATIVE_ASSETS];
   int num_assets;
} network_native_assets_mapping_t;

int request_asset_compare(const void *first, const void *second);

void init_native_request_object(native_request_t *native_obj);

void print_parsed_native_request_object(const native_request_t *parsed_native_object);

int native_request_parser(const char *json_request, native_request_t *parsed_native_object);

void free_native_request(native_request_t *parsed_native_object);

#endif /* __NATIVE_REQUEST_H__ */
