/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef CONFIG_H
#define CONFIG_H   
#include "property.h"

/* Fixed configuration properties */
#define CONFIG_FILE_NAME    "/etc/adserver.properties"
#define ADSERVER_THREAD_COUNT "adserver.thread.count"
/* Signal Hanlders catch shutdown and coredump events; In case of shutdown event, threads will go down gracefully
 * In case of coredump event, the decision is taken as per the config "enable.coredumps" */
#define IS_SIGNAL_HANDLERS_ENABLED "enable.signal.handlers"
#define IS_COREDUMPS_ENABLED "enable.coredumps"
//Minimum percentage of threads to continue if threads are exiting due to coredump signal
#define MIN_THREAD_THRESHOLD_PERCENT "minimum.thread.threshold.percent"

#define ADTRACKER_THREAD_COUNT "adtracker.thread.count"
#define AD_TRACKER_DOMAIN_NAME	"adtracker.domain.name"
#define PIXEL_TRACKER_DOMAIN_NAME "pixel.tracker.domain.name"
#define AKAMAI_TRACKER_DOMAIN_NAME "ak.tracker.domain.name"
#define CLICK_TRACKER_DOMAIN_NAME	"clicktracker.domain.name"
#define AD_SERVER_DOMAIN_NAME   "adserver.domain.name"
#define DOMAIN_NAME	"domain.name"
#define LAYER_DOMAIN_NAME	"layer.domain.name"
#define GEO_BINARY_FILE_PATH	"geo.binary.file.path"
#define ISP_BINARY_FILE_PATH	"isp.binary.file.path"
#define NET_SPEED_BINARY_FILE_PATH	"net.speed.binary.file.path"
#define NET_ACUITY_DATA_DIR	"netacuity.data.dir"
#define CONTEXTUAL_DOMAIN_NAME	"contextual.domain.name"
#define ADSERVER_ODBC_DSN_NAME "adserver.odbc.dsn.name"
#define ADSERVER_ODBC_DSN_USERNAME "adserver.odbc.dsn.user.name"
#define ADSERVER_ODBC_DSN_PASSWORD "adserver.odbc.dsn.user.password"
#define ADSERVER_CACHE_SERVERS "adserver.cache.servers"
#define ADSERVER_DSTR_CACHE_SERVERS "adserver.distributed.cache.servers"
#define ADSERVER_CONTEXTUAL_CACHE_SERVERS "adserver.contextual.cache.servers"
#define ADSERVER_CACHE_ELEMENT_TIMEOUT "adserver.cache.element.timeout"
#define ADSERVER_CONTEXTUAL_CACHE_ELEMENT_TIMEOUT "adserver.contextual.cache.element.timeout"
#define CONTEXTUAL_RESPONSE_TIMEOUT "contextual.response.timeout"
#define CONTEXTUAL_CONNECTION_TIMEOUT "contextual.connection.timeout"
#define ADSERVER_ADSP_HASHQUEUES "adserver.adsp.hashqueues"
#define ADSERVER_ADSP_HASHELEMENTS "adserver.adsp.hashelements"
#define ADSERVER_ALLOW_CONFIG_RELOAD "adserver.config.reload"
#define ADSERVER_GEO_ENABLED_FLAG "adserver.geo.enabled.flag"
#define ADSERVER_FREQ_ENABLED_FLAG "adserver.frequency.enabled.flag"
#define ADSERVER_FTE_ENABLED_FLAG "adserver.fte.enabled.flag"
#define ADSERVER_BIDDING_ENABLED_FLAG "adserver.bidding.enabled.flag"
#define ADSERVER_DSS_FREQUENCY_TIMEWINDOW "adserver.dss.frequency.timewindow"
#define ADSERVER_CONTEXTUAL_TRACKING_ENABLED_FLAG "adserver.contextual.tracking.enabled.flag"
#define ADSERVER_ADHOC_LOGGING_ENABLED_FLAG "adserver.adhoc.logging.enabled.flag"
#define ADTRACKER_ODBC_DSN_NAME "adtracker.odbc.dsn.name"
#define ADTRACKER_ODBC_DSN_USERNAME "adtracker.odbc.dsn.user.name"
#define ADTRACKER_ODBC_DSN_PASSWORD "adtracker.odbc.dsn.user.password"
#define ADTRACKER_TRACKING_FILE_DIR	"adtracker.tracking.file.dir"
#define ADTRACKER_TRACKING_TSV_FILE_DIR "adtracker.tracking.tsv.file.dir"
#define ADTRACKER_BATCH_FILE_DIR	"adtracker.batch.file.dir"
#define ADTRACKER_TSV_BATCH_FILE_DIR "adtracker.tsv.batch.file.dir"
#define ADTRACKER_FILE_TYPE "adtracker.file.type"
#define ADTRACKER_TSV_FILE_TYPE "adtracker.tsv.file.type"
#define ADTRACKER_IMPRESSION_TRACKING_FILE_SUFFIX	"adtracker.impression.tracking.file.suffix"
#define ADTRACKER_CLICK_TRACKING_FILE_SUFFIX	"adtracker.click.tracking.file.suffix"
#define ADTRACKER_ACTIVITY_TRACKING_FILE_SUFFIX	"adtracker.activity.tracking.file.suffix"
#define ADTRACKER_CONTEXTUAL_TRACKING_FILE_SUFFIX	"adtracker.contextual.tracking.file.suffix"
#define ADTRACKER_ZONE_TRACKING_FILE_SUFFIX "adtracker.zone.tracking.file.suffix"
#define ADTRACKER_PIXEL_BLOCKED_TRACKING_FILE_SUFFIX "adtracker.pixelblocked.tracking.file.suffix"
#define ADTRACKER_VIDEO_TRACKING_FILE_SUFFIX "adtracker.video.tracking.file.suffix"
#define ADTRACKER_DATAMOVE_TIME_PERIOD	"adtracker.datamove.time.period"
#define ADTRACKER_CLICK_TRACKING_FILE_SUFFIX_DEFAULT "click"
#define ADTRACKER_ZONE_TRACKING_FILE_SUFFIX_DEFAULT "zone"
#define ADTRACKER_IMPRESSION_TRACKING_FILE_SUFFIX_DEFAULT "impression"
#define ADTRACKER_ACTIVITY_TRACKING_FILE_SUFFIX_DEFAULT "activity"
#define ADTRACKER_CONTEXTUAL_TRACKING_FILE_SUFFIX_DEFAULT "contextual"
#define ADTRACKER_PIXEL_BLOCKED_TRACKING_FILE_SUFFIX_DEFAULT "pixel_blocked"
#define ADTRACKER_VIDEO_TRACKING_FILE_SUFFIX_DEFAULT "video"
#define ADTRACKER_CONNECTION_TIMEOUT "adtracker.curl.connection.timeout"
#define ADTRACKER_TIMEOUT "adtracker.curl.timeout"
#define ADSERVER_ZONEID_LIMIT "adserver.zoneid.limit"
#define ADSERVER_RTB_ENABLE_FLAG "adserver.realtimebidding.enable.flag"
#define ADSERVER_DATACENTER_ID "adserver.datacenter.id"
#define ADSERVER_STATS_COLLECTION_ENABLE "adserver.stats.collection.enable.flag"
#define ADSERVER_REQUEST_PARAM_LOG "adserver.request.param.log"
#define MMAP_CONFIG_RELOAD_FLAGS_FILE_NAME "mmap.config.reload.flags.file.name"
#define SECURE_AD_TRACKER_DOMAIN_NAME "secure.adtracker.domain.name"
#define PIGGY_BACK_COOKIE_NEW_NAME  "piggyback.cookie.newname"
#define INPC_MEM_SIZE  "inpc.mem.size.in.mb"
#define DNT_HONOR_FLAG	"dnt.honor.enable.flag"
#define AUD_ODBC_DSN_NAME "audience.odbc.dsn.name"
#define AUD_ODBC_DSN_USERNAME "audience.odbc.dsn.user.name"
#define AUD_ODBC_DSN_PASSWORD "audience.odbc.dsn.user.password"

#define WURFL_CURL_URL "wurfl.curl.url"
#define WURFL_CONNECTION_TIMEOUT "wurfl.curl.con.timeout"
#define WURFL_REQUEST_TIMEOUT "wurfl.curl.req.timeout"
#define WURFL_ENABLED "wurfl.enabled"
#define MOBILE_NETWORK_TIMEOUT "mob.nw.timeout"
#define UPDATE_THREAD_WAITTIME "update.thread.waittime"
#define USER_IP_MASKING "user.ip.masking"
#define ADSERVER_COOKIESTORE_ENABLED_FLAG "adserver.cookiestore.enabled.flag"

#define CURL_REQUEST_CONNECTION_TIMEOUT "curl.request.connection.timeout"
/*Audience parameters */
#define ADSERVER_AUDIENCE_ENABLED "adserver.audience.enabled.flag" 
#define ADSERVER_AUDIENCE_URL "adserver.audience.url"
#define ADSERVER_AUDIENCE_CONNECTION_TIMEOUT "adserver.audience.connection.timeout"
#define ADSERVER_AUDIENCE_REQUEST_TIMEOUT "adserver.audience.request.timeout"
#define AUDIENCE_TRIE_REGENERATION_PERIOD "aud.trie.regeneration.interval"
#define CACHEPUSHBACK_RESTIMATION_TIME_IN_MINUTES "cachepushback.reestimation.time"
#define DATACENTER_AWARNESS_ENABLED "datacenter.awarness.enabled.flag"
#define CACHE_PUSHBACK_SITE_ID "cache.pushback.site.id"
#define CACHE_PUSHBACK_TWEAK_REESTIMATION_TIME_IN_MINUTES "cache.pushback.tweak.reestimation.time"
/*config required for icap new algo */
#define ICAP_MAX_THREAD_WORKING_ON_FINISHING_ICAP "icap.maxthread.on.finishing.icap"
#define ICAP_FINISHING_APPROACH_COUNT "icap.finishing.approach.count"
/* centralised icap enabled flag for impression cap if its value is 0 then old approach will work*/
#define CENTRALISED_ICAP_ENABLED  "centralised.icap.enabled.flag"
#define CITRUS_LEAF_ENABLED       "citrusleaf.enabled.flag"
#define ADSERVER_ADTRUTH_ENABLED  "adserver.adtruth.enabled.flag"
#define MODULE_ENABLED  "module.enabled.flag"
#define FATAL_LOG_FILE_NAME  "fatal.log.file.name"
#define DEBUG_RESPONSE_ENABLED "debug.response.enabled.flag"
/*conf for enabling fcap new approach*/
#define ACTIVE_TAG_NEW_APPROACH_ENABLED "active.tag.new.approach"
/* Set the percent of impressions for which time logging should be performed */
#define LOG_TIME_PC_FILE "adserver.logtime.pc"
#define DISABLE_DISTRIBUTED_CACHE "disable.distributed.cache.flag"

#define ENABLE_GDPR_CONSENT_PARSER_SERVICE "enable.gdpr.consent.parser.service"

/* Various required constants */
#define MAX_CONFIG_LINE_LEN	4096
#define COMMENT_CHAR	'#'
#define PROPDEF_CHAR	"="

int get_config_properties(
		char *filename,
		property_list_t **conf_properties);

#endif /* CONFIG_H */
