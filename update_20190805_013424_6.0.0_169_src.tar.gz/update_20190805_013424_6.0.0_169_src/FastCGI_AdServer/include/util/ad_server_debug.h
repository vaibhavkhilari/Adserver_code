/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef AD_SERVER_DEBUG_H
#define AD_SERVER_DEBUG_H
#include "ad_server_types.h"
#include "fte_types.h"

#define FREQUENCY_CAPPING "Eliminated AdNetworks: Frequency Capping"
#define IMPRESSION_CAPPING "Eliminated AdNetworks: Impression Capping"
#define NETWORK_IMPRESSION_CAPPING "Eliminated AdNetworks: Network Level Impression Capping"
#define NWRETARGETTING_FILTER "Eliminated AdNetworks: AdNetwork Retargetting"
#define CAMPAIGN_FREQ_FILTER "Frequency Filter: Eliminated CampaignId:"
#define GEO_FILTER "Geo Filter: Eliminated CampaignId:"
#define BROWSER_FILTER "Browser Filter: Eliminated CampaignId:"
#define ISP_FILTER "ISP Filter: Eliminated CampaignId:"
#define BOT_INVENTORY_FILTER "Bot Inventory Filter: Eliminated CampaignId:"
#define COPPA_COMPLIANCE_FILTER "COPPA Filter: Eliminated Campaign Id:"
#define NCB_IMPRESSION_FILTER "NCB Filter: Eliminated Campaign Id:"
#define USER_DEFAULT_CAMPAIGN_FILTER "Default Filter: Eliminated Campaign Id:"
#define CONNECTION_FILTER "CONNECTION Filter: Eliminated CampaignId:"
#define OS_FILTER "OS Filter:Eliminated CampaignId:"
#define PLATFORM_FILTER "Platform Filter:Eliminated CampaignId:"
#define CAMPAIGN_IMPRESSION_CAP "Campaign Impression Capping: Elininated CampaignId:"
#define TIME_TARGETTING_FILTER "Time Targetting Filter: Eliminated CampaignId:"
#define URL_CAPPING_FILTER "URL Capping: Eliminated campaign Id:"
#define GEO_PRIORITY_FILTER "Geo Priority Filter: Campaign Id:"
#define RTB_FILTER_TIMEOUT "RealTime TimeOut Filter: Campaign Id:"
#define RTB_FILTER_ZEROBID "RealTime ZeroBid Fillter: Campaign Id:"
#define RTB_FILTER_REQUEST_ID_MISMATCH "RealTime Request Id mismatch Filter: Campaign Id:"
#define RTB_FILTER_INVALID_BID "RealTime Invalid Bid Filter: Campaign Id:"
#define BUDGET_FILTER "Budget Filter: Campaign_id:"
#define ACTIVE_ACCOUNTS_FROM_DB "Active Accounts list from DB"
#define POST_DSS_PROCESSING		"After Applying DSS Algo"
#define REST_OF_THE_WORLD_SETTING "Moving to Rest Of the World. Settings:"
#define ACTIVE_ACCOUNTS_LIST_GEO "Geo: Active Accounts list"
#define CAMPAIGN_RETARGETTING_FILTER "Retargetting Filter: Campaign Id:"
#define CREATIVE_CATEGORY_FILTER "Creative Category Filter: Creative Id:"
#define CAMPAIGN_CREATIVE_FILTER "Campaign Creative Category Filter: Campaign Id:"
#define CAMPAIGN_PIXEL_LESS_TARGETTING_FILTER "Pixel Less Targetting Filter: Campaign Id:"
#define AUDIENCE_TARGETING "Audience targeting filter: Eliminated CampaignId:"
#define AD_MAKE_MODEL_FILTER "Make Model Filter:Eliminated CampaignId:"
#define AD_DEVICE_CAPABILITY_FILTER "Device Capability Filter:Eliminated CampaignId:"
#define CREATIVE_REVIEW_FILTER "Creative Review Filter: CampaignId:"
#define BID_PRICE_DECRYPTION_FAILURE_FILTER "Bid Price Decryption Failure: CampaignId:"
#define FILTER_BID_WITHOUT_LP "Publisher wants landing page but not sent by the campaign: CampaignId:"
#define CAM_AD_CODE_TYPE_FILTER "Ad code type filter , CampaignId :"
#define VIDEO_PARAMS_FILTER "VIDEO: Mandatory params missing camp id:"
#define VIDEO_CREATIVE_TYPE_FILTER "Video Creative type filter, camp id:"
#define CAM_PROTOCOL_FILTER "Video, Protocol Id filter Camp Id :"
#define VIDEO_FLAG_DISABLE "VIDEO: use_video_params 0, Camp id :"
#define AUDIO_FLAG_DISABLE "AUDIO: use_audio_params 0, Camp id :"
#define NATIVE_FLAG_DISABLE "NATIVE: supports_native_ad_format 0, Camp Id:"
#define PUB_CAM_GEO_FILTER "Pub Camp Geo Filter, Camp Id:"
#define COOKIED_REQUEST_FILTER "Cookied Request Filter, Camp Id:"
#define NONCOOKIED_REQUEST_FILTER "NON Cookied Request Filter, Camp Id:"
#define BRC_ANY_MANDATORY_MISSING_FILTER "FILTERED Due to one of the mobile pub latlong, device id, appstore url not found Camp Id:"
#define BRC_ALL_MANDATORY_MISSING_FILTER "FILTERED Due to all of the mobile pub latlong, device id, appstore url not found Camp Id:"
#define BRC_THROTTLE_PERCENT_FILTER "FILTERED Due to publisher/campaign throttle percent Camp Id:"
#define BRC_AD_FOLD_POSITION_FILTER "FILTERED Due to ad fold position does not match with camp setting Camp Id:"
#define FILTER_BID_CURRENCY_CODE "Currency code filter: CampaignId:"

void print_campaign_auction_table(FCGX_Request request, int print_in_browser_flag, publisher_site_ad_campaign_list_t *adcampaigns, int nelements, double bidding_ecpm, int thread_id);

void print_input_params(FCGX_Request request,int print_in_browser_flag, ad_server_req_gen_param_t *gen_param, ad_server_req_param_t *params);

void print_eliminated_networks(FCGX_Request request, int print_in_browser_flag, ad_server_additional_params_t *additional_params, int start_index, char * filter);

void print_filtered_campaigns(FCGX_Request request, int print_in_browser_flag,  long campaign_id, char *filter);

void print_adnetwork_auction_table(FCGX_Request request, int print_in_browser_flag,  ad_active_account_t **ad_active_account, int nelements, char *filter);

void print_geo_settings(FCGX_Request request, int print_in_browser_flag, const ad_geo_settings_t *ad_geo_settings, int nelements);

void print_geo_id(FCGX_Request request, int print_in_browser_flag, int *geo_list);

void print_min_max_water_mark(FCGX_Request request, int print_in_browser_flag, long min, long max, int max_flag);

#endif
