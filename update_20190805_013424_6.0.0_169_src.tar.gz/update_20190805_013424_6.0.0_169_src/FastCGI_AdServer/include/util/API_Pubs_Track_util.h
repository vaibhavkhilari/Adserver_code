/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef API_Pubs_Track_util
#define API_Pubs_Track_util

#include "API_Pubs_Track_thread.h"
#include "API_Pubs_Thread.h"
#include "API_Pubs_Track.h"

int set_configuration_APIPubsDemandSafety();
tracking_params_api_demand_safety_t* get_tracking_params_api_demand_safety(const char *in_query_string);
int add_record_api_demand_safety(api_pubs_tracking_context_t *context,
                            long pubId,
                            long site_id,
														long ad_id,
                            char *pub_pgURL,
                            char *ret_pgURL,
                            char *ret_refURL,
                            long timestamp);
/*int add_record_api_demand_safety(api_pubs_tracking_context_t *context,
                            long pubId,
                            long site_id,
														long ad_id,
                            char *pub_pgURL,
                            char *ret_pgURL,
                            char *ret_refURL,
                            long timestamp);*/

int init_tracking_context_api_demand_safety(api_pubs_tracking_context_t* ftrackcontext,
                long time_limit,
                char *write_filename,
                char *new_file_dir,
                char *old_file_dir);

int __backup_tracking_file(api_pubs_tracking_context_t* ftrackcontext);

int __free_tracking_context_api_demand_safety(api_pubs_tracking_context_t* ftrackcontext);

int free_tracking_context_api_demand_safety(api_pubs_tracking_context_t* ftrackcontext);

long get_timestamp(timestamp_t* out_stamp);

int backup_tracking_file(
                api_pubs_tracking_context_t* ftrackcontext,
                timestamp_t* ftrackunixtimestamp);


//void static init_track_params(data_recipt_t *current_data_recipt);
//int fwriter_init_api_demand_safety(fwriter_data_t *fwriter_data, int (*set_configuration)(fwriter_data_t *data);


#endif
