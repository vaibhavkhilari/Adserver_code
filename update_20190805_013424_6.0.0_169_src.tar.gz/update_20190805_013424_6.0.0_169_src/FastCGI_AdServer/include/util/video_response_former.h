/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __VIDEO_RESPONSE_FORMER_H__
#define __VIDEO_RESPONSE_FORMER_H__
#include "ad_server_types.h"
#include "ad_server_main_utils.h"
#include "video_xml.h"
extern void prepare_image_syncup_url(char * image_syncup_url_buf,
		        const ad_server_req_param_t* params,
		        const ad_server_additional_params_t * additional_params,
		        const fte_additional_params_t * fte_additional_params);

int form_video_response (video_context_t *video_context, video_xml_t *buf, //20k buffer variable on stack.
		const char *pubmatic_uid,
		const ad_server_req_param_t* params,
		selected_compaign_context_t *selected_camp_cntx, int selected_camp_idx,
		ad_server_additional_params_t * additional_params,
		const fte_additional_params_t * fte_additional_parameters,
		db_connection_t *dbconn,
		cache_handle_t *cache_handle,
		const ad_server_req_gen_param_t *gen_params
		);

int update_native_vast_xml(video_xml_t *buf, const char *src_xml,
		int video_events_bit_map,
		const selected_campaign_attribute_t* selected_camp,
		const ad_server_req_param_t *params,
		const ad_server_additional_params_t *additional_params
		);

void write_vast_response(
		FCGX_Request *request,
		video_context_t *video_context,
		const char *buf,
		int sbih,
		double ecpm
		);

extern void create_events_tracking_uri(char *event_tracking_uri,
		const char* tracking_domain,int oper_id, 
		ad_server_req_param_t *params, int adserver_id, int campaign_id, 
		long timestamp, const char *http_protocol, int defaulted_network_id, int defaulted_camp_id);

#endif
