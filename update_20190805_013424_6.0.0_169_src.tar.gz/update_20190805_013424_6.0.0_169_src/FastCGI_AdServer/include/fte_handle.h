/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __FTE_HANDLE_H__
#define __FTE_HANDLE_H__

#include "fcgiapp.h"
#include <db/db_connection.h>
#include <cache/cache_types.h>
#include <util/retargetting_util.h>
#include "ad_server_type_helper.h"

#define MAX_FREQ_CAMPAIGNS_IN_SITE 50

/* This macro defines max size for postfix audience segment expression and this macro should be in sync with MAX_USER_SEGMENT_LIST_SIZE */
#define MAX_SEGMENT_EXPR_SIZE 450


typedef struct campaign_frequency {
        int campaign;
        int frequency;
        int frequency_time_window;
} campaign_frequency_t;


/* structure to store cookie frequency data for a campaign  */
typedef struct fte_freq_data {
	campaign_frequency_t campaign_freq_data[MAX_FREQ_CAMPAIGNS_IN_SITE];
	int ncampaigns;
} fte_freq_data_t;

typedef struct retargetting_pixels_data {
        retargetting_pixels_t *retarget_pixels;
        int npixels;
} retargetting_pixels_data_t;

/* this is to store current active campaign and their associated creatives */
typedef struct campaign_creatives {
	unsigned long campaign_id;
	unsigned long creative_id;
	int filtered;
}campaign_creatives_t;

/* this is wrapping list for campaign_creatives_t */
typedef struct campaign_creative_list {
	campaign_creatives_t *campaign_creatives;
	int ncreatives;
}campaign_creative_list_t;



typedef struct fte_handle {
	db_connection_t dbconn; /* DB connection */
	FCGX_Request request;	
	fte_freq_data_t fte_freq_data;	
	retargetting_pixels_data_t retargeting_pixels;
	int thread_id;
	struct IPCache* pcache_handle;
	int third_party_cookie_allowed;
	int cs_enabled_for_fcap; //This flag indicates whether cookie store is enabled for FCAP or not
	int adflex_frequency;
	campaign_creative_list_t campaign_creative_list;
}fte_handle_t;

#endif

