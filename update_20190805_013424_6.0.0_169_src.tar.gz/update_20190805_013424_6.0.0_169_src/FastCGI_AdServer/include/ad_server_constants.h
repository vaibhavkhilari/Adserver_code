/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef AD_SERVER_CONSTANTS_H
#define AD_SERVER_CONSTANTS_H

/* Include required headers */
#include "common_constants.h"

/* Constant for user cookie name */
#define SERV_ADS_HTML_OPER	1
#define SERV_ADS_JSCRIPT_OPER	2
#define SERV_ADS_OPTIMIZED_JSCRIPT_OPER	3
#define SERV_ADS_VIDEO_OPER 301
#define SERV_ADS_DEBUG_OPER	20
#define SERV_ADS_GDPR_CNS_PARSE_OPER 22
#define SERV_ADS_REGEN_GLOBAL_DATA_STRUCTURE 23

//#define MAX_SINGLE_LINE_LENGTH 12288
#define MAX_SINGLE_LINE_LENGTH 230400 //225K
//#define MAX_ADTAG_LENGTH 25192
#define MAX_ADTAG_LENGTH 307200 //300K

/* CONSTANTS FOR AD CODE TYPE */
#define IFRAME_AD_CODE 0
#define JS_AD_CODE 1
#define MOBILE_JS_AD_CODE 2
#define VIDEO_AD_CODE 3
#define DONT_CARE 5

/*CONSTANTS for ADSERVER RUNTIME DEBUG */
#define DEBUG_REQUEST 4321

#define FORCE_PRE_FILTER_STATS 1 


#define GET_TIMESTAMP_DIFF_IN_MIS(time_diff, end, start) \
  (time_diff) = (((end.tv_sec * 1000000) + end.tv_usec) - ((start.tv_sec * 1000000) + start.tv_usec));

#define APPLY_RANDOM_NUMBER_SAMPLING(random_number, sampling_percentage) \
	(random_number % 10000 <= sampling_percentage * 100)
#endif /* AD_SERVER_CONSTANTS_H */
