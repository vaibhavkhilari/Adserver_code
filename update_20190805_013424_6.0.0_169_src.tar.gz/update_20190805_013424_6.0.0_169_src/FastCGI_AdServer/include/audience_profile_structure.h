
#ifndef __AUDIENCE_PROFILE_STRUCTURE_H__
#define __AUDIENCE_PROFILE_STRUCTURE_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "slist.h"


typedef struct dp_profiles {
	int dpid;
	SLIST audiences;
	SLIST audiences_string;
}dp_profiles_t;


#ifdef __cplusplus
extern "C" {
#endif


void print_int ( void *head );
void* search_int( void *node,const void* search_value);
int compare_slist_int( const void *node1, const void *node2 );

void print_string ( void *head );
void free_generic_ptr( void *ptr );
void* search_string( void *node, const void* search_value);
int compare_slist_string( const void *node1, const void *node2 );
void audience_prof_print ( void *head );

void *audience_prof_search( void *node, const void *search_value );
int audience_prof_compr( const void *node1, const void *node2 );
void audience_prof_free( void *ptr );

#ifdef __cplusplus
}
#endif
#endif

