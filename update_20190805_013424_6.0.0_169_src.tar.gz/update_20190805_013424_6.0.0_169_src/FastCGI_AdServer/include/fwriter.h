/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __FWRITER_H__
#define __FWRITTER_H__

#include "error.h"

/* TODO_SURAJ: Change to appropriate location */
#ifdef IT_DEBUG 
#define debug(format, ...) fprintf(stderr, "D:" format "\n", ##__VA_ARGS__);
#else
#define debug(format, ...)
#endif

	#define error_print(format, ...) fprintf(stderr, "E:" format "\n", ##__VA_ARGS__);
	#define error_log(format, ...) fprintf(stderr, "E:" format "\n", ##__VA_ARGS__);
	#define log(format, ...) fprintf(stderr, "L:" format "\n", ##__VA_ARGS__);

/* TODO_SURAJ: Change to appropriate header files */
#define MAX_FILE_TYPES 7
#define CLICK_FILE_TYPE 0
#define DISPLAY_FILE_TYPE 1
#define ZONE_FILE_TYPE 2
#define ACTIVITY_FILE_TYPE 3
#define CONTEXTUAL_FILE_TYPE 4
#define PIXEL_BLOCK_FILE_TYPE 5
#define VIDEO_FILE_TYPE	6

#define FWRITTER_SUCCESS 0
#define FWRITTER_ERROR 1
#define FWRITTER_TRUE 1
#define FWRITTER_FALSE 0


#define FWRITER_MAX_FILEPATHSIZE 192

/* Configuration Macros */
//#define FWRITER_FILE_MOVE_PERIOD_DEFAULT 5
#define FWRITER_SLEEP_INTERVAL_DEFAULT 5
#define FWRITER_RECORD_CUTOFF_DEFAULT 1
//#define FWRITER_WRITE_DIR "/tracker_data/"
//#define FWRITER_MOVE_DIR "/tracker_moved_data/"


#define FWRITER_THREAD_CREATION_ERROR 1
#define FWRITER_MEMORY_ALLOCATION_ERROR 2
#define FWRITER_CONFIGURATION_ERROR 3
#define FWRITER_FUNCTION_POINTER_ERROR 4
#define FWRITER_INIT_ERROR 5
#define FWRITER_INVALID_ARGS_ERROR 6
#define FWRITER_THREAD_FWRITER_DATA_NOT_INITIALIZED 7
#define FWRITER_FP_ERROR 8
#define FWRITER_WRITE_ERROR 9
#define FWRITER_FILENAME_ERROR 10

typedef struct
{
  FILE *fp[MAX_FILE_TYPES];
   int n_records[MAX_FILE_TYPES];
   int is_valid;
  pthread_mutex_t lock;
   unsigned long creation_time[MAX_FILE_TYPES];
  char file_name[MAX_FILE_TYPES][FWRITER_MAX_FILEPATHSIZE + 1];
}fwriter_thread_node_t;

typedef struct fwriter_data
{
  fwriter_thread_node_t *list;
   int n_threads;
   int sleep_interval;
   int file_move_period;
   int record_cutoff;
  pthread_mutex_t lock;
  char write_dir[FWRITER_MAX_FILEPATHSIZE + 1];
  char move_dir[FWRITER_MAX_FILEPATHSIZE + 1];
  char app_name[FWRITER_MAX_FILEPATHSIZE + 1];
  int (*set_configuration)(struct fwriter_data *fwriter_data);
  void (*get_filename) ( int thread_id, char *filename,  int file_type,  unsigned long current_time);
  int (*should_file_be_moved) (unsigned long creation_time,
                   int file_move_period,  unsigned long current_time, int n_records, int record_cutoff);
  void (*write_to_file) (FILE *fp,  int file_type, void * write_object);
}fwriter_data_t;

int fwriter_finish ( fwriter_data_t *fwriter_data);

int fwriter_write (fwriter_data_t *fwriter_data,  int thread_id,  int file_type,  int n_records, void *write_object);

int is_fwriter_thread_node_initialized (fwriter_thread_node_t *fwriter_thread_node);

int fwriter_init(fwriter_data_t *fwriter_data,
        int (*set_configuration)(fwriter_data_t *fwriter_data));

#endif
