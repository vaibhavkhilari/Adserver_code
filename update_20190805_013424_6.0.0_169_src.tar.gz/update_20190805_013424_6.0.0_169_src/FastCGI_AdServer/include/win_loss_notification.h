/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __WIN_LOSS_NOFIFICATION__
#define __WIN_LOSS_NOFIFICATION__

#include <currency_conversion.h>

//Debug Logs
#ifdef WLN_DEBUG
        #define WLN_DEBUGLOG(format, ...); llog_write(L_DEBUG, "\nWLN: " format " -> %s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__);
#else
        #define WLN_DEBUGLOG(format, ...);
#endif

#define WLN_ERRORLOG(format, ...); llog_write(L_DEBUG, "\nERROR Win Loss Notification: " format " :%s:%d\n", ##__VA_ARGS__, __FILE__, __LINE__);

//General Macros
#define MAX_WINLOSS_STR_LEN		(128+128*MAX_BIDS_LIMIT*MAX_MUX_REQ_PER_CAM)
#define INITIAL_HASH_TABLE_LEN		50
#define HASH_TABLE_REALLOC_FACTOR	2	//Realloc hash table by this factor if tends to become full
#define MAX_ALLOWED_HASH_TABLE_USE	0.6	//Realloc hash table if its used space becomes greater than this factor

//Variable Names
#define WLN_NOTIFICATION_STR	"\"wli\""
#define WLN_REQUEST_ID		"\"rId\""
#define WLN_BID_CURRENCY	"\"bCur\""
#define WLN_WINNING_BID		"\"wBid\""
#define WLN_CLIENT_ACTION_CHECK	"\"csa\""
#define WLN_BID_INFO_STR	"\"bInfo\""
#define WLN_BID_ID		"\"bId\""
#define WLN_STATUS		"\"st\""

//Error Codes
enum WLN_ERROR_CODES {
	WLN_SUCCESS = 0,
	WLN_ERROR,
	WLN_INVALID_ARGS,
	WLN_INVALID_HASHKEY,
	WLN_HASH_TABLE_FULL,
	WLN_BIDS_OVERFLOW,
	WLN_BUFFER_OVERFLOW,
	WLN_NO_MEMORY
};

//win loss reason codes
enum WIN_LOSS_REASON_CODES {
	WLN_UNFILTERED = -1,
	WLN_WON_ACTION = 0,
	WLN_TIMEOUT = 1,
	WLN_INCOMPLETE_RESPONSE = 2,
	WLN_INVALID_BID = 3,
	WLN_OUTBID = 4,
	WLN_ADV_DOMAIN_BLOCKED = 5,
	WLN_ADV_DOMAIN_MISSING = 6,
	WLN_MISSING_CREATIVE_ID = 7,
	WLN_CREATIVE_FILTER = 8,
	WLN_BID_DECRYPTION_FAILED = 9,
	WLN_FLOOR_FILTER = 10, //or prioritization filter
	WLN_REQUEST_ID_MISMATCH = 11,
	WLN_UNSECURE_CREATIVE = 12,
	WLN_INVALID_CURRENCY_CODE = 13,
	WLN_MAX_CREATIVE_SIZE = 14,
	WLN_ACD_FILTER = 15,
	
	WLN_ZERO_BID = 50 	//loss notification for zero bid will not be sent
};


//Structure Definitions
typedef struct campaign_info {
	int campaign_id;					
	int bids_set;				/*Number of bids stored in this struct.. Can be used to index next empty location*/
	char request_id[MAX_UNIQUE_ID_LEN + 1]; /*Request ID of last impression */
	double winning_bid;			/*First price of winning campaign of last impression*/
	int client_auction_enabled;		/*Flag to check if client auction was enabled*/
	char bid_id[MAX_BIDS_LIMIT][MAX_TRANSACTION_ID_SIZE + 1];
	int reasons[MAX_BIDS_LIMIT];
	char bid_currency_code[MAX_CURRENCY_CODE_SIZE];
} campaign_info_t;

typedef struct hash_table {
	campaign_info_t *campaign_info;		/*Pointer to array of campaign_info_t struct*/
	int hash_table_size;			/*Number of elements in campaign_info array (alloc size)*/
	int no_of_campaigns;			/*Number of campaigns set in campaign_info array (use size)*/
} hash_table_t;

//Function definitions
#ifdef __cplusplus
extern "C" {
#endif
	int get_winloss_info_str(char *dest, int max_len, int camp_id, const hash_table_t *hash_table);
#ifdef __cplusplus
}
#endif

int init_winloss_hash_table(hash_table_t *hash_table);
int expand_winloss_hash_table(hash_table_t *hash_table);
int free_winloss_hash_table(hash_table_t *hash_table);

#endif
