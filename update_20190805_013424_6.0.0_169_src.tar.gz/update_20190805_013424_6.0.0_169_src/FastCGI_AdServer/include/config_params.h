/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __CONFIG_PARAMS_H
#define __CONFIG_PARAMS_H

#include<inttypes.h>
#define MAX_PROPERTY_NAME_LEN 128
#define MAX_FILE_PATH 4096
/* please update distributed server count if you are going to use more than 50 servers*/
#define MAX_DISTRIBUTED_SERVER_COUNT 50
#define MAX_RELOAD_FLAG_VALUE_LENGTH 4096
#define MAX_REQUEST_PARAM_LOG_LENGTH 63
#define MAX_DEAL_PARAM_LOG_LENGTH 43
/*assuming max length of a server with port will be 25*/
#define MAX_DISTRIBUTED_CACHE_LIST_LENGTH (MAX_DISTRIBUTED_SERVER_COUNT * 25)
/*config variable names in DB*/
#define ADS_GEO_ENABLED_FLAG "GEO_ENABLED_FLAG"
#define ADS_FTE_ENABLED_FLAG "FTE_ENABLED_FLAG"
#define ADS_RTB_ENABLED_FLAG "RTB_ENABLED_FLAG"
#define ADS_CPC_ENABLED_FLAG "CPC_ENABLED_FLAG"
#define ADS_CONTEXTUAL_ENABLED_FLAG "CONTEXTUAL_ANALYSIS_ENABLED_FLAG"
#define ADS_FREQUENCY_ENABLED_FLAG "FREQUENCY_ENABLED_FLAG"
#define RTB_DEBUG_ENABLED_FLAG "RTB_DEBUG_ENABLED_FLAG"
#define STAT_COLLECTION_ENABLED_FLAG "STAT_COLLECTION_ENABLED_FLAG"
#define AUDIENCE_ENABLED_FLAG "AUDIENCE_ENABLED_FLAG"
#define WURFL_ENABLED_FLAG "WURFL_ENABLED_FLAG"
#define GEO_FILE_PATH "GEO_FILE_PATH"
#define ISP_FILE_PATH "ISP_FILE_PATH"
#define NET_SPEED_FILE_PATH "NET_SPEED_FILE_PATH"
#define NETACUITY_DATA_DIR "NETACUITY_DATA_DIR"
#define ENABLE_MAXMIND_GEO_CLIENT "ENABLE_MAXMIND_GEO_CLIENT"
#define RTB_BIDDER_ENABLED_FLAG "RTB_BIDDER_ENABLED_FLAG"
#define DATACENTER_AWARNESS_ENABLED_FLAG "DATACENTER_AWARNESS_ENABLED_FLAG"
#define CENTRALISED_ICAP_ENABLED_FLAG "CENTRALISED_ICAP_ENABLED_FLAG"
#define COOKIE_STORE_ENABLED_FLAG "COOKIE_STORE_ENABLED_FLAG"
#define MODULE_ENABLED_FLAG "MODULE_ENABLED_FLAG"
#define ADHOC_ANALYSIS_ENABLED "ADHOC_ANALYSIS_ENABLED"
#define CACHE_SWITCH "CACHE_SWITCH"
#define USER_BID_PRICE_CACHING_ENABLED "USER_BID_CACHING_ENABLED"
#define FAST_TARGETING_ENABLED_FLAG "FAST_TARGETING_ENABLED_FLAG"
#define DEBUG_RESPONSE_ENABLED_FLAG "DEBUG_RESPONSE_ENABLED_FLAG"
#define REQUEST_PARAM_LOG "REQUEST_PARAM_LOG"
#define DEAL_PARAM_LOG "DEAL_PARAM_LOG"
#define DISTRIBUTED_CACHE_SERVER_LIST "DISTRIBUTED_CACHE_SERVER_LIST"
#define AUDIENCE_EARLY_MERGE_ENABLE	"AUDIENCE_EARLY_MERGE_ENABLE"
#define ACTIVE_TAG_NEW_APPROACH "ACTIVE_TAG_NEW_APPROACH"
#define USE_EPOLL_FLAG "USE_EPOLL_FLAG"
#define SHUTDOWN_FLAG "SHUTDOWN_FLAG"
#define NETACUITY_DATA_DIR "NETACUITY_DATA_DIR"
#define LOG_TIME_PC_DB "LOG_TIME_PC" 
#define LOG_LEVEL "LOG_LEVEL" 

/*structure contains all the configs params*/
typedef struct adserver_config_params {
	int fte_enabled_flag;
	int geo_enabled_flag;
	int rtb_enabled_flag;
	int contextual_enabled_flag;
	int adserver_frequency_enabled_flag;
	int fte_cpc_enabled_flag;
	int rtb_debug_flag;
	int stats_collection_enable;
	char geo_file_path[MAX_FILE_PATH];
	//sagar
	int rtb_bidder_enabled_flag;
	//~sagar
	int audience_enabled_flag;	/* Flag to indicate audience targeting is enable (1) or disable (0) for campaign */ 
	int adhoc_analysis_enabled_flag;	/* Flag to indicate adhoc analysis is enabled(1)*/
	//int adserver_adhoc_logging_enabled_flag; /* Flag to indicate adhoc analysis is enabled(1)*/
	int wurfl_enabled_flag; /* Flag to denote wurfl call is enabled or not */
	int cookie_store_enabled_flag;
	int datacenter_awarness_enabled_flag; /*Flag to indicate datacenter awarness is enbled or not for datacenter aware functionality i.e ICAP*/
  int centralised_icap_enabled_flag;/*To on/off centralised icap feature by cachepushback*/
  unsigned int cache_switch; /* flag to switch between local & distributed memcache, 0:local 1:both 2:distributed */
	int user_bid_caching_enabled;
	int fast_targeting_enabled_flag; // ON/OFF FAST TARGETING
	char isp_file_path[MAX_FILE_PATH + 1];
	uint64_t module_enabled_flag;
	char net_speed_file_path[MAX_FILE_PATH + 1];

	char request_param_log[MAX_REQUEST_PARAM_LOG_LENGTH+1];
	long request_param_log_pub_id;
	long request_param_log_site_id;
	long request_param_log_tag_id;

	int deal_param_log;
	int debug_response_enabled_flag;
	char distributed_cache_server_list[MAX_DISTRIBUTED_CACHE_LIST_LENGTH + 1];
	int audience_early_merge_enable;
	int active_tag_new_approach;/*if 0 old fcap tag counting will work otherwise new one*/
	char netacuity_data_dir[MAX_FILE_PATH]; // ON/OFF PUGGIXML LIB FOR VAST PARSING
	// LOG_TIME for this percent of impressions.
	double log_time_pc;
	int use_epoll_flag; // if flag is ON then epoll() implementation for RTB call is get used
	int shutdown_flag; // if flag is on then AdServer will shutdown to make way for asan logs
	int log_level; // configure the log level at runtime. default is set to ERROR.
}adserver_config_params_t;

/*structure contains all the mmapped configs params --- used at tracker*/
typedef struct mmap_config_params {
	char geo_file_path[MAX_FILE_PATH+1];
}mmap_config_params_t;


#endif
