/*
 PubMatic Inc. ("PubMatic") CONFIDENTIAL
 Unpublished Copyright (c) 2006-2014 PubMatic, All Rights Reserved.
 
 NOTICE: All information contained herein is, and remains the property of PubMatic. The intellectual and 
technical concepts contained
 herein are proprietary to PubMatic and may be covered by U.S. and Foreign Patents, patents in process, and are 
protected by trade secret or copyright law.
 Dissemination of this information or reproduction of this material is strictly forbidden unless prior written 
permission is obtained
 from PubMatic. Access to the source code contained herein is hereby forbidden to anyone except current 
PubMatic employees, managers or contractors who have executed 
 Confidentiality and Non-disclosure agreements explicitly covering such access.
 
 The copyright notice above does not evidence any actual or intended publication or disclosure of this source 
code, which includes 
 information that is confidential and/or proprietary, and is a trade secret, of PubMatic. ANY REPRODUCTION, 
MODIFICATION, DISTRIBUTION, PUBLIC PERFORMANCE, 
 OR PUBLIC DISPLAY OF OR THROUGH USE OF THIS SOURCE CODE WITHOUT THE EXPRESS WRITTEN CONSENT OF PubMatic IS 
STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE 
 LAWS AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF THIS SOURCE CODE AND/OR RELATED INFORMATION 
DOES NOT CONVEY OR IMPLY ANY RIGHTS 
 TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING THAT IT MAY 
DESCRIBE, IN WHOLE OR IN PART. 
 */


#ifndef __AD_SERVER_VERSION_H__
#define __AD_SERVER_VERSION_H__


/*
* major.minor[.build[.revision]] ..  
* "Major" versions are updated with some major functionality/Epic going in.  
* If some small stories are deployed, "minor" version will be updated. 
* Else just for bug fixes "build" number will be updated.
* "revision" number will be updated in case any problem is adentiefied with build and new build is prepared.  
*/
#ifndef  BUILD_VERSION
#define BUILD_VERSION "5.3.0"
#endif
#ifndef BUILD_NUMBER
#define BUILD_NUMBER "0"
#endif

#define ADS_VERSION BUILD_VERSION"_"BUILD_NUMBER

/*
* In case of any  updare in AdServer revison, add summary of changes in new revision in below section
*/

/*************************** VERSION DETAILS *****************************
*---------------------------------------------------------------------------------------------------------------
*5.3.0.0: Changes for Native, global supply side blocklist, rich media, BSC, video params, conversant IP changes
*5.2.0.0: Changes for IUrl, creative id and dsp campaign id in API response, RID type change from int to string
*5.1.0.0: ASPS-105, new pricing model i.e new way to calculate the closing price for a DSP
*5.0.0.0: In memory cache,centralised icap phase 2
*4.0.0.0: Multi-currency support in RTB
*3.3.0.0: AdServer changes for throttling logic, logging framework and pubclkurl issue fix and operid 201 removal changes
*3.2.0.0: Url categorization changes, rtb response time logging, floor rule issue fix
"3.1.0.0: FPCP issue fix (RPS-74), UDID type changes (ASD-393,396), Audience (APS-50,
AD-167) changes, changes to remove setting 'vep' cookie
*3.0.0.0: Win loss notification in RTB bid request RPS-40 and bid request control RPS-60
*2.1.3.0: MobileFuse S2S adnetwork Integration 
*2.1.2.0: Printinbrowser for Mobile & some logs commented
*2.1.1.0: Creative sync enabled flag at pub_site level 
*2.1.0.0: pub level setting to skip logging params , short term JSON optimisation
*2.0.0.0: Added PMP Support for Mobile and OpenRTB, Distributed memcache changes
*1.9.0.0: Enable rtb_timeout at publisher and publisher-site level
*1.8.0.0: Disabled Expect:100-continue header from RTB and OpenRTB
*1.7.0.0: AdTruth Recipe/License Update, deal whitelist and Caching WRUFL data based on user agent
*1.6.0.0: Mobile: Added support for skipping mandatory params and floors for Ad Networks
*1.5.0.0: Added Support for Video in OpenRTB
*1.4.0.0 UPug bug fix - set cookie under g_conf_pubmatic_domain_name.
*1.3.0.0 Added Publisher Campaign Geo Filter for controlling bid request 
*1.2.1.0 Extended Soft floor for selective inclusion of DSPs
*1.2.0.0 Floor rule revamp and campaign default deprioritisation
*1.0.0.0: Include adserver versioning feature
*1.1.2.0: Fixed issue of click tracking url redirect
*-------------------------------------------------------------------------
*/
#endif


